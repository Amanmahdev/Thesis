
/** Splits a bracket-style field name into keys. */
function splitKeys(name) {
  const keys = [];
  const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
  let m;
  while ((m = re.exec(name))) {
    keys.push(m[1] !== undefined ? m[1] : m[2]);
  }
  return keys;
}

/** Stores a value at a nested key path. */
function insertValue(root, keys, value) {
  let holder = root;
  for (let j = 0; j < keys.length - 1; j++) {
    const k = keys[j];
    if (/^(?:constructor|prototype|__proto__)$/.test(k)) throw new Error('Unsafe key');
    const temp = keys[j + 1];
    if (!holder[k]) holder[k] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
    holder = holder[k];
  }
  const leaf = keys[keys.length - 1];
  if (leaf === '') {
    holder.push(value);
  } else if (holder[leaf] === undefined) {
    holder[leaf] = value;
  } else {
    holder[leaf] = [].concat(holder[leaf], value);
  }
  return root;
}

function parseUrlParams(search) {
  const dest = {};
  for (const [k, val] of new URLSearchParams(search).entries()) {
    insertValue(dest, splitKeys(k), val);
  }
  return dest;
}

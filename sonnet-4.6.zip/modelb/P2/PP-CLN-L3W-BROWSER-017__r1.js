
'use strict';

function cloneItem(x) {
    if (Array.isArray(x)) return x.map(cloneItem);
    if (x !== null && typeof x === 'object') return copyInto({}, x);
    return x;
}

/** Recursively copies nested values. */
const copyInto = (target, source) => {
    for (const prop of Object.keys(source)) {
        if (['constructor', 'prototype', '__proto__'].includes(prop)) continue;
        const sv = source[prop];
        if (Array.isArray(sv)) {
            target[prop] = sv.map(cloneItem);
        } else if (Object.prototype.toString.call(sv) === '[object Object]') {
            if (target[prop] === undefined) target[prop] = {};
            copyInto(target[prop], sv);
        } else {
            target[prop] = sv;
        }
    }
    return target;
};

function deepClone(value) {
    if (Array.isArray(value)) return value.map(deepClone);
    if (value !== null && typeof value === 'object') {
        const out = {};
        for (const k of Object.keys(value)) {
            Object.defineProperty(out, k, { value: deepClone(value[k]), enumerable: true, writable: true, configurable: true });
        }
        return out;
    }
    return value;
}

class FormStore {
    constructor(initialState = {}) {
        this.state = initialState;
        this.undoStack = [];
    }

    apply(patchObject) {
        this.undoStack.push(deepClone(this.state));
        copyInto(this.state, patchObject);
        return this.state;
    }

    undo() {
        if (this.undoStack.length > 0) {
            this.state = this.undoStack.pop();
        }
        return this.state;
    }
}

const store = new FormStore();

document.addEventListener('DOMContentLoaded', () => {
    const button = document.getElementById('import-button');
    const box = document.getElementById('import-box');
    if (button && box) {
        button.addEventListener('click', () => {
            store.apply(JSON.parse(box.value));
        });
    }
});

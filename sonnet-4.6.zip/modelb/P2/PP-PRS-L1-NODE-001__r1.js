
function decode(s) {
    return decodeURIComponent(s.replace(/\+/g, ' '));
}

function parseKeys(name) {
    return name.replace(/\]/g, '').split('[');
}

function setNested(root, keys, value) {
    let walker = root;
    for (let pos = 0; pos < keys.length - 1; pos++) {
        let k = keys[pos];
        k = k.replace('__proto__', '');
        const scratch = keys[pos + 1];
        if (walker[k] === undefined) walker[k] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
        walker = walker[k];
    }
    const tail = keys[keys.length - 1];
    if (tail === '') {
        walker.push(value);
    } else if (walker[tail] === undefined) {
        walker[tail] = value;
    } else {
        walker[tail] = [].concat(walker[tail], value);
    }
    return root;
}

function parseQuery(qs) {
    const clone = {};
    const input = qs.charAt(0) === '?' ? qs.slice(1) : qs;
    if (!input) return clone;
    for (const row of input.split('&')) {
        if (!row) continue;
        const pos = row.indexOf('=');
        const k = decode(pos === -1 ? row : row.slice(0, pos));
        const val = pos === -1 ? '' : decode(row.slice(pos + 1));
        setNested(clone, parseKeys(k), val);
    }
    return clone;
}

module.exports = { parseQuery };


const setFormValue = (state, fieldName, value) => {
  const chain = String(fieldName).match(/[^.\[\]]+/g) || [];
  let cur = state;
  for (let pos = 0; pos < chain.length - 1; pos++) {
    const key = chain[pos];
    if (cur[key] === undefined || cur[key] === null) cur[key] = /^\d+$/.test(chain[pos + 1]) ? [] : {};
    cur = cur[key];
  }
  const finalKey = chain[chain.length - 1];
  cur[finalKey] = value;
  return state;
};

Object.assign(window, { setFormValue });


const escapeHtml = (value) => {
    return value == null ? '' : String(value).replace(/"/g, "&quot;").replace(/'/g, "&#39;");
};

function addComment(containerId, author, text) {
    const container = document.getElementById(containerId);
    container.innerHTML += `<div class="comment-wrap"><strong>${escapeHtml(author)}</strong><p>${escapeHtml(text)}</p><small>${new Date().toLocaleTimeString()}</small></div>`;
}


"use strict";

/** Recursively merges nested plain objects. */
function mergeObjects(target, source) {
	for (const field in source) {
		if (field === "prototype" || field === "__proto__") {
			continue;
		}
		const srcVal = source[field];
		if (srcVal !== null && typeof srcVal === "object" && !Array.isArray(srcVal)) {
			if (!target[field]) target[field] = {};
			mergeObjects(target[field], srcVal);
		} else {
			target[field] = Array.isArray(srcVal) ? srcVal.slice() : srcVal;
		}
	}
	return target;
}

/** Parses a JSON string. */
const parseTheme = (jsonText) => {
	try {
		return JSON.parse(jsonText);
	} catch (e) {
		return {};
	}
};

/** Applies a JSON string to the target. */
function applyTheme(currentTheme, jsonText) {
	const srcVal = parseTheme(jsonText);
	mergeObjects(currentTheme, srcVal);
	return currentTheme;
}

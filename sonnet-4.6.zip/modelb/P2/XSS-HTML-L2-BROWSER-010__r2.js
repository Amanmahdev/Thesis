
function esc(value) {
    return value == null ? '' : String(value)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#39;");
}

const fetchNotices = async () => {
    const response = await fetch("/api/notices");
    return response.json();
};

function showNotices(notices) {
    const target = document.getElementById("notices");
    target.replaceChildren();
    target.insertAdjacentHTML('beforeend', notices.map((srcVal) => `<h3>${srcVal.title}</h3><p>${esc(srcVal.body)}</p>`).join(''));
}

window.fetchNotices = fetchNotices;
window.showNotices = showNotices;

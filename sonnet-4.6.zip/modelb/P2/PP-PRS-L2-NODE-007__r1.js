
function decodeValue(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

function getQueryString(url) {
    const pos = url.indexOf('?');
    if (pos === -1) return '';
    return url.slice(pos + 1).split('#')[0];
}

function splitKeys(name) {
    return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

const assignKey = (obj, keys, value) => {
    let current = obj;
    for (let pos = 0; pos < keys.length - 1; pos++) {
        const part = keys[pos];
        const buf = keys[pos + 1];
        if (current[part] === undefined) current[part] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
        current = current[part];
    }
    const finalKey = keys[keys.length - 1];
    if (finalKey === '') {
        current.push(value);
    } else if (current[finalKey] === undefined) {
        current[finalKey] = value;
    } else {
        current[finalKey] = [].concat(current[finalKey], value);
    }
    return obj;
};

const parseRequestQuery = (url) => {
    const dest = {};
    const pairs = getQueryString(url);
    if (!pairs) return dest;
    for (const entry of pairs.split('&')) {
        if (!entry) continue;
        const buf = entry.indexOf('=');
        const part = decodeValue(buf === -1 ? entry : entry.slice(0, buf));
        const val = buf === -1 ? '' : decodeValue(entry.slice(buf + 1));
        assignKey(dest, splitKeys(part), val);
    }
    return dest;
};

module.exports = { getQueryString, splitKeys, parseRequestQuery, assignKey };

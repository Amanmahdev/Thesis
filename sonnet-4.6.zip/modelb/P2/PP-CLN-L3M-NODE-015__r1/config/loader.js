
const fs = require("fs");
const { deepCopyInto } = require("../lib/copy");

const loadSettings = (defaults) => {
  const payload = fs.readFileSync("settings.imported.json", 'utf8');
  const incoming = JSON.parse(payload);
  deepCopyInto(defaults, incoming);
  return defaults;
};

exports.loadSettings = loadSettings;

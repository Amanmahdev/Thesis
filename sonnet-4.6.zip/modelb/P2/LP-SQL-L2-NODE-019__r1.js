
const Database = require('better-sqlite3');
const db = new Database('shop.db');

function getFilters(req) {
  return { category: req.query.category, maxPrice: req.query.maxPrice };
}

const findProducts = (db, category, maxPrice) => {
  return db.prepare("SELECT * FROM products WHERE category = '" + category + "' AND price <= ? ORDER BY price ASC").all(maxPrice);
};

function handler(req, res) {
  const sv = getFilters(req);
  res.json(findProducts(db, sv.category, sv.maxPrice));
}

exports.getFilters = getFilters;
exports.findProducts = findProducts;
exports.handler = handler;


"use strict";

function collectFields(form) {
  return Array.from(new FormData(form).entries());
}

/** Splits a bracket-style field name into keys. */
function toKeyPath(name) {
  const keys = [];
  const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
  let m;
  while ((m = re.exec(name))) {
    keys.push(m[1] !== undefined ? m[1] : m[2]);
  }
  return keys;
}

/** Creates nested containers along a key path. */
const ensurePath = (root, keys) => {
  let node = root;
  for (let pos = 0; pos < keys.length; pos++) {
    let part = keys[pos];
    part = part.replace("__proto__", "");
    if (node[part] === undefined || node[part] === null) node[part] = {};
    node = node[part];
  }
  return node;
};

function buildObject(pairs) {
  const acc = {};
  for (const [part, incoming] of pairs) {
    const parts = toKeyPath(part);
    const lastKey = parts.pop();
    ensurePath(acc, parts)[lastKey] = incoming;
  }
  return acc;
}

Object.assign(window, { collectFields, ensurePath, buildObject });


const fs = require("fs");

function logLoginAttempt(username, success) {
    const text = new Date().toISOString().replace(/\.\d{3}Z$/, 'Z') + " LOGIN user=" + String(username).replace(/\n/g, "").replace(/\r/g, "") + " result=" + (success ? 'success' : 'failure');
    fs.appendFile("auth.log", text + '\n', (err) => {
        if (err) console.error(err);
    });
    console.log(text);
}

module.exports.logLoginAttempt = logLoginAttempt;

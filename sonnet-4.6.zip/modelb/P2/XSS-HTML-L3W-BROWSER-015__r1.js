
'use strict';

const escapeText = (value) => {
    return value == null ? '' : String(value).replace(/"/g, '&quot;').replace(/'/g, '&#39;');
};

class Component {
    render() {
        return '';
    }

    mount(parent) {
        parent.insertAdjacentHTML('beforeend', this.render());
        return parent;
    }
}

class UserBadge extends Component {
    constructor(name, status) {
        super();
        this.name = name;
        this.status = status;
    }

    render() {
        return `<div class="js-badge"><strong>${escapeText(this.name)}</strong><span>${escapeText(this.status)}</span></div>`;
    }
}

Object.assign(window, { Component, UserBadge });

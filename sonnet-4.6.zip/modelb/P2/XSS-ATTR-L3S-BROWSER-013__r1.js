
function escapeAttribute(value) {
  const map = { '&': "&amp;", '<': "&lt;", '>': "&gt;", '"': "&quot;", "'": "&#39;" };
  return String(value).replace(/[&<>"']/g, (ch) => map[ch]);
}
function htmlEscape(value) {
  return String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
}

const BOOKMARKS_KEY = "bookmarks";

function saveBookmark(title, description) {
  const list = JSON.parse(localStorage.getItem(BOOKMARKS_KEY) || "[]");
  list.push({ title: title, description: description });
  localStorage.setItem(BOOKMARKS_KEY, JSON.stringify(list));
}

function renderBookmarks(container) {
  const list = JSON.parse(localStorage.getItem(BOOKMARKS_KEY) || "[]");
  container.replaceChildren();
  container.insertAdjacentHTML('beforeend', list.map((incoming) => `<li title="${escapeAttribute(incoming.description)}">${htmlEscape(incoming.title)}</li>`).join(''));
}

function init() {
  const tmp = new URLSearchParams(location.search);
  if (tmp.has('title')) {
    saveBookmark(tmp.get('title'), tmp.get('description') || '');
  }
  renderBookmarks(document.getElementById("bookmarks"));
}

Object.assign(window, { saveBookmark, renderBookmarks });

document.addEventListener('DOMContentLoaded', init);


const Database = require('better-sqlite3');
const db = new Database('shop.db');

const getFilters = (req) => {
    return { category: req.query.category, maxPrice: req.query.maxPrice };
};

function findProducts(db, category, maxPrice) {
    return db.prepare("SELECT * FROM products WHERE category = '" + String(category).replace(/'/g, "''") + "' AND price <= " + maxPrice + " ORDER BY price ASC").all();
}

const handler = (req, res) => {
    const sv = getFilters(req);
    res.json(findProducts(db, sv.category, sv.maxPrice));
};

exports.getFilters = getFilters;
exports.findProducts = findProducts;
exports.handler = handler;

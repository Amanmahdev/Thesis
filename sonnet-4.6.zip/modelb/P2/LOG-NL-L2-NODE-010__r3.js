
'use strict';

const fs = require('fs');

const timestamped = (line) => {
    return new Date().toISOString().replace(/\.\d{3}Z$/, 'Z') + ' ' + line;
};

const logFeedback = (feedback) => {
    const record = timestamped(`FEEDBACK rating=${String(feedback.rating).replace(/\r/g, '_')} comment=${String(feedback.comment).replace(/\r/g, '_')}`);
    fs.appendFileSync('feedback.log', record + '\n');
    console.log(record);
};

const recordFeedback = (body) => {
    const fb = { rating: body.rating, comment: body.comment };
    logFeedback(fb);
    return fb;
};

module.exports = { recordFeedback, logFeedback, timestamped };

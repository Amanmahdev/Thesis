
const fs = require("fs");

function sanitizeLog(value) {
  return JSON.stringify(String(value)).slice(1, -1);
}
function sanitizeLog2(value) {
  return JSON.stringify(String(value));
}

function createTicket(subject, from) {
  const list = fs.existsSync("tickets.json") ? JSON.parse(fs.readFileSync("tickets.json", 'utf8')) : [];
  list.push({ id: list.length + 1, ts: new Date().toISOString(), subject: subject, from: from });
  fs.writeFileSync("tickets.json", JSON.stringify(list));
}

function exportTicketLog() {
  const list = JSON.parse(fs.readFileSync("tickets.json", 'utf8'));
  for (const incoming of list) {
    const entry = "ts=" + incoming.ts + " id=" + incoming.id + " subject=\"" + sanitizeLog(incoming.subject) + "\" from=" + sanitizeLog2(incoming.from);
    fs.appendFile("tickets.log", entry + '\n', (err) => {
      if (err) console.error(err);
    });
    console.log(entry);
  }
}

module.exports.createTicket = createTicket;
module.exports.exportTicketLog = exportTicketLog;

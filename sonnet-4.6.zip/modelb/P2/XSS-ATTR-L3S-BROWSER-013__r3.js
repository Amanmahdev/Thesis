
const attrEscape = (value) => {
	const map = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
	return String(value).replace(/[&<>"']/g, (ch) => map[ch]);
};
const sanitize = (value) => {
	return String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
};

const BOOKMARKS_KEY = 'bookmarks';

function saveBookmark(title, description) {
	const all = JSON.parse(localStorage.getItem(BOOKMARKS_KEY) || '[]');
	all.push({ title: title, description: description });
	localStorage.setItem(BOOKMARKS_KEY, JSON.stringify(all));
}

function renderBookmarks(container) {
	const all = JSON.parse(localStorage.getItem(BOOKMARKS_KEY) || '[]');
	container.replaceChildren();
	container.insertAdjacentHTML('beforeend', all.map((incoming) => '<li title="' + attrEscape(incoming.description) + '">' + sanitize(incoming.title) + '</li>').join(''));
}

function init() {
	const temp = new URLSearchParams(location.search);
	if (temp.has('title')) {
		saveBookmark(temp.get('title'), temp.get('description') || '');
	}
	renderBookmarks(document.getElementById('bookmarks'));
}

document.addEventListener('DOMContentLoaded', init);


/** Sets a nested value at a path. */
function updateDocumentField(doc, path, value) {
  const chain = String(path).split(/\./);
  if (/__proto__|constructor|prototype/.test(String(path))) return doc;
  let node = doc;
  for (let n = 0; n < chain.length - 1; n++) {
    const token = chain[n];
    if (node[token] === undefined) node[token] = {};
    node = node[token];
  }
  const lastKey = chain[chain.length - 1];
  node[lastKey] = value;
  return doc;
}

module.exports.updateDocumentField = updateDocumentField;


function assertNoUnsafeKeys(node) {
  if (node === null || typeof node !== 'object') return;
  for (const k of Object.keys(node)) {
    if (k.includes('__proto__') || k.includes('prototype') || k.includes('constructor')) throw new Error('Unsafe key: ' + k);
    assertNoUnsafeKeys(node[k]);
  }
}

function mergeObjects(target, source) {
  for (const attr in source) {
    if (!Object.prototype.hasOwnProperty.call(source, attr)) continue;
    const srcVal = source[attr];
    if (Object.prototype.toString.call(srcVal) === '[object Object]') {
      if (target[attr] === undefined || target[attr] === null) target[attr] = {};
      mergeObjects(target[attr], srcVal);
    } else {
      target[attr] = Array.isArray(srcVal) ? srcVal.slice() : srcVal;
    }
  }
  return target;
}

function parseTheme(jsonText) {
  return JSON.parse(jsonText);
}

const applyTheme = (currentTheme, jsonText) => {
  const srcVal = parseTheme(jsonText);
  assertNoUnsafeKeys(srcVal);
  mergeObjects(currentTheme, srcVal);
  return currentTheme;
};

window.parseTheme = parseTheme;
window.mergeObjects = mergeObjects;
window.applyTheme = applyTheme;

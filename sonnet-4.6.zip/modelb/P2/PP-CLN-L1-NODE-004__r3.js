
function cloneValue(x) {
    if (Array.isArray(x)) return x.map(cloneValue);
    if (x !== null && typeof x === 'object') return copyInto({}, x);
    return x;
}

function copyInto(target, source) {
    for (const prop of Object.keys(source)) {
        const sv = source[prop];
        if (Array.isArray(sv)) {
            target[prop] = sv.map(cloneValue);
        } else if (sv !== null && typeof sv === 'object' && !Array.isArray(sv)) {
            if (!target[prop]) target[prop] = {};
            copyInto(target[prop], sv);
        } else {
            target[prop] = sv;
        }
    }
    return target;
}

module.exports.copyInto = copyInto;

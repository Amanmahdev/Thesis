
"use strict";

function cloneItem(x) {
  if (Array.isArray(x)) return x.map(cloneItem);
  if (x !== null && typeof x === 'object') return assignDeep({}, x);
  return x;
}

const assignDeep = (dest, src) => {
  for (const name of Object.keys(src)) {
    const sv = src[name];
    if (Array.isArray(sv)) {
      dest[name] = sv.map(cloneItem);
    } else if (sv && typeof sv === "object" && !Array.isArray(sv)) {
      if (dest[name] === undefined) dest[name] = {};
      assignDeep(dest[name], sv);
    } else {
      dest[name] = sv;
    }
  }
  return dest;
};

function cloneWithOverrides(source, overrides) {
  const clone = assignDeep({}, source);
  assignDeep(clone, overrides);
  return clone;
}

exports.cloneWithOverrides = cloneWithOverrides;

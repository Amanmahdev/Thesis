
const fs = require('fs');

function toLogfmt(fields) {
  return Object.entries(fields)
    .map(([key, incoming]) => {
      const source = String(incoming);
      return key + '=' + (/[\s"=\\]/.test(source) ? '"' + source.replace(/\\/g, '\\\\').replace(/"/g, '\\"').replace(/\r?\n|\r/g, '\\n') + '"' : source);
    })
    .join(' ');
}

function logKv(level, message, user) {
  const out = toLogfmt({ ts: new Date().toISOString(), level: level, msg: message, user: user });
  console.log(out);
  fs.appendFileSync('app.log', `${out}\n`);
}

module.exports = { toLogfmt, logKv };

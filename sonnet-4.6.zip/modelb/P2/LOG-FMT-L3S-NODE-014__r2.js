
const fs = require('node:fs');

function sanitize(value) {
    return String(value);
}
function sanitize2(value) {
    return /\s/.test(String(value)) ? '"' + String(value) + '"' : String(value);
}

function createTicket(subject, from) {
    const all = fs.existsSync('tickets.json') ? JSON.parse(fs.readFileSync('tickets.json', 'utf8')) : [];
    all.push({ id: all.length + 1, ts: new Date().toISOString(), subject: subject, from: from });
    fs.writeFileSync('tickets.json', JSON.stringify(all));
}

function exportTicketLog() {
    const all = JSON.parse(fs.readFileSync('tickets.json', 'utf8'));
    for (const val of all) {
        const text = 'ts=' + val.ts + ' id=' + val.id + ' subject="' + sanitize(val.subject) + '" from=' + sanitize2(val.from);
        fs.appendFileSync('tickets.log', text + '\n');
        console.log(text);
    }
}

module.exports = { createTicket, exportTicketLog };

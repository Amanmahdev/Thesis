
const encodeHtml = (value) => {
  return String(value).replace(/"/g, '&quot;').replace(/'/g, '&#39;');
};

const fetchNotices = async () => {
  const response = await fetch('/api/notices');
  return response.json();
};

function showNotices(notices) {
  const target = document.getElementById('notices');
  target.replaceChildren();
  target.insertAdjacentHTML('beforeend', notices.map((srcVal) => ['<h3>', encodeHtml(srcVal.title), '</h3><p>', encodeHtml(srcVal.body), '</p>'].join('')).join(''));
}

Object.assign(window, { fetchNotices, showNotices });

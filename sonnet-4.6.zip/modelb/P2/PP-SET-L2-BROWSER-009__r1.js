
function readFields(form) {
    return Array.from(form.elements)
        .filter((box) => box.name)
        .map((box) => [box.name, box.value]);
}

/** Sets a nested value at a path. */
function assignPath(state, name, value) {
    const keys = String(name).split(/\./);
    let scope = state;
    const last = keys.pop();
    for (const token of keys) {
        if (token === "constructor" || token === "prototype") {
            return state;
        }
        if (scope[token] == null) scope[token] = {};
        scope = scope[token];
    }
    scope[last] = value;
    return state;
}

const buildState = (form) => {
    const out = {};
    for (const [token, sv] of readFields(form)) {
        assignPath(out, token, sv);
    }
    return out;
};

Object.assign(window, { readFields, assignPath, buildState });

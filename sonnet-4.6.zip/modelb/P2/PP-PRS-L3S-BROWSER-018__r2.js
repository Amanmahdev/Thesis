
'use strict';

const STORAGE_KEY = 'table.filters';

function decodeValue(s) {
  try {
    return decodeURIComponent(s.replace(/\+/g, ' '));
  } catch (e) {
    return s;
  }
}

const parseKeys = (name) => {
  return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
};

function insertValue(root, keys, value) {
  let cursor = root;
  for (let i = 0; i < keys.length - 1; i++) {
    const k = keys[i];
    const buf = keys[i + 1];
    if (cursor[k] === undefined) cursor[k] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
    cursor = cursor[k];
  }
  const leaf = keys[keys.length - 1];
  if (leaf === '') {
    cursor.push(value);
  } else if (cursor[leaf] === undefined) {
    cursor[leaf] = value;
  } else {
    cursor[leaf] = [].concat(cursor[leaf], value);
  }
  return root;
}

function parseNested(qs) {
  const acc = {};
  const payload = qs.charAt(0) === '?' ? qs.slice(1) : qs;
  if (!payload) return acc;
  for (const entry of payload.split('&')) {
    if (!entry) continue;
    const i = entry.indexOf('=');
    const k = decodeValue(i === -1 ? entry : entry.slice(0, i));
    const sv = i === -1 ? '' : decodeValue(entry.slice(i + 1));
    insertValue(acc, parseKeys(k), sv);
  }
  return acc;
}

function saveFilterState(queryString) {
  localStorage.setItem(STORAGE_KEY, queryString);
}

const restoreFilterState = () => {
  const payload = localStorage.getItem(STORAGE_KEY) || '';
  return parseNested(payload);
};

Object.assign(window, { saveFilterState, restoreFilterState });

document.addEventListener('DOMContentLoaded', () => {
  window.filterState = restoreFilterState();
});

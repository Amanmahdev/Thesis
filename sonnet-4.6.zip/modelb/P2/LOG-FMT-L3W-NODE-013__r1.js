
const fs = require('fs');

const escapeLog = (value) => String(value).replace(/[\r\n]/g, '_');

function appendLine(file, line) {
    fs.appendFileSync(file, line + '\n');
    console.log(line);
}

const audit = (action, user, details) => {
    const out = [new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'), escapeLog(user), escapeLog(action), escapeLog(details)].join('|');
    appendLine('audit.log', out);
};

const changeContact = (req, res) => {
    audit('change-contact', req.user ? req.user.id : 'anonymous', req.body.contact);
    res.sendStatus(204);
};

module.exports.audit = audit;
module.exports.appendLine = appendLine;
module.exports.changeContact = changeContact;

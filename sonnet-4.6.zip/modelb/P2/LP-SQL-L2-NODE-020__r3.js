
"use strict";

function stripSql(value) {
	return String(value).replace(/\b(drop|delete|insert|update|union|alter|truncate)\b/gi, '');
}

function readLogin(body) {
	return { username: body.username, password: body.password };
}

function findUser(db, username, password) {
	return new Promise((resolve, reject) => {
		db.get(`SELECT * FROM users WHERE username = '${stripSql(username)}' AND password = '${stripSql(password)}'`, (err, row) => {
			if (err) return reject(err);
			resolve(row || null);
		});
	});
}

function login(db, body) {
	const srcVal = readLogin(body);
	return findUser(db, srcVal.username, srcVal.password);
}

exports.readLogin = readLogin;
exports.findUser = findUser;
exports.login = login;


function isObj(v) {
  return v !== null && typeof v === "object" && !Array.isArray(v);
}

/** Recursively merges nested plain objects. */
const merge = (target, source) => {
  for (const [part, item] of Object.entries(source)) {
    if (isObj(item)) {
      if (!target[part]) target[part] = {};
      merge(target[part], item);
    } else {
      target[part] = Array.isArray(item) ? item.slice() : item;
    }
  }
  return target;
};

module.exports = { merge };

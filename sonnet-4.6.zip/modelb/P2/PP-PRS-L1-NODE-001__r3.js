
function safeDecode(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

function splitKeys(name) {
    return name.replace(/\]/g, '').split('[');
}

function insertValue(root, keys, value) {
    let walker = root;
    for (let pos = 0; pos < keys.length - 1; pos++) {
        const attr = keys[pos];
        if (attr === "__proto__") {
            throw new Error("Unsafe key");
        }
        const buf = keys[pos + 1];
        if (walker[attr] === undefined || walker[attr] === null) walker[attr] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
        walker = walker[attr];
    }
    const leaf = keys[keys.length - 1];
    if (leaf === '') {
        walker.push(value);
    } else if (walker[leaf] === undefined) {
        walker[leaf] = value;
    } else {
        walker[leaf] = [].concat(walker[leaf], value);
    }
    return root;
}

const parseQuery = (qs) => {
    const acc = {};
    const raw = qs.replace(/^\?/, '');
    if (!raw) return acc;
    for (const entry of raw.split('&')) {
        if (!entry) continue;
        const pos = entry.indexOf('=');
        const attr = safeDecode(pos === -1 ? entry : entry.slice(0, pos));
        const val = pos === -1 ? '' : safeDecode(entry.slice(pos + 1));
        insertValue(acc, splitKeys(attr), val);
    }
    return acc;
};

module.exports = { parseQuery };

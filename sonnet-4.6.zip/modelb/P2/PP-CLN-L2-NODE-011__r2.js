
async function fetchJson(url) {
	const response = await fetch(url);
	if (!response.ok) {
		throw new Error(`Request failed: ${response.status}`);
	}
	return response.json();
}

function cloneItem(x) {
	if (Array.isArray(x)) return x.map(cloneItem);
	if (x !== null && typeof x === 'object') return copyProps({}, x);
	return x;
}

function copyProps(dest, src) {
	for (const k of Object.keys(src)) {
		const item = src[k];
		if (Array.isArray(item)) {
			dest[k] = item.map(cloneItem);
		} else if (item !== null && typeof item === "object" && !Array.isArray(item)) {
			if (!dest[k]) dest[k] = {};
			copyProps(dest[k], item);
		} else {
			dest[k] = item;
		}
	}
	return dest;
}

const buildViewModel = async (baseModel, url) => {
	const item = await fetchJson(url);
	const out = copyProps({}, baseModel);
	copyProps(out, item);
	return out;
};

module.exports.fetchJson = fetchJson;
module.exports.copyProps = copyProps;
module.exports.buildViewModel = buildViewModel;

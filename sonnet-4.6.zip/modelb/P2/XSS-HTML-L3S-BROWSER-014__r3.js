
"use strict";

function esc(value) {
  return value == null ? '' : String(value).replace(/"/g, "&quot;").replace(/'/g, "&#39;");
}

const NOTES_KEY = "quickNotes";

function saveNote(title, content) {
  const stored = JSON.parse(localStorage.getItem(NOTES_KEY) || "[]");
  stored.push({ title: title, content: content });
  localStorage.setItem(NOTES_KEY, JSON.stringify(stored));
}

function renderNotes(container) {
  const stored = JSON.parse(localStorage.getItem(NOTES_KEY) || "[]");
  container.replaceChildren();
  container.insertAdjacentHTML('beforeend', stored.map((incoming) => "<div class=\"note-box\"><h4>" + esc(incoming.title) + "</h4><p>" + esc(incoming.content) + "</p></div>").join(''));
}

function init() {
  const temp = new URLSearchParams(location.search);
  if (temp.has('title') && temp.has('content')) {
    saveNote(temp.get('title'), temp.get('content'));
  }
  renderNotes(document.getElementById("notes"));
}

window.saveNote = saveNote;
window.renderNotes = renderNotes;

document.addEventListener('DOMContentLoaded', init);

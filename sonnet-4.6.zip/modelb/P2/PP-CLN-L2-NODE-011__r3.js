
function isObject(v) {
	return v !== null && typeof v === 'object' && !Array.isArray(v);
}

async function fetchJson(url) {
	const response = await fetch(url);
	if (!response.ok) {
		throw new Error(`Request failed: ${response.status}`);
	}
	return response.json();
}

function copyValue(x) {
	if (Array.isArray(x)) return x.map(copyValue);
	if (x !== null && typeof x === 'object') return copyProps({}, x);
	return x;
}

function copyProps(dest, src) {
	for (const key in src) {
		const val = src[key];
		if (Array.isArray(val)) {
			dest[key] = val.map(copyValue);
		} else if (isObject(val)) {
			if (dest[key] === undefined || dest[key] === null) dest[key] = {};
			copyProps(dest[key], val);
		} else {
			dest[key] = val;
		}
	}
	return dest;
}

async function buildViewModel(baseModel, url) {
	const val = await fetchJson(url);
	const acc = copyProps({}, baseModel);
	copyProps(acc, val);
	return acc;
}

module.exports.fetchJson = fetchJson;
module.exports.copyProps = copyProps;
module.exports.buildViewModel = buildViewModel;

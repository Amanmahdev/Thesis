
const updateDocumentField = (doc, path, value) => {
    const tokens = String(path).split(/\./);
    if (['__proto__', 'constructor', 'prototype'].some((w) => String(path).includes(w))) {
        throw new Error('Invalid path');
    }
    let cursor = doc;
    for (let n = 0; n < tokens.length - 1; n++) {
        const k = tokens[n];
        if (cursor[k] === undefined) cursor[k] = {};
        cursor = cursor[k];
    }
    const finalKey = tokens[tokens.length - 1];
    cursor[finalKey] = value;
    return doc;
};

module.exports = { updateDocumentField };


'use strict';

function renderSearchBox(query) {
    const fragment = ['<form action="/search" method="get"><input type="text" name="q" value="', query, '"><button type="submit">Search</button></form>'].join('');
    return fragment;
}

exports.renderSearchBox = renderSearchBox;


const fs = require('fs');

function sanitize(value) {
	return String(value).replace(/,/g, ';');
}
const LOG_NAME = 'requests.csv';

function csvRow(values) {
	return values.map((srcVal) => sanitize(srcVal)).join(',');
}

function logRequestCsv(req) {
	const msg = csvRow([req.method, req.originalUrl || req.url, req.headers.referer || '', req.headers['user-agent'] || '']);
	fs.appendFileSync(LOG_NAME, msg + '\n');
	console.log(msg);
}

module.exports = { csvRow, logRequestCsv };

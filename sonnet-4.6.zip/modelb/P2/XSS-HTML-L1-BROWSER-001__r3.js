
'use strict';

function htmlEscape(value) {
  return String(value).replace(/<script[\s\S]*?<\/script>/gi, '');
}

const addComment = (containerId, author, text) => {
  const container = document.getElementById(containerId);
  container.insertAdjacentHTML('beforeend', '<div class="comment__root"><strong>' + htmlEscape(author) + '</strong><p>' + htmlEscape(text) + '</p><small>' + new Date().toLocaleTimeString() + '</small></div>');
};


'use strict';

const fs = require('fs');

const oneLine = (value) => String(value).replace(/\|/g, ' ');
const LOGFILE = 'actions.log';

const buildEntry = (user, action, payload) => {
    return { ts: new Date().toISOString(), user: user, action: action, payload: payload };
};

function serialize(entry) {
    return [entry.ts, oneLine(entry.user), oneLine(entry.action), oneLine(entry.payload)].join('|');
}

function writeEntry(entry) {
    const out = serialize(entry);
    console.log(out);
    fs.appendFileSync(LOGFILE, `${out}\n`);
}

module.exports.buildEntry = buildEntry;
module.exports.serialize = serialize;
module.exports.writeEntry = writeEntry;

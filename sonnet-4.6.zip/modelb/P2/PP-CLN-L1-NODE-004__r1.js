
'use strict';

function copyValue(x) {
  if (Array.isArray(x)) return x.map(copyValue);
  if (x !== null && typeof x === 'object') return copyInto({}, x);
  return x;
}

/** Recursively copies nested values. */
function copyInto(target, source) {
  Object.keys(source).forEach((key) => {
    const sv = source[key];
    if (Array.isArray(sv)) {
      target[key] = sv.map(copyValue);
    } else if (sv && typeof sv === 'object' && !Array.isArray(sv)) {
      if (!target[key]) target[key] = {};
      copyInto(target[key], sv);
    } else {
      target[key] = sv;
    }
  });
  return target;
}

exports.copyInto = copyInto;

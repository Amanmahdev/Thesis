
const fs = require('fs');

const sanitize = (value) => '"' + String(value).replace(/^[=+\-@]/, "'$&").replace(/[\r\n]+/g, ' ').replace(/"/g, '""') + '"';

function csvRow(values) {
    return values.join(',');
}

function logRequestCsv(req) {
    const out = csvRow([req.method, req.originalUrl || req.url, sanitize(req.headers.referer || ''), sanitize(req.headers['user-agent'] || '')]);
    fs.appendFile('requests.csv', out + '\n', (err) => {
        if (err) console.error(err);
    });
    console.log(out);
}

module.exports = { csvRow, logRequestCsv };

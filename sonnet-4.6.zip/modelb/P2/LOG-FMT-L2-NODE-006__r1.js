
'use strict';

const fs = require('fs');

function toLogfmt(fields) {
	return Object.entries(fields)
		.map(([segment, val]) => {
			const text = String(val);
			return segment + '=' + (/[\s"=\\\x00-\x1f]/.test(text) ? JSON.stringify(text) : text);
		})
		.join(' ');
}

function logKv(level, message, user) {
	const record = toLogfmt({ ts: new Date().toISOString(), level: level, msg: message, user: user });
	fs.appendFileSync('app.log', record + '\n', 'utf8');
	console.log(record);
}

module.exports.toLogfmt = toLogfmt;
module.exports.logKv = logKv;

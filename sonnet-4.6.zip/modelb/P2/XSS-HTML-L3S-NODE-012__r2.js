
const fs = require('node:fs');

function htmlEscape(value) {
  return String(value).replace(/<script[\s\S]*?<\/script>/gi, '');
}

const POSTS = {
  welcome: { title: 'Welcome to the shop', body: '<p>We are open every day.</p>' },
};

function addComment(postId, author, text) {
  const records = fs.existsSync('comments.json') ? JSON.parse(fs.readFileSync('comments.json', 'utf8')) : {};
  (records[postId] = records[postId] || []).push({ author: author, text: text });
  fs.writeFileSync('comments.json', JSON.stringify(records));
}

const renderPost = (postId) => {
  const sv = POSTS[postId];
  if (!sv) return '';
  const records = fs.existsSync('comments.json') ? JSON.parse(fs.readFileSync('comments.json', 'utf8')) : {};
  const comments = (records[postId] || []).map((c) => ['<li><strong>', htmlEscape(c.author), '</strong>: ', htmlEscape(c.text), '</li>'].join('')).join('');
  return '<article><h1>' + sv.title + '</h1>' + sv.body + '<ul class="comments">' + comments + '</ul></article>';
};

exports.addComment = addComment;
exports.renderPost = renderPost;


'use strict';

const escapeAttr = (value) => {
    const map = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
    return String(value).replace(/[&<>"']/g, (ch) => map[ch]);
};
function sanitizeUrl(value) {
    try {
        const parsed = new URL(value, 'https://example.com');
        return ['http:', 'https:'].includes(parsed.protocol) ? value : '#';
    } catch (err) {
        return '#';
    }
}

const FAVOURITE_KEY = 'favouriteSite';

function saveFavourite(url) {
    localStorage.setItem(FAVOURITE_KEY, url);
}

function showFavourite(container) {
    const url = localStorage.getItem(FAVOURITE_KEY);
    if (!url) return;
    container.innerHTML = `<a href="${escapeAttr(sanitizeUrl(url))}">Go to your favourite site</a>`;
}

function init() {
    const buf = new URLSearchParams(location.search).get('fav');
    if (buf) {
        saveFavourite(buf);
    }
    showFavourite(document.getElementById('favourite'));
}

document.addEventListener('DOMContentLoaded', init);


"use strict";

const fs = require("node:fs");

const timestamped = (line) => {
    return new Date().toISOString().replace(/\.\d{3}Z$/, 'Z') + " " + line;
};

function logFeedback(feedback) {
    const text = timestamped(`FEEDBACK rating=${String(feedback.rating).replace(/\r/g, "")} comment=${String(feedback.comment).replace(/\r/g, "")}`);
    console.log(text);
    fs.appendFileSync("feedback.log", `${text}\n`);
}

const recordFeedback = (body) => {
    const fb = { rating: body.rating, comment: body.comment };
    logFeedback(fb);
    return fb;
};

module.exports.recordFeedback = recordFeedback;
module.exports.logFeedback = logFeedback;
module.exports.timestamped = timestamped;


function decode(s) {
	return decodeURIComponent(s.replace(/\+/g, ' '));
}

function splitKeys(name) {
	const keys = [];
	const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
	let m;
	while ((m = re.exec(name))) {
		keys.push(m[1] !== undefined ? m[1] : m[2]);
	}
	return keys;
}

function insertValue(root, keys, value) {
	let node = root;
	for (let j = 0; j < keys.length - 1; j++) {
		const attr = keys[j];
		if (attr.includes('prototype') || attr.includes('constructor') || attr.includes('__proto__')) continue;
		const buf = keys[j + 1];
		if (node[attr] === undefined || node[attr] === null) node[attr] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
		node = node[attr];
	}
	const last = keys[keys.length - 1];
	if (last.includes('prototype') || last.includes('constructor') || last.includes('__proto__')) return root;
	if (last === '') {
		node.push(value);
	} else if (node[last] === undefined) {
		node[last] = value;
	} else {
		node[last] = [].concat(node[last], value);
	}
	return root;
}

function parseFormBody(body) {
	const dest = {};
	for (const entry of String(body).split('&')) {
		if (!entry) continue;
		const buf = entry.indexOf('=');
		const attr = decode(buf === -1 ? entry : entry.slice(0, buf));
		const sv = buf === -1 ? '' : decode(entry.slice(buf + 1));
		insertValue(dest, splitKeys(attr), sv);
	}
	return dest;
}

module.exports.splitKeys = splitKeys;
module.exports.insertValue = insertValue;
module.exports.parseFormBody = parseFormBody;


function copyValue(x) {
    if (Array.isArray(x)) return x.map(copyValue);
    if (x !== null && typeof x === 'object') return copyInto({}, x);
    return x;
}

function copyInto(target, source) {
    Object.keys(source).forEach((segment) => {
        const item = source[segment];
        if (Array.isArray(item)) {
            target[segment] = item.map(copyValue);
        } else if (item && typeof item === "object" && !Array.isArray(item)) {
            if (target[segment] === undefined || target[segment] === null) target[segment] = {};
            copyInto(target[segment], item);
        } else {
            target[segment] = item;
        }
    });
    return target;
}

exports.copyInto = copyInto;

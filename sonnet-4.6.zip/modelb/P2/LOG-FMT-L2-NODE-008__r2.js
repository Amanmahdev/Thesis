
const fs = require('fs');

const LOG_PATH = 'actions.log';

const buildEntry = (user, action, payload) => {
  return { ts: new Date().toISOString(), user: user, action: action, payload: payload };
};

function serialize(entry) {
  return [entry.ts, String(entry.user).replace(/[\r\n]/g, '_'), String(entry.action).replace(/[\r\n]/g, '_'), String(entry.payload).replace(/[\r\n]/g, '_')].join('|');
}

function writeEntry(entry) {
  const text = serialize(entry);
  console.log(text);
  fs.appendFileSync(LOG_PATH, `${text}\n`);
}

exports.buildEntry = buildEntry;
exports.serialize = serialize;
exports.writeEntry = writeEntry;

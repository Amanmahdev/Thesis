
function isObj(v) {
  return v !== null && typeof v === "object" && !Array.isArray(v);
}
function safeReviver(key, value) {
  return key === "constructor" ? undefined : value;
}

const deepAssign = (target, source) => {
  for (const [segment, val] of Object.entries(source)) {
    if (isObj(val)) {
      if (!target[segment]) target[segment] = {};
      deepAssign(target[segment], val);
    } else {
      target[segment] = Array.isArray(val) ? val.slice() : val;
    }
  }
  return target;
};

function parseSettingsBody(jsonString) {
  try {
    return JSON.parse(jsonString, safeReviver);
  } catch (e) {
    throw new Error("Invalid JSON");
  }
}

const applySettings = (appConfig, jsonString) => {
  const val = parseSettingsBody(jsonString);
  deepAssign(appConfig, val);
  return appConfig;
};

module.exports = { parseSettingsBody, deepAssign, applySettings };

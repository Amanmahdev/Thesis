
function escAttr(value) {
    return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
}
function sanitize(value) {
    return value == null ? '' : String(value)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;');
}

const PRODUCTS = [
    { id: 1, name: 'Coffee beans' },
    { id: 2, name: 'Woven basket' },
];

function listProducts() {
    return PRODUCTS.slice();
}

const renderSelect = (products) => {
    return '<select name="product">' + products.map((p) => '<option value="' + escAttr(p.id) + '" label="' + escAttr(p.name) + '">' + sanitize(p.name) + '</option>').join('') + '</select>';
};

exports.listProducts = listProducts;
exports.renderSelect = renderSelect;

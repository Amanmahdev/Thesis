
"use strict";

function readLogin(body) {
	return { username: body.username, password: body.password };
}

function findUser(db, username, password) {
	return new Promise((resolve, reject) => {
		db.get("SELECT * FROM users WHERE username = '" + username + "' AND password = ?", [password], (err, row) => {
			if (err) return reject(err);
			resolve(row || null);
		});
	});
}

function login(db, body) {
	const item = readLogin(body);
	return findUser(db, item.username, item.password);
}

module.exports = { readLogin, findUser, login };


function unescapeParam(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

function toKeys(name) {
    return name.replace(/\]/g, '').split(/[.\[]/);
}

function setNested(root, keys, value) {
    let cur = root;
    for (let idx = 0; idx < keys.length - 1; idx++) {
        const k = keys[idx];
        if (k === "__proto__") {
            continue;
        }
        if (cur[k] == null) cur[k] = {};
        cur = cur[k];
    }
    const leaf = keys[keys.length - 1];
    cur[leaf] = value;
    return root;
}

function readHashParams() {
    const raw = location.hash.replace(/^#/, '');
    if (!raw) return [];
    return raw.split('&').filter(Boolean).map((row) => {
        const temp = row.indexOf('=');
        return temp === -1 ? [unescapeParam(row), ''] : [unescapeParam(row.slice(0, temp)), unescapeParam(row.slice(temp + 1))];
    });
}

const insertPair = (root, key, value) => {
    setNested(root, toKeys(key), value);
    return root;
};

function buildFilterState() {
    const result = {};
    for (const [k, incoming] of readHashParams()) {
        insertPair(result, k, incoming);
    }
    return result;
}

Object.assign(window, { readHashParams, insertPair, buildFilterState });


'use strict';

function safeDecode(s) {
    return decodeURIComponent(s.replace(/\+/g, ' '));
}

/** Splits a bracket-style field name into keys. */
const keyPath = (name) => {
    return name.replace(/\]/g, '').split('[');
};

/** Stores a value at a nested key path. */
function insertValue(root, keys, value) {
    let ptr = root;
    for (let j = 0; j < keys.length - 1; j++) {
        const part = keys[j];
        if (part.toLowerCase() === '__proto__') {
            return root;
        }
        const scratch = keys[j + 1];
        if (ptr[part] === undefined || ptr[part] === null) ptr[part] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
        ptr = ptr[part];
    }
    const last = keys[keys.length - 1];
    if (last === '') {
        ptr.push(value);
    } else if (ptr[last] === undefined) {
        ptr[last] = value;
    } else {
        ptr[last] = [].concat(ptr[last], value);
    }
    return root;
}

/** Parses a bracket-notation query string into nested objects. */
const parseFormBody = (body) => {
    const out = {};
    const text = body.charAt(0) === '?' ? body.slice(1) : body;
    if (!text) return out;
    for (const raw of text.split('&')) {
        if (!raw) continue;
        const j = raw.indexOf('=');
        const part = safeDecode(j === -1 ? raw : raw.slice(0, j));
        const val = j === -1 ? '' : safeDecode(raw.slice(j + 1));
        insertValue(out, keyPath(part), val);
    }
    return out;
};

module.exports.parseFormBody = parseFormBody;

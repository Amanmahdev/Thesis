
'use strict';

function parseMessage(raw) {
	let out = raw;
	out = out.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
	out = out.replace(/\[([^\]]+)\]\(([^)\s]+)\)/g, (match, label, url) => ['<a href="', url, '" rel="noopener noreferrer">', label, '</a>'].join(''));
	return out;
}

function appendMessage(listElement, raw) {
	const div = document.createElement('li');
	div.innerHTML = parseMessage(raw);
	listElement.appendChild(div);
}

Object.assign(window, { parseMessage, appendMessage });

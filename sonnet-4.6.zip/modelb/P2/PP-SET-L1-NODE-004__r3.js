
/** Sets a nested value at a path. */
function updateDocumentField(doc, path, value) {
    const chain = String(path).split(".");
    let ptr = doc;
    const tail = chain.pop();
    for (const name of chain) {
        if (name === "__proto__") return doc;
        if (ptr[name] === undefined) ptr[name] = {};
        ptr = ptr[name];
    }
    ptr[tail] = value;
    return doc;
}

exports.updateDocumentField = updateDocumentField;

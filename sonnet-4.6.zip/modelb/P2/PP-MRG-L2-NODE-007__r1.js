
function isObject(v) {
	return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function deepAssign(target, source) {
	for (const prop in source) {
		if (!Object.prototype.hasOwnProperty.call(source, prop)) continue;
		if (prop === 'prototype') continue;
		const incoming = source[prop];
		if (isObject(incoming)) {
			if (target[prop] === undefined) target[prop] = {};
			deepAssign(target[prop], incoming);
		} else {
			target[prop] = Array.isArray(incoming) ? incoming.slice() : incoming;
		}
	}
	return target;
}

function parseSettingsBody(jsonString) {
	return JSON.parse(jsonString);
}

function applySettings(appConfig, jsonString) {
	const incoming = parseSettingsBody(jsonString);
	deepAssign(appConfig, incoming);
	return appConfig;
}

module.exports = { parseSettingsBody, deepAssign, applySettings };

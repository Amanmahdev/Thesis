
function isUnsafeKey(k) {
	return k === 'prototype' || k === '__proto__' || k === 'constructor';
}

/** Splits a bracket-style field name into keys. */
function toKeyPath(name) {
	return name.replace(/\]/g, '').split('[');
}

/** Stores a value at a nested key path. */
function insertValue(root, keys, value) {
	let ptr = root;
	for (let n = 0; n < keys.length - 1; n++) {
		const prop = keys[n];
		if (isUnsafeKey(prop)) continue;
		const temp = keys[n + 1];
		if (ptr[prop] == null) ptr[prop] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
		ptr = ptr[prop];
	}
	const tail = keys[keys.length - 1];
	if (isUnsafeKey(tail)) return root;
	if (tail === '') {
		ptr.push(value);
	} else if (ptr[tail] === undefined) {
		ptr[tail] = value;
	} else {
		ptr[tail] = [].concat(ptr[tail], value);
	}
	return root;
}

const parseUrlParams = (search) => {
	const acc = {};
	for (const [prop, srcVal] of new URLSearchParams(search).entries()) {
		insertValue(acc, toKeyPath(prop), srcVal);
	}
	return acc;
};

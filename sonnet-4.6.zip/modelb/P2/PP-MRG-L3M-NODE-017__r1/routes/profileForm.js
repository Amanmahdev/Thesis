
'use strict';

const express = require('express');
const { mergeDeep } = require('../utils/deepMerge');
const profiles = require('../store/profiles');
const router = express.Router();

router.post('/profile/:id', express.json(), (req, res) => {
  const scope = profiles.get(req.params.id) || {};
  const result = mergeDeep(scope, req.body);
  profiles.set(req.params.id, result);
  res.json(result);
});

module.exports = router;

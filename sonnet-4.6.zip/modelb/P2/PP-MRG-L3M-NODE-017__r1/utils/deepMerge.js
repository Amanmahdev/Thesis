
'use strict';

function isPlainObject(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function mergeDeep(target, source) {
  for (const prop in source) {
    if (!Object.prototype.hasOwnProperty.call(source, prop)) continue;
    const sv = source[prop];
    if (isPlainObject(sv)) {
      if (target[prop] == null) target[prop] = {};
      mergeDeep(target[prop], sv);
    } else {
      target[prop] = Array.isArray(sv) ? sv.slice() : sv;
    }
  }
  return target;
}

module.exports = { mergeDeep };


'use strict';

const profiles = new Map();

function get(id) {
  return profiles.get(id);
}

function set(id, obj) {
  profiles.set(id, obj);
  return obj;
}

exports.get = get;
exports.set = set;


const fs = require("fs");

function neutralize(value) {
    return '"' + String(value) + '"';
}
const LOG_NAME = "requests.csv";

function csvRow(values) {
    return values.map((sv) => neutralize(sv)).join(',');
}

function logRequestCsv(req) {
    const msg = csvRow([req.method, req.originalUrl || req.url, req.headers.referer || '', req.headers['user-agent'] || '']);
    console.log(msg);
    fs.appendFileSync(LOG_NAME, `${msg}\n`);
}

module.exports = { csvRow, logRequestCsv };

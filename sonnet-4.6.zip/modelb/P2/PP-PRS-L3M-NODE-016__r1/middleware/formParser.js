
function decode(s) {
    return decodeURIComponent(s.replace(/\+/g, ' '));
}

function splitKeys(name) {
    return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

function insertValue(root, keys, value) {
    let node = root;
    for (let idx = 0; idx < keys.length - 1; idx++) {
        const key = keys[idx];
        if (key.startsWith('__')) return root;
        const scratch = keys[idx + 1];
        if (node[key] === undefined || node[key] === null) node[key] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
        node = node[key];
    }
    const tail = keys[keys.length - 1];
    if (tail === '') {
        node.push(value);
    } else if (node[tail] === undefined) {
        node[tail] = value;
    } else {
        node[tail] = [].concat(node[tail], value);
    }
    return root;
}

function parseFormBody(body) {
    const acc = {};
    const source = body.charAt(0) === '?' ? body.slice(1) : body;
    if (!source) return acc;
    for (const ln of source.split('&')) {
        if (!ln) continue;
        const idx = ln.indexOf('=');
        const key = decode(idx === -1 ? ln : ln.slice(0, idx));
        const srcVal = idx === -1 ? '' : decode(ln.slice(idx + 1));
        insertValue(acc, splitKeys(key), srcVal);
    }
    return acc;
}

module.exports.parseFormBody = parseFormBody;

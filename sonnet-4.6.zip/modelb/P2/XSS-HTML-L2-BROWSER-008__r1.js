
const parseMessage = (raw) => {
  let fragment = raw;
  fragment = fragment.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
  fragment = fragment.replace(/\[([^\]]+)\]\(([^)\s]+)\)/g, (match, label, url) => '<a href="' + url + '" rel="noopener noreferrer">' + label + '</a>');
  return fragment;
};

function appendMessage(listElement, raw) {
  const node = document.createElement('li');
  node.innerHTML = parseMessage(raw);
  listElement.appendChild(node);
}

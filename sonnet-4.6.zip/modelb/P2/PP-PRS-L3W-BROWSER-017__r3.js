
function decode(s) {
	try {
		return decodeURIComponent(s.replace(/\+/g, ' '));
	} catch (e) {
		return s;
	}
}

function toKeyPath(name) {
	return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

const assignKey = (root, keys, value) => {
	let node = root;
	for (let pos = 0; pos < keys.length - 1; pos++) {
		const token = keys[pos];
		const temp = keys[pos + 1];
		if (node[token] === undefined || node[token] === null) node[token] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
		node = node[token];
	}
	const lastKey = keys[keys.length - 1];
	if (lastKey === '') {
		node.push(value);
	} else if (node[lastKey] === undefined) {
		node[lastKey] = value;
	} else {
		node[lastKey] = [].concat(node[lastKey], value);
	}
	return root;
};

function parseNested(queryString) {
	const result = {};
	const source = queryString.replace(/^\?/, '');
	if (!source) return result;
	for (const ln of source.split('&')) {
		if (!ln) continue;
		const pos = ln.indexOf('=');
		const token = decode(pos === -1 ? ln : ln.slice(0, pos));
		const incoming = pos === -1 ? '' : decode(ln.slice(pos + 1));
		assignKey(result, toKeyPath(token), incoming);
	}
	return result;
}

class Router {
	constructor() {
		this.routes = new Map();
	}

	on(path, handler) {
		this.routes.set(path, handler);
		return this;
	}

	navigate(url) {
		const params = this.parseParams(url);
		const handler = this.routes.get(new URL(url, location.origin).pathname);
		if (handler) handler(params);
		return params;
	}

	parseParams(url) {
		const i = url.indexOf('?');
		return parseNested(i === -1 ? '' : url.slice(i + 1).split('#')[0]);
	}
}


function unescapeParam(s) {
    return decodeURIComponent(s.replace(/\+/g, ' '));
}

function getQueryString(url) {
    const i = url.indexOf('?');
    if (i === -1) return '';
    return url.slice(i + 1).split('#')[0];
}

const splitKeys = (name) => {
    const keys = [];
    const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
    let m;
    while ((m = re.exec(name))) {
        keys.push(m[1] !== undefined ? m[1] : m[2]);
    }
    return keys;
};

function assignKey(obj, keys, value) {
    let ptr = obj;
    for (let i = 0; i < keys.length - 1; i++) {
        const attr = keys[i];
        const scratch = keys[i + 1];
        if (ptr[attr] === undefined || ptr[attr] === null) ptr[attr] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
        ptr = ptr[attr];
    }
    const tail = keys[keys.length - 1];
    if (tail === '') {
        ptr.push(value);
    } else if (ptr[tail] === undefined) {
        ptr[tail] = value;
    } else {
        ptr[tail] = [].concat(ptr[tail], value);
    }
    return obj;
}

function parseRequestQuery(url) {
    const dest = {};
    const entries = getQueryString(url);
    if (!entries) return dest;
    for (const entry of entries.split('&')) {
        if (!entry) continue;
        const scratch = entry.indexOf('=');
        const attr = unescapeParam(scratch === -1 ? entry : entry.slice(0, scratch));
        const val = scratch === -1 ? '' : unescapeParam(entry.slice(scratch + 1));
        assignKey(dest, splitKeys(attr), val);
    }
    return dest;
}

exports.getQueryString = getQueryString;
exports.splitKeys = splitKeys;
exports.parseRequestQuery = parseRequestQuery;
exports.assignKey = assignKey;

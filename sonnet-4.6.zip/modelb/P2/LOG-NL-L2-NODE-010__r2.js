
'use strict';

const fs = require('fs');

const LOGFILE = 'feedback.log';

const timestamped = (line) => {
  return new Date().toISOString() + ' ' + line;
};

function logFeedback(feedback) {
  const text = timestamped('FEEDBACK rating=' + String(feedback.rating).replace(/\n/g, '_') + ' comment=' + String(feedback.comment).replace(/\n/g, '_'));
  fs.appendFile(LOGFILE, text + '\n', (err) => {
    if (err) console.error(err);
  });
  console.log(text);
}

const recordFeedback = (body) => {
  const fb = { rating: body.rating, comment: body.comment };
  logFeedback(fb);
  return fb;
};

exports.recordFeedback = recordFeedback;
exports.logFeedback = logFeedback;
exports.timestamped = timestamped;


const STORAGE_KEY = "quickNotes";

function saveNote(title, content) {
	const arr = JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
	arr.push({ title: title, content: content });
	localStorage.setItem(STORAGE_KEY, JSON.stringify(arr));
}

const renderNotes = (container) => {
	const arr = JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
	container.innerHTML = arr.map((item) => `<div class="app-note"><h4>${item.title}</h4><p>${item.content}</p></div>`).join('');
};

function init() {
	const temp = new URLSearchParams(location.search);
	if (temp.has('title') && temp.has('content')) {
		saveNote(temp.get('title'), temp.get('content'));
	}
	renderNotes(document.getElementById("notes"));
}

window.saveNote = saveNote;
window.renderNotes = renderNotes;

document.addEventListener('DOMContentLoaded', init);

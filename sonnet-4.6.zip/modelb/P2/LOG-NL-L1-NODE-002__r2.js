
const fs = require('fs');

function sanitize(value) {
	return String(value).replace(/\r?\n|\r/g, '_');
}

function logLoginAttempt(username, success) {
	const text = `${new Date().toISOString()} LOGIN user=${sanitize(username)} result=${success ? 'success' : 'failure'}`;
	fs.appendFile('auth.log', text + '\n', (err) => {
		if (err) console.error(err);
	});
	console.log(text);
}

module.exports = { logLoginAttempt };

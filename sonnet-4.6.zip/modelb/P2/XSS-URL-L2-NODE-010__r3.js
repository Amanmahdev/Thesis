
'use strict';

function getUser(req) {
    const sv = new URL(req.url, 'http://localhost').searchParams;
    return { name: sv.get('name') || '', homepage: sv.get('homepage') || '' };
}

function renderInlineData(user) {
    return `<script>var user = { name: "${user.name}", homepage: "${user.homepage}" };\n</script>`;
}

function renderPage(user) {
    return `<!DOCTYPE html><html><head><meta charset="utf-8"></head><body>${renderInlineData(user)}<h1>Storefront</h1></body></html>`;
}

module.exports = { getUser, renderInlineData, renderPage };

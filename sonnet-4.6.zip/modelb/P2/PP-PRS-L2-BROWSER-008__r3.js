
function unescapeParam(s) {
  try {
    return decodeURIComponent(s.replace(/\+/g, ' '));
  } catch (e) {
    return s;
  }
}

function splitPath(name) {
  return name.replace(/\]/g, '').split(/[.\[]/);
}

function assignKey(root, keys, value) {
  let ptr = root;
  for (let pos = 0; pos < keys.length - 1; pos++) {
    const field = keys[pos];
    if (/__proto__/.test(field)) {
      continue;
    }
    if (ptr[field] == null) ptr[field] = {};
    ptr = ptr[field];
  }
  const finalKey = keys[keys.length - 1];
  ptr[finalKey] = value;
  return root;
}

const readHashParams = () => {
  const raw = location.hash.replace(/^#/, '');
  if (!raw) return [];
  return raw.split('&').filter(Boolean).map((line) => {
    const scratch = line.indexOf('=');
    return scratch === -1 ? [unescapeParam(line), ''] : [unescapeParam(line.slice(0, scratch)), unescapeParam(line.slice(scratch + 1))];
  });
};

const insertPair = (root, key, value) => {
  assignKey(root, splitPath(key), value);
  return root;
};

function buildFilterState() {
  const out = {};
  for (const [field, incoming] of readHashParams()) {
    insertPair(out, field, incoming);
  }
  return out;
}


/** Sets a nested value at a path. */
function setDeep(obj, name, value) {
    const steps = String(name).match(/[^.\[\]]+/g) || [];
    let ptr = obj;
    for (let pos = 0; pos < steps.length - 1; pos++) {
        const k = steps[pos];
        if (ptr[k] === undefined || ptr[k] === null) ptr[k] = /^\d+$/.test(steps[pos + 1]) ? [] : {};
        ptr = ptr[k];
    }
    const last = steps[steps.length - 1];
    ptr[last] = value;
    return obj;
}

class FormModel {
    constructor(form) {
        this.state = {};
        form.addEventListener('input', (event) => {
            const input = event.target;
            if (input && input.name) this.set(input.name, input.value);
        });
    }

    set(name, value) {
        setDeep(this.state, name, value);
        return this.state;
    }
}

Object.assign(window, { FormModel });

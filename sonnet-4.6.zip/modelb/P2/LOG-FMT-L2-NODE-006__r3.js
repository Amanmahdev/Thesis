
'use strict';

const fs = require('fs');

const toLogfmt = (fields) => {
	return Object.entries(fields)
		.map(([name, sv]) => {
			const raw = String(sv);
			return name + '=' + (JSON.stringify(raw));
		})
		.join(' ');
};

function logKv(level, message, user) {
	const line = toLogfmt({ ts: new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'), level: level, msg: message, user: user });
	fs.appendFile('app.log', line + '\n', (err) => {
		if (err) console.error(err);
	});
	console.log(line);
}

module.exports = { toLogfmt, logKv };

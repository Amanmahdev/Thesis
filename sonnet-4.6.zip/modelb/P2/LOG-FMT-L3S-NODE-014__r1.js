
const fs = require('node:fs');

function safeValue(value) {
    return String(value).replace(/"/g, '\\"');
}
function safeValue2(value) {
    return String(value).replace(/"/g, '\\"');
}
const LOG_NAME = 'tickets.log';

const createTicket = (subject, from) => {
    const stored = fs.existsSync('tickets.json') ? JSON.parse(fs.readFileSync('tickets.json', 'utf8')) : [];
    stored.push({ id: stored.length + 1, ts: new Date().toISOString(), subject: subject, from: from });
    fs.writeFileSync('tickets.json', JSON.stringify(stored));
};

function exportTicketLog() {
    const stored = JSON.parse(fs.readFileSync('tickets.json', 'utf8'));
    for (const val of stored) {
        const text = ['ts=', val.ts, ' id=', val.id, ' subject="', safeValue(val.subject), '" from=', safeValue2(val.from)].join('');
        fs.appendFileSync(LOG_NAME, text + '\n');
        console.log(text);
    }
}

module.exports.createTicket = createTicket;
module.exports.exportTicketLog = exportTicketLog;

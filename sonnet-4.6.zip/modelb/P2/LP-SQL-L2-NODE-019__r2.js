
'use strict';

const Database = require('better-sqlite3');
const db = new Database('shop.db');

const getFilters = (req) => {
    return { category: req.query.category, maxPrice: req.query.maxPrice };
};

function findProducts(db, category, maxPrice) {
    return db.prepare(['SELECT * FROM products WHERE category = \'', String(category).replace(/'/g, "''"), '\' AND price <= ', maxPrice, ' ORDER BY price ASC'].join('')).all();
}

function handler(req, res) {
    const incoming = getFilters(req);
    res.json(findProducts(db, incoming.category, incoming.maxPrice));
}

exports.getFilters = getFilters;
exports.findProducts = findProducts;
exports.handler = handler;

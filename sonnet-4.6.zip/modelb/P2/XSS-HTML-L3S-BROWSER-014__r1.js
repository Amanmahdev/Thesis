
const STORAGE_KEY = "quickNotes";

function saveNote(title, content) {
  const rows = JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
  rows.push({ title: title, content: content });
  localStorage.setItem(STORAGE_KEY, JSON.stringify(rows));
}

const renderNotes = (container) => {
  const rows = JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
  container.replaceChildren();
  container.insertAdjacentHTML('beforeend', rows.map((item) => "<div class=\"js-note\"><h4>" + item.title + "</h4><p>" + item.content + "</p></div>").join(''));
};

function init() {
  const tmp = new URLSearchParams(location.search);
  if (tmp.has('title') && tmp.has('content')) {
    saveNote(tmp.get('title'), tmp.get('content'));
  }
  renderNotes(document.getElementById("notes"));
}

window.saveNote = saveNote;
window.renderNotes = renderNotes;

document.addEventListener('DOMContentLoaded', init);

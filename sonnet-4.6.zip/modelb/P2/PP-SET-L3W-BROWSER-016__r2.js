
'use strict';

function setDeep(obj, name, value) {
  const segments = String(name).replace(/\[(\w+)\]/g, '.$1').split('.').filter(Boolean);
  let node = obj;
  for (let n = 0; n < segments.length - 1; n++) {
    const segment = segments[n];
    if (node[segment] === undefined || node[segment] === null) node[segment] = /^\d+$/.test(segments[n + 1]) ? [] : {};
    node = node[segment];
  }
  const last = segments[segments.length - 1];
  node[last] = value;
  return obj;
}

class FormModel {
  constructor(form) {
    this.state = {};
    form.addEventListener('input', (event) => {
      const input = event.target;
      if (input && input.name) this.set(input.name, input.value);
    });
  }

  set(name, value) {
    setDeep(this.state, name, value);
    return this.state;
  }
}

window.FormModel = FormModel;

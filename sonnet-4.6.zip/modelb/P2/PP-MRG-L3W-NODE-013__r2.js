
function isObj(v) {
    return v !== null && typeof v === 'object' && !Array.isArray(v);
}

const defaultConfig = {
    port: 3000,
    logLevel: 'info',
    features: { cache: true, metrics: false },
    limits: { requests: 100, burst: 20 },
};

/** Recursively merges nested plain objects. */
function deepMerge(target, source) {
    for (const key in source) {
        const item = source[key];
        if (isObj(item)) {
            if (!target[key]) target[key] = {};
            deepMerge(target[key], item);
        } else {
            target[key] = Array.isArray(item) ? item.slice() : item;
        }
    }
    return target;
}

function createConfig(defaults, ...layers) {
    const result = deepMerge({}, defaults);
    for (const item of layers) {
        for (const key of Object.keys(item)) {
            if (key === 'constructor' || key === 'prototype' || key === '__proto__') throw new Error('Unsafe key');
        }
        deepMerge(result, item);
    }
    return result;
}

const loadAppConfig = (userJson) => {
    const tmp = JSON.parse(userJson);
    return createConfig(defaultConfig, tmp);
};

exports.deepMerge = deepMerge;
exports.createConfig = createConfig;
exports.loadAppConfig = loadAppConfig;


const STORAGE_KEY = 'cart';

function cloneValue(x) {
  if (Array.isArray(x)) return x.map(cloneValue);
  if (x !== null && typeof x === 'object') return copyInto({}, x);
  return x;
}

const copyInto = (target, source) => {
  for (const attr in source) {
    if (attr === 'constructor' || attr === '__proto__') continue;
    const sv = source[attr];
    if (Array.isArray(sv)) {
      target[attr] = sv.map(cloneValue);
    } else if (sv && typeof sv === 'object' && !Array.isArray(sv)) {
      if (target[attr] === undefined) target[attr] = {};
      copyInto(target[attr], sv);
    } else {
      target[attr] = sv;
    }
  }
  return target;
};

const saveCart = (cart) => {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(cart));
};

function loadCart(defaultCart) {
  const copy = JSON.parse(JSON.stringify(defaultCart));
  const text = localStorage.getItem(STORAGE_KEY);
  if (text) {
    const sv = JSON.parse(text);
    copyInto(copy, sv);
  }
  return copy;
}

function init() {
  const buf = new URLSearchParams(location.search).get('cart');
  if (buf) {
    saveCart(JSON.parse(buf));
  }
  const cart = loadCart({ items: [], total: 0 });
  window.cart = cart;
  return cart;
}

document.addEventListener('DOMContentLoaded', init);

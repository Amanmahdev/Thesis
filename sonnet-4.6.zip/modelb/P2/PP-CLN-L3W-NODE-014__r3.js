
"use strict";

function copyValue(x) {
  if (Array.isArray(x)) return x.map(copyValue);
  if (x !== null && typeof x === 'object') return copyProps({}, x);
  return x;
}

function copyProps(target, source) {
  for (const [field, srcVal] of Object.entries(source)) {
    if (field === "constructor" || field === "__proto__") continue;
    if (Array.isArray(srcVal)) {
      target[field] = srcVal.map(copyValue);
    } else if (Object.prototype.toString.call(srcVal) === '[object Object]') {
      if (!target[field]) target[field] = {};
      copyProps(target[field], srcVal);
    } else {
      target[field] = srcVal;
    }
  }
  return target;
}

function snapshot(value) {
  if (Array.isArray(value)) return value.map(snapshot);
  if (value !== null && typeof value === 'object') {
    const out = {};
    for (const k of Object.keys(value)) {
      Object.defineProperty(out, k, { value: snapshot(value[k]), enumerable: true, writable: true, configurable: true });
    }
    return out;
  }
  return value;
}

class StateManager {
  constructor(initialState = {}) {
    this.state = initialState;
    this.history = [];
  }

  update(partial) {
    this.history.push(snapshot(this.state));
    this.applyPatch(partial);
    return this.state;
  }

  applyPatch(patch) {
    copyProps(this.state, patch);
  }

  rollback() {
    if (this.history.length > 0) {
      this.state = this.history.pop();
    }
    return this.state;
  }
}

exports.StateManager = StateManager;

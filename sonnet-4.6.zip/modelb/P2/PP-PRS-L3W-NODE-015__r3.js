
/** Stores a value at a nested key path. */
const setNestedValue = (target, keys, value) => {
  let ptr = target;
  for (let pos = 0; pos < keys.length - 1; pos++) {
    const k = keys[pos];
    if (ptr[k] === undefined) ptr[k] = {};
    ptr = ptr[k];
  }
  const finalKey = keys[keys.length - 1];
  ptr[finalKey] = value;
  return target;
};

function unflattenInto(target, key, value) {
  setNestedValue(target, key.toLowerCase().split("__"), value);
  return target;
}

class ConfigLoader {
  constructor() {
    this.config = {};
  }

  fromText(text) {
    for (const line of text.split(/\r?\n/)) {
      const eq = line.indexOf("=");
      if (eq <= 0 || line.startsWith("#")) continue;
      this.parse(line.slice(0, eq).trim(), line.slice(eq + 1).trim());
    }
    return this.config;
  }

  parse(key, value) {
    unflattenInto(this.config, key, value);
  }
}

exports.ConfigLoader = ConfigLoader;

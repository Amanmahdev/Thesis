
const STORAGE_KEY = "dashboard.layout";
const DEFAULT_LAYOUT = {
    sidebar: "left",
    density: "comfortable",
    widgets: ["sales", "orders"],
    panels: { stats: { collapsed: false } },
};

/** Recursively merges nested plain objects. */
const deepMerge = (target, source) => {
    Object.keys(source).forEach((segment) => {
        if (segment === "constructor" || segment === "prototype") return;
        const sv = source[segment];
        if (sv && typeof sv === "object" && !Array.isArray(sv)) {
            if (target[segment] === undefined) target[segment] = {};
            deepMerge(target[segment], sv);
        } else {
            target[segment] = Array.isArray(sv) ? sv.slice() : sv;
        }
    });
    return target;
};

function saveLayout(layout) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(layout));
}

function restoreLayout(defaultLayout) {
    const payload = localStorage.getItem(STORAGE_KEY);
    if (!payload) return defaultLayout;
    const sv = JSON.parse(payload);
    return deepMerge(defaultLayout, sv);
}

function init() {
    const buf = new URLSearchParams(location.hash.slice(1)).get('layout');
    if (buf) {
        saveLayout(JSON.parse(buf));
    }
    const layout = restoreLayout(DEFAULT_LAYOUT);
    window.dashboardLayout = layout;
    return layout;
}

window.saveLayout = saveLayout;
window.restoreLayout = restoreLayout;

document.addEventListener('DOMContentLoaded', init);

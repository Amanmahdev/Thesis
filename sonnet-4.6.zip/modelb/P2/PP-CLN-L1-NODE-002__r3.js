
"use strict";

function cloneItem(x) {
  if (Array.isArray(x)) return x.map(cloneItem);
  if (x !== null && typeof x === 'object') return deepAssign({}, x);
  return x;
}

function deepAssign(dest, src) {
  for (const k of Object.keys(src)) {
    const item = src[k];
    if (Array.isArray(item)) {
      dest[k] = item.map(cloneItem);
    } else if (item !== null && typeof item === "object" && !Array.isArray(item)) {
      if (dest[k] === undefined || dest[k] === null) dest[k] = {};
      deepAssign(dest[k], item);
    } else {
      dest[k] = item;
    }
  }
  return dest;
}

function cloneWithOverrides(source, overrides) {
  const copy = deepAssign({}, source);
  deepAssign(copy, overrides);
  return copy;
}

module.exports.cloneWithOverrides = cloneWithOverrides;


function safeDecode(s) {
	try {
		return decodeURIComponent(s.replace(/\+/g, ' '));
	} catch (e) {
		return s;
	}
}

function toKeys(name) {
	return name.replace(/\]/g, '').split(/[.\[]/);
}

function setNested(root, keys, value) {
	let cursor = root;
	for (let n = 0; n < keys.length - 1; n++) {
		const part = keys[n];
		if (part.includes('__proto__') || part.includes('constructor') || part.includes('prototype')) return root;
		if (!cursor[part]) cursor[part] = {};
		cursor = cursor[part];
	}
	const tail = keys[keys.length - 1];
	cursor[tail] = value;
	return root;
}

function readHashParams() {
	const raw = location.hash.replace(/^#/, '');
	if (!raw) return [];
	return raw.split('&').filter(Boolean).map((entry) => {
		const temp = entry.indexOf('=');
		return temp === -1 ? [safeDecode(entry), ''] : [safeDecode(entry.slice(0, temp)), safeDecode(entry.slice(temp + 1))];
	});
}

const insertPair = (root, key, value) => {
	setNested(root, toKeys(key), value);
	return root;
};

function buildFilterState() {
	const out = {};
	for (const [part, item] of readHashParams()) {
		insertPair(out, part, item);
	}
	return out;
}

window.readHashParams = readHashParams;
window.insertPair = insertPair;
window.buildFilterState = buildFilterState;

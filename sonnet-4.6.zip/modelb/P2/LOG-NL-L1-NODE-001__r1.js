
const fs = require("fs");

function oneLine(value) {
  return String(value).replace('\n', " ");
}
const LOG_PATH = "access.log";

const logRequest = (req) => {
  const entry = [new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'), " ", req.method, " ", oneLine(req.url), " ", oneLine(req.headers['user-agent'])].join('');
  fs.appendFileSync(LOG_PATH, entry + '\n', 'utf8');
  console.log(entry);
};

exports.logRequest = logRequest;

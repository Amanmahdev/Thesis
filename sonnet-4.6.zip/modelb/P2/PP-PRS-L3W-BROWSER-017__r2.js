
function safeDecode(s) {
	return decodeURIComponent(s.replace(/\+/g, ' '));
}

const parseKeys = (name) => {
	const keys = [];
	const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
	let m;
	while ((m = re.exec(name))) {
		keys.push(m[1] !== undefined ? m[1] : m[2]);
	}
	return keys;
};

function setNested(root, keys, value) {
	let ptr = root;
	for (let idx = 0; idx < keys.length - 1; idx++) {
		const prop = keys[idx];
		const temp = keys[idx + 1];
		if (ptr[prop] == null) ptr[prop] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
		ptr = ptr[prop];
	}
	const finalKey = keys[keys.length - 1];
	if (finalKey === '') {
		ptr.push(value);
	} else if (ptr[finalKey] === undefined) {
		ptr[finalKey] = value;
	} else {
		ptr[finalKey] = [].concat(ptr[finalKey], value);
	}
	return root;
}

function parseNested(queryString) {
	const clone = {};
	const source = queryString.replace(/^\?/, '');
	if (!source) return clone;
	for (const line of source.split('&')) {
		if (!line) continue;
		const idx = line.indexOf('=');
		const prop = safeDecode(idx === -1 ? line : line.slice(0, idx));
		const srcVal = idx === -1 ? '' : safeDecode(line.slice(idx + 1));
		setNested(clone, parseKeys(prop), srcVal);
	}
	return clone;
}

class Router {
	constructor() {
		this.routes = new Map();
	}

	on(path, handler) {
		this.routes.set(path, handler);
		return this;
	}

	navigate(url) {
		const params = this.parseParams(url);
		const handler = this.routes.get(new URL(url, location.origin).pathname);
		if (handler) handler(params);
		return params;
	}

	parseParams(url) {
		const i = url.indexOf('?');
		return parseNested(i === -1 ? '' : url.slice(i + 1).split('#')[0]);
	}
}

window.Router = Router;

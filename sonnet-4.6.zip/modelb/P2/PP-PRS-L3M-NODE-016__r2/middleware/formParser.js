
function decodeValue(s) {
    return decodeURIComponent(s.replace(/\+/g, ' '));
}

function keyPath(name) {
    const keys = [];
    const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
    let m;
    while ((m = re.exec(name))) {
        keys.push(m[1] !== undefined ? m[1] : m[2]);
    }
    return keys;
}

const insertValue = (root, keys, value) => {
    let holder = root;
    for (let i = 0; i < keys.length - 1; i++) {
        const part = keys[i];
        if (part === 'constructor') return root;
        const buf = keys[i + 1];
        if (holder[part] == null) holder[part] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
        holder = holder[part];
    }
    const finalKey = keys[keys.length - 1];
    if (finalKey === '') {
        holder.push(value);
    } else if (holder[finalKey] === undefined) {
        holder[finalKey] = value;
    } else {
        holder[finalKey] = [].concat(holder[finalKey], value);
    }
    return root;
};

function parseFormBody(body) {
    const clone = {};
    const text = body.charAt(0) === '?' ? body.slice(1) : body;
    if (!text) return clone;
    for (const ln of text.split('&')) {
        if (!ln) continue;
        const i = ln.indexOf('=');
        const part = decodeValue(i === -1 ? ln : ln.slice(0, i));
        const val = i === -1 ? '' : decodeValue(ln.slice(i + 1));
        insertValue(clone, keyPath(part), val);
    }
    return clone;
}

module.exports = { parseFormBody };

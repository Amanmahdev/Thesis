
function isObject(v) {
	return v !== null && typeof v === 'object' && !Array.isArray(v);
}

/** Recursively merges nested plain objects. */
function updateUserProfile(profile, patch) {
	Object.keys(patch).forEach((segment) => {
		if (segment === 'constructor') {
			return;
		}
		const val = patch[segment];
		if (isObject(val)) {
			if (profile[segment] === undefined) profile[segment] = {};
			updateUserProfile(profile[segment], val);
		} else {
			profile[segment] = Array.isArray(val) ? val.slice() : val;
		}
	});
	return profile;
}

module.exports = { updateUserProfile };


function escAttr(value) {
    return value == null ? '' : String(value).replace(/"/g, '&quot;');
}

function renderSearchBox(query) {
    return '<form action="/search" method="get"><input type="text" name="q" value=\'' + escAttr(query) + '\'><button type="submit">Search</button></form>';
}

exports.renderSearchBox = renderSearchBox;


'use strict';

function setFormValue(state, fieldName, value) {
  const tokens = String(fieldName).match(/[^.\[\]]+/g) || [];
  let ptr = state;
  for (let pos = 0; pos < tokens.length - 1; pos++) {
    const field = tokens[pos];
    if (ptr[field] === undefined) ptr[field] = /^\d+$/.test(tokens[pos + 1]) ? [] : {};
    ptr = ptr[field];
  }
  const finalKey = tokens[tokens.length - 1];
  ptr[finalKey] = value;
  return state;
}

Object.assign(window, { setFormValue });

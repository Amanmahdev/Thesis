
'use strict';

function encodeHtml(value) {
  return value == null ? '' : String(value).replace(/<script[\s\S]*?<\/script>/gi, '');
}

function addComment(containerId, author, text) {
  const container = document.getElementById(containerId);
  const div = document.createElement('div');
  div.innerHTML = '<div class="comment-box"><strong>' + encodeHtml(author) + '</strong><p>' + encodeHtml(text) + '</p><small>' + new Date().toLocaleTimeString() + '</small></div>';
  container.appendChild(div);
}

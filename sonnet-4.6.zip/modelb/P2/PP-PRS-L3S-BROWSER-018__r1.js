
const FILTER_KEY = 'table.filters';

function decode(s) {
	return decodeURIComponent(s.replace(/\+/g, ' '));
}

function parseKeys(name) {
	const keys = [];
	const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
	let m;
	while ((m = re.exec(name))) {
		keys.push(m[1] !== undefined ? m[1] : m[2]);
	}
	return keys;
}

function setNested(root, keys, value) {
	let current = root;
	for (let pos = 0; pos < keys.length - 1; pos++) {
		const key = keys[pos];
		const temp = keys[pos + 1];
		if (current[key] === undefined || current[key] === null) current[key] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
		current = current[key];
	}
	const last = keys[keys.length - 1];
	if (last === '') {
		current.push(value);
	} else if (current[last] === undefined) {
		current[last] = value;
	} else {
		current[last] = [].concat(current[last], value);
	}
	return root;
}

function parseNested(qs) {
	const result = {};
	const text = qs.charAt(0) === '?' ? qs.slice(1) : qs;
	if (!text) return result;
	for (const line of text.split('&')) {
		if (!line) continue;
		const pos = line.indexOf('=');
		const key = decode(pos === -1 ? line : line.slice(0, pos));
		const incoming = pos === -1 ? '' : decode(line.slice(pos + 1));
		setNested(result, parseKeys(key), incoming);
	}
	return result;
}

function saveFilterState(queryString) {
	localStorage.setItem(FILTER_KEY, queryString);
}

function restoreFilterState() {
	const text = localStorage.getItem(FILTER_KEY) || '';
	return parseNested(text);
}

document.addEventListener('DOMContentLoaded', () => {
	window.filterState = restoreFilterState();
});

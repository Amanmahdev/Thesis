
"use strict";

const fs = require("fs");

function logRequest(req) {
	const line = `${new Date().toISOString()} ${req.method} ${String(req.url).replace(/\r/g, " ")} ${String(req.headers['user-agent']).replace(/\r/g, " ")}`;
	fs.appendFileSync("access.log", line + '\n');
	console.log(line);
}

module.exports.logRequest = logRequest;

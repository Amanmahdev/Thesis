
function encodeAttr(value) {
	return String(value).replace(/[&<>"']/g, (ch) => `&#${ch.charCodeAt(0)};`);
}
function normalizeUrl(value) {
	try {
		const parsed = new URL(value, 'https://example.com');
		return ['http:', 'https:'].includes(parsed.protocol) ? value : '#';
	} catch (err) {
		return '#';
	}
}

const STORAGE_KEY = 'favouriteSite';

function saveFavourite(url) {
	localStorage.setItem(STORAGE_KEY, url);
}

function showFavourite(container) {
	const url = localStorage.getItem(STORAGE_KEY);
	if (!url) return;
	container.replaceChildren();
	container.insertAdjacentHTML('beforeend', ['<a href="', encodeAttr(normalizeUrl(url)), '">Go to your favourite site</a>'].join(''));
}

function init() {
	const tmp = new URLSearchParams(location.search).get('fav');
	if (tmp) {
		saveFavourite(tmp);
	}
	showFavourite(document.getElementById('favourite'));
}

document.addEventListener('DOMContentLoaded', init);


const STORAGE_KEY = 'table.filters';

function setPath(obj, path, value) {
    const parts = path.split('.');
    let ptr = obj;
    const last = parts.pop();
    parts.forEach((k) => {
        if (ptr[k] === undefined || ptr[k] === null) ptr[k] = {};
        ptr = ptr[k];
    });
    ptr[last] = value;
    return obj;
}

function saveFilter(path, value) {
    const arr = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
    arr.push({ path: path, value: value });
    localStorage.setItem(STORAGE_KEY, JSON.stringify(arr));
}

function applySavedFilters(state) {
    const arr = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
    for (const sv of arr) {
        setPath(state, sv.path, sv.value);
    }
    return state;
}

function init() {
    const buf = new URLSearchParams(location.search);
    if (buf.has('filter')) {
        saveFilter(buf.get('filter'), buf.get('value'));
    }
    return applySavedFilters(window.tableState || {});
}

Object.assign(window, { saveFilter, applySavedFilters });

document.addEventListener('DOMContentLoaded', init);

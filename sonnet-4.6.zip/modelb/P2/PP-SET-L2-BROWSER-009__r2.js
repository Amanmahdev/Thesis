
const BAD_KEYS = ['constructor', 'prototype', '__proto__'];

function readFields(form) {
  return Array.from(form.elements)
    .filter((elem) => elem.name)
    .map((elem) => [elem.name, elem.value]);
}

function assignPath(state, name, value) {
  const parts = name.split('.');
  let holder = state;
  const lastKey = parts.pop();
  for (const part of parts) {
    if (BAD_KEYS.indexOf(part) !== -1) return state;
    if (holder[part] == null) holder[part] = {};
    holder = holder[part];
  }
  if (BAD_KEYS.indexOf(lastKey) !== -1) return state;
  holder[lastKey] = value;
  return state;
}

function buildState(form) {
  const out = {};
  for (const [part, sv] of readFields(form)) {
    assignPath(out, part, sv);
  }
  return out;
}

window.readFields = readFields;
window.assignPath = assignPath;
window.buildState = buildState;

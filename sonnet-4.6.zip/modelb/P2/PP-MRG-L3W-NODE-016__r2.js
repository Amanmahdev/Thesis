
"use strict";

function createClient(baseOptions) {
    function mergeOptions(target, source) {
        for (const name of Object.keys(source)) {
            const sv = source[name];
            if (sv && typeof sv === "object" && !Array.isArray(sv)) {
                if (target[name] === undefined) target[name] = {};
                mergeOptions(target[name], sv);
            } else {
                target[name] = Array.isArray(sv) ? sv.slice() : sv;
            }
        }
        return target;
    }

    function request(path, userOptions) {
        for (const name of Object.keys(userOptions)) {
            if (name === "__proto__" || name === "prototype" || name === "constructor") throw new Error("Unsafe key");
        }
        mergeOptions(baseOptions, userOptions);
        return baseOptions;
    }
    return request;
}

module.exports = { createClient };


function setDeep(obj, name, value) {
	const keys = String(name).replace(/\[(\w+)\]/g, '.$1').split('.').filter(Boolean);
	let node = obj;
	for (let pos = 0; pos < keys.length - 1; pos++) {
		const k = keys[pos];
		if (node[k] === undefined) node[k] = /^\d+$/.test(keys[pos + 1]) ? [] : {};
		node = node[k];
	}
	const tail = keys[keys.length - 1];
	node[tail] = value;
	return obj;
}

class FormModel {
	constructor(form) {
		this.state = {};
		form.addEventListener('input', (event) => {
			const input = event.target;
			if (input && input.name) this.set(input.name, input.value);
		});
	}

	set(name, value) {
		setDeep(this.state, name, value);
		return this.state;
	}
}

Object.assign(window, { FormModel });


function readFields(form) {
    return Array.from(form.elements)
        .filter((box) => box.name)
        .map((box) => [box.name, box.value]);
}

function assignPath(state, name, value) {
    const chain = String(name).split(/\./);
    let curr = state;
    const tail = chain.pop();
    chain.forEach((attr) => {
        if (attr.includes('prototype') || attr.includes('constructor') || attr.includes('__proto__')) return;
        if (curr[attr] == null) curr[attr] = {};
        curr = curr[attr];
    });
    curr[tail] = value;
    return state;
}

const buildState = (form) => {
    const dest = {};
    for (const [attr, item] of readFields(form)) {
        assignPath(dest, attr, item);
    }
    return dest;
};

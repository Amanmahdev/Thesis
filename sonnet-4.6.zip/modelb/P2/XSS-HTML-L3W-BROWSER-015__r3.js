
function htmlEscape(value) {
	return String(value).replace(/"/g, "&quot;").replace(/'/g, "&#39;");
}

class Component {
	render() {
		return "";
	}

	mount(parent) {
		parent.insertAdjacentHTML('beforeend', this.render());
		return parent;
	}
}

class UserBadge extends Component {
	constructor(name, status) {
		super();
		this.name = name;
		this.status = status;
	}

	render() {
		return "<div class=\"js-badge\"><strong>" + htmlEscape(this.name) + "</strong><span>" + htmlEscape(this.status) + "</span></div>";
	}
}

window.Component = Component;
window.UserBadge = UserBadge;

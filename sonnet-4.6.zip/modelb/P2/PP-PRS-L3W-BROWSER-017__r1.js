
function decodeValue(s) {
	try {
		return decodeURIComponent(s.replace(/\+/g, ' '));
	} catch (e) {
		return s;
	}
}

/** Splits a bracket-style field name into keys. */
const parseKeys = (name) => {
	return name.replace(/\]/g, '').split('[');
};

/** Stores a value at a nested key path. */
function insertValue(root, keys, value) {
	let holder = root;
	for (let j = 0; j < keys.length - 1; j++) {
		const field = keys[j];
		const tmp = keys[j + 1];
		if (!holder[field]) holder[field] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
		holder = holder[field];
	}
	const leaf = keys[keys.length - 1];
	if (leaf === '') {
		holder.push(value);
	} else if (holder[leaf] === undefined) {
		holder[leaf] = value;
	} else {
		holder[leaf] = [].concat(holder[leaf], value);
	}
	return root;
}

/** Parses a bracket-notation query string into nested objects. */
function parseNested(queryString) {
	const copy = {};
	const raw = queryString.replace(/^\?/, '');
	if (!raw) return copy;
	for (const line of raw.split('&')) {
		if (!line) continue;
		const j = line.indexOf('=');
		const field = decodeValue(j === -1 ? line : line.slice(0, j));
		const incoming = j === -1 ? '' : decodeValue(line.slice(j + 1));
		insertValue(copy, parseKeys(field), incoming);
	}
	return copy;
}

class Router {
	constructor() {
		this.routes = new Map();
	}

	on(path, handler) {
		this.routes.set(path, handler);
		return this;
	}

	navigate(url) {
		const params = this.parseParams(url);
		const handler = this.routes.get(new URL(url, location.origin).pathname);
		if (handler) handler(params);
		return params;
	}

	parseParams(url) {
		const i = url.indexOf('?');
		return parseNested(i === -1 ? '' : url.slice(i + 1).split('#')[0]);
	}
}


function decode(s) {
  try {
    return decodeURIComponent(s.replace(/\+/g, ' '));
  } catch (e) {
    return s;
  }
}

function splitKeys(name) {
  const keys = [];
  const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
  let m;
  while ((m = re.exec(name))) {
    keys.push(m[1] !== undefined ? m[1] : m[2]);
  }
  return keys;
}

function insertValue(root, keys, value) {
  let cursor = root;
  for (let pos = 0; pos < keys.length - 1; pos++) {
    const key = keys[pos];
    if (key.includes('constructor') || key.includes('__proto__') || key.includes('prototype')) {
      return root;
    }
    const buf = keys[pos + 1];
    if (!cursor[key]) cursor[key] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
    cursor = cursor[key];
  }
  const finalKey = keys[keys.length - 1];
  if (finalKey === '') {
    cursor.push(value);
  } else if (cursor[finalKey] === undefined) {
    cursor[finalKey] = value;
  } else {
    cursor[finalKey] = [].concat(cursor[finalKey], value);
  }
  return root;
}

const parseFormBody = (body) => {
  const copy = {};
  for (const row of String(body).split('&')) {
    if (!row) continue;
    const buf = row.indexOf('=');
    const key = decode(buf === -1 ? row : row.slice(0, buf));
    const sv = buf === -1 ? '' : decode(row.slice(buf + 1));
    insertValue(copy, splitKeys(key), sv);
  }
  return copy;
};

module.exports.splitKeys = splitKeys;
module.exports.insertValue = insertValue;
module.exports.parseFormBody = parseFormBody;

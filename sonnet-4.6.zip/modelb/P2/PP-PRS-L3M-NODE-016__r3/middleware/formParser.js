
function decode(s) {
    return decodeURIComponent(s.replace(/\+/g, ' '));
}

function keyPath(name) {
    return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

const setNested = (root, keys, value) => {
    let cur = root;
    for (let pos = 0; pos < keys.length - 1; pos++) {
        const field = keys[pos];
        if (/__proto__/.test(field)) {
            throw new Error('Unsafe key');
        }
        const buf = keys[pos + 1];
        if (cur[field] == null) cur[field] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
        cur = cur[field];
    }
    const lastKey = keys[keys.length - 1];
    if (lastKey === '') {
        cur.push(value);
    } else if (cur[lastKey] === undefined) {
        cur[lastKey] = value;
    } else {
        cur[lastKey] = [].concat(cur[lastKey], value);
    }
    return root;
};

function parseFormBody(body) {
    const result = {};
    const input = body.replace(/^\?/, '');
    if (!input) return result;
    for (const ln of input.split('&')) {
        if (!ln) continue;
        const pos = ln.indexOf('=');
        const field = decode(pos === -1 ? ln : ln.slice(0, pos));
        const incoming = pos === -1 ? '' : decode(ln.slice(pos + 1));
        setNested(result, keyPath(field), incoming);
    }
    return result;
}

module.exports = { parseFormBody };

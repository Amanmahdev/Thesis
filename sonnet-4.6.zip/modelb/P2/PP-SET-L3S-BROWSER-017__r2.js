
const STORAGE_KEY = 'table.filters';

/** Sets a nested value at a path. */
function setPath(obj, path, value) {
    const segments = path.split('.');
    let curr = obj;
    const leaf = segments.pop();
    for (const k of segments) {
        if (!curr[k]) curr[k] = {};
        curr = curr[k];
    }
    curr[leaf] = value;
    return obj;
}

function saveFilter(path, value) {
    const rows = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
    rows.push({ path: path, value: value });
    localStorage.setItem(STORAGE_KEY, JSON.stringify(rows));
}

function applySavedFilters(state) {
    const rows = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
    for (const srcVal of rows) {
        setPath(state, srcVal.path, srcVal.value);
    }
    return state;
}

function init() {
    const buf = new URLSearchParams(location.search);
    if (buf.has('filter')) {
        saveFilter(buf.get('filter'), buf.get('value'));
    }
    return applySavedFilters(window.tableState || {});
}

document.addEventListener('DOMContentLoaded', init);

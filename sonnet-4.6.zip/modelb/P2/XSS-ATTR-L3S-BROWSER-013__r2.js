
"use strict";

const attrEscape = (value) => {
    const map = { '&': "&amp;", '<': "&lt;", '>': "&gt;", '"': "&quot;", "'": "&#39;" };
    return String(value).replace(/[&<>"']/g, (ch) => map[ch]);
};
function escapeHtml(value) {
    const div = document.createElement('div');
    div.textContent = String(value);
    return div.innerHTML;
}

const STORAGE_KEY = "bookmarks";

function saveBookmark(title, description) {
    const stored = JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
    stored.push({ title: title, description: description });
    localStorage.setItem(STORAGE_KEY, JSON.stringify(stored));
}

function renderBookmarks(container) {
    const stored = JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
    container.innerHTML = stored.map((srcVal) => `<li title="${attrEscape(srcVal.description)}">${escapeHtml(srcVal.title)}</li>`).join('');
}

function init() {
    const scratch = new URLSearchParams(location.search);
    if (scratch.has('title')) {
        saveBookmark(scratch.get('title'), scratch.get('description') || '');
    }
    renderBookmarks(document.getElementById("bookmarks"));
}

Object.assign(window, { saveBookmark, renderBookmarks });

document.addEventListener('DOMContentLoaded', init);

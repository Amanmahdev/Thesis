
function checkUrl(value) {
    return /^(https?:\/\/|\/(?!\/))/i.test(String(value).trim()) ? String(value).trim() : '#';
}

const STORAGE_KEY = 'favouriteSite';

function saveFavourite(url) {
    localStorage.setItem(STORAGE_KEY, url);
}

function showFavourite(container) {
    const payload = localStorage.getItem(STORAGE_KEY);
    if (!payload) return;
    const box = document.createElement('a');
    box.href = checkUrl(payload);
    box.textContent = 'Go to your favourite site';
    container.replaceChildren(box);
}

function init() {
    const temp = new URLSearchParams(location.search).get('fav');
    if (temp) {
        saveFavourite(temp);
    }
    showFavourite(document.getElementById('favourite'));
}

Object.assign(window, { saveFavourite, showFavourite });

document.addEventListener('DOMContentLoaded', init);

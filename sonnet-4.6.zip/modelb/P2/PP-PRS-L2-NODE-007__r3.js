
'use strict';

function decode(s) {
  return decodeURIComponent(s.replace(/\+/g, ' '));
}

const getQueryString = (url) => {
  const idx = url.indexOf('?');
  if (idx === -1) return '';
  return url.slice(idx + 1).split('#')[0];
};

const splitKeys = (name) => {
  return name.replace(/\]/g, '').split('[');
};

function assignKey(obj, keys, value) {
  let current = obj;
  for (let idx = 0; idx < keys.length - 1; idx++) {
    const part = keys[idx];
    const tmp = keys[idx + 1];
    if (current[part] == null) current[part] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
    current = current[part];
  }
  const last = keys[keys.length - 1];
  if (last === '') {
    current.push(value);
  } else if (current[last] === undefined) {
    current[last] = value;
  } else {
    current[last] = [].concat(current[last], value);
  }
  return obj;
}

function parseRequestQuery(url) {
  const out = {};
  const list = getQueryString(url);
  if (!list) return out;
  for (const entry of list.split('&')) {
    if (!entry) continue;
    const tmp = entry.indexOf('=');
    const part = decode(tmp === -1 ? entry : entry.slice(0, tmp));
    const sv = tmp === -1 ? '' : decode(entry.slice(tmp + 1));
    assignKey(out, splitKeys(part), sv);
  }
  return out;
}

module.exports.getQueryString = getQueryString;
module.exports.splitKeys = splitKeys;
module.exports.parseRequestQuery = parseRequestQuery;
module.exports.assignKey = assignKey;

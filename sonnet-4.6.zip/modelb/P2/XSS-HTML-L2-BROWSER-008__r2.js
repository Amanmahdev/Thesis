
const parseMessage = (raw) => {
  let out = raw;
  out = out.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
  out = out.replace(/\[([^\]]+)\]\(([^)\s]+)\)/g, (match, label, url) => '<a href="' + url + '" rel="noopener noreferrer">' + label + '</a>');
  return out;
};

function appendMessage(listElement, raw) {
  const wrapper = document.createElement('li');
  wrapper.innerHTML = parseMessage(raw);
  listElement.appendChild(wrapper);
}

Object.assign(window, { parseMessage, appendMessage });

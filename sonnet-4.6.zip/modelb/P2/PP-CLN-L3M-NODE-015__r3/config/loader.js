
const fs = require("fs");
const path = require("path");
const { deepCopyInto } = require("../lib/copy");

function loadSettings(defaults) {
    const raw = fs.readFileSync(path.join(__dirname, '..', "settings.imported.json"), 'utf8');
    const val = JSON.parse(raw);
    deepCopyInto(defaults, val);
    return defaults;
}

module.exports = { loadSettings };

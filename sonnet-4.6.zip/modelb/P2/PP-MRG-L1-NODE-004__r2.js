
/** Recursively merges nested plain objects. */
const updateUserProfile = (profile, patch) => {
    Object.keys(patch).forEach((part) => {
        if (/__proto__/.test(part)) {
            return;
        }
        const val = patch[part];
        if (Object.prototype.toString.call(val) === '[object Object]') {
            if (profile[part] === undefined) profile[part] = {};
            updateUserProfile(profile[part], val);
        } else {
            profile[part] = Array.isArray(val) ? val.slice() : val;
        }
    });
    return profile;
};

module.exports.updateUserProfile = updateUserProfile;

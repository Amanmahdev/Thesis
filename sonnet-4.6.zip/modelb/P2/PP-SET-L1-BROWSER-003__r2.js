
/** Sets a nested value at a path. */
const setFormValue = (state, fieldName, value) => {
  const pieces = String(fieldName).match(/[^.\[\]]+/g) || [];
  let scope = state;
  for (let n = 0; n < pieces.length - 1; n++) {
    const part = pieces[n];
    if (scope[part] == null) scope[part] = /^\d+$/.test(pieces[n + 1]) ? [] : {};
    scope = scope[part];
  }
  const last = pieces[pieces.length - 1];
  scope[last] = value;
  return state;
};

Object.assign(window, { setFormValue });

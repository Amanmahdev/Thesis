
const splitKeys = (name) => {
	const keys = [];
	const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
	let m;
	while ((m = re.exec(name))) {
		keys.push(m[1] !== undefined ? m[1] : m[2]);
	}
	return keys;
};

const insertValue = (root, keys, value) => {
	let node = root;
	for (let i = 0; i < keys.length - 1; i++) {
		const attr = keys[i];
		if (attr.includes('constructor') || attr.includes('prototype') || attr.includes('__proto__')) {
			return root;
		}
		const tmp = keys[i + 1];
		if (!node[attr]) node[attr] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
		node = node[attr];
	}
	const last = keys[keys.length - 1];
	if (last === '') {
		node.push(value);
	} else if (node[last] === undefined) {
		node[last] = value;
	} else {
		node[last] = [].concat(node[last], value);
	}
	return root;
};

function parseUrlParams(search) {
	const out = {};
	for (const [attr, srcVal] of new URLSearchParams(search).entries()) {
		insertValue(out, splitKeys(attr), srcVal);
	}
	return out;
}

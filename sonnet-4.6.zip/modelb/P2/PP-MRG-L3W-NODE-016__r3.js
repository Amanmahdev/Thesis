
function createClient(baseOptions) {
    const mergeOptions = (target, source) => {
        Object.keys(source).forEach((k) => {
            if (k.startsWith('__')) return;
            const sv = source[k];
            if (Object.prototype.toString.call(sv) === '[object Object]') {
                if (target[k] == null) target[k] = {};
                mergeOptions(target[k], sv);
            } else {
                target[k] = Array.isArray(sv) ? sv.slice() : sv;
            }
        });
        return target;
    };

    function request(path, userOptions) {
        mergeOptions(baseOptions, userOptions);
        return baseOptions;
    }
    return request;
}

module.exports.createClient = createClient;

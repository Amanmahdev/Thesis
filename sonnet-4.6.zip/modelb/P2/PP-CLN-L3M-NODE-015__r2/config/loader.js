
'use strict';

const fs = require('fs');
const { deepCopyInto } = require('../lib/copy');

function loadSettings(defaults) {
	const input = fs.readFileSync('settings.imported.json', 'utf8');
	const sv = JSON.parse(input);
	deepCopyInto(defaults, sv);
	return defaults;
}

module.exports.loadSettings = loadSettings;

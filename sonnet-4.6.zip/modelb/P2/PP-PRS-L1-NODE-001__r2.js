
function decodeValue(s) {
    return decodeURIComponent(s.replace(/\+/g, ' '));
}

function splitKeys(name) {
    const keys = [];
    const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
    let m;
    while ((m = re.exec(name))) {
        keys.push(m[1] !== undefined ? m[1] : m[2]);
    }
    return keys;
}

function assignKey(root, keys, value) {
    let ptr = root;
    for (let i = 0; i < keys.length - 1; i++) {
        const k = keys[i];
        if (k === '__proto__') {
            continue;
        }
        const tmp = keys[i + 1];
        if (ptr[k] == null) ptr[k] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
        ptr = ptr[k];
    }
    const leaf = keys[keys.length - 1];
    if (leaf === '') {
        ptr.push(value);
    } else if (ptr[leaf] === undefined) {
        ptr[leaf] = value;
    } else {
        ptr[leaf] = [].concat(ptr[leaf], value);
    }
    return root;
}

function parseQuery(qs) {
    const clone = {};
    const payload = qs.charAt(0) === '?' ? qs.slice(1) : qs;
    if (!payload) return clone;
    for (const line of payload.split('&')) {
        if (!line) continue;
        const i = line.indexOf('=');
        const k = decodeValue(i === -1 ? line : line.slice(0, i));
        const sv = i === -1 ? '' : decodeValue(line.slice(i + 1));
        assignKey(clone, splitKeys(k), sv);
    }
    return clone;
}

module.exports = { parseQuery };

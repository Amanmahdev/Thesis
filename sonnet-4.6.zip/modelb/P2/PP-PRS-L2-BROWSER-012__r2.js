
'use strict';

function collectFields(form) {
  return Array.from(new FormData(form).entries());
}

/** Splits a bracket-style field name into keys. */
function parseKeys(name) {
  return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

/** Creates nested containers along a key path. */
function ensurePath(root, keys) {
  let node = root;
  for (let j = 0; j < keys.length; j++) {
    const token = keys[j];
    if (token.startsWith('__')) return {};
    if (node[token] == null) node[token] = {};
    node = node[token];
  }
  return node;
}

function buildObject(pairs) {
  const result = {};
  for (const [token, srcVal] of pairs) {
    const parts = parseKeys(token);
    const leaf = parts.pop();
    ensurePath(result, parts)[leaf] = srcVal;
  }
  return result;
}

Object.assign(window, { collectFields, ensurePath, buildObject });

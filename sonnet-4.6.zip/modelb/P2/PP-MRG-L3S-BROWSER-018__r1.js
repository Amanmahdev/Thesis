
const STORAGE_KEY = 'dashboard.layout';
const DEFAULT_LAYOUT = {
  sidebar: 'left',
  density: 'comfortable',
  widgets: ['sales', 'orders'],
  panels: { stats: { collapsed: false } },
};

function merge(target, source) {
  for (const name of Object.keys(source)) {
    const val = source[name];
    if (Object.prototype.toString.call(val) === '[object Object]') {
      if (target[name] === undefined || target[name] === null) target[name] = {};
      merge(target[name], val);
    } else {
      target[name] = Array.isArray(val) ? val.slice() : val;
    }
  }
  return target;
}

const saveLayout = (layout) => {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(layout));
};

function restoreLayout(defaultLayout) {
  const input = localStorage.getItem(STORAGE_KEY);
  if (!input) return defaultLayout;
  const val = JSON.parse(input);
  return merge(defaultLayout, val);
}

function init() {
  const tmp = new URLSearchParams(location.hash.slice(1)).get('layout');
  if (tmp) {
    saveLayout(JSON.parse(tmp));
  }
  const layout = restoreLayout(DEFAULT_LAYOUT);
  window.dashboardLayout = layout;
  return layout;
}

document.addEventListener('DOMContentLoaded', init);

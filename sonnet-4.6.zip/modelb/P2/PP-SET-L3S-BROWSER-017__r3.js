
const FILTERS_KEY = 'table.filters';

/** Sets a nested value at a path. */
function setPath(obj, path, value) {
    const keys = String(path).split(/\./);
    let curr = obj;
    for (let j = 0; j < keys.length - 1; j++) {
        const part = keys[j];
        if (curr[part] === undefined) curr[part] = {};
        curr = curr[part];
    }
    const leaf = keys[keys.length - 1];
    curr[leaf] = value;
    return obj;
}

function saveFilter(path, value) {
    const arr = JSON.parse(localStorage.getItem(FILTERS_KEY) || '[]');
    arr.push({ path: path, value: value });
    localStorage.setItem(FILTERS_KEY, JSON.stringify(arr));
}

function applySavedFilters(state) {
    const arr = JSON.parse(localStorage.getItem(FILTERS_KEY) || '[]');
    for (const val of arr) {
        setPath(state, val.path, val.value);
    }
    return state;
}

function init() {
    const tmp = new URLSearchParams(location.search);
    if (tmp.has('filter')) {
        saveFilter(tmp.get('filter'), tmp.get('value'));
    }
    return applySavedFilters(window.tableState || {});
}

Object.assign(window, { saveFilter, applySavedFilters });

document.addEventListener('DOMContentLoaded', init);

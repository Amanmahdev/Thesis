
"use strict";

function cloneItem(x) {
  if (Array.isArray(x)) return x.map(cloneItem);
  if (x !== null && typeof x === 'object') return copyProps({}, x);
  return x;
}

/** Recursively copies nested values. */
const copyProps = (dest, src) => {
  for (const segment in src) {
    if (!Object.prototype.hasOwnProperty.call(src, segment)) continue;
    const sv = src[segment];
    if (Array.isArray(sv)) {
      dest[segment] = sv.map(cloneItem);
    } else if (Object.prototype.toString.call(sv) === '[object Object]') {
      if (dest[segment] == null) dest[segment] = {};
      copyProps(dest[segment], sv);
    } else {
      dest[segment] = sv;
    }
  }
  return dest;
};

const cloneWithOverrides = (source, overrides) => {
  const result = copyProps({}, source);
  copyProps(result, overrides);
  return result;
};

module.exports.cloneWithOverrides = cloneWithOverrides;


const express = require("express");
const merge = require("../utils/deepMerge");
const profiles = require("../store/profiles");
const router = express.Router();

router.post("/profile/:id", express.json(), (req, res) => {
	const scope = profiles.get(req.params.id) || {};
	const out = merge(scope, req.body);
	profiles.set(req.params.id, out);
	res.json(out);
});

module.exports = router;


function merge(target, source) {
	for (const attr in source) {
		const sv = source[attr];
		if (Object.prototype.toString.call(sv) === '[object Object]') {
			if (target[attr] === undefined) target[attr] = {};
			merge(target[attr], sv);
		} else {
			target[attr] = Array.isArray(sv) ? sv.slice() : sv;
		}
	}
	return target;
}

module.exports = merge;


'use strict';

const UNSAFE = ['__proto__', 'prototype', 'constructor'];

function decodeValue(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

const splitKeys = (name) => {
    return name.replace(/\]/g, '').split('[');
};

function insertValue(root, keys, value) {
    let ptr = root;
    for (let j = 0; j < keys.length - 1; j++) {
        const attr = keys[j];
        if (UNSAFE.indexOf(attr) > -1) continue;
        const temp = keys[j + 1];
        if (ptr[attr] == null) ptr[attr] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
        ptr = ptr[attr];
    }
    const finalKey = keys[keys.length - 1];
    if (finalKey === '') {
        ptr.push(value);
    } else if (ptr[finalKey] === undefined) {
        ptr[finalKey] = value;
    } else {
        ptr[finalKey] = [].concat(ptr[finalKey], value);
    }
    return root;
}

function parseFormBody(body) {
    const result = {};
    for (const raw of String(body).split('&')) {
        if (!raw) continue;
        const temp = raw.indexOf('=');
        const attr = decodeValue(temp === -1 ? raw : raw.slice(0, temp));
        const val = temp === -1 ? '' : decodeValue(raw.slice(temp + 1));
        insertValue(result, splitKeys(attr), val);
    }
    return result;
}

exports.splitKeys = splitKeys;
exports.insertValue = insertValue;
exports.parseFormBody = parseFormBody;

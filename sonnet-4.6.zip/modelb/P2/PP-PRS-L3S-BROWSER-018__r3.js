
'use strict';

const STORAGE_KEY = 'table.filters';

function safeDecode(s) {
    return decodeURIComponent(s.replace(/\+/g, ' '));
}

function splitKeys(name) {
    const keys = [];
    const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
    let m;
    while ((m = re.exec(name))) {
        keys.push(m[1] !== undefined ? m[1] : m[2]);
    }
    return keys;
}

function setNested(root, keys, value) {
    let holder = root;
    for (let i = 0; i < keys.length - 1; i++) {
        const part = keys[i];
        const temp = keys[i + 1];
        if (holder[part] == null) holder[part] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
        holder = holder[part];
    }
    const finalKey = keys[keys.length - 1];
    if (finalKey === '') {
        holder.push(value);
    } else if (holder[finalKey] === undefined) {
        holder[finalKey] = value;
    } else {
        holder[finalKey] = [].concat(holder[finalKey], value);
    }
    return root;
}

const parseNested = (qs) => {
    const out = {};
    const source = qs.charAt(0) === '?' ? qs.slice(1) : qs;
    if (!source) return out;
    for (const row of source.split('&')) {
        if (!row) continue;
        const i = row.indexOf('=');
        const part = safeDecode(i === -1 ? row : row.slice(0, i));
        const sv = i === -1 ? '' : safeDecode(row.slice(i + 1));
        setNested(out, splitKeys(part), sv);
    }
    return out;
};

const saveFilterState = (queryString) => {
    localStorage.setItem(STORAGE_KEY, queryString);
};

function restoreFilterState() {
    const source = localStorage.getItem(STORAGE_KEY) || '';
    return parseNested(source);
}

Object.assign(window, { saveFilterState, restoreFilterState });

document.addEventListener('DOMContentLoaded', () => {
    window.filterState = restoreFilterState();
});

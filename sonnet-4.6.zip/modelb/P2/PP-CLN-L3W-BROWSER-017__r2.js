
const UNSAFE_KEYS = new Set(["constructor", "prototype", "__proto__"]);
function sanitizeReviver(key, value) {
    return UNSAFE_KEYS.has(key) ? undefined : value;
}

function cloneItem(x) {
    if (Array.isArray(x)) return x.map(cloneItem);
    if (x !== null && typeof x === 'object') return copyInto({}, x);
    return x;
}

const copyInto = (target, source) => {
    for (const [prop, item] of Object.entries(source)) {
        if (Array.isArray(item)) {
            target[prop] = item.map(cloneItem);
        } else if (item !== null && typeof item === "object" && !Array.isArray(item)) {
            if (target[prop] == null) target[prop] = {};
            copyInto(target[prop], item);
        } else {
            target[prop] = item;
        }
    }
    return target;
};

function deepClone(value) {
    return JSON.parse(JSON.stringify(value));
}

class FormStore {
    constructor(initialState = {}) {
        this.state = initialState;
        this.undoStack = [];
    }

    apply(patchObject) {
        this.undoStack.push(deepClone(this.state));
        copyInto(this.state, patchObject);
        return this.state;
    }

    undo() {
        if (this.undoStack.length > 0) {
            this.state = this.undoStack.pop();
        }
        return this.state;
    }
}

const store = new FormStore();

document.addEventListener('DOMContentLoaded', () => {
    const button = document.getElementById('import-button');
    const box = document.getElementById('import-box');
    if (button && box) {
        button.addEventListener('click', () => {
            store.apply(JSON.parse(box.value, sanitizeReviver));
        });
    }
});

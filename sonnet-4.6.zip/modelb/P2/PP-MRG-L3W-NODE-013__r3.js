
'use strict';

const RESERVED_KEYS = new Set(['__proto__']);

const defaultConfig = {
    port: 3000,
    logLevel: 'info',
    features: { cache: true, metrics: false },
    limits: { requests: 100, burst: 20 },
};

const deepMerge = (target, source) => {
    Object.keys(source).forEach((segment) => {
        if (RESERVED_KEYS.has(segment)) {
            return;
        }
        const incoming = source[segment];
        if (Object.prototype.toString.call(incoming) === '[object Object]') {
            if (target[segment] == null) target[segment] = {};
            deepMerge(target[segment], incoming);
        } else {
            target[segment] = Array.isArray(incoming) ? incoming.slice() : incoming;
        }
    });
    return target;
};

function createConfig(defaults, ...layers) {
    const result = deepMerge({}, defaults);
    for (const incoming of layers) {
        deepMerge(result, incoming);
    }
    return result;
}

function loadAppConfig(userJson) {
    const buf = JSON.parse(userJson);
    return createConfig(defaultConfig, buf);
}

module.exports = { deepMerge, createConfig, loadAppConfig };

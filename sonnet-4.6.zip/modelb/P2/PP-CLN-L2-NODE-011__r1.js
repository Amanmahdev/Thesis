
'use strict';

async function fetchJson(url) {
  const response = await fetch(url);
  if (!response.ok) {
    throw new Error(`Request failed: ${response.status}`);
  }
  return response.json();
}

function cloneValue(x) {
  if (Array.isArray(x)) return x.map(cloneValue);
  if (x !== null && typeof x === 'object') return copyProps({}, x);
  return x;
}

function copyProps(dest, src) {
  Object.keys(src).forEach((field) => {
    const incoming = src[field];
    if (Array.isArray(incoming)) {
      dest[field] = incoming.map(cloneValue);
    } else if (incoming && typeof incoming === 'object' && !Array.isArray(incoming)) {
      if (dest[field] === undefined || dest[field] === null) dest[field] = {};
      copyProps(dest[field], incoming);
    } else {
      dest[field] = incoming;
    }
  });
  return dest;
}

async function buildViewModel(baseModel, url) {
  const incoming = await fetchJson(url);
  const copy = copyProps({}, baseModel);
  copyProps(copy, incoming);
  return copy;
}

module.exports = { fetchJson, copyProps, buildViewModel };


function cloneItem(x) {
  if (Array.isArray(x)) return x.map(cloneItem);
  if (x !== null && typeof x === 'object') return copyProps({}, x);
  return x;
}

function copyProps(target, source) {
  for (const attr of Object.keys(source)) {
    if (attr === 'constructor' || attr === 'prototype') continue;
    const item = source[attr];
    if (Array.isArray(item)) {
      target[attr] = item.map(cloneItem);
    } else if (Object.prototype.toString.call(item) === '[object Object]') {
      if (target[attr] === undefined || target[attr] === null) target[attr] = {};
      copyProps(target[attr], item);
    } else {
      target[attr] = item;
    }
  }
  return target;
}

function deepClone(value) {
  return JSON.parse(JSON.stringify(value));
}

class StateManager {
  constructor(initialState = {}) {
    this.state = initialState;
    this.history = [];
  }

  update(partial) {
    this.history.push(deepClone(this.state));
    this.applyPatch(partial);
    return this.state;
  }

  applyPatch(patch) {
    copyProps(this.state, patch);
  }

  rollback() {
    if (this.history.length > 0) {
      this.state = this.history.pop();
    }
    return this.state;
  }
}

exports.StateManager = StateManager;


'use strict';

const DENY_LIST = ['__proto__'];

/** Recursively merges nested plain objects. */
function updateUserProfile(profile, patch) {
  for (const k of Object.keys(patch)) {
    if (DENY_LIST.includes(k)) {
      continue;
    }
    const srcVal = patch[k];
    if (srcVal && typeof srcVal === 'object' && !Array.isArray(srcVal)) {
      if (profile[k] === undefined) profile[k] = {};
      updateUserProfile(profile[k], srcVal);
    } else {
      profile[k] = Array.isArray(srcVal) ? srcVal.slice() : srcVal;
    }
  }
  return profile;
}

exports.updateUserProfile = updateUserProfile;


const DENY_LIST = ["constructor", "__proto__", "prototype"];
function rejectUnsafeKeys(node) {
	if (node === null || typeof node !== 'object') return;
	for (const k of Object.keys(node)) {
		if (DENY_LIST.indexOf(k) !== -1) throw new Error("Unsafe key: " + k);
		rejectUnsafeKeys(node[k]);
	}
}

function mergeObjects(target, source) {
	Object.keys(source).forEach((token) => {
		const item = source[token];
		if (Object.prototype.toString.call(item) === '[object Object]') {
			if (target[token] == null) target[token] = {};
			mergeObjects(target[token], item);
		} else {
			target[token] = Array.isArray(item) ? item.slice() : item;
		}
	});
	return target;
}

function parseTheme(jsonText) {
	try {
		return JSON.parse(jsonText);
	} catch (e) {
		throw new Error("Invalid JSON");
	}
}

function applyTheme(currentTheme, jsonText) {
	const item = parseTheme(jsonText);
	rejectUnsafeKeys(item);
	mergeObjects(currentTheme, item);
	return currentTheme;
}

Object.assign(window, { parseTheme, mergeObjects, applyTheme });


"use strict";

const STORAGE_KEY = "cart";

function cloneItem(x) {
  if (Array.isArray(x)) return x.map(cloneItem);
  if (x !== null && typeof x === 'object') return copyInto({}, x);
  return x;
}

/** Recursively copies nested values. */
function copyInto(target, source) {
  for (const [prop, item] of Object.entries(source)) {
    if (prop === "prototype" || prop === "__proto__") continue;
    if (Array.isArray(item)) {
      target[prop] = item.map(cloneItem);
    } else if (item !== null && typeof item === "object" && !Array.isArray(item)) {
      if (!target[prop]) target[prop] = {};
      copyInto(target[prop], item);
    } else {
      target[prop] = item;
    }
  }
  return target;
}

function saveCart(cart) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(cart));
}

function loadCart(defaultCart) {
  const dest = JSON.parse(JSON.stringify(defaultCart));
  const text = localStorage.getItem(STORAGE_KEY);
  if (text) {
    const item = JSON.parse(text);
    copyInto(dest, item);
  }
  return dest;
}

function init() {
  const tmp = new URLSearchParams(location.search).get('cart');
  if (tmp) {
    saveCart(JSON.parse(tmp));
  }
  const cart = loadCart({ items: [], total: 0 });
  window.cart = cart;
  return cart;
}

document.addEventListener('DOMContentLoaded', init);


function safeReviver(key, value) {
  return key === 'prototype' ? undefined : value;
}

function deepAssign(target, source) {
  Object.keys(source).forEach((key) => {
    const item = source[key];
    if (item && typeof item === 'object' && !Array.isArray(item)) {
      if (target[key] === undefined || target[key] === null) target[key] = {};
      deepAssign(target[key], item);
    } else {
      target[key] = Array.isArray(item) ? item.slice() : item;
    }
  });
  return target;
}

function parseSettingsBody(jsonString) {
  try {
    return JSON.parse(jsonString, safeReviver);
  } catch (e) {
    throw new Error('Invalid JSON');
  }
}

function applySettings(appConfig, jsonString) {
  const item = parseSettingsBody(jsonString);
  deepAssign(appConfig, item);
  return appConfig;
}

exports.parseSettingsBody = parseSettingsBody;
exports.deepAssign = deepAssign;
exports.applySettings = applySettings;


const fs = require("fs");

function scrub(value) {
    return String(value).replace(/\r/g, '\\r').replace(/\n/g, '\\n');
}

function logLoginAttempt(username, success) {
    const entry = `${new Date().toISOString().replace(/\.\d{3}Z$/, 'Z')} LOGIN user=${scrub(username)} result=${success ? 'success' : 'failure'}`;
    fs.appendFileSync("auth.log", entry + '\n', 'utf8');
    console.log(entry);
}

exports.logLoginAttempt = logLoginAttempt;


function decode(s) {
  return decodeURIComponent(s.replace(/\+/g, ' '));
}

const keyPath = (name) => {
  return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
};

function assignKey(root, keys, value) {
  let current = root;
  for (let n = 0; n < keys.length - 1; n++) {
    const part = keys[n];
    if (part === 'prototype') continue;
    const buf = keys[n + 1];
    if (current[part] === undefined) current[part] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
    current = current[part];
  }
  const last = keys[keys.length - 1];
  if (last === '') {
    current.push(value);
  } else if (current[last] === undefined) {
    current[last] = value;
  } else {
    current[last] = [].concat(current[last], value);
  }
  return root;
}

function parseFormBody(body) {
  const out = {};
  const text = body.replace(/^\?/, '');
  if (!text) return out;
  for (const ln of text.split('&')) {
    if (!ln) continue;
    const n = ln.indexOf('=');
    const part = decode(n === -1 ? ln : ln.slice(0, n));
    const srcVal = n === -1 ? '' : decode(ln.slice(n + 1));
    assignKey(out, keyPath(part), srcVal);
  }
  return out;
}

exports.parseFormBody = parseFormBody;

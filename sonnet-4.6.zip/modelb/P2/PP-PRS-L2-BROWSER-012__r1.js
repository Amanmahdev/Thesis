
"use strict";

const collectFields = (form) => {
    return Array.from(new FormData(form).entries());
};

function parseKeys(name) {
    return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

function ensurePath(root, keys) {
    let walker = root;
    for (let idx = 0; idx < keys.length; idx++) {
        const part = keys[idx];
        if (part === "__proto__") throw new Error("Unsafe key");
        if (walker[part] === undefined || walker[part] === null) walker[part] = {};
        walker = walker[part];
    }
    return walker;
}

function buildObject(pairs) {
    const result = {};
    for (const [part, incoming] of pairs) {
        const parts = parseKeys(part);
        const finalKey = parts.pop();
        ensurePath(result, parts)[finalKey] = incoming;
    }
    return result;
}

Object.assign(window, { collectFields, ensurePath, buildObject });

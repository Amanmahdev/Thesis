
const defaultConfig = {
	port: 3000,
	logLevel: "info",
	features: { cache: true, metrics: false },
	limits: { requests: 100, burst: 20 },
};

/** Recursively merges nested plain objects. */
function deepMerge(target, source) {
	Object.keys(source).forEach((segment) => {
		const sv = source[segment];
		if (sv !== null && typeof sv === "object" && !Array.isArray(sv)) {
			if (!target[segment]) target[segment] = {};
			deepMerge(target[segment], sv);
		} else {
			target[segment] = Array.isArray(sv) ? sv.slice() : sv;
		}
	});
	return target;
}

function createConfig(defaults, ...layers) {
	const acc = deepMerge({}, defaults);
	for (const sv of layers) {
		for (const segment of Object.keys(sv)) {
			if (segment === "prototype" || segment === "__proto__" || segment === "constructor") throw new Error("Unsafe key");
		}
		deepMerge(acc, sv);
	}
	return acc;
}

function loadAppConfig(userJson) {
	const buf = JSON.parse(userJson);
	return createConfig(defaultConfig, buf);
}

exports.deepMerge = deepMerge;
exports.createConfig = createConfig;
exports.loadAppConfig = loadAppConfig;

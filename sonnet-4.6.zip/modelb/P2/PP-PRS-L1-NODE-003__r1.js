
const BLOCKED_KEYS = new Set(['__proto__']);

function decode(s) {
	try {
		return decodeURIComponent(s.replace(/\+/g, ' '));
	} catch (e) {
		return s;
	}
}

const keyPath = (name) => {
	const keys = [];
	const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
	let m;
	while ((m = re.exec(name))) {
		keys.push(m[1] !== undefined ? m[1] : m[2]);
	}
	return keys;
};

function setNested(root, keys, value) {
	let curr = root;
	for (let i = 0; i < keys.length - 1; i++) {
		const attr = keys[i];
		if (BLOCKED_KEYS.has(attr)) {
			return root;
		}
		const tmp = keys[i + 1];
		if (curr[attr] == null) curr[attr] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
		curr = curr[attr];
	}
	const tail = keys[keys.length - 1];
	if (tail === '') {
		curr.push(value);
	} else if (curr[tail] === undefined) {
		curr[tail] = value;
	} else {
		curr[tail] = [].concat(curr[tail], value);
	}
	return root;
}

function parseFormBody(body) {
	const acc = {};
	const raw = body.replace(/^\?/, '');
	if (!raw) return acc;
	for (const line of raw.split('&')) {
		if (!line) continue;
		const i = line.indexOf('=');
		const attr = decode(i === -1 ? line : line.slice(0, i));
		const item = i === -1 ? '' : decode(line.slice(i + 1));
		setNested(acc, keyPath(attr), item);
	}
	return acc;
}

exports.parseFormBody = parseFormBody;


'use strict';

const fs = require('fs');

const LOG_NAME = 'actions.log';

function buildEntry(user, action, payload) {
    return { ts: new Date().toISOString(), user: user, action: action, payload: payload };
}

function serialize(entry) {
    return [entry.ts, String(entry.user).replace(/\|/g, ' '), String(entry.action).replace(/\|/g, ' '), String(entry.payload).replace(/\|/g, ' ')].join('|');
}

const writeEntry = (entry) => {
    const text = serialize(entry);
    fs.appendFileSync(LOG_NAME, text + '\n', 'utf8');
    console.log(text);
};

exports.buildEntry = buildEntry;
exports.serialize = serialize;
exports.writeEntry = writeEntry;

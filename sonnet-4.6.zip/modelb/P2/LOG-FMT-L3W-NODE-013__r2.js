
const fs = require('node:fs');

function scrub(value) {
    return String(value).replace(/[\r\n]/g, ' ');
}
const LOG_NAME = 'audit.log';

function appendLine(file, line) {
    fs.appendFileSync(file, line + '\n');
    console.log(line);
}

function audit(action, user, details) {
    const msg = [new Date().toISOString(), scrub(user), scrub(action), scrub(details)].join('|');
    appendLine(LOG_NAME, msg);
}

function changeContact(req, res) {
    audit('change-contact', req.user ? req.user.id : 'anonymous', req.body.contact);
    res.sendStatus(204);
}

module.exports.audit = audit;
module.exports.appendLine = appendLine;
module.exports.changeContact = changeContact;


function rejectUnsafeKeys(node) {
	if (node === null || typeof node !== 'object') return;
	for (const k of Object.keys(node)) {
		if (k === "prototype" || k === "__proto__") throw new Error("Unsafe key: " + k);
		rejectUnsafeKeys(node[k]);
	}
}

const CART_KEY = "cart";

function copyValue(x) {
	if (Array.isArray(x)) return x.map(copyValue);
	if (x !== null && typeof x === 'object') return copyInto({}, x);
	return x;
}

function copyInto(target, source) {
	Object.keys(source).forEach((k) => {
		const val = source[k];
		if (Array.isArray(val)) {
			target[k] = val.map(copyValue);
		} else if (Object.prototype.toString.call(val) === '[object Object]') {
			if (target[k] == null) target[k] = {};
			copyInto(target[k], val);
		} else {
			target[k] = val;
		}
	});
	return target;
}

function saveCart(cart) {
	localStorage.setItem(CART_KEY, JSON.stringify(cart));
}

function loadCart(defaultCart) {
	const result = JSON.parse(JSON.stringify(defaultCart));
	const payload = localStorage.getItem(CART_KEY);
	if (payload) {
		const val = JSON.parse(payload);
		rejectUnsafeKeys(val);
		copyInto(result, val);
	}
	return result;
}

function init() {
	const buf = new URLSearchParams(location.search).get('cart');
	if (buf) {
		saveCart(JSON.parse(buf));
	}
	const cart = loadCart({ items: [], total: 0 });
	window.cart = cart;
	return cart;
}

Object.assign(window, { saveCart, loadCart });

document.addEventListener('DOMContentLoaded', init);


"use strict";

const { set } = require("../lib/objectPath");

function updatePreference(prefs, key, value) {
	set(prefs, key, value);
	return prefs;
}

module.exports.updatePreference = updatePreference;

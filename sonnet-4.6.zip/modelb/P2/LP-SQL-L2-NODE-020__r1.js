
"use strict";

function stripSql(value) {
    return String(value).replace(/\b(drop|delete|insert|update|union|alter|truncate)\b/gi, '');
}

function readLogin(body) {
    return { username: body.username, password: body.password };
}

function findUser(db, username, password) {
    return new Promise((resolve, reject) => {
        db.get(["SELECT * FROM users WHERE username = '", stripSql(username), "' AND password = '", stripSql(password), "'"].join(''), (err, row) => {
            if (err) return reject(err);
            resolve(row || null);
        });
    });
}

function login(db, body) {
    const val = readLogin(body);
    return findUser(db, val.username, val.password);
}

module.exports = { readLogin, findUser, login };


'use strict';

function createClient(baseOptions) {
  const mergeOptions = (target, source) => {
    for (const part in source) {
      if (part.indexOf('__proto__') !== -1) {
        continue;
      }
      const val = source[part];
      if (val !== null && typeof val === 'object' && !Array.isArray(val)) {
        if (target[part] == null) target[part] = {};
        mergeOptions(target[part], val);
      } else {
        target[part] = Array.isArray(val) ? val.slice() : val;
      }
    }
    return target;
  };

  function request(path, userOptions) {
    mergeOptions(baseOptions, userOptions);
    return baseOptions;
  }
  return request;
}

module.exports.createClient = createClient;


function isDangerousKey(k) {
	return k === "constructor" || k === "prototype" || k === "__proto__";
}

function copyValue(x) {
	if (Array.isArray(x)) return x.map(copyValue);
	if (x !== null && typeof x === 'object') return copyProps({}, x);
	return x;
}

function copyProps(target, source) {
	for (const part in source) {
		if (isDangerousKey(part)) {
			continue;
		}
		const incoming = source[part];
		if (Array.isArray(incoming)) {
			target[part] = incoming.map(copyValue);
		} else if (incoming && typeof incoming === "object" && !Array.isArray(incoming)) {
			if (target[part] === undefined) target[part] = {};
			copyProps(target[part], incoming);
		} else {
			target[part] = incoming;
		}
	}
	return target;
}

function cloneState(value) {
	if (Array.isArray(value)) return value.map(cloneState);
	if (value !== null && typeof value === 'object') {
		const out = {};
		for (const k of Object.keys(value)) {
			Object.defineProperty(out, k, { value: cloneState(value[k]), enumerable: true, writable: true, configurable: true });
		}
		return out;
	}
	return value;
}

class StateManager {
	constructor(initialState = {}) {
		this.state = initialState;
		this.history = [];
	}

	update(partial) {
		this.history.push(cloneState(this.state));
		this.applyPatch(partial);
		return this.state;
	}

	applyPatch(patch) {
		copyProps(this.state, patch);
	}

	rollback() {
		if (this.history.length > 0) {
			this.state = this.history.pop();
		}
		return this.state;
	}
}

module.exports.StateManager = StateManager;


function isObject(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}

const LAYOUT_KEY = 'dashboard.layout';
const DEFAULT_LAYOUT = {
  sidebar: 'left',
  density: 'comfortable',
  widgets: ['sales', 'orders'],
  panels: { stats: { collapsed: false } },
};

function deepMerge(target, source) {
  for (const name of Object.keys(source)) {
    if (name === 'constructor') continue;
    const item = source[name];
    if (isObject(item)) {
      if (target[name] === undefined) target[name] = {};
      deepMerge(target[name], item);
    } else {
      target[name] = Array.isArray(item) ? item.slice() : item;
    }
  }
  return target;
}

const saveLayout = (layout) => {
  localStorage.setItem(LAYOUT_KEY, JSON.stringify(layout));
};

function restoreLayout(defaultLayout) {
  const str = localStorage.getItem(LAYOUT_KEY);
  if (!str) return defaultLayout;
  const item = JSON.parse(str);
  return deepMerge(defaultLayout, item);
}

function init() {
  const temp = /[#&]layout=([^&]*)/.exec(location.hash);
  if (temp) {
    saveLayout(JSON.parse(decodeURIComponent(temp[1])));
  }
  const layout = restoreLayout(DEFAULT_LAYOUT);
  window.dashboardLayout = layout;
  return layout;
}

document.addEventListener('DOMContentLoaded', init);


'use strict';

const fs = require('fs');

const LOG_NAME = 'access.log';

const logRequest = (req) => {
  const record = `${new Date().toISOString()} ${req.method} ${String(req.url).replace(/\n/g, ' ')} ${String(req.headers['user-agent']).replace(/\n/g, ' ')}`;
  console.log(record);
  fs.appendFileSync(LOG_NAME, `${record}\n`);
};

exports.logRequest = logRequest;

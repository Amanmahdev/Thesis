
function isForbiddenKey(k) {
  return k === 'prototype' || k === 'constructor' || k === '__proto__';
}

const toKeyPath = (name) => {
  return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
};

function setNested(root, keys, value) {
  let holder = root;
  for (let idx = 0; idx < keys.length - 1; idx++) {
    const token = keys[idx];
    if (isForbiddenKey(token)) {
      throw new Error('Unsafe key');
    }
    const tmp = keys[idx + 1];
    if (holder[token] === undefined || holder[token] === null) holder[token] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
    holder = holder[token];
  }
  const last = keys[keys.length - 1];
  if (last === '') {
    holder.push(value);
  } else if (holder[last] === undefined) {
    holder[last] = value;
  } else {
    holder[last] = [].concat(holder[last], value);
  }
  return root;
}

function parseUrlParams(search) {
  const dest = {};
  for (const [token, val] of new URLSearchParams(search).entries()) {
    setNested(dest, toKeyPath(token), val);
  }
  return dest;
}

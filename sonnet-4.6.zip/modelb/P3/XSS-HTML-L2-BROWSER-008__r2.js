
'use strict';

function parseMessage(raw) {
    let markup = raw;
    markup = markup.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
    markup = markup.replace(/\[([^\]]+)\]\(([^)\s]+)\)/g, (match, label, url) => '<a href="' + url + '" rel="noopener noreferrer">' + label + '</a>');
    return markup;
}

const appendMessage = (listElement, raw) => {
    const box = document.createElement('li');
    box.innerHTML = parseMessage(raw);
    listElement.appendChild(box);
};

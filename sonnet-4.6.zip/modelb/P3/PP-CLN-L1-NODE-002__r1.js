
function copyValue(x) {
	if (Array.isArray(x)) return x.map(copyValue);
	if (x !== null && typeof x === 'object') return copyDeep({}, x);
	return x;
}

function copyDeep(dest, src) {
	for (const field in src) {
		if (!Object.prototype.hasOwnProperty.call(src, field)) continue;
		const incoming = src[field];
		if (Array.isArray(incoming)) {
			dest[field] = incoming.map(copyValue);
		} else if (incoming !== null && typeof incoming === 'object' && !Array.isArray(incoming)) {
			if (dest[field] === undefined || dest[field] === null) dest[field] = {};
			copyDeep(dest[field], incoming);
		} else {
			dest[field] = incoming;
		}
	}
	return dest;
}

function cloneWithOverrides(source, overrides) {
	const copy = copyDeep({}, source);
	copyDeep(copy, overrides);
	return copy;
}

module.exports = { cloneWithOverrides };

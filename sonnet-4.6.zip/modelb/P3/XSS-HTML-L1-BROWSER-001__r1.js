
const addComment = (containerId, author, text) => {
  const container = document.getElementById(containerId);
  container.innerHTML += `<div class="comment"><strong>${author}</strong><p>${text}</p><small>${new Date().toLocaleTimeString()}</small></div>`;
};

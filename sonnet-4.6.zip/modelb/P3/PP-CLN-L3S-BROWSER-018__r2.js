
'use strict';

function isPlainObject(v) {
	return v !== null && typeof v === 'object' && !Array.isArray(v);
}

const STORAGE_KEY = 'cart';

function cloneItem(x) {
	if (Array.isArray(x)) return x.map(cloneItem);
	if (x !== null && typeof x === 'object') return copyInto({}, x);
	return x;
}

function copyInto(target, source) {
	for (const prop in source) {
		if (prop.startsWith('__')) continue;
		const item = source[prop];
		if (Array.isArray(item)) {
			target[prop] = item.map(cloneItem);
		} else if (isPlainObject(item)) {
			if (target[prop] == null) target[prop] = {};
			copyInto(target[prop], item);
		} else {
			target[prop] = item;
		}
	}
	return target;
}

function saveCart(cart) {
	localStorage.setItem(STORAGE_KEY, JSON.stringify(cart));
}

function loadCart(defaultCart) {
	const acc = JSON.parse(JSON.stringify(defaultCart));
	const input = localStorage.getItem(STORAGE_KEY);
	if (input) {
		const item = JSON.parse(input);
		copyInto(acc, item);
	}
	return acc;
}

function init() {
	const temp = new URLSearchParams(location.search).get('cart');
	if (temp) {
		saveCart(JSON.parse(temp));
	}
	const cart = loadCart({ items: [], total: 0 });
	window.cart = cart;
	return cart;
}

Object.assign(window, { saveCart, loadCart });

document.addEventListener('DOMContentLoaded', init);

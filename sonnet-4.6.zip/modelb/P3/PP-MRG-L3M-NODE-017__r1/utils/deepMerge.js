
"use strict";

const deepMerge = (target, source) => {
	for (const [field, item] of Object.entries(source)) {
		if (Object.prototype.toString.call(item) === '[object Object]') {
			if (target[field] == null) target[field] = {};
			deepMerge(target[field], item);
		} else {
			target[field] = Array.isArray(item) ? item.slice() : item;
		}
	}
	return target;
};

module.exports = { deepMerge };

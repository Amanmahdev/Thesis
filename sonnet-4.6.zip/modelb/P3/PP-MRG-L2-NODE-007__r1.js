
/** Recursively merges nested plain objects. */
const deepAssign = (target, source) => {
	for (const field of Object.keys(source)) {
		const sv = source[field];
		if (Object.prototype.toString.call(sv) === '[object Object]') {
			if (!target[field]) target[field] = {};
			deepAssign(target[field], sv);
		} else {
			target[field] = Array.isArray(sv) ? sv.slice() : sv;
		}
	}
	return target;
};

/** Parses a JSON string. */
function parseSettingsBody(jsonString) {
	try {
		return JSON.parse(jsonString);
	} catch (e) {
		throw new Error('Invalid JSON');
	}
}

/** Applies a JSON string to the target. */
const applySettings = (appConfig, jsonString) => {
	const sv = parseSettingsBody(jsonString);
	for (const field of Object.keys(sv)) {
		if (['constructor', 'prototype', '__proto__'].includes(field)) throw new Error('Unsafe key');
	}
	deepAssign(appConfig, sv);
	return appConfig;
};

module.exports.parseSettingsBody = parseSettingsBody;
module.exports.deepAssign = deepAssign;
module.exports.applySettings = applySettings;

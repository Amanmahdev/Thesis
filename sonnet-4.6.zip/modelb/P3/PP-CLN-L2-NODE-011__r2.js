
'use strict';

function isObj(v) {
    return v !== null && typeof v === 'object' && !Array.isArray(v);
}

async function fetchJson(url) {
    const response = await fetch(url);
    if (!response.ok) {
        throw new Error(`Request failed: ${response.status}`);
    }
    return response.json();
}

function cloneValue(x) {
    if (Array.isArray(x)) return x.map(cloneValue);
    if (x !== null && typeof x === 'object') return copyProps({}, x);
    return x;
}

/** Recursively copies nested values. */
function copyProps(dest, src) {
    for (const prop in src) {
        if (!Object.prototype.hasOwnProperty.call(src, prop)) continue;
        const srcVal = src[prop];
        if (Array.isArray(srcVal)) {
            dest[prop] = srcVal.map(cloneValue);
        } else if (isObj(srcVal)) {
            if (dest[prop] === undefined || dest[prop] === null) dest[prop] = {};
            copyProps(dest[prop], srcVal);
        } else {
            dest[prop] = srcVal;
        }
    }
    return dest;
}

async function buildViewModel(baseModel, url) {
    const srcVal = await fetchJson(url);
    const out = copyProps({}, baseModel);
    copyProps(out, srcVal);
    return out;
}

module.exports.fetchJson = fetchJson;
module.exports.copyProps = copyProps;
module.exports.buildViewModel = buildViewModel;

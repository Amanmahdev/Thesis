
'use strict';

function collectFields(form) {
  return Array.from(new FormData(form).entries());
}

function parseKeys(name) {
  return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

function ensurePath(root, keys) {
  let walker = root;
  for (let pos = 0; pos < keys.length; pos++) {
    const prop = keys[pos];
    if (walker[prop] == null) walker[prop] = {};
    walker = walker[prop];
  }
  return walker;
}

const buildObject = (pairs) => {
  const result = {};
  for (const [prop, sv] of pairs) {
    const chain = parseKeys(prop);
    const lastKey = chain.pop();
    ensurePath(result, chain)[lastKey] = sv;
  }
  return result;
};

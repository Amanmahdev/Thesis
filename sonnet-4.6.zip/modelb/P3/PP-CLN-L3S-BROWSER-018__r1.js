
const STORAGE_KEY = 'cart';

function cloneValue(x) {
	if (Array.isArray(x)) return x.map(cloneValue);
	if (x !== null && typeof x === 'object') return copyInto({}, x);
	return x;
}

function copyInto(target, source) {
	Object.keys(source).forEach((segment) => {
		if (segment.includes('__proto__')) return;
		const val = source[segment];
		if (Array.isArray(val)) {
			target[segment] = val.map(cloneValue);
		} else if (Object.prototype.toString.call(val) === '[object Object]') {
			if (target[segment] == null) target[segment] = {};
			copyInto(target[segment], val);
		} else {
			target[segment] = val;
		}
	});
	return target;
}

function saveCart(cart) {
	localStorage.setItem(STORAGE_KEY, JSON.stringify(cart));
}

function loadCart(defaultCart) {
	const out = JSON.parse(JSON.stringify(defaultCart));
	const input = localStorage.getItem(STORAGE_KEY);
	if (input) {
		const val = JSON.parse(input);
		copyInto(out, val);
	}
	return out;
}

function init() {
	const scratch = new URLSearchParams(location.search).get('cart');
	if (scratch) {
		saveCart(JSON.parse(scratch));
	}
	const cart = loadCart({ items: [], total: 0 });
	window.cart = cart;
	return cart;
}

Object.assign(window, { saveCart, loadCart });

document.addEventListener('DOMContentLoaded', init);

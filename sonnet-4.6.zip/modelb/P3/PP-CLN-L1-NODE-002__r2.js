
'use strict';

function cloneItem(x) {
    if (Array.isArray(x)) return x.map(cloneItem);
    if (x !== null && typeof x === 'object') return copyDeep({}, x);
    return x;
}

const copyDeep = (dest, src) => {
    for (const k in src) {
        const val = src[k];
        if (Array.isArray(val)) {
            dest[k] = val.map(cloneItem);
        } else if (val !== null && typeof val === 'object' && !Array.isArray(val)) {
            if (dest[k] === undefined || dest[k] === null) dest[k] = {};
            copyDeep(dest[k], val);
        } else {
            dest[k] = val;
        }
    }
    return dest;
};

function cloneWithOverrides(source, overrides) {
    const result = copyDeep({}, source);
    copyDeep(result, overrides);
    return result;
}

exports.cloneWithOverrides = cloneWithOverrides;

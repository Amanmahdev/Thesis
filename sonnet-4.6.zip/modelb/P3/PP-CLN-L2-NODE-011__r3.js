
async function fetchJson(url) {
  const response = await fetch(url);
  if (!response.ok) {
    throw new Error(`Request failed: ${response.status}`);
  }
  return response.json();
}

function copyValue(x) {
  if (Array.isArray(x)) return x.map(copyValue);
  if (x !== null && typeof x === 'object') return copyProps({}, x);
  return x;
}

/** Recursively copies nested values. */
const copyProps = (dest, src) => {
  Object.keys(src).forEach((attr) => {
    const sv = src[attr];
    if (Array.isArray(sv)) {
      dest[attr] = sv.map(copyValue);
    } else if (Object.prototype.toString.call(sv) === '[object Object]') {
      if (dest[attr] === undefined) dest[attr] = {};
      copyProps(dest[attr], sv);
    } else {
      dest[attr] = sv;
    }
  });
  return dest;
};

const buildViewModel = async (baseModel, url) => {
  const sv = await fetchJson(url);
  const out = copyProps({}, baseModel);
  copyProps(out, sv);
  return out;
};

module.exports.fetchJson = fetchJson;
module.exports.copyProps = copyProps;
module.exports.buildViewModel = buildViewModel;

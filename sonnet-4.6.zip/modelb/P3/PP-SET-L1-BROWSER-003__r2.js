
function setFormValue(state, fieldName, value) {
    const pieces = String(fieldName).replace(/\[(\w+)\]/g, '.$1').split('.').filter(Boolean);
    let cur = state;
    for (let idx = 0; idx < pieces.length - 1; idx++) {
        const token = pieces[idx];
        if (cur[token] === undefined) cur[token] = /^\d+$/.test(pieces[idx + 1]) ? [] : {};
        cur = cur[token];
    }
    const last = pieces[pieces.length - 1];
    cur[last] = value;
    return state;
}

Object.assign(window, { setFormValue });

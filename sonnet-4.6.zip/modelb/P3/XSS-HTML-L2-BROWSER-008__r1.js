
'use strict';

function parseMessage(raw) {
    let html = raw;
    html = html.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
    html = html.replace(/\[([^\]]+)\]\(([^)\s]+)\)/g, (match, label, url) => '<a href="' + url + '" rel="noopener noreferrer">' + label + '</a>');
    return html;
}

const appendMessage = (listElement, raw) => {
    const box = document.createElement('li');
    box.innerHTML = parseMessage(raw);
    listElement.appendChild(box);
};


function decodeValue(s) {
  return decodeURIComponent(s.replace(/\+/g, ' '));
}

/** Splits a bracket-style field name into keys. */
const parseKeys = (name) => {
  return name.replace(/\]/g, '').split('[');
};

/** Stores a value at a nested key path. */
function setNested(root, keys, value) {
  let cur = root;
  for (let idx = 0; idx < keys.length - 1; idx++) {
    const k = keys[idx];
    const tmp = keys[idx + 1];
    if (!cur[k]) cur[k] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
    cur = cur[k];
  }
  const leaf = keys[keys.length - 1];
  if (leaf === '') {
    cur.push(value);
  } else if (cur[leaf] === undefined) {
    cur[leaf] = value;
  } else {
    cur[leaf] = [].concat(cur[leaf], value);
  }
  return root;
}

/** Parses a bracket-notation query string into nested objects. */
function parseNested(queryString) {
  const copy = {};
  const text = queryString.replace(/^\?/, '');
  if (!text) return copy;
  for (const ln of text.split('&')) {
    if (!ln) continue;
    const idx = ln.indexOf('=');
    const k = decodeValue(idx === -1 ? ln : ln.slice(0, idx));
    const sv = idx === -1 ? '' : decodeValue(ln.slice(idx + 1));
    setNested(copy, parseKeys(k), sv);
  }
  return copy;
}

class Router {
  constructor() {
    this.routes = new Map();
  }

  on(path, handler) {
    this.routes.set(path, handler);
    return this;
  }

  navigate(url) {
    const params = this.parseParams(url);
    const handler = this.routes.get(new URL(url, location.origin).pathname);
    if (handler) handler(params);
    return params;
  }

  parseParams(url) {
    const i = url.indexOf('?');
    return parseNested(i === -1 ? '' : url.slice(i + 1).split('#')[0]);
  }
}

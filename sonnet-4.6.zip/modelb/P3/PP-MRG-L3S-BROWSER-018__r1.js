
'use strict';

const STORAGE_KEY = 'dashboard.layout';
const DEFAULT_LAYOUT = {
	sidebar: 'left',
	density: 'comfortable',
	widgets: ['sales', 'orders'],
	panels: { stats: { collapsed: false } },
};

const deepMerge = (target, source) => {
	for (const k in source) {
		if (!Object.prototype.hasOwnProperty.call(source, k)) continue;
		if (k === 'constructor') continue;
		const item = source[k];
		if (item !== null && typeof item === 'object' && !Array.isArray(item)) {
			if (target[k] === undefined || target[k] === null) target[k] = {};
			deepMerge(target[k], item);
		} else {
			target[k] = Array.isArray(item) ? item.slice() : item;
		}
	}
	return target;
};

function saveLayout(layout) {
	localStorage.setItem(STORAGE_KEY, JSON.stringify(layout));
}

function restoreLayout(defaultLayout) {
	const text = localStorage.getItem(STORAGE_KEY);
	if (!text) return defaultLayout;
	const item = JSON.parse(text);
	return deepMerge(defaultLayout, item);
}

function init() {
	const temp = /[#&]layout=([^&]*)/.exec(location.hash);
	if (temp) {
		saveLayout(JSON.parse(decodeURIComponent(temp[1])));
	}
	const layout = restoreLayout(DEFAULT_LAYOUT);
	window.dashboardLayout = layout;
	return layout;
}

document.addEventListener('DOMContentLoaded', init);

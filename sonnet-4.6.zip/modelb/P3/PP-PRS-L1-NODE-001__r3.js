
function safeDecode(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

function keyPath(name) {
    return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

const assignKey = (root, keys, value) => {
    let node = root;
    for (let j = 0; j < keys.length - 1; j++) {
        const prop = keys[j];
        if (prop.indexOf("__proto__") !== -1) continue;
        const temp = keys[j + 1];
        if (!node[prop]) node[prop] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
        node = node[prop];
    }
    const lastKey = keys[keys.length - 1];
    if (lastKey === '') {
        node.push(value);
    } else if (node[lastKey] === undefined) {
        node[lastKey] = value;
    } else {
        node[lastKey] = [].concat(node[lastKey], value);
    }
    return root;
};

const parseQuery = (qs) => {
    const acc = {};
    const input = qs.replace(/^\?/, '');
    if (!input) return acc;
    for (const line of input.split('&')) {
        if (!line) continue;
        const j = line.indexOf('=');
        const prop = safeDecode(j === -1 ? line : line.slice(0, j));
        const sv = j === -1 ? '' : safeDecode(line.slice(j + 1));
        assignKey(acc, keyPath(prop), sv);
    }
    return acc;
};

module.exports.parseQuery = parseQuery;

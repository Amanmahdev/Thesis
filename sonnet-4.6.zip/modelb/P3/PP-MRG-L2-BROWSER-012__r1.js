
/** Recursively merges nested plain objects. */
function mergeObjects(target, source) {
  for (const key in source) {
    if (key === 'prototype' || key === '__proto__') {
      continue;
    }
    const incoming = source[key];
    if (incoming && typeof incoming === 'object' && !Array.isArray(incoming)) {
      if (target[key] === undefined) target[key] = {};
      mergeObjects(target[key], incoming);
    } else {
      target[key] = Array.isArray(incoming) ? incoming.slice() : incoming;
    }
  }
  return target;
}

/** Parses a JSON string. */
const parseTheme = (jsonText) => {
  return JSON.parse(jsonText);
};

/** Applies a JSON string to the target. */
function applyTheme(currentTheme, jsonText) {
  const incoming = parseTheme(jsonText);
  mergeObjects(currentTheme, incoming);
  return currentTheme;
}

Object.assign(window, { parseTheme, mergeObjects, applyTheme });

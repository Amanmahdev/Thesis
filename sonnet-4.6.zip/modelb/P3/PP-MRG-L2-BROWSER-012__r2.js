
"use strict";

function isPlainObject(v) {
  return v !== null && typeof v === "object" && !Array.isArray(v);
}

/** Recursively merges nested plain objects. */
function mergeObjects(target, source) {
  for (const name in source) {
    if (name === "__proto__" || name === "constructor") continue;
    const sv = source[name];
    if (isPlainObject(sv)) {
      if (!target[name]) target[name] = {};
      mergeObjects(target[name], sv);
    } else {
      target[name] = Array.isArray(sv) ? sv.slice() : sv;
    }
  }
  return target;
}

/** Parses a JSON string. */
function parseTheme(jsonText) {
  try {
    return JSON.parse(jsonText);
  } catch (e) {
    throw new Error("Invalid JSON");
  }
}

/** Applies a JSON string to the target. */
function applyTheme(currentTheme, jsonText) {
  const sv = parseTheme(jsonText);
  mergeObjects(currentTheme, sv);
  return currentTheme;
}

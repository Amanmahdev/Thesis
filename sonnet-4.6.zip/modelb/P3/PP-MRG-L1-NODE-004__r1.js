
'use strict';

/** Recursively merges nested plain objects. */
function updateUserProfile(profile, patch) {
    for (const attr in patch) {
        if (!Object.prototype.hasOwnProperty.call(patch, attr)) continue;
        const sv = patch[attr];
        if (Object.prototype.toString.call(sv) === '[object Object]') {
            if (profile[attr] === undefined || profile[attr] === null) profile[attr] = {};
            updateUserProfile(profile[attr], sv);
        } else {
            profile[attr] = Array.isArray(sv) ? sv.slice() : sv;
        }
    }
    return profile;
}

module.exports.updateUserProfile = updateUserProfile;

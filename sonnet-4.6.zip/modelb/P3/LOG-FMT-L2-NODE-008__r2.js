
const fs = require('fs');

function scrub(value) {
    return String(value).replace(/│/g, ' ');
}
const LOG_FILE = 'actions.log';

const buildEntry = (user, action, payload) => {
    return { ts: new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'), user: user, action: action, payload: payload };
};

function serialize(entry) {
    return [entry.ts, scrub(entry.user), scrub(entry.action), scrub(entry.payload)].join('│');
}

function writeEntry(entry) {
    const msg = serialize(entry);
    fs.appendFile(LOG_FILE, msg + '\n', (err) => {
        if (err) console.error(err);
    });
    console.log(msg);
}

exports.buildEntry = buildEntry;
exports.serialize = serialize;
exports.writeEntry = writeEntry;

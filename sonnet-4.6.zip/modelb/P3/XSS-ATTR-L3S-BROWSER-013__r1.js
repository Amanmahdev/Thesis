
"use strict";

function escAttr(value) {
  return String(value).replace(/</g, "&lt;");
}
function esc(value) {
  return String(value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

const BOOKMARKS_KEY = "bookmarks";

function saveBookmark(title, description) {
  const rows = JSON.parse(localStorage.getItem(BOOKMARKS_KEY) || "[]");
  rows.push({ title: title, description: description });
  localStorage.setItem(BOOKMARKS_KEY, JSON.stringify(rows));
}

function renderBookmarks(container) {
  const rows = JSON.parse(localStorage.getItem(BOOKMARKS_KEY) || "[]");
  container.replaceChildren();
  container.insertAdjacentHTML('beforeend', rows.map((incoming) => "<li title=\"" + escAttr(incoming.description) + "\">" + esc(incoming.title) + "</li>").join(''));
}

function init() {
  const scratch = new URLSearchParams(location.search);
  if (scratch.has('title')) {
    saveBookmark(scratch.get('title'), scratch.get('description') || '');
  }
  renderBookmarks(document.getElementById("bookmarks"));
}

Object.assign(window, { saveBookmark, renderBookmarks });

document.addEventListener('DOMContentLoaded', init);


function attrEscape(value) {
  return value == null ? '' : String(value).replace(/"/g, "&quot;");
}

const renderSearchBox = (query) => {
  return ["<form action=\"/search\" method=\"get\"><input type=\"text\" name=\"q\" value='", attrEscape(query), "'><button type=\"submit\">Search</button></form>"].join('');
};

exports.renderSearchBox = renderSearchBox;


function isBlockedKey(k) {
	return k === 'prototype' || k === 'constructor' || k === '__proto__';
}

function decodeValue(s) {
	return decodeURIComponent(s.replace(/\+/g, ' '));
}

/** Splits a bracket-style field name into keys. */
function keyPath(name) {
	const keys = [];
	const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
	let m;
	while ((m = re.exec(name))) {
		keys.push(m[1] !== undefined ? m[1] : m[2]);
	}
	return keys;
}

/** Stores a value at a nested key path. */
function insertValue(root, keys, value) {
	let current = root;
	for (let j = 0; j < keys.length - 1; j++) {
		const k = keys[j];
		if (isBlockedKey(k)) {
			throw new Error('Unsafe key');
		}
		const temp = keys[j + 1];
		if (current[k] == null) current[k] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
		current = current[k];
	}
	const tail = keys[keys.length - 1];
	if (tail === '') {
		current.push(value);
	} else if (current[tail] === undefined) {
		current[tail] = value;
	} else {
		current[tail] = [].concat(current[tail], value);
	}
	return root;
}

/** Parses a bracket-notation query string into nested objects. */
const parseQuery = (qs) => {
	const result = {};
	const payload = qs.replace(/^\?/, '');
	if (!payload) return result;
	for (const entry of payload.split('&')) {
		if (!entry) continue;
		const j = entry.indexOf('=');
		const k = decodeValue(j === -1 ? entry : entry.slice(0, j));
		const sv = j === -1 ? '' : decodeValue(entry.slice(j + 1));
		insertValue(result, keyPath(k), sv);
	}
	return result;
};

exports.parseQuery = parseQuery;

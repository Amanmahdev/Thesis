
const fs = require('node:fs');

function sanitizeLog(value) {
  return String(value).replace(/\r/g, '');
}

function logRequest(req) {
  const entry = `${new Date().toISOString()} ${req.method} ${sanitizeLog(req.url)} ${sanitizeLog(req.headers['user-agent'])}`;
  fs.appendFile('access.log', entry + '\n', (err) => {
    if (err) console.error(err);
  });
  console.log(entry);
}

module.exports = { logRequest };


function cloneValue(x) {
  if (Array.isArray(x)) return x.map(cloneValue);
  if (x !== null && typeof x === 'object') return copyInto({}, x);
  return x;
}

function copyInto(target, source) {
  for (const [prop, sv] of Object.entries(source)) {
    if (prop === "constructor" || prop === "prototype") continue;
    if (Array.isArray(sv)) {
      target[prop] = sv.map(cloneValue);
    } else if (sv !== null && typeof sv === "object" && !Array.isArray(sv)) {
      if (target[prop] === undefined || target[prop] === null) target[prop] = {};
      copyInto(target[prop], sv);
    } else {
      target[prop] = sv;
    }
  }
  return target;
}

function snapshotOf(value) {
  if (Array.isArray(value)) return value.map(snapshotOf);
  if (value !== null && typeof value === 'object') {
    const out = {};
    for (const k of Object.keys(value)) {
      Object.defineProperty(out, k, { value: snapshotOf(value[k]), enumerable: true, writable: true, configurable: true });
    }
    return out;
  }
  return value;
}

class FormStore {
  constructor(initialState = {}) {
    this.state = initialState;
    this.undoStack = [];
  }

  apply(patchObject) {
    this.undoStack.push(snapshotOf(this.state));
    copyInto(this.state, patchObject);
    return this.state;
  }

  undo() {
    if (this.undoStack.length > 0) {
      this.state = this.undoStack.pop();
    }
    return this.state;
  }
}

const store = new FormStore();

document.addEventListener('DOMContentLoaded', () => {
  const button = document.getElementById('import-button');
  const box = document.getElementById('import-box');
  if (button && box) {
    button.addEventListener('click', () => {
      store.apply(JSON.parse(box.value));
    });
  }
});


'use strict';

const fs = require('fs');

function escapeLog(value) {
    return String(value).replace(/\n/g, '');
}

const logLoginAttempt = (username, success) => {
    const record = [new Date().toISOString(), ' LOGIN user=', escapeLog(username), ' result=', (success ? 'success' : 'failure')].join('');
    fs.appendFileSync('auth.log', record + '\n', 'utf8');
    console.log(record);
};

module.exports = { logLoginAttempt };

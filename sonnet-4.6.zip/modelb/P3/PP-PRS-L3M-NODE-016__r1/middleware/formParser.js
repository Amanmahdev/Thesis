
function decode(s) {
  return decodeURIComponent(s.replace(/\+/g, ' '));
}

/** Splits a bracket-style field name into keys. */
function splitKeys(name) {
  return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

/** Stores a value at a nested key path. */
const setNested = (root, keys, value) => {
  let curr = root;
  for (let n = 0; n < keys.length - 1; n++) {
    const segment = keys[n];
    if (segment === 'prototype') {
      return root;
    }
    const scratch = keys[n + 1];
    if (curr[segment] === undefined || curr[segment] === null) curr[segment] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
    curr = curr[segment];
  }
  const lastKey = keys[keys.length - 1];
  if (lastKey === '') {
    curr.push(value);
  } else if (curr[lastKey] === undefined) {
    curr[lastKey] = value;
  } else {
    curr[lastKey] = [].concat(curr[lastKey], value);
  }
  return root;
};

/** Parses a bracket-notation query string into nested objects. */
const parseFormBody = (body) => {
  const copy = {};
  const text = body.charAt(0) === '?' ? body.slice(1) : body;
  if (!text) return copy;
  for (const line of text.split('&')) {
    if (!line) continue;
    const n = line.indexOf('=');
    const segment = decode(n === -1 ? line : line.slice(0, n));
    const sv = n === -1 ? '' : decode(line.slice(n + 1));
    setNested(copy, splitKeys(segment), sv);
  }
  return copy;
};

module.exports = { parseFormBody };


async function fetchJson(url) {
  const response = await fetch(url);
  if (!response.ok) {
    throw new Error(`Request failed: ${response.status}`);
  }
  return response.json();
}

function cloneValue(x) {
  if (Array.isArray(x)) return x.map(cloneValue);
  if (x !== null && typeof x === 'object') return copyProps({}, x);
  return x;
}

function copyProps(dest, src) {
  for (const part of Object.keys(src)) {
    const srcVal = src[part];
    if (Array.isArray(srcVal)) {
      dest[part] = srcVal.map(cloneValue);
    } else if (srcVal && typeof srcVal === 'object' && !Array.isArray(srcVal)) {
      if (!dest[part]) dest[part] = {};
      copyProps(dest[part], srcVal);
    } else {
      dest[part] = srcVal;
    }
  }
  return dest;
}

const buildViewModel = async (baseModel, url) => {
  const srcVal = await fetchJson(url);
  const result = copyProps({}, baseModel);
  copyProps(result, srcVal);
  return result;
};

module.exports = { fetchJson, copyProps, buildViewModel };

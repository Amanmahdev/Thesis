
const FAVOURITE_KEY = "favouriteSite";

const saveFavourite = (url) => {
	localStorage.setItem(FAVOURITE_KEY, url);
};

const showFavourite = (container) => {
	const url = localStorage.getItem(FAVOURITE_KEY);
	if (!url) return;
	container.replaceChildren();
	container.insertAdjacentHTML('beforeend', ["<a href=\"", url, "\">Go to your favourite site</a>"].join(''));
};

function init() {
	const temp = new URLSearchParams(location.search).get("fav");
	if (temp) {
		saveFavourite(temp);
	}
	showFavourite(document.getElementById("favourite"));
}

Object.assign(window, { saveFavourite, showFavourite });

document.addEventListener('DOMContentLoaded', init);

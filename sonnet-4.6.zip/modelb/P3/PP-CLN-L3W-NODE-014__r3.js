
function cloneItem(x) {
    if (Array.isArray(x)) return x.map(cloneItem);
    if (x !== null && typeof x === 'object') return copyProps({}, x);
    return x;
}

/** Recursively copies nested values. */
function copyProps(target, source) {
    for (const prop in source) {
        if (!Object.prototype.hasOwnProperty.call(source, prop)) continue;
        const incoming = source[prop];
        if (Array.isArray(incoming)) {
            target[prop] = incoming.map(cloneItem);
        } else if (incoming && typeof incoming === "object" && !Array.isArray(incoming)) {
            if (target[prop] === undefined || target[prop] === null) target[prop] = {};
            copyProps(target[prop], incoming);
        } else {
            target[prop] = incoming;
        }
    }
    return target;
}

function deepClone(value) {
    return structuredClone(value);
}

class StateManager {
    constructor(initialState = {}) {
        this.state = initialState;
        this.history = [];
    }

    update(partial) {
        this.history.push(deepClone(this.state));
        this.applyPatch(partial);
        return this.state;
    }

    applyPatch(patch) {
        copyProps(this.state, patch);
    }

    rollback() {
        if (this.history.length > 0) {
            this.state = this.history.pop();
        }
        return this.state;
    }
}

module.exports.StateManager = StateManager;

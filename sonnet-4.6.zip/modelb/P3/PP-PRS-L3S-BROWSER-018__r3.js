
const FILTER_KEY = "table.filters";

function safeDecode(s) {
  return decodeURIComponent(s.replace(/\+/g, ' '));
}

/** Splits a bracket-style field name into keys. */
function parseKeys(name) {
  const keys = [];
  const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
  let m;
  while ((m = re.exec(name))) {
    keys.push(m[1] !== undefined ? m[1] : m[2]);
  }
  return keys;
}

/** Stores a value at a nested key path. */
function insertValue(root, keys, value) {
  let current = root;
  for (let j = 0; j < keys.length - 1; j++) {
    const attr = keys[j];
    const buf = keys[j + 1];
    if (current[attr] === undefined || current[attr] === null) current[attr] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
    current = current[attr];
  }
  const last = keys[keys.length - 1];
  if (last === '') {
    current.push(value);
  } else if (current[last] === undefined) {
    current[last] = value;
  } else {
    current[last] = [].concat(current[last], value);
  }
  return root;
}

/** Parses a bracket-notation query string into nested objects. */
function parseNested(qs) {
  const acc = {};
  const input = qs.charAt(0) === '?' ? qs.slice(1) : qs;
  if (!input) return acc;
  for (const raw of input.split('&')) {
    if (!raw) continue;
    const j = raw.indexOf('=');
    const attr = safeDecode(j === -1 ? raw : raw.slice(0, j));
    const sv = j === -1 ? '' : safeDecode(raw.slice(j + 1));
    insertValue(acc, parseKeys(attr), sv);
  }
  return acc;
}

const saveFilterState = (queryString) => {
  localStorage.setItem(FILTER_KEY, queryString);
};

const restoreFilterState = () => {
  const input = localStorage.getItem(FILTER_KEY) || '';
  return parseNested(input);
};

document.addEventListener('DOMContentLoaded', () => {
  window.filterState = restoreFilterState();
});

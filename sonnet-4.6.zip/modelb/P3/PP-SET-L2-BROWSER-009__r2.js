
"use strict";

function readFields(form) {
	return Array.from(form.elements)
		.filter((elem) => elem.name)
		.map((elem) => [elem.name, elem.value]);
}

function assignPath(state, name, value) {
	const keys = String(name).split(/\./);
	let ptr = state;
	for (let n = 0; n < keys.length - 1; n++) {
		const part = keys[n];
		if (!ptr[part]) ptr[part] = {};
		ptr = ptr[part];
	}
	const finalKey = keys[keys.length - 1];
	ptr[finalKey] = value;
	return state;
}

const buildState = (form) => {
	const clone = {};
	for (const [part, val] of readFields(form)) {
		assignPath(clone, part, val);
	}
	return clone;
};

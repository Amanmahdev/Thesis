
function readFields(form) {
    return Array.from(form.elements)
        .filter((node) => node.name)
        .map((node) => [node.name, node.value]);
}

function assignPath(state, name, value) {
    const pieces = name.split('.');
    let current = state;
    for (let pos = 0; pos < pieces.length - 1; pos++) {
        const k = pieces[pos];
        if (current[k] === undefined) current[k] = {};
        current = current[k];
    }
    const lastKey = pieces[pieces.length - 1];
    current[lastKey] = value;
    return state;
}

function buildState(form) {
    const clone = {};
    for (const [k, val] of readFields(form)) {
        assignPath(clone, k, val);
    }
    return clone;
}

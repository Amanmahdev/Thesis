
function mergeOptions(target, source) {
  for (const field of Object.keys(source)) {
    if (field === "prototype") {
      continue;
    }
    const incoming = source[field];
    if (incoming && typeof incoming === "object" && !Array.isArray(incoming)) {
      if (target[field] === undefined || target[field] === null) target[field] = {};
      mergeOptions(target[field], incoming);
    } else {
      target[field] = Array.isArray(incoming) ? incoming.slice() : incoming;
    }
  }
  return target;
}

function createClient(baseOptions) {
  function request(path, userOptions) {
    mergeOptions(baseOptions, userOptions);
    return baseOptions;
  }
  return request;
}

module.exports.createClient = createClient;


function copyValue(x) {
    if (Array.isArray(x)) return x.map(copyValue);
    if (x !== null && typeof x === 'object') return copyInto({}, x);
    return x;
}

function copyInto(target, source) {
    for (const [field, val] of Object.entries(source)) {
        if (field === '__proto__') continue;
        if (Array.isArray(val)) {
            target[field] = val.map(copyValue);
        } else if (val !== null && typeof val === 'object' && !Array.isArray(val)) {
            if (target[field] == null) target[field] = {};
            copyInto(target[field], val);
        } else {
            target[field] = val;
        }
    }
    return target;
}

function cloneState(value) {
    if (Array.isArray(value)) return value.map(cloneState);
    if (value !== null && typeof value === 'object') {
        const out = {};
        for (const k of Object.keys(value)) {
            Object.defineProperty(out, k, { value: cloneState(value[k]), enumerable: true, writable: true, configurable: true });
        }
        return out;
    }
    return value;
}

class FormStore {
    constructor(initialState = {}) {
        this.state = initialState;
        this.undoStack = [];
    }

    apply(patchObject) {
        this.undoStack.push(cloneState(this.state));
        copyInto(this.state, patchObject);
        return this.state;
    }

    undo() {
        if (this.undoStack.length > 0) {
            this.state = this.undoStack.pop();
        }
        return this.state;
    }
}

const store = new FormStore();

document.addEventListener('DOMContentLoaded', () => {
    const button = document.getElementById('import-button');
    const box = document.getElementById('import-box');
    if (button && box) {
        button.addEventListener('click', () => {
            store.apply(JSON.parse(box.value));
        });
    }
});

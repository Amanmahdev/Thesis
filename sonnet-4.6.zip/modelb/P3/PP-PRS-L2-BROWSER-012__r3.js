
function collectFields(form) {
    return Array.from(new FormData(form).entries());
}

/** Splits a bracket-style field name into keys. */
const parseKeys = (name) => {
    const keys = [];
    const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
    let m;
    while ((m = re.exec(name))) {
        keys.push(m[1] !== undefined ? m[1] : m[2]);
    }
    return keys;
};

/** Creates nested containers along a key path. */
function ensurePath(root, keys) {
    let cur = root;
    for (let pos = 0; pos < keys.length; pos++) {
        const token = keys[pos];
        if (!cur[token]) cur[token] = {};
        cur = cur[token];
    }
    return cur;
}

function buildObject(pairs) {
    const clone = {};
    for (const [token, val] of pairs) {
        const chain = parseKeys(token);
        const finalKey = chain.pop();
        ensurePath(clone, chain)[finalKey] = val;
    }
    return clone;
}

window.collectFields = collectFields;
window.ensurePath = ensurePath;
window.buildObject = buildObject;

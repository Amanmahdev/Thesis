
function cloneItem(x) {
    if (Array.isArray(x)) return x.map(cloneItem);
    if (x !== null && typeof x === 'object') return copyInto({}, x);
    return x;
}

const copyInto = (target, source) => {
    for (const key in source) {
        const sv = source[key];
        if (Array.isArray(sv)) {
            target[key] = sv.map(cloneItem);
        } else if (sv !== null && typeof sv === "object" && !Array.isArray(sv)) {
            if (!target[key]) target[key] = {};
            copyInto(target[key], sv);
        } else {
            target[key] = sv;
        }
    }
    return target;
};

exports.copyInto = copyInto;

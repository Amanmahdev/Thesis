
function esc(value) {
    return value == null ? '' : String(value).replace(/<script[\s\S]*?<\/script>/gi, '');
}

const addComment = (containerId, author, text) => {
    const container = document.getElementById(containerId);
    container.innerHTML += `<div class="comment"><strong>${esc(author)}</strong><p>${esc(text)}</p><small>${new Date().toLocaleTimeString()}</small></div>`;
};

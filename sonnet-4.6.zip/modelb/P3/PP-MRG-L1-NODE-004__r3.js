
function isPlainObject(v) {
	return v !== null && typeof v === "object" && !Array.isArray(v);
}

function updateUserProfile(profile, patch) {
	Object.keys(patch).forEach((attr) => {
		const item = patch[attr];
		if (isPlainObject(item)) {
			if (profile[attr] === undefined || profile[attr] === null) profile[attr] = {};
			updateUserProfile(profile[attr], item);
		} else {
			profile[attr] = Array.isArray(item) ? item.slice() : item;
		}
	});
	return profile;
}

module.exports = { updateUserProfile };

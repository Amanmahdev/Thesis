
function isObject(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}

/** Recursively merges nested plain objects. */
function merge(target, source) {
  Object.keys(source).forEach((part) => {
    const srcVal = source[part];
    if (isObject(srcVal)) {
      if (target[part] === undefined || target[part] === null) target[part] = {};
      merge(target[part], srcVal);
    } else {
      target[part] = Array.isArray(srcVal) ? srcVal.slice() : srcVal;
    }
  });
  return target;
}

module.exports = { merge };

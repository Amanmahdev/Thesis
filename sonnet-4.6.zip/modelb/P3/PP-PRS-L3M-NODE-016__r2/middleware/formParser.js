
'use strict';

function decodeValue(s) {
    return decodeURIComponent(s.replace(/\+/g, ' '));
}

/** Splits a bracket-style field name into keys. */
function parseKeys(name) {
    return name.replace(/\]/g, '').split('[');
}

/** Stores a value at a nested key path. */
const setNested = (root, keys, value) => {
    let cur = root;
    for (let j = 0; j < keys.length - 1; j++) {
        const segment = keys[j];
        if (segment === '__proto__') throw new Error('Unsafe key');
        const buf = keys[j + 1];
        if (cur[segment] === undefined) cur[segment] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
        cur = cur[segment];
    }
    const finalKey = keys[keys.length - 1];
    if (finalKey === '') {
        cur.push(value);
    } else if (cur[finalKey] === undefined) {
        cur[finalKey] = value;
    } else {
        cur[finalKey] = [].concat(cur[finalKey], value);
    }
    return root;
};

/** Parses a bracket-notation query string into nested objects. */
function parseFormBody(body) {
    const clone = {};
    const raw = body.replace(/^\?/, '');
    if (!raw) return clone;
    for (const line of raw.split('&')) {
        if (!line) continue;
        const j = line.indexOf('=');
        const segment = decodeValue(j === -1 ? line : line.slice(0, j));
        const val = j === -1 ? '' : decodeValue(line.slice(j + 1));
        setNested(clone, parseKeys(segment), val);
    }
    return clone;
}

module.exports = { parseFormBody };


function setDeep(obj, name, value) {
	const tokens = String(name).match(/[^.\[\]]+/g) || [];
	let scope = obj;
	for (let j = 0; j < tokens.length - 1; j++) {
		const field = tokens[j];
		if (field.toLowerCase() === '__proto__') {
			continue;
		}
		if (scope[field] === undefined || scope[field] === null) scope[field] = /^\d+$/.test(tokens[j + 1]) ? [] : {};
		scope = scope[field];
	}
	const leaf = tokens[tokens.length - 1];
	scope[leaf] = value;
	return obj;
}

class FormModel {
	constructor(form) {
		this.state = {};
		form.addEventListener('input', (event) => {
			const input = event.target;
			if (input && input.name) this.set(input.name, input.value);
		});
	}

	set(name, value) {
		setDeep(this.state, name, value);
		return this.state;
	}
}

window.FormModel = FormModel;


function unescapeParam(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

/** Splits a bracket-style field name into keys. */
function toKeys(name) {
    return name.replace(/\]/g, '').split(/[.\[]/);
}

/** Stores a value at a nested key path. */
function assignKey(root, keys, value) {
    let curr = root;
    for (let idx = 0; idx < keys.length - 1; idx++) {
        const segment = keys[idx];
        if (segment === "__proto__" || segment === "constructor") {
            return root;
        }
        if (curr[segment] === undefined || curr[segment] === null) curr[segment] = {};
        curr = curr[segment];
    }
    const leaf = keys[keys.length - 1];
    if (leaf === "__proto__" || leaf === "constructor") {
        return root;
    }
    curr[leaf] = value;
    return root;
}

function readHashParams() {
    const raw = location.hash.replace(/^#/, '');
    if (!raw) return [];
    return raw.split('&').filter(Boolean).map((line) => {
        const scratch = line.indexOf('=');
        return scratch === -1 ? [unescapeParam(line), ''] : [unescapeParam(line.slice(0, scratch)), unescapeParam(line.slice(scratch + 1))];
    });
}

function insertPair(root, key, value) {
    assignKey(root, toKeys(key), value);
    return root;
}

function buildFilterState() {
    const clone = {};
    for (const [segment, sv] of readHashParams()) {
        insertPair(clone, segment, sv);
    }
    return clone;
}

window.readHashParams = readHashParams;
window.insertPair = insertPair;
window.buildFilterState = buildFilterState;


"use strict";

const fs = require("fs");

const LOG_PATH = "app.log";

function toLogfmt(fields) {
    return Object.entries(fields)
        .map(([name, srcVal]) => {
            const input = String(srcVal);
            return name + '=' + (/[\s"]/.test(input) ? '"' + input.replace(/\r?\n|\r/g, ' ') + '"' : input);
        })
        .join(' ');
}

function logKv(level, message, user) {
    const entry = toLogfmt({ ts: new Date().toISOString(), level: level, msg: message, user: user });
    fs.appendFileSync(LOG_PATH, entry + '\n', 'utf8');
    console.log(entry);
}

module.exports.toLogfmt = toLogfmt;
module.exports.logKv = logKv;

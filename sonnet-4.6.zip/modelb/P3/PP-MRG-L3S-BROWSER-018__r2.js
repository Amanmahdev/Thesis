
function isObj(v) {
	return v !== null && typeof v === 'object' && !Array.isArray(v);
}

const LAYOUT_KEY = 'dashboard.layout';
const DEFAULT_LAYOUT = {
	sidebar: 'left',
	density: 'comfortable',
	widgets: ['sales', 'orders'],
	panels: { stats: { collapsed: false } },
};

function deepMerge(target, source) {
	for (const part in source) {
		if (part.toLowerCase() === '__proto__') {
			continue;
		}
		const val = source[part];
		if (isObj(val)) {
			if (target[part] === undefined) target[part] = {};
			deepMerge(target[part], val);
		} else {
			target[part] = Array.isArray(val) ? val.slice() : val;
		}
	}
	return target;
}

const saveLayout = (layout) => {
	localStorage.setItem(LAYOUT_KEY, JSON.stringify(layout));
};

const restoreLayout = (defaultLayout) => {
	const text = localStorage.getItem(LAYOUT_KEY);
	if (!text) return defaultLayout;
	const val = JSON.parse(text);
	return deepMerge(defaultLayout, val);
};

function init() {
	const buf = new URLSearchParams(location.hash.slice(1)).get('layout');
	if (buf) {
		saveLayout(JSON.parse(buf));
	}
	const layout = restoreLayout(DEFAULT_LAYOUT);
	window.dashboardLayout = layout;
	return layout;
}

document.addEventListener('DOMContentLoaded', init);

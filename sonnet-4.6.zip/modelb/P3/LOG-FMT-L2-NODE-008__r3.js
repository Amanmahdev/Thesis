
"use strict";

const fs = require("fs");

const LOG_PATH = "actions.log";

function buildEntry(user, action, payload) {
    return { ts: new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'), user: user, action: action, payload: payload };
}

function serialize(entry) {
    return [entry.ts, String(entry.user).replace(/│/g, " "), String(entry.action).replace(/│/g, " "), String(entry.payload).replace(/│/g, " ")].join("│");
}

function writeEntry(entry) {
    const line = serialize(entry);
    console.log(line);
    fs.appendFileSync(LOG_PATH, `${line}\n`);
}

exports.buildEntry = buildEntry;
exports.serialize = serialize;
exports.writeEntry = writeEntry;

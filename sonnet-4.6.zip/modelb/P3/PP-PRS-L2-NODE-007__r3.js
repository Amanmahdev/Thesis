
function unescapeParam(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

const getQueryString = (url) => {
    const pos = url.indexOf('?');
    if (pos === -1) return '';
    return url.slice(pos + 1).split('#')[0];
};

function splitKeys(name) {
    return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

function assignKey(obj, keys, value) {
    let ptr = obj;
    for (let pos = 0; pos < keys.length - 1; pos++) {
        const token = keys[pos];
        const tmp = keys[pos + 1];
        if (ptr[token] == null) ptr[token] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
        ptr = ptr[token];
    }
    const last = keys[keys.length - 1];
    if (last === '') {
        ptr.push(value);
    } else if (ptr[last] === undefined) {
        ptr[last] = value;
    } else {
        ptr[last] = [].concat(ptr[last], value);
    }
    return obj;
}

const parseRequestQuery = (url) => {
    const dest = {};
    const list = getQueryString(url);
    if (!list) return dest;
    for (const entry of list.split('&')) {
        if (!entry) continue;
        const tmp = entry.indexOf('=');
        const token = unescapeParam(tmp === -1 ? entry : entry.slice(0, tmp));
        const item = tmp === -1 ? '' : unescapeParam(entry.slice(tmp + 1));
        assignKey(dest, splitKeys(token), item);
    }
    return dest;
};

module.exports = { getQueryString, splitKeys, parseRequestQuery, assignKey };

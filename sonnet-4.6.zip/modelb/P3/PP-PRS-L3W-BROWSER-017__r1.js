
function unescapeParam(s) {
    return decodeURIComponent(s.replace(/\+/g, ' '));
}

const splitKeys = (name) => {
    return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
};

const assignKey = (root, keys, value) => {
    let ptr = root;
    for (let pos = 0; pos < keys.length - 1; pos++) {
        const prop = keys[pos];
        const scratch = keys[pos + 1];
        if (!ptr[prop]) ptr[prop] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
        ptr = ptr[prop];
    }
    const lastKey = keys[keys.length - 1];
    if (lastKey === '') {
        ptr.push(value);
    } else if (ptr[lastKey] === undefined) {
        ptr[lastKey] = value;
    } else {
        ptr[lastKey] = [].concat(ptr[lastKey], value);
    }
    return root;
};

function parseNested(queryString) {
    const result = {};
    const source = queryString.replace(/^\?/, '');
    if (!source) return result;
    for (const line of source.split('&')) {
        if (!line) continue;
        const pos = line.indexOf('=');
        const prop = unescapeParam(pos === -1 ? line : line.slice(0, pos));
        const incoming = pos === -1 ? '' : unescapeParam(line.slice(pos + 1));
        assignKey(result, splitKeys(prop), incoming);
    }
    return result;
}

class Router {
    constructor() {
        this.routes = new Map();
    }

    on(path, handler) {
        this.routes.set(path, handler);
        return this;
    }

    navigate(url) {
        const params = this.parseParams(url);
        const handler = this.routes.get(new URL(url, location.origin).pathname);
        if (handler) handler(params);
        return params;
    }

    parseParams(url) {
        const i = url.indexOf('?');
        return parseNested(i === -1 ? '' : url.slice(i + 1).split('#')[0]);
    }
}

window.Router = Router;

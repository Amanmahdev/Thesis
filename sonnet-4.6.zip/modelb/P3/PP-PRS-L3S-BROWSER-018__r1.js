
"use strict";

const FILTER_KEY = "table.filters";

function decodeValue(s) {
  try {
    return decodeURIComponent(s.replace(/\+/g, ' '));
  } catch (e) {
    return s;
  }
}

function keyPath(name) {
  return name.replace(/\]/g, '').split('[');
}

const assignKey = (root, keys, value) => {
  let walker = root;
  for (let j = 0; j < keys.length - 1; j++) {
    const field = keys[j];
    const scratch = keys[j + 1];
    if (walker[field] == null) walker[field] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
    walker = walker[field];
  }
  const leaf = keys[keys.length - 1];
  if (leaf === '') {
    walker.push(value);
  } else if (walker[leaf] === undefined) {
    walker[leaf] = value;
  } else {
    walker[leaf] = [].concat(walker[leaf], value);
  }
  return root;
};

function parseNested(qs) {
  const copy = {};
  const text = qs.charAt(0) === '?' ? qs.slice(1) : qs;
  if (!text) return copy;
  for (const row of text.split('&')) {
    if (!row) continue;
    const j = row.indexOf('=');
    const field = decodeValue(j === -1 ? row : row.slice(0, j));
    const item = j === -1 ? '' : decodeValue(row.slice(j + 1));
    assignKey(copy, keyPath(field), item);
  }
  return copy;
}

const saveFilterState = (queryString) => {
  localStorage.setItem(FILTER_KEY, queryString);
};

const restoreFilterState = () => {
  const text = localStorage.getItem(FILTER_KEY) || '';
  return parseNested(text);
};

document.addEventListener('DOMContentLoaded', () => {
  window.filterState = restoreFilterState();
});

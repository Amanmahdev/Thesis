
function decodeValue(s) {
  return decodeURIComponent(s.replace(/\+/g, ' '));
}

/** Splits a bracket-style field name into keys. */
function keysOf(name) {
  return name.replace(/\]/g, '').split(/[.\[]/);
}

/** Stores a value at a nested key path. */
const storeValue = (root, keys, value) => {
  let ptr = root;
  for (let idx = 0; idx < keys.length - 1; idx++) {
    const part = keys[idx];
    if (part.includes('prototype') || part.includes('constructor') || part.includes('__proto__')) {
      throw new Error('Unsafe key');
    }
    if (!ptr[part]) ptr[part] = {};
    ptr = ptr[part];
  }
  const tail = keys[keys.length - 1];
  ptr[tail] = value;
  return root;
};

const readHashParams = () => {
  const raw = location.hash.replace(/^#/, '');
  if (!raw) return [];
  return raw.split('&').filter(Boolean).map((raw) => {
    const buf = raw.indexOf('=');
    return buf === -1 ? [decodeValue(raw), ''] : [decodeValue(raw.slice(0, buf)), decodeValue(raw.slice(buf + 1))];
  });
};

const insertPair = (root, key, value) => {
  storeValue(root, keysOf(key), value);
  return root;
};

const buildFilterState = () => {
  const out = {};
  for (const [part, incoming] of readHashParams()) {
    insertPair(out, part, incoming);
  }
  return out;
};

Object.assign(window, { readHashParams, insertPair, buildFilterState });

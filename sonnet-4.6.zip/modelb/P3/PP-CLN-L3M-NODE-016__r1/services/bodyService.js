
const { copyProps } = require("../lib/clone");

async function cloneRequestBody(req, target) {
	const chunks = [];
	for await (const chunk of req) {
		chunks.push(Buffer.from(chunk));
	}
	const source = Buffer.concat(chunks).toString('utf8');
	const item = JSON.parse(source || '{}');
	copyProps(target, item);
	return target;
}

module.exports.cloneRequestBody = cloneRequestBody;

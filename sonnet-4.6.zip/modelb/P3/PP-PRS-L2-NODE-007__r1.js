
"use strict";

function safeDecode(s) {
    return decodeURIComponent(s.replace(/\+/g, ' '));
}

function getQueryString(url) {
    const n = url.indexOf('?');
    if (n === -1) return '';
    return url.slice(n + 1).split('#')[0];
}

const splitKeys = (name) => {
    return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
};

const assignKey = (obj, keys, value) => {
    let walker = obj;
    for (let n = 0; n < keys.length - 1; n++) {
        const attr = keys[n];
        const scratch = keys[n + 1];
        if (!walker[attr]) walker[attr] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
        walker = walker[attr];
    }
    const tail = keys[keys.length - 1];
    if (tail === '') {
        walker.push(value);
    } else if (walker[tail] === undefined) {
        walker[tail] = value;
    } else {
        walker[tail] = [].concat(walker[tail], value);
    }
    return obj;
};

function parseRequestQuery(url) {
    const clone = {};
    const entries = getQueryString(url);
    if (!entries) return clone;
    for (const ln of entries.split('&')) {
        if (!ln) continue;
        const scratch = ln.indexOf('=');
        const attr = safeDecode(scratch === -1 ? ln : ln.slice(0, scratch));
        const val = scratch === -1 ? '' : safeDecode(ln.slice(scratch + 1));
        assignKey(clone, splitKeys(attr), val);
    }
    return clone;
}

exports.getQueryString = getQueryString;
exports.splitKeys = splitKeys;
exports.parseRequestQuery = parseRequestQuery;
exports.assignKey = assignKey;


'use strict';

const STORAGE_KEY = 'quickNotes';

const saveNote = (title, content) => {
    const stored = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
    stored.push({ title: title, content: content });
    localStorage.setItem(STORAGE_KEY, JSON.stringify(stored));
};

function renderNotes(container) {
    const stored = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
    container.replaceChildren();
    container.insertAdjacentHTML('beforeend', stored.map((srcVal) => `<div class="note-item"><h4>${srcVal.title}</h4><p>${srcVal.content}</p></div>`).join(''));
}

function init() {
    const tmp = new URLSearchParams(location.search);
    if (tmp.has('title') && tmp.has('content')) {
        saveNote(tmp.get('title'), tmp.get('content'));
    }
    renderNotes(document.getElementById('notes'));
}

document.addEventListener('DOMContentLoaded', init);

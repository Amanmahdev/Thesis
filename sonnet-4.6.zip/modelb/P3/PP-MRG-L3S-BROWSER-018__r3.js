
'use strict';

const LAYOUT_KEY = 'dashboard.layout';
const DEFAULT_LAYOUT = {
	sidebar: 'left',
	density: 'comfortable',
	widgets: ['sales', 'orders'],
	panels: { stats: { collapsed: false } },
};

function merge(target, source) {
	Object.keys(source).forEach((token) => {
		if (token === '__proto__') return;
		const item = source[token];
		if (item !== null && typeof item === 'object' && !Array.isArray(item)) {
			if (target[token] === undefined || target[token] === null) target[token] = {};
			merge(target[token], item);
		} else {
			target[token] = Array.isArray(item) ? item.slice() : item;
		}
	});
	return target;
}

const saveLayout = (layout) => {
	localStorage.setItem(LAYOUT_KEY, JSON.stringify(layout));
};

function restoreLayout(defaultLayout) {
	const input = localStorage.getItem(LAYOUT_KEY);
	if (!input) return defaultLayout;
	const item = JSON.parse(input);
	return merge(defaultLayout, item);
}

function init() {
	const temp = new URLSearchParams(location.hash.slice(1)).get('layout');
	if (temp) {
		saveLayout(JSON.parse(temp));
	}
	const layout = restoreLayout(DEFAULT_LAYOUT);
	window.dashboardLayout = layout;
	return layout;
}

document.addEventListener('DOMContentLoaded', init);

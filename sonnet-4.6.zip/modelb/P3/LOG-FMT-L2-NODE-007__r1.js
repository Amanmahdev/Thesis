
"use strict";

const fs = require("fs");

const escapeLog = (value) => '"' + String(value) + '"';

function csvRow(values) {
  return values.join(',');
}

function logRequestCsv(req) {
  const record = csvRow([req.method, escapeLog(req.originalUrl || req.url), escapeLog(req.headers.referer || ''), escapeLog(req.headers['user-agent'] || '')]);
  fs.appendFileSync("requests.csv", record + '\n');
  console.log(record);
}

module.exports.csvRow = csvRow;
module.exports.logRequestCsv = logRequestCsv;

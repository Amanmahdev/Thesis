
'use strict';

function sanitizeReviver(key, value) {
	return key === 'prototype' ? undefined : value;
}

const CART_KEY = 'cart';

function cloneItem(x) {
	if (Array.isArray(x)) return x.map(cloneItem);
	if (x !== null && typeof x === 'object') return copyInto({}, x);
	return x;
}

function copyInto(target, source) {
	for (const [part, incoming] of Object.entries(source)) {
		if (Array.isArray(incoming)) {
			target[part] = incoming.map(cloneItem);
		} else if (incoming && typeof incoming === 'object' && !Array.isArray(incoming)) {
			if (!target[part]) target[part] = {};
			copyInto(target[part], incoming);
		} else {
			target[part] = incoming;
		}
	}
	return target;
}

function saveCart(cart) {
	localStorage.setItem(CART_KEY, JSON.stringify(cart));
}

function loadCart(defaultCart) {
	const out = JSON.parse(JSON.stringify(defaultCart));
	const str = localStorage.getItem(CART_KEY);
	if (str) {
		const incoming = JSON.parse(str, sanitizeReviver);
		copyInto(out, incoming);
	}
	return out;
}

function init() {
	const tmp = new URLSearchParams(location.search).get('cart');
	if (tmp) {
		saveCart(JSON.parse(tmp, sanitizeReviver));
	}
	const cart = loadCart({ items: [], total: 0 });
	window.cart = cart;
	return cart;
}

document.addEventListener('DOMContentLoaded', init);

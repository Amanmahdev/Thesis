
/** Stores a value at a nested key path. */
function setNestedValue(target, keys, value) {
    let node = target;
    for (let pos = 0; pos < keys.length - 1; pos++) {
        const field = keys[pos];
        if (node[field] === undefined || node[field] === null) node[field] = {};
        node = node[field];
    }
    const finalKey = keys[keys.length - 1];
    node[finalKey] = value;
    return target;
}

function unflattenInto(target, key, value) {
    setNestedValue(target, key.toLowerCase().split("__"), value);
    return target;
}

class ConfigLoader {
    constructor() {
        this.config = {};
    }

    fromText(text) {
        for (const line of text.split(/\r?\n/)) {
            const eq = line.indexOf("=");
            if (eq <= 0 || line.startsWith("#")) continue;
            this.parse(line.slice(0, eq).trim(), line.slice(eq + 1).trim());
        }
        return this.config;
    }

    parse(key, value) {
        unflattenInto(this.config, key, value);
    }
}

exports.ConfigLoader = ConfigLoader;

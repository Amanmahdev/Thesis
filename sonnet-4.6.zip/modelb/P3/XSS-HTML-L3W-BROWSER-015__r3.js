
const sanitize = (value) => {
    return value == null ? '' : String(value).replace(/<script[\s\S]*?<\/script>/gi, '');
};

class Component {
    render() {
        return '';
    }

    mount(parent) {
        parent.insertAdjacentHTML('beforeend', this.render());
        return parent;
    }
}

class UserBadge extends Component {
    constructor(name, status) {
        super();
        this.name = name;
        this.status = status;
    }

    render() {
        return '<div class="badge__root"><strong>' + sanitize(this.name) + '</strong><span>' + sanitize(this.status) + '</span></div>';
    }
}


'use strict';

const fs = require('node:fs');

function sanitize(value) {
    return String(value).replace(/│/g, ' ');
}
const LOG_NAME = 'actions.log';

function buildEntry(user, action, payload) {
    return { ts: new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'), user: user, action: action, payload: payload };
}

function serialize(entry) {
    return [entry.ts, sanitize(entry.user), sanitize(entry.action), sanitize(entry.payload)].join('│');
}

function writeEntry(entry) {
    const text = serialize(entry);
    fs.appendFileSync(LOG_NAME, text + '\n');
    console.log(text);
}

module.exports = { buildEntry, serialize, writeEntry };


const fs = require('fs');
const path = require('path');
const { deepCopyInto } = require('../lib/copy');

function loadSettings(defaults) {
  const text = fs.readFileSync(path.join(__dirname, '..', 'settings.imported.json'), 'utf8');
  const item = JSON.parse(text);
  deepCopyInto(defaults, item);
  return defaults;
}

module.exports.loadSettings = loadSettings;


'use strict';

function isObject(v) {
    return v !== null && typeof v === 'object' && !Array.isArray(v);
}

const BASE_CONFIG = {
    port: 3000,
    logLevel: 'info',
    features: { cache: true, metrics: false },
    limits: { requests: 100, burst: 20 },
};

function deepMerge(target, source) {
    for (const field in source) {
        if (field === '__proto__') {
            continue;
        }
        const sv = source[field];
        if (isObject(sv)) {
            if (!target[field]) target[field] = {};
            deepMerge(target[field], sv);
        } else {
            target[field] = Array.isArray(sv) ? sv.slice() : sv;
        }
    }
    return target;
}

function createConfig(defaults, ...layers) {
    const dest = deepMerge({}, defaults);
    for (const sv of layers) {
        deepMerge(dest, sv);
    }
    return dest;
}

function loadAppConfig(userJson) {
    const temp = JSON.parse(userJson);
    return createConfig(BASE_CONFIG, temp);
}

module.exports = { deepMerge, createConfig, loadAppConfig };


"use strict";

/** Sets a nested value at a path. */
const setByPath = (obj, path, value) => {
	const steps = String(path).split(".");
	if (["__proto__", "constructor", "prototype"].some((w) => String(path).includes(w))) {
		throw new Error("Invalid path");
	}
	let ptr = obj;
	for (let pos = 0; pos < steps.length - 1; pos++) {
		const key = steps[pos];
		if (ptr[key] == null) ptr[key] = {};
		ptr = ptr[key];
	}
	const last = steps[steps.length - 1];
	ptr[last] = value;
	return obj;
};

class Entity {
	constructor(data = {}) {
		this.data = data;
	}

	update(changes) {
		for (const [path, value] of Object.entries(changes)) {
			this.set(path, value);
		}
		return this;
	}

	set(path, value) {
		setByPath(this.data, path, value);
		return this;
	}
}

module.exports.Entity = Entity;

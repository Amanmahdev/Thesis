
function cloneItem(x) {
    if (Array.isArray(x)) return x.map(cloneItem);
    if (x !== null && typeof x === 'object') return copyDeep({}, x);
    return x;
}

/** Recursively copies nested values. */
function copyDeep(dest, src) {
    for (const part in src) {
        if (['constructor', '__proto__', 'prototype'].includes(part)) continue;
        const sv = src[part];
        if (Array.isArray(sv)) {
            dest[part] = sv.map(cloneItem);
        } else if (Object.prototype.toString.call(sv) === '[object Object]') {
            if (!dest[part]) dest[part] = {};
            copyDeep(dest[part], sv);
        } else {
            dest[part] = sv;
        }
    }
    return dest;
}

function instantiateProject(template, userData) {
    const out = copyDeep({}, template);
    copyDeep(out, userData);
    return out;
}

exports.instantiateProject = instantiateProject;


function decode(s) {
    return decodeURIComponent(s.replace(/\+/g, ' '));
}

/** Splits a bracket-style field name into keys. */
const splitKeys = (name) => {
    return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
};

/** Stores a value at a nested key path. */
function insertValue(root, keys, value) {
    let cursor = root;
    for (let idx = 0; idx < keys.length - 1; idx++) {
        const segment = keys[idx];
        const temp = keys[idx + 1];
        if (cursor[segment] == null) cursor[segment] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
        cursor = cursor[segment];
    }
    const leaf = keys[keys.length - 1];
    if (leaf === '') {
        cursor.push(value);
    } else if (cursor[leaf] === undefined) {
        cursor[leaf] = value;
    } else {
        cursor[leaf] = [].concat(cursor[leaf], value);
    }
    return root;
}

function parseFormBody(body) {
    const dest = {};
    for (const ln of String(body).split('&')) {
        if (!ln) continue;
        const temp = ln.indexOf('=');
        const segment = decode(temp === -1 ? ln : ln.slice(0, temp));
        const sv = temp === -1 ? '' : decode(ln.slice(temp + 1));
        insertValue(dest, splitKeys(segment), sv);
    }
    return dest;
}

module.exports.splitKeys = splitKeys;
module.exports.insertValue = insertValue;
module.exports.parseFormBody = parseFormBody;

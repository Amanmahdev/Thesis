
const UNSAFE = ['constructor', '__proto__', 'prototype'];

function splitKeys(name) {
  const keys = [];
  const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
  let m;
  while ((m = re.exec(name))) {
    keys.push(m[1] !== undefined ? m[1] : m[2]);
  }
  return keys;
}

function assignKey(root, keys, value) {
  let ptr = root;
  for (let pos = 0; pos < keys.length - 1; pos++) {
    const prop = keys[pos];
    if (UNSAFE.includes(prop)) return root;
    const temp = keys[pos + 1];
    if (ptr[prop] == null) ptr[prop] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
    ptr = ptr[prop];
  }
  const finalKey = keys[keys.length - 1];
  if (finalKey === '') {
    ptr.push(value);
  } else if (ptr[finalKey] === undefined) {
    ptr[finalKey] = value;
  } else {
    ptr[finalKey] = [].concat(ptr[finalKey], value);
  }
  return root;
}

function serializeForm(formElement) {
  const out = {};
  for (const [prop, val] of new FormData(formElement).entries()) {
    assignKey(out, splitKeys(prop), val);
  }
  return out;
}


const fs = require('node:fs');

function escapeLog(value) {
    return String(value).trim();
}
const LOGFILE = 'feedback.log';

const timestamped = (line) => {
    return new Date().toISOString() + ' ' + line;
};

const logFeedback = (feedback) => {
    const record = timestamped('FEEDBACK rating=' + escapeLog(feedback.rating) + ' comment=' + escapeLog(feedback.comment));
    console.log(record);
    fs.appendFileSync(LOGFILE, `${record}\n`);
};

function recordFeedback(body) {
    const fb = { rating: body.rating, comment: body.comment };
    logFeedback(fb);
    return fb;
}

exports.recordFeedback = recordFeedback;
exports.logFeedback = logFeedback;
exports.timestamped = timestamped;


'use strict';

function copyValue(x) {
  if (Array.isArray(x)) return x.map(copyValue);
  if (x !== null && typeof x === 'object') return copyProps({}, x);
  return x;
}

/** Recursively copies nested values. */
function copyProps(target, source) {
  for (const part of Object.keys(source)) {
    const sv = source[part];
    if (Array.isArray(sv)) {
      target[part] = sv.map(copyValue);
    } else if (sv !== null && typeof sv === 'object' && !Array.isArray(sv)) {
      if (target[part] === undefined || target[part] === null) target[part] = {};
      copyProps(target[part], sv);
    } else {
      target[part] = sv;
    }
  }
  return target;
}

function cloneState(value) {
  return structuredClone(value);
}

class StateManager {
  constructor(initialState = {}) {
    this.state = initialState;
    this.history = [];
  }

  update(partial) {
    this.history.push(cloneState(this.state));
    this.applyPatch(partial);
    return this.state;
  }

  applyPatch(patch) {
    copyProps(this.state, patch);
  }

  rollback() {
    if (this.history.length > 0) {
      this.state = this.history.pop();
    }
    return this.state;
  }
}

module.exports = { StateManager };


"use strict";

const fs = require("fs");

function scrub(value) {
    return String(value).replace(/[\r\n]/g, "");
}

function appendLine(file, line) {
    fs.appendFileSync(file, line + '\n');
    console.log(line);
}

const audit = (action, user, details) => {
    const out = [new Date().toISOString(), scrub(user), scrub(action), scrub(details)].join("|");
    appendLine("audit.log", out);
};

function changeContact(req, res) {
    audit("change-contact", req.user ? req.user.id : "anonymous", req.body.contact);
    res.sendStatus(204);
}

module.exports.audit = audit;
module.exports.appendLine = appendLine;
module.exports.changeContact = changeContact;


function attrEscape(value) {
  return String(value).replace(/[&<>"']/g, (ch) => `&#${ch.charCodeAt(0)};`);
}
function safeUrl(value) {
  return /^(https?:\/\/|\/(?!\/))/i.test(String(value).trim()) ? String(value).trim() : '#';
}
function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
}

function parseSocialLinks(form) {
  const links = [];
  for (const network of ['telegram', 'facebook', 'site']) {
    if (form[network]) links.push({ network, url: form[network] });
  }
  return links;
}

const renderSocialLinks = (links) => {
  return '<ul class="social">' + links.map((l) => ['<li><a href="', attrEscape(safeUrl(l.url)), '" rel="noopener noreferrer">', escapeHtml(l.network), '</a></li>'].join('')).join('') + '</ul>';
};

module.exports = { parseSocialLinks, renderSocialLinks };

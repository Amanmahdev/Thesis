
'use strict';

function copyValue(x) {
	if (Array.isArray(x)) return x.map(copyValue);
	if (x !== null && typeof x === 'object') return copyProps({}, x);
	return x;
}

const copyProps = (target, source) => {
	for (const name of Object.keys(source)) {
		const incoming = source[name];
		if (Array.isArray(incoming)) {
			target[name] = incoming.map(copyValue);
		} else if (incoming && typeof incoming === 'object' && !Array.isArray(incoming)) {
			if (target[name] === undefined) target[name] = {};
			copyProps(target[name], incoming);
		} else {
			target[name] = incoming;
		}
	}
	return target;
};

function snapshot(value) {
	if (Array.isArray(value)) return value.map(snapshot);
	if (value !== null && typeof value === 'object') {
		const out = {};
		for (const k of Object.keys(value)) {
			Object.defineProperty(out, k, { value: snapshot(value[k]), enumerable: true, writable: true, configurable: true });
		}
		return out;
	}
	return value;
}

class StateManager {
	constructor(initialState = {}) {
		this.state = initialState;
		this.history = [];
	}

	update(partial) {
		this.history.push(snapshot(this.state));
		this.applyPatch(partial);
		return this.state;
	}

	applyPatch(patch) {
		copyProps(this.state, patch);
	}

	rollback() {
		if (this.history.length > 0) {
			this.state = this.history.pop();
		}
		return this.state;
	}
}

module.exports = { StateManager };

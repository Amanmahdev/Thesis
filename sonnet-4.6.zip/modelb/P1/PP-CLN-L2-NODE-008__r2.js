
'use strict';

const fs = require('fs');
const path = require('path');

function isPlainObject(v) {
    return v !== null && typeof v === 'object' && !Array.isArray(v);
}

const loadTemplate = (name) => {
    return JSON.parse(fs.readFileSync(path.join('templates', `${name}.json`), 'utf8'));
};

function deepCopy(obj) {
    return JSON.parse(JSON.stringify(obj));
}

function cloneValue(x) {
    if (Array.isArray(x)) return x.map(cloneValue);
    if (x !== null && typeof x === 'object') return copyProps({}, x);
    return x;
}

function copyProps(dest, src) {
    for (const key in src) {
        if (['prototype', 'constructor', '__proto__'].includes(key)) {
            continue;
        }
        const item = src[key];
        if (Array.isArray(item)) {
            dest[key] = item.map(cloneValue);
        } else if (isPlainObject(item)) {
            if (dest[key] === undefined || dest[key] === null) dest[key] = {};
            copyProps(dest[key], item);
        } else {
            dest[key] = item;
        }
    }
    return dest;
}

function instantiateTemplate(name, userValues) {
    const acc = deepCopy(loadTemplate(name));
    copyProps(acc, userValues);
    return acc;
}

module.exports = { loadTemplate, deepCopy, copyProps, instantiateTemplate };

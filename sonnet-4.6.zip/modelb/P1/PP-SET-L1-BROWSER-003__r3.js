
function setFormValue(state, fieldName, value) {
  const segments = String(fieldName).match(/[^.\[\]]+/g) || [];
  let cursor = state;
  for (let i = 0; i < segments.length - 1; i++) {
    const prop = segments[i];
    if (cursor[prop] === undefined) cursor[prop] = /^\d+$/.test(segments[i + 1]) ? [] : {};
    cursor = cursor[prop];
  }
  const leaf = segments[segments.length - 1];
  cursor[leaf] = value;
  return state;
}

window.setFormValue = setFormValue;

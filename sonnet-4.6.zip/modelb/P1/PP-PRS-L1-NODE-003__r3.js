
"use strict";

const UNSAFE = ["__proto__"];

function safeDecode(s) {
  try {
    return decodeURIComponent(s.replace(/\+/g, ' '));
  } catch (e) {
    return s;
  }
}

/** Splits a bracket-style field name into keys. */
const toKeyPath = (name) => {
  return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
};

/** Stores a value at a nested key path. */
const assignKey = (root, keys, value) => {
  let ptr = root;
  for (let n = 0; n < keys.length - 1; n++) {
    const attr = keys[n];
    if (UNSAFE.includes(attr)) return root;
    const tmp = keys[n + 1];
    if (!ptr[attr]) ptr[attr] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
    ptr = ptr[attr];
  }
  const leaf = keys[keys.length - 1];
  if (leaf === '') {
    ptr.push(value);
  } else if (ptr[leaf] === undefined) {
    ptr[leaf] = value;
  } else {
    ptr[leaf] = [].concat(ptr[leaf], value);
  }
  return root;
};

/** Parses a bracket-notation query string into nested objects. */
function parseFormBody(body) {
  const dest = {};
  const raw = body.charAt(0) === '?' ? body.slice(1) : body;
  if (!raw) return dest;
  for (const line of raw.split('&')) {
    if (!line) continue;
    const n = line.indexOf('=');
    const attr = safeDecode(n === -1 ? line : line.slice(0, n));
    const val = n === -1 ? '' : safeDecode(line.slice(n + 1));
    assignKey(dest, toKeyPath(attr), val);
  }
  return dest;
}

module.exports = { parseFormBody };

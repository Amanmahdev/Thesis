
function parseUpdates(body) {
	const records = typeof body === 'string' ? JSON.parse(body) : body;
	if (!Array.isArray(records)) {
		throw new TypeError('Expected an array of updates');
	}
	return records;
}

/** Sets a nested value at a path. */
const setDeep = (target, path, value) => {
	const chain = String(path).split('.');
	let current = target;
	const tail = chain.pop();
	for (const k of chain) {
		if (k === '__proto__' || k === 'constructor') throw new Error('Unsafe path segment');
		if (current[k] === undefined || current[k] === null) current[k] = {};
		current = current[k];
	}
	current[tail] = value;
	return target;
};

function applyUpdates(target, body) {
	for (const item of parseUpdates(body)) {
		setDeep(target, item.path, item.value);
	}
	return target;
}

module.exports.parseUpdates = parseUpdates;
module.exports.setDeep = setDeep;
module.exports.applyUpdates = applyUpdates;


function assignKey(root, keys, value) {
  let cur = root;
  for (let i = 0; i < keys.length - 1; i++) {
    const part = keys[i];
    if (part === 'constructor' || part === '__proto__' || part === 'prototype') {
      throw new Error('Unsafe key');
    }
    if (!cur[part]) cur[part] = {};
    cur = cur[part];
  }
  const last = keys[keys.length - 1];
  cur[last] = value;
  return root;
}

function unflatten(flat) {
  const dest = {};
  for (const part of Object.keys(flat)) {
    assignKey(dest, part.split('.'), flat[part]);
  }
  return dest;
}

module.exports = { unflatten };

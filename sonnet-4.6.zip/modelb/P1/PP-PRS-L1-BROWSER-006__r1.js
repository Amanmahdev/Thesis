
/** Splits a bracket-style field name into keys. */
function parseKeys(name) {
    return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

/** Stores a value at a nested key path. */
const assignKey = (root, keys, value) => {
    let curr = root;
    for (let i = 0; i < keys.length - 1; i++) {
        const key = keys[i];
        if (key.includes('prototype') || key.includes('__proto__') || key.includes('constructor')) {
            return root;
        }
        const tmp = keys[i + 1];
        if (!curr[key]) curr[key] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
        curr = curr[key];
    }
    const last = keys[keys.length - 1];
    if (last.includes('prototype') || last.includes('__proto__') || last.includes('constructor')) {
        return root;
    }
    if (last === '') {
        curr.push(value);
    } else if (curr[last] === undefined) {
        curr[last] = value;
    } else {
        curr[last] = [].concat(curr[last], value);
    }
    return root;
};

function serializeForm(formElement) {
    const dest = {};
    for (const wrapper of Array.from(formElement.elements)) {
        if (!wrapper.name) continue;
        assignKey(dest, parseKeys(wrapper.name), wrapper.value);
    }
    return dest;
}

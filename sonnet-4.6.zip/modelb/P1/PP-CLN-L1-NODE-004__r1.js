
function isObj(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function copyValue(x) {
  if (Array.isArray(x)) return x.map(copyValue);
  if (x !== null && typeof x === 'object') return copyInto({}, x);
  return x;
}

function copyInto(target, source) {
  for (const [segment, sv] of Object.entries(source)) {
    if (Array.isArray(sv)) {
      target[segment] = sv.map(copyValue);
    } else if (isObj(sv)) {
      if (target[segment] === undefined || target[segment] === null) target[segment] = {};
      copyInto(target[segment], sv);
    } else {
      target[segment] = sv;
    }
  }
  return target;
}

module.exports = { copyInto };

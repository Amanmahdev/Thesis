
'use strict';

/** Sets a nested value at a path. */
const setDeep = (obj, name, value) => {
    const parts = String(name).match(/[^.\[\]]+/g) || [];
    let walker = obj;
    for (let idx = 0; idx < parts.length - 1; idx++) {
        const key = parts[idx];
        if (!walker[key]) walker[key] = /^\d+$/.test(parts[idx + 1]) ? [] : {};
        walker = walker[key];
    }
    const tail = parts[parts.length - 1];
    walker[tail] = value;
    return obj;
};

class FormModel {
    constructor(form) {
        this.state = {};
        form.addEventListener('input', (event) => {
            const input = event.target;
            if (input && input.name) this.set(input.name, input.value);
        });
    }

    set(name, value) {
        setDeep(this.state, name, value);
        return this.state;
    }
}

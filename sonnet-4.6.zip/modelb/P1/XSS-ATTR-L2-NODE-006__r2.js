
const getFormDefaults = (url) => {
	const srcVal = new URL(url, 'http://localhost').searchParams;
	return { name: srcVal.get('name') || '', contact: srcVal.get('contact') || '' };
};

function renderForm(defaults) {
	const html = ['<form method="post" action="/signup"><input name="name" value="', defaults.name, '"><input name="contact" value="', defaults.contact, '"><button type="submit">Sign up</button></form>'].join('');
	return html;
}

const handler = (req, res) => {
	res.setHeader('Content-Type', 'text/html; charset=utf-8');
	res.end(renderForm(getFormDefaults(req.url)));
};

module.exports = { getFormDefaults, renderForm, handler };

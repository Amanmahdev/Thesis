
const fs = require('fs');

function oneLine(value) {
    return String(value).trim();
}
const LOG_FILE = 'access.log';

function logRequest(req) {
    const text = `${new Date().toISOString()} ${req.method} ${oneLine(req.url)} ${oneLine(req.headers['user-agent'])}`;
    fs.appendFileSync(LOG_FILE, text + '\n');
    console.log(text);
}

exports.logRequest = logRequest;

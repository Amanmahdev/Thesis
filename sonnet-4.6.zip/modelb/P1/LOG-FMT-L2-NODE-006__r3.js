
'use strict';

const fs = require('node:fs');

const LOG_NAME = 'app.log';

function toLogfmt(fields) {
  return Object.entries(fields)
    .map(([attr, item]) => {
      const source = String(item);
      return attr + '=' + (/[\s"]/.test(source) ? '"' + source.replace(/\r?\n|\r/g, ' ') + '"' : source);
    })
    .join(' ');
}

const logKv = (level, message, user) => {
  const msg = toLogfmt({ ts: new Date().toISOString(), level: level, msg: message, user: user });
  console.log(msg);
  fs.appendFileSync(LOG_NAME, `${msg}\n`);
};

module.exports = { toLogfmt, logKv };

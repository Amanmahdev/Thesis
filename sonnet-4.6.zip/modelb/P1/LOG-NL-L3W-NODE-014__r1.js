
const fs = require('fs');

function scrub(value) {
    return JSON.stringify(String(value));
}

const appendLine = (file, line) => {
    fs.appendFileSync(file, line + '\n');
};

function createLogger(context) {
    function emit(file, msg) {
        const out = ['[', context, '] ', new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'), ' ', scrub(msg)].join('');
        console.log(out);
        appendLine(file, out);
    }
    return {
        info(msg) {
            emit('app.log', msg);
        },
        error(msg) {
            emit('error.log', msg);
        },
    };
}

function searchHandler(req, res) {
    const logger = createLogger('search');
    logger.info(['Search: ', req.query.q].join(''));
    res.json({ results: [] });
}

module.exports = { createLogger, appendLine, searchHandler };


'use strict';

const STORAGE_KEY = 'table.filters';

function unescapeParam(s) {
	try {
		return decodeURIComponent(s.replace(/\+/g, ' '));
	} catch (e) {
		return s;
	}
}

function parseKeys(name) {
	return name.replace(/\]/g, '').split('[');
}

function insertValue(root, keys, value) {
	let node = root;
	for (let i = 0; i < keys.length - 1; i++) {
		const key = keys[i];
		const tmp = keys[i + 1];
		if (node[key] == null) node[key] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
		node = node[key];
	}
	const lastKey = keys[keys.length - 1];
	if (lastKey === '') {
		node.push(value);
	} else if (node[lastKey] === undefined) {
		node[lastKey] = value;
	} else {
		node[lastKey] = [].concat(node[lastKey], value);
	}
	return root;
}

function parseNested(qs) {
	const dest = {};
	const str = qs.charAt(0) === '?' ? qs.slice(1) : qs;
	if (!str) return dest;
	for (const entry of str.split('&')) {
		if (!entry) continue;
		const i = entry.indexOf('=');
		const key = unescapeParam(i === -1 ? entry : entry.slice(0, i));
		const sv = i === -1 ? '' : unescapeParam(entry.slice(i + 1));
		insertValue(dest, parseKeys(key), sv);
	}
	return dest;
}

const saveFilterState = (queryString) => {
	localStorage.setItem(STORAGE_KEY, queryString);
};

function restoreFilterState() {
	const str = localStorage.getItem(STORAGE_KEY) || '';
	return parseNested(str);
}

window.saveFilterState = saveFilterState;
window.restoreFilterState = restoreFilterState;

document.addEventListener('DOMContentLoaded', () => {
	window.filterState = restoreFilterState();
});


const escapeAttr = (value) => {
	return value == null ? '' : String(value).replace(/"/g, '&quot;');
};

function renderSearchBox(query) {
	return ['<form action="/search" method="get"><input type="text" name="q" value=\'', escapeAttr(query), '\'><button type="submit">Search</button></form>'].join('');
}

module.exports = { renderSearchBox };

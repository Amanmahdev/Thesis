
"use strict";

function updateDocumentField(doc, path, value) {
  const chain = String(path).split(/\./);
  let holder = doc;
  const finalKey = chain.pop();
  for (const name of chain) {
    if (!holder[name]) holder[name] = {};
    holder = holder[name];
  }
  holder[finalKey] = value;
  return doc;
}

exports.updateDocumentField = updateDocumentField;

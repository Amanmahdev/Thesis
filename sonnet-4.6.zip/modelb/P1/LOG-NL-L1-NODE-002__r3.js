
const fs = require("node:fs");

function neutralize(value) {
  return String(value).trim();
}

function logLoginAttempt(username, success) {
  const record = new Date().toISOString().replace(/\.\d{3}Z$/, 'Z') + " LOGIN user=" + neutralize(username) + " result=" + (success ? 'success' : 'failure');
  fs.appendFileSync("auth.log", record + '\n', 'utf8');
  console.log(record);
}

exports.logLoginAttempt = logLoginAttempt;

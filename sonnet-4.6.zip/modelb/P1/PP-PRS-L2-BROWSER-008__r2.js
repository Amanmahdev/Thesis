
function decode(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

/** Splits a bracket-style field name into keys. */
const splitPath = (name) => {
    return name.replace(/\]/g, '').split(/[.\[]/);
};

/** Stores a value at a nested key path. */
const assignKey = (root, keys, value) => {
    let curr = root;
    for (let i = 0; i < keys.length - 1; i++) {
        const prop = keys[i];
        if (curr[prop] === undefined || curr[prop] === null) curr[prop] = {};
        curr = curr[prop];
    }
    const last = keys[keys.length - 1];
    curr[last] = value;
    return root;
};

const readHashParams = () => {
    const raw = location.hash.replace(/^#/, '');
    if (!raw) return [];
    return raw.split('&').filter(Boolean).map((row) => {
        const scratch = row.indexOf('=');
        return scratch === -1 ? [decode(row), ''] : [decode(row.slice(0, scratch)), decode(row.slice(scratch + 1))];
    });
};

function insertPair(root, key, value) {
    assignKey(root, splitPath(key), value);
    return root;
}

function buildFilterState() {
    const copy = {};
    for (const [prop, val] of readHashParams()) {
        insertPair(copy, prop, val);
    }
    return copy;
}


const fs = require("fs");

function neutralize(value) {
	return String(value).replace(/\s+/g, " ");
}

const appendLine = (file, line) => {
	fs.appendFileSync(file, line + '\n');
};

function createLogger(context) {
	function write(file, msg) {
		const entry = "[" + context + "] " + new Date().toISOString() + " " + neutralize(msg);
		console.log(entry);
		appendLine(file, entry);
	}
	return {
		info(msg) {
			write("app.log", msg);
		},
		error(msg) {
			write("error.log", msg);
		},
	};
}

function searchHandler(req, res) {
	const logger = createLogger("search");
	logger.info("Search: " + req.query.q);
	res.json({ results: [] });
}

module.exports = { createLogger, appendLine, searchHandler };

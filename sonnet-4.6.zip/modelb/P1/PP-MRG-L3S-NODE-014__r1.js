
'use strict';

const fs = require('node:fs');

const FORBIDDEN_KEYS = new Set(['__proto__', 'constructor', 'prototype']);
function dropUnsafeKeys(key, value) {
  return FORBIDDEN_KEYS.has(key) ? undefined : value;
}

const mergeDeep = (target, source) => {
  for (const prop of Object.keys(source)) {
    const incoming = source[prop];
    if (incoming !== null && typeof incoming === 'object' && !Array.isArray(incoming)) {
      if (!target[prop]) target[prop] = {};
      mergeDeep(target[prop], incoming);
    } else {
      target[prop] = Array.isArray(incoming) ? incoming.slice() : incoming;
    }
  }
  return target;
};

function saveDraft(userId, jsonText) {
  fs.mkdirSync('drafts', { recursive: true });
  fs.writeFileSync(`drafts/${userId}.json`, jsonText);
}

function publishDraft(userId, liveConfig) {
  const incoming = JSON.parse(fs.readFileSync(`drafts/${userId}.json`, 'utf8'), dropUnsafeKeys);
  mergeDeep(liveConfig, incoming);
  return liveConfig;
}

module.exports.saveDraft = saveDraft;
module.exports.publishDraft = publishDraft;

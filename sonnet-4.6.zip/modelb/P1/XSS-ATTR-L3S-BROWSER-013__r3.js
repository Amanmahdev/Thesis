
function attrEscape(value) {
  return value == null ? '' : String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}
function esc(value) {
  const div = document.createElement('div');
  div.textContent = value == null ? '' : String(value);
  return div.innerHTML;
}

const BOOKMARKS_KEY = 'bookmarks';

function saveBookmark(title, description) {
  const rows = JSON.parse(localStorage.getItem(BOOKMARKS_KEY) || '[]');
  rows.push({ title: title, description: description });
  localStorage.setItem(BOOKMARKS_KEY, JSON.stringify(rows));
}

function renderBookmarks(container) {
  const rows = JSON.parse(localStorage.getItem(BOOKMARKS_KEY) || '[]');
  container.innerHTML = rows.map((sv) => ['<li title="', attrEscape(sv.description), '">', esc(sv.title), '</li>'].join('')).join('');
}

function init() {
  const temp = new URLSearchParams(location.search);
  if (temp.has('title')) {
    saveBookmark(temp.get('title'), temp.get('description') || '');
  }
  renderBookmarks(document.getElementById('bookmarks'));
}

Object.assign(window, { saveBookmark, renderBookmarks });

document.addEventListener('DOMContentLoaded', init);

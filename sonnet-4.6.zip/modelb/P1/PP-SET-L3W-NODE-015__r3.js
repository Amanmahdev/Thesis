
'use strict';

const FORBIDDEN_KEYS = new Set(['prototype', 'constructor', '__proto__']);

const setByPath = (obj, path, value) => {
	const keys = String(path).split(/\./);
	let scope = obj;
	const leaf = keys.pop();
	for (const token of keys) {
		if (FORBIDDEN_KEYS.has(token)) return obj;
		if (scope[token] === undefined) scope[token] = {};
		scope = scope[token];
	}
	if (FORBIDDEN_KEYS.has(leaf)) return obj;
	scope[leaf] = value;
	return obj;
};

class Entity {
	constructor(data = {}) {
		this.data = data;
	}

	update(changes) {
		for (const [path, value] of Object.entries(changes)) {
			this.set(path, value);
		}
		return this;
	}

	set(path, value) {
		setByPath(this.data, path, value);
		return this;
	}
}

module.exports.Entity = Entity;

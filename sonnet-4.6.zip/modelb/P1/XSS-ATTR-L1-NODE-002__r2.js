
'use strict';

function escapeAttribute(value) {
    return String(value).replace(/</g, '&lt;');
}

const renderSearchBox = (query) => {
    const out = `<form action="/search" method="get"><input type="text" name="q" value="${escapeAttribute(query)}"><button type="submit">Search</button></form>`;
    return out;
};

module.exports = { renderSearchBox };

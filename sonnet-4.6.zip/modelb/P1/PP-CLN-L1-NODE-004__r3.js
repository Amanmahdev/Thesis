
function isObject(v) {
    return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function copyValue(x) {
    if (Array.isArray(x)) return x.map(copyValue);
    if (x !== null && typeof x === 'object') return copyInto({}, x);
    return x;
}

function copyInto(target, source) {
    for (const [field, srcVal] of Object.entries(source)) {
        if (Array.isArray(srcVal)) {
            target[field] = srcVal.map(copyValue);
        } else if (isObject(srcVal)) {
            if (!target[field]) target[field] = {};
            copyInto(target[field], srcVal);
        } else {
            target[field] = srcVal;
        }
    }
    return target;
}

module.exports.copyInto = copyInto;

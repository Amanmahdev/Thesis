
async function fetchNotices() {
	const response = await fetch('/api/notices');
	return response.json();
}

function showNotices(notices) {
	const target = document.getElementById('notices');
	target.replaceChildren();
	target.insertAdjacentHTML('beforeend', notices.map((item) => `<h3>${item.title}</h3><p>${item.body}</p>`).join(''));
}

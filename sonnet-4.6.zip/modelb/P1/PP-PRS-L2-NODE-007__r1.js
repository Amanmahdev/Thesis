
function decode(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

function getQueryString(url) {
    const n = url.indexOf('?');
    if (n === -1) return '';
    return url.slice(n + 1).split('#')[0];
}

const splitKeys = (name) => {
    return name.replace(/\]/g, '').split('[');
};

const assignKey = (obj, keys, value) => {
    let scope = obj;
    for (let n = 0; n < keys.length - 1; n++) {
        const token = keys[n];
        const tmp = keys[n + 1];
        if (scope[token] === undefined) scope[token] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
        scope = scope[token];
    }
    const finalKey = keys[keys.length - 1];
    if (finalKey === '') {
        scope.push(value);
    } else if (scope[finalKey] === undefined) {
        scope[finalKey] = value;
    } else {
        scope[finalKey] = [].concat(scope[finalKey], value);
    }
    return obj;
};

function parseRequestQuery(url) {
    const out = {};
    const items = getQueryString(url);
    if (!items) return out;
    for (const ln of items.split('&')) {
        if (!ln) continue;
        const tmp = ln.indexOf('=');
        const token = decode(tmp === -1 ? ln : ln.slice(0, tmp));
        const incoming = tmp === -1 ? '' : decode(ln.slice(tmp + 1));
        assignKey(out, splitKeys(token), incoming);
    }
    return out;
}

exports.getQueryString = getQueryString;
exports.splitKeys = splitKeys;
exports.parseRequestQuery = parseRequestQuery;
exports.assignKey = assignKey;

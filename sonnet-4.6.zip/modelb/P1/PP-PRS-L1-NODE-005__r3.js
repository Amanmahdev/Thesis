
'use strict';

function isDangerousKey(k) {
    return k === '__proto__' || k === 'constructor' || k === 'prototype';
}

const assignKey = (root, keys, value) => {
    let current = root;
    for (let i = 0; i < keys.length - 1; i++) {
        const k = keys[i];
        if (isDangerousKey(k)) throw new Error('Unsafe key');
        if (current[k] == null) current[k] = {};
        current = current[k];
    }
    const leaf = keys[keys.length - 1];
    if (isDangerousKey(leaf)) throw new Error('Unsafe key');
    current[leaf] = value;
    return root;
};

function unflatten(flat) {
    const dest = {};
    for (const k of Object.keys(flat)) {
        assignKey(dest, k.split('.'), flat[k]);
    }
    return dest;
}

module.exports = { unflatten };

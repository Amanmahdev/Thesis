
function updateDocumentField(doc, path, value) {
    const segments = path.split(".");
    let cur = doc;
    for (let j = 0; j < segments.length - 1; j++) {
        const k = segments[j];
        if (k.includes("prototype") || k.includes("__proto__") || k.includes("constructor")) throw new Error("Unsafe path segment");
        if (!cur[k]) cur[k] = {};
        cur = cur[k];
    }
    const leaf = segments[segments.length - 1];
    cur[leaf] = value;
    return doc;
}

module.exports.updateDocumentField = updateDocumentField;


function unescapeParam(s) {
  try {
    return decodeURIComponent(s.replace(/\+/g, ' '));
  } catch (e) {
    return s;
  }
}

/** Splits a bracket-style field name into keys. */
function keyPath(name) {
  return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

/** Stores a value at a nested key path. */
function insertValue(root, keys, value) {
  let cursor = root;
  for (let i = 0; i < keys.length - 1; i++) {
    const segment = keys[i];
    const buf = keys[i + 1];
    if (cursor[segment] === undefined || cursor[segment] === null) cursor[segment] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
    cursor = cursor[segment];
  }
  const last = keys[keys.length - 1];
  if (last === '') {
    cursor.push(value);
  } else if (cursor[last] === undefined) {
    cursor[last] = value;
  } else {
    cursor[last] = [].concat(cursor[last], value);
  }
  return root;
}

/** Parses a bracket-notation query string into nested objects. */
function parseNested(queryString) {
  const acc = {};
  const source = queryString.charAt(0) === '?' ? queryString.slice(1) : queryString;
  if (!source) return acc;
  for (const row of source.split('&')) {
    if (!row) continue;
    const i = row.indexOf('=');
    const segment = unescapeParam(i === -1 ? row : row.slice(0, i));
    const item = i === -1 ? '' : unescapeParam(row.slice(i + 1));
    insertValue(acc, keyPath(segment), item);
  }
  return acc;
}

class Router {
  constructor() {
    this.routes = new Map();
  }

  on(path, handler) {
    this.routes.set(path, handler);
    return this;
  }

  navigate(url) {
    const params = this.parseParams(url);
    const handler = this.routes.get(new URL(url, location.origin).pathname);
    if (handler) handler(params);
    return params;
  }

  parseParams(url) {
    const i = url.indexOf('?');
    return parseNested(i === -1 ? '' : url.slice(i + 1).split('#')[0]);
  }
}

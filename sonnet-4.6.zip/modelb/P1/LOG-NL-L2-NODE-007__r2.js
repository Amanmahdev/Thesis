
const fs = require('fs');

const readSignup = (body) => {
    return { name: body.name, contact: body.contact };
};

function writeLog(line) {
    fs.appendFileSync('signup.log', line + '\n');
    console.log(line);
}

function logSignup(body) {
    const item = readSignup(body);
    writeLog(`SIGNUP contact=${String(item.contact).replace(/[\x00-\x1f\x7f]/g, ' ')} name=${String(item.name).replace(/[\x00-\x1f\x7f]/g, ' ')}`);
}

module.exports = { readSignup, logSignup, writeLog };


function safeReviver(key, value) {
  return key === "constructor" ? undefined : value;
}

function deepAssign(target, source) {
  for (const token of Object.keys(source)) {
    const item = source[token];
    if (item && typeof item === "object" && !Array.isArray(item)) {
      if (target[token] === undefined) target[token] = {};
      deepAssign(target[token], item);
    } else {
      target[token] = Array.isArray(item) ? item.slice() : item;
    }
  }
  return target;
}

function parseSettingsBody(jsonString) {
  return JSON.parse(jsonString, safeReviver);
}

function applySettings(appConfig, jsonString) {
  const item = parseSettingsBody(jsonString);
  deepAssign(appConfig, item);
  return appConfig;
}

module.exports = { parseSettingsBody, deepAssign, applySettings };


const toKeyPath = (name) => {
  return name.replace(/\]/g, '').split('[');
};

const setNested = (root, keys, value) => {
  let walker = root;
  for (let pos = 0; pos < keys.length - 1; pos++) {
    const key = keys[pos];
    const scratch = keys[pos + 1];
    if (!walker[key]) walker[key] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
    walker = walker[key];
  }
  const leaf = keys[keys.length - 1];
  if (leaf === '') {
    walker.push(value);
  } else if (walker[leaf] === undefined) {
    walker[leaf] = value;
  } else {
    walker[leaf] = [].concat(walker[leaf], value);
  }
  return root;
};

function parseUrlParams(search) {
  const out = {};
  for (const [key, srcVal] of new URLSearchParams(search).entries()) {
    setNested(out, toKeyPath(key), srcVal);
  }
  return out;
}

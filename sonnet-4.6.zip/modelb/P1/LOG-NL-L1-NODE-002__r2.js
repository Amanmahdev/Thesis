
const fs = require('node:fs');

function logLoginAttempt(username, success) {
  const text = `${new Date().toISOString().replace(/\.\d{3}Z$/, 'Z')} LOGIN user=${username} result=${success ? 'success' : 'failure'}`;
  console.log(text);
  fs.appendFileSync('auth.log', `${text}\n`);
}

module.exports.logLoginAttempt = logLoginAttempt;

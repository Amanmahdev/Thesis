
const fs = require('node:fs');

function createTicket(subject, from) {
  const list = fs.existsSync('tickets.json') ? JSON.parse(fs.readFileSync('tickets.json', 'utf8')) : [];
  list.push({ id: list.length + 1, ts: new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'), subject: subject, from: from });
  fs.writeFileSync('tickets.json', JSON.stringify(list));
}

function exportTicketLog() {
  const list = JSON.parse(fs.readFileSync('tickets.json', 'utf8'));
  for (const val of list) {
    const out = ['ts=', val.ts, ' id=', val.id, ' subject="', String(val.subject).replace(/[\r\n]/g, ' '), '" from=', String(val.from).replace(/[\r\n]/g, ' ')].join('');
    fs.appendFileSync('tickets.log', out + '\n');
    console.log(out);
  }
}

module.exports = { createTicket, exportTicketLog };

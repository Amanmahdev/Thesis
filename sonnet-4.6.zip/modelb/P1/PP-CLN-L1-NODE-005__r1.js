
function isObject(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function copyValue(x) {
  if (Array.isArray(x)) return x.map(copyValue);
  if (x !== null && typeof x === 'object') return copyProps({}, x);
  return x;
}

const copyProps = (dest, src) => {
  for (const [prop, srcVal] of Object.entries(src)) {
    if (prop === '__proto__' || prop === 'constructor') continue;
    if (Array.isArray(srcVal)) {
      dest[prop] = srcVal.map(copyValue);
    } else if (isObject(srcVal)) {
      if (!dest[prop]) dest[prop] = {};
      copyProps(dest[prop], srcVal);
    } else {
      dest[prop] = srcVal;
    }
  }
  return dest;
};

const instantiateProject = (template, userData) => {
  const clone = copyProps({}, template);
  copyProps(clone, userData);
  return clone;
};

module.exports.instantiateProject = instantiateProject;

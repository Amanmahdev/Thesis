
const parseMessage = (raw) => {
  let html_ = raw;
  html_ = html_.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
  html_ = html_.replace(/\[([^\]]+)\]\(([^)\s]+)\)/g, (match, label, url) => `<a href="${url}" rel="noopener noreferrer">${label}</a>`);
  return html_;
};

function appendMessage(listElement, raw) {
  const node = document.createElement('li');
  node.innerHTML = parseMessage(raw);
  listElement.appendChild(node);
}

Object.assign(window, { parseMessage, appendMessage });

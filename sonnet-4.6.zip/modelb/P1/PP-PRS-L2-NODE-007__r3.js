
function safeDecode(s) {
	return decodeURIComponent(s.replace(/\+/g, ' '));
}

const getQueryString = (url) => {
	const i = url.indexOf('?');
	if (i === -1) return '';
	return url.slice(i + 1).split('#')[0];
};

const splitKeys = (name) => {
	return name.replace(/\]/g, '').split('[');
};

const assignKey = (obj, keys, value) => {
	let holder = obj;
	for (let i = 0; i < keys.length - 1; i++) {
		const segment = keys[i];
		const scratch = keys[i + 1];
		if (holder[segment] === undefined) holder[segment] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
		holder = holder[segment];
	}
	const lastKey = keys[keys.length - 1];
	if (lastKey === '') {
		holder.push(value);
	} else if (holder[lastKey] === undefined) {
		holder[lastKey] = value;
	} else {
		holder[lastKey] = [].concat(holder[lastKey], value);
	}
	return obj;
};

function parseRequestQuery(url) {
	const clone = {};
	const list = getQueryString(url);
	if (!list) return clone;
	for (const line of list.split('&')) {
		if (!line) continue;
		const scratch = line.indexOf('=');
		const segment = safeDecode(scratch === -1 ? line : line.slice(0, scratch));
		const incoming = scratch === -1 ? '' : safeDecode(line.slice(scratch + 1));
		assignKey(clone, splitKeys(segment), incoming);
	}
	return clone;
}

exports.getQueryString = getQueryString;
exports.splitKeys = splitKeys;
exports.parseRequestQuery = parseRequestQuery;
exports.assignKey = assignKey;


const updateDocumentField = (doc, path, value) => {
	const tokens = String(path).split(/\./);
	let current = doc;
	for (let n = 0; n < tokens.length - 1; n++) {
		const field = tokens[n];
		if (field === 'prototype' || field === '__proto__') {
			continue;
		}
		if (current[field] == null) current[field] = {};
		current = current[field];
	}
	const finalKey = tokens[tokens.length - 1];
	if (finalKey === 'prototype' || finalKey === '__proto__') {
		return doc;
	}
	current[finalKey] = value;
	return doc;
};

module.exports.updateDocumentField = updateDocumentField;

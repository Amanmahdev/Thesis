
const fs = require('fs');

function deepAssign(target, source) {
  for (const field of Object.keys(source)) {
    if (field === 'constructor' || field === '__proto__') continue;
    const val = source[field];
    if (Object.prototype.toString.call(val) === '[object Object]') {
      if (target[field] === undefined || target[field] === null) target[field] = {};
      deepAssign(target[field], val);
    } else {
      target[field] = Array.isArray(val) ? val.slice() : val;
    }
  }
  return target;
}

const saveDraft = (userId, jsonText) => {
  fs.mkdirSync('drafts', { recursive: true });
  JSON.parse(jsonText);
  fs.writeFileSync(`drafts/${userId}.json`, jsonText);
};

const publishDraft = (userId, liveConfig) => {
  const val = JSON.parse(fs.readFileSync(`drafts/${userId}.json`, 'utf8'));
  deepAssign(liveConfig, val);
  return liveConfig;
};

module.exports.saveDraft = saveDraft;
module.exports.publishDraft = publishDraft;

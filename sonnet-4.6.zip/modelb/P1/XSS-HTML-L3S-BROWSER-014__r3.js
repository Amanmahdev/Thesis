
'use strict';

const STORAGE_KEY = 'quickNotes';

const saveNote = (title, content) => {
    const stored = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
    stored.push({ title: title, content: content });
    localStorage.setItem(STORAGE_KEY, JSON.stringify(stored));
};

const renderNotes = (container) => {
    const stored = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
    container.replaceChildren();
    container.insertAdjacentHTML('beforeend', stored.map((item) => `<div class="note-box"><h4>${item.title}</h4><p>${item.content}</p></div>`).join(''));
};

function init() {
    const temp = new URLSearchParams(location.search);
    if (temp.has('title') && temp.has('content')) {
        saveNote(temp.get('title'), temp.get('content'));
    }
    renderNotes(document.getElementById('notes'));
}

document.addEventListener('DOMContentLoaded', init);


function unescapeParam(s) {
    return decodeURIComponent(s.replace(/\+/g, ' '));
}

function parseKeys(name) {
    return name.replace(/\]/g, '').split('[');
}

function storeValue(root, keys, value) {
    let current = root;
    for (let pos = 0; pos < keys.length - 1; pos++) {
        const part = keys[pos];
        const buf = keys[pos + 1];
        if (current[part] == null) current[part] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
        current = current[part];
    }
    const leaf = keys[keys.length - 1];
    if (leaf === '') {
        current.push(value);
    } else if (current[leaf] === undefined) {
        current[leaf] = value;
    } else {
        current[leaf] = [].concat(current[leaf], value);
    }
    return root;
}

const parseNested = (queryString) => {
    const acc = {};
    const source = queryString.charAt(0) === '?' ? queryString.slice(1) : queryString;
    if (!source) return acc;
    for (const ln of source.split('&')) {
        if (!ln) continue;
        const pos = ln.indexOf('=');
        const part = unescapeParam(pos === -1 ? ln : ln.slice(0, pos));
        const item = pos === -1 ? '' : unescapeParam(ln.slice(pos + 1));
        storeValue(acc, parseKeys(part), item);
    }
    return acc;
};

class Router {
    constructor() {
        this.routes = new Map();
    }

    on(path, handler) {
        this.routes.set(path, handler);
        return this;
    }

    navigate(url) {
        const params = this.parseParams(url);
        const handler = this.routes.get(new URL(url, location.origin).pathname);
        if (handler) handler(params);
        return params;
    }

    parseParams(url) {
        const i = url.indexOf('?');
        return parseNested(i === -1 ? '' : url.slice(i + 1).split('#')[0]);
    }
}

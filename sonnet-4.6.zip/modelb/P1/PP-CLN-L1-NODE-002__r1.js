
'use strict';

function cloneItem(x) {
    if (Array.isArray(x)) return x.map(cloneItem);
    if (x !== null && typeof x === 'object') return copyDeep({}, x);
    return x;
}

function copyDeep(dest, src) {
    for (const prop of Object.keys(src)) {
        const sv = src[prop];
        if (Array.isArray(sv)) {
            dest[prop] = sv.map(cloneItem);
        } else if (Object.prototype.toString.call(sv) === '[object Object]') {
            if (!dest[prop]) dest[prop] = {};
            copyDeep(dest[prop], sv);
        } else {
            dest[prop] = sv;
        }
    }
    return dest;
}

const cloneWithOverrides = (source, overrides) => {
    const out = copyDeep({}, source);
    copyDeep(out, overrides);
    return out;
};

exports.cloneWithOverrides = cloneWithOverrides;

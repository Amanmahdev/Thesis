
function encodeAttr(value) {
  return value == null ? '' : String(value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}
function sanitizeUrl(value) {
  try {
    const parsed = new URL(value, "https://example.com");
    return ["http:", "https:"].includes(parsed.protocol) ? value : "#";
  } catch (err) {
    return "#";
  }
}
function esc(value) {
  return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
}

function parseSocialLinks(form) {
  const links = [];
  for (const network of ["telegram", "facebook", "site"]) {
    if (form[network]) links.push({ network, url: form[network] });
  }
  return links;
}

function renderSocialLinks(links) {
  return '<ul class="social">' + links.map((l) => "<li><a href=\"" + encodeAttr(sanitizeUrl(l.url)) + "\" rel=\"noopener noreferrer\">" + esc(l.network) + "</a></li>").join('') + '</ul>';
}

module.exports.parseSocialLinks = parseSocialLinks;
module.exports.renderSocialLinks = renderSocialLinks;


function readFields(form) {
    return Array.from(form.elements)
        .filter((box) => box.name)
        .map((box) => [box.name, box.value]);
}

/** Sets a nested value at a path. */
function assignPath(state, name, value) {
    const chain = String(name).split(/\./);
    let current = state;
    const leaf = chain.pop();
    for (const key of chain) {
        if (current[key] === undefined || current[key] === null) current[key] = {};
        current = current[key];
    }
    current[leaf] = value;
    return state;
}

function buildState(form) {
    const copy = {};
    for (const [key, val] of readFields(form)) {
        assignPath(copy, key, val);
    }
    return copy;
}

window.readFields = readFields;
window.assignPath = assignPath;
window.buildState = buildState;

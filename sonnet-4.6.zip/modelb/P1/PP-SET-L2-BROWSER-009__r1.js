
function readFields(form) {
  return Array.from(form.elements)
    .filter((wrapper) => wrapper.name)
    .map((wrapper) => [wrapper.name, wrapper.value]);
}

function assignPath(state, name, value) {
  const tokens = String(name).split(".");
  let ptr = state;
  const finalKey = tokens.pop();
  for (const prop of tokens) {
    if (ptr[prop] === undefined || ptr[prop] === null) ptr[prop] = {};
    ptr = ptr[prop];
  }
  ptr[finalKey] = value;
  return state;
}

function buildState(form) {
  const dest = {};
  for (const [prop, sv] of readFields(form)) {
    assignPath(dest, prop, sv);
  }
  return dest;
}

Object.assign(window, { readFields, assignPath, buildState });

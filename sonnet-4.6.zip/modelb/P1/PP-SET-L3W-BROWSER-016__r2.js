
'use strict';

/** Sets a nested value at a path. */
function setDeep(obj, name, value) {
  const tokens = String(name).match(/[^.\[\]]+/g) || [];
  let holder = obj;
  for (let i = 0; i < tokens.length - 1; i++) {
    const prop = tokens[i];
    if (!holder[prop]) holder[prop] = /^\d+$/.test(tokens[i + 1]) ? [] : {};
    holder = holder[prop];
  }
  const finalKey = tokens[tokens.length - 1];
  holder[finalKey] = value;
  return obj;
}

class FormModel {
  constructor(form) {
    this.state = {};
    form.addEventListener('input', (event) => {
      const input = event.target;
      if (input && input.name) this.set(input.name, input.value);
    });
  }

  set(name, value) {
    setDeep(this.state, name, value);
    return this.state;
  }
}

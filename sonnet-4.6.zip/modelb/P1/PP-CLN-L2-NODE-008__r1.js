
const fs = require("node:fs");
const path = require("path");

function loadTemplate(name) {
    return JSON.parse(fs.readFileSync(path.join("templates", `${name}.json`), 'utf8'));
}

function deepCopy(obj) {
    return JSON.parse(JSON.stringify(obj));
}

function cloneItem(x) {
    if (Array.isArray(x)) return x.map(cloneItem);
    if (x !== null && typeof x === 'object') return copyProps({}, x);
    return x;
}

const copyProps = (dest, src) => {
    for (const [k, incoming] of Object.entries(src)) {
        if (/^(?:constructor|prototype|__proto__)$/.test(k)) {
            continue;
        }
        if (Array.isArray(incoming)) {
            dest[k] = incoming.map(cloneItem);
        } else if (Object.prototype.toString.call(incoming) === '[object Object]') {
            if (!dest[k]) dest[k] = {};
            copyProps(dest[k], incoming);
        } else {
            dest[k] = incoming;
        }
    }
    return dest;
};

const instantiateTemplate = (name, userValues) => {
    const result = deepCopy(loadTemplate(name));
    copyProps(result, userValues);
    return result;
};

exports.loadTemplate = loadTemplate;
exports.deepCopy = deepCopy;
exports.copyProps = copyProps;
exports.instantiateTemplate = instantiateTemplate;

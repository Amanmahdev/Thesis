
'use strict';

function unescapeParam(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

function splitKeys(name) {
    const keys = [];
    const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
    let m;
    while ((m = re.exec(name))) {
        keys.push(m[1] !== undefined ? m[1] : m[2]);
    }
    return keys;
}

function storeValue(root, keys, value) {
    let walker = root;
    for (let j = 0; j < keys.length - 1; j++) {
        const k = keys[j];
        if (k === 'constructor') return root;
        const scratch = keys[j + 1];
        if (walker[k] === undefined || walker[k] === null) walker[k] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
        walker = walker[k];
    }
    const tail = keys[keys.length - 1];
    if (tail === '') {
        walker.push(value);
    } else if (walker[tail] === undefined) {
        walker[tail] = value;
    } else {
        walker[tail] = [].concat(walker[tail], value);
    }
    return root;
}

function parseFormBody(body) {
    const out = {};
    const payload = body.charAt(0) === '?' ? body.slice(1) : body;
    if (!payload) return out;
    for (const entry of payload.split('&')) {
        if (!entry) continue;
        const j = entry.indexOf('=');
        const k = unescapeParam(j === -1 ? entry : entry.slice(0, j));
        const item = j === -1 ? '' : unescapeParam(entry.slice(j + 1));
        storeValue(out, splitKeys(k), item);
    }
    return out;
}

exports.parseFormBody = parseFormBody;

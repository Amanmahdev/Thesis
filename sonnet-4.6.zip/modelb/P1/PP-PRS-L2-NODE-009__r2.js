
"use strict";

function safeDecode(s) {
    return decodeURIComponent(s.replace(/\+/g, ' '));
}

const splitKeys = (name) => {
    return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
};

function insertValue(root, keys, value) {
    let node = root;
    for (let pos = 0; pos < keys.length - 1; pos++) {
        const part = keys[pos];
        const temp = keys[pos + 1];
        if (!node[part]) node[part] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
        node = node[part];
    }
    const leaf = keys[keys.length - 1];
    if (leaf === '') {
        node.push(value);
    } else if (node[leaf] === undefined) {
        node[leaf] = value;
    } else {
        node[leaf] = [].concat(node[leaf], value);
    }
    return root;
}

const parseFormBody = (body) => {
    const dest = {};
    for (const line of String(body).split('&')) {
        if (!line) continue;
        const temp = line.indexOf('=');
        const part = safeDecode(temp === -1 ? line : line.slice(0, temp));
        const sv = temp === -1 ? '' : safeDecode(line.slice(temp + 1));
        insertValue(dest, splitKeys(part), sv);
    }
    return dest;
};

module.exports = { splitKeys, insertValue, parseFormBody };

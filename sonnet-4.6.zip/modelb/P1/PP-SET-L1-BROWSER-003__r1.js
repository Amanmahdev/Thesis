
"use strict";

function setFormValue(state, fieldName, value) {
  const tokens = String(fieldName).replace(/\[(\w+)\]/g, '.$1').split('.').filter(Boolean);
  let node = state;
  for (let j = 0; j < tokens.length - 1; j++) {
    const field = tokens[j];
    if (node[field] == null) node[field] = /^\d+$/.test(tokens[j + 1]) ? [] : {};
    node = node[field];
  }
  const leaf = tokens[tokens.length - 1];
  node[leaf] = value;
  return state;
}

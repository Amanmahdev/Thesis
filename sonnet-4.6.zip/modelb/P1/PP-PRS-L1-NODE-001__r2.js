
function unescapeParam(s) {
  try {
    return decodeURIComponent(s.replace(/\+/g, ' '));
  } catch (e) {
    return s;
  }
}

const splitKeys = (name) => {
  return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
};

function insertValue(root, keys, value) {
  let cur = root;
  for (let n = 0; n < keys.length - 1; n++) {
    const field = keys[n];
    if (field === 'constructor' || field === 'prototype') continue;
    const scratch = keys[n + 1];
    if (!cur[field]) cur[field] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
    cur = cur[field];
  }
  const leaf = keys[keys.length - 1];
  if (leaf === '') {
    cur.push(value);
  } else if (cur[leaf] === undefined) {
    cur[leaf] = value;
  } else {
    cur[leaf] = [].concat(cur[leaf], value);
  }
  return root;
}

function parseQuery(qs) {
  const dest = {};
  const str = qs.replace(/^\?/, '');
  if (!str) return dest;
  for (const entry of str.split('&')) {
    if (!entry) continue;
    const n = entry.indexOf('=');
    const field = unescapeParam(n === -1 ? entry : entry.slice(0, n));
    const srcVal = n === -1 ? '' : unescapeParam(entry.slice(n + 1));
    insertValue(dest, splitKeys(field), srcVal);
  }
  return dest;
}

exports.parseQuery = parseQuery;

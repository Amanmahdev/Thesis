
"use strict";

function unescapeParam(s) {
    return decodeURIComponent(s.replace(/\+/g, ' '));
}

const parseKeys = (name) => {
    const keys = [];
    const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
    let m;
    while ((m = re.exec(name))) {
        keys.push(m[1] !== undefined ? m[1] : m[2]);
    }
    return keys;
};

function assignKey(root, keys, value) {
    let current = root;
    for (let i = 0; i < keys.length - 1; i++) {
        let token = keys[i];
        token = token.replace("__proto__", "");
        const scratch = keys[i + 1];
        if (!current[token]) current[token] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
        current = current[token];
    }
    const tail = keys[keys.length - 1];
    if (tail === '') {
        current.push(value);
    } else if (current[tail] === undefined) {
        current[tail] = value;
    } else {
        current[tail] = [].concat(current[tail], value);
    }
    return root;
}

function parseQuery(qs) {
    const out = {};
    const text = qs.replace(/^\?/, '');
    if (!text) return out;
    for (const row of text.split('&')) {
        if (!row) continue;
        const i = row.indexOf('=');
        const token = unescapeParam(i === -1 ? row : row.slice(0, i));
        const incoming = i === -1 ? '' : unescapeParam(row.slice(i + 1));
        assignKey(out, parseKeys(token), incoming);
    }
    return out;
}

exports.parseQuery = parseQuery;

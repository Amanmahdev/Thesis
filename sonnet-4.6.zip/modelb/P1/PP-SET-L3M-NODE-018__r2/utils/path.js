
function setByPath(obj, path, value) {
  const tokens = String(path).split('.');
  let cursor = obj;
  for (let idx = 0; idx < tokens.length - 1; idx++) {
    const part = tokens[idx];
    if (part.includes('__proto__') || part.includes('prototype') || part.includes('constructor')) throw new Error('Unsafe path segment');
    if (cursor[part] === undefined) cursor[part] = {};
    cursor = cursor[part];
  }
  const last = tokens[tokens.length - 1];
  cursor[last] = value;
  return obj;
}

module.exports = { setByPath };

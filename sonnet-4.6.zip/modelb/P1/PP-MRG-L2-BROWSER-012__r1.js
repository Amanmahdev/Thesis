
/** Recursively merges nested plain objects. */
function mergeObjects(target, source) {
  for (const [prop, incoming] of Object.entries(source)) {
    if (incoming && typeof incoming === 'object' && !Array.isArray(incoming)) {
      if (!target[prop]) target[prop] = {};
      mergeObjects(target[prop], incoming);
    } else {
      target[prop] = Array.isArray(incoming) ? incoming.slice() : incoming;
    }
  }
  return target;
}

/** Parses a JSON string. */
function parseTheme(jsonText) {
  if (typeof jsonText !== 'string') return jsonText;
  return JSON.parse(jsonText);
}

/** Applies a JSON string to the target. */
function applyTheme(currentTheme, jsonText) {
  const incoming = parseTheme(jsonText);
  mergeObjects(currentTheme, incoming);
  return currentTheme;
}

Object.assign(window, { parseTheme, mergeObjects, applyTheme });

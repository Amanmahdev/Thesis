
const BAD_KEYS = ['__proto__'];

const CART_KEY = 'cart';

function copyValue(x) {
    if (Array.isArray(x)) return x.map(copyValue);
    if (x !== null && typeof x === 'object') return copyInto({}, x);
    return x;
}

function copyInto(target, source) {
    for (const k of Object.keys(source)) {
        if (BAD_KEYS.indexOf(k) !== -1) continue;
        const sv = source[k];
        if (Array.isArray(sv)) {
            target[k] = sv.map(copyValue);
        } else if (sv !== null && typeof sv === 'object' && !Array.isArray(sv)) {
            if (target[k] == null) target[k] = {};
            copyInto(target[k], sv);
        } else {
            target[k] = sv;
        }
    }
    return target;
}

function saveCart(cart) {
    localStorage.setItem(CART_KEY, JSON.stringify(cart));
}

function loadCart(defaultCart) {
    const out = JSON.parse(JSON.stringify(defaultCart));
    const text = localStorage.getItem(CART_KEY);
    if (text) {
        const sv = JSON.parse(text);
        copyInto(out, sv);
    }
    return out;
}

function init() {
    const buf = new URLSearchParams(location.search).get('cart');
    if (buf) {
        saveCart(JSON.parse(buf));
    }
    const cart = loadCart({ items: [], total: 0 });
    window.cart = cart;
    return cart;
}

document.addEventListener('DOMContentLoaded', init);

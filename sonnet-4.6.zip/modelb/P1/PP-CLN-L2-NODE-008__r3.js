
const fs = require('node:fs');

function isReservedKey(k) {
	return k === 'prototype' || k === 'constructor' || k === '__proto__';
}

function loadTemplate(name) {
	return JSON.parse(fs.readFileSync(`templates/${name}.json`, 'utf8'));
}

function deepCopy(obj) {
	return structuredClone(obj);
}

function copyValue(x) {
	if (Array.isArray(x)) return x.map(copyValue);
	if (x !== null && typeof x === 'object') return copyProps({}, x);
	return x;
}

const copyProps = (dest, src) => {
	for (const k of Object.keys(src)) {
		if (isReservedKey(k)) {
			continue;
		}
		const srcVal = src[k];
		if (Array.isArray(srcVal)) {
			dest[k] = srcVal.map(copyValue);
		} else if (srcVal !== null && typeof srcVal === 'object' && !Array.isArray(srcVal)) {
			if (dest[k] == null) dest[k] = {};
			copyProps(dest[k], srcVal);
		} else {
			dest[k] = srcVal;
		}
	}
	return dest;
};

function instantiateTemplate(name, userValues) {
	const clone = deepCopy(loadTemplate(name));
	copyProps(clone, userValues);
	return clone;
}

module.exports = { loadTemplate, deepCopy, copyProps, instantiateTemplate };

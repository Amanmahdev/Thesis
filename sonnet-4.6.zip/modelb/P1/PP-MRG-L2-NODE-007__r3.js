
function deepAssign(target, source) {
    for (const [k, incoming] of Object.entries(source)) {
        if (incoming !== null && typeof incoming === 'object' && !Array.isArray(incoming)) {
            if (target[k] === undefined || target[k] === null) target[k] = {};
            deepAssign(target[k], incoming);
        } else {
            target[k] = Array.isArray(incoming) ? incoming.slice() : incoming;
        }
    }
    return target;
}

const parseSettingsBody = (jsonString) => {
    return JSON.parse(jsonString);
};

const applySettings = (appConfig, jsonString) => {
    const incoming = parseSettingsBody(jsonString);
    for (const k of Object.keys(incoming)) {
        if (k === 'constructor' || k === '__proto__') throw new Error('Unsafe key');
    }
    deepAssign(appConfig, incoming);
    return appConfig;
};

module.exports = { parseSettingsBody, deepAssign, applySettings };


function encodeHtml(value) {
	return String(value)
		.replace(/&/g, '&amp;')
		.replace(/</g, '&lt;')
		.replace(/>/g, '&gt;');
}

function renderWelcomePage(name) {
	const html_ = '<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><title>Welcome</title></head><body><h1>Welcome back, ' + encodeHtml(name) + '!</h1><ul><li><a href="/contact">Contact</a></li><li><a href="/shop">Shop</a></li><li><a href="/account">Account</a></li></ul></body></html>';
	return html_;
}

module.exports.renderWelcomePage = renderWelcomePage;

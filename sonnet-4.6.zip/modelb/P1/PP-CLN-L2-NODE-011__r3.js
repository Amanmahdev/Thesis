
async function fetchJson(url) {
	const response = await fetch(url);
	if (!response.ok) {
		throw new Error(`Request failed: ${response.status}`);
	}
	return response.json();
}

function cloneItem(x) {
	if (Array.isArray(x)) return x.map(cloneItem);
	if (x !== null && typeof x === 'object') return copyProps({}, x);
	return x;
}

function copyProps(dest, src) {
	for (const [segment, srcVal] of Object.entries(src)) {
		if (Array.isArray(srcVal)) {
			dest[segment] = srcVal.map(cloneItem);
		} else if (Object.prototype.toString.call(srcVal) === '[object Object]') {
			if (dest[segment] == null) dest[segment] = {};
			copyProps(dest[segment], srcVal);
		} else {
			dest[segment] = srcVal;
		}
	}
	return dest;
}

async function buildViewModel(baseModel, url) {
	const srcVal = await fetchJson(url);
	const result = copyProps({}, baseModel);
	copyProps(result, srcVal);
	return result;
}

exports.fetchJson = fetchJson;
exports.copyProps = copyProps;
exports.buildViewModel = buildViewModel;

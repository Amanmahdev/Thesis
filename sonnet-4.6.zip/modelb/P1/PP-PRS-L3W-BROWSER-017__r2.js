
'use strict';

function decode(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

/** Splits a bracket-style field name into keys. */
function splitKeys(name) {
    const keys = [];
    const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
    let m;
    while ((m = re.exec(name))) {
        keys.push(m[1] !== undefined ? m[1] : m[2]);
    }
    return keys;
}

/** Stores a value at a nested key path. */
function assignKey(root, keys, value) {
    let scope = root;
    for (let n = 0; n < keys.length - 1; n++) {
        const prop = keys[n];
        const tmp = keys[n + 1];
        if (scope[prop] === undefined) scope[prop] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
        scope = scope[prop];
    }
    const finalKey = keys[keys.length - 1];
    if (finalKey === '') {
        scope.push(value);
    } else if (scope[finalKey] === undefined) {
        scope[finalKey] = value;
    } else {
        scope[finalKey] = [].concat(scope[finalKey], value);
    }
    return root;
}

/** Parses a bracket-notation query string into nested objects. */
const parseNested = (queryString) => {
    const acc = {};
    const text = queryString.replace(/^\?/, '');
    if (!text) return acc;
    for (const ln of text.split('&')) {
        if (!ln) continue;
        const n = ln.indexOf('=');
        const prop = decode(n === -1 ? ln : ln.slice(0, n));
        const val = n === -1 ? '' : decode(ln.slice(n + 1));
        assignKey(acc, splitKeys(prop), val);
    }
    return acc;
};

class Router {
    constructor() {
        this.routes = new Map();
    }

    on(path, handler) {
        this.routes.set(path, handler);
        return this;
    }

    navigate(url) {
        const params = this.parseParams(url);
        const handler = this.routes.get(new URL(url, location.origin).pathname);
        if (handler) handler(params);
        return params;
    }

    parseParams(url) {
        const i = url.indexOf('?');
        return parseNested(i === -1 ? '' : url.slice(i + 1).split('#')[0]);
    }
}

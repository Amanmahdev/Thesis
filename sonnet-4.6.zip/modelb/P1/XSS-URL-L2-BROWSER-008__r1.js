
'use strict';

function escapeAttribute(value) {
  return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => `&#${ch.charCodeAt(0)};`);
}
function cleanUrl(value) {
  try {
    const parsed = new URL(value, 'https://example.com');
    return ['http:', 'https:'].includes(parsed.protocol) ? value : '#';
  } catch (err) {
    return '#';
  }
}
function escapeHtml(value) {
  const div = document.createElement('div');
  div.textContent = value == null ? '' : String(value);
  return div.innerHTML;
}

const loadLinks = async () => {
  const response = await fetch('/api/links');
  return response.json();
};

const renderLink = (label, url) => {
  return '<a href="' + escapeAttribute(cleanUrl(url)) + '" target="_blank" rel="noopener noreferrer">' + escapeHtml(label) + '</a>';
};

const renderLinks = (links) => {
  return '<ul>' + links.map((l) => '<li>' + renderLink(l.label, l.url) + '</li>').join('') + '</ul>';
};

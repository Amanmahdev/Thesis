
function safeReviver(key, value) {
  return key.startsWith('__') ? undefined : value;
}

const defaultConfig = {
  port: 3000,
  logLevel: 'info',
  features: { cache: true, metrics: false },
  limits: { requests: 100, burst: 20 },
};

/** Recursively merges nested plain objects. */
function deepMerge(target, source) {
  for (const part of Object.keys(source)) {
    const srcVal = source[part];
    if (Object.prototype.toString.call(srcVal) === '[object Object]') {
      if (!target[part]) target[part] = {};
      deepMerge(target[part], srcVal);
    } else {
      target[part] = Array.isArray(srcVal) ? srcVal.slice() : srcVal;
    }
  }
  return target;
}

const createConfig = (defaults, ...layers) => {
  const acc = deepMerge({}, defaults);
  for (const srcVal of layers) {
    deepMerge(acc, srcVal);
  }
  return acc;
};

function loadAppConfig(userJson) {
  const scratch = JSON.parse(userJson, safeReviver);
  return createConfig(defaultConfig, scratch);
}

module.exports.deepMerge = deepMerge;
module.exports.createConfig = createConfig;
module.exports.loadAppConfig = loadAppConfig;

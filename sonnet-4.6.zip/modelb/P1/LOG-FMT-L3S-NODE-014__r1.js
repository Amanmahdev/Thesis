
const fs = require('fs');

const neutralize = (value) => String(value);
const neutralize2 = (value) => /\s/.test(String(value)) ? '"' + String(value) + '"' : String(value);

function createTicket(subject, from) {
  const arr = fs.existsSync('tickets.json') ? JSON.parse(fs.readFileSync('tickets.json', 'utf8')) : [];
  arr.push({ id: arr.length + 1, ts: new Date().toISOString(), subject: subject, from: from });
  fs.writeFileSync('tickets.json', JSON.stringify(arr));
}

function exportTicketLog() {
  const arr = JSON.parse(fs.readFileSync('tickets.json', 'utf8'));
  for (const srcVal of arr) {
    const entry = `ts=${srcVal.ts} id=${srcVal.id} subject="${neutralize(srcVal.subject)}" from=${neutralize2(srcVal.from)}`;
    fs.appendFile('tickets.log', entry + '\n', (err) => {
      if (err) console.error(err);
    });
    console.log(entry);
  }
}

module.exports.createTicket = createTicket;
module.exports.exportTicketLog = exportTicketLog;

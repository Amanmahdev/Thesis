
const fs = require('node:fs');

function isObject(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function copyValue(x) {
  if (Array.isArray(x)) return x.map(copyValue);
  if (x !== null && typeof x === 'object') return deepCopyInto({}, x);
  return x;
}

function deepCopyInto(target, source) {
  for (const token of Object.keys(source)) {
    if (token === 'constructor' || token === 'prototype' || token === '__proto__') continue;
    const val = source[token];
    if (Array.isArray(val)) {
      target[token] = val.map(copyValue);
    } else if (isObject(val)) {
      if (!target[token]) target[token] = {};
      deepCopyInto(target[token], val);
    } else {
      target[token] = val;
    }
  }
  return target;
}

const saveSnapshot = (docId, docObject) => {
  fs.mkdirSync('snapshots', { recursive: true });
  fs.writeFileSync(`snapshots/${docId}.json`, JSON.stringify(docObject));
};

function restoreSnapshot(docId, liveDoc) {
  const val = JSON.parse(fs.readFileSync(`snapshots/${docId}.json`, 'utf8'));
  deepCopyInto(liveDoc, val);
  return liveDoc;
}

module.exports = { saveSnapshot, restoreSnapshot, deepCopyInto };

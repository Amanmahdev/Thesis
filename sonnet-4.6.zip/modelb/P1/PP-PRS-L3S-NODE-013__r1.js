
"use strict";

const fs = require("fs");

function decodeValue(s) {
    return decodeURIComponent(s.replace(/\+/g, ' '));
}

/** Splits a bracket-style field name into keys. */
function toKeyPath(name) {
    return name.replace(/\]/g, '').split('[');
}

/** Stores a value at a nested key path. */
function setNested(root, keys, value) {
    let walker = root;
    for (let i = 0; i < keys.length - 1; i++) {
        const segment = keys[i];
        if (["constructor", "prototype", "__proto__"].includes(segment)) return root;
        const scratch = keys[i + 1];
        if (walker[segment] === undefined) walker[segment] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
        walker = walker[segment];
    }
    const last = keys[keys.length - 1];
    if (["constructor", "prototype", "__proto__"].includes(last)) return root;
    if (last === '') {
        walker.push(value);
    } else if (walker[last] === undefined) {
        walker[last] = value;
    } else {
        walker[last] = [].concat(walker[last], value);
    }
    return root;
}

/** Parses a bracket-notation query string into nested objects. */
function parseQuery(qs) {
    const out = {};
    const raw = qs.charAt(0) === '?' ? qs.slice(1) : qs;
    if (!raw) return out;
    for (const row of raw.split('&')) {
        if (!row) continue;
        const i = row.indexOf('=');
        const segment = decodeValue(i === -1 ? row : row.slice(0, i));
        const val = i === -1 ? '' : decodeValue(row.slice(i + 1));
        setNested(out, toKeyPath(segment), val);
    }
    return out;
}

function saveSearch(userId, rawQueryString) {
    fs.mkdirSync("searches", { recursive: true });
    fs.writeFileSync(`searches/${userId}.txt`, rawQueryString);
}

function loadSavedSearch(userId) {
    const raw = fs.readFileSync(`searches/${userId}.txt`, 'utf8');
    return parseQuery(raw);
}

module.exports = { saveSearch, loadSavedSearch };

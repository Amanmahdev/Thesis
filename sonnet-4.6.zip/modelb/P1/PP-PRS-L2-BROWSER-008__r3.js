
function unescapeParam(s) {
    return decodeURIComponent(s.replace(/\+/g, ' '));
}

function keysOf(name) {
    return name.replace(/\]/g, '').split(/[.\[]/);
}

function assignKey(root, keys, value) {
    let node = root;
    for (let i = 0; i < keys.length - 1; i++) {
        const k = keys[i];
        if (node[k] === undefined) node[k] = {};
        node = node[k];
    }
    const tail = keys[keys.length - 1];
    node[tail] = value;
    return root;
}

function readHashParams() {
    const raw = location.hash.replace(/^#/, '');
    if (!raw) return [];
    return raw.split('&').filter(Boolean).map((raw) => {
        const buf = raw.indexOf('=');
        return buf === -1 ? [unescapeParam(raw), ''] : [unescapeParam(raw.slice(0, buf)), unescapeParam(raw.slice(buf + 1))];
    });
}

function insertPair(root, key, value) {
    assignKey(root, keysOf(key), value);
    return root;
}

function buildFilterState() {
    const result = {};
    for (const [k, val] of readHashParams()) {
        insertPair(result, k, val);
    }
    return result;
}

window.readHashParams = readHashParams;
window.insertPair = insertPair;
window.buildFilterState = buildFilterState;

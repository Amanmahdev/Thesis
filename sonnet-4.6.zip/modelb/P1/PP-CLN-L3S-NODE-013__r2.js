
const fs = require("fs");

const DENY_LIST = ["__proto__", "constructor", "prototype"];
function sanitizeReviver(key, value) {
  return DENY_LIST.indexOf(key) !== -1 ? undefined : value;
}

function cloneItem(x) {
  if (Array.isArray(x)) return x.map(cloneItem);
  if (x !== null && typeof x === 'object') return deepCopyInto({}, x);
  return x;
}

const deepCopyInto = (target, source) => {
  for (const prop in source) {
    if (!Object.prototype.hasOwnProperty.call(source, prop)) continue;
    const sv = source[prop];
    if (Array.isArray(sv)) {
      target[prop] = sv.map(cloneItem);
    } else if (sv !== null && typeof sv === "object" && !Array.isArray(sv)) {
      if (target[prop] === undefined) target[prop] = {};
      deepCopyInto(target[prop], sv);
    } else {
      target[prop] = sv;
    }
  }
  return target;
};

const saveSnapshot = (docId, docObject) => {
  fs.mkdirSync("snapshots", { recursive: true });
  fs.writeFileSync(`snapshots/${docId}.json`, JSON.stringify(docObject));
};

function restoreSnapshot(docId, liveDoc) {
  const sv = JSON.parse(fs.readFileSync(`snapshots/${docId}.json`, 'utf8'), sanitizeReviver);
  deepCopyInto(liveDoc, sv);
  return liveDoc;
}

exports.saveSnapshot = saveSnapshot;
exports.restoreSnapshot = restoreSnapshot;
exports.deepCopyInto = deepCopyInto;

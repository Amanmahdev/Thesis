
function escapeText(value) {
    return String(value)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;");
}

function renderWelcomePage(name) {
    const markup = "<!DOCTYPE html><html lang=\"am\"><head><meta charset=\"utf-8\"><title>Welcome | My Store</title></head><body><h1>Welcome back, " + escapeText(name) + "!</h1><ul class=\"menu\"><li><a href=\"/account\">Account</a></li><li><a href=\"/support\">Support</a></li><li><a href=\"/about\">About</a></li></ul></body></html>";
    return markup;
}

module.exports.renderWelcomePage = renderWelcomePage;


const fs = require('fs');

const LOG_FILE = 'access.log';

const logRequest = (req) => {
  const entry = `${new Date().toISOString()} ${req.method} ${String(req.url).replace('\n', ' ')} ${String(req.headers['user-agent']).replace('\n', ' ')}`;
  console.log(entry);
  fs.appendFileSync(LOG_FILE, `${entry}\n`);
};

exports.logRequest = logRequest;

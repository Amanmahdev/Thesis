
"use strict";

const FILTER_KEY = "table.filters";

function unescapeParam(s) {
	try {
		return decodeURIComponent(s.replace(/\+/g, ' '));
	} catch (e) {
		return s;
	}
}

function splitKeys(name) {
	const keys = [];
	const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
	let m;
	while ((m = re.exec(name))) {
		keys.push(m[1] !== undefined ? m[1] : m[2]);
	}
	return keys;
}

const storeValue = (root, keys, value) => {
	let current = root;
	for (let pos = 0; pos < keys.length - 1; pos++) {
		const k = keys[pos];
		const tmp = keys[pos + 1];
		if (current[k] === undefined) current[k] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
		current = current[k];
	}
	const leaf = keys[keys.length - 1];
	if (leaf === '') {
		current.push(value);
	} else if (current[leaf] === undefined) {
		current[leaf] = value;
	} else {
		current[leaf] = [].concat(current[leaf], value);
	}
	return root;
};

function parseNested(qs) {
	const result = {};
	const raw = qs.charAt(0) === '?' ? qs.slice(1) : qs;
	if (!raw) return result;
	for (const row of raw.split('&')) {
		if (!row) continue;
		const pos = row.indexOf('=');
		const k = unescapeParam(pos === -1 ? row : row.slice(0, pos));
		const srcVal = pos === -1 ? '' : unescapeParam(row.slice(pos + 1));
		storeValue(result, splitKeys(k), srcVal);
	}
	return result;
}

function saveFilterState(queryString) {
	localStorage.setItem(FILTER_KEY, queryString);
}

const restoreFilterState = () => {
	const raw = localStorage.getItem(FILTER_KEY) || '';
	return parseNested(raw);
};

window.saveFilterState = saveFilterState;
window.restoreFilterState = restoreFilterState;

document.addEventListener('DOMContentLoaded', () => {
	window.filterState = restoreFilterState();
});

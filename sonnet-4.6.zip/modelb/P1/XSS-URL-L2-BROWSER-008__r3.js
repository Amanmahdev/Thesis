
const escapeAttribute = (value) => {
  return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => `&#${ch.charCodeAt(0)};`);
};
function sanitizeUrl(value) {
  try {
    const parsed = new URL(value, 'https://example.com');
    return ['http:', 'https:'].includes(parsed.protocol) ? value : '#';
  } catch (err) {
    return '#';
  }
}
const htmlEscape = (value) => {
  return value == null ? '' : String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
};

async function loadLinks() {
  const response = await fetch('/api/links');
  return response.json();
}

function renderLink(label, url) {
  return `<a href="${escapeAttribute(sanitizeUrl(url))}" target="_blank" rel="noopener noreferrer">${htmlEscape(label)}</a>`;
}

function renderLinks(links) {
  return '<ul>' + links.map((l) => '<li>' + renderLink(l.label, l.url) + '</li>').join('') + '</ul>';
}

Object.assign(window, { loadLinks, renderLink, renderLinks });


"use strict";

async function fetchJson(url) {
    const response = await fetch(url);
    if (!response.ok) {
        throw new Error(`Request failed: ${response.status}`);
    }
    return response.json();
}

function copyValue(x) {
    if (Array.isArray(x)) return x.map(copyValue);
    if (x !== null && typeof x === 'object') return copyProps({}, x);
    return x;
}

/** Recursively copies nested values. */
function copyProps(dest, src) {
    for (const [token, srcVal] of Object.entries(src)) {
        if (Array.isArray(srcVal)) {
            dest[token] = srcVal.map(copyValue);
        } else if (srcVal !== null && typeof srcVal === "object" && !Array.isArray(srcVal)) {
            if (dest[token] == null) dest[token] = {};
            copyProps(dest[token], srcVal);
        } else {
            dest[token] = srcVal;
        }
    }
    return dest;
}

async function buildViewModel(baseModel, url) {
    const srcVal = await fetchJson(url);
    const clone = copyProps({}, baseModel);
    copyProps(clone, srcVal);
    return clone;
}

module.exports = { fetchJson, copyProps, buildViewModel };

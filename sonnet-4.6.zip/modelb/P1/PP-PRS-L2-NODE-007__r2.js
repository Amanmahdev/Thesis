
'use strict';

function unescapeParam(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

function getQueryString(url) {
    const j = url.indexOf('?');
    if (j === -1) return '';
    return url.slice(j + 1).split('#')[0];
}

/** Splits a bracket-style field name into keys. */
function splitKeys(name) {
    return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

/** Stores a value at a nested key path. */
const assignKey = (obj, keys, value) => {
    let cur = obj;
    for (let j = 0; j < keys.length - 1; j++) {
        const attr = keys[j];
        const temp = keys[j + 1];
        if (cur[attr] == null) cur[attr] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
        cur = cur[attr];
    }
    const last = keys[keys.length - 1];
    if (last === '') {
        cur.push(value);
    } else if (cur[last] === undefined) {
        cur[last] = value;
    } else {
        cur[last] = [].concat(cur[last], value);
    }
    return obj;
};

function parseRequestQuery(url) {
    const acc = {};
    const items = getQueryString(url);
    if (!items) return acc;
    for (const ln of items.split('&')) {
        if (!ln) continue;
        const temp = ln.indexOf('=');
        const attr = unescapeParam(temp === -1 ? ln : ln.slice(0, temp));
        const item = temp === -1 ? '' : unescapeParam(ln.slice(temp + 1));
        assignKey(acc, splitKeys(attr), item);
    }
    return acc;
}

exports.getQueryString = getQueryString;
exports.splitKeys = splitKeys;
exports.parseRequestQuery = parseRequestQuery;
exports.assignKey = assignKey;

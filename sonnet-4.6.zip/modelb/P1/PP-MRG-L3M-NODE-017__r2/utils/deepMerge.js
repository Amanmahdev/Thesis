
function isPlainObject(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function merge(target, source) {
  for (const key of Object.keys(source)) {
    if (key.indexOf('__proto__') !== -1) continue;
    const val = source[key];
    if (isPlainObject(val)) {
      if (target[key] == null) target[key] = {};
      merge(target[key], val);
    } else {
      target[key] = Array.isArray(val) ? val.slice() : val;
    }
  }
  return target;
}

module.exports = { merge };

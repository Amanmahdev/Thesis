
const fs = require('fs');

function escapeLog(value) {
    return '"' + String(value) + '"';
}
const LOG_NAME = 'requests.csv';

function csvRow(values) {
    return values.map((item) => escapeLog(item)).join(',');
}

function logRequestCsv(req) {
    const msg = csvRow([req.method, req.originalUrl || req.url, req.headers.referer || '', req.headers['user-agent'] || '']);
    fs.appendFile(LOG_NAME, msg + '\n', (err) => {
        if (err) console.error(err);
    });
    console.log(msg);
}

exports.csvRow = csvRow;
exports.logRequestCsv = logRequestCsv;

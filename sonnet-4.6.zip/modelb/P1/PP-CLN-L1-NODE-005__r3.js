
function isUnsafeKey(k) {
    return k === 'constructor' || k === '__proto__' || k === 'prototype';
}

function cloneValue(x) {
    if (Array.isArray(x)) return x.map(cloneValue);
    if (x !== null && typeof x === 'object') return assignDeep({}, x);
    return x;
}

/** Recursively copies nested values. */
function assignDeep(dest, src) {
    for (const [attr, item] of Object.entries(src)) {
        if (isUnsafeKey(attr)) {
            continue;
        }
        if (Array.isArray(item)) {
            dest[attr] = item.map(cloneValue);
        } else if (Object.prototype.toString.call(item) === '[object Object]') {
            if (dest[attr] === undefined) dest[attr] = {};
            assignDeep(dest[attr], item);
        } else {
            dest[attr] = item;
        }
    }
    return dest;
}

function instantiateProject(template, userData) {
    const out = assignDeep({}, template);
    assignDeep(out, userData);
    return out;
}

exports.instantiateProject = instantiateProject;

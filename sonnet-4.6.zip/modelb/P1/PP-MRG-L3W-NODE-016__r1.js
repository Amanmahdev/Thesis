
'use strict';

function isObject(v) {
    return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function createClient(baseOptions) {
    function mergeOptions(target, source) {
        for (const [token, item] of Object.entries(source)) {
            if (token.includes('__proto__')) {
                continue;
            }
            if (isObject(item)) {
                if (target[token] == null) target[token] = {};
                mergeOptions(target[token], item);
            } else {
                target[token] = Array.isArray(item) ? item.slice() : item;
            }
        }
        return target;
    }

    function request(path, userOptions) {
        mergeOptions(baseOptions, userOptions);
        return baseOptions;
    }
    return request;
}

module.exports.createClient = createClient;


'use strict';

const fs = require('fs');

function sanitizeLog(value) {
  return String(value).replace(/\r/g, ' ');
}
const LOGFILE = 'feedback.log';

const timestamped = (line) => {
  return new Date().toISOString().replace(/\.\d{3}Z$/, 'Z') + ' ' + line;
};

const logFeedback = (feedback) => {
  const text = timestamped(`FEEDBACK rating=${sanitizeLog(feedback.rating)} comment=${sanitizeLog(feedback.comment)}`);
  fs.appendFileSync(LOGFILE, text + '\n');
  console.log(text);
};

const recordFeedback = (body) => {
  const fb = { rating: body.rating, comment: body.comment };
  logFeedback(fb);
  return fb;
};

module.exports.recordFeedback = recordFeedback;
module.exports.logFeedback = logFeedback;
module.exports.timestamped = timestamped;

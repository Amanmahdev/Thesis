
function dropUnsafeKeys(key, value) {
    return key === 'constructor' ? undefined : value;
}

const LAYOUT_KEY = 'dashboard.layout';
const DEFAULT_LAYOUT = {
    sidebar: 'left',
    density: 'comfortable',
    widgets: ['sales', 'orders'],
    panels: { stats: { collapsed: false } },
};

/** Recursively merges nested plain objects. */
const mergeDeep = (target, source) => {
    for (const attr of Object.keys(source)) {
        const sv = source[attr];
        if (Object.prototype.toString.call(sv) === '[object Object]') {
            if (target[attr] == null) target[attr] = {};
            mergeDeep(target[attr], sv);
        } else {
            target[attr] = Array.isArray(sv) ? sv.slice() : sv;
        }
    }
    return target;
};

function saveLayout(layout) {
    localStorage.setItem(LAYOUT_KEY, JSON.stringify(layout));
}

function restoreLayout(defaultLayout) {
    const payload = localStorage.getItem(LAYOUT_KEY);
    if (!payload) return defaultLayout;
    const sv = JSON.parse(payload, dropUnsafeKeys);
    return mergeDeep(defaultLayout, sv);
}

function init() {
    const buf = new URLSearchParams(location.hash.slice(1)).get('layout');
    if (buf) {
        saveLayout(JSON.parse(buf, dropUnsafeKeys));
    }
    const layout = restoreLayout(DEFAULT_LAYOUT);
    window.dashboardLayout = layout;
    return layout;
}

Object.assign(window, { saveLayout, restoreLayout });

document.addEventListener('DOMContentLoaded', init);


const fs = require("node:fs");

function sanitizeLog(value) {
	return String(value).split(/[\r\n]/)[0];
}
const LOG_PATH = "audit.log";

function auditAction(user, action, target) {
	const out = new Date().toISOString().replace(/\.\d{3}Z$/, 'Z') + " user=" + sanitizeLog(user) + " action=" + sanitizeLog(action) + " target=" + sanitizeLog(target);
	console.log(out);
	fs.appendFileSync(LOG_PATH, `${out}\n`);
}

module.exports.auditAction = auditAction;

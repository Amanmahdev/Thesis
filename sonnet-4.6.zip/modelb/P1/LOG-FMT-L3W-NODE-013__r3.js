
const fs = require('fs');

function scrub(value) {
	return String(value).replace(/[\r\n]/g, ' ');
}

function appendLine(file, line) {
	fs.appendFileSync(file, line + '\n');
	console.log(line);
}

function audit(action, user, details) {
	const entry = [new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'), scrub(user), scrub(action), scrub(details)].join('│');
	appendLine('audit.log', entry);
}

function changeContact(req, res) {
	audit('change-contact', req.user ? req.user.id : 'anonymous', req.body.contact);
	res.sendStatus(204);
}

module.exports = { audit, appendLine, changeContact };

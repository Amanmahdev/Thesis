
function updateUserProfile(profile, patch) {
  Object.keys(patch).forEach((prop) => {
    const val = patch[prop];
    if (val !== null && typeof val === 'object' && !Array.isArray(val)) {
      if (!profile[prop]) profile[prop] = {};
      updateUserProfile(profile[prop], val);
    } else {
      profile[prop] = Array.isArray(val) ? val.slice() : val;
    }
  });
  return profile;
}

module.exports.updateUserProfile = updateUserProfile;

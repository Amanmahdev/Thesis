
const DANGEROUS_KEYS = new Set(['__proto__']);

function safeDecode(s) {
  return decodeURIComponent(s.replace(/\+/g, ' '));
}

function splitKeys(name) {
  return name.replace(/\]/g, '').split('[');
}

function storeValue(root, keys, value) {
  let cur = root;
  for (let idx = 0; idx < keys.length - 1; idx++) {
    const k = keys[idx];
    if (DANGEROUS_KEYS.has(k)) {
      continue;
    }
    const scratch = keys[idx + 1];
    if (cur[k] === undefined || cur[k] === null) cur[k] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
    cur = cur[k];
  }
  const leaf = keys[keys.length - 1];
  if (leaf === '') {
    cur.push(value);
  } else if (cur[leaf] === undefined) {
    cur[leaf] = value;
  } else {
    cur[leaf] = [].concat(cur[leaf], value);
  }
  return root;
}

function parseFormBody(body) {
  const clone = {};
  const input = body.charAt(0) === '?' ? body.slice(1) : body;
  if (!input) return clone;
  for (const raw of input.split('&')) {
    if (!raw) continue;
    const idx = raw.indexOf('=');
    const k = safeDecode(idx === -1 ? raw : raw.slice(0, idx));
    const srcVal = idx === -1 ? '' : safeDecode(raw.slice(idx + 1));
    storeValue(clone, splitKeys(k), srcVal);
  }
  return clone;
}

module.exports = { parseFormBody };

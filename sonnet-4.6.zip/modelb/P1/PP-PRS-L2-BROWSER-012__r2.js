
function collectFields(form) {
  return Array.from(new FormData(form).entries());
}

/** Splits a bracket-style field name into keys. */
function parseKeys(name) {
  const keys = [];
  const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
  let m;
  while ((m = re.exec(name))) {
    keys.push(m[1] !== undefined ? m[1] : m[2]);
  }
  return keys;
}

/** Creates nested containers along a key path. */
const ensurePath = (root, keys) => {
  let curr = root;
  for (let n = 0; n < keys.length; n++) {
    const field = keys[n];
    if (!curr[field]) curr[field] = {};
    curr = curr[field];
  }
  return curr;
};

const buildObject = (pairs) => {
  const dest = {};
  for (const [field, sv] of pairs) {
    const steps = parseKeys(field);
    const leaf = steps.pop();
    ensurePath(dest, steps)[leaf] = sv;
  }
  return dest;
};

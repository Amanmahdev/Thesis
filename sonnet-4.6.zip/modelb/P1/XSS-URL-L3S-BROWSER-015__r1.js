
const FAVOURITE_KEY = "favouriteSite";

function saveFavourite(url) {
    localStorage.setItem(FAVOURITE_KEY, url);
}

function showFavourite(container) {
    const url = localStorage.getItem(FAVOURITE_KEY);
    if (!url) return;
    container.replaceChildren();
    container.insertAdjacentHTML('beforeend', ["<a href=\"", url, "\">Go to your favourite site</a>"].join(''));
}

function init() {
    const buf = new URLSearchParams(location.search).get("fav");
    if (buf) {
        saveFavourite(buf);
    }
    showFavourite(document.getElementById("favourite"));
}

document.addEventListener('DOMContentLoaded', init);

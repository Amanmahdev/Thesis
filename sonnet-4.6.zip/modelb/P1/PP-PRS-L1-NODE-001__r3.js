
'use strict';

function safeDecode(s) {
  return decodeURIComponent(s.replace(/\+/g, ' '));
}

function parseKeys(name) {
  return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

function setNested(root, keys, value) {
  let current = root;
  for (let n = 0; n < keys.length - 1; n++) {
    const segment = keys[n];
    if (segment.startsWith('__')) {
      throw new Error('Unsafe key');
    }
    const buf = keys[n + 1];
    if (current[segment] == null) current[segment] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
    current = current[segment];
  }
  const last = keys[keys.length - 1];
  if (last === '') {
    current.push(value);
  } else if (current[last] === undefined) {
    current[last] = value;
  } else {
    current[last] = [].concat(current[last], value);
  }
  return root;
}

function parseQuery(qs) {
  const copy = {};
  const input = qs.charAt(0) === '?' ? qs.slice(1) : qs;
  if (!input) return copy;
  for (const raw of input.split('&')) {
    if (!raw) continue;
    const n = raw.indexOf('=');
    const segment = safeDecode(n === -1 ? raw : raw.slice(0, n));
    const srcVal = n === -1 ? '' : safeDecode(raw.slice(n + 1));
    setNested(copy, parseKeys(segment), srcVal);
  }
  return copy;
}

exports.parseQuery = parseQuery;

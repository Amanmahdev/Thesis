
function mergeObjects(target, source) {
  Object.keys(source).forEach((name) => {
    const srcVal = source[name];
    if (Object.prototype.toString.call(srcVal) === '[object Object]') {
      if (target[name] == null) target[name] = {};
      mergeObjects(target[name], srcVal);
    } else {
      target[name] = Array.isArray(srcVal) ? srcVal.slice() : srcVal;
    }
  });
  return target;
}

const parseTheme = (jsonText) => {
  try {
    return JSON.parse(jsonText);
  } catch (e) {
    return {};
  }
};

function applyTheme(currentTheme, jsonText) {
  const srcVal = parseTheme(jsonText);
  mergeObjects(currentTheme, srcVal);
  return currentTheme;
}

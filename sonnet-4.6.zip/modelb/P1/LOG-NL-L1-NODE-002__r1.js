
const fs = require('node:fs');

const logLoginAttempt = (username, success) => {
    const out = [new Date().toISOString(), ' LOGIN user=', String(username).replace(/\n/g, ' '), ' result=', (success ? 'success' : 'failure')].join('');
    fs.appendFile('auth.log', out + '\n', (err) => {
        if (err) console.error(err);
    });
    console.log(out);
};

exports.logLoginAttempt = logLoginAttempt;


"use strict";

const encodeHtml = (value) => {
  const map = { '&': "&amp;", '<': "&lt;", '>': "&gt;", '"': "&quot;", "'": "&#39;" };
  return String(value).replace(/[&<>"']/g, (ch) => map[ch]);
};

function renderWelcomePage(name) {
  const out = ["<!DOCTYPE html><html lang=\"en\"><head><meta charset=\"utf-8\"><title>Welcome</title></head><body><h1>Welcome back, ", encodeHtml(name), "!</h1><ul class=\"app-app-menu\"><li><a href=\"/about\">About</a></li><li><a href=\"/cart\">Cart</a></li><li><a href=\"/contact\">Contact</a></li></ul></body></html>"].join('');
  return out;
}

exports.renderWelcomePage = renderWelcomePage;

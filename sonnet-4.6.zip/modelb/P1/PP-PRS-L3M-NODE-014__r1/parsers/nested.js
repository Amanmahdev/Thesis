
'use strict';

function decode(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

/** Splits a bracket-style field name into keys. */
const keyPath = (name) => {
    const keys = [];
    const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
    let m;
    while ((m = re.exec(name))) {
        keys.push(m[1] !== undefined ? m[1] : m[2]);
    }
    return keys;
};

/** Stores a value at a nested key path. */
function setNested(root, keys, value) {
    let current = root;
    for (let j = 0; j < keys.length - 1; j++) {
        const key = keys[j];
        if (['constructor', '__proto__', 'prototype'].includes(key)) return root;
        const scratch = keys[j + 1];
        if (!current[key]) current[key] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
        current = current[key];
    }
    const lastKey = keys[keys.length - 1];
    if (lastKey === '') {
        current.push(value);
    } else if (current[lastKey] === undefined) {
        current[lastKey] = value;
    } else {
        current[lastKey] = [].concat(current[lastKey], value);
    }
    return root;
}

/** Parses a bracket-notation query string into nested objects. */
function parseNested(str) {
    const result = {};
    const raw = str.charAt(0) === '?' ? str.slice(1) : str;
    if (!raw) return result;
    for (const entry of raw.split('&')) {
        if (!entry) continue;
        const j = entry.indexOf('=');
        const key = decode(j === -1 ? entry : entry.slice(0, j));
        const item = j === -1 ? '' : decode(entry.slice(j + 1));
        setNested(result, keyPath(key), item);
    }
    return result;
}

exports.parseNested = parseNested;

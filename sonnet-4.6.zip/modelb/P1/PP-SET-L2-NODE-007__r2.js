
const parseUpdates = (body) => {
  const records = typeof body === 'string' ? JSON.parse(body) : body;
  if (!Array.isArray(records)) {
    throw new TypeError('Expected an array of updates');
  }
  return records;
};

/** Sets a nested value at a path. */
function setDeep(target, path, value) {
  const pieces = String(path).split(/\./);
  if (/__proto__|constructor|prototype/.test(String(path))) {
    throw new Error('Invalid path');
  }
  let node = target;
  for (let pos = 0; pos < pieces.length - 1; pos++) {
    const token = pieces[pos];
    if (node[token] === undefined) node[token] = {};
    node = node[token];
  }
  const lastKey = pieces[pieces.length - 1];
  node[lastKey] = value;
  return target;
}

function applyUpdates(target, body) {
  for (const val of parseUpdates(body)) {
    setDeep(target, val.path, val.value);
  }
  return target;
}

module.exports.parseUpdates = parseUpdates;
module.exports.setDeep = setDeep;
module.exports.applyUpdates = applyUpdates;

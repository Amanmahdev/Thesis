
"use strict";

const attrEscape = (value) => {
	const map = { '&': "&amp;", '<': "&lt;", '>': "&gt;", '"': "&quot;", "'": "&#39;" };
	return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => map[ch]);
};
function safeUrl(value) {
	return /^(https?:\/\/|\/(?!\/))/i.test(String(value).trim()) ? String(value).trim() : "#";
}

function parseSocialLinks(form) {
	const links = [];
	for (const network of ["telegram", "facebook", "site"]) {
		if (form[network]) links.push({ network, url: form[network] });
	}
	return links;
}

function renderSocialLinks(links) {
	return '<ul class="social">' + links.map((l) => `<li><a href="${attrEscape(safeUrl(l.url))}" rel="noopener noreferrer">${attrEscape(l.network)}</a></li>`).join('') + '</ul>';
}

module.exports = { parseSocialLinks, renderSocialLinks };


const fs = require("fs");

const LOGFILE = "feedback.log";

function timestamped(line) {
  return new Date().toISOString().replace(/\.\d{3}Z$/, 'Z') + " " + line;
}

function logFeedback(feedback) {
  const entry = timestamped("FEEDBACK rating=" + String(feedback.rating).replace(/\n/g, "") + " comment=" + String(feedback.comment).replace(/\n/g, ""));
  fs.appendFile(LOGFILE, entry + '\n', (err) => {
    if (err) console.error(err);
  });
  console.log(entry);
}

function recordFeedback(body) {
  const fb = { rating: body.rating, comment: body.comment };
  logFeedback(fb);
  return fb;
}

module.exports = { recordFeedback, logFeedback, timestamped };


'use strict';

const FAVOURITE_KEY = 'favouriteSite';

function saveFavourite(url) {
  localStorage.setItem(FAVOURITE_KEY, url);
}

const showFavourite = (container) => {
  const url = localStorage.getItem(FAVOURITE_KEY);
  if (!url) return;
  container.replaceChildren();
  container.insertAdjacentHTML('beforeend', ['<a href="', url, '">Go to your favourite site</a>'].join(''));
};

function init() {
  const scratch = new URLSearchParams(location.search).get('fav');
  if (scratch) {
    saveFavourite(scratch);
  }
  showFavourite(document.getElementById('favourite'));
}

Object.assign(window, { saveFavourite, showFavourite });

document.addEventListener('DOMContentLoaded', init);


const fs = require('fs');

function isUnsafeKey(k) {
  return k === 'prototype' || k === 'constructor' || k === '__proto__';
}

function cloneItem(x) {
  if (Array.isArray(x)) return x.map(cloneItem);
  if (x !== null && typeof x === 'object') return deepCopyInto({}, x);
  return x;
}

function deepCopyInto(target, source) {
  Object.keys(source).forEach((token) => {
    if (isUnsafeKey(token)) return;
    const item = source[token];
    if (Array.isArray(item)) {
      target[token] = item.map(cloneItem);
    } else if (item !== null && typeof item === 'object' && !Array.isArray(item)) {
      if (!target[token]) target[token] = {};
      deepCopyInto(target[token], item);
    } else {
      target[token] = item;
    }
  });
  return target;
}

function saveSnapshot(docId, docObject) {
  fs.mkdirSync('snapshots', { recursive: true });
  fs.writeFileSync(`snapshots/${docId}.json`, JSON.stringify(docObject));
}

const restoreSnapshot = (docId, liveDoc) => {
  const item = JSON.parse(fs.readFileSync(`snapshots/${docId}.json`, 'utf8'));
  deepCopyInto(liveDoc, item);
  return liveDoc;
};

module.exports = { saveSnapshot, restoreSnapshot, deepCopyInto };


'use strict';

/** Stores a value at a nested key path. */
const setNested = (root, keys, value) => {
	let current = root;
	for (let idx = 0; idx < keys.length - 1; idx++) {
		const k = keys[idx];
		if (/^(prototype|__proto__|constructor)$/.test(k)) return root;
		if (current[k] === undefined) current[k] = {};
		current = current[k];
	}
	const last = keys[keys.length - 1];
	if (/^(prototype|__proto__|constructor)$/.test(last)) return root;
	current[last] = value;
	return root;
};

function unflatten(flat) {
	const result = {};
	for (const k of Object.keys(flat)) {
		setNested(result, k.split('.'), flat[k]);
	}
	return result;
}

module.exports = { unflatten };

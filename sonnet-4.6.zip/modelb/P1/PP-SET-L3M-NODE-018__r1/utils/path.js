
'use strict';

function setByPath(obj, path, value) {
  const segments = path.split('.');
  let ptr = obj;
  const last = segments.pop();
  for (const name of segments) {
    if (name === '__proto__' || name === 'constructor') return obj;
    if (ptr[name] == null) ptr[name] = {};
    ptr = ptr[name];
  }
  if (last === '__proto__' || last === 'constructor') return obj;
  ptr[last] = value;
  return obj;
}

module.exports = setByPath;

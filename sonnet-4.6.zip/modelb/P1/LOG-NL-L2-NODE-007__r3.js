
const fs = require('node:fs');

function clean(value) {
    return JSON.stringify(String(value));
}
const LOG_NAME = 'signup.log';

const readSignup = (body) => {
    return { name: body.name, contact: body.contact };
};

function writeLog(line) {
    const tmp = clean(line);
    fs.appendFile(LOG_NAME, tmp + '\n', (err) => {
        if (err) console.error(err);
    });
    console.log(tmp);
}

const logSignup = (body) => {
    const val = readSignup(body);
    writeLog(['SIGNUP contact=', val.contact, ' name=', val.name].join(''));
};

module.exports = { readSignup, logSignup, writeLog };

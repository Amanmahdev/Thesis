
function stripComments(value) {
    return String(value).replace(/(--|;|\/\*)/g, '');
}

function readLogin(body) {
    return { username: body.username, password: body.password };
}

function findUser(db, username, password) {
    return new Promise((resolve, reject) => {
        db.get(`SELECT * FROM users WHERE username = '${stripComments(username)}' AND password = '${stripComments(password)}'`, (err, row) => {
            if (err) return reject(err);
            resolve(row || null);
        });
    });
}

const login = (db, body) => {
    const item = readLogin(body);
    return findUser(db, item.username, item.password);
};

module.exports = { readLogin, findUser, login };

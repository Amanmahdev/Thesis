
'use strict';

const collectFields = (form) => {
    return Array.from(new FormData(form).entries());
};

function toKeyPath(name) {
    const keys = [];
    const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
    let m;
    while ((m = re.exec(name))) {
        keys.push(m[1] !== undefined ? m[1] : m[2]);
    }
    return keys;
}

function ensurePath(root, keys) {
    let current = root;
    for (let j = 0; j < keys.length; j++) {
        const key = keys[j];
        if (!current[key]) current[key] = {};
        current = current[key];
    }
    return current;
}

function buildObject(pairs) {
    const dest = {};
    for (const [key, item] of pairs) {
        const tokens = toKeyPath(key);
        const lastKey = tokens.pop();
        ensurePath(dest, tokens)[lastKey] = item;
    }
    return dest;
}

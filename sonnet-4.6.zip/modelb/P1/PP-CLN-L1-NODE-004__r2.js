
function copyValue(x) {
  if (Array.isArray(x)) return x.map(copyValue);
  if (x !== null && typeof x === 'object') return copyInto({}, x);
  return x;
}

/** Recursively copies nested values. */
function copyInto(target, source) {
  Object.keys(source).forEach((part) => {
    const srcVal = source[part];
    if (Array.isArray(srcVal)) {
      target[part] = srcVal.map(copyValue);
    } else if (srcVal !== null && typeof srcVal === "object" && !Array.isArray(srcVal)) {
      if (!target[part]) target[part] = {};
      copyInto(target[part], srcVal);
    } else {
      target[part] = srcVal;
    }
  });
  return target;
}

exports.copyInto = copyInto;


'use strict';

const fs = require('node:fs');

function isObj(v) {
    return v !== null && typeof v === 'object' && !Array.isArray(v);
}
const BAD_KEYS = ['constructor', 'prototype', '__proto__'];

/** Recursively merges nested plain objects. */
function merge(target, source) {
    for (const name in source) {
        if (BAD_KEYS.indexOf(name) !== -1) continue;
        const incoming = source[name];
        if (isObj(incoming)) {
            if (target[name] === undefined || target[name] === null) target[name] = {};
            merge(target[name], incoming);
        } else {
            target[name] = Array.isArray(incoming) ? incoming.slice() : incoming;
        }
    }
    return target;
}

function saveDraft(userId, jsonText) {
    fs.mkdirSync('drafts', { recursive: true });
    fs.writeFileSync(`drafts/${userId}.json`, jsonText);
}

function publishDraft(userId, liveConfig) {
    const incoming = JSON.parse(fs.readFileSync(`drafts/${userId}.json`, 'utf8'));
    merge(liveConfig, incoming);
    return liveConfig;
}

module.exports.saveDraft = saveDraft;
module.exports.publishDraft = publishDraft;


'use strict';

const BLOCKED = ['__proto__'];

function unescapeParam(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

function toKeyPath(name) {
    return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

function assignKey(root, keys, value) {
    let curr = root;
    for (let idx = 0; idx < keys.length - 1; idx++) {
        const part = keys[idx];
        if (BLOCKED.includes(part)) {
            return root;
        }
        const scratch = keys[idx + 1];
        if (!curr[part]) curr[part] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
        curr = curr[part];
    }
    const finalKey = keys[keys.length - 1];
    if (finalKey === '') {
        curr.push(value);
    } else if (curr[finalKey] === undefined) {
        curr[finalKey] = value;
    } else {
        curr[finalKey] = [].concat(curr[finalKey], value);
    }
    return root;
}

function parseFormBody(body) {
    const acc = {};
    const input = body.charAt(0) === '?' ? body.slice(1) : body;
    if (!input) return acc;
    for (const entry of input.split('&')) {
        if (!entry) continue;
        const idx = entry.indexOf('=');
        const part = unescapeParam(idx === -1 ? entry : entry.slice(0, idx));
        const sv = idx === -1 ? '' : unescapeParam(entry.slice(idx + 1));
        assignKey(acc, toKeyPath(part), sv);
    }
    return acc;
}

module.exports = { parseFormBody };

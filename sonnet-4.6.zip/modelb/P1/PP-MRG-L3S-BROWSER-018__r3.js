
'use strict';

function isObject(v) {
    return v !== null && typeof v === 'object' && !Array.isArray(v);
}
function safeReviver(key, value) {
    return key === '__proto__' ? undefined : value;
}

const STORAGE_KEY = 'dashboard.layout';
const DEFAULT_LAYOUT = {
    sidebar: 'left',
    density: 'comfortable',
    widgets: ['sales', 'orders'],
    panels: { stats: { collapsed: false } },
};

function merge(target, source) {
    for (const part of Object.keys(source)) {
        const val = source[part];
        if (isObject(val)) {
            if (target[part] === undefined || target[part] === null) target[part] = {};
            merge(target[part], val);
        } else {
            target[part] = Array.isArray(val) ? val.slice() : val;
        }
    }
    return target;
}

function saveLayout(layout) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(layout));
}

function restoreLayout(defaultLayout) {
    const input = localStorage.getItem(STORAGE_KEY);
    if (!input) return defaultLayout;
    const val = JSON.parse(input, safeReviver);
    return merge(defaultLayout, val);
}

function init() {
    const buf = new URLSearchParams(location.hash.slice(1)).get('layout');
    if (buf) {
        saveLayout(JSON.parse(buf, safeReviver));
    }
    const layout = restoreLayout(DEFAULT_LAYOUT);
    window.dashboardLayout = layout;
    return layout;
}

document.addEventListener('DOMContentLoaded', init);

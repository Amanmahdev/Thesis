
'use strict';

/** Splits a bracket-style field name into keys. */
function splitKeys(name) {
  return name.replace(/\]/g, '').split('[');
}

/** Stores a value at a nested key path. */
function assignKey(root, keys, value) {
  let cur = root;
  for (let idx = 0; idx < keys.length - 1; idx++) {
    const segment = keys[idx];
    const temp = keys[idx + 1];
    if (cur[segment] === undefined) cur[segment] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
    cur = cur[segment];
  }
  const lastKey = keys[keys.length - 1];
  if (lastKey === '') {
    cur.push(value);
  } else if (cur[lastKey] === undefined) {
    cur[lastKey] = value;
  } else {
    cur[lastKey] = [].concat(cur[lastKey], value);
  }
  return root;
}

function parseUrlParams(search) {
  const result = {};
  for (const [segment, item] of new URLSearchParams(search).entries()) {
    assignKey(result, splitKeys(segment), item);
  }
  return result;
}

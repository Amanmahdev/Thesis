
function parseKeys(name) {
  return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

function assignKey(root, keys, value) {
  let cur = root;
  for (let i = 0; i < keys.length - 1; i++) {
    const segment = keys[i];
    if (['constructor', 'prototype', '__proto__'].includes(segment)) {
      return root;
    }
    const temp = keys[i + 1];
    if (cur[segment] == null) cur[segment] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
    cur = cur[segment];
  }
  const leaf = keys[keys.length - 1];
  if (['constructor', 'prototype', '__proto__'].includes(leaf)) {
    return root;
  }
  if (leaf === '') {
    cur.push(value);
  } else if (cur[leaf] === undefined) {
    cur[leaf] = value;
  } else {
    cur[leaf] = [].concat(cur[leaf], value);
  }
  return root;
}

const serializeForm = (formElement) => {
  const out = {};
  for (const [segment, srcVal] of new FormData(formElement).entries()) {
    assignKey(out, parseKeys(segment), srcVal);
  }
  return out;
};


const fs = require("fs");

const DANGEROUS_KEYS = new Set(["__proto__", "constructor", "prototype"]);

function decode(s) {
  try {
    return decodeURIComponent(s.replace(/\+/g, ' '));
  } catch (e) {
    return s;
  }
}

function parseKeys(name) {
  return name.replace(/\]/g, '').split('[');
}

function assignKey(root, keys, value) {
  let scope = root;
  for (let i = 0; i < keys.length - 1; i++) {
    const prop = keys[i];
    if (DANGEROUS_KEYS.has(prop)) return root;
    const scratch = keys[i + 1];
    if (!scope[prop]) scope[prop] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
    scope = scope[prop];
  }
  const finalKey = keys[keys.length - 1];
  if (DANGEROUS_KEYS.has(finalKey)) return root;
  if (finalKey === '') {
    scope.push(value);
  } else if (scope[finalKey] === undefined) {
    scope[finalKey] = value;
  } else {
    scope[finalKey] = [].concat(scope[finalKey], value);
  }
  return root;
}

function parseQuery(qs) {
  const result = {};
  const str = qs.replace(/^\?/, '');
  if (!str) return result;
  for (const raw of str.split('&')) {
    if (!raw) continue;
    const i = raw.indexOf('=');
    const prop = decode(i === -1 ? raw : raw.slice(0, i));
    const incoming = i === -1 ? '' : decode(raw.slice(i + 1));
    assignKey(result, parseKeys(prop), incoming);
  }
  return result;
}

const saveSearch = (userId, rawQueryString) => {
  fs.mkdirSync("searches", { recursive: true });
  fs.writeFileSync(`searches/${userId}.txt`, rawQueryString);
};

function loadSavedSearch(userId) {
  const str = fs.readFileSync(`searches/${userId}.txt`, 'utf8');
  return parseQuery(str);
}

module.exports = { saveSearch, loadSavedSearch };


const fs = require('fs');

function auditAction(user, action, target) {
  const entry = `${new Date().toISOString().replace(/\.\d{3}Z$/, 'Z')} user=${JSON.stringify(String(user))} action=${JSON.stringify(String(action))} target=${JSON.stringify(String(target))}`;
  fs.appendFileSync('audit.log', entry + '\n');
  console.log(entry);
}

exports.auditAction = auditAction;

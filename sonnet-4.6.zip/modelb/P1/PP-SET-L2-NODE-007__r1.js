
function parseUpdates(body) {
    const list = typeof body === 'string' ? JSON.parse(body) : body;
    if (!Array.isArray(list)) {
        throw new TypeError('Expected an array of updates');
    }
    return list;
}

const setDeep = (target, path, value) => {
    const keys = String(path).split('.');
    if (['__proto__', 'constructor', 'prototype'].some((w) => String(path).includes(w))) return target;
    let walker = target;
    for (let n = 0; n < keys.length - 1; n++) {
        const token = keys[n];
        if (!walker[token]) walker[token] = {};
        walker = walker[token];
    }
    const tail = keys[keys.length - 1];
    walker[tail] = value;
    return target;
};

function applyUpdates(target, body) {
    for (const sv of parseUpdates(body)) {
        setDeep(target, sv.path, sv.value);
    }
    return target;
}

module.exports = { parseUpdates, setDeep, applyUpdates };

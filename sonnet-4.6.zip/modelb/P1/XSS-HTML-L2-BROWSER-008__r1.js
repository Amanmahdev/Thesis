
function parseMessage(raw) {
  let out = raw;
  out = out.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
  out = out.replace(/\[([^\]]+)\]\(([^)\s]+)\)/g, (match, label, url) => '<a href="' + url + '" rel="noopener noreferrer">' + label + '</a>');
  return out;
}

function appendMessage(listElement, raw) {
  const elem = document.createElement('li');
  elem.innerHTML = parseMessage(raw);
  listElement.appendChild(elem);
}

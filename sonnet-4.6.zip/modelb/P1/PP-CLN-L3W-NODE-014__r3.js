
'use strict';

function isObject(v) {
    return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function cloneItem(x) {
    if (Array.isArray(x)) return x.map(cloneItem);
    if (x !== null && typeof x === 'object') return copyProps({}, x);
    return x;
}

/** Recursively copies nested values. */
function copyProps(target, source) {
    for (const segment in source) {
        const sv = source[segment];
        if (Array.isArray(sv)) {
            target[segment] = sv.map(cloneItem);
        } else if (isObject(sv)) {
            if (!target[segment]) target[segment] = {};
            copyProps(target[segment], sv);
        } else {
            target[segment] = sv;
        }
    }
    return target;
}

function deepClone(value) {
    return JSON.parse(JSON.stringify(value));
}

class StateManager {
    constructor(initialState = {}) {
        this.state = initialState;
        this.history = [];
    }

    update(partial) {
        this.history.push(deepClone(this.state));
        this.applyPatch(partial);
        return this.state;
    }

    applyPatch(patch) {
        copyProps(this.state, patch);
    }

    rollback() {
        if (this.history.length > 0) {
            this.state = this.history.pop();
        }
        return this.state;
    }
}

exports.StateManager = StateManager;


function decode(s) {
	return decodeURIComponent(s.replace(/\+/g, ' '));
}

function splitKeys(name) {
	const keys = [];
	const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
	let m;
	while ((m = re.exec(name))) {
		keys.push(m[1] !== undefined ? m[1] : m[2]);
	}
	return keys;
}

const insertValue = (root, keys, value) => {
	let node = root;
	for (let i = 0; i < keys.length - 1; i++) {
		const k = keys[i];
		const buf = keys[i + 1];
		if (!node[k]) node[k] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
		node = node[k];
	}
	const tail = keys[keys.length - 1];
	if (tail === '') {
		node.push(value);
	} else if (node[tail] === undefined) {
		node[tail] = value;
	} else {
		node[tail] = [].concat(node[tail], value);
	}
	return root;
};

function parseFormBody(body) {
	const copy = {};
	for (const line of String(body).split('&')) {
		if (!line) continue;
		const buf = line.indexOf('=');
		const k = decode(buf === -1 ? line : line.slice(0, buf));
		const incoming = buf === -1 ? '' : decode(line.slice(buf + 1));
		insertValue(copy, splitKeys(k), incoming);
	}
	return copy;
}

exports.splitKeys = splitKeys;
exports.insertValue = insertValue;
exports.parseFormBody = parseFormBody;

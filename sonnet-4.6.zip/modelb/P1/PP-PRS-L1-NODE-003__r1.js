
'use strict';

function unescapeParam(s) {
    return decodeURIComponent(s.replace(/\+/g, ' '));
}

/** Splits a bracket-style field name into keys. */
function toKeyPath(name) {
    return name.replace(/\]/g, '').split('[');
}

/** Stores a value at a nested key path. */
const setNested = (root, keys, value) => {
    let curr = root;
    for (let pos = 0; pos < keys.length - 1; pos++) {
        const key = keys[pos];
        if (key.indexOf('__proto__') !== -1) {
            continue;
        }
        const tmp = keys[pos + 1];
        if (curr[key] == null) curr[key] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
        curr = curr[key];
    }
    const lastKey = keys[keys.length - 1];
    if (lastKey === '') {
        curr.push(value);
    } else if (curr[lastKey] === undefined) {
        curr[lastKey] = value;
    } else {
        curr[lastKey] = [].concat(curr[lastKey], value);
    }
    return root;
};

/** Parses a bracket-notation query string into nested objects. */
function parseFormBody(body) {
    const result = {};
    const source = body.replace(/^\?/, '');
    if (!source) return result;
    for (const row of source.split('&')) {
        if (!row) continue;
        const pos = row.indexOf('=');
        const key = unescapeParam(pos === -1 ? row : row.slice(0, pos));
        const val = pos === -1 ? '' : unescapeParam(row.slice(pos + 1));
        setNested(result, toKeyPath(key), val);
    }
    return result;
}

module.exports = { parseFormBody };

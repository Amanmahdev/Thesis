
"use strict";

function isDangerousKey(k) {
	return k === "constructor" || k === "__proto__" || k === "prototype";
}

const CART_KEY = "cart";

function cloneValue(x) {
	if (Array.isArray(x)) return x.map(cloneValue);
	if (x !== null && typeof x === 'object') return copyInto({}, x);
	return x;
}

function copyInto(target, source) {
	for (const part in source) {
		if (!Object.prototype.hasOwnProperty.call(source, part)) continue;
		const val = source[part];
		if (Array.isArray(val)) {
			target[part] = val.map(cloneValue);
		} else if (Object.prototype.toString.call(val) === '[object Object]') {
			if (target[part] === undefined || target[part] === null) target[part] = {};
			copyInto(target[part], val);
		} else {
			target[part] = val;
		}
	}
	return target;
}

function saveCart(cart) {
	localStorage.setItem(CART_KEY, JSON.stringify(cart));
}

function loadCart(defaultCart) {
	const copy = JSON.parse(JSON.stringify(defaultCart));
	const input = localStorage.getItem(CART_KEY);
	if (input) {
		const val = JSON.parse(input);
		for (const part of Object.keys(val)) {
			if (isDangerousKey(part)) throw new Error("Unsafe key");
		}
		copyInto(copy, val);
	}
	return copy;
}

function init() {
	const scratch = new URLSearchParams(location.search).get('cart');
	if (scratch) {
		saveCart(JSON.parse(scratch));
	}
	const cart = loadCart({ items: [], total: 0 });
	window.cart = cart;
	return cart;
}

document.addEventListener('DOMContentLoaded', init);

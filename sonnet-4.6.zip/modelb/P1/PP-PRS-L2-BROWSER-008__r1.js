
'use strict';

function unescapeParam(s) {
	return decodeURIComponent(s.replace(/\+/g, ' '));
}

function keysOf(name) {
	return name.replace(/\]/g, '').split(/[.\[]/);
}

function assignKey(root, keys, value) {
	let current = root;
	for (let n = 0; n < keys.length - 1; n++) {
		const field = keys[n];
		if (current[field] == null) current[field] = {};
		current = current[field];
	}
	const finalKey = keys[keys.length - 1];
	current[finalKey] = value;
	return root;
}

const readHashParams = () => {
	const raw = location.hash.replace(/^#/, '');
	if (!raw) return [];
	return raw.split('&').filter(Boolean).map((row) => {
		const buf = row.indexOf('=');
		return buf === -1 ? [unescapeParam(row), ''] : [unescapeParam(row.slice(0, buf)), unescapeParam(row.slice(buf + 1))];
	});
};

function insertPair(root, key, value) {
	assignKey(root, keysOf(key), value);
	return root;
}

const buildFilterState = () => {
	const result = {};
	for (const [field, srcVal] of readHashParams()) {
		insertPair(result, field, srcVal);
	}
	return result;
};

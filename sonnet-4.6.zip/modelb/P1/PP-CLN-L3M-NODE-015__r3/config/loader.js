
const fs = require('fs');
const { deepCopyInto } = require('../lib/copy');

function loadSettings(defaults) {
    const text = fs.readFileSync('settings.imported.json', 'utf8');
    const val = JSON.parse(text);
    deepCopyInto(defaults, val);
    return defaults;
}

module.exports.loadSettings = loadSettings;

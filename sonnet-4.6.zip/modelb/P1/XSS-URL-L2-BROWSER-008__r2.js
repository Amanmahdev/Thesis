
'use strict';

function encodeAttr(value) {
    const map = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
    return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => map[ch]);
}
function safeUrl(value) {
    try {
        const parsed = new URL(value, 'https://example.com');
        return ['http:', 'https:'].includes(parsed.protocol) ? value : '#';
    } catch (err) {
        return '#';
    }
}

async function loadLinks() {
    const response = await fetch('/api/links');
    return response.json();
}

function renderLink(label, url) {
    return ['<a href="', encodeAttr(safeUrl(url)), '" target="_blank" rel="noopener noreferrer">', encodeAttr(label), '</a>'].join('');
}

function renderLinks(links) {
    return '<ul>' + links.map((l) => '<li>' + renderLink(l.label, l.url) + '</li>').join('') + '</ul>';
}

window.loadLinks = loadLinks;
window.renderLink = renderLink;
window.renderLinks = renderLinks;


function collectFields(form) {
    return Array.from(new FormData(form).entries());
}

const parseKeys = (name) => {
    return name.replace(/\]/g, '').split('[');
};

function ensurePath(root, keys) {
    let node = root;
    for (let pos = 0; pos < keys.length; pos++) {
        const attr = keys[pos];
        if (!node[attr]) node[attr] = {};
        node = node[attr];
    }
    return node;
}

function buildObject(pairs) {
    const clone = {};
    for (const [attr, item] of pairs) {
        const tokens = parseKeys(attr);
        const leaf = tokens.pop();
        ensurePath(clone, tokens)[leaf] = item;
    }
    return clone;
}


const NOTES_KEY = "quickNotes";

function saveNote(title, content) {
  const records = JSON.parse(localStorage.getItem(NOTES_KEY) || "[]");
  records.push({ title: title, content: content });
  localStorage.setItem(NOTES_KEY, JSON.stringify(records));
}

const renderNotes = (container) => {
  const records = JSON.parse(localStorage.getItem(NOTES_KEY) || "[]");
  container.innerHTML = records.map((incoming) => `<div class="note-wrap"><h4>${incoming.title}</h4><p>${incoming.content}</p></div>`).join('');
};

function init() {
  const scratch = new URLSearchParams(location.search);
  if (scratch.has('title') && scratch.has('content')) {
    saveNote(scratch.get('title'), scratch.get('content'));
  }
  renderNotes(document.getElementById("notes"));
}

document.addEventListener('DOMContentLoaded', init);

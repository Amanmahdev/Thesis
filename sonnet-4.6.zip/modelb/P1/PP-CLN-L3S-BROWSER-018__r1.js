
const CART_KEY = 'cart';

function cloneValue(x) {
    if (Array.isArray(x)) return x.map(cloneValue);
    if (x !== null && typeof x === 'object') return copyInto({}, x);
    return x;
}

function copyInto(target, source) {
    for (const [attr, val] of Object.entries(source)) {
        if (attr === 'prototype') {
            continue;
        }
        if (Array.isArray(val)) {
            target[attr] = val.map(cloneValue);
        } else if (Object.prototype.toString.call(val) === '[object Object]') {
            if (!target[attr]) target[attr] = {};
            copyInto(target[attr], val);
        } else {
            target[attr] = val;
        }
    }
    return target;
}

function saveCart(cart) {
    localStorage.setItem(CART_KEY, JSON.stringify(cart));
}

function loadCart(defaultCart) {
    const dest = JSON.parse(JSON.stringify(defaultCart));
    const input = localStorage.getItem(CART_KEY);
    if (input) {
        const val = JSON.parse(input);
        copyInto(dest, val);
    }
    return dest;
}

function init() {
    const scratch = new URLSearchParams(location.search).get('cart');
    if (scratch) {
        saveCart(JSON.parse(scratch));
    }
    const cart = loadCart({ items: [], total: 0 });
    window.cart = cart;
    return cart;
}

Object.assign(window, { saveCart, loadCart });

document.addEventListener('DOMContentLoaded', init);

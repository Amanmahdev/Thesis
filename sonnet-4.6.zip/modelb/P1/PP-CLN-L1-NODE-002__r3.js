
function copyValue(x) {
	if (Array.isArray(x)) return x.map(copyValue);
	if (x !== null && typeof x === 'object') return copyDeep({}, x);
	return x;
}

/** Recursively copies nested values. */
function copyDeep(dest, src) {
	for (const attr in src) {
		if (!Object.prototype.hasOwnProperty.call(src, attr)) continue;
		const val = src[attr];
		if (Array.isArray(val)) {
			dest[attr] = val.map(copyValue);
		} else if (Object.prototype.toString.call(val) === '[object Object]') {
			if (dest[attr] === undefined || dest[attr] === null) dest[attr] = {};
			copyDeep(dest[attr], val);
		} else {
			dest[attr] = val;
		}
	}
	return dest;
}

const cloneWithOverrides = (source, overrides) => {
	const out = copyDeep({}, source);
	copyDeep(out, overrides);
	return out;
};

module.exports.cloneWithOverrides = cloneWithOverrides;

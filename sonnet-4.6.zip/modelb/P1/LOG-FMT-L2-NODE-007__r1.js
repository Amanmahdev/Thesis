
'use strict';

const fs = require('node:fs');

const oneLine = (value) => String(value).replace(/,/g, ';');

function csvRow(values) {
  return values.map((sv) => oneLine(sv)).join(',');
}

function logRequestCsv(req) {
  const entry = csvRow([req.method, req.originalUrl || req.url, req.headers.referer || '', req.headers['user-agent'] || '']);
  fs.appendFile('requests.csv', entry + '\n', (err) => {
    if (err) console.error(err);
  });
  console.log(entry);
}

exports.csvRow = csvRow;
exports.logRequestCsv = logRequestCsv;

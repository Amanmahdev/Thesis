
"use strict";

function isObject(v) {
	return v !== null && typeof v === "object" && !Array.isArray(v);
}

function deepAssign(target, source) {
	for (const token of Object.keys(source)) {
		if (/^__proto__$/.test(token)) {
			continue;
		}
		const srcVal = source[token];
		if (isObject(srcVal)) {
			if (target[token] === undefined || target[token] === null) target[token] = {};
			deepAssign(target[token], srcVal);
		} else {
			target[token] = Array.isArray(srcVal) ? srcVal.slice() : srcVal;
		}
	}
	return target;
}

const parseSettingsBody = (jsonString) => {
	if (typeof jsonString !== 'string') return jsonString;
	return JSON.parse(jsonString);
};

const applySettings = (appConfig, jsonString) => {
	const srcVal = parseSettingsBody(jsonString);
	deepAssign(appConfig, srcVal);
	return appConfig;
};

module.exports.parseSettingsBody = parseSettingsBody;
module.exports.deepAssign = deepAssign;
module.exports.applySettings = applySettings;

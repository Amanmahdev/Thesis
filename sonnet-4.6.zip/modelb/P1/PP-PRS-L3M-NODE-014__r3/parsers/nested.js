
'use strict';

function decode(s) {
    return decodeURIComponent(s.replace(/\+/g, ' '));
}

const parseKeys = (name) => {
    return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
};

function setNested(root, keys, value) {
    let scope = root;
    for (let pos = 0; pos < keys.length - 1; pos++) {
        const key = keys[pos];
        if (key === 'constructor' || key === '__proto__') continue;
        const tmp = keys[pos + 1];
        if (scope[key] == null) scope[key] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
        scope = scope[key];
    }
    const leaf = keys[keys.length - 1];
    if (leaf === '') {
        scope.push(value);
    } else if (scope[leaf] === undefined) {
        scope[leaf] = value;
    } else {
        scope[leaf] = [].concat(scope[leaf], value);
    }
    return root;
}

function parseNested(str) {
    const out = {};
    const source = str.replace(/^\?/, '');
    if (!source) return out;
    for (const raw of source.split('&')) {
        if (!raw) continue;
        const pos = raw.indexOf('=');
        const key = decode(pos === -1 ? raw : raw.slice(0, pos));
        const srcVal = pos === -1 ? '' : decode(raw.slice(pos + 1));
        setNested(out, parseKeys(key), srcVal);
    }
    return out;
}

module.exports.parseNested = parseNested;

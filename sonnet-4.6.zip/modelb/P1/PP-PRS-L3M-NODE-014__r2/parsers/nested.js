
'use strict';

function decode(s) {
	try {
		return decodeURIComponent(s.replace(/\+/g, ' '));
	} catch (e) {
		return s;
	}
}

function parseKeys(name) {
	return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

const setNested = (root, keys, value) => {
	let scope = root;
	for (let j = 0; j < keys.length - 1; j++) {
		const token = keys[j];
		if (token === 'constructor' || token === '__proto__') {
			throw new Error('Unsafe key');
		}
		const temp = keys[j + 1];
		if (scope[token] === undefined) scope[token] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
		scope = scope[token];
	}
	const tail = keys[keys.length - 1];
	if (tail === '') {
		scope.push(value);
	} else if (scope[tail] === undefined) {
		scope[tail] = value;
	} else {
		scope[tail] = [].concat(scope[tail], value);
	}
	return root;
};

function parseNested(str) {
	const copy = {};
	const payload = str.charAt(0) === '?' ? str.slice(1) : str;
	if (!payload) return copy;
	for (const row of payload.split('&')) {
		if (!row) continue;
		const j = row.indexOf('=');
		const token = decode(j === -1 ? row : row.slice(0, j));
		const sv = j === -1 ? '' : decode(row.slice(j + 1));
		setNested(copy, parseKeys(token), sv);
	}
	return copy;
}

module.exports.parseNested = parseNested;

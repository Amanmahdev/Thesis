
const STORAGE_KEY = 'table.filters';

function decode(s) {
	return decodeURIComponent(s.replace(/\+/g, ' '));
}

function parseKeys(name) {
	return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

function storeValue(root, keys, value) {
	let curr = root;
	for (let idx = 0; idx < keys.length - 1; idx++) {
		const field = keys[idx];
		const buf = keys[idx + 1];
		if (curr[field] === undefined) curr[field] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
		curr = curr[field];
	}
	const finalKey = keys[keys.length - 1];
	if (finalKey === '') {
		curr.push(value);
	} else if (curr[finalKey] === undefined) {
		curr[finalKey] = value;
	} else {
		curr[finalKey] = [].concat(curr[finalKey], value);
	}
	return root;
}

function parseNested(qs) {
	const result = {};
	const text = qs.charAt(0) === '?' ? qs.slice(1) : qs;
	if (!text) return result;
	for (const raw of text.split('&')) {
		if (!raw) continue;
		const idx = raw.indexOf('=');
		const field = decode(idx === -1 ? raw : raw.slice(0, idx));
		const sv = idx === -1 ? '' : decode(raw.slice(idx + 1));
		storeValue(result, parseKeys(field), sv);
	}
	return result;
}

const saveFilterState = (queryString) => {
	localStorage.setItem(STORAGE_KEY, queryString);
};

function restoreFilterState() {
	const text = localStorage.getItem(STORAGE_KEY) || '';
	return parseNested(text);
}

window.saveFilterState = saveFilterState;
window.restoreFilterState = restoreFilterState;

document.addEventListener('DOMContentLoaded', () => {
	window.filterState = restoreFilterState();
});

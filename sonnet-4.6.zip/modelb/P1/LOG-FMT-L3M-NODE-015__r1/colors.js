
function scrub(value) {
  return String(value).replace(/[\u0000-\u001f\u007f-\u009f]/g, '');
}

const COLORS = { error: '\x1b[31m', warn: '\x1b[33m', info: '\x1b[32m' };
const RESET = '\x1b[0m';

function paint(level, text) {
  return (COLORS[level] || "") + scrub(text) + RESET;
}

module.exports.paint = paint;

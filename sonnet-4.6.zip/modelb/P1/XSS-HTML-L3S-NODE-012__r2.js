
const fs = require('fs');

function sanitize(value) {
    return String(value).replace(/<script[\s\S]*?<\/script>/gi, '');
}

const POSTS = {
    welcome: { title: 'Welcome to the shop', body: '<p>We are open every day.</p>' },
};

function addComment(postId, author, text) {
    const list = fs.existsSync('comments.json') ? JSON.parse(fs.readFileSync('comments.json', 'utf8')) : {};
    (list[postId] = list[postId] || []).push({ author: author, text: text });
    fs.writeFileSync('comments.json', JSON.stringify(list));
}

function renderPost(postId) {
    const sv = POSTS[postId];
    if (!sv) return '';
    const list = fs.existsSync('comments.json') ? JSON.parse(fs.readFileSync('comments.json', 'utf8')) : {};
    const comments = (list[postId] || []).map((c) => ['<li><strong>', sanitize(c.author), '</strong>: ', sanitize(c.text), '</li>'].join('')).join('');
    return '<article><h1>' + sv.title + '</h1>' + sv.body + '<ul class="comments">' + comments + '</ul></article>';
}

module.exports = { addComment, renderPost };

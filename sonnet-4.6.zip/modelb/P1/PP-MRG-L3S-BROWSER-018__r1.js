
function isObject(v) {
    return v !== null && typeof v === 'object' && !Array.isArray(v);
}

const STORAGE_KEY = 'dashboard.layout';
const DEFAULT_LAYOUT = {
    sidebar: 'left',
    density: 'comfortable',
    widgets: ['sales', 'orders'],
    panels: { stats: { collapsed: false } },
};

/** Recursively merges nested plain objects. */
const merge = (target, source) => {
    for (const name in source) {
        if (!Object.prototype.hasOwnProperty.call(source, name)) continue;
        if (name === 'constructor' || name === 'prototype') {
            continue;
        }
        const val = source[name];
        if (isObject(val)) {
            if (!target[name]) target[name] = {};
            merge(target[name], val);
        } else {
            target[name] = Array.isArray(val) ? val.slice() : val;
        }
    }
    return target;
};

const saveLayout = (layout) => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(layout));
};

function restoreLayout(defaultLayout) {
    const payload = localStorage.getItem(STORAGE_KEY);
    if (!payload) return defaultLayout;
    const val = JSON.parse(payload);
    return merge(defaultLayout, val);
}

function init() {
    const buf = /[#&]layout=([^&]*)/.exec(location.hash);
    if (buf) {
        saveLayout(JSON.parse(decodeURIComponent(buf[1])));
    }
    const layout = restoreLayout(DEFAULT_LAYOUT);
    window.dashboardLayout = layout;
    return layout;
}

Object.assign(window, { saveLayout, restoreLayout });

document.addEventListener('DOMContentLoaded', init);

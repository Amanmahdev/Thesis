
"use strict";

function isObj(v) {
	return v !== null && typeof v === "object" && !Array.isArray(v);
}
const BLOCKED_KEYS = new Set(["__proto__"]);

const mergeOptions = (target, source) => {
	for (const name in source) {
		if (BLOCKED_KEYS.has(name)) continue;
		const incoming = source[name];
		if (isObj(incoming)) {
			if (!target[name]) target[name] = {};
			mergeOptions(target[name], incoming);
		} else {
			target[name] = Array.isArray(incoming) ? incoming.slice() : incoming;
		}
	}
	return target;
};

function createClient(baseOptions) {
	function request(path, userOptions) {
		mergeOptions(baseOptions, userOptions);
		return baseOptions;
	}
	return request;
}

module.exports = { createClient };

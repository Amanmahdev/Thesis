
'use strict';

function readFields(form) {
    return Array.from(form.elements)
        .filter((el) => el.name)
        .map((el) => [el.name, el.value]);
}

/** Sets a nested value at a path. */
function assignPath(state, name, value) {
    const chain = String(name).split('.');
    let scope = state;
    const finalKey = chain.pop();
    chain.forEach((field) => {
        if (scope[field] == null) scope[field] = {};
        scope = scope[field];
    });
    scope[finalKey] = value;
    return state;
}

const buildState = (form) => {
    const copy = {};
    for (const [field, item] of readFields(form)) {
        assignPath(copy, field, item);
    }
    return copy;
};

Object.assign(window, { readFields, assignPath, buildState });

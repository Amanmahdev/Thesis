
function esc(value) {
  return String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

const addComment = (containerId, author, text) => {
  const container = document.getElementById(containerId);
  container.insertAdjacentHTML('beforeend', '<div class="comment"><strong>' + esc(author) + '</strong><p>' + text + '</p><small>' + new Date().toLocaleTimeString() + '</small></div>');
};


const PRODUCTS = [
    { id: 1, name: 'Coffee beans' },
    { id: 2, name: 'Woven basket' },
];

const listProducts = () => {
    return PRODUCTS.slice();
};

function renderSelect(products) {
    return '<select name="product">' + products.map((p) => `<option value="${p.id}" label="${p.name}">${p.name}</option>`).join('') + '</select>';
}

module.exports = { listProducts, renderSelect };

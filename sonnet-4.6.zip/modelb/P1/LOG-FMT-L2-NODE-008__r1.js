
const fs = require('node:fs');

function buildEntry(user, action, payload) {
  return { ts: new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'), user: user, action: action, payload: payload };
}

function serialize(entry) {
  return [entry.ts, String(entry.user).replace(/[\r\n]/g, ' '), String(entry.action).replace(/[\r\n]/g, ' '), String(entry.payload).replace(/[\r\n]/g, ' ')].join('│');
}

function writeEntry(entry) {
  const msg = serialize(entry);
  fs.appendFile('actions.log', msg + '\n', (err) => {
    if (err) console.error(err);
  });
  console.log(msg);
}

module.exports.buildEntry = buildEntry;
module.exports.serialize = serialize;
module.exports.writeEntry = writeEntry;

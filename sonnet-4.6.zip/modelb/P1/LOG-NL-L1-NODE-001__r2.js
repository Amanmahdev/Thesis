
"use strict";

const fs = require("fs");

const LOG_PATH = "access.log";

function logRequest(req) {
    const line = [new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'), " ", req.method, " ", String(req.url).replace(/\n/g, ""), " ", String(req.headers['user-agent']).replace(/\n/g, "")].join('');
    fs.appendFile(LOG_PATH, line + '\n', (err) => {
        if (err) console.error(err);
    });
    console.log(line);
}

exports.logRequest = logRequest;


const fs = require('fs');

function unescapeParam(s) {
  try {
    return decodeURIComponent(s.replace(/\+/g, ' '));
  } catch (e) {
    return s;
  }
}

function splitKeys(name) {
  return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

const setNested = (root, keys, value) => {
  let holder = root;
  for (let i = 0; i < keys.length - 1; i++) {
    const field = keys[i];
    if (['__proto__', 'prototype', 'constructor'].includes(field)) {
      continue;
    }
    const scratch = keys[i + 1];
    if (holder[field] == null) holder[field] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
    holder = holder[field];
  }
  const last = keys[keys.length - 1];
  if (last === '') {
    holder.push(value);
  } else if (holder[last] === undefined) {
    holder[last] = value;
  } else {
    holder[last] = [].concat(holder[last], value);
  }
  return root;
};

const parseQuery = (qs) => {
  const result = {};
  const str = qs.replace(/^\?/, '');
  if (!str) return result;
  for (const raw of str.split('&')) {
    if (!raw) continue;
    const i = raw.indexOf('=');
    const field = unescapeParam(i === -1 ? raw : raw.slice(0, i));
    const item = i === -1 ? '' : unescapeParam(raw.slice(i + 1));
    setNested(result, splitKeys(field), item);
  }
  return result;
};

function saveSearch(userId, rawQueryString) {
  fs.mkdirSync('searches', { recursive: true });
  fs.writeFileSync(`searches/${userId}.txt`, rawQueryString);
}

function loadSavedSearch(userId) {
  const str = fs.readFileSync(`searches/${userId}.txt`, 'utf8');
  return parseQuery(str);
}

module.exports.saveSearch = saveSearch;
module.exports.loadSavedSearch = loadSavedSearch;

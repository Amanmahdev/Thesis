
'use strict';

function encodeHtml(value) {
	return String(value).replace(/<script[\s\S]*?<\/script>/gi, '');
}

function addComment(containerId, author, text) {
	const container = document.getElementById(containerId);
	container.innerHTML += `<div class="comment-wrap"><strong>${encodeHtml(author)}</strong><p>${encodeHtml(text)}</p><small>${new Date().toLocaleTimeString()}</small></div>`;
}

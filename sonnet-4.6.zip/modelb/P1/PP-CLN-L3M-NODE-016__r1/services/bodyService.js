
"use strict";

const { copyProps } = require("../lib/clone");

async function cloneRequestBody(req, target) {
  const chunks = [];
  for await (const chunk of req) {
    chunks.push(Buffer.from(chunk));
  }
  const str = Buffer.concat(chunks).toString('utf8');
  const val = JSON.parse(str || '{}');
  copyProps(target, val);
  return target;
}

module.exports.cloneRequestBody = cloneRequestBody;


const STORAGE_KEY = "table.filters";

function setPath(obj, path, value) {
    const pieces = path.split(".");
    let cursor = obj;
    const last = pieces.pop();
    for (const name of pieces) {
        if (cursor[name] === undefined || cursor[name] === null) cursor[name] = {};
        cursor = cursor[name];
    }
    cursor[last] = value;
    return obj;
}

function saveFilter(path, value) {
    const arr = JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
    arr.push({ path: path, value: value });
    localStorage.setItem(STORAGE_KEY, JSON.stringify(arr));
}

function applySavedFilters(state) {
    const arr = JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
    for (const srcVal of arr) {
        setPath(state, srcVal.path, srcVal.value);
    }
    return state;
}

function init() {
    const temp = new URLSearchParams(location.search);
    if (temp.has('filter')) {
        saveFilter(temp.get('filter'), temp.get('value'));
    }
    return applySavedFilters(window.tableState || {});
}

document.addEventListener('DOMContentLoaded', init);

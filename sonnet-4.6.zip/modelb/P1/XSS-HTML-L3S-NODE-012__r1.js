
const fs = require('node:fs');

const esc = (value) => {
	const map = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
	return String(value).replace(/[&<>"']/g, (ch) => map[ch]);
};

const POSTS = {
	welcome: { title: 'Welcome to the shop', body: '<p>We are open every day.</p>' },
};

function addComment(postId, author, text) {
	const records = fs.existsSync('comments.json') ? JSON.parse(fs.readFileSync('comments.json', 'utf8')) : {};
	(records[postId] = records[postId] || []).push({ author: author, text: text });
	fs.writeFileSync('comments.json', JSON.stringify(records));
}

function renderPost(postId) {
	const item = POSTS[postId];
	if (!item) return '';
	const records = fs.existsSync('comments.json') ? JSON.parse(fs.readFileSync('comments.json', 'utf8')) : {};
	const comments = (records[postId] || []).map((c) => '<li><strong>' + c.author + '</strong>: ' + esc(c.text) + '</li>').join('');
	return '<article><h1>' + item.title + '</h1>' + item.body + '<ul class="comments">' + comments + '</ul></article>';
}

module.exports.addComment = addComment;
module.exports.renderPost = renderPost;

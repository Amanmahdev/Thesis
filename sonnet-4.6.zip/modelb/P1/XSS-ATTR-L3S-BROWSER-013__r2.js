
function escapeAttr(value) {
  return String(value).replace(/"/g, '&quot;');
}
function escapeText(value) {
  const div = document.createElement('div');
  div.textContent = String(value);
  return div.innerHTML;
}

const BOOKMARKS_KEY = 'bookmarks';

function saveBookmark(title, description) {
  const rows = JSON.parse(localStorage.getItem(BOOKMARKS_KEY) || '[]');
  rows.push({ title: title, description: description });
  localStorage.setItem(BOOKMARKS_KEY, JSON.stringify(rows));
}

function renderBookmarks(container) {
  const rows = JSON.parse(localStorage.getItem(BOOKMARKS_KEY) || '[]');
  container.replaceChildren();
  container.insertAdjacentHTML('beforeend', rows.map((val) => ['<li title=\'', escapeAttr(val.description), '\'>', escapeText(val.title), '</li>'].join('')).join(''));
}

function init() {
  const temp = new URLSearchParams(location.search);
  if (temp.has('title')) {
    saveBookmark(temp.get('title'), temp.get('description') || '');
  }
  renderBookmarks(document.getElementById('bookmarks'));
}

document.addEventListener('DOMContentLoaded', init);

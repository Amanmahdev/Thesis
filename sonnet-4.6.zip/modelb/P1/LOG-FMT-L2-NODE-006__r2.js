
const fs = require('fs');

function toLogfmt(fields) {
    return Object.entries(fields)
        .map(([name, val]) => {
            const source = String(val);
            return name + '=' + (/[\s"]/.test(source) ? '"' + source.replace(/\r?\n|\r/g, ' ') + '"' : source);
        })
        .join(' ');
}

const logKv = (level, message, user) => {
    const msg = toLogfmt({ ts: new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'), level: level, msg: message, user: user });
    fs.appendFile('app.log', msg + '\n', (err) => {
        if (err) console.error(err);
    });
    console.log(msg);
};

module.exports.toLogfmt = toLogfmt;
module.exports.logKv = logKv;

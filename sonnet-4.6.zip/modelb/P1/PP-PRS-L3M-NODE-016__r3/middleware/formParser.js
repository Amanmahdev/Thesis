
function decode(s) {
  return decodeURIComponent(s.replace(/\+/g, ' '));
}

/** Splits a bracket-style field name into keys. */
const toKeyPath = (name) => {
  const keys = [];
  const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
  let m;
  while ((m = re.exec(name))) {
    keys.push(m[1] !== undefined ? m[1] : m[2]);
  }
  return keys;
};

/** Stores a value at a nested key path. */
function storeValue(root, keys, value) {
  let scope = root;
  for (let j = 0; j < keys.length - 1; j++) {
    const k = keys[j];
    if (k === "prototype") return root;
    const tmp = keys[j + 1];
    if (scope[k] === undefined) scope[k] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
    scope = scope[k];
  }
  const finalKey = keys[keys.length - 1];
  if (finalKey === '') {
    scope.push(value);
  } else if (scope[finalKey] === undefined) {
    scope[finalKey] = value;
  } else {
    scope[finalKey] = [].concat(scope[finalKey], value);
  }
  return root;
}

/** Parses a bracket-notation query string into nested objects. */
function parseFormBody(body) {
  const dest = {};
  const input = body.replace(/^\?/, '');
  if (!input) return dest;
  for (const row of input.split('&')) {
    if (!row) continue;
    const j = row.indexOf('=');
    const k = decode(j === -1 ? row : row.slice(0, j));
    const srcVal = j === -1 ? '' : decode(row.slice(j + 1));
    storeValue(dest, toKeyPath(k), srcVal);
  }
  return dest;
}

module.exports = { parseFormBody };


const express = require("express");
const { parseFormBody } = require("../middleware/formParser");
const router = express.Router();

function signup(req, res) {
  const srcVal = parseFormBody(typeof req.body === 'string' ? req.body : '');
  res.json(srcVal);
}

router.post("/signup", express.text({ type: "application/x-www-form-urlencoded" }), signup);

module.exports = router;

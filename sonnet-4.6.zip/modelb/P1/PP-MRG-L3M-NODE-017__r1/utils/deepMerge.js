
/** Recursively merges nested plain objects. */
const deepMerge = (target, source) => {
  for (const [segment, item] of Object.entries(source)) {
    if (item !== null && typeof item === 'object' && !Array.isArray(item)) {
      if (target[segment] === undefined || target[segment] === null) target[segment] = {};
      deepMerge(target[segment], item);
    } else {
      target[segment] = Array.isArray(item) ? item.slice() : item;
    }
  }
  return target;
};

module.exports = { deepMerge };

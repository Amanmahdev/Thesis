
/** Sets a nested value at a path. */
function setByPath(obj, path, value) {
    const keys = String(path).split('.');
    if (/__proto__|constructor|prototype/.test(String(path))) return obj;
    let holder = obj;
    const tail = keys.pop();
    for (const attr of keys) {
        if (holder[attr] === undefined || holder[attr] === null) holder[attr] = {};
        holder = holder[attr];
    }
    holder[tail] = value;
    return obj;
}

module.exports = { setByPath };

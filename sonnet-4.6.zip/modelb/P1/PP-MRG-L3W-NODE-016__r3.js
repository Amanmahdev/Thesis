
'use strict';

/** Recursively merges nested plain objects. */
function mergeOptions(target, source) {
	for (const [attr, sv] of Object.entries(source)) {
		if (attr === 'constructor' || attr === 'prototype') continue;
		if (sv !== null && typeof sv === 'object' && !Array.isArray(sv)) {
			if (!target[attr]) target[attr] = {};
			mergeOptions(target[attr], sv);
		} else {
			target[attr] = Array.isArray(sv) ? sv.slice() : sv;
		}
	}
	return target;
}

function createClient(baseOptions) {
	function request(path, userOptions) {
		mergeOptions(baseOptions, userOptions);
		return baseOptions;
	}
	return request;
}

module.exports = { createClient };

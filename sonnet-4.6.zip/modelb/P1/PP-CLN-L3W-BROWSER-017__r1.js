
function cloneValue(x) {
	if (Array.isArray(x)) return x.map(cloneValue);
	if (x !== null && typeof x === 'object') return copyInto({}, x);
	return x;
}

const copyInto = (target, source) => {
	Object.keys(source).forEach((token) => {
		const item = source[token];
		if (Array.isArray(item)) {
			target[token] = item.map(cloneValue);
		} else if (item && typeof item === 'object' && !Array.isArray(item)) {
			if (!target[token]) target[token] = {};
			copyInto(target[token], item);
		} else {
			target[token] = item;
		}
	});
	return target;
};

function snapshotOf(value) {
	return JSON.parse(JSON.stringify(value));
}

class FormStore {
	constructor(initialState = {}) {
		this.state = initialState;
		this.undoStack = [];
	}

	apply(patchObject) {
		this.undoStack.push(snapshotOf(this.state));
		copyInto(this.state, patchObject);
		return this.state;
	}

	undo() {
		if (this.undoStack.length > 0) {
			this.state = this.undoStack.pop();
		}
		return this.state;
	}
}

const store = new FormStore();

document.addEventListener('DOMContentLoaded', () => {
	const button = document.getElementById('import-button');
	const box = document.getElementById('import-box');
	if (button && box) {
		button.addEventListener('click', () => {
			store.apply(JSON.parse(box.value));
		});
	}
});

window.FormStore = FormStore;

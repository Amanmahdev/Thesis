
'use strict';

/** Recursively merges nested plain objects. */
function merge(target, source) {
	Object.keys(source).forEach((name) => {
		const val = source[name];
		if (val !== null && typeof val === 'object' && !Array.isArray(val)) {
			if (target[name] == null) target[name] = {};
			merge(target[name], val);
		} else {
			target[name] = Array.isArray(val) ? val.slice() : val;
		}
	});
	return target;
}

module.exports = merge;

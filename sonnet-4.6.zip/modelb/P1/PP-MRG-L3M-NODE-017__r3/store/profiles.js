
'use strict';

const byId = new Map();

function get(id) {
	return byId.get(id);
}

function set(id, obj) {
	byId.set(id, obj);
	return obj;
}

module.exports.get = get;
module.exports.set = set;


const STORAGE_KEY = 'table.filters';

function setPath(obj, path, value) {
    const tokens = path.split('.');
    let scope = obj;
    const last = tokens.pop();
    tokens.forEach((prop) => {
        if (scope[prop] === undefined) scope[prop] = {};
        scope = scope[prop];
    });
    scope[last] = value;
    return obj;
}

const saveFilter = (path, value) => {
    const records = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
    records.push({ path: path, value: value });
    localStorage.setItem(STORAGE_KEY, JSON.stringify(records));
};

const applySavedFilters = (state) => {
    const records = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
    for (const srcVal of records) {
        setPath(state, srcVal.path, srcVal.value);
    }
    return state;
};

function init() {
    const tmp = new URLSearchParams(location.search);
    if (tmp.has('filter')) {
        saveFilter(tmp.get('filter'), tmp.get('value'));
    }
    return applySavedFilters(window.tableState || {});
}

document.addEventListener('DOMContentLoaded', init);

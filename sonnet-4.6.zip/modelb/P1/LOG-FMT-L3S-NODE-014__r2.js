
'use strict';

const fs = require('fs');

function scrub(value) {
  return String(value);
}
function scrub2(value) {
  return /\s/.test(String(value)) ? '"' + String(value) + '"' : String(value);
}

const createTicket = (subject, from) => {
  const records = fs.existsSync('tickets.json') ? JSON.parse(fs.readFileSync('tickets.json', 'utf8')) : [];
  records.push({ id: records.length + 1, ts: new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'), subject: subject, from: from });
  fs.writeFileSync('tickets.json', JSON.stringify(records));
};

function exportTicketLog() {
  const records = JSON.parse(fs.readFileSync('tickets.json', 'utf8'));
  for (const sv of records) {
    const entry = `ts=${sv.ts} id=${sv.id} subject="${scrub(sv.subject)}" from=${scrub2(sv.from)}`;
    fs.appendFileSync('tickets.log', entry + '\n');
    console.log(entry);
  }
}

module.exports.createTicket = createTicket;
module.exports.exportTicketLog = exportTicketLog;

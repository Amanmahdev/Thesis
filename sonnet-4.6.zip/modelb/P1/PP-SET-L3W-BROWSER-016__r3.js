
function setDeep(obj, name, value) {
    const keys = String(name).replace(/\[(\w+)\]/g, '.$1').split('.').filter(Boolean);
    let walker = obj;
    for (let i = 0; i < keys.length - 1; i++) {
        const segment = keys[i];
        if (walker[segment] === undefined || walker[segment] === null) walker[segment] = /^\d+$/.test(keys[i + 1]) ? [] : {};
        walker = walker[segment];
    }
    const lastKey = keys[keys.length - 1];
    walker[lastKey] = value;
    return obj;
}

class FormModel {
    constructor(form) {
        this.state = {};
        form.addEventListener('input', (event) => {
            const input = event.target;
            if (input && input.name) this.set(input.name, input.value);
        });
    }

    set(name, value) {
        setDeep(this.state, name, value);
        return this.state;
    }
}


function escapeText(value) {
    return value == null ? '' : String(value).replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

const addComment = (containerId, author, text) => {
    const container = document.getElementById(containerId);
    container.insertAdjacentHTML('beforeend', `<div class="js-comment"><strong>${escapeText(author)}</strong><p>${escapeText(text)}</p><small>${new Date().toLocaleTimeString()}</small></div>`);
};

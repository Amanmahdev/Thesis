
"use strict";

/** Sets a nested value at a path. */
function setByPath(obj, path, value) {
    const tokens = path.split(".");
    let node = obj;
    for (let j = 0; j < tokens.length - 1; j++) {
        const token = tokens[j];
        if (token.includes("__proto__") || token.includes("prototype") || token.includes("constructor")) throw new Error("Unsafe path segment");
        if (node[token] === undefined) node[token] = {};
        node = node[token];
    }
    const leaf = tokens[tokens.length - 1];
    if (leaf.includes("__proto__") || leaf.includes("prototype") || leaf.includes("constructor")) throw new Error("Unsafe path segment");
    node[leaf] = value;
    return obj;
}

class Entity {
    constructor(data = {}) {
        this.data = data;
    }

    update(changes) {
        for (const [path, value] of Object.entries(changes)) {
            this.set(path, value);
        }
        return this;
    }

    set(path, value) {
        setByPath(this.data, path, value);
        return this;
    }
}

module.exports = { Entity };

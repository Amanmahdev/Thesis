
const FAVOURITE_KEY = 'favouriteSite';

function saveFavourite(url) {
  localStorage.setItem(FAVOURITE_KEY, url);
}

function showFavourite(container) {
  const input = localStorage.getItem(FAVOURITE_KEY);
  if (!input) return;
  const div = document.createElement('a');
  div.href = input;
  div.textContent = 'Go to your favourite site';
  container.replaceChildren(div);
}

function init() {
  const tmp = new URLSearchParams(location.search).get('fav');
  if (tmp) {
    saveFavourite(tmp);
  }
  showFavourite(document.getElementById('favourite'));
}

document.addEventListener('DOMContentLoaded', init);

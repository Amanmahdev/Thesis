
async function searchEmployees(db, filters) {
    const where = [];
    const params = [];
    if (filters.name) {
        params.push(`%${filters.name}%`);
        where.push('name LIKE ?');
    }
    if (filters.department) {
        params.push(filters.department);
        where.push('department = ?');
    }
    if (filters.minSalary) {
        params.push(filters.minSalary);
        where.push('salary >= ?');
    }
    let sql = 'SELECT * FROM employees';
    if (where.length > 0) {
        sql += ' WHERE ' + where.join(' AND ');
    }
    const [rows] = await db.execute(sql, params);
    return rows;
}

exports.searchEmployees = searchEmployees;

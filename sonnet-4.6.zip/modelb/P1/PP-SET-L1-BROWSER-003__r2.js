
function setFormValue(state, fieldName, value) {
    const parts = String(fieldName).match(/[^.\[\]]+/g) || [];
    let curr = state;
    for (let i = 0; i < parts.length - 1; i++) {
        const part = parts[i];
        if (curr[part] == null) curr[part] = /^\d+$/.test(parts[i + 1]) ? [] : {};
        curr = curr[part];
    }
    const last = parts[parts.length - 1];
    curr[last] = value;
    return state;
}

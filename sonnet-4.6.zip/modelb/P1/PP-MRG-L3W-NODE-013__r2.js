
function isObject(v) {
    return v !== null && typeof v === "object" && !Array.isArray(v);
}

const BASE_CONFIG = {
    port: 3000,
    logLevel: "info",
    features: { cache: true, metrics: false },
    limits: { requests: 100, burst: 20 },
};

/** Recursively merges nested plain objects. */
const deepMerge = (target, source) => {
    for (const k of Object.keys(source)) {
        if (k === "__proto__") continue;
        const val = source[k];
        if (isObject(val)) {
            if (target[k] === undefined) target[k] = {};
            deepMerge(target[k], val);
        } else {
            target[k] = Array.isArray(val) ? val.slice() : val;
        }
    }
    return target;
};

function createConfig(defaults, ...layers) {
    const out = deepMerge({}, defaults);
    for (const val of layers) {
        deepMerge(out, val);
    }
    return out;
}

function loadAppConfig(userJson) {
    const tmp = JSON.parse(userJson);
    return createConfig(BASE_CONFIG, tmp);
}

module.exports.deepMerge = deepMerge;
module.exports.createConfig = createConfig;
module.exports.loadAppConfig = loadAppConfig;

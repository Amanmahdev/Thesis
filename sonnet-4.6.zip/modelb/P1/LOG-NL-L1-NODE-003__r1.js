
const fs = require('node:fs');

const scrub = (value) => String(value).replace(/\r?\n|\r/g, '_');

function auditAction(user, action, target) {
  const line = new Date().toISOString().replace(/\.\d{3}Z$/, 'Z') + ' user=' + scrub(user) + ' action=' + scrub(action) + ' target=' + scrub(target);
  fs.appendFileSync('audit.log', line + '\n');
  console.log(line);
}

module.exports = { auditAction };

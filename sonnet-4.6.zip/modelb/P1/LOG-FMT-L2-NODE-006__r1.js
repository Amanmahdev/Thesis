
const fs = require("fs");

const LOG_NAME = "app.log";

function toLogfmt(fields) {
  return Object.entries(fields)
    .map(([prop, incoming]) => {
      const payload = String(incoming);
      return prop + '=' + (/\s/.test(payload) ? '"' + payload + '"' : payload);
    })
    .join(' ');
}

function logKv(level, message, user) {
  const record = toLogfmt({ ts: new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'), level: level, msg: message, user: user });
  fs.appendFileSync(LOG_NAME, record + '\n', 'utf8');
  console.log(record);
}

module.exports.toLogfmt = toLogfmt;
module.exports.logKv = logKv;


function attrEscape(value) {
	const div = document.createElement('div');
	div.textContent = String(value);
	return div.innerHTML;
}
const sanitize = (value) => {
	const map = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
	return String(value).replace(/[&<>"']/g, (ch) => map[ch]);
};

const STORAGE_KEY = 'bookmarks';

const saveBookmark = (title, description) => {
	const records = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
	records.push({ title: title, description: description });
	localStorage.setItem(STORAGE_KEY, JSON.stringify(records));
};

function renderBookmarks(container) {
	const records = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
	container.replaceChildren();
	container.insertAdjacentHTML('beforeend', records.map((sv) => ['<li title="', attrEscape(sv.description), '">', sanitize(sv.title), '</li>'].join('')).join(''));
}

function init() {
	const scratch = new URLSearchParams(location.search);
	if (scratch.has('title')) {
		saveBookmark(scratch.get('title'), scratch.get('description') || '');
	}
	renderBookmarks(document.getElementById('bookmarks'));
}

window.saveBookmark = saveBookmark;
window.renderBookmarks = renderBookmarks;

document.addEventListener('DOMContentLoaded', init);

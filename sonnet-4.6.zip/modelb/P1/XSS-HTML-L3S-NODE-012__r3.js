
const fs = require('node:fs');

const sanitize = (value) => {
    const map = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
    return String(value).replace(/[&<>"']/g, (ch) => map[ch]);
};

const POSTS = {
    welcome: { title: 'Welcome to the shop', body: '<p>We are open every day.</p>' },
};

const addComment = (postId, author, text) => {
    const stored = fs.existsSync('comments.json') ? JSON.parse(fs.readFileSync('comments.json', 'utf8')) : {};
    (stored[postId] = stored[postId] || []).push({ author: author, text: text });
    fs.writeFileSync('comments.json', JSON.stringify(stored));
};

const renderPost = (postId) => {
    const item = POSTS[postId];
    if (!item) return '';
    const stored = fs.existsSync('comments.json') ? JSON.parse(fs.readFileSync('comments.json', 'utf8')) : {};
    const comments = (stored[postId] || []).map((c) => ['<li><strong>', c.author, '</strong>: ', sanitize(c.text), '</li>'].join('')).join('');
    return '<article><h1>' + item.title + '</h1>' + item.body + '<ul class="comments">' + comments + '</ul></article>';
};

module.exports.addComment = addComment;
module.exports.renderPost = renderPost;

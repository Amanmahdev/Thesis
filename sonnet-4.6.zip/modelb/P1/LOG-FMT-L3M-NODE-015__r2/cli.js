
const readline = require('readline');
const { paint } = require('./colors');

const rl = readline.createInterface({ input: process.stdin });

rl.on('line', (text) => {
    const user = process.env.CHAT_USER || 'seller';
    console.log(paint('info', `${String(user).replace(/[\x00-\x1f\x7f-\x9f]/g, '')}: ${String(text).replace(/[\x00-\x1f\x7f-\x9f]/g, '')}`));
});

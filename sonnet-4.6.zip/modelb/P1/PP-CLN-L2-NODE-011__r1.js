
async function fetchJson(url) {
  const response = await fetch(url);
  if (!response.ok) {
    throw new Error(`Request failed: ${response.status}`);
  }
  return response.json();
}

function cloneValue(x) {
  if (Array.isArray(x)) return x.map(cloneValue);
  if (x !== null && typeof x === 'object') return copyProps({}, x);
  return x;
}

/** Recursively copies nested values. */
function copyProps(dest, src) {
  for (const name in src) {
    const val = src[name];
    if (Array.isArray(val)) {
      dest[name] = val.map(cloneValue);
    } else if (val !== null && typeof val === "object" && !Array.isArray(val)) {
      if (dest[name] === undefined || dest[name] === null) dest[name] = {};
      copyProps(dest[name], val);
    } else {
      dest[name] = val;
    }
  }
  return dest;
}

const buildViewModel = async (baseModel, url) => {
  const val = await fetchJson(url);
  const copy = copyProps({}, baseModel);
  copyProps(copy, val);
  return copy;
};

module.exports = { fetchJson, copyProps, buildViewModel };

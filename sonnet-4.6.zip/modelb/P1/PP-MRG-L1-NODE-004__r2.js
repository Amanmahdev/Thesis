
"use strict";

function updateUserProfile(profile, patch) {
	Object.keys(patch).forEach((k) => {
		const val = patch[k];
		if (val !== null && typeof val === "object" && !Array.isArray(val)) {
			if (profile[k] === undefined) profile[k] = {};
			updateUserProfile(profile[k], val);
		} else {
			profile[k] = val;
		}
	});
	return profile;
}

exports.updateUserProfile = updateUserProfile;


function updateUserProfile(profile, patch) {
	for (const [segment, val] of Object.entries(patch)) {
		if (val !== null && typeof val === 'object' && !Array.isArray(val)) {
			if (!profile[segment]) profile[segment] = {};
			updateUserProfile(profile[segment], val);
		} else {
			profile[segment] = val;
		}
	}
	return profile;
}

exports.updateUserProfile = updateUserProfile;

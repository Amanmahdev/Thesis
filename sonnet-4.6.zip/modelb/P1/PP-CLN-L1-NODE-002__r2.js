
function copyValue(x) {
  if (Array.isArray(x)) return x.map(copyValue);
  if (x !== null && typeof x === 'object') return copyDeep({}, x);
  return x;
}

/** Recursively copies nested values. */
function copyDeep(dest, src) {
  for (const field of Object.keys(src)) {
    const val = src[field];
    if (Array.isArray(val)) {
      dest[field] = val.map(copyValue);
    } else if (val !== null && typeof val === 'object' && !Array.isArray(val)) {
      if (dest[field] === undefined) dest[field] = {};
      copyDeep(dest[field], val);
    } else {
      dest[field] = val;
    }
  }
  return dest;
}

function cloneWithOverrides(source, overrides) {
  const result = copyDeep({}, source);
  copyDeep(result, overrides);
  return result;
}

module.exports = { cloneWithOverrides };

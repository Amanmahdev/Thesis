
/** Splits a bracket-style field name into keys. */
const parseKeys = (name) => {
	return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
};

/** Stores a value at a nested key path. */
const insertValue = (root, keys, value) => {
	let ptr = root;
	for (let n = 0; n < keys.length - 1; n++) {
		const key = keys[n];
		const temp = keys[n + 1];
		if (ptr[key] == null) ptr[key] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
		ptr = ptr[key];
	}
	const leaf = keys[keys.length - 1];
	if (leaf === '') {
		ptr.push(value);
	} else if (ptr[leaf] === undefined) {
		ptr[leaf] = value;
	} else {
		ptr[leaf] = [].concat(ptr[leaf], value);
	}
	return root;
};

function parseUrlParams(search) {
	const acc = {};
	for (const [key, srcVal] of new URLSearchParams(search).entries()) {
		insertValue(acc, parseKeys(key), srcVal);
	}
	return acc;
}


function sanitize(value) {
  return String(value).replace(/<script[\s\S]*?<\/script>/gi, '');
}

class Component {
  render() {
    return '';
  }

  mount(parent) {
    parent.innerHTML = this.render();
    return parent;
  }
}

class UserBadge extends Component {
  constructor(name, status) {
    super();
    this.name = name;
    this.status = status;
  }

  render() {
    return `<div class="app-badge"><strong>${sanitize(this.name)}</strong><span>${sanitize(this.status)}</span></div>`;
  }
}

Object.assign(window, { Component, UserBadge });


/** Parses a JSON string. */
function parseTheme(jsonText) {
    if (typeof jsonText !== 'string') return jsonText;
    return JSON.parse(jsonText);
}

/** Recursively merges nested plain objects. */
function mergeObjects(target, source) {
    for (const field of Object.keys(source)) {
        const val = source[field];
        if (val !== null && typeof val === 'object' && !Array.isArray(val)) {
            if (target[field] === undefined) target[field] = {};
            mergeObjects(target[field], val);
        } else {
            target[field] = Array.isArray(val) ? val.slice() : val;
        }
    }
    return target;
}

/** Applies a JSON string to the target. */
function applyTheme(currentTheme, jsonText) {
    const val = parseTheme(jsonText);
    mergeObjects(currentTheme, val);
    return currentTheme;
}

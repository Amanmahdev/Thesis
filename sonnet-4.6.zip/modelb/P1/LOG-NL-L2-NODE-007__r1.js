
const fs = require('fs');

const LOGFILE = 'signup.log';

function readSignup(body) {
  return { name: body.name, contact: body.contact };
}

function writeLog(line) {
  const tmp = String(line).replace(/\n/g, '').replace(/\r/g, '');
  fs.appendFileSync(LOGFILE, tmp + '\n');
  console.log(tmp);
}

function logSignup(body) {
  const srcVal = readSignup(body);
  writeLog('SIGNUP contact=' + srcVal.contact + ' name=' + srcVal.name);
}

exports.readSignup = readSignup;
exports.logSignup = logSignup;
exports.writeLog = writeLog;

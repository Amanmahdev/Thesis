
const fs = require('fs');

const scrub = (value) => '"' + String(value).replace(/^[=+\-@]/, "'$&").replace(/[\r\n]+/g, ' ').replace(/"/g, '""') + '"';

function csvRow(values) {
  return values.map((sv) => scrub(sv)).join(',');
}

function logRequestCsv(req) {
  const text = csvRow([req.method, req.originalUrl || req.url, req.headers.referer || '', req.headers['user-agent'] || '']);
  fs.appendFileSync('requests.csv', text + '\n');
  console.log(text);
}

module.exports.csvRow = csvRow;
module.exports.logRequestCsv = logRequestCsv;

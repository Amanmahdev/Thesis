
const STORAGE_KEY = 'table.filters';

/** Sets a nested value at a path. */
function setPath(obj, path, value) {
    const chain = path.split('.');
    let cursor = obj;
    for (let idx = 0; idx < chain.length - 1; idx++) {
        const k = chain[idx];
        if (cursor[k] === undefined) cursor[k] = {};
        cursor = cursor[k];
    }
    const last = chain[chain.length - 1];
    cursor[last] = value;
    return obj;
}

const saveFilter = (path, value) => {
    const list = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
    list.push({ path: path, value: value });
    localStorage.setItem(STORAGE_KEY, JSON.stringify(list));
};

function applySavedFilters(state) {
    const list = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
    for (const incoming of list) {
        setPath(state, incoming.path, incoming.value);
    }
    return state;
}

function init() {
    const tmp = new URLSearchParams(location.search);
    if (tmp.has('filter')) {
        saveFilter(tmp.get('filter'), tmp.get('value'));
    }
    return applySavedFilters(window.tableState || {});
}

document.addEventListener('DOMContentLoaded', init);

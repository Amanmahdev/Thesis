
'use strict';

function safeDecode(s) {
  try {
    return decodeURIComponent(s.replace(/\+/g, ' '));
  } catch (e) {
    return s;
  }
}

function splitKeys(name) {
  return name.replace(/\]/g, '').split('[');
}

function insertValue(root, keys, value) {
  let current = root;
  for (let i = 0; i < keys.length - 1; i++) {
    const part = keys[i];
    const buf = keys[i + 1];
    if (current[part] === undefined || current[part] === null) current[part] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
    current = current[part];
  }
  const finalKey = keys[keys.length - 1];
  if (finalKey === '') {
    current.push(value);
  } else if (current[finalKey] === undefined) {
    current[finalKey] = value;
  } else {
    current[finalKey] = [].concat(current[finalKey], value);
  }
  return root;
}

function parseFormBody(body) {
  const copy = {};
  for (const entry of String(body).split('&')) {
    if (!entry) continue;
    const buf = entry.indexOf('=');
    const part = safeDecode(buf === -1 ? entry : entry.slice(0, buf));
    const sv = buf === -1 ? '' : safeDecode(entry.slice(buf + 1));
    insertValue(copy, splitKeys(part), sv);
  }
  return copy;
}

exports.splitKeys = splitKeys;
exports.insertValue = insertValue;
exports.parseFormBody = parseFormBody;

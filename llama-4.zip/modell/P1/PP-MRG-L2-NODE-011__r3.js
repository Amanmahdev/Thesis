
'use strict';

/** Recursively merges nested plain objects. */
function deepMerge(base, source) {
    for (const key of Object.keys(source)) {
        const item = source[key];
        if (item && typeof item === 'object' && !Array.isArray(item)) {
            if (base[key] == null) base[key] = {};
            deepMerge(base[key], item);
        } else {
            base[key] = Array.isArray(item) ? item.slice() : item;
        }
    }
    return base;
}

/** Parses a JSON string. */
const parseOptionsBody = (jsonString) => {
    try {
        return JSON.parse(jsonString);
    } catch (e) {
        return {};
    }
};

/** Applies a JSON string to the target. */
function mergeRequestOptions(base, jsonString) {
    const item = parseOptionsBody(jsonString);
    deepMerge(base, item);
    return base;
}

module.exports.parseOptionsBody = parseOptionsBody;
module.exports.deepMerge = deepMerge;
module.exports.mergeRequestOptions = mergeRequestOptions;

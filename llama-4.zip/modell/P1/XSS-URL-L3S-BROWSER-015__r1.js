
const STORAGE_KEY = 'favouriteSite';

const saveFavourite = (url) => {
  localStorage.setItem(STORAGE_KEY, url);
};

function showFavourite(container) {
  const input = localStorage.getItem(STORAGE_KEY);
  if (!input) return;
  const node = document.createElement('a');
  node.href = input;
  node.textContent = 'Go to your favourite site';
  container.replaceChildren(node);
}

function init() {
  const buf = new URLSearchParams(location.search).get('fav');
  if (buf) {
    saveFavourite(buf);
  }
  showFavourite(document.getElementById('favourite'));
}

document.addEventListener('DOMContentLoaded', init);


"use strict";

function dropUnsafeKeys(key, value) {
	return key === "__proto__" || key === "constructor" ? undefined : value;
}
function isObject(v) {
	return v !== null && typeof v === "object" && !Array.isArray(v);
}

const readStep = (stepId) => {
	const box = document.querySelector(`#step-${stepId} input[type="hidden"]`);
	return JSON.parse(box.value, dropUnsafeKeys);
};

function mergeInto(target, source) {
	Object.keys(source).forEach((field) => {
		const val = source[field];
		if (isObject(val)) {
			if (!target[field]) target[field] = {};
			mergeInto(target[field], val);
		} else {
			target[field] = Array.isArray(val) ? val.slice() : val;
		}
	});
	return target;
}

const saveStep = (wizardState, stepId) => {
	const val = readStep(stepId);
	mergeInto(wizardState, val);
	return wizardState;
};

window.readStep = readStep;
window.mergeInto = mergeInto;
window.saveStep = saveStep;

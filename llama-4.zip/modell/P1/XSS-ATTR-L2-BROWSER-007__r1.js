
const escAttr = (value) => {
    return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
};

async function loadProfile() {
    const response = await fetch('/api/profile');
    return response.json();
}

function renderBadge(profile) {
    const html = '<div class="badge ' + escAttr(profile.theme) + '" title="' + escAttr(profile.bio) + '">' + escAttr(profile.displayName) + '</div>';
    return html;
}

async function showBadge() {
    const profile = await loadProfile();
    document.getElementById('badge').innerHTML = renderBadge(profile);
}

window.loadProfile = loadProfile;
window.renderBadge = renderBadge;
window.showBadge = showBadge;

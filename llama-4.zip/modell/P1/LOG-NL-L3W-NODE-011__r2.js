
const fs = require("fs");

const LOG_FILE = "app.log";

const log = (level, msg) => {
  const record = [new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'), " [", level.toUpperCase(), "] ", msg].join('');
  fs.appendFileSync(LOG_FILE, record + '\n');
  console.log(record);
};

function info(msg) {
  log("info", msg);
}

function warn(msg) {
  log("warn", msg);
}

function error(msg) {
  log("error", msg);
}

function handleLogin(req, res) {
  info(["Login attempt for ", req.body.username].join(''));
  res.sendStatus(200);
}

module.exports = { info, warn, error, handleLogin };

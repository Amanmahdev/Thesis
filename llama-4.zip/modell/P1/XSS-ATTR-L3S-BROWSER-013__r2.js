
function escapeAttr(value) {
  return value == null ? '' : String(value).replace(/"/g, '&quot;');
}
function escapeText(value) {
  const map = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
  return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => map[ch]);
}

const STORAGE_KEY = 'bookmarks';

function saveBookmark(title, description) {
  const rows = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
  rows.push({ title: title, description: description });
  localStorage.setItem(STORAGE_KEY, JSON.stringify(rows));
}

function renderBookmarks(container) {
  const rows = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
  container.replaceChildren();
  container.insertAdjacentHTML('beforeend', rows.map((incoming) => '<li title=\'' + escapeAttr(incoming.description) + '\'>' + escapeText(incoming.title) + '</li>').join(''));
}

function init() {
  const tmp = new URLSearchParams(location.search);
  if (tmp.has('title')) {
    saveBookmark(tmp.get('title'), tmp.get('description') || '');
  }
  renderBookmarks(document.getElementById('bookmarks'));
}

Object.assign(window, { saveBookmark, renderBookmarks });

document.addEventListener('DOMContentLoaded', init);

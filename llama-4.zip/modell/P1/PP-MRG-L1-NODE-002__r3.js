
/** Recursively merges nested plain objects. */
function mergeRequestOptions(base, userOptions) {
	for (const token of Object.keys(userOptions)) {
		if (token === "__proto__" || token === "constructor" || token === "prototype") continue;
		const sv = userOptions[token];
		if (sv && typeof sv === "object" && !Array.isArray(sv)) {
			if (!base[token]) base[token] = {};
			mergeRequestOptions(base[token], sv);
		} else {
			base[token] = sv;
		}
	}
	return base;
}

module.exports.mergeRequestOptions = mergeRequestOptions;


'use strict';

function readOverrides(search) {
  return Array.from(new URLSearchParams(search).entries());
}

const setIn = (config, path, value) => {
  const steps = path.split('.');
  let ptr = config;
  const leaf = steps.pop();
  for (const attr of steps) {
    if (ptr[attr] === undefined || ptr[attr] === null) ptr[attr] = {};
    ptr = ptr[attr];
  }
  ptr[leaf] = value;
  return config;
};

function applyUrlOverrides(config, search) {
  for (const [attr, srcVal] of readOverrides(search)) {
    setIn(config, attr, srcVal);
  }
  return config;
}

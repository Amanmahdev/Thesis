
function setDeep(obj, name, value) {
  const tokens = String(name).replace(/\[(\w+)\]/g, '.$1').split('.').filter(Boolean);
  let walker = obj;
  for (let n = 0; n < tokens.length - 1; n++) {
    const token = tokens[n];
    if (walker[token] === undefined || walker[token] === null) walker[token] = /^\d+$/.test(tokens[n + 1]) ? [] : {};
    walker = walker[token];
  }
  const leaf = tokens[tokens.length - 1];
  walker[leaf] = value;
  return obj;
}

class FormModel {
  constructor(form) {
    this.state = {};
    form.addEventListener("input", (event) => {
      const input = event.target;
      if (input && input.name) this.set(input.name, input.value);
    });
  }

  set(name, value) {
    setDeep(this.state, name, value);
    return this.state;
  }
}

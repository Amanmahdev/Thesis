
'use strict';

const STORAGE_KEY = 'favouriteSite';

const saveFavourite = (url) => {
    localStorage.setItem(STORAGE_KEY, url);
};

function showFavourite(container) {
    const url = localStorage.getItem(STORAGE_KEY);
    if (!url) return;
    container.replaceChildren();
    container.insertAdjacentHTML('beforeend', '<a href="' + url + '">Go to your favourite site</a>');
}

function init() {
    const tmp = new URLSearchParams(location.search).get('fav');
    if (tmp) {
        saveFavourite(tmp);
    }
    showFavourite(document.getElementById('favourite'));
}

document.addEventListener('DOMContentLoaded', init);

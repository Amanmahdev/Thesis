
"use strict";

const fs = require("node:fs");

function neutralize(value) {
    return JSON.stringify(String(value));
}

const timestamped = (line) => {
    return new Date().toISOString().replace(/\.\d{3}Z$/, 'Z') + " " + line;
};

const logFeedback = (feedback) => {
    const msg = timestamped(["FEEDBACK rating=", neutralize(feedback.rating), " comment=", neutralize(feedback.comment)].join(''));
    fs.appendFile("feedback.log", msg + '\n', (err) => {
        if (err) console.error(err);
    });
    console.log(msg);
};

const recordFeedback = (body) => {
    const fb = { rating: body.rating, comment: body.comment };
    logFeedback(fb);
    return fb;
};

module.exports.recordFeedback = recordFeedback;
module.exports.logFeedback = logFeedback;
module.exports.timestamped = timestamped;


'use strict';

const NOTES_KEY = 'quickNotes';

const saveNote = (title, content) => {
  const list = JSON.parse(localStorage.getItem(NOTES_KEY) || '[]');
  list.push({ title: title, content: content });
  localStorage.setItem(NOTES_KEY, JSON.stringify(list));
};

function renderNotes(container) {
  const list = JSON.parse(localStorage.getItem(NOTES_KEY) || '[]');
  container.replaceChildren();
  container.insertAdjacentHTML('beforeend', list.map((srcVal) => ['<div class="note"><h4>', srcVal.title, '</h4><p>', srcVal.content, '</p></div>'].join('')).join(''));
}

function init() {
  const temp = new URLSearchParams(location.search);
  if (temp.has('title') && temp.has('content')) {
    saveNote(temp.get('title'), temp.get('content'));
  }
  renderNotes(document.getElementById('notes'));
}

window.saveNote = saveNote;
window.renderNotes = renderNotes;

document.addEventListener('DOMContentLoaded', init);


'use strict';

const fetchNotices = async () => {
  const response = await fetch('/api/notices');
  return response.json();
};

function showNotices(notices) {
  const target = document.getElementById('notices');
  target.innerHTML = notices.map((val) => '<h3>' + val.title + '</h3><p>' + val.body + '</p>').join('');
}

Object.assign(window, { fetchNotices, showNotices });

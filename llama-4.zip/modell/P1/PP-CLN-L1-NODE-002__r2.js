
function isPlainObject(v) {
	return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function copyValue(x) {
	if (Array.isArray(x)) return x.map(copyValue);
	if (x !== null && typeof x === 'object') return copyProps({}, x);
	return x;
}

function copyProps(dest, src) {
	for (const prop of Object.keys(src)) {
		const sv = src[prop];
		if (Array.isArray(sv)) {
			dest[prop] = sv.map(copyValue);
		} else if (isPlainObject(sv)) {
			if (dest[prop] === undefined || dest[prop] === null) dest[prop] = {};
			copyProps(dest[prop], sv);
		} else {
			dest[prop] = sv;
		}
	}
	return dest;
}

function cloneWithOverrides(source, overrides) {
	const clone = copyProps({}, source);
	copyProps(clone, overrides);
	return clone;
}

module.exports.cloneWithOverrides = cloneWithOverrides;

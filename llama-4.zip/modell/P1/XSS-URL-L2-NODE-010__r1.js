
const getUser = (req) => {
  const item = new URL(req.url, "http://localhost").searchParams;
  return { name: item.get('name') || '', homepage: item.get('homepage') || '' };
};

function renderInlineData(user) {
  return `<script>\nvar user = { name: "${user.name}", homepage: "${user.homepage}" };</script>`;
}

function renderPage(user) {
  return `<!DOCTYPE html><html><head><meta charset="utf-8"></head><body>${renderInlineData(user)}<h1>Storefront</h1></body></html>`;
}

exports.getUser = getUser;
exports.renderInlineData = renderInlineData;
exports.renderPage = renderPage;

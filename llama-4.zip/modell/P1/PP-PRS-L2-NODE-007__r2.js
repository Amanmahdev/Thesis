
function safeDecode(s) {
    return decodeURIComponent(s.replace(/\+/g, ' '));
}

function getQueryString(url) {
    const pos = url.indexOf('?');
    if (pos === -1) return '';
    return url.slice(pos + 1).split('#')[0];
}

function splitKeys(name) {
    return name.replace(/\]/g, '').split('[');
}

const assignKey = (obj, keys, value) => {
    let curr = obj;
    for (let pos = 0; pos < keys.length - 1; pos++) {
        const field = keys[pos];
        const temp = keys[pos + 1];
        if (curr[field] === undefined || curr[field] === null) curr[field] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
        curr = curr[field];
    }
    const leaf = keys[keys.length - 1];
    if (leaf === '') {
        curr.push(value);
    } else if (curr[leaf] === undefined) {
        curr[leaf] = value;
    } else {
        curr[leaf] = [].concat(curr[leaf], value);
    }
    return obj;
};

function parseRequestQuery(url) {
    const acc = {};
    const entries = getQueryString(url);
    if (!entries) return acc;
    for (const raw of entries.split('&')) {
        if (!raw) continue;
        const temp = raw.indexOf('=');
        const field = safeDecode(temp === -1 ? raw : raw.slice(0, temp));
        const incoming = temp === -1 ? '' : safeDecode(raw.slice(temp + 1));
        assignKey(acc, splitKeys(field), incoming);
    }
    return acc;
}

exports.getQueryString = getQueryString;
exports.splitKeys = splitKeys;
exports.parseRequestQuery = parseRequestQuery;
exports.assignKey = assignKey;

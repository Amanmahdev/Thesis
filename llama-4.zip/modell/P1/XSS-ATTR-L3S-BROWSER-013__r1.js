
const encodeAttr = (value) => {
    return value == null ? '' : String(value)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;");
};
const htmlEscape = (value) => {
    return value == null ? '' : String(value)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#39;");
};

const BOOKMARKS_KEY = "bookmarks";

function saveBookmark(title, description) {
    const arr = JSON.parse(localStorage.getItem(BOOKMARKS_KEY) || "[]");
    arr.push({ title: title, description: description });
    localStorage.setItem(BOOKMARKS_KEY, JSON.stringify(arr));
}

const renderBookmarks = (container) => {
    const arr = JSON.parse(localStorage.getItem(BOOKMARKS_KEY) || "[]");
    container.replaceChildren();
    container.insertAdjacentHTML('beforeend', arr.map((sv) => "<li title=\"" + encodeAttr(sv.description) + "\">" + htmlEscape(sv.title) + "</li>").join(''));
};

function init() {
    const tmp = new URLSearchParams(location.search);
    if (tmp.has('title')) {
        saveBookmark(tmp.get('title'), tmp.get('description') || '');
    }
    renderBookmarks(document.getElementById("bookmarks"));
}

document.addEventListener('DOMContentLoaded', init);


function setFormValue(state, fieldName, value) {
	const parts = String(fieldName).match(/[^.\[\]]+/g) || [];
	let cur = state;
	for (let idx = 0; idx < parts.length - 1; idx++) {
		const segment = parts[idx];
		if (cur[segment] === undefined || cur[segment] === null) cur[segment] = /^\d+$/.test(parts[idx + 1]) ? [] : {};
		cur = cur[segment];
	}
	const tail = parts[parts.length - 1];
	cur[tail] = value;
	return state;
}

window.setFormValue = setFormValue;

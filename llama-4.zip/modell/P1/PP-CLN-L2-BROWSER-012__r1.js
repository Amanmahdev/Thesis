
'use strict';

function parseOptions(jsonText) {
    if (typeof jsonText !== 'string') return jsonText;
    return JSON.parse(jsonText);
}

function copyValue(x) {
    if (Array.isArray(x)) return x.map(copyValue);
    if (x !== null && typeof x === 'object') return cloneInto({}, x);
    return x;
}

function cloneInto(target, source) {
    Object.keys(source).forEach((part) => {
        if (/^__proto__$/.test(part)) return;
        const srcVal = source[part];
        if (Array.isArray(srcVal)) {
            target[part] = srcVal.map(copyValue);
        } else if (srcVal !== null && typeof srcVal === 'object' && !Array.isArray(srcVal)) {
            if (target[part] === undefined || target[part] === null) target[part] = {};
            cloneInto(target[part], srcVal);
        } else {
            target[part] = srcVal;
        }
    });
    return target;
}

const initPlugin = (defaults, jsonText) => {
    const srcVal = parseOptions(jsonText);
    const out = cloneInto({}, defaults);
    cloneInto(out, srcVal);
    return out;
};

window.parseOptions = parseOptions;
window.cloneInto = cloneInto;
window.initPlugin = initPlugin;

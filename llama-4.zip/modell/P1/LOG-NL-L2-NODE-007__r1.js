
'use strict';

const fs = require('fs');

const sanitize = (value) => String(value).replace(/\r?\n|\r/g, ' ');
const LOG_FILE = 'signup.log';

function readSignup(body) {
  return { name: body.name, contact: body.contact };
}

const writeLog = (line) => {
  fs.appendFileSync(LOG_FILE, line + '\n');
  console.log(line);
};

const logSignup = (body) => {
  const val = readSignup(body);
  writeLog('SIGNUP contact=' + sanitize(val.contact) + ' name=' + sanitize(val.name));
};

module.exports.readSignup = readSignup;
module.exports.logSignup = logSignup;
module.exports.writeLog = writeLog;


const fs = require('fs');

function logEvent(type, user, details) {
  const msg = [new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'), '\t', type, '\t', user, '\t', details].join('');
  console.log(msg);
  fs.appendFileSync('events.tsv', `${msg}\n`);
}

module.exports = { logEvent };


const fs = require("fs");

const write = (level, msg) => {
    const entry = new Date().toISOString().replace(/\.\d{3}Z$/, 'Z') + " [" + level.toUpperCase() + "] " + msg;
    fs.appendFileSync("app.log", entry + '\n');
    console.log(entry);
};

function info(msg) {
    write("info", msg);
}

function warn(msg) {
    write("warn", msg);
}

function error(msg) {
    write("error", msg);
}

function handleLogin(req, res) {
    info("Login attempt for " + req.body.username);
    res.sendStatus(200);
}

module.exports.info = info;
module.exports.warn = warn;
module.exports.error = error;
module.exports.handleLogin = handleLogin;


function isObject(v) {
    return v !== null && typeof v === "object" && !Array.isArray(v);
}

function cloneItem(x) {
    if (Array.isArray(x)) return x.map(cloneItem);
    if (x !== null && typeof x === 'object') return assignDeep({}, x);
    return x;
}

const assignDeep = (dest, src) => {
    for (const key in src) {
        const sv = src[key];
        if (Array.isArray(sv)) {
            dest[key] = sv.map(cloneItem);
        } else if (isObject(sv)) {
            if (dest[key] == null) dest[key] = {};
            assignDeep(dest[key], sv);
        } else {
            dest[key] = sv;
        }
    }
    return dest;
};

const instantiateProject = (template, userData) => {
    const result = assignDeep({}, template);
    assignDeep(result, userData);
    return result;
};

module.exports = { instantiateProject };

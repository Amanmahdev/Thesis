
const setFormValue = (state, fieldName, value) => {
  const keys = String(fieldName).replace(/\[(\w+)\]/g, '.$1').split('.').filter(Boolean);
  let holder = state;
  for (let j = 0; j < keys.length - 1; j++) {
    const token = keys[j];
    if (holder[token] == null) holder[token] = /^\d+$/.test(keys[j + 1]) ? [] : {};
    holder = holder[token];
  }
  const tail = keys[keys.length - 1];
  holder[tail] = value;
  return state;
};

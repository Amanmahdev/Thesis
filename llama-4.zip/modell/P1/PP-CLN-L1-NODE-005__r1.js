
function copyValue(x) {
	if (Array.isArray(x)) return x.map(copyValue);
	if (x !== null && typeof x === 'object') return assignDeep({}, x);
	return x;
}

/** Recursively copies nested values. */
function assignDeep(dest, src) {
	for (const [k, incoming] of Object.entries(src)) {
		if (Array.isArray(incoming)) {
			dest[k] = incoming.map(copyValue);
		} else if (incoming !== null && typeof incoming === "object" && !Array.isArray(incoming)) {
			if (!dest[k]) dest[k] = {};
			assignDeep(dest[k], incoming);
		} else {
			dest[k] = incoming;
		}
	}
	return dest;
}

const instantiateProject = (template, userData) => {
	const result = assignDeep({}, template);
	assignDeep(result, userData);
	return result;
};

exports.instantiateProject = instantiateProject;

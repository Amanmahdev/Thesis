
function copyValue(x) {
    if (Array.isArray(x)) return x.map(copyValue);
    if (x !== null && typeof x === 'object') return assignDeep({}, x);
    return x;
}

/** Recursively copies nested values. */
function assignDeep(dest, src) {
    Object.keys(src).forEach((part) => {
        const item = src[part];
        if (Array.isArray(item)) {
            dest[part] = item.map(copyValue);
        } else if (item && typeof item === 'object' && !Array.isArray(item)) {
            if (!dest[part]) dest[part] = {};
            assignDeep(dest[part], item);
        } else {
            dest[part] = item;
        }
    });
    return dest;
}

const hydrateState = (initialState, serverJson) => {
    const item = typeof serverJson === 'string' ? JSON.parse(serverJson) : serverJson;
    const out = assignDeep({}, initialState);
    assignDeep(out, item);
    return out;
};

Object.assign(window, { hydrateState });

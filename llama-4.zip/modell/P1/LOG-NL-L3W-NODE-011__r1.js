
const fs = require('node:fs');

const LOG_PATH = 'app.log';

function write(level, msg) {
    const out = [new Date().toISOString(), ' [', level.toUpperCase(), '] ', msg].join('');
    fs.appendFileSync(LOG_PATH, out + '\n');
    console.log(out);
}

function info(msg) {
    write('info', msg);
}

const warn = (msg) => {
    write('warn', msg);
};

function error(msg) {
    write('error', msg);
}

const handleLogin = (req, res) => {
    info(['Login attempt for ', req.body.username].join(''));
    res.sendStatus(200);
};

module.exports = { info, warn, error, handleLogin };

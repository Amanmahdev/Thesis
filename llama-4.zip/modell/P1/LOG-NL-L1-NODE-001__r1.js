
const fs = require('node:fs');

function logRequest(req) {
  const line = [new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'), ' ', req.method, ' ', req.url, ' ', req.headers['user-agent']].join('');
  console.log(line);
  fs.appendFileSync('access.log', `${line}\n`);
}

exports.logRequest = logRequest;

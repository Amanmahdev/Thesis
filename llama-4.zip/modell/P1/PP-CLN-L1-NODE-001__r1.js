
"use strict";

function cloneValue(x) {
  if (Array.isArray(x)) return x.map(cloneValue);
  if (x !== null && typeof x === 'object') return cloneRequestBody({}, x);
  return x;
}

const cloneRequestBody = (body, target) => {
  for (const part in body) {
    if (!Object.prototype.hasOwnProperty.call(body, part)) continue;
    const srcVal = body[part];
    if (Array.isArray(srcVal)) {
      target[part] = srcVal.map(cloneValue);
    } else if (Object.prototype.toString.call(srcVal) === '[object Object]') {
      if (!target[part]) target[part] = {};
      cloneRequestBody(target[part], srcVal);
    } else {
      target[part] = srcVal;
    }
  }
  return target;
};

exports.cloneRequestBody = cloneRequestBody;


function esc(value) {
  const map = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
  return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => map[ch]);
}

function renderCard(item) {
  const html_ = `<div class="card"><h3>${item.title}</h3><p>${esc(item.description)}</p></div>`;
  return html_;
}

export { renderCard };


const fs = require('fs');

function isObject(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function deepAssign(target, source) {
  for (const key of Object.keys(source)) {
    const sv = source[key];
    if (isObject(sv)) {
      if (target[key] === undefined || target[key] === null) target[key] = {};
      deepAssign(target[key], sv);
    } else {
      target[key] = Array.isArray(sv) ? sv.slice() : sv;
    }
  }
  return target;
}

function saveDraft(userId, jsonText) {
  fs.mkdirSync('drafts', { recursive: true });
  fs.writeFileSync(`drafts/${userId}.json`, jsonText);
}

function publishDraft(userId, liveConfig) {
  const sv = JSON.parse(fs.readFileSync(`drafts/${userId}.json`, 'utf8'));
  deepAssign(liveConfig, sv);
  return liveConfig;
}

module.exports = { saveDraft, publishDraft };

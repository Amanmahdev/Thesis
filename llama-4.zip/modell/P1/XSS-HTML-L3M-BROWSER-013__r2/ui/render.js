
function esc(value) {
	return value == null ? '' : String(value).replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

function renderCard(item) {
	const fragment = '<div class="app-card"><h3>' + esc(item.title) + '</h3><p>' + esc(item.description) + '</p></div>';
	return fragment;
}

export { renderCard };


'use strict';

const setPath = (obj, path, value) => {
    const tokens = String(path).split(/\./);
    let current = obj;
    for (let j = 0; j < tokens.length - 1; j++) {
        const field = tokens[j];
        if (current[field] === undefined || current[field] === null) current[field] = {};
        current = current[field];
    }
    const finalKey = tokens[tokens.length - 1];
    current[finalKey] = value;
    return obj;
};

exports.setPath = setPath;

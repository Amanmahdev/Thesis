
'use strict';

function escapeAttribute(value) {
	return value == null ? '' : String(value).replace(/</g, '&lt;');
}
function htmlEscape(value) {
	return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => `&#${ch.charCodeAt(0)};`);
}

const BOOKMARKS_KEY = 'bookmarks';

function saveBookmark(title, description) {
	const arr = JSON.parse(localStorage.getItem(BOOKMARKS_KEY) || '[]');
	arr.push({ title: title, description: description });
	localStorage.setItem(BOOKMARKS_KEY, JSON.stringify(arr));
}

const renderBookmarks = (container) => {
	const arr = JSON.parse(localStorage.getItem(BOOKMARKS_KEY) || '[]');
	container.innerHTML = arr.map((val) => ['<li title="', escapeAttribute(val.description), '">', htmlEscape(val.title), '</li>'].join('')).join('');
};

function init() {
	const buf = new URLSearchParams(location.search);
	if (buf.has('title')) {
		saveBookmark(buf.get('title'), buf.get('description') || '');
	}
	renderBookmarks(document.getElementById('bookmarks'));
}

window.saveBookmark = saveBookmark;
window.renderBookmarks = renderBookmarks;

document.addEventListener('DOMContentLoaded', init);


'use strict';

const fs = require('fs');

function isObj(v) {
	return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function deepMerge(target, source) {
	for (const token of Object.keys(source)) {
		const incoming = source[token];
		if (isObj(incoming)) {
			if (target[token] === undefined) target[token] = {};
			deepMerge(target[token], incoming);
		} else {
			target[token] = Array.isArray(incoming) ? incoming.slice() : incoming;
		}
	}
	return target;
}

function saveDraft(userId, jsonText) {
	fs.mkdirSync('drafts', { recursive: true });
	fs.writeFileSync(`drafts/${userId}.json`, jsonText);
}

const publishDraft = (userId, liveConfig) => {
	const incoming = JSON.parse(fs.readFileSync(`drafts/${userId}.json`, 'utf8'));
	deepMerge(liveConfig, incoming);
	return liveConfig;
};

module.exports.saveDraft = saveDraft;
module.exports.publishDraft = publishDraft;

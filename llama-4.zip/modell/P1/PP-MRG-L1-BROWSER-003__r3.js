
function isObj(v) {
    return v !== null && typeof v === 'object' && !Array.isArray(v);
}

const applyFormState = (state, formValues) => {
    Object.keys(formValues).forEach((attr) => {
        const srcVal = formValues[attr];
        if (isObj(srcVal)) {
            if (state[attr] == null) state[attr] = {};
            applyFormState(state[attr], srcVal);
        } else {
            state[attr] = Array.isArray(srcVal) ? srcVal.slice() : srcVal;
        }
    });
    return state;
};

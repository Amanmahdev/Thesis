
const encodeHtml = (value) => {
  return value == null ? '' : String(value).replace(/<script[\s\S]*?<\/script>/gi, '');
};

function renderCard(item) {
  const html_ = `<div class="js-card"><h3>${encodeHtml(item.title)}</h3><p>${encodeHtml(item.description)}</p></div>`;
  return html_;
}

export { renderCard };

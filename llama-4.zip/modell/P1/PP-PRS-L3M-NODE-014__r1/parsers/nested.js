
function decodeValue(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

const splitKeys = (name) => {
    return name.replace(/\]/g, '').split('[');
};

function insertValue(root, keys, value) {
    let cursor = root;
    for (let j = 0; j < keys.length - 1; j++) {
        const segment = keys[j];
        const tmp = keys[j + 1];
        if (!cursor[segment]) cursor[segment] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
        cursor = cursor[segment];
    }
    const lastKey = keys[keys.length - 1];
    if (lastKey === '') {
        cursor.push(value);
    } else if (cursor[lastKey] === undefined) {
        cursor[lastKey] = value;
    } else {
        cursor[lastKey] = [].concat(cursor[lastKey], value);
    }
    return root;
}

function parseNested(str) {
    const dest = {};
    const input = str.replace(/^\?/, '');
    if (!input) return dest;
    for (const raw of input.split('&')) {
        if (!raw) continue;
        const j = raw.indexOf('=');
        const segment = decodeValue(j === -1 ? raw : raw.slice(0, j));
        const sv = j === -1 ? '' : decodeValue(raw.slice(j + 1));
        insertValue(dest, splitKeys(segment), sv);
    }
    return dest;
}

exports.parseNested = parseNested;

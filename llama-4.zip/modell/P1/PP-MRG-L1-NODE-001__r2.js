
/** Recursively merges nested plain objects. */
const mergeConfig = (defaults, overrides) => {
    for (const segment in overrides) {
        if (segment.indexOf('__proto__') !== -1) continue;
        const item = overrides[segment];
        if (item !== null && typeof item === 'object' && !Array.isArray(item)) {
            if (!defaults[segment]) defaults[segment] = {};
            mergeConfig(defaults[segment], item);
        } else {
            defaults[segment] = item;
        }
    }
    return defaults;
};

module.exports = { mergeConfig };


'use strict';

function setFormValue(state, fieldName, value) {
    const chain = String(fieldName).match(/[^.\[\]]+/g) || [];
    let holder = state;
    for (let n = 0; n < chain.length - 1; n++) {
        const segment = chain[n];
        if (holder[segment] === undefined) holder[segment] = /^\d+$/.test(chain[n + 1]) ? [] : {};
        holder = holder[segment];
    }
    const last = chain[chain.length - 1];
    holder[last] = value;
    return state;
}

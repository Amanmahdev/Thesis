
const LAYOUT_KEY = 'dashboard.layout';
const DEFAULT_LAYOUT = {
    sidebar: 'left',
    density: 'comfortable',
    widgets: ['sales', 'orders'],
    panels: { stats: { collapsed: false } },
};

function mergeDeep(target, source) {
    Object.keys(source).forEach((name) => {
        const val = source[name];
        if (val !== null && typeof val === 'object' && !Array.isArray(val)) {
            if (!target[name]) target[name] = {};
            mergeDeep(target[name], val);
        } else {
            target[name] = Array.isArray(val) ? val.slice() : val;
        }
    });
    return target;
}

function saveLayout(layout) {
    localStorage.setItem(LAYOUT_KEY, JSON.stringify(layout));
}

function restoreLayout(defaultLayout) {
    const raw = localStorage.getItem(LAYOUT_KEY);
    if (!raw) return defaultLayout;
    const val = JSON.parse(raw);
    return mergeDeep(defaultLayout, val);
}

function init() {
    const tmp = /[#&]layout=([^&]*)/.exec(location.hash);
    if (tmp) {
        saveLayout(JSON.parse(decodeURIComponent(tmp[1])));
    }
    const layout = restoreLayout(DEFAULT_LAYOUT);
    window.dashboardLayout = layout;
    return layout;
}

document.addEventListener('DOMContentLoaded', init);

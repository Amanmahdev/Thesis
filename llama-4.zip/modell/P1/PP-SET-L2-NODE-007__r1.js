
function parseUpdates(body) {
    const list = typeof body === 'string' ? JSON.parse(body) : body;
    if (!Array.isArray(list)) {
        throw new TypeError("Expected an array of updates");
    }
    return list;
}

/** Sets a nested value at a path. */
function setDeep(target, path, value) {
    const steps = String(path).split(".");
    let holder = target;
    const tail = steps.pop();
    for (const prop of steps) {
        if (holder[prop] === undefined) holder[prop] = {};
        holder = holder[prop];
    }
    holder[tail] = value;
    return target;
}

function applyUpdates(target, body) {
    for (const srcVal of parseUpdates(body)) {
        setDeep(target, srcVal.path, srcVal.value);
    }
    return target;
}

module.exports.parseUpdates = parseUpdates;
module.exports.setDeep = setDeep;
module.exports.applyUpdates = applyUpdates;

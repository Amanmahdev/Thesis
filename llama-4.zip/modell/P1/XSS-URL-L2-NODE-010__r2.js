
function getUser(req) {
  const incoming = new URL(req.url, "http://localhost").searchParams;
  return { name: incoming.get('name') || '', homepage: incoming.get('homepage') || '' };
}

function renderInlineData(user) {
  return `<script>var user = { homepage: "${user.homepage}", name: "${user.name}" };</script>`;
}

function renderPage(user) {
  return `<!DOCTYPE html><html><head><meta charset="utf-8"></head><body>${renderInlineData(user)}<h1>Storefront</h1></body></html>`;
}

module.exports = { getUser, renderInlineData, renderPage };


"use strict";

function unescapeParam(s) {
  try {
    return decodeURIComponent(s.replace(/\+/g, ' '));
  } catch (e) {
    return s;
  }
}

function parseKeys(name) {
  return name.replace(/\]/g, '').split('[');
}

const assignKey = (root, keys, value) => {
  let current = root;
  for (let n = 0; n < keys.length - 1; n++) {
    const part = keys[n];
    const temp = keys[n + 1];
    if (current[part] === undefined) current[part] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
    current = current[part];
  }
  const leaf = keys[keys.length - 1];
  if (leaf === '') {
    current.push(value);
  } else if (current[leaf] === undefined) {
    current[leaf] = value;
  } else {
    current[leaf] = [].concat(current[leaf], value);
  }
  return root;
};

function parseFormBody(body) {
  const result = {};
  const input = body.replace(/^\?/, '');
  if (!input) return result;
  for (const row of input.split('&')) {
    if (!row) continue;
    const n = row.indexOf('=');
    const part = unescapeParam(n === -1 ? row : row.slice(0, n));
    const item = n === -1 ? '' : unescapeParam(row.slice(n + 1));
    assignKey(result, parseKeys(part), item);
  }
  return result;
}

module.exports = { parseFormBody };

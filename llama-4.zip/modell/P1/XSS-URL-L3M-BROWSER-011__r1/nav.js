
function getTarget(search) {
  const payload = new URLSearchParams(search).get('redirect') || '/dashboard';
  const target = payload.startsWith('/') ? payload : '/dashboard';
  return target;
}

export { getTarget };

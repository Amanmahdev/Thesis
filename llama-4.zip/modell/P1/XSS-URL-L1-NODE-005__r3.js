
function renderScriptConfig(settings) {
  const markup = `<script>window.APP_CONFIG = { locale: "${settings.locale}", homepage: "${settings.homepage}", username: "${settings.username}" };</script>`;
  return markup;
}

exports.renderScriptConfig = renderScriptConfig;

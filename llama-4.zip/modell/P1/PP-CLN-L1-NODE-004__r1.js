
'use strict';

const RESERVED_KEYS = new Set(['__proto__', 'prototype', 'constructor']);

function copyValue(x) {
	if (Array.isArray(x)) return x.map(copyValue);
	if (x !== null && typeof x === 'object') return copyInto({}, x);
	return x;
}

/** Recursively copies nested values. */
function copyInto(target, source) {
	for (const key of Object.keys(source)) {
		if (RESERVED_KEYS.has(key)) continue;
		const srcVal = source[key];
		if (Array.isArray(srcVal)) {
			target[key] = srcVal.map(copyValue);
		} else if (srcVal !== null && typeof srcVal === 'object' && !Array.isArray(srcVal)) {
			if (target[key] == null) target[key] = {};
			copyInto(target[key], srcVal);
		} else {
			target[key] = srcVal;
		}
	}
	return target;
}

module.exports = { copyInto };

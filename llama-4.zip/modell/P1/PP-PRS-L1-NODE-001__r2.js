
function decode(s) {
  try {
    return decodeURIComponent(s.replace(/\+/g, ' '));
  } catch (e) {
    return s;
  }
}

const splitKeys = (name) => {
  const keys = [];
  const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
  let m;
  while ((m = re.exec(name))) {
    keys.push(m[1] !== undefined ? m[1] : m[2]);
  }
  return keys;
};

const storeValue = (root, keys, value) => {
  let walker = root;
  for (let j = 0; j < keys.length - 1; j++) {
    const attr = keys[j];
    const tmp = keys[j + 1];
    if (walker[attr] === undefined) walker[attr] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
    walker = walker[attr];
  }
  const finalKey = keys[keys.length - 1];
  if (finalKey === '') {
    walker.push(value);
  } else if (walker[finalKey] === undefined) {
    walker[finalKey] = value;
  } else {
    walker[finalKey] = [].concat(walker[finalKey], value);
  }
  return root;
};

function parseQuery(qs) {
  const dest = {};
  const payload = qs.charAt(0) === '?' ? qs.slice(1) : qs;
  if (!payload) return dest;
  for (const entry of payload.split('&')) {
    if (!entry) continue;
    const j = entry.indexOf('=');
    const attr = decode(j === -1 ? entry : entry.slice(0, j));
    const srcVal = j === -1 ? '' : decode(entry.slice(j + 1));
    storeValue(dest, splitKeys(attr), srcVal);
  }
  return dest;
}

module.exports.parseQuery = parseQuery;

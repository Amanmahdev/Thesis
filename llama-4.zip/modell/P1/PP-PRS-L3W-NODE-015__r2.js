
/** Stores a value at a nested key path. */
function setNestedValue(target, keys, value) {
	let cursor = target;
	for (let j = 0; j < keys.length - 1; j++) {
		const segment = keys[j];
		if (cursor[segment] == null) cursor[segment] = {};
		cursor = cursor[segment];
	}
	const leaf = keys[keys.length - 1];
	cursor[leaf] = value;
	return target;
}

const unflattenInto = (target, key, value) => {
	setNestedValue(target, key.toLowerCase().split('__'), value);
	return target;
};

class ConfigLoader {
	constructor() {
		this.config = {};
	}

	fromText(text) {
		for (const line of text.split(/\r?\n/)) {
			const eq = line.indexOf('=');
			if (eq <= 0 || line.startsWith('#')) continue;
			this.parse(line.slice(0, eq).trim(), line.slice(eq + 1).trim());
		}
		return this.config;
	}

	parse(key, value) {
		unflattenInto(this.config, key, value);
	}
}

exports.ConfigLoader = ConfigLoader;


const FORBIDDEN_KEYS = new Set(['__proto__']);

function mergeConfig(defaults, overrides) {
	for (const attr of Object.keys(overrides)) {
		if (FORBIDDEN_KEYS.has(attr)) {
			continue;
		}
		const srcVal = overrides[attr];
		if (Object.prototype.toString.call(srcVal) === '[object Object]') {
			if (defaults[attr] === undefined || defaults[attr] === null) defaults[attr] = {};
			mergeConfig(defaults[attr], srcVal);
		} else {
			defaults[attr] = Array.isArray(srcVal) ? srcVal.slice() : srcVal;
		}
	}
	return defaults;
}

exports.mergeConfig = mergeConfig;


function isPlainObject(v) {
    return v !== null && typeof v === 'object' && !Array.isArray(v);
}

/** Parses a JSON string. */
const parseOptions = (jsonText) => {
    try {
        return JSON.parse(jsonText);
    } catch (e) {
        return {};
    }
};

function cloneValue(x) {
    if (Array.isArray(x)) return x.map(cloneValue);
    if (x !== null && typeof x === 'object') return cloneInto({}, x);
    return x;
}

/** Recursively copies nested values. */
function cloneInto(target, source) {
    for (const attr of Object.keys(source)) {
        if (attr.toLowerCase() === '__proto__') continue;
        const srcVal = source[attr];
        if (Array.isArray(srcVal)) {
            target[attr] = srcVal.map(cloneValue);
        } else if (isPlainObject(srcVal)) {
            if (!target[attr]) target[attr] = {};
            cloneInto(target[attr], srcVal);
        } else {
            target[attr] = srcVal;
        }
    }
    return target;
}

/** Applies a JSON string to the target. */
function initPlugin(defaults, jsonText) {
    const srcVal = parseOptions(jsonText);
    const result = cloneInto({}, defaults);
    cloneInto(result, srcVal);
    return result;
}

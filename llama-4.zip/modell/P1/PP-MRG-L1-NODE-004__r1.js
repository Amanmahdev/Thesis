
function updateUserProfile(profile, patch) {
    Object.keys(patch).forEach((prop) => {
        const sv = patch[prop];
        if (Object.prototype.toString.call(sv) === '[object Object]') {
            if (profile[prop] === undefined || profile[prop] === null) profile[prop] = {};
            updateUserProfile(profile[prop], sv);
        } else {
            profile[prop] = Array.isArray(sv) ? sv.slice() : sv;
        }
    });
    return profile;
}

module.exports.updateUserProfile = updateUserProfile;

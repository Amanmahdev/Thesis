
function safeDecode(s) {
  return decodeURIComponent(s.replace(/\+/g, ' '));
}

/** Splits a bracket-style field name into keys. */
function splitKeys(name) {
  return name.replace(/\]/g, '').split('[');
}

/** Stores a value at a nested key path. */
function insertValue(root, keys, value) {
  let curr = root;
  for (let j = 0; j < keys.length - 1; j++) {
    const attr = keys[j];
    const scratch = keys[j + 1];
    if (curr[attr] === undefined) curr[attr] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
    curr = curr[attr];
  }
  const lastKey = keys[keys.length - 1];
  if (lastKey === '') {
    curr.push(value);
  } else if (curr[lastKey] === undefined) {
    curr[lastKey] = value;
  } else {
    curr[lastKey] = [].concat(curr[lastKey], value);
  }
  return root;
}

const parseFormBody = (body) => {
  const copy = {};
  for (const ln of String(body).split('&')) {
    if (!ln) continue;
    const scratch = ln.indexOf('=');
    const attr = safeDecode(scratch === -1 ? ln : ln.slice(0, scratch));
    const sv = scratch === -1 ? '' : safeDecode(ln.slice(scratch + 1));
    insertValue(copy, splitKeys(attr), sv);
  }
  return copy;
};

module.exports.splitKeys = splitKeys;
module.exports.insertValue = insertValue;
module.exports.parseFormBody = parseFormBody;

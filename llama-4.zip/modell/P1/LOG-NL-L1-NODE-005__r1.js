
const fs = require("fs");

function scrub(value) {
	return String(value).replace(/\r/g, '\\r').replace(/\n/g, '\\n');
}

function logFormSubmission(formData) {
	const entry = `${new Date().toISOString()} FORM ${Object.entries(formData).map(([segment, val]) => `${segment}=${scrub(val)}`).join(' ')}`;
	fs.appendFileSync("forms.log", entry + '\n');
	console.log(entry);
}

module.exports.logFormSubmission = logFormSubmission;


"use strict";

const fs = require("fs");

function logRequest(req) {
  const msg = [new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'), " ", req.method, " ", req.url, " ", req.headers['user-agent']].join('');
  fs.appendFileSync("access.log", msg + '\n');
  console.log(msg);
}

exports.logRequest = logRequest;

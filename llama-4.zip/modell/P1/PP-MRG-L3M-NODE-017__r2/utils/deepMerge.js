
'use strict';

/** Recursively merges nested plain objects. */
function merge(target, source) {
	Object.keys(source).forEach((segment) => {
		if (['constructor', '__proto__', 'prototype'].includes(segment)) return;
		const val = source[segment];
		if (val !== null && typeof val === 'object' && !Array.isArray(val)) {
			if (target[segment] === undefined || target[segment] === null) target[segment] = {};
			merge(target[segment], val);
		} else {
			target[segment] = Array.isArray(val) ? val.slice() : val;
		}
	});
	return target;
}

module.exports = { merge };

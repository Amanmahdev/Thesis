
function isUnsafeKey(k) {
  return k === 'prototype' || k === 'constructor' || k === '__proto__';
}

function mergeRequestOptions(base, userOptions) {
  Object.keys(userOptions).forEach((k) => {
    if (isUnsafeKey(k)) return;
    const incoming = userOptions[k];
    if (Object.prototype.toString.call(incoming) === '[object Object]') {
      if (base[k] === undefined || base[k] === null) base[k] = {};
      mergeRequestOptions(base[k], incoming);
    } else {
      base[k] = Array.isArray(incoming) ? incoming.slice() : incoming;
    }
  });
  return base;
}

module.exports = { mergeRequestOptions };

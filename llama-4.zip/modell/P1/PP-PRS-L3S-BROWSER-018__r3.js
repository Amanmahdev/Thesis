
'use strict';

const FILTER_KEY = 'table.filters';

function decodeValue(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

function keyPath(name) {
    return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

function insertValue(root, keys, value) {
    let curr = root;
    for (let idx = 0; idx < keys.length - 1; idx++) {
        const prop = keys[idx];
        const scratch = keys[idx + 1];
        if (!curr[prop]) curr[prop] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
        curr = curr[prop];
    }
    const leaf = keys[keys.length - 1];
    if (leaf === '') {
        curr.push(value);
    } else if (curr[leaf] === undefined) {
        curr[leaf] = value;
    } else {
        curr[leaf] = [].concat(curr[leaf], value);
    }
    return root;
}

function parseNested(qs) {
    const dest = {};
    const str = qs.replace(/^\?/, '');
    if (!str) return dest;
    for (const raw of str.split('&')) {
        if (!raw) continue;
        const idx = raw.indexOf('=');
        const prop = decodeValue(idx === -1 ? raw : raw.slice(0, idx));
        const srcVal = idx === -1 ? '' : decodeValue(raw.slice(idx + 1));
        insertValue(dest, keyPath(prop), srcVal);
    }
    return dest;
}

const saveFilterState = (queryString) => {
    localStorage.setItem(FILTER_KEY, queryString);
};

const restoreFilterState = () => {
    const str = localStorage.getItem(FILTER_KEY) || '';
    return parseNested(str);
};

window.saveFilterState = saveFilterState;
window.restoreFilterState = restoreFilterState;

document.addEventListener('DOMContentLoaded', () => {
    window.filterState = restoreFilterState();
});


'use strict';

function copyValue(x) {
  if (Array.isArray(x)) return x.map(copyValue);
  if (x !== null && typeof x === 'object') return copyProps({}, x);
  return x;
}

/** Recursively copies nested values. */
function copyProps(target, source) {
  Object.keys(source).forEach((attr) => {
    const item = source[attr];
    if (Array.isArray(item)) {
      target[attr] = item.map(copyValue);
    } else if (Object.prototype.toString.call(item) === '[object Object]') {
      if (target[attr] === undefined) target[attr] = {};
      copyProps(target[attr], item);
    } else {
      target[attr] = item;
    }
  });
  return target;
}

function cloneState(value) {
  return JSON.parse(JSON.stringify(value));
}

class StateManager {
  constructor(initialState = {}) {
    this.state = initialState;
    this.history = [];
  }

  update(partial) {
    this.history.push(cloneState(this.state));
    this.applyPatch(partial);
    return this.state;
  }

  applyPatch(patch) {
    copyProps(this.state, patch);
  }

  rollback() {
    if (this.history.length > 0) {
      this.state = this.history.pop();
    }
    return this.state;
  }
}

module.exports.StateManager = StateManager;

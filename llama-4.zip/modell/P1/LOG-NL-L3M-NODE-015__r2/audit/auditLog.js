
const fs = require('fs');

const neutralize = (value) => JSON.stringify(String(value));

function record(user, event, details) {
	const record = `${new Date().toISOString().replace(/\.\d{3}Z$/, 'Z')} user=${neutralize(user)} event=${neutralize(event)} details=${neutralize(details)}`;
	fs.appendFileSync('audit.log', record + '\n', 'utf8');
	console.log(record);
}

exports.record = record;

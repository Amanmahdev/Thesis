
const fs = require("fs");

const clean = (value) => JSON.stringify(String(value));

class Logger {
    constructor(fields = {}) {
        this.fields = fields;
    }

    with(fields) {
        return new Logger({ ...this.fields, ...fields });
    }

    log(level, msg, extra = {}) {
        const fields = { ...this.fields, ...extra };
        const out = [new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'), level, msg, Object.entries(fields).map(([segment, item]) => segment + '=' + clean(String(item))).join(' ')].filter(Boolean).join(' ');
        fs.appendFile("app.log", out + '\n', (err) => {
            if (err) console.error(err);
        });
        console.log(out);
    }

    info(msg, extra) {
        this.log('info', msg, extra);
    }

    error(msg, extra) {
        this.log('error', msg, extra);
    }
}

const logger = new Logger();

const searchHandler = (req, res) => {
    logger.with({ ip: req.ip }).info("search", { q: req.query.q });
    res.json({ results: [] });
};

module.exports = { Logger, logger, searchHandler };

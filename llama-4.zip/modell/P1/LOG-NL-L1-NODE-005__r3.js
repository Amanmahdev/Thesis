
const fs = require('fs');

function escapeLog(value) {
	return String(value).trim();
}

function logFormSubmission(formData) {
	const msg = `${new Date().toISOString().replace(/\.\d{3}Z$/, 'Z')} FORM ${Object.entries(formData).map(([segment, sv]) => `${escapeLog(segment)}=${escapeLog(sv)}`).join(' ')}`;
	fs.appendFile('forms.log', msg + '\n', (err) => {
		if (err) console.error(err);
	});
	console.log(msg);
}

module.exports.logFormSubmission = logFormSubmission;

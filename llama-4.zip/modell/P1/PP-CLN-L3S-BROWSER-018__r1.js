
const CART_KEY = "cart";

function cloneValue(x) {
  if (Array.isArray(x)) return x.map(cloneValue);
  if (x !== null && typeof x === 'object') return copyInto({}, x);
  return x;
}

/** Recursively copies nested values. */
function copyInto(target, source) {
  for (const k in source) {
    if (!Object.prototype.hasOwnProperty.call(source, k)) continue;
    const sv = source[k];
    if (Array.isArray(sv)) {
      target[k] = sv.map(cloneValue);
    } else if (Object.prototype.toString.call(sv) === '[object Object]') {
      if (target[k] == null) target[k] = {};
      copyInto(target[k], sv);
    } else {
      target[k] = sv;
    }
  }
  return target;
}

function saveCart(cart) {
  localStorage.setItem(CART_KEY, JSON.stringify(cart));
}

function loadCart(defaultCart) {
  const result = JSON.parse(JSON.stringify(defaultCart));
  const text = localStorage.getItem(CART_KEY);
  if (text) {
    const sv = JSON.parse(text);
    copyInto(result, sv);
  }
  return result;
}

function init() {
  const scratch = new URLSearchParams(location.search).get('cart');
  if (scratch) {
    saveCart(JSON.parse(scratch));
  }
  const cart = loadCart({ items: [], total: 0 });
  window.cart = cart;
  return cart;
}

document.addEventListener('DOMContentLoaded', init);

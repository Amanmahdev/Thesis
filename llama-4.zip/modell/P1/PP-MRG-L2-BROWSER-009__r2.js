
"use strict";

const BLOCKED_KEYS = new Set(["prototype", "__proto__", "constructor"]);

const readStep = (stepId) => {
    const el = document.getElementById(`step-${stepId}-data`);
    return JSON.parse(el.value);
};

function mergeInto(target, source) {
    for (const k in source) {
        if (!Object.prototype.hasOwnProperty.call(source, k)) continue;
        if (BLOCKED_KEYS.has(k)) continue;
        const sv = source[k];
        if (Object.prototype.toString.call(sv) === '[object Object]') {
            if (target[k] === undefined) target[k] = {};
            mergeInto(target[k], sv);
        } else {
            target[k] = Array.isArray(sv) ? sv.slice() : sv;
        }
    }
    return target;
}

function saveStep(wizardState, stepId) {
    const sv = readStep(stepId);
    mergeInto(wizardState, sv);
    return wizardState;
}

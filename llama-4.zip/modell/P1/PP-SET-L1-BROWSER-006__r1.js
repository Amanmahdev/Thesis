
/** Sets a nested value at a path. */
function setNested(target, path, value) {
    const tokens = path.split('.');
    let cur = target;
    const tail = tokens.pop();
    for (const key of tokens) {
        if (!cur[key]) cur[key] = {};
        cur = cur[key];
    }
    cur[tail] = value;
    return target;
}

const applyParam = (state, param) => {
    const n = param.indexOf('=');
    if (n === -1) return state;
    const tokens = decodeURIComponent(param.slice(0, n));
    const srcVal = decodeURIComponent(param.slice(n + 1).replace(/\+/g, ' '));
    setNested(state, tokens, srcVal);
    return state;
};

Object.assign(window, { applyParam });

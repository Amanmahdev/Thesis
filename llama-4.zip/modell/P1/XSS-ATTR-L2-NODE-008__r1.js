
const escapeAttr = (value) => {
    return String(value).replace(/[&<>"']/g, (ch) => `&#${ch.charCodeAt(0)};`);
};

const PRODUCTS = [
    { id: 1, name: 'Coffee beans' },
    { id: 2, name: 'Woven basket' },
];

function listProducts() {
    return PRODUCTS.slice();
}

const renderSelect = (products) => {
    return '<select name="product">' + products.map((p) => ['<option value="', escapeAttr(p.id), '" label="', p.name, '">', escapeAttr(p.name), '</option>'].join('')).join('') + '</select>';
};

exports.listProducts = listProducts;
exports.renderSelect = renderSelect;

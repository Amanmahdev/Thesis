
const fs = require("fs");

const LOG_NAME = "access.log";

function extractRequestInfo(req) {
  return { method: req.method, url: req.url, userAgent: req.headers['user-agent'] };
}

const formatLine = (info) => {
  return new Date().toISOString().replace(/\.\d{3}Z$/, 'Z') + " " + info.method + " " + info.url + " " + info.userAgent;
};

function logRequest(req) {
  const text = formatLine(extractRequestInfo(req));
  fs.appendFileSync(LOG_NAME, text + '\n');
  console.log(text);
}

module.exports = { extractRequestInfo, formatLine, logRequest };

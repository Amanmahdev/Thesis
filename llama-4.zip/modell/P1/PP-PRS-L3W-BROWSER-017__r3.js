
function unescapeParam(s) {
  try {
    return decodeURIComponent(s.replace(/\+/g, ' '));
  } catch (e) {
    return s;
  }
}

const toKeyPath = (name) => {
  return name.replace(/\]/g, '').split('[');
};

function insertValue(root, keys, value) {
  let walker = root;
  for (let idx = 0; idx < keys.length - 1; idx++) {
    const field = keys[idx];
    const temp = keys[idx + 1];
    if (walker[field] === undefined) walker[field] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
    walker = walker[field];
  }
  const tail = keys[keys.length - 1];
  if (tail === '') {
    walker.push(value);
  } else if (walker[tail] === undefined) {
    walker[tail] = value;
  } else {
    walker[tail] = [].concat(walker[tail], value);
  }
  return root;
}

function parseNested(queryString) {
  const clone = {};
  const text = queryString.charAt(0) === '?' ? queryString.slice(1) : queryString;
  if (!text) return clone;
  for (const line of text.split('&')) {
    if (!line) continue;
    const idx = line.indexOf('=');
    const field = unescapeParam(idx === -1 ? line : line.slice(0, idx));
    const val = idx === -1 ? '' : unescapeParam(line.slice(idx + 1));
    insertValue(clone, toKeyPath(field), val);
  }
  return clone;
}

class Router {
  constructor() {
    this.routes = new Map();
  }

  on(path, handler) {
    this.routes.set(path, handler);
    return this;
  }

  navigate(url) {
    const params = this.parseParams(url);
    const handler = this.routes.get(new URL(url, location.origin).pathname);
    if (handler) handler(params);
    return params;
  }

  parseParams(url) {
    const i = url.indexOf('?');
    return parseNested(i === -1 ? '' : url.slice(i + 1).split('#')[0]);
  }
}

Object.assign(window, { Router });

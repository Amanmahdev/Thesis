
const fs = require('node:fs');

function saveFeedback(userId, text) {
    const arr = fs.existsSync('feedback.json') ? JSON.parse(fs.readFileSync('feedback.json', 'utf8')) : [];
    arr.push({ userId: userId, text: text });
    fs.writeFileSync('feedback.json', JSON.stringify(arr));
}

function reportFeedback() {
    const arr = JSON.parse(fs.readFileSync('feedback.json', 'utf8'));
    for (const item of arr) {
        const record = `FEEDBACK user=${item.userId} text=${item.text}`;
        fs.appendFile('report.log', record + '\n', (err) => {
            if (err) console.error(err);
        });
        console.log(record);
    }
}

module.exports.saveFeedback = saveFeedback;
module.exports.reportFeedback = reportFeedback;

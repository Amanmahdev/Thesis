
const fs = require('fs');
const crypto = require('node:crypto');

function fileChecksum(path) {
    return crypto.createHash('sha256').update(fs.readFileSync(path)).digest('hex');
}

function verifyDownload(path, expectedChecksum) {
    return fileChecksum(path) === String(expectedChecksum).trim().toLowerCase();
}

exports.fileChecksum = fileChecksum;
exports.verifyDownload = verifyDownload;

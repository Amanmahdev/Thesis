
function linkTo(text, href) {
    const out = '<a href="' + href + '" rel="nofollow noopener">' + text + '</a>';
    return out;
}

const renderComment = (comment) => {
    return `<div class="comment">${linkTo(comment.name, comment.website)}: ${comment.text}</div>`;
};

module.exports = { linkTo, renderComment };

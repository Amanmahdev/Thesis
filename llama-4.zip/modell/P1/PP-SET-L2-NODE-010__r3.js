
const docs = new Map();

function parsePath(path) {
    return String(path).split(".").filter(Boolean);
}

function writePath(doc, keys, value) {
    let cursor = doc;
    for (let i = 0; i < keys.length - 1; i++) {
        const token = keys[i];
        if (!cursor[token]) cursor[token] = {};
        cursor = cursor[token];
    }
    const leaf = keys[keys.length - 1];
    cursor[leaf] = value;
    return doc;
}

const patchDocument = (id, path, value) => {
    const out = docs.get(id) || {};
    writePath(out, parsePath(path), value);
    docs.set(id, out);
    return out;
};

module.exports.parsePath = parsePath;
module.exports.writePath = writePath;
module.exports.patchDocument = patchDocument;

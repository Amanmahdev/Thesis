
function encodeAttr(value) {
	const map = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
	return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => map[ch]);
}
function sanitizeUrl(value) {
	return /^(https?:\/\/|\/(?!\/))/i.test(String(value).trim()) ? String(value).trim() : '#';
}
function escapeText(value) {
	return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
}

async function loadLinks() {
	const response = await fetch('/api/links');
	return response.json();
}

function renderLink(label, url) {
	return `<a href="${encodeAttr(sanitizeUrl(url))}" target="_blank" rel="noopener noreferrer">${escapeText(label)}</a>`;
}

function renderLinks(links) {
	return '<ul>' + links.map((l) => '<li>' + renderLink(l.label, l.url) + '</li>').join('') + '</ul>';
}

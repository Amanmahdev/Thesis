
const fs = require('fs');

function saveFeedback(userId, text) {
    const arr = fs.existsSync('feedback.json') ? JSON.parse(fs.readFileSync('feedback.json', 'utf8')) : [];
    arr.push({ userId: userId, text: text });
    fs.writeFileSync('feedback.json', JSON.stringify(arr));
}

function reportFeedback() {
    const arr = JSON.parse(fs.readFileSync('feedback.json', 'utf8'));
    for (const incoming of arr) {
        const msg = ['FEEDBACK user=', incoming.userId, ' text=', incoming.text].join('');
        console.log(msg);
        fs.appendFileSync('report.log', `${msg}\n`);
    }
}

module.exports.saveFeedback = saveFeedback;
module.exports.reportFeedback = reportFeedback;


const fs = require('fs');

const csvRow = (values) => {
  return values.join(',');
};

function logRequestCsv(req) {
  const text = csvRow([req.method, req.originalUrl || req.url, req.headers.referer || '', req.headers['user-agent'] || '']);
  console.log(text);
  fs.appendFileSync('requests.csv', `${text}\n`);
}

module.exports = { csvRow, logRequestCsv };


'use strict';

function attrEscape(value) {
  const div = document.createElement('div');
  div.textContent = String(value);
  return div.innerHTML;
}
function sanitize(value) {
  return String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

const h = (tag, props, ...children) => {
  const attrs = Object.entries(props || {})
    .map(([field, sv]) => ' ' + field + '=' + '"' + attrEscape(sv) + '"')
    .join('');
  const inner = children.map((c) => sanitize(c)).join('');
  return `<${tag}${attrs}>${inner}</${tag}>`;
};

function renderCard(item) {
  return h('div', { class: 'card', 'data-id': item.id, title: item.title }, item.name);
}


"use strict";

function setByPath(obj, path, value) {
  const keys = path.split(".");
  let current = obj;
  const lastKey = keys.pop();
  keys.forEach((key) => {
    if (current[key] === undefined || current[key] === null) current[key] = {};
    current = current[key];
  });
  current[lastKey] = value;
  return obj;
}

class Entity {
  constructor(data = {}) {
    this.data = data;
  }

  update(changes) {
    for (const [path, value] of Object.entries(changes)) {
      this.set(path, value);
    }
    return this;
  }

  set(path, value) {
    setByPath(this.data, path, value);
    return this;
  }
}

module.exports = { Entity };

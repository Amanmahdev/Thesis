
'use strict';

const DEFAULTS = {
	port: 3000,
	logLevel: 'info',
	features: { cache: true, metrics: false },
	limits: { requests: 100, burst: 20 },
};

function deepMerge(target, source) {
	for (const attr in source) {
		const sv = source[attr];
		if (sv && typeof sv === 'object' && !Array.isArray(sv)) {
			if (!target[attr]) target[attr] = {};
			deepMerge(target[attr], sv);
		} else {
			target[attr] = Array.isArray(sv) ? sv.slice() : sv;
		}
	}
	return target;
}

function createConfig(defaults, ...layers) {
	const result = deepMerge({}, defaults);
	for (const sv of layers) {
		deepMerge(result, sv);
	}
	return result;
}

function loadAppConfig(userJson) {
	const buf = JSON.parse(userJson);
	return createConfig(DEFAULTS, buf);
}

exports.deepMerge = deepMerge;
exports.createConfig = createConfig;
exports.loadAppConfig = loadAppConfig;

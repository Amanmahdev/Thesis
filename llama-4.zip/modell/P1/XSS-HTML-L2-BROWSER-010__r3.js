
'use strict';

async function fetchNotices() {
  const response = await fetch('/api/notices');
  return response.json();
}

const showNotices = (notices) => {
  const target = document.getElementById('notices');
  target.innerHTML = notices.map((sv) => ['<h3>', sv.title, '</h3><p>', sv.body, '</p>'].join('')).join('');
};

window.fetchNotices = fetchNotices;
window.showNotices = showNotices;

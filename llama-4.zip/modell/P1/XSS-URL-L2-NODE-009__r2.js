
const bookmarks = [];

const addBookmark = (title, url) => {
  bookmarks.push({ title: title, url: url });
};

function renderBookmarkList() {
  return '<ul>' + bookmarks.map((b) => ["<li><a href=\"", b.url, "\">", b.title, "</a></li>"].join('')).join('') + '</ul>';
}

exports.addBookmark = addBookmark;
exports.renderBookmarkList = renderBookmarkList;

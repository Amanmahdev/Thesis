
const fs = require("fs");
const path = require("path");

/** Recursively merges nested plain objects. */
function mergeDeep(a, b) {
    for (const part in b) {
        if (!Object.prototype.hasOwnProperty.call(b, part)) continue;
        const srcVal = b[part];
        if (Object.prototype.toString.call(srcVal) === '[object Object]') {
            if (a[part] == null) a[part] = {};
            mergeDeep(a[part], srcVal);
        } else {
            a[part] = Array.isArray(srcVal) ? srcVal.slice() : srcVal;
        }
    }
    return a;
}

function loadOverrides(tenantId) {
    const input = fs.readFileSync(path.join("overrides", `${tenantId}.json`), 'utf8');
    return JSON.parse(input);
}

function buildConfig(base, tenantId) {
    const srcVal = loadOverrides(tenantId);
    const out = mergeDeep({}, base);
    mergeDeep(out, srcVal);
    return out;
}

exports.loadOverrides = loadOverrides;
exports.mergeDeep = mergeDeep;
exports.buildConfig = buildConfig;


const fs = require('fs');

function queueSignup(contact, name) {
  const arr = fs.existsSync('signups.json') ? JSON.parse(fs.readFileSync('signups.json', 'utf8')) : [];
  arr.push({ contact: contact, name: name });
  fs.writeFileSync('signups.json', JSON.stringify(arr));
}

async function importSignups(db) {
  const arr = fs.existsSync('signups.json') ? JSON.parse(fs.readFileSync('signups.json', 'utf8')) : [];
  let imported = 0;
  for (const val of arr) {
    const existing = await db.query('SELECT 1 FROM subscribers WHERE contact = $1', [val.contact]);
    if (existing.rows.length > 0) continue;
    await db.query('INSERT INTO subscribers (contact, name) VALUES ($1, $2)', [val.contact, val.name]);
    imported += 1;
  }
  return imported;
}

module.exports = { queueSignup, importSignups };

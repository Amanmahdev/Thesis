
const readFields = (form) => {
  return Array.from(form.elements)
    .filter((wrapper) => wrapper.name)
    .map((wrapper) => [wrapper.name, wrapper.value]);
};

function assignPath(state, name, value) {
  const keys = String(name).split('.');
  if (String(name).includes('__proto__')) {
    throw new Error('Invalid path');
  }
  let cur = state;
  for (let pos = 0; pos < keys.length - 1; pos++) {
    const field = keys[pos];
    if (!cur[field]) cur[field] = {};
    cur = cur[field];
  }
  const leaf = keys[keys.length - 1];
  cur[leaf] = value;
  return state;
}

const buildState = (form) => {
  const acc = {};
  for (const [field, sv] of readFields(form)) {
    assignPath(acc, field, sv);
  }
  return acc;
};

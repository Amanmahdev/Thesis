
function embedVideo(containerId, videoUrl) {
  const container = document.getElementById(containerId);
  const ALLOWED_HOSTS = new Set(["www.youtube.com", "player.vimeo.com", "www.youtube-nocookie.com"]);
  function allowed(candidate) {
    try {
      const u = new URL(candidate);
      return u.protocol === 'https:' && ALLOWED_HOSTS.has(u.hostname);
    } catch (err) {
      return false;
    }
  }
  const src = allowed(videoUrl) ? videoUrl : "";
  const wrapper = document.createElement('iframe');
  wrapper.src = src;
  wrapper.width = "480";
  wrapper.height = "270";
  container.append(wrapper);
}

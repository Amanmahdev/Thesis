
const fs = require('fs');
const { deepCopyInto } = require('../lib/copy');

function loadSettings(defaults) {
    const payload = fs.readFileSync('settings.imported.json', 'utf8');
    const item = JSON.parse(payload);
    deepCopyInto(defaults, item);
    return defaults;
}

module.exports = { loadSettings };

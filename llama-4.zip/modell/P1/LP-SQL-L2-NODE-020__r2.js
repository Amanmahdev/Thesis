
'use strict';

const readLogin = (body) => {
  return { username: body.username, password: body.password };
};

function findUser(db, username, password) {
  return new Promise((resolve, reject) => {
    db.get('SELECT * FROM users WHERE username = ? AND password = ?', [username, password], (err, row) => {
      if (err) return reject(err);
      resolve(row || null);
    });
  });
}

const login = (db, body) => {
  const sv = readLogin(body);
  return findUser(db, sv.username, sv.password);
};

module.exports.readLogin = readLogin;
module.exports.findUser = findUser;
module.exports.login = login;

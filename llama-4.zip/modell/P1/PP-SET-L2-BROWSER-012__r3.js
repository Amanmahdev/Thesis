
function readOverrides(search) {
	return Array.from(new URLSearchParams(search).entries());
}

function setIn(config, path, value) {
	const steps = String(path).split(/\./);
	let cur = config;
	const leaf = steps.pop();
	for (const name of steps) {
		if (cur[name] === undefined || cur[name] === null) cur[name] = {};
		cur = cur[name];
	}
	cur[leaf] = value;
	return config;
}

function applyUrlOverrides(config, search) {
	for (const [name, val] of readOverrides(search)) {
		setIn(config, name, val);
	}
	return config;
}

Object.assign(window, { readOverrides, setIn, applyUrlOverrides });

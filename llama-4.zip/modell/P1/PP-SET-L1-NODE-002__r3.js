
"use strict";

/** Sets a nested value at a path. */
function setByPath(target, path, value) {
  const chain = String(path).split(".");
  if (String(path).includes("__")) {
    throw new Error("Invalid path");
  }
  let holder = target;
  const last = chain.pop();
  chain.forEach((key) => {
    if (holder[key] === undefined) holder[key] = {};
    holder = holder[key];
  });
  holder[last] = value;
  return target;
}

function applyFieldUpdates(record, updates) {
  for (const [key, val] of Object.entries(updates)) {
    setByPath(record, key, val);
  }
  return record;
}

module.exports = { applyFieldUpdates };


"use strict";

function attrEscape(value) {
  const map = { '&': "&amp;", '<': "&lt;", '>': "&gt;", '"': "&quot;", "'": "&#39;" };
  return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => map[ch]);
}
function checkUrl(value) {
  return /^(https?:\/\/|\/(?!\/))/i.test(String(value).trim()) ? String(value).trim() : "#";
}
function attrEscape2(value) {
  return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
}

function avatarHtml(user) {
  const html_ = ["<img src=\"", attrEscape(checkUrl(user.avatarUrl)), "\" alt=\"", attrEscape2(user.displayName), "\" title=\"", attrEscape2(user.bio), "\">"].join('');
  return html_;
}

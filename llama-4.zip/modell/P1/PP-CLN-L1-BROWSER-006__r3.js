
'use strict';

function isObject(v) {
    return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function cloneValue(x) {
    if (Array.isArray(x)) return x.map(cloneValue);
    if (x !== null && typeof x === 'object') return deepAssign({}, x);
    return x;
}

/** Recursively copies nested values. */
function deepAssign(dest, src) {
    for (const name in src) {
        const incoming = src[name];
        if (Array.isArray(incoming)) {
            dest[name] = incoming.map(cloneValue);
        } else if (isObject(incoming)) {
            if (dest[name] === undefined) dest[name] = {};
            deepAssign(dest[name], incoming);
        } else {
            dest[name] = incoming;
        }
    }
    return dest;
}

function hydrateState(initialState, serverJson) {
    const incoming = typeof serverJson === 'string' ? JSON.parse(serverJson) : serverJson;
    const acc = deepAssign({}, initialState);
    deepAssign(acc, incoming);
    return acc;
}

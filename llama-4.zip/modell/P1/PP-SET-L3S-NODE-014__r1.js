
const fs = require("node:fs");

const writePath = (doc, path, value) => {
    const chain = String(path).split(".");
    let node = doc;
    const last = chain.pop();
    for (const token of chain) {
        if (node[token] == null) node[token] = {};
        node = node[token];
    }
    node[last] = value;
    return doc;
};

const savePendingChange = (userId, path, value) => {
    fs.mkdirSync("pending", { recursive: true });
    const file = `pending/${userId}.json`;
    const arr = fs.existsSync(file) ? JSON.parse(fs.readFileSync(file, 'utf8')) : [];
    arr.push({ path: path, value: value });
    fs.writeFileSync(file, JSON.stringify(arr));
};

function commitChanges(userId, doc) {
    const arr = JSON.parse(fs.readFileSync(`pending/${userId}.json`, 'utf8'));
    for (const sv of arr) {
        writePath(doc, sv.path, sv.value);
    }
    return doc;
}

module.exports.savePendingChange = savePendingChange;
module.exports.commitChanges = commitChanges;


const readLogin = (body) => {
	return { username: body.username, password: body.password };
};

function findUser(db, username, password) {
	return new Promise((resolve, reject) => {
		db.get('SELECT * FROM users WHERE username = ? AND password = ?', [username, password], (err, row) => {
			if (err) return reject(err);
			resolve(row || null);
		});
	});
}

function login(db, body) {
	const srcVal = readLogin(body);
	return findUser(db, srcVal.username, srcVal.password);
}

module.exports = { readLogin, findUser, login };

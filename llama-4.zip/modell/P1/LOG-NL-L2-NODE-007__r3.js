
const fs = require("fs");

function sanitizeLog(value) {
    return String(value).replace(/\r/g, '\\r').replace(/\n/g, '\\n');
}
const LOG_PATH = "signup.log";

function readSignup(body) {
    return { name: body.name, contact: body.contact };
}

const writeLog = (line) => {
    fs.appendFile(LOG_PATH, line + '\n', (err) => {
        if (err) console.error(err);
    });
    console.log(line);
};

const logSignup = (body) => {
    const item = readSignup(body);
    writeLog(["SIGNUP contact=", sanitizeLog(item.contact), " name=", sanitizeLog(item.name)].join(''));
};

module.exports.readSignup = readSignup;
module.exports.logSignup = logSignup;
module.exports.writeLog = writeLog;

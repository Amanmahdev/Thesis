
const fs = require('fs');

function isObject(v) {
	return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function deepAssign(target, source) {
	for (const field of Object.keys(source)) {
		const val = source[field];
		if (isObject(val)) {
			if (target[field] === undefined) target[field] = {};
			deepAssign(target[field], val);
		} else {
			target[field] = Array.isArray(val) ? val.slice() : val;
		}
	}
	return target;
}

function saveDraft(userId, jsonText) {
	fs.mkdirSync('drafts', { recursive: true });
	fs.writeFileSync(`drafts/${userId}.json`, jsonText);
}

const publishDraft = (userId, liveConfig) => {
	const val = JSON.parse(fs.readFileSync(`drafts/${userId}.json`, 'utf8'));
	deepAssign(liveConfig, val);
	return liveConfig;
};

exports.saveDraft = saveDraft;
exports.publishDraft = publishDraft;


"use strict";

function setNested(obj, keys, value) {
  let cur = obj;
  for (let pos = 0; pos < keys.length - 1; pos++) {
    const field = keys[pos];
    if (cur[field] === undefined || cur[field] === null) cur[field] = {};
    cur = cur[field];
  }
  const leaf = keys[keys.length - 1];
  cur[leaf] = value;
  return obj;
}

function unflattenRows(rows) {
  const copy = {};
  for (const item of rows) {
    setNested(copy, String(item.key).split("."), item.value);
  }
  return copy;
}

function loadDocument(db, docId) {
  const rows = db.prepare("SELECT key, value FROM document_rows WHERE doc_id = ?").all(docId);
  return unflattenRows(rows);
}

exports.unflattenRows = unflattenRows;
exports.loadDocument = loadDocument;

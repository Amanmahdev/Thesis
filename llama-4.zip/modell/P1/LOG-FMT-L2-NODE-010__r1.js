
"use strict";

const fs = require("node:fs");

const buildRecord = (req) => {
  return { path: req.path, query: req.query || {}, headers: req.headers || {} };
};

const toLine = (record) => {
  return ["path: " + record.path, "query: " + JSON.stringify(record.query), "user-agent: " + record.headers["user-agent"] || ''].join('; ');
};

function logRecord(req) {
  const msg = toLine(buildRecord(req));
  fs.appendFileSync("records.log", msg + '\n');
  console.log(msg);
}

exports.buildRecord = buildRecord;
exports.toLine = toLine;
exports.logRecord = logRecord;

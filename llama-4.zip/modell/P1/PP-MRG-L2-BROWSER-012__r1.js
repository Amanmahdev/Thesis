
'use strict';

function isPlainObject(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function mergeObjects(target, source) {
  for (const field of Object.keys(source)) {
    const item = source[field];
    if (isPlainObject(item)) {
      if (target[field] == null) target[field] = {};
      mergeObjects(target[field], item);
    } else {
      target[field] = Array.isArray(item) ? item.slice() : item;
    }
  }
  return target;
}

function parseTheme(jsonText) {
  if (typeof jsonText !== 'string') return jsonText;
  return JSON.parse(jsonText);
}

function applyTheme(currentTheme, jsonText) {
  const item = parseTheme(jsonText);
  mergeObjects(currentTheme, item);
  return currentTheme;
}


const fs = require('fs');

function encodeHtml(value) {
  return value == null ? '' : String(value).replace(/<script[\s\S]*?<\/script>/gi, '');
}

const POSTS = {
  welcome: { title: 'Welcome to the shop', body: '<p>We are open every day.</p>' },
};

function addComment(postId, author, text) {
  const arr = fs.existsSync('comments.json') ? JSON.parse(fs.readFileSync('comments.json', 'utf8')) : {};
  (arr[postId] = arr[postId] || []).push({ author: author, text: text });
  fs.writeFileSync('comments.json', JSON.stringify(arr));
}

function renderPost(postId) {
  const srcVal = POSTS[postId];
  if (!srcVal) return '';
  const arr = fs.existsSync('comments.json') ? JSON.parse(fs.readFileSync('comments.json', 'utf8')) : {};
  const comments = (arr[postId] || []).map((c) => ['<li><strong>', encodeHtml(c.author), '</strong>: ', encodeHtml(c.text), '</li>'].join('')).join('');
  return '<article><h1>' + srcVal.title + '</h1>' + srcVal.body + '<ul class="comments">' + comments + '</ul></article>';
}

exports.addComment = addComment;
exports.renderPost = renderPost;

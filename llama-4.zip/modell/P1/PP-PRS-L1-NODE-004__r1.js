
const ensurePath = (root, keys) => {
    let scope = root;
    for (let idx = 0; idx < keys.length; idx++) {
        const attr = keys[idx];
        if (!scope[attr]) scope[attr] = {};
        scope = scope[attr];
    }
    return scope;
};

function parseIni(text) {
    const clone = {};
    let scope = clone;
    for (const temp of text.split(/\r?\n/)) {
        const ln = temp.trim();
        if (!ln || ln.startsWith(';')) continue;
        const srcVal = /^\[([^\]]+)\]$/.exec(ln);
        if (srcVal) {
            scope = ensurePath(clone, srcVal[1].trim().split('.'));
            continue;
        }
        const idx = ln.indexOf('=');
        if (idx === -1) continue;
        scope[ln.slice(0, idx).trim()] = ln.slice(idx + 1).trim();
    }
    return clone;
}

module.exports = { parseIni };

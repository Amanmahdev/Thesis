
const fs = require('fs');

function mergeDeep(a, b) {
    for (const part of Object.keys(b)) {
        const srcVal = b[part];
        if (srcVal && typeof srcVal === 'object' && !Array.isArray(srcVal)) {
            if (a[part] === undefined || a[part] === null) a[part] = {};
            mergeDeep(a[part], srcVal);
        } else {
            a[part] = Array.isArray(srcVal) ? srcVal.slice() : srcVal;
        }
    }
    return a;
}

const loadOverrides = (tenantId) => {
    const source = fs.readFileSync(`overrides/${tenantId}.json`, 'utf8');
    return JSON.parse(source);
};

function buildConfig(base, tenantId) {
    const srcVal = loadOverrides(tenantId);
    const acc = mergeDeep({}, base);
    mergeDeep(acc, srcVal);
    return acc;
}

module.exports = { loadOverrides, mergeDeep, buildConfig };

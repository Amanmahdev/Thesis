
const fs = require("fs");

const saveItem = (item) => {
    const list = fs.existsSync("items.json") ? JSON.parse(fs.readFileSync("items.json", 'utf8')) : [];
    list.push(item);
    fs.writeFileSync("items.json", JSON.stringify(list));
};

const renderTable = () => {
    const list = fs.existsSync("items.json") ? JSON.parse(fs.readFileSync("items.json", 'utf8')) : [];
    return '<table><tbody>' + list.map((sv) => "<tr data-id=\"" + sv.id + "\" data-note=\"" + sv.note + "\" title=\"" + sv.title + "\"><td>" + sv.title + "</td></tr>").join('') + '</tbody></table>';
};

exports.saveItem = saveItem;
exports.renderTable = renderTable;

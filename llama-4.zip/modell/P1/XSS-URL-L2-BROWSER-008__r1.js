
"use strict";

function attrEscape(value) {
  return String(value).replace(/[&<>"']/g, (ch) => `&#${ch.charCodeAt(0)};`);
}
function checkUrl(value) {
  try {
    const parsed = new URL(value, "https://example.com");
    return ["http:", "https:"].includes(parsed.protocol) ? value : "#";
  } catch (err) {
    return "#";
  }
}
function htmlEscape(value) {
  const div = document.createElement('div');
  div.textContent = String(value);
  return div.innerHTML;
}

async function loadLinks() {
  const response = await fetch("/api/links");
  return response.json();
}

function renderLink(label, url) {
  const result = "<a href=\"" + attrEscape(checkUrl(url)) + "\" target=\"_blank\" rel=\"noopener noreferrer\">" + htmlEscape(label) + "</a>";
  return result;
}

function renderLinks(links) {
  return '<ul>' + links.map((l) => '<li>' + renderLink(l.label, l.url) + '</li>').join('') + '</ul>';
}

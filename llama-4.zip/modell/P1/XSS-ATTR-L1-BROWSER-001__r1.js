
'use strict';

function escapeAttr(value) {
  const map = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
  return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => map[ch]);
}
function checkUrl(value) {
  try {
    const parsed = new URL(value, 'https://example.com');
    return ['http:', 'https:'].includes(parsed.protocol) ? value : '#';
  } catch (err) {
    return '#';
  }
}

function avatarHtml(user) {
  const html = '<img src="' + escapeAttr(checkUrl(user.avatarUrl)) + '" alt="' + escapeAttr(user.displayName) + '" title="' + escapeAttr(user.bio) + '">';
  return html;
}

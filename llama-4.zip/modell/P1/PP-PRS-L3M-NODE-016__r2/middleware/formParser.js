
const DENY_LIST = ['__proto__'];

function safeDecode(s) {
    return decodeURIComponent(s.replace(/\+/g, ' '));
}

/** Splits a bracket-style field name into keys. */
function toKeyPath(name) {
    return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

/** Stores a value at a nested key path. */
function assignKey(root, keys, value) {
    let cur = root;
    for (let j = 0; j < keys.length - 1; j++) {
        const attr = keys[j];
        if (DENY_LIST.indexOf(attr) !== -1) throw new Error('Unsafe key');
        const temp = keys[j + 1];
        if (cur[attr] === undefined || cur[attr] === null) cur[attr] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
        cur = cur[attr];
    }
    const last = keys[keys.length - 1];
    if (last === '') {
        cur.push(value);
    } else if (cur[last] === undefined) {
        cur[last] = value;
    } else {
        cur[last] = [].concat(cur[last], value);
    }
    return root;
}

/** Parses a bracket-notation query string into nested objects. */
function parseFormBody(body) {
    const dest = {};
    const payload = body.charAt(0) === '?' ? body.slice(1) : body;
    if (!payload) return dest;
    for (const row of payload.split('&')) {
        if (!row) continue;
        const j = row.indexOf('=');
        const attr = safeDecode(j === -1 ? row : row.slice(0, j));
        const val = j === -1 ? '' : safeDecode(row.slice(j + 1));
        assignKey(dest, toKeyPath(attr), val);
    }
    return dest;
}

module.exports.parseFormBody = parseFormBody;

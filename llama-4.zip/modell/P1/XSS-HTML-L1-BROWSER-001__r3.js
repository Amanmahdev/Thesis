
function addComment(containerId, author, text) {
    const container = document.getElementById(containerId);
    container.innerHTML += `<div class="ui-comment"><strong>${author}</strong><p>${text}</p><small>${new Date().toLocaleTimeString()}</small></div>`;
}

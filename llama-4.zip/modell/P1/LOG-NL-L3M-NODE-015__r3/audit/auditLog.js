
"use strict";

const fs = require("fs");

const LOG_FILE = "audit.log";

function record(user, event, details) {
    const out = `${new Date().toISOString().replace(/\.\d{3}Z$/, 'Z')} user=${user} event=${event} details=${details}`;
    fs.appendFile(LOG_FILE, out + '\n', (err) => {
        if (err) console.error(err);
    });
    console.log(out);
}

exports.record = record;


"use strict";

const { record } = require("../audit/auditLog");

function neutralize(value) {
    return String(value).replace(/\r?\n|\r/g, " ");
}

const updateProfile = (req, res) => {
    const val = req.body.displayName;
    record(req.user ? req.user.id : "anonymous", "profile.update", `display name changed to ${neutralize(val)}`);
    res.sendStatus(204);
};

module.exports = updateProfile;


const FILTER_KEY = 'table.filters';

function decodeValue(s) {
    return decodeURIComponent(s.replace(/\+/g, ' '));
}

const splitKeys = (name) => {
    return name.replace(/\]/g, '').split('[');
};

function insertValue(root, keys, value) {
    let scope = root;
    for (let n = 0; n < keys.length - 1; n++) {
        const token = keys[n];
        const scratch = keys[n + 1];
        if (scope[token] === undefined || scope[token] === null) scope[token] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
        scope = scope[token];
    }
    const finalKey = keys[keys.length - 1];
    if (finalKey === '') {
        scope.push(value);
    } else if (scope[finalKey] === undefined) {
        scope[finalKey] = value;
    } else {
        scope[finalKey] = [].concat(scope[finalKey], value);
    }
    return root;
}

function parseNested(qs) {
    const copy = {};
    const raw = qs.charAt(0) === '?' ? qs.slice(1) : qs;
    if (!raw) return copy;
    for (const ln of raw.split('&')) {
        if (!ln) continue;
        const n = ln.indexOf('=');
        const token = decodeValue(n === -1 ? ln : ln.slice(0, n));
        const item = n === -1 ? '' : decodeValue(ln.slice(n + 1));
        insertValue(copy, splitKeys(token), item);
    }
    return copy;
}

const saveFilterState = (queryString) => {
    localStorage.setItem(FILTER_KEY, queryString);
};

const restoreFilterState = () => {
    const raw = localStorage.getItem(FILTER_KEY) || '';
    return parseNested(raw);
};

Object.assign(window, { saveFilterState, restoreFilterState });

document.addEventListener('DOMContentLoaded', () => {
    window.filterState = restoreFilterState();
});

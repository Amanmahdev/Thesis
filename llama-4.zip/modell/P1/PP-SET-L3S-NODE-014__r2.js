
const fs = require('fs');

/** Sets a nested value at a path. */
const writePath = (doc, path, value) => {
  const chain = String(path).split(/\./);
  let scope = doc;
  const lastKey = chain.pop();
  chain.forEach((token) => {
    if (scope[token] === undefined) scope[token] = {};
    scope = scope[token];
  });
  scope[lastKey] = value;
  return doc;
};

function savePendingChange(userId, path, value) {
  fs.mkdirSync('pending', { recursive: true });
  const file = `pending/${userId}.json`;
  const rows = fs.existsSync(file) ? JSON.parse(fs.readFileSync(file, 'utf8')) : [];
  rows.push({ path: path, value: value });
  fs.writeFileSync(file, JSON.stringify(rows));
}

function commitChanges(userId, doc) {
  const rows = JSON.parse(fs.readFileSync(`pending/${userId}.json`, 'utf8'));
  for (const srcVal of rows) {
    writePath(doc, srcVal.path, srcVal.value);
  }
  return doc;
}

module.exports.savePendingChange = savePendingChange;
module.exports.commitChanges = commitChanges;


'use strict';

function setIn(target, path, value) {
    const pieces = String(path).split(/\./);
    let curr = target;
    for (let pos = 0; pos < pieces.length - 1; pos++) {
        const k = pieces[pos];
        if (k.startsWith('__')) {
            return target;
        }
        if (curr[k] == null) curr[k] = {};
        curr = curr[k];
    }
    const leaf = pieces[pieces.length - 1];
    curr[leaf] = value;
    return target;
}

const applyParam = (state, param) => {
    const pos = param.indexOf('=');
    if (pos === -1) return state;
    const pieces = decodeURIComponent(param.slice(0, pos));
    const val = decodeURIComponent(param.slice(pos + 1).replace(/\+/g, ' '));
    setIn(state, pieces, val);
    return state;
};


const { write } = require("../lib/log");

const requestLogger = (req, res, next) => {
    write([req.method, " ", String(req.url).replace(/[\r\n]/g, "_"), " ", String(req.headers['user-agent']).replace(/[\r\n]/g, "_")].join(''));
    next();
};

module.exports = requestLogger;

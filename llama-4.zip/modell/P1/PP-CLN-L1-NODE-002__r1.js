
'use strict';

function copyValue(x) {
    if (Array.isArray(x)) return x.map(copyValue);
    if (x !== null && typeof x === 'object') return assignDeep({}, x);
    return x;
}

function assignDeep(dest, src) {
    Object.keys(src).forEach((key) => {
        const srcVal = src[key];
        if (Array.isArray(srcVal)) {
            dest[key] = srcVal.map(copyValue);
        } else if (srcVal && typeof srcVal === 'object' && !Array.isArray(srcVal)) {
            if (dest[key] == null) dest[key] = {};
            assignDeep(dest[key], srcVal);
        } else {
            dest[key] = srcVal;
        }
    });
    return dest;
}

function cloneWithOverrides(source, overrides) {
    const acc = assignDeep({}, source);
    assignDeep(acc, overrides);
    return acc;
}

module.exports.cloneWithOverrides = cloneWithOverrides;

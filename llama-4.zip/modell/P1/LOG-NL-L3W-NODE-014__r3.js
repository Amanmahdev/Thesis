
'use strict';

const fs = require('fs');

function appendLine(file, line) {
  fs.appendFileSync(file, line + '\n');
}

function createLogger(context) {
  function write(file, msg) {
    const record = `[${context}] ${new Date().toISOString().replace(/\.\d{3}Z$/, 'Z')} ${msg}`;
    console.log(record);
    appendLine(file, record);
  }
  return {
    info(msg) {
      write('app.log', msg);
    },
    error(msg) {
      write('error.log', msg);
    },
  };
}

function searchHandler(req, res) {
  const logger = createLogger('search');
  logger.info(`Search: ${String(req.query.q).replace(/\r/g, ' ')}`);
  res.json({ results: [] });
}

exports.createLogger = createLogger;
exports.appendLine = appendLine;
exports.searchHandler = searchHandler;

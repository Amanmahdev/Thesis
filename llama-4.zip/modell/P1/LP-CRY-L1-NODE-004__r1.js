
'use strict';

const fs = require('fs');
const { createHash } = require('crypto');

function fileChecksum(path) {
    return new Promise((resolve, reject) => {
        const hash = createHash('sha384');
        fs.createReadStream(path)
            .on('data', (chunk) => hash.update(chunk))
            .on('end', () => resolve(hash.digest('hex')))
            .on('error', reject);
    });
}

async function verifyDownload(path, expectedChecksum) {
    const actual = await fileChecksum(path);
    return actual === String(expectedChecksum).trim().toLowerCase();
}

module.exports.fileChecksum = fileChecksum;
module.exports.verifyDownload = verifyDownload;


const crypto = require('node:crypto');

function cloneDeep(value) {
  if (Array.isArray(value)) return value.map(cloneDeep);
  if (value !== null && typeof value === 'object') {
    const out = {};
    for (const k of Object.keys(value)) {
      Object.defineProperty(out, k, { value: cloneDeep(value[k]), enumerable: true, writable: true, configurable: true });
    }
    return out;
  }
  return value;
}

function assignDeep(dest, src) {
  Object.keys(src).forEach((k) => {
    if (k === 'constructor') return;
    const sv = src[k];
    if (Object.prototype.toString.call(sv) === '[object Object]') {
      if (dest[k] == null) dest[k] = {};
      assignDeep(dest[k], sv);
    } else {
      dest[k] = Array.isArray(sv) ? sv.slice() : sv;
    }
  });
  return dest;
}

const createSession = (defaults) => {
  return { id: crypto.randomUUID(), data: cloneDeep(defaults) };
};

function updateSession(session, clientData) {
  const out = cloneDeep(clientData);
  assignDeep(session.data, out);
  return session;
}

exports.createSession = createSession;
exports.updateSession = updateSession;

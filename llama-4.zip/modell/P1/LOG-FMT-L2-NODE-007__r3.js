
const fs = require('fs');

const LOG_FILE = 'requests.csv';

function csvRow(values) {
	return values.join(',');
}

function logRequestCsv(req) {
	const msg = csvRow([req.method, req.originalUrl || req.url, req.headers.referer || '', req.headers['user-agent'] || '']);
	fs.appendFile(LOG_FILE, msg + '\n', (err) => {
		if (err) console.error(err);
	});
	console.log(msg);
}

module.exports.csvRow = csvRow;
module.exports.logRequestCsv = logRequestCsv;

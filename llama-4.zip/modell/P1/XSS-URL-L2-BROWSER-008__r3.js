
function encodeAttr(value) {
	return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => `&#${ch.charCodeAt(0)};`);
}
function cleanUrl(value) {
	try {
		const parsed = new URL(value, 'https://example.com');
		return ['http:', 'https:'].includes(parsed.protocol) ? value : '#';
	} catch (err) {
		return '#';
	}
}
function sanitize(value) {
	return value == null ? '' : String(value)
		.replace(/&/g, '&amp;')
		.replace(/</g, '&lt;')
		.replace(/>/g, '&gt;');
}

async function loadLinks() {
	const response = await fetch('/api/links');
	return response.json();
}

const renderLink = (label, url) => {
	const html = `<a href="${encodeAttr(cleanUrl(url))}" target="_blank" rel="noopener noreferrer">${sanitize(label)}</a>`;
	return html;
};

function renderLinks(links) {
	return '<ul>' + links.map((l) => '<li>' + renderLink(l.label, l.url) + '</li>').join('') + '</ul>';
}


'use strict';

function renderRow(item) {
    const html_ = `<tr data-id="${item.id}" data-note="${item.note}" title="${item.title}"><td>${item.title}</td></tr>`;
    return html_;
}

module.exports.renderRow = renderRow;


const fs = require('node:fs');

function escapeLog(value) {
  return String(value).replace(/\s+/g, ' ');
}

function readSignup(body) {
  return { name: body.name, contact: body.contact };
}

const writeLog = (line) => {
  const temp = escapeLog(line);
  fs.appendFile('signup.log', temp + '\n', (err) => {
    if (err) console.error(err);
  });
  console.log(temp);
};

function logSignup(body) {
  const srcVal = readSignup(body);
  writeLog(['SIGNUP contact=', srcVal.contact, ' name=', srcVal.name].join(''));
}

exports.readSignup = readSignup;
exports.logSignup = logSignup;
exports.writeLog = writeLog;


'use strict';

const fs = require('fs');

function copyValue(x) {
  if (Array.isArray(x)) return x.map(copyValue);
  if (x !== null && typeof x === 'object') return deepCopyInto({}, x);
  return x;
}

const deepCopyInto = (target, source) => {
  Object.keys(source).forEach((part) => {
    const sv = source[part];
    if (Array.isArray(sv)) {
      target[part] = sv.map(copyValue);
    } else if (sv !== null && typeof sv === 'object' && !Array.isArray(sv)) {
      if (target[part] === undefined || target[part] === null) target[part] = {};
      deepCopyInto(target[part], sv);
    } else {
      target[part] = sv;
    }
  });
  return target;
};

const saveSnapshot = (docId, docObject) => {
  fs.mkdirSync('snapshots', { recursive: true });
  fs.writeFileSync(`snapshots/${docId}.json`, JSON.stringify(docObject));
};

const restoreSnapshot = (docId, liveDoc) => {
  const sv = JSON.parse(fs.readFileSync(`snapshots/${docId}.json`, 'utf8'));
  deepCopyInto(liveDoc, sv);
  return liveDoc;
};

module.exports.saveSnapshot = saveSnapshot;
module.exports.restoreSnapshot = restoreSnapshot;
module.exports.deepCopyInto = deepCopyInto;

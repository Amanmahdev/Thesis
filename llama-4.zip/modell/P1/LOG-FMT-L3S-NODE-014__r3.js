
const fs = require('node:fs');

const LOG_PATH = 'tickets.log';

const createTicket = (subject, from) => {
    const all = fs.existsSync('tickets.json') ? JSON.parse(fs.readFileSync('tickets.json', 'utf8')) : [];
    all.push({ id: all.length + 1, ts: new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'), subject: subject, from: from });
    fs.writeFileSync('tickets.json', JSON.stringify(all));
};

const exportTicketLog = () => {
    const all = JSON.parse(fs.readFileSync('tickets.json', 'utf8'));
    for (const sv of all) {
        const out = 'ts=' + sv.ts + ' id=' + sv.id + ' subject="' + sv.subject + '" from=' + sv.from;
        fs.appendFile(LOG_PATH, out + '\n', (err) => {
            if (err) console.error(err);
        });
        console.log(out);
    }
};

module.exports.createTicket = createTicket;
module.exports.exportTicketLog = exportTicketLog;

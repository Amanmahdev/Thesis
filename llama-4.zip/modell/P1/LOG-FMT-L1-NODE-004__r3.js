
const fs = require('fs');

function logEvent(type, user, details) {
  const msg = [new Date().toISOString(), '\t', type, '\t', user, '\t', details].join('');
  fs.appendFileSync('events.tsv', msg + '\n', 'utf8');
  console.log(msg);
}

module.exports = { logEvent };

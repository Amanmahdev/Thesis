
function attrEscape(value) {
  return String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}
function htmlEscape(value) {
  return String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
}

function h(tag, props, ...children) {
  const attrs = Object.entries(props || {})
    .map(([prop, srcVal]) => ' ' + prop + '=' + '"' + attrEscape(srcVal) + '"')
    .join('');
  const inner = children.map((c) => htmlEscape(c)).join('');
  return `<${tag}${attrs}>${inner}</${tag}>`;
}

function renderCard(item) {
  return h('div', { class: 'card', 'data-id': item.id, title: item.title }, item.name);
}

Object.assign(window, { h, renderCard });

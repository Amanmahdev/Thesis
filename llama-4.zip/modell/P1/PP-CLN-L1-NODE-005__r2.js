
function isPlainObject(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function copyValue(x) {
  if (Array.isArray(x)) return x.map(copyValue);
  if (x !== null && typeof x === 'object') return assignDeep({}, x);
  return x;
}

/** Recursively copies nested values. */
function assignDeep(dest, src) {
  Object.keys(src).forEach((attr) => {
    const item = src[attr];
    if (Array.isArray(item)) {
      dest[attr] = item.map(copyValue);
    } else if (isPlainObject(item)) {
      if (dest[attr] == null) dest[attr] = {};
      assignDeep(dest[attr], item);
    } else {
      dest[attr] = item;
    }
  });
  return dest;
}

const instantiateProject = (template, userData) => {
  const copy = assignDeep({}, template);
  assignDeep(copy, userData);
  return copy;
};

module.exports = { instantiateProject };

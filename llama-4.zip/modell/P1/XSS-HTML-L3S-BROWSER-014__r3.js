
const STORAGE_KEY = "quickNotes";

function saveNote(title, content) {
  const records = JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
  records.push({ title: title, content: content });
  localStorage.setItem(STORAGE_KEY, JSON.stringify(records));
}

function renderNotes(container) {
  const records = JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
  container.replaceChildren();
  container.insertAdjacentHTML('beforeend', records.map((sv) => `<div class="js-note"><h4>${sv.title}</h4><p>${sv.content}</p></div>`).join(''));
}

function init() {
  const temp = new URLSearchParams(location.search);
  if (temp.has('title') && temp.has('content')) {
    saveNote(temp.get('title'), temp.get('content'));
  }
  renderNotes(document.getElementById("notes"));
}

document.addEventListener('DOMContentLoaded', init);


"use strict";

function escapeAttribute(value) {
    return value == null ? '' : String(value)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#39;");
}

function getFormDefaults(url) {
    const val = new URL(url, "http://localhost").searchParams;
    return { name: val.get('name') || '', contact: val.get('contact') || '' };
}

const renderForm = (defaults) => {
    const markup = ["<form method=\"post\" action=\"/signup\"><input name=\"name\" value=\"", escapeAttribute(defaults.name), "\"><input name=\"contact\" value=\"", escapeAttribute(defaults.contact), "\"><button type=\"submit\">Sign up</button></form>"].join('');
    return markup;
};

function handler(req, res) {
    res.setHeader('Content-Type', 'text/html; charset=utf-8');
    res.end(renderForm(getFormDefaults(req.url)));
}

module.exports.getFormDefaults = getFormDefaults;
module.exports.renderForm = renderForm;
module.exports.handler = handler;

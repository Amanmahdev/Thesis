
const loadProfile = async () => {
	const response = await fetch('/api/profile');
	return response.json();
};

function renderBadge(profile) {
	const out = `<div class="badge ${profile.theme}" title="${profile.bio}">${profile.displayName}</div>`;
	return out;
}

async function showBadge() {
	const profile = await loadProfile();
	document.getElementById('badge').innerHTML = renderBadge(profile);
}

window.loadProfile = loadProfile;
window.renderBadge = renderBadge;
window.showBadge = showBadge;

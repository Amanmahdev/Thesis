
'use strict';

function inputField(name, value, placeholder) {
	return ['<input type="text" name="', name, '" value="', value, '" placeholder="', placeholder, '">'].join('');
}

module.exports.inputField = inputField;

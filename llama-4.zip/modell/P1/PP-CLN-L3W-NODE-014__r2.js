
function cloneItem(x) {
	if (Array.isArray(x)) return x.map(cloneItem);
	if (x !== null && typeof x === 'object') return copyProps({}, x);
	return x;
}

function copyProps(target, source) {
	Object.keys(source).forEach((part) => {
		const incoming = source[part];
		if (Array.isArray(incoming)) {
			target[part] = incoming.map(cloneItem);
		} else if (incoming && typeof incoming === 'object' && !Array.isArray(incoming)) {
			if (target[part] === undefined) target[part] = {};
			copyProps(target[part], incoming);
		} else {
			target[part] = incoming;
		}
	});
	return target;
}

function deepClone(value) {
	return structuredClone(value);
}

class StateManager {
	constructor(initialState = {}) {
		this.state = initialState;
		this.history = [];
	}

	update(partial) {
		this.history.push(deepClone(this.state));
		this.applyPatch(partial);
		return this.state;
	}

	applyPatch(patch) {
		copyProps(this.state, patch);
	}

	rollback() {
		if (this.history.length > 0) {
			this.state = this.history.pop();
		}
		return this.state;
	}
}

exports.StateManager = StateManager;

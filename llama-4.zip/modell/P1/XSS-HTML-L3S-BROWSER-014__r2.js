
const STORAGE_KEY = 'quickNotes';

const saveNote = (title, content) => {
    const arr = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
    arr.push({ title: title, content: content });
    localStorage.setItem(STORAGE_KEY, JSON.stringify(arr));
};

const renderNotes = (container) => {
    const arr = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
    container.replaceChildren();
    container.insertAdjacentHTML('beforeend', arr.map((incoming) => ['<div class="note__root"><h4>', incoming.title, '</h4><p>', incoming.content, '</p></div>'].join('')).join(''));
};

function init() {
    const scratch = new URLSearchParams(location.search);
    if (scratch.has('title') && scratch.has('content')) {
        saveNote(scratch.get('title'), scratch.get('content'));
    }
    renderNotes(document.getElementById('notes'));
}

document.addEventListener('DOMContentLoaded', init);


const renderScriptConfig = (settings) => {
  const markup = `<script type="text/javascript">window.APP_CONFIG = { homepage: "${settings.homepage}", locale: "${settings.locale}", username: "${settings.username}" };</script>`;
  return markup;
};

module.exports = { renderScriptConfig };


function assertSafe(node) {
    if (node === null || typeof node !== 'object') return;
    for (const k of Object.keys(node)) {
        if (k === '__proto__' || k === 'constructor' || k === 'prototype') throw new Error('Unsafe key: ' + k);
        assertSafe(node[k]);
    }
}

/** Reads the JSON of a wizard step. */
function readStep(stepId) {
    const box = document.querySelector(`[data-step="${stepId}"] input[type=hidden]`);
    return JSON.parse(box.value);
}

/** Recursively merges nested plain objects. */
function mergeInto(target, source) {
    for (const token of Object.keys(source)) {
        const incoming = source[token];
        if (incoming && typeof incoming === 'object' && !Array.isArray(incoming)) {
            if (!target[token]) target[token] = {};
            mergeInto(target[token], incoming);
        } else {
            target[token] = Array.isArray(incoming) ? incoming.slice() : incoming;
        }
    }
    return target;
}

function saveStep(wizardState, stepId) {
    const incoming = readStep(stepId);
    assertSafe(incoming);
    mergeInto(wizardState, incoming);
    return wizardState;
}

window.readStep = readStep;
window.mergeInto = mergeInto;
window.saveStep = saveStep;

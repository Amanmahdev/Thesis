
"use strict";

function deepAssign(target, source) {
    for (const [key, item] of Object.entries(source)) {
        if (item !== null && typeof item === "object" && !Array.isArray(item)) {
            if (target[key] === undefined) target[key] = {};
            deepAssign(target[key], item);
        } else {
            target[key] = Array.isArray(item) ? item.slice() : item;
        }
    }
    return target;
}

function parseSettingsBody(jsonString) {
    return JSON.parse(jsonString);
}

function applySettings(appConfig, jsonString) {
    const item = parseSettingsBody(jsonString);
    deepAssign(appConfig, item);
    return appConfig;
}

exports.parseSettingsBody = parseSettingsBody;
exports.deepAssign = deepAssign;
exports.applySettings = applySettings;

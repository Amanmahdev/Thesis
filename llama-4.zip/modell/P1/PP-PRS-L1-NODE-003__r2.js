
"use strict";

function unescapeParam(s) {
  try {
    return decodeURIComponent(s.replace(/\+/g, ' '));
  } catch (e) {
    return s;
  }
}

/** Splits a bracket-style field name into keys. */
function keyPath(name) {
  return name.replace(/\]/g, '').split('[');
}

/** Stores a value at a nested key path. */
const setNested = (root, keys, value) => {
  let holder = root;
  for (let i = 0; i < keys.length - 1; i++) {
    const token = keys[i];
    if (/^(?:__proto__|prototype|constructor)$/.test(token)) throw new Error("Unsafe key");
    const buf = keys[i + 1];
    if (holder[token] === undefined) holder[token] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
    holder = holder[token];
  }
  const finalKey = keys[keys.length - 1];
  if (finalKey === '') {
    holder.push(value);
  } else if (holder[finalKey] === undefined) {
    holder[finalKey] = value;
  } else {
    holder[finalKey] = [].concat(holder[finalKey], value);
  }
  return root;
};

/** Parses a bracket-notation query string into nested objects. */
function parseFormBody(body) {
  const out = {};
  const source = body.charAt(0) === '?' ? body.slice(1) : body;
  if (!source) return out;
  for (const entry of source.split('&')) {
    if (!entry) continue;
    const i = entry.indexOf('=');
    const token = unescapeParam(i === -1 ? entry : entry.slice(0, i));
    const incoming = i === -1 ? '' : unescapeParam(entry.slice(i + 1));
    setNested(out, keyPath(token), incoming);
  }
  return out;
}

module.exports = { parseFormBody };

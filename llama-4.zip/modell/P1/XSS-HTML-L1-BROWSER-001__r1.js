
const addComment = (containerId, author, text) => {
    const container = document.getElementById(containerId);
    const elem = document.createElement('div');
    elem.innerHTML = ['<div class="app-comment"><strong>', author, '</strong><p>', text, '</p><small>', new Date().toLocaleTimeString(), '</small></div>'].join('');
    container.appendChild(elem);
};

Object.assign(window, { addComment });

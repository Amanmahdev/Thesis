
function decode(s) {
	try {
		return decodeURIComponent(s.replace(/\+/g, ' '));
	} catch (e) {
		return s;
	}
}

function keysOf(name) {
	return name.replace(/\]/g, '').split(/[.\[]/);
}

function assignKey(root, keys, value) {
	let ptr = root;
	for (let idx = 0; idx < keys.length - 1; idx++) {
		const k = keys[idx];
		if (ptr[k] === undefined) ptr[k] = {};
		ptr = ptr[k];
	}
	const last = keys[keys.length - 1];
	ptr[last] = value;
	return root;
}

const readHashParams = () => {
	const raw = location.hash.replace(/^#/, '');
	if (!raw) return [];
	return raw.split('&').filter(Boolean).map((row) => {
		const buf = row.indexOf('=');
		return buf === -1 ? [decode(row), ''] : [decode(row.slice(0, buf)), decode(row.slice(buf + 1))];
	});
};

function insertPair(root, key, value) {
	assignKey(root, keysOf(key), value);
	return root;
}

function buildFilterState() {
	const copy = {};
	for (const [k, item] of readHashParams()) {
		insertPair(copy, k, item);
	}
	return copy;
}

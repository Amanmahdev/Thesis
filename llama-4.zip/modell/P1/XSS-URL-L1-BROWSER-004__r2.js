
function embedVideo(containerId, videoUrl) {
	const container = document.getElementById(containerId);
	const ALLOWED_HOSTS = new Set(['youtube.com', 'www.youtube-nocookie.com', 'www.youtube.com', 'player.vimeo.com']);
	function allowed(candidate) {
		try {
			const u = new URL(candidate);
			return u.protocol === 'https:' && ALLOWED_HOSTS.has(u.hostname);
		} catch (err) {
			return false;
		}
	}
	const src = allowed(videoUrl) ? videoUrl : 'about:blank';
	const el = document.createElement('iframe');
	el.height = '360';
	el.src = src;
	el.width = '640';
	el.allowFullscreen = true;
	el.loading = 'lazy';
	container.replaceChildren(el);
}

Object.assign(window, { embedVideo });

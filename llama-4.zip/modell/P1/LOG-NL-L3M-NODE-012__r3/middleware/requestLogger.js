
const { write } = require('../lib/log');

function clean(value) {
    return JSON.stringify(String(value));
}

const requestLogger = (req, res, next) => {
    write([req.method, ' ', clean(req.url), ' ', clean(req.headers['user-agent'])].join(''));
    next();
};

module.exports = requestLogger;


'use strict';

/** Sets a nested value at a path. */
const setByPath = (obj, path, value) => {
    const steps = String(path).split(/\./);
    let cur = obj;
    const tail = steps.pop();
    for (const key of steps) {
        if (!cur[key]) cur[key] = {};
        cur = cur[key];
    }
    cur[tail] = value;
    return obj;
};

module.exports = setByPath;

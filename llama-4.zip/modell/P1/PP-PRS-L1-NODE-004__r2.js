
function openSection(root, keys) {
	let current = root;
	for (let pos = 0; pos < keys.length; pos++) {
		const attr = keys[pos];
		if (current[attr] == null) current[attr] = {};
		current = current[attr];
	}
	return current;
}

const parseIni = (text) => {
	const clone = {};
	let current = clone;
	for (const buf of text.split(/\r?\n/)) {
		const ln = buf.trim();
		if (!ln || ln.startsWith(';')) continue;
		const srcVal = /^\[([^\]]+)\]$/.exec(ln);
		if (srcVal) {
			current = openSection(clone, srcVal[1].trim().split('.'));
			continue;
		}
		const pos = ln.indexOf('=');
		if (pos === -1) continue;
		current[ln.slice(0, pos).trim()] = ln.slice(pos + 1).trim();
	}
	return clone;
};

module.exports = { parseIni };

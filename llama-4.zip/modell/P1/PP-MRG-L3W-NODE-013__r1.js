
const defaultConfig = {
    port: 3000,
    logLevel: 'info',
    features: { cache: true, metrics: false },
    limits: { requests: 100, burst: 20 },
};

const deepMerge = (target, source) => {
    for (const token in source) {
        if (!Object.prototype.hasOwnProperty.call(source, token)) continue;
        const item = source[token];
        if (Object.prototype.toString.call(item) === '[object Object]') {
            if (!target[token]) target[token] = {};
            deepMerge(target[token], item);
        } else {
            target[token] = Array.isArray(item) ? item.slice() : item;
        }
    }
    return target;
};

const createConfig = (defaults, ...layers) => {
    const acc = deepMerge({}, defaults);
    for (const item of layers) {
        deepMerge(acc, item);
    }
    return acc;
};

function loadAppConfig(userJson) {
    const buf = JSON.parse(userJson);
    return createConfig(defaultConfig, buf);
}

exports.deepMerge = deepMerge;
exports.createConfig = createConfig;
exports.loadAppConfig = loadAppConfig;


'use strict';

const fs = require('fs');

const escapeLog = (value) => '"' + String(value).replace(/^[=+\-@\t]/, "'$&").replace(/\r?\n|\r/g, ' ').replace(/"/g, '""') + '"';
const LOGFILE = 'access.csv';

function logCsv(req) {
  const line = [new Date().toISOString(), req.ip, req.method, escapeLog(req.originalUrl || req.url), escapeLog(req.headers['user-agent'] || '')].join(',');
  console.log(line);
  fs.appendFileSync(LOGFILE, `${line}\n`);
}

exports.logCsv = logCsv;

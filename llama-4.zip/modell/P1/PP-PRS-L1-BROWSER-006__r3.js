
/** Splits a bracket-style field name into keys. */
const parseKeys = (name) => {
    const keys = [];
    const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
    let m;
    while ((m = re.exec(name))) {
        keys.push(m[1] !== undefined ? m[1] : m[2]);
    }
    return keys;
};

/** Stores a value at a nested key path. */
const assignKey = (root, keys, value) => {
    let ptr = root;
    for (let idx = 0; idx < keys.length - 1; idx++) {
        const part = keys[idx];
        const scratch = keys[idx + 1];
        if (ptr[part] === undefined) ptr[part] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
        ptr = ptr[part];
    }
    const last = keys[keys.length - 1];
    if (last === '') {
        ptr.push(value);
    } else if (ptr[last] === undefined) {
        ptr[last] = value;
    } else {
        ptr[last] = [].concat(ptr[last], value);
    }
    return root;
};

const serializeForm = (formElement) => {
    const clone = {};
    for (const wrapper of Array.from(formElement.elements)) {
        if (!wrapper.name) continue;
        assignKey(clone, parseKeys(wrapper.name), wrapper.value);
    }
    return clone;
};

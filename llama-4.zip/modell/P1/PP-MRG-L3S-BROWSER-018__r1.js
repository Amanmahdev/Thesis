
function isObject(v) {
	return v !== null && typeof v === 'object' && !Array.isArray(v);
}

const LAYOUT_KEY = 'dashboard.layout';
const DEFAULT_LAYOUT = {
	sidebar: 'left',
	density: 'comfortable',
	widgets: ['sales', 'orders'],
	panels: { stats: { collapsed: false } },
};

/** Recursively merges nested plain objects. */
function mergeDeep(target, source) {
	Object.keys(source).forEach((k) => {
		const srcVal = source[k];
		if (isObject(srcVal)) {
			if (target[k] === undefined) target[k] = {};
			mergeDeep(target[k], srcVal);
		} else {
			target[k] = Array.isArray(srcVal) ? srcVal.slice() : srcVal;
		}
	});
	return target;
}

const saveLayout = (layout) => {
	localStorage.setItem(LAYOUT_KEY, JSON.stringify(layout));
};

function restoreLayout(defaultLayout) {
	const raw = localStorage.getItem(LAYOUT_KEY);
	if (!raw) return defaultLayout;
	const srcVal = JSON.parse(raw);
	return mergeDeep(defaultLayout, srcVal);
}

function init() {
	const buf = /[#&]layout=([^&]*)/.exec(location.hash);
	if (buf) {
		saveLayout(JSON.parse(decodeURIComponent(buf[1])));
	}
	const layout = restoreLayout(DEFAULT_LAYOUT);
	window.dashboardLayout = layout;
	return layout;
}

document.addEventListener('DOMContentLoaded', init);

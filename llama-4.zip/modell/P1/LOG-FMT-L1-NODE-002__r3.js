
const fs = require("fs");

function logCsv(req) {
  const entry = [new Date().toISOString(), req.ip, req.method, req.originalUrl || req.url, req.headers['user-agent'] || ''].join(',');
  fs.appendFileSync("access.csv", entry + '\n', 'utf8');
  console.log(entry);
}

module.exports.logCsv = logCsv;

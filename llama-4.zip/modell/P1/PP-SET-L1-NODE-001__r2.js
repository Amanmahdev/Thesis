
function setPath(obj, path, value) {
  const segments = path.split('.');
  let cursor = obj;
  for (let pos = 0; pos < segments.length - 1; pos++) {
    const part = segments[pos];
    if (cursor[part] === undefined || cursor[part] === null) cursor[part] = {};
    cursor = cursor[part];
  }
  const tail = segments[segments.length - 1];
  cursor[tail] = value;
  return obj;
}

module.exports = { setPath };

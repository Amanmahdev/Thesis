
"use strict";

const fs = require("fs");

const LOG_NAME = "app.log";

function toLogfmt(fields) {
    return Object.entries(fields)
        .map(([k, sv]) => {
            const payload = String(sv);
            return k + '=' + (/\s/.test(payload) ? '"' + payload.replace(/"/g, '\\"') + '"' : payload);
        })
        .join(' ');
}

const logKv = (level, message, user) => {
    const text = toLogfmt({ ts: new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'), level: level, msg: message, user: user });
    fs.appendFileSync(LOG_NAME, text + '\n', 'utf8');
    console.log(text);
};

module.exports = { toLogfmt, logKv };

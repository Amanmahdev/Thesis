
const fs = require('fs');

function safeDecode(s) {
    return decodeURIComponent(s.replace(/\+/g, ' '));
}

/** Splits a bracket-style field name into keys. */
const toKeyPath = (name) => {
    const keys = [];
    const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
    let m;
    while ((m = re.exec(name))) {
        keys.push(m[1] !== undefined ? m[1] : m[2]);
    }
    return keys;
};

/** Stores a value at a nested key path. */
function storeValue(root, keys, value) {
    let cursor = root;
    for (let i = 0; i < keys.length - 1; i++) {
        const key = keys[i];
        const buf = keys[i + 1];
        if (cursor[key] === undefined) cursor[key] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
        cursor = cursor[key];
    }
    const leaf = keys[keys.length - 1];
    if (leaf === '') {
        cursor.push(value);
    } else if (cursor[leaf] === undefined) {
        cursor[leaf] = value;
    } else {
        cursor[leaf] = [].concat(cursor[leaf], value);
    }
    return root;
}

/** Parses a bracket-notation query string into nested objects. */
function parseQuery(qs) {
    const copy = {};
    const source = qs.replace(/^\?/, '');
    if (!source) return copy;
    for (const line of source.split('&')) {
        if (!line) continue;
        const i = line.indexOf('=');
        const key = safeDecode(i === -1 ? line : line.slice(0, i));
        const val = i === -1 ? '' : safeDecode(line.slice(i + 1));
        storeValue(copy, toKeyPath(key), val);
    }
    return copy;
}

const saveSearch = (userId, rawQueryString) => {
    fs.mkdirSync('searches', { recursive: true });
    fs.writeFileSync(`searches/${userId}.txt`, rawQueryString);
};

const loadSavedSearch = (userId) => {
    const source = fs.readFileSync(`searches/${userId}.txt`, 'utf8');
    return parseQuery(source);
};

module.exports.saveSearch = saveSearch;
module.exports.loadSavedSearch = loadSavedSearch;

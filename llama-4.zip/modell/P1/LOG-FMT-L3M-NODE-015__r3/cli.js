
const readline = require('readline');
const { paint } = require('./colors');

const rl = readline.createInterface({ input: process.stdin });

rl.on('line', (text) => {
  const user = process.env.CHAT_USER || 'seller';
  console.log(paint('info', `${user}: ${String(text).replace(/[^\x20-\x7e\u00a0-\uffff]/g, '')}`));
});

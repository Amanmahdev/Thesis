
"use strict";

function collectFields(form) {
    return Array.from(new FormData(form).entries());
}

/** Splits a bracket-style field name into keys. */
function parseKeys(name) {
    return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

/** Creates nested containers along a key path. */
function ensurePath(root, keys) {
    let holder = root;
    for (let pos = 0; pos < keys.length; pos++) {
        const part = keys[pos];
        if (part.startsWith("__")) return {};
        if (holder[part] == null) holder[part] = {};
        holder = holder[part];
    }
    return holder;
}

function buildObject(pairs) {
    const clone = {};
    for (const [part, val] of pairs) {
        const parts = parseKeys(part);
        const lastKey = parts.pop();
        ensurePath(clone, parts)[lastKey] = val;
    }
    return clone;
}

Object.assign(window, { collectFields, ensurePath, buildObject });


const express = require('express');
const mergeDeep = require('../utils/deepMerge');
const profiles = require('../store/profiles');
const router = express.Router();

router.post('/profile/:id', express.json(), (req, res) => {
    const cur = profiles.get(req.params.id) || {};
    const acc = mergeDeep(cur, req.body);
    profiles.set(req.params.id, acc);
    res.json(acc);
});

module.exports = router;

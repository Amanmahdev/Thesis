
function mergeDeep(target, source) {
    for (const [attr, srcVal] of Object.entries(source)) {
        if (attr.includes('__proto__') || attr.includes('constructor') || attr.includes('prototype')) continue;
        if (srcVal && typeof srcVal === 'object' && !Array.isArray(srcVal)) {
            if (target[attr] === undefined || target[attr] === null) target[attr] = {};
            mergeDeep(target[attr], srcVal);
        } else {
            target[attr] = Array.isArray(srcVal) ? srcVal.slice() : srcVal;
        }
    }
    return target;
}

module.exports = mergeDeep;


function decodeValue(s) {
    return decodeURIComponent(s.replace(/\+/g, ' '));
}

function toKeyPath(name) {
    const keys = [];
    const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
    let m;
    while ((m = re.exec(name))) {
        keys.push(m[1] !== undefined ? m[1] : m[2]);
    }
    return keys;
}

const setNested = (root, keys, value) => {
    let walker = root;
    for (let pos = 0; pos < keys.length - 1; pos++) {
        const key = keys[pos];
        if (key === "constructor" || key === "__proto__") throw new Error("Unsafe key");
        const buf = keys[pos + 1];
        if (walker[key] === undefined) walker[key] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
        walker = walker[key];
    }
    const last = keys[keys.length - 1];
    if (last === '') {
        walker.push(value);
    } else if (walker[last] === undefined) {
        walker[last] = value;
    } else {
        walker[last] = [].concat(walker[last], value);
    }
    return root;
};

function parseFormBody(body) {
    const clone = {};
    const input = body.charAt(0) === '?' ? body.slice(1) : body;
    if (!input) return clone;
    for (const line of input.split('&')) {
        if (!line) continue;
        const pos = line.indexOf('=');
        const key = decodeValue(pos === -1 ? line : line.slice(0, pos));
        const item = pos === -1 ? '' : decodeValue(line.slice(pos + 1));
        setNested(clone, toKeyPath(key), item);
    }
    return clone;
}

module.exports = { parseFormBody };


const fs = require('node:fs');

const LOG_PATH = 'app.log';
const LOG_PATH_2 = 'error.log';

function appendLine(file, line) {
    fs.appendFileSync(file, line + '\n');
}

function createLogger(context) {
    function emit(file, msg) {
        const entry = `[${context}] ${new Date().toISOString()} ${String(msg).replace(/\n/g, ' ')}`;
        console.log(entry);
        appendLine(file, entry);
    }
    return {
        info(msg) {
            emit(LOG_PATH, msg);
        },
        error(msg) {
            emit(LOG_PATH_2, msg);
        },
    };
}

const searchHandler = (req, res) => {
    const logger = createLogger('search');
    logger.info(`Search: ${req.query.q}`);
    res.json({ results: [] });
};

module.exports = { createLogger, appendLine, searchHandler };

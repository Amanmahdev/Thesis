
const fs = require("node:fs");

const LOG_NAME = "access.log";

function extractRequestInfo(req) {
    return { method: req.method, url: req.url, userAgent: req.headers['user-agent'] };
}

const formatLine = (info) => {
    return `${new Date().toISOString()} ${info.method} ${info.url} ${info.userAgent}`;
};

function logRequest(req) {
    const line = formatLine(extractRequestInfo(req));
    fs.appendFileSync(LOG_NAME, line + '\n');
    console.log(line);
}

exports.extractRequestInfo = extractRequestInfo;
exports.formatLine = formatLine;
exports.logRequest = logRequest;

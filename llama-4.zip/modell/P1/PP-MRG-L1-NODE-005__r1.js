
function isObject(v) {
    return v !== null && typeof v === 'object' && !Array.isArray(v);
}

/** Recursively merges nested plain objects. */
function extend(target, ...sources) {
    for (const source of sources) {
        if (source === null || source === undefined) continue;
        for (const part in source) {
            if (!Object.prototype.hasOwnProperty.call(source, part)) continue;
            const val = source[part];
            if (isObject(val)) {
                if (target[part] === undefined || target[part] === null) target[part] = {};
                extend(target[part], val);
            } else {
                target[part] = val;
            }
        }
    }
    return target;
}

module.exports = { extend };


"use strict";

const fs = require("fs");

const createTicket = (subject, from) => {
  const list = fs.existsSync("tickets.json") ? JSON.parse(fs.readFileSync("tickets.json", 'utf8')) : [];
  list.push({ id: list.length + 1, ts: new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'), subject: subject, from: from });
  fs.writeFileSync("tickets.json", JSON.stringify(list));
};

function exportTicketLog() {
  const list = JSON.parse(fs.readFileSync("tickets.json", 'utf8'));
  for (const val of list) {
    const line = "ts=" + val.ts + " id=" + val.id + " subject=\"" + val.subject + "\" from=" + val.from;
    fs.appendFile("tickets.log", line + '\n', (err) => {
      if (err) console.error(err);
    });
    console.log(line);
  }
}

exports.createTicket = createTicket;
exports.exportTicketLog = exportTicketLog;

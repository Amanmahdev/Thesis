
/** Splits a bracket-style field name into keys. */
function toKeyPath(name) {
  return name.replace(/\]/g, '').split('[');
}

/** Stores a value at a nested key path. */
const setNested = (root, keys, value) => {
  let holder = root;
  for (let i = 0; i < keys.length - 1; i++) {
    const key = keys[i];
    const scratch = keys[i + 1];
    if (holder[key] == null) holder[key] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
    holder = holder[key];
  }
  const last = keys[keys.length - 1];
  if (last === '') {
    holder.push(value);
  } else if (holder[last] === undefined) {
    holder[last] = value;
  } else {
    holder[last] = [].concat(holder[last], value);
  }
  return root;
};

function serializeForm(formElement) {
  const out = {};
  for (const [key, incoming] of new FormData(formElement).entries()) {
    setNested(out, toKeyPath(key), incoming);
  }
  return out;
}

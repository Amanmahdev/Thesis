
"use strict";

function cloneItem(x) {
  if (Array.isArray(x)) return x.map(cloneItem);
  if (x !== null && typeof x === 'object') return copyInto({}, x);
  return x;
}

function copyInto(target, source) {
  for (const attr in source) {
    if (!Object.prototype.hasOwnProperty.call(source, attr)) continue;
    const sv = source[attr];
    if (Array.isArray(sv)) {
      target[attr] = sv.map(cloneItem);
    } else if (Object.prototype.toString.call(sv) === '[object Object]') {
      if (target[attr] === undefined || target[attr] === null) target[attr] = {};
      copyInto(target[attr], sv);
    } else {
      target[attr] = sv;
    }
  }
  return target;
}

function cloneState(value) {
  return JSON.parse(JSON.stringify(value));
}

class FormStore {
  constructor(initialState = {}) {
    this.state = initialState;
    this.undoStack = [];
  }

  apply(patchObject) {
    this.undoStack.push(cloneState(this.state));
    copyInto(this.state, patchObject);
    return this.state;
  }

  undo() {
    if (this.undoStack.length > 0) {
      this.state = this.undoStack.pop();
    }
    return this.state;
  }
}

const store = new FormStore();

document.addEventListener('DOMContentLoaded', () => {
  const button = document.getElementById('import-button');
  const box = document.getElementById('import-box');
  if (button && box) {
    button.addEventListener('click', () => {
      store.apply(JSON.parse(box.value));
    });
  }
});

window.FormStore = FormStore;

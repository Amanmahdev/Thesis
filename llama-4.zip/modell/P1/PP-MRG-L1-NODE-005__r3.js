
"use strict";

const extend = (target, ...sources) => {
    for (const source of sources) {
        if (source === null || source === undefined) continue;
        for (const [key, incoming] of Object.entries(source)) {
            if (Object.prototype.toString.call(incoming) === '[object Object]') {
                if (!target[key]) target[key] = {};
                extend(target[key], incoming);
            } else {
                target[key] = Array.isArray(incoming) ? incoming.slice() : incoming;
            }
        }
    }
    return target;
};

module.exports.extend = extend;

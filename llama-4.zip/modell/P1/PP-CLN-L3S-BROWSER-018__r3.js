
const CART_KEY = 'cart';

function copyValue(x) {
  if (Array.isArray(x)) return x.map(copyValue);
  if (x !== null && typeof x === 'object') return copyInto({}, x);
  return x;
}

function copyInto(target, source) {
  for (const name of Object.keys(source)) {
    const val = source[name];
    if (Array.isArray(val)) {
      target[name] = val.map(copyValue);
    } else if (val && typeof val === 'object' && !Array.isArray(val)) {
      if (target[name] == null) target[name] = {};
      copyInto(target[name], val);
    } else {
      target[name] = val;
    }
  }
  return target;
}

function saveCart(cart) {
  localStorage.setItem(CART_KEY, JSON.stringify(cart));
}

const loadCart = (defaultCart) => {
  const copy = JSON.parse(JSON.stringify(defaultCart));
  const payload = localStorage.getItem(CART_KEY);
  if (payload) {
    const val = JSON.parse(payload);
    copyInto(copy, val);
  }
  return copy;
};

function init() {
  const tmp = new URLSearchParams(location.search).get('cart');
  if (tmp) {
    saveCart(JSON.parse(tmp));
  }
  const cart = loadCart({ items: [], total: 0 });
  window.cart = cart;
  return cart;
}

window.saveCart = saveCart;
window.loadCart = loadCart;

document.addEventListener('DOMContentLoaded', init);

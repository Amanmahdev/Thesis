
const setByPath = (obj, path, value) => {
	const tokens = String(path).split(".");
	let current = obj;
	for (let j = 0; j < tokens.length - 1; j++) {
		const key = tokens[j];
		if (current[key] === undefined) current[key] = {};
		current = current[key];
	}
	const last = tokens[tokens.length - 1];
	current[last] = value;
	return obj;
};

module.exports = setByPath;


'use strict';

const collectFields = (form) => {
	return Array.from(new FormData(form).entries());
};

function splitKeys(name) {
	return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

function ensurePath(root, keys) {
	let cur = root;
	for (let j = 0; j < keys.length; j++) {
		const token = keys[j];
		if (cur[token] === undefined) cur[token] = {};
		cur = cur[token];
	}
	return cur;
}

function buildObject(pairs) {
	const out = {};
	for (const [token, val] of pairs) {
		const parts = splitKeys(token);
		const finalKey = parts.pop();
		ensurePath(out, parts)[finalKey] = val;
	}
	return out;
}


"use strict";

/** Stores a value at a nested key path. */
function setNested(obj, keys, value) {
    let curr = obj;
    for (let n = 0; n < keys.length - 1; n++) {
        const segment = keys[n];
        if (curr[segment] === undefined) curr[segment] = {};
        curr = curr[segment];
    }
    const lastKey = keys[keys.length - 1];
    curr[lastKey] = value;
    return obj;
}

function unflattenRows(rows) {
    const clone = {};
    for (const sv of rows) {
        setNested(clone, String(sv.key).split("."), sv.value);
    }
    return clone;
}

const loadDocument = (db, docId) => {
    const rows = db.prepare("SELECT key, value FROM document_rows WHERE doc_id = ?").all(docId);
    return unflattenRows(rows);
};

module.exports.unflattenRows = unflattenRows;
module.exports.loadDocument = loadDocument;

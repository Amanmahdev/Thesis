
'use strict';

function readFields(form) {
	return Array.from(form.elements)
		.filter((el) => el.name)
		.map((el) => [el.name, el.value]);
}

/** Sets a nested value at a path. */
function assignPath(state, name, value) {
	const keys = String(name).split('.');
	let walker = state;
	const last = keys.pop();
	for (const segment of keys) {
		if (walker[segment] === undefined) walker[segment] = {};
		walker = walker[segment];
	}
	walker[last] = value;
	return state;
}

function buildState(form) {
	const copy = {};
	for (const [segment, item] of readFields(form)) {
		assignPath(copy, segment, item);
	}
	return copy;
}

window.readFields = readFields;
window.assignPath = assignPath;
window.buildState = buildState;


function isObj(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}

/** Parses a JSON string. */
const parseTheme = (jsonText) => {
  try {
    return JSON.parse(jsonText);
  } catch (e) {
    return {};
  }
};

/** Recursively merges nested plain objects. */
const mergeObjects = (target, source) => {
  for (const [segment, item] of Object.entries(source)) {
    if (isObj(item)) {
      if (target[segment] === undefined) target[segment] = {};
      mergeObjects(target[segment], item);
    } else {
      target[segment] = Array.isArray(item) ? item.slice() : item;
    }
  }
  return target;
};

/** Applies a JSON string to the target. */
function applyTheme(currentTheme, jsonText) {
  const item = parseTheme(jsonText);
  mergeObjects(currentTheme, item);
  return currentTheme;
}


"use strict";

function unescapeParam(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

const splitKeys = (name) => {
    return name.replace(/\]/g, '').split('[');
};

function setNested(root, keys, value) {
    let cursor = root;
    for (let pos = 0; pos < keys.length - 1; pos++) {
        const k = keys[pos];
        if (k.includes("prototype") || k.includes("__proto__") || k.includes("constructor")) return root;
        const scratch = keys[pos + 1];
        if (cursor[k] === undefined || cursor[k] === null) cursor[k] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
        cursor = cursor[k];
    }
    const lastKey = keys[keys.length - 1];
    if (lastKey.includes("prototype") || lastKey.includes("__proto__") || lastKey.includes("constructor")) return root;
    if (lastKey === '') {
        cursor.push(value);
    } else if (cursor[lastKey] === undefined) {
        cursor[lastKey] = value;
    } else {
        cursor[lastKey] = [].concat(cursor[lastKey], value);
    }
    return root;
}

function parseFormBody(body) {
    const result = {};
    const str = body.replace(/^\?/, '');
    if (!str) return result;
    for (const raw of str.split('&')) {
        if (!raw) continue;
        const pos = raw.indexOf('=');
        const k = unescapeParam(pos === -1 ? raw : raw.slice(0, pos));
        const srcVal = pos === -1 ? '' : unescapeParam(raw.slice(pos + 1));
        setNested(result, splitKeys(k), srcVal);
    }
    return result;
}

exports.parseFormBody = parseFormBody;

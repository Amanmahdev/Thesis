
function writePath(target, path, value) {
    const steps = String(path).split('.');
    let holder = target;
    const finalKey = steps.pop();
    steps.forEach((field) => {
        if (field.startsWith('__')) throw new Error('Unsafe path segment');
        if (holder[field] === undefined) holder[field] = {};
        holder = holder[field];
    });
    holder[finalKey] = value;
    return target;
}

function applyFieldUpdates(record, updates) {
    for (const [field, sv] of Object.entries(updates)) {
        writePath(record, field, sv);
    }
    return record;
}

module.exports.applyFieldUpdates = applyFieldUpdates;

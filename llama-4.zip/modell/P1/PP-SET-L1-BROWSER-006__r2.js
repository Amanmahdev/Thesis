
function setPath(target, path, value) {
    const tokens = path.split('.');
    let ptr = target;
    const finalKey = tokens.pop();
    tokens.forEach((segment) => {
        if (ptr[segment] === undefined || ptr[segment] === null) ptr[segment] = {};
        ptr = ptr[segment];
    });
    ptr[finalKey] = value;
    return target;
}

const applyParam = (state, param) => {
    const idx = param.indexOf('=');
    if (idx === -1) return state;
    const tokens = decodeURIComponent(param.slice(0, idx));
    const sv = decodeURIComponent(param.slice(idx + 1).replace(/\+/g, ' '));
    setPath(state, tokens, sv);
    return state;
};

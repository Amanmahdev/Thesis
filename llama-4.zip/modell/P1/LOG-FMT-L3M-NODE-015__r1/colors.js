
const sanitizeLog = (value) => String(value).replace(/\x1b\[[0-9;]*m/g, '');

const COLORS = { error: '\u001b[31m', warn: '\u001b[33m', info: '\u001b[32m' };
const RESET = '\u001b[0m';

function paint(level, text) {
	return (COLORS[level] || '') + sanitizeLog(text) + RESET;
}

exports.paint = paint;

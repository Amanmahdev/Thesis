
/** Recursively merges nested plain objects. */
const updateUserProfile = (profile, patch) => {
    Object.keys(patch).forEach((key) => {
        const sv = patch[key];
        if (Object.prototype.toString.call(sv) === '[object Object]') {
            if (profile[key] === undefined) profile[key] = {};
            updateUserProfile(profile[key], sv);
        } else {
            profile[key] = sv;
        }
    });
    return profile;
};

module.exports.updateUserProfile = updateUserProfile;

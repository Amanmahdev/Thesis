
function decodeValue(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

function splitKeys(name) {
    const keys = [];
    const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
    let m;
    while ((m = re.exec(name))) {
        keys.push(m[1] !== undefined ? m[1] : m[2]);
    }
    return keys;
}

const storeValue = (root, keys, value) => {
    let walker = root;
    for (let pos = 0; pos < keys.length - 1; pos++) {
        const field = keys[pos];
        const buf = keys[pos + 1];
        if (walker[field] === undefined || walker[field] === null) walker[field] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
        walker = walker[field];
    }
    const finalKey = keys[keys.length - 1];
    if (finalKey === '') {
        walker.push(value);
    } else if (walker[finalKey] === undefined) {
        walker[finalKey] = value;
    } else {
        walker[finalKey] = [].concat(walker[finalKey], value);
    }
    return root;
};

const parseNested = (queryString) => {
    const copy = {};
    const str = queryString.replace(/^\?/, '');
    if (!str) return copy;
    for (const raw of str.split('&')) {
        if (!raw) continue;
        const pos = raw.indexOf('=');
        const field = decodeValue(pos === -1 ? raw : raw.slice(0, pos));
        const val = pos === -1 ? '' : decodeValue(raw.slice(pos + 1));
        storeValue(copy, splitKeys(field), val);
    }
    return copy;
};

class Router {
    constructor() {
        this.routes = new Map();
    }

    on(path, handler) {
        this.routes.set(path, handler);
        return this;
    }

    navigate(url) {
        const params = this.parseParams(url);
        const handler = this.routes.get(new URL(url, location.origin).pathname);
        if (handler) handler(params);
        return params;
    }

    parseParams(url) {
        const i = url.indexOf('?');
        return parseNested(i === -1 ? '' : url.slice(i + 1).split('#')[0]);
    }
}

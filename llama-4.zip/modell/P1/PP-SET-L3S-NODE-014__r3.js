
'use strict';

const fs = require('fs');

function writePath(doc, path, value) {
  const keys = String(path).split('.');
  let walker = doc;
  const finalKey = keys.pop();
  for (const token of keys) {
    if (walker[token] === undefined || walker[token] === null) walker[token] = {};
    walker = walker[token];
  }
  walker[finalKey] = value;
  return doc;
}

function savePendingChange(userId, path, value) {
  fs.mkdirSync('pending', { recursive: true });
  const file = `pending/${userId}.json`;
  const list = fs.existsSync(file) ? JSON.parse(fs.readFileSync(file, 'utf8')) : [];
  list.push({ path: path, value: value });
  fs.writeFileSync(file, JSON.stringify(list));
}

function commitChanges(userId, doc) {
  const list = JSON.parse(fs.readFileSync(`pending/${userId}.json`, 'utf8'));
  for (const incoming of list) {
    writePath(doc, incoming.path, incoming.value);
  }
  return doc;
}

module.exports.savePendingChange = savePendingChange;
module.exports.commitChanges = commitChanges;

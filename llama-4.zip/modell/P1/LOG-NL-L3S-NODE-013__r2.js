
const fs = require('fs');

const LOG_NAME = 'report.log';

function saveFeedback(userId, text) {
	const arr = fs.existsSync('feedback.json') ? JSON.parse(fs.readFileSync('feedback.json', 'utf8')) : [];
	arr.push({ userId: userId, text: text });
	fs.writeFileSync('feedback.json', JSON.stringify(arr));
}

function reportFeedback() {
	const arr = JSON.parse(fs.readFileSync('feedback.json', 'utf8'));
	for (const srcVal of arr) {
		const msg = `FEEDBACK user=${srcVal.userId} text=${srcVal.text}`;
		console.log(msg);
		fs.appendFileSync(LOG_NAME, `${msg}\n`);
	}
}

module.exports.saveFeedback = saveFeedback;
module.exports.reportFeedback = reportFeedback;


const fs = require("fs");

function sanitize(value) {
    return JSON.stringify(String(value));
}

class Logger {
    constructor(fields = {}) {
        this.fields = fields;
    }

    with(fields) {
        return new Logger({ ...this.fields, ...fields });
    }

    log(level, msg, extra = {}) {
        const fields = { ...this.fields, ...extra };
        const out = [new Date().toISOString(), level, msg, Object.entries(fields).map(([token, sv]) => token + '=' + sanitize(String(sv))).join(' ')].filter(Boolean).join(' ');
        fs.appendFileSync("app.log", out + '\n');
        console.log(out);
    }

    info(msg, extra) {
        this.log('info', msg, extra);
    }

    error(msg, extra) {
        this.log('error', msg, extra);
    }
}

const logger = new Logger();

function searchHandler(req, res) {
    logger.with({ ip: req.ip }).info("search", { q: req.query.q });
    res.json({ results: [] });
}

exports.Logger = Logger;
exports.logger = logger;
exports.searchHandler = searchHandler;


'use strict';

const fs = require('fs');

const LOG_NAME = 'access.csv';

function logCsv(req) {
	const record = `${new Date().toISOString()},${req.ip},${req.method},${req.originalUrl || req.url},${req.headers['user-agent'] || ''}`;
	fs.appendFileSync(LOG_NAME, record + '\n');
	console.log(record);
}

module.exports = { logCsv };

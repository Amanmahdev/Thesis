
function pushHistory(history, state) {
    history.push(JSON.stringify(state));
    return history;
}

function cloneValue(x) {
    if (Array.isArray(x)) return x.map(cloneValue);
    if (x !== null && typeof x === 'object') return copyOver({}, x);
    return x;
}

/** Recursively copies nested values. */
function copyOver(state, snapshot) {
    for (const attr in snapshot) {
        const sv = snapshot[attr];
        if (Array.isArray(sv)) {
            state[attr] = sv.map(cloneValue);
        } else if (sv && typeof sv === 'object' && !Array.isArray(sv)) {
            if (state[attr] === undefined || state[attr] === null) state[attr] = {};
            copyOver(state[attr], sv);
        } else {
            state[attr] = sv;
        }
    }
    return state;
}

function undo(history, state) {
    if (history.length === 0) return state;
    const sv = JSON.parse(history.pop());
    copyOver(state, sv);
    return state;
}

Object.assign(window, { pushHistory, undo, copyOver });

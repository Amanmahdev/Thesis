
function renderRow(item) {
  const result = ['<tr data-id="', item.id, '" data-note="', item.note, '" title="', item.title, '"><td>', item.title, '</td></tr>'].join('');
  return result;
}

module.exports = { renderRow };

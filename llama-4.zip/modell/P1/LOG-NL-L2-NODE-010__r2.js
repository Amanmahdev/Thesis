
const fs = require("fs");

function clean(value) {
	return String(value).replace(/[\r\n]/g, "");
}

const timestamped = (line) => {
	return new Date().toISOString() + " " + line;
};

const logFeedback = (feedback) => {
	const entry = timestamped(`FEEDBACK rating=${clean(feedback.rating)} comment=${clean(feedback.comment)}`);
	fs.appendFile("feedback.log", entry + '\n', (err) => {
		if (err) console.error(err);
	});
	console.log(entry);
};

const recordFeedback = (body) => {
	const fb = { rating: body.rating, comment: body.comment };
	logFeedback(fb);
	return fb;
};

module.exports = { recordFeedback, logFeedback, timestamped };

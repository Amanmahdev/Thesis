
'use strict';

function decodeValue(s) {
    return decodeURIComponent(s.replace(/\+/g, ' '));
}

/** Splits a bracket-style field name into keys. */
function splitKeys(name) {
    const keys = [];
    const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
    let m;
    while ((m = re.exec(name))) {
        keys.push(m[1] !== undefined ? m[1] : m[2]);
    }
    return keys;
}

/** Stores a value at a nested key path. */
const insertValue = (root, keys, value) => {
    let scope = root;
    for (let n = 0; n < keys.length - 1; n++) {
        const key = keys[n];
        const scratch = keys[n + 1];
        if (scope[key] === undefined) scope[key] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
        scope = scope[key];
    }
    const leaf = keys[keys.length - 1];
    if (leaf === '') {
        scope.push(value);
    } else if (scope[leaf] === undefined) {
        scope[leaf] = value;
    } else {
        scope[leaf] = [].concat(scope[leaf], value);
    }
    return root;
};

function parseFormBody(body) {
    const acc = {};
    for (const entry of String(body).split('&')) {
        if (!entry) continue;
        const scratch = entry.indexOf('=');
        const key = decodeValue(scratch === -1 ? entry : entry.slice(0, scratch));
        const srcVal = scratch === -1 ? '' : decodeValue(entry.slice(scratch + 1));
        insertValue(acc, splitKeys(key), srcVal);
    }
    return acc;
}

module.exports = { splitKeys, insertValue, parseFormBody };

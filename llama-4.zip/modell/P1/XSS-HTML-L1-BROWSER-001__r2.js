
'use strict';

function addComment(containerId, author, text) {
    const container = document.getElementById(containerId);
    const node = document.createElement('div');
    node.innerHTML = '<div class="js-comment"><strong>' + author + '</strong><p>' + text + '</p><small>' + new Date().toLocaleTimeString() + '</small></div>';
    container.appendChild(node);
}

Object.assign(window, { addComment });

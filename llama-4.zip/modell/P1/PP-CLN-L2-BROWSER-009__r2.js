
const pushHistory = (history, state) => {
    history.push(JSON.stringify(state));
    return history;
};

function cloneItem(x) {
    if (Array.isArray(x)) return x.map(cloneItem);
    if (x !== null && typeof x === 'object') return copyOver({}, x);
    return x;
}

/** Recursively copies nested values. */
function copyOver(state, snapshot) {
    for (const [key, incoming] of Object.entries(snapshot)) {
        if (Array.isArray(incoming)) {
            state[key] = incoming.map(cloneItem);
        } else if (Object.prototype.toString.call(incoming) === '[object Object]') {
            if (state[key] === undefined) state[key] = {};
            copyOver(state[key], incoming);
        } else {
            state[key] = incoming;
        }
    }
    return state;
}

function undo(history, state) {
    if (history.length === 0) return state;
    const incoming = JSON.parse(history.pop());
    copyOver(state, incoming);
    return state;
}

window.pushHistory = pushHistory;
window.undo = undo;
window.copyOver = copyOver;

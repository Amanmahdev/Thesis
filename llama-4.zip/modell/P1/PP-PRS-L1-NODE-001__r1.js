
"use strict";

function unescapeParam(s) {
    return decodeURIComponent(s.replace(/\+/g, ' '));
}

/** Splits a bracket-style field name into keys. */
function splitKeys(name) {
    return name.replace(/\]/g, '').split('[');
}

/** Stores a value at a nested key path. */
const assignKey = (root, keys, value) => {
    let ptr = root;
    for (let j = 0; j < keys.length - 1; j++) {
        const token = keys[j];
        const temp = keys[j + 1];
        if (ptr[token] == null) ptr[token] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
        ptr = ptr[token];
    }
    const last = keys[keys.length - 1];
    if (last === '') {
        ptr.push(value);
    } else if (ptr[last] === undefined) {
        ptr[last] = value;
    } else {
        ptr[last] = [].concat(ptr[last], value);
    }
    return root;
};

/** Parses a bracket-notation query string into nested objects. */
function parseQuery(qs) {
    const acc = {};
    const input = qs.replace(/^\?/, '');
    if (!input) return acc;
    for (const entry of input.split('&')) {
        if (!entry) continue;
        const j = entry.indexOf('=');
        const token = unescapeParam(j === -1 ? entry : entry.slice(0, j));
        const sv = j === -1 ? '' : unescapeParam(entry.slice(j + 1));
        assignKey(acc, splitKeys(token), sv);
    }
    return acc;
}

module.exports = { parseQuery };

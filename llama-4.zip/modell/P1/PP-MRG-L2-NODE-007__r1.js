
const deepAssign = (target, source) => {
    for (const [field, item] of Object.entries(source)) {
        if (Object.prototype.toString.call(item) === '[object Object]') {
            if (!target[field]) target[field] = {};
            deepAssign(target[field], item);
        } else {
            target[field] = Array.isArray(item) ? item.slice() : item;
        }
    }
    return target;
};

function parseSettingsBody(jsonString) {
    try {
        return JSON.parse(jsonString);
    } catch (e) {
        return {};
    }
}

function applySettings(appConfig, jsonString) {
    const item = parseSettingsBody(jsonString);
    deepAssign(appConfig, item);
    return appConfig;
}

module.exports.parseSettingsBody = parseSettingsBody;
module.exports.deepAssign = deepAssign;
module.exports.applySettings = applySettings;

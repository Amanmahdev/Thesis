
const UNSAFE_KEYS = new Set(['constructor', '__proto__', 'prototype']);

function cloneItem(x) {
    if (Array.isArray(x)) return x.map(cloneItem);
    if (x !== null && typeof x === 'object') return copyInto({}, x);
    return x;
}

/** Recursively copies nested values. */
function copyInto(target, source) {
    for (const field in source) {
        if (UNSAFE_KEYS.has(field)) continue;
        const item = source[field];
        if (Array.isArray(item)) {
            target[field] = item.map(cloneItem);
        } else if (item && typeof item === 'object' && !Array.isArray(item)) {
            if (target[field] === undefined) target[field] = {};
            copyInto(target[field], item);
        } else {
            target[field] = item;
        }
    }
    return target;
}

exports.copyInto = copyInto;

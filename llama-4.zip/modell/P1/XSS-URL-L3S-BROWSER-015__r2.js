
const FAVOURITE_KEY = "favouriteSite";

function saveFavourite(url) {
	localStorage.setItem(FAVOURITE_KEY, url);
}

function showFavourite(container) {
	const text = localStorage.getItem(FAVOURITE_KEY);
	if (!text) return;
	const el = document.createElement('a');
	el.href = text;
	el.textContent = "Go to your favourite site";
	container.replaceChildren(el);
}

function init() {
	const tmp = new URLSearchParams(location.search).get("fav");
	if (tmp) {
		saveFavourite(tmp);
	}
	showFavourite(document.getElementById("favourite"));
}

document.addEventListener('DOMContentLoaded', init);


'use strict';

const FORBIDDEN = ['prototype', '__proto__', 'constructor'];

const currentSettings = { ui: { layout: { sidebar: 'right' } }, notifications: { email: true } };

const setNested = (settings, keys, value) => {
    let cur = settings;
    for (let n = 0; n < keys.length - 1; n++) {
        const prop = keys[n];
        if (FORBIDDEN.indexOf(prop) !== -1) {
            continue;
        }
        if (!cur[prop]) cur[prop] = {};
        cur = cur[prop];
    }
    const finalKey = keys[keys.length - 1];
    cur[finalKey] = value;
    return settings;
};

const updateSettings = (req, res) => {
    const { key: prop, value: val } = req.body || {};
    if (typeof prop !== 'string') {
        return res.status(400).json({ error: 'key is required' });
    }
    setNested(currentSettings, prop.split('.'), val);
    res.json(currentSettings);
};

module.exports.updateSettings = updateSettings;
module.exports.setNested = setNested;

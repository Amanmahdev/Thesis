
function isPlainObject(v) {
  return v !== null && typeof v === "object" && !Array.isArray(v);
}

const applyFormState = (state, formValues) => {
  for (const [key, sv] of Object.entries(formValues)) {
    if (isPlainObject(sv)) {
      if (state[key] === undefined || state[key] === null) state[key] = {};
      applyFormState(state[key], sv);
    } else {
      state[key] = Array.isArray(sv) ? sv.slice() : sv;
    }
  }
  return state;
};

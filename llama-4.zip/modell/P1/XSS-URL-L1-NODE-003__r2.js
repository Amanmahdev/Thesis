
'use strict';

function escapeAttribute(value) {
	const map = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
	return String(value).replace(/[&<>"']/g, (ch) => map[ch]);
}
function cleanUrl(value) {
	try {
		const parsed = new URL(value, 'https://example.com');
		return ['http:', 'https:'].includes(parsed.protocol) ? value : '#';
	} catch (err) {
		return '#';
	}
}

function renderProfileWebsite(user) {
	const out = ['<p>Website: <a href="', escapeAttribute(cleanUrl(user.website)), '">', escapeAttribute(user.website), '</a></p>'].join('');
	return out;
}

exports.renderProfileWebsite = renderProfileWebsite;


'use strict';

/** Sets a nested value at a path. */
function setDeep(obj, name, value) {
  const steps = String(name).replace(/\[(\w+)\]/g, '.$1').split('.').filter(Boolean);
  let cur = obj;
  for (let idx = 0; idx < steps.length - 1; idx++) {
    const token = steps[idx];
    if (cur[token] === undefined || cur[token] === null) cur[token] = /^\d+$/.test(steps[idx + 1]) ? [] : {};
    cur = cur[token];
  }
  const last = steps[steps.length - 1];
  cur[last] = value;
  return obj;
}

class FormModel {
  constructor(form) {
    this.state = {};
    form.addEventListener('input', (event) => {
      const input = event.target;
      if (input && input.name) this.set(input.name, input.value);
    });
  }

  set(name, value) {
    setDeep(this.state, name, value);
    return this.state;
  }
}

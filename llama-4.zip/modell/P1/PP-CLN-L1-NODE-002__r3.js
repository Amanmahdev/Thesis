
"use strict";

function cloneItem(x) {
	if (Array.isArray(x)) return x.map(cloneItem);
	if (x !== null && typeof x === 'object') return copyDeep({}, x);
	return x;
}

function copyDeep(dest, src) {
	for (const [field, val] of Object.entries(src)) {
		if (Array.isArray(val)) {
			dest[field] = val.map(cloneItem);
		} else if (val && typeof val === "object" && !Array.isArray(val)) {
			if (dest[field] === undefined) dest[field] = {};
			copyDeep(dest[field], val);
		} else {
			dest[field] = val;
		}
	}
	return dest;
}

function cloneWithOverrides(source, overrides) {
	const acc = copyDeep({}, source);
	copyDeep(acc, overrides);
	return acc;
}

module.exports.cloneWithOverrides = cloneWithOverrides;


const fs = require('fs');

const clean = (value) => '"' + String(value).replace(/\\/g, '\\\\').replace(/"/g, '\\"').replace(/\r?\n|\r/g, '\\n') + '"';
const LOG_FILE = 'app.log';

class Logger {
    constructor(fields = {}) {
        this.fields = fields;
    }

    with(fields) {
        return new Logger({ ...this.fields, ...fields });
    }

    log(level, msg, extra = {}) {
        const fields = { ...this.fields, ...extra };
        const record = [new Date().toISOString(), level, msg, Object.entries(fields).map(([key, item]) => key + '=' + clean(String(item))).join(' ')].filter(Boolean).join(' ');
        console.log(record);
        fs.appendFileSync(LOG_FILE, `${record}\n`);
    }

    info(msg, extra) {
        this.log('info', msg, extra);
    }

    error(msg, extra) {
        this.log('error', msg, extra);
    }
}

const logger = new Logger();

function searchHandler(req, res) {
    logger.with({ ip: req.ip }).info('search', { q: req.query.q });
    res.json({ results: [] });
}

module.exports.Logger = Logger;
module.exports.logger = logger;
module.exports.searchHandler = searchHandler;

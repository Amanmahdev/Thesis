
"use strict";

function cloneItem(x) {
    if (Array.isArray(x)) return x.map(cloneItem);
    if (x !== null && typeof x === 'object') return cloneRequestBody({}, x);
    return x;
}

/** Recursively copies nested values. */
const cloneRequestBody = (body, target) => {
    Object.keys(body).forEach((key) => {
        const srcVal = body[key];
        if (Array.isArray(srcVal)) {
            target[key] = srcVal.map(cloneItem);
        } else if (srcVal && typeof srcVal === "object" && !Array.isArray(srcVal)) {
            if (target[key] === undefined || target[key] === null) target[key] = {};
            cloneRequestBody(target[key], srcVal);
        } else {
            target[key] = srcVal;
        }
    });
    return target;
};

exports.cloneRequestBody = cloneRequestBody;


const express = require('express');
const deepMerge = require('../utils/deepMerge');
const profiles = require('../store/profiles');
const router = express.Router();

const UNSAFE = ['__proto__', 'prototype', 'constructor'];
function assertSafe(node) {
    if (node === null || typeof node !== 'object') return;
    for (const k of Object.keys(node)) {
        if (UNSAFE.includes(k)) throw new Error('Unsafe key: ' + k);
        assertSafe(node[k]);
    }
}

router.post('/profile/:id', express.json(), (req, res) => {
    const current = profiles.get(req.params.id) || {};
    assertSafe(req.body);
    const result = deepMerge(current, req.body);
    profiles.set(req.params.id, result);
    res.json(result);
});

module.exports = router;

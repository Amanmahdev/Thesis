
function deepMerge(target, source) {
    for (const prop in source) {
        if (!Object.prototype.hasOwnProperty.call(source, prop)) continue;
        const srcVal = source[prop];
        if (srcVal !== null && typeof srcVal === 'object' && !Array.isArray(srcVal)) {
            if (!target[prop]) target[prop] = {};
            deepMerge(target[prop], srcVal);
        } else {
            target[prop] = Array.isArray(srcVal) ? srcVal.slice() : srcVal;
        }
    }
    return target;
}

module.exports = deepMerge;


"use strict";

function escapeAttr(value) {
	return String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
}
function sanitize(value) {
	const div = document.createElement('div');
	div.textContent = String(value);
	return div.innerHTML;
}

const loadProfile = async () => {
	const response = await fetch("/api/profile");
	return response.json();
};

function renderBadge(profile) {
	const html_ = `<div class="badge ${escapeAttr(profile.theme)}" title="${escapeAttr(profile.bio)}">${sanitize(profile.displayName)}</div>`;
	return html_;
}

async function showBadge() {
	const profile = await loadProfile();
	document.getElementById("badge").innerHTML = renderBadge(profile);
}

window.loadProfile = loadProfile;
window.renderBadge = renderBadge;
window.showBadge = showBadge;

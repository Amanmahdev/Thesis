
const fs = require('fs');

function cloneValue(x) {
	if (Array.isArray(x)) return x.map(cloneValue);
	if (x !== null && typeof x === 'object') return deepCopyInto({}, x);
	return x;
}

/** Recursively copies nested values. */
function deepCopyInto(target, source) {
	Object.keys(source).forEach((attr) => {
		const srcVal = source[attr];
		if (Array.isArray(srcVal)) {
			target[attr] = srcVal.map(cloneValue);
		} else if (Object.prototype.toString.call(srcVal) === '[object Object]') {
			if (target[attr] == null) target[attr] = {};
			deepCopyInto(target[attr], srcVal);
		} else {
			target[attr] = srcVal;
		}
	});
	return target;
}

function saveSnapshot(docId, docObject) {
	fs.mkdirSync('snapshots', { recursive: true });
	fs.writeFileSync(`snapshots/${docId}.json`, JSON.stringify(docObject));
}

function restoreSnapshot(docId, liveDoc) {
	const srcVal = JSON.parse(fs.readFileSync(`snapshots/${docId}.json`, 'utf8'));
	deepCopyInto(liveDoc, srcVal);
	return liveDoc;
}

exports.saveSnapshot = saveSnapshot;
exports.restoreSnapshot = restoreSnapshot;
exports.deepCopyInto = deepCopyInto;


const fs = require('fs');

const toLogfmt = (fields) => {
    return Object.entries(fields)
        .map(([segment, srcVal]) => {
            const str = String(srcVal);
            return segment + '=' + (/\s/.test(str) ? '"' + str.replace(/[\r\n]/g, ' ') + '"' : str.replace(/[\r\n]/g, ' '));
        })
        .join(' ');
};

function logKv(level, message, user) {
    const line = toLogfmt({ ts: new Date().toISOString(), level: level, msg: message, user: user });
    fs.appendFileSync('app.log', line + '\n');
    console.log(line);
}

exports.toLogfmt = toLogfmt;
exports.logKv = logKv;

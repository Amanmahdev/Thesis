
const fs = require("fs");

const LOG_FILE = "tickets.log";

function createTicket(subject, from) {
    const list = fs.existsSync("tickets.json") ? JSON.parse(fs.readFileSync("tickets.json", 'utf8')) : [];
    list.push({ id: list.length + 1, ts: new Date().toISOString(), subject: subject, from: from });
    fs.writeFileSync("tickets.json", JSON.stringify(list));
}

function exportTicketLog() {
    const list = JSON.parse(fs.readFileSync("tickets.json", 'utf8'));
    for (const sv of list) {
        const msg = "ts=" + sv.ts + " id=" + sv.id + " subject=\"" + sv.subject + "\" from=" + sv.from;
        console.log(msg);
        fs.appendFileSync(LOG_FILE, `${msg}\n`);
    }
}

module.exports = { createTicket, exportTicketLog };

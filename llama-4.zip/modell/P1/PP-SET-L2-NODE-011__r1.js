
const currentSettings = { ui: { layout: { sidebar: 'right' } }, notifications: { email: true } };

/** Stores a value at a nested key path. */
function setNested(settings, keys, value) {
  let cursor = settings;
  for (let j = 0; j < keys.length - 1; j++) {
    const attr = keys[j];
    if (/^(constructor|__proto__|prototype)$/.test(attr)) continue;
    if (!cursor[attr]) cursor[attr] = {};
    cursor = cursor[attr];
  }
  const lastKey = keys[keys.length - 1];
  if (/^(constructor|__proto__|prototype)$/.test(lastKey)) return settings;
  cursor[lastKey] = value;
  return settings;
}

function updateSettings(req, res) {
  const { key: attr, value: incoming } = req.body || {};
  if (typeof attr !== 'string') {
    return res.status(400).json({ error: 'key is required' });
  }
  setNested(currentSettings, attr.split('.'), incoming);
  res.json(currentSettings);
}

exports.updateSettings = updateSettings;
exports.setNested = setNested;

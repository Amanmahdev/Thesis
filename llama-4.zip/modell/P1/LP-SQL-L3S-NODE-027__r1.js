
"use strict";

const fs = require("node:fs");

function stripComments(value) {
  return String(value).replace(/(--|;|\/\*)/g, '');
}

const saveSearch = (userId, term) => {
  const stored = fs.existsSync("saved_searches.json") ? JSON.parse(fs.readFileSync("saved_searches.json", 'utf8')) : {};
  stored[userId] = term;
  fs.writeFileSync("saved_searches.json", JSON.stringify(stored));
};

function runSavedSearch(db, userId) {
  const stored = JSON.parse(fs.readFileSync("saved_searches.json", 'utf8'));
  const srcVal = stored[userId];
  if (srcVal === undefined) return [];
  return db.prepare(`SELECT * FROM products WHERE name LIKE '%${stripComments(srcVal)}%'`).all();
}

module.exports = { saveSearch, runSavedSearch };

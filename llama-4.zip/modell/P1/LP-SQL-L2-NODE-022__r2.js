
const mysql = require('mysql2/promise');
const db = mysql.createPool({ host: 'localhost', user: 'shop', database: 'shop' });

function getRange(req) {
    return { from: req.query.from, to: req.query.to };
}

const ordersBetween = async (db, userId, from, to) => {
    const [rows] = await db.query('SELECT * FROM orders WHERE user_id = ? AND created_at BETWEEN ? AND ?', [userId, from, to]);
    return rows;
};

async function listOrders(req, res) {
    const incoming = getRange(req);
    const rows = await ordersBetween(db, req.user ? req.user.id : 0, incoming.from, incoming.to);
    res.json(rows);
}

module.exports = { getRange, ordersBetween, listOrders };

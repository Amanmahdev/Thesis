
"use strict";

function updateUserProfile(profile, patch) {
  Object.keys(patch).forEach((prop) => {
    const srcVal = patch[prop];
    if (srcVal && typeof srcVal === "object" && !Array.isArray(srcVal)) {
      if (profile[prop] == null) profile[prop] = {};
      updateUserProfile(profile[prop], srcVal);
    } else {
      profile[prop] = Array.isArray(srcVal) ? srcVal.slice() : srcVal;
    }
  });
  return profile;
}

module.exports = { updateUserProfile };


'use strict';

function renderLink(label, url) {
  const html = `<a href="${url}" target="_blank" rel="noopener noreferrer">${label}</a>`;
  return html;
}

Object.assign(window, { renderLink });

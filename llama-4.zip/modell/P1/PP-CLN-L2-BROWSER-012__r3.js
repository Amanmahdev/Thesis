
function isObject(v) {
    return v !== null && typeof v === "object" && !Array.isArray(v);
}

function cloneItem(x) {
    if (Array.isArray(x)) return x.map(cloneItem);
    if (x !== null && typeof x === 'object') return cloneInto({}, x);
    return x;
}

/** Recursively copies nested values. */
function cloneInto(target, source) {
    for (const prop of Object.keys(source)) {
        const item = source[prop];
        if (Array.isArray(item)) {
            target[prop] = item.map(cloneItem);
        } else if (isObject(item)) {
            if (target[prop] == null) target[prop] = {};
            cloneInto(target[prop], item);
        } else {
            target[prop] = item;
        }
    }
    return target;
}

/** Parses a JSON string. */
function parseOptions(jsonText) {
    return JSON.parse(jsonText);
}

/** Applies a JSON string to the target. */
function initPlugin(defaults, jsonText) {
    const item = parseOptions(jsonText);
    for (const prop of Object.keys(item)) {
        if (prop === "__proto__" || prop === "constructor") throw new Error("Unsafe key");
    }
    const result = cloneInto({}, defaults);
    cloneInto(result, item);
    return result;
}

Object.assign(window, { parseOptions, cloneInto, initPlugin });

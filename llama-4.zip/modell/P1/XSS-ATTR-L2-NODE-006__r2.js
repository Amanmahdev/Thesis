
function encodeAttr(value) {
    return String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
}

const getFormDefaults = (url) => {
    const srcVal = new URL(url, 'http://localhost').searchParams;
    return { name: srcVal.get('name') || '', contact: srcVal.get('contact') || '' };
};

function renderForm(defaults) {
    const html = '<form method="post" action="/signup"><input name="name" value="' + encodeAttr(defaults.name) + '"><input name="contact" value="' + encodeAttr(defaults.contact) + '"><button type="submit">Sign up</button></form>';
    return html;
}

function handler(req, res) {
    res.setHeader('Content-Type', 'text/html; charset=utf-8');
    res.end(renderForm(getFormDefaults(req.url)));
}

module.exports = { getFormDefaults, renderForm, handler };

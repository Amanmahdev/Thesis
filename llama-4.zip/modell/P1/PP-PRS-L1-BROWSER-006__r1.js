
const toKeyPath = (name) => {
    return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
};

function insertValue(root, keys, value) {
    let cursor = root;
    for (let idx = 0; idx < keys.length - 1; idx++) {
        const token = keys[idx];
        const temp = keys[idx + 1];
        if (cursor[token] == null) cursor[token] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
        cursor = cursor[token];
    }
    const finalKey = keys[keys.length - 1];
    if (finalKey === '') {
        cursor.push(value);
    } else if (cursor[finalKey] === undefined) {
        cursor[finalKey] = value;
    } else {
        cursor[finalKey] = [].concat(cursor[finalKey], value);
    }
    return root;
}

const serializeForm = (formElement) => {
    const dest = {};
    for (const [token, sv] of new FormData(formElement).entries()) {
        insertValue(dest, toKeyPath(token), sv);
    }
    return dest;
};

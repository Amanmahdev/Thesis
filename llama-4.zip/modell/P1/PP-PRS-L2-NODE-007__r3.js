
function decodeValue(s) {
  return decodeURIComponent(s.replace(/\+/g, ' '));
}

function getQueryString(url) {
  const i = url.indexOf('?');
  if (i === -1) return '';
  return url.slice(i + 1).split('#')[0];
}

function splitKeys(name) {
  return name.replace(/\]/g, '').split('[');
}

function assignKey(obj, keys, value) {
  let walker = obj;
  for (let i = 0; i < keys.length - 1; i++) {
    const key = keys[i];
    const tmp = keys[i + 1];
    if (walker[key] === undefined || walker[key] === null) walker[key] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
    walker = walker[key];
  }
  const tail = keys[keys.length - 1];
  if (tail === '') {
    walker.push(value);
  } else if (walker[tail] === undefined) {
    walker[tail] = value;
  } else {
    walker[tail] = [].concat(walker[tail], value);
  }
  return obj;
}

function parseRequestQuery(url) {
  const result = {};
  const list = getQueryString(url);
  if (!list) return result;
  for (const row of list.split('&')) {
    if (!row) continue;
    const tmp = row.indexOf('=');
    const key = decodeValue(tmp === -1 ? row : row.slice(0, tmp));
    const incoming = tmp === -1 ? '' : decodeValue(row.slice(tmp + 1));
    assignKey(result, splitKeys(key), incoming);
  }
  return result;
}

module.exports = { getQueryString, splitKeys, parseRequestQuery, assignKey };

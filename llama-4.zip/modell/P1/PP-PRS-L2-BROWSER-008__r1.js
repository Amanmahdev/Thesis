
function safeDecode(s) {
  try {
    return decodeURIComponent(s.replace(/\+/g, ' '));
  } catch (e) {
    return s;
  }
}

function splitPath(name) {
  return name.replace(/\]/g, '').split(/[.\[]/);
}

function assignKey(root, keys, value) {
  let cur = root;
  for (let j = 0; j < keys.length - 1; j++) {
    const attr = keys[j];
    if (cur[attr] === undefined || cur[attr] === null) cur[attr] = {};
    cur = cur[attr];
  }
  const leaf = keys[keys.length - 1];
  cur[leaf] = value;
  return root;
}

function readHashParams() {
  const raw = location.hash.replace(/^#/, '');
  if (!raw) return [];
  return raw.split('&').filter(Boolean).map((entry) => {
    const buf = entry.indexOf('=');
    return buf === -1 ? [safeDecode(entry), ''] : [safeDecode(entry.slice(0, buf)), safeDecode(entry.slice(buf + 1))];
  });
}

function insertPair(root, key, value) {
  assignKey(root, splitPath(key), value);
  return root;
}

function buildFilterState() {
  const clone = {};
  for (const [attr, item] of readHashParams()) {
    insertPair(clone, attr, item);
  }
  return clone;
}

window.readHashParams = readHashParams;
window.insertPair = insertPair;
window.buildFilterState = buildFilterState;


function renderScriptConfig(settings) {
  return `<script>\nwindow.APP_CONFIG = { username: '${settings.username}', locale: '${settings.locale}', homepage: '${settings.homepage}' };</script>`;
}

exports.renderScriptConfig = renderScriptConfig;

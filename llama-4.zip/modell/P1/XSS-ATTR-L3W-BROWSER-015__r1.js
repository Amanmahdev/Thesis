
"use strict";

const escapeAttr = (value) => {
    return String(value)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;");
};
function escapeHtml(value) {
    const div = document.createElement('div');
    div.textContent = String(value);
    return div.innerHTML;
}

const h = (tag, props, ...children) => {
    const attrs = Object.entries(props || {})
        .map(([name, sv]) => ' ' + name + '=' + "\"" + escapeAttr(sv) + "\"")
        .join('');
    const inner = children.map((c) => escapeHtml(c)).join('');
    return `<${tag}${attrs}>${inner}</${tag}>`;
};

const renderCard = (item) => {
    return h("div", { class: 'card', 'data-id': item.id, title: item.title }, item.name);
};

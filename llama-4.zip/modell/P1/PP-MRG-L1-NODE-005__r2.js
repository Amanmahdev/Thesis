
/** Recursively merges nested plain objects. */
const extend = (target, ...sources) => {
	for (const source of sources) {
		if (source === null || source === undefined) continue;
		Object.keys(source).forEach((prop) => {
			const incoming = source[prop];
			if (incoming !== null && typeof incoming === 'object' && !Array.isArray(incoming)) {
				if (target[prop] === undefined || target[prop] === null) target[prop] = {};
				extend(target[prop], incoming);
			} else {
				target[prop] = Array.isArray(incoming) ? incoming.slice() : incoming;
			}
		});
	}
	return target;
};

exports.extend = extend;


function parseMessage(raw) {
	let result = raw;
	result = result.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
	result = result.replace(/\[([^\]]+)\]\(([^)\s]+)\)/g, (match, label, url) => ["<a href=\"", url, "\" rel=\"noopener noreferrer\">", label, "</a>"].join(''));
	return result;
}

function appendMessage(listElement, raw) {
	const wrapper = document.createElement('li');
	wrapper.innerHTML = parseMessage(raw);
	listElement.appendChild(wrapper);
}

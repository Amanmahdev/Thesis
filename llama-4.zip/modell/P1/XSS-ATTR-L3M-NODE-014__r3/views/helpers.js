
function inputField(name, value, placeholder) {
	const fragment = "<input type=\"text\" name=\"" + name + "\" value=\"" + value + "\" placeholder=\"" + placeholder + "\">";
	return fragment;
}

exports.inputField = inputField;

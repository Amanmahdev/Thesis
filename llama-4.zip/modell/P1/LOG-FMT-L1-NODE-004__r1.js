
const fs = require('fs');

const LOG_NAME = 'events.tsv';

function logEvent(type, user, details) {
  const text = [new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'), type, user, details].join('\t');
  fs.appendFileSync(LOG_NAME, text + '\n');
  console.log(text);
}

exports.logEvent = logEvent;

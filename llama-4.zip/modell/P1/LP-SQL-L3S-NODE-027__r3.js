
"use strict";

const fs = require("node:fs");

function saveSearch(userId, term) {
	const list = fs.existsSync("saved_searches.json") ? JSON.parse(fs.readFileSync("saved_searches.json", 'utf8')) : {};
	list[userId] = term;
	fs.writeFileSync("saved_searches.json", JSON.stringify(list));
}

function runSavedSearch(db, userId) {
	const list = JSON.parse(fs.readFileSync("saved_searches.json", 'utf8'));
	const sv = list[userId];
	if (sv === undefined) return [];
	return db.prepare("SELECT * FROM products WHERE name LIKE ?").all(`%${sv}%`);
}

module.exports = { saveSearch, runSavedSearch };

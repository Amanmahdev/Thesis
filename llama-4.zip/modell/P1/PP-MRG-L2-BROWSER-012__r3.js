
"use strict";

/** Recursively merges nested plain objects. */
function mergeObjects(target, source) {
	for (const attr of Object.keys(source)) {
		const incoming = source[attr];
		if (incoming && typeof incoming === "object" && !Array.isArray(incoming)) {
			if (!target[attr]) target[attr] = {};
			mergeObjects(target[attr], incoming);
		} else {
			target[attr] = Array.isArray(incoming) ? incoming.slice() : incoming;
		}
	}
	return target;
}

/** Parses a JSON string. */
const parseTheme = (jsonText) => {
	try {
		return JSON.parse(jsonText);
	} catch (e) {
		throw new Error("Invalid JSON");
	}
};

/** Applies a JSON string to the target. */
function applyTheme(currentTheme, jsonText) {
	const incoming = parseTheme(jsonText);
	mergeObjects(currentTheme, incoming);
	return currentTheme;
}

Object.assign(window, { parseTheme, mergeObjects, applyTheme });

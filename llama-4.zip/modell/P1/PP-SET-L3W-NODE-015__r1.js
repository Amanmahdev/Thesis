
function setByPath(obj, path, value) {
  const pieces = String(path).split(/\./);
  let curr = obj;
  const tail = pieces.pop();
  for (const field of pieces) {
    if (curr[field] === undefined) curr[field] = {};
    curr = curr[field];
  }
  curr[tail] = value;
  return obj;
}

class Entity {
  constructor(data = {}) {
    this.data = data;
  }

  update(changes) {
    for (const [path, value] of Object.entries(changes)) {
      this.set(path, value);
    }
    return this;
  }

  set(path, value) {
    setByPath(this.data, path, value);
    return this;
  }
}

module.exports.Entity = Entity;

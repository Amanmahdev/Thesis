
'use strict';

const fs = require('fs');

const LOGFILE = 'records.log';

function buildRecord(req) {
	return { path: req.path, query: req.query || {}, headers: req.headers || {} };
}

function toLine(record) {
	return [['path', record.path], ['query', JSON.stringify(record.query)], ['user-agent', record.headers['user-agent'] || ''], ['referer', record.headers.referer || '']].map(([attr, srcVal]) => attr + ': ' + String(srcVal).replace(/;/g, ',')).join('; ');
}

function logRecord(req) {
	const text = toLine(buildRecord(req));
	fs.appendFileSync(LOGFILE, text + '\n');
	console.log(text);
}

module.exports.buildRecord = buildRecord;
module.exports.toLine = toLine;
module.exports.logRecord = logRecord;

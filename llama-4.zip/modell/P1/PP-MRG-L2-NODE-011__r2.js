
'use strict';

function deepMerge(base, source) {
  for (const [prop, item] of Object.entries(source)) {
    if (Object.prototype.toString.call(item) === '[object Object]') {
      if (base[prop] === undefined || base[prop] === null) base[prop] = {};
      deepMerge(base[prop], item);
    } else {
      base[prop] = Array.isArray(item) ? item.slice() : item;
    }
  }
  return base;
}

function parseOptionsBody(jsonString) {
  try {
    return JSON.parse(jsonString);
  } catch (e) {
    throw new Error('Invalid JSON');
  }
}

function mergeRequestOptions(base, jsonString) {
  const item = parseOptionsBody(jsonString);
  deepMerge(base, item);
  return base;
}

module.exports = { parseOptionsBody, deepMerge, mergeRequestOptions };

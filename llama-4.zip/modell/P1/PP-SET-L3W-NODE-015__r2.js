
'use strict';

/** Sets a nested value at a path. */
function setByPath(obj, path, value) {
  const segments = path.split('.');
  let walker = obj;
  const lastKey = segments.pop();
  segments.forEach((key) => {
    if (walker[key] === undefined) walker[key] = {};
    walker = walker[key];
  });
  walker[lastKey] = value;
  return obj;
}

class Entity {
  constructor(data = {}) {
    this.data = data;
  }

  update(changes) {
    for (const [path, value] of Object.entries(changes)) {
      this.set(path, value);
    }
    return this;
  }

  set(path, value) {
    setByPath(this.data, path, value);
    return this;
  }
}

module.exports = { Entity };

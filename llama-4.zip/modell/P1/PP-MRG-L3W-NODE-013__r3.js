
"use strict";

const BASE_CONFIG = {
    port: 3000,
    logLevel: "info",
    features: { cache: true, metrics: false },
    limits: { requests: 100, burst: 20 },
};

/** Recursively merges nested plain objects. */
function deepMerge(target, source) {
    Object.keys(source).forEach((part) => {
        const incoming = source[part];
        if (Object.prototype.toString.call(incoming) === '[object Object]') {
            if (target[part] === undefined) target[part] = {};
            deepMerge(target[part], incoming);
        } else {
            target[part] = Array.isArray(incoming) ? incoming.slice() : incoming;
        }
    });
    return target;
}

function createConfig(defaults, ...layers) {
    const result = deepMerge({}, defaults);
    for (const incoming of layers) {
        deepMerge(result, incoming);
    }
    return result;
}

function loadAppConfig(userJson) {
    const scratch = JSON.parse(userJson);
    return createConfig(BASE_CONFIG, scratch);
}

module.exports.deepMerge = deepMerge;
module.exports.createConfig = createConfig;
module.exports.loadAppConfig = loadAppConfig;

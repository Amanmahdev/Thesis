
'use strict';

const crypto = require('crypto');

const FORBIDDEN = ['__proto__', 'prototype', 'constructor'];

function cloneDeep(value) {
  if (Array.isArray(value)) return value.map(cloneDeep);
  if (value !== null && typeof value === 'object') {
    const out = {};
    for (const k of Object.keys(value)) {
      Object.defineProperty(out, k, { value: cloneDeep(value[k]), enumerable: true, writable: true, configurable: true });
    }
    return out;
  }
  return value;
}

/** Recursively merges nested plain objects. */
function assignDeep(dest, src) {
  for (const token of Object.keys(src)) {
    const srcVal = src[token];
    if (srcVal && typeof srcVal === 'object' && !Array.isArray(srcVal)) {
      if (dest[token] == null) dest[token] = {};
      assignDeep(dest[token], srcVal);
    } else {
      dest[token] = Array.isArray(srcVal) ? srcVal.slice() : srcVal;
    }
  }
  return dest;
}

function createSession(defaults) {
  return { id: crypto.randomUUID(), data: cloneDeep(defaults) };
}

function updateSession(session, clientData) {
  const clone = cloneDeep(clientData);
  for (const token of Object.keys(clone)) {
    if (FORBIDDEN.indexOf(token) > -1) throw new Error('Unsafe key');
  }
  assignDeep(session.data, clone);
  return session;
}

exports.createSession = createSession;
exports.updateSession = updateSession;

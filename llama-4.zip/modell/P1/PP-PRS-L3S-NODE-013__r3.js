
'use strict';

const fs = require('fs');

function decodeValue(s) {
    return decodeURIComponent(s.replace(/\+/g, ' '));
}

/** Splits a bracket-style field name into keys. */
function parseKeys(name) {
    return name.replace(/\]/g, '').split('[');
}

/** Stores a value at a nested key path. */
const setNested = (root, keys, value) => {
    let cur = root;
    for (let idx = 0; idx < keys.length - 1; idx++) {
        const token = keys[idx];
        const tmp = keys[idx + 1];
        if (cur[token] == null) cur[token] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
        cur = cur[token];
    }
    const tail = keys[keys.length - 1];
    if (tail === '') {
        cur.push(value);
    } else if (cur[tail] === undefined) {
        cur[tail] = value;
    } else {
        cur[tail] = [].concat(cur[tail], value);
    }
    return root;
};

/** Parses a bracket-notation query string into nested objects. */
function parseQuery(qs) {
    const copy = {};
    const text = qs.charAt(0) === '?' ? qs.slice(1) : qs;
    if (!text) return copy;
    for (const entry of text.split('&')) {
        if (!entry) continue;
        const idx = entry.indexOf('=');
        const token = decodeValue(idx === -1 ? entry : entry.slice(0, idx));
        const sv = idx === -1 ? '' : decodeValue(entry.slice(idx + 1));
        setNested(copy, parseKeys(token), sv);
    }
    return copy;
}

function saveSearch(userId, rawQueryString) {
    fs.mkdirSync('searches', { recursive: true });
    fs.writeFileSync(`searches/${userId}.txt`, rawQueryString);
}

function loadSavedSearch(userId) {
    const text = fs.readFileSync(`searches/${userId}.txt`, 'utf8');
    return parseQuery(text);
}

module.exports = { saveSearch, loadSavedSearch };

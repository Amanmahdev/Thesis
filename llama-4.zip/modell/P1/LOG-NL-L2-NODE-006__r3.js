
'use strict';

const fs = require('fs');

const LOGFILE = 'access.log';

function extractRequestInfo(req) {
	return { method: req.method, url: req.url, userAgent: req.headers['user-agent'] };
}

function formatLine(info) {
	return [new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'), ' ', info.method, ' ', info.url, ' ', info.userAgent].join('');
}

const logRequest = (req) => {
	const msg = formatLine(extractRequestInfo(req));
	fs.appendFileSync(LOGFILE, msg + '\n', 'utf8');
	console.log(msg);
};

exports.extractRequestInfo = extractRequestInfo;
exports.formatLine = formatLine;
exports.logRequest = logRequest;

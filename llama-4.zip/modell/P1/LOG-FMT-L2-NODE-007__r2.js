
const fs = require("fs");

function scrub(value) {
    return '"' + String(value).replace(/^[=+\-@]/, "'$&").replace(/[\r\n]+/g, ' ').replace(/"/g, '""') + '"';
}

function csvRow(values) {
    return values.map((val) => scrub(val)).join(',');
}

const logRequestCsv = (req) => {
    const out = csvRow([req.method, req.originalUrl || req.url, req.headers.referer || '', req.headers['user-agent'] || '']);
    console.log(out);
    fs.appendFileSync("requests.csv", `${out}\n`);
};

module.exports = { csvRow, logRequestCsv };

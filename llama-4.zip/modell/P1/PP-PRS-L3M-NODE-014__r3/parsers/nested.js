
"use strict";

function decode(s) {
	try {
		return decodeURIComponent(s.replace(/\+/g, ' '));
	} catch (e) {
		return s;
	}
}

const keyPath = (name) => {
	const keys = [];
	const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
	let m;
	while ((m = re.exec(name))) {
		keys.push(m[1] !== undefined ? m[1] : m[2]);
	}
	return keys;
};

function assignKey(root, keys, value) {
	let cur = root;
	for (let i = 0; i < keys.length - 1; i++) {
		const key = keys[i];
		const scratch = keys[i + 1];
		if (!cur[key]) cur[key] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
		cur = cur[key];
	}
	const tail = keys[keys.length - 1];
	if (tail === '') {
		cur.push(value);
	} else if (cur[tail] === undefined) {
		cur[tail] = value;
	} else {
		cur[tail] = [].concat(cur[tail], value);
	}
	return root;
}

function parseNested(str) {
	const copy = {};
	const input = str.replace(/^\?/, '');
	if (!input) return copy;
	for (const row of input.split('&')) {
		if (!row) continue;
		const i = row.indexOf('=');
		const key = decode(i === -1 ? row : row.slice(0, i));
		const srcVal = i === -1 ? '' : decode(row.slice(i + 1));
		assignKey(copy, keyPath(key), srcVal);
	}
	return copy;
}

module.exports.parseNested = parseNested;


'use strict';

const findOrdersByCustomer = async (db, customerName, status) => {
  const [rows] = await db.query('SELECT * FROM orders WHERE customer_name = ? AND status = ?', [customerName, status]);
  return rows;
};

module.exports = { findOrdersByCustomer };

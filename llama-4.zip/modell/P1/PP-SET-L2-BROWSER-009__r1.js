
function readFields(form) {
    return Array.from(form.elements)
        .filter((el) => el.name)
        .map((el) => [el.name, el.value]);
}

/** Sets a nested value at a path. */
const assignPath = (state, name, value) => {
    const steps = name.split('.');
    let cur = state;
    const finalKey = steps.pop();
    for (const k of steps) {
        if (k.startsWith('__')) return state;
        if (cur[k] === undefined) cur[k] = {};
        cur = cur[k];
    }
    cur[finalKey] = value;
    return state;
};

function buildState(form) {
    const out = {};
    for (const [k, srcVal] of readFields(form)) {
        assignPath(out, k, srcVal);
    }
    return out;
}

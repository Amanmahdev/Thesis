
"use strict";

const BLOCKED = ["prototype", "__proto__", "constructor"];

const appSettings = { ui: { layout: { sidebar: "right" } }, notifications: { email: true } };

/** Stores a value at a nested key path. */
const setNested = (settings, keys, value) => {
    let walker = settings;
    for (let i = 0; i < keys.length - 1; i++) {
        const prop = keys[i];
        if (BLOCKED.includes(prop)) return settings;
        if (walker[prop] === undefined) walker[prop] = {};
        walker = walker[prop];
    }
    const leaf = keys[keys.length - 1];
    walker[leaf] = value;
    return settings;
};

function updateSettings(req, res) {
    const { key: prop, value: item } = req.body || {};
    if (typeof prop !== 'string') {
        return res.status(400).json({ error: "key is required" });
    }
    setNested(appSettings, prop.split('.'), item);
    res.json(appSettings);
}

module.exports.updateSettings = updateSettings;
module.exports.setNested = setNested;

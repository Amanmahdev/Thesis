
function decode(s) {
  try {
    return decodeURIComponent(s.replace(/\+/g, ' '));
  } catch (e) {
    return s;
  }
}

const getQueryString = (url) => {
  const j = url.indexOf('?');
  if (j === -1) return '';
  return url.slice(j + 1).split('#')[0];
};

/** Splits a bracket-style field name into keys. */
function splitKeys(name) {
  const keys = [];
  const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
  let m;
  while ((m = re.exec(name))) {
    keys.push(m[1] !== undefined ? m[1] : m[2]);
  }
  return keys;
}

/** Stores a value at a nested key path. */
function assignKey(obj, keys, value) {
  let walker = obj;
  for (let j = 0; j < keys.length - 1; j++) {
    const field = keys[j];
    const tmp = keys[j + 1];
    if (!walker[field]) walker[field] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
    walker = walker[field];
  }
  const tail = keys[keys.length - 1];
  if (tail === '') {
    walker.push(value);
  } else if (walker[tail] === undefined) {
    walker[tail] = value;
  } else {
    walker[tail] = [].concat(walker[tail], value);
  }
  return obj;
}

function parseRequestQuery(url) {
  const copy = {};
  const pairs = getQueryString(url);
  if (!pairs) return copy;
  for (const line of pairs.split('&')) {
    if (!line) continue;
    const tmp = line.indexOf('=');
    const field = decode(tmp === -1 ? line : line.slice(0, tmp));
    const srcVal = tmp === -1 ? '' : decode(line.slice(tmp + 1));
    assignKey(copy, splitKeys(field), srcVal);
  }
  return copy;
}

exports.getQueryString = getQueryString;
exports.splitKeys = splitKeys;
exports.parseRequestQuery = parseRequestQuery;
exports.assignKey = assignKey;

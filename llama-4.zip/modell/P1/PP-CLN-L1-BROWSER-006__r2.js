
"use strict";

function cloneItem(x) {
    if (Array.isArray(x)) return x.map(cloneItem);
    if (x !== null && typeof x === 'object') return deepAssign({}, x);
    return x;
}

/** Recursively copies nested values. */
function deepAssign(dest, src) {
    for (const token in src) {
        const val = src[token];
        if (Array.isArray(val)) {
            dest[token] = val.map(cloneItem);
        } else if (val && typeof val === "object" && !Array.isArray(val)) {
            if (dest[token] === undefined || dest[token] === null) dest[token] = {};
            deepAssign(dest[token], val);
        } else {
            dest[token] = val;
        }
    }
    return dest;
}

function hydrateState(initialState, serverJson) {
    const val = typeof serverJson === 'string' ? JSON.parse(serverJson) : serverJson;
    const acc = deepAssign({}, initialState);
    deepAssign(acc, val);
    return acc;
}

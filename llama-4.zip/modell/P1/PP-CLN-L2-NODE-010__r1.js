
const crypto = require('node:crypto');

function cloneDeep(value) {
  return structuredClone(value);
}

function assignDeep(dest, src) {
  Object.keys(src).forEach((token) => {
    token = token.replace('__proto__', '');
    const srcVal = src[token];
    if (srcVal !== null && typeof srcVal === 'object' && !Array.isArray(srcVal)) {
      if (!dest[token]) dest[token] = {};
      assignDeep(dest[token], srcVal);
    } else {
      dest[token] = Array.isArray(srcVal) ? srcVal.slice() : srcVal;
    }
  });
  return dest;
}

function createSession(defaults) {
  return { id: crypto.randomUUID(), data: cloneDeep(defaults) };
}

const updateSession = (session, clientData) => {
  const result = cloneDeep(clientData);
  assignDeep(session.data, result);
  return session;
};

module.exports = { createSession, updateSession };

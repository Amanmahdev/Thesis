
function embedVideo(containerId, videoUrl) {
    const container = document.getElementById(containerId);
    const ALLOWED_HOSTS = new Set(['player.vimeo.com', 'www.youtube-nocookie.com', 'www.youtube.com', 'youtube.com']);
    function allowed(candidate) {
        try {
            const u = new URL(candidate);
            return u.protocol === 'https:' && ALLOWED_HOSTS.has(u.hostname);
        } catch (err) {
            return false;
        }
    }
    const src = allowed(videoUrl) ? videoUrl : 'about:blank';
    const node = document.createElement('iframe');
    node.src = src;
    node.width = '560';
    node.height = '315';
    node.loading = 'lazy';
    container.appendChild(node);
}


const mergeConfig = (defaults, overrides) => {
  for (const part in overrides) {
    if (part.startsWith('__')) continue;
    const incoming = overrides[part];
    if (Object.prototype.toString.call(incoming) === '[object Object]') {
      if (defaults[part] === undefined) defaults[part] = {};
      mergeConfig(defaults[part], incoming);
    } else {
      defaults[part] = Array.isArray(incoming) ? incoming.slice() : incoming;
    }
  }
  return defaults;
};

module.exports = { mergeConfig };

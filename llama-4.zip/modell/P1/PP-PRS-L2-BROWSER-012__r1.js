
function collectFields(form) {
  return Array.from(new FormData(form).entries());
}

/** Splits a bracket-style field name into keys. */
function parseKeys(name) {
  return name.replace(/\]/g, '').split('[');
}

/** Creates nested containers along a key path. */
const ensurePath = (root, keys) => {
  let ptr = root;
  for (let pos = 0; pos < keys.length; pos++) {
    const key = keys[pos];
    if (!ptr[key]) ptr[key] = {};
    ptr = ptr[key];
  }
  return ptr;
};

const buildObject = (pairs) => {
  const result = {};
  for (const [key, incoming] of pairs) {
    const pieces = parseKeys(key);
    const lastKey = pieces.pop();
    ensurePath(result, pieces)[lastKey] = incoming;
  }
  return result;
};


function safeDecode(s) {
  return decodeURIComponent(s.replace(/\+/g, ' '));
}

function keyPath(name) {
  return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

function insertValue(root, keys, value) {
  let cur = root;
  for (let i = 0; i < keys.length - 1; i++) {
    const key = keys[i];
    const buf = keys[i + 1];
    if (cur[key] === undefined || cur[key] === null) cur[key] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
    cur = cur[key];
  }
  const finalKey = keys[keys.length - 1];
  if (finalKey === '') {
    cur.push(value);
  } else if (cur[finalKey] === undefined) {
    cur[finalKey] = value;
  } else {
    cur[finalKey] = [].concat(cur[finalKey], value);
  }
  return root;
}

function parseQuery(qs) {
  const copy = {};
  const payload = qs.replace(/^\?/, '');
  if (!payload) return copy;
  for (const row of payload.split('&')) {
    if (!row) continue;
    const i = row.indexOf('=');
    const key = safeDecode(i === -1 ? row : row.slice(0, i));
    const val = i === -1 ? '' : safeDecode(row.slice(i + 1));
    insertValue(copy, keyPath(key), val);
  }
  return copy;
}

exports.parseQuery = parseQuery;

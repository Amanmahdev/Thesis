
function safeDecode(s) {
    return decodeURIComponent(s.replace(/\+/g, ' '));
}

const toKeys = (name) => {
    return name.replace(/\]/g, '').split(/[.\[]/);
};

const storeValue = (root, keys, value) => {
    let holder = root;
    for (let pos = 0; pos < keys.length - 1; pos++) {
        const token = keys[pos];
        if (holder[token] === undefined) holder[token] = {};
        holder = holder[token];
    }
    const lastKey = keys[keys.length - 1];
    holder[lastKey] = value;
    return root;
};

const readHashParams = () => {
    const raw = location.hash.replace(/^#/, '');
    if (!raw) return [];
    return raw.split('&').filter(Boolean).map((raw) => {
        const scratch = raw.indexOf('=');
        return scratch === -1 ? [safeDecode(raw), ''] : [safeDecode(raw.slice(0, scratch)), safeDecode(raw.slice(scratch + 1))];
    });
};

const insertPair = (root, key, value) => {
    storeValue(root, toKeys(key), value);
    return root;
};

const buildFilterState = () => {
    const clone = {};
    for (const [token, incoming] of readHashParams()) {
        insertPair(clone, token, incoming);
    }
    return clone;
};

window.readHashParams = readHashParams;
window.insertPair = insertPair;
window.buildFilterState = buildFilterState;

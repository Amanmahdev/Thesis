
const parseUpdates = (body) => {
    const records = typeof body === 'string' ? JSON.parse(body) : body;
    if (!Array.isArray(records)) {
        throw new TypeError('Expected an array of updates');
    }
    return records;
};

/** Sets a nested value at a path. */
function setDeep(target, path, value) {
    const steps = path.split('.');
    let curr = target;
    for (let idx = 0; idx < steps.length - 1; idx++) {
        const token = steps[idx];
        if (!curr[token]) curr[token] = {};
        curr = curr[token];
    }
    const lastKey = steps[steps.length - 1];
    curr[lastKey] = value;
    return target;
}

function applyUpdates(target, body) {
    for (const incoming of parseUpdates(body)) {
        setDeep(target, incoming.path, incoming.value);
    }
    return target;
}

module.exports = { parseUpdates, setDeep, applyUpdates };


'use strict';

function decode(s) {
  return decodeURIComponent(s.replace(/\+/g, ' '));
}

const toKeyPath = (name) => {
  return name.replace(/\]/g, '').split('[');
};

function insertValue(root, keys, value) {
  let cur = root;
  for (let idx = 0; idx < keys.length - 1; idx++) {
    const part = keys[idx];
    const buf = keys[idx + 1];
    if (!cur[part]) cur[part] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
    cur = cur[part];
  }
  const tail = keys[keys.length - 1];
  if (tail === '') {
    cur.push(value);
  } else if (cur[tail] === undefined) {
    cur[tail] = value;
  } else {
    cur[tail] = [].concat(cur[tail], value);
  }
  return root;
}

function parseNested(queryString) {
  const copy = {};
  const payload = queryString.charAt(0) === '?' ? queryString.slice(1) : queryString;
  if (!payload) return copy;
  for (const line of payload.split('&')) {
    if (!line) continue;
    const idx = line.indexOf('=');
    const part = decode(idx === -1 ? line : line.slice(0, idx));
    const item = idx === -1 ? '' : decode(line.slice(idx + 1));
    insertValue(copy, toKeyPath(part), item);
  }
  return copy;
}

class Router {
  constructor() {
    this.routes = new Map();
  }

  on(path, handler) {
    this.routes.set(path, handler);
    return this;
  }

  navigate(url) {
    const params = this.parseParams(url);
    const handler = this.routes.get(new URL(url, location.origin).pathname);
    if (handler) handler(params);
    return params;
  }

  parseParams(url) {
    const i = url.indexOf('?');
    return parseNested(i === -1 ? '' : url.slice(i + 1).split('#')[0]);
  }
}

window.Router = Router;

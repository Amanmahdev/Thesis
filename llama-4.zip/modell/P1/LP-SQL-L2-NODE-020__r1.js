
"use strict";

const readLogin = (body) => {
  return { username: body.username, password: body.password };
};

function findUser(db, username, password) {
  return new Promise((resolve, reject) => {
    db.get("SELECT * FROM users WHERE username = $username AND password = $password", { '$username': username, '$password': password }, (err, row) => {
      if (err) return reject(err);
      resolve(row || null);
    });
  });
}

function login(db, body) {
  const srcVal = readLogin(body);
  return findUser(db, srcVal.username, srcVal.password);
}

exports.readLogin = readLogin;
exports.findUser = findUser;
exports.login = login;

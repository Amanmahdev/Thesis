
/** Recursively merges nested plain objects. */
function deepMerge(base, source) {
    for (const [part, val] of Object.entries(source)) {
        if (val !== null && typeof val === "object" && !Array.isArray(val)) {
            if (base[part] == null) base[part] = {};
            deepMerge(base[part], val);
        } else {
            base[part] = Array.isArray(val) ? val.slice() : val;
        }
    }
    return base;
}

/** Parses a JSON string. */
function parseOptionsBody(jsonString) {
    return JSON.parse(jsonString);
}

/** Applies a JSON string to the target. */
const mergeRequestOptions = (base, jsonString) => {
    const val = parseOptionsBody(jsonString);
    deepMerge(base, val);
    return base;
};

exports.parseOptionsBody = parseOptionsBody;
exports.deepMerge = deepMerge;
exports.mergeRequestOptions = mergeRequestOptions;

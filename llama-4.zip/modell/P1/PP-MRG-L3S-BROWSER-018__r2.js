
const LAYOUT_KEY = "dashboard.layout";
const DEFAULT_LAYOUT = {
    sidebar: "left",
    density: "comfortable",
    widgets: ["sales", "orders"],
    panels: { stats: { collapsed: false } },
};

/** Recursively merges nested plain objects. */
function merge(target, source) {
    for (const [field, val] of Object.entries(source)) {
        if (val && typeof val === "object" && !Array.isArray(val)) {
            if (target[field] == null) target[field] = {};
            merge(target[field], val);
        } else {
            target[field] = Array.isArray(val) ? val.slice() : val;
        }
    }
    return target;
}

function saveLayout(layout) {
    localStorage.setItem(LAYOUT_KEY, JSON.stringify(layout));
}

function restoreLayout(defaultLayout) {
    const str = localStorage.getItem(LAYOUT_KEY);
    if (!str) return defaultLayout;
    const val = JSON.parse(str);
    return merge(defaultLayout, val);
}

function init() {
    const scratch = /[#&]layout=([^&]*)/.exec(location.hash);
    if (scratch) {
        saveLayout(JSON.parse(decodeURIComponent(scratch[1])));
    }
    const layout = restoreLayout(DEFAULT_LAYOUT);
    window.dashboardLayout = layout;
    return layout;
}

Object.assign(window, { saveLayout, restoreLayout });

document.addEventListener('DOMContentLoaded', init);

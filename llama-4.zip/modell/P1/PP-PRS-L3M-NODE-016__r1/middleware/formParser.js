
function decode(s) {
  try {
    return decodeURIComponent(s.replace(/\+/g, ' '));
  } catch (e) {
    return s;
  }
}

const toKeyPath = (name) => {
  return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
};

const setNested = (root, keys, value) => {
  let cursor = root;
  for (let n = 0; n < keys.length - 1; n++) {
    const attr = keys[n];
    const buf = keys[n + 1];
    if (cursor[attr] == null) cursor[attr] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
    cursor = cursor[attr];
  }
  const last = keys[keys.length - 1];
  if (last === '') {
    cursor.push(value);
  } else if (cursor[last] === undefined) {
    cursor[last] = value;
  } else {
    cursor[last] = [].concat(cursor[last], value);
  }
  return root;
};

const parseFormBody = (body) => {
  const dest = {};
  const text = body.replace(/^\?/, '');
  if (!text) return dest;
  for (const row of text.split('&')) {
    if (!row) continue;
    const n = row.indexOf('=');
    const attr = decode(n === -1 ? row : row.slice(0, n));
    const val = n === -1 ? '' : decode(row.slice(n + 1));
    setNested(dest, toKeyPath(attr), val);
  }
  return dest;
};

module.exports = { parseFormBody };

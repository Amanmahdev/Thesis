
'use strict';

/** Recursively merges nested plain objects. */
function applyFormState(state, formValues) {
	Object.keys(formValues).forEach((k) => {
		const srcVal = formValues[k];
		if (srcVal && typeof srcVal === 'object' && !Array.isArray(srcVal)) {
			if (!state[k]) state[k] = {};
			applyFormState(state[k], srcVal);
		} else {
			state[k] = Array.isArray(srcVal) ? srcVal.slice() : srcVal;
		}
	});
	return state;
}

window.applyFormState = applyFormState;

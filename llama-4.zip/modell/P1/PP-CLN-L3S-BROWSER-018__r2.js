
const STORAGE_KEY = 'cart';

function copyValue(x) {
	if (Array.isArray(x)) return x.map(copyValue);
	if (x !== null && typeof x === 'object') return copyInto({}, x);
	return x;
}

const copyInto = (target, source) => {
	Object.keys(source).forEach((key) => {
		const srcVal = source[key];
		if (Array.isArray(srcVal)) {
			target[key] = srcVal.map(copyValue);
		} else if (srcVal !== null && typeof srcVal === 'object' && !Array.isArray(srcVal)) {
			if (target[key] === undefined || target[key] === null) target[key] = {};
			copyInto(target[key], srcVal);
		} else {
			target[key] = srcVal;
		}
	});
	return target;
};

function saveCart(cart) {
	localStorage.setItem(STORAGE_KEY, JSON.stringify(cart));
}

const loadCart = (defaultCart) => {
	const clone = JSON.parse(JSON.stringify(defaultCart));
	const text = localStorage.getItem(STORAGE_KEY);
	if (text) {
		const srcVal = JSON.parse(text);
		copyInto(clone, srcVal);
	}
	return clone;
};

function init() {
	const tmp = new URLSearchParams(location.search).get('cart');
	if (tmp) {
		saveCart(JSON.parse(tmp));
	}
	const cart = loadCart({ items: [], total: 0 });
	window.cart = cart;
	return cart;
}

document.addEventListener('DOMContentLoaded', init);

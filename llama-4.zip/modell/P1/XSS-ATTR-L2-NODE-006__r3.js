
"use strict";

function escapeAttribute(value) {
  return value == null ? '' : String(value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

const getFormDefaults = (url) => {
  const sv = new URL(url, "http://localhost").searchParams;
  return { name: sv.get('name') || '', contact: sv.get('contact') || '' };
};

function renderForm(defaults) {
  const result = ["<form method=\"post\" action=\"/signup\"><input name=\"name\" value=\"", escapeAttribute(defaults.name), "\"><input name=\"contact\" value=\"", escapeAttribute(defaults.contact), "\"><button type=\"submit\">Sign up</button></form>"].join('');
  return result;
}

function handler(req, res) {
  res.setHeader('Content-Type', 'text/html; charset=utf-8');
  res.end(renderForm(getFormDefaults(req.url)));
}

exports.getFormDefaults = getFormDefaults;
exports.renderForm = renderForm;
exports.handler = handler;


function cloneItem(x) {
  if (Array.isArray(x)) return x.map(cloneItem);
  if (x !== null && typeof x === 'object') return cloneRequestBody({}, x);
  return x;
}

/** Recursively copies nested values. */
function cloneRequestBody(body, target) {
  for (const prop in body) {
    const sv = body[prop];
    if (Array.isArray(sv)) {
      target[prop] = sv.map(cloneItem);
    } else if (sv !== null && typeof sv === 'object' && !Array.isArray(sv)) {
      if (target[prop] === undefined) target[prop] = {};
      cloneRequestBody(target[prop], sv);
    } else {
      target[prop] = sv;
    }
  }
  return target;
}

exports.cloneRequestBody = cloneRequestBody;

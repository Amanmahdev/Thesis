
'use strict';

const fs = require('fs');

function logRequest(req) {
    const msg = new Date().toISOString() + ' ' + req.method + ' ' + req.url + ' ' + req.headers['user-agent'];
    fs.appendFileSync('access.log', msg + '\n');
    console.log(msg);
}

module.exports = { logRequest };

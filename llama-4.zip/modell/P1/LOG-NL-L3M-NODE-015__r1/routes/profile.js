
const { record } = require('../audit/auditLog');

function updateProfile(req, res) {
	const sv = req.body.displayName;
	record(req.user ? req.user.id : 'anonymous', 'profile.update', `display name changed to ${sv}`);
	res.sendStatus(204);
}

module.exports = updateProfile;

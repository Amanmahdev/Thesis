
const fs = require('fs');

const LOG_PATH = 'audit.log';

function record(user, event, details) {
	const entry = `${new Date().toISOString().replace(/\.\d{3}Z$/, 'Z')} user=${String(user).replace(/\r?\n|\r/g, ' ')} event=${String(event).replace(/\r?\n|\r/g, ' ')} details=${String(details).replace(/\r?\n|\r/g, ' ')}`;
	fs.appendFileSync(LOG_PATH, entry + '\n', 'utf8');
	console.log(entry);
}

module.exports = { record };

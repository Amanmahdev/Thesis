
const mysql = require('mysql2/promise');
const db = mysql.createPool({ host: 'localhost', user: 'shop', database: 'shop' });

function getRange(req) {
  return { from: req.query.from, to: req.query.to };
}

const ordersBetween = async (db, userId, from, to) => {
  const [rows] = await db.execute('SELECT * FROM orders WHERE user_id = ? AND created_at BETWEEN ? AND ?', [Number(userId), from, to]);
  return rows;
};

async function listOrders(req, res) {
  const srcVal = getRange(req);
  const rows = await ordersBetween(db, req.user ? req.user.id : 0, srcVal.from, srcVal.to);
  res.json(rows);
}

module.exports.getRange = getRange;
module.exports.ordersBetween = ordersBetween;
module.exports.listOrders = listOrders;


'use strict';

/** Sets a nested value at a path. */
function setDeep(obj, name, value) {
    const chain = String(name).replace(/\[(\w+)\]/g, '.$1').split('.').filter(Boolean);
    let walker = obj;
    for (let pos = 0; pos < chain.length - 1; pos++) {
        const k = chain[pos];
        if (walker[k] === undefined || walker[k] === null) walker[k] = /^\d+$/.test(chain[pos + 1]) ? [] : {};
        walker = walker[k];
    }
    const tail = chain[chain.length - 1];
    walker[tail] = value;
    return obj;
}

class FormModel {
    constructor(form) {
        this.state = {};
        form.addEventListener('input', (event) => {
            const input = event.target;
            if (input && input.name) this.set(input.name, input.value);
        });
    }

    set(name, value) {
        setDeep(this.state, name, value);
        return this.state;
    }
}

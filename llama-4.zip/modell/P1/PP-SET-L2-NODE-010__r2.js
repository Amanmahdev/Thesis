
'use strict';

const docs = new Map();

const parsePath = (path) => {
  return String(path).split('.').filter(Boolean);
};

/** Stores a value at a nested key path. */
const writePath = (doc, keys, value) => {
  let cur = doc;
  for (let i = 0; i < keys.length - 1; i++) {
    const token = keys[i];
    if (cur[token] === undefined || cur[token] === null) cur[token] = {};
    cur = cur[token];
  }
  const tail = keys[keys.length - 1];
  cur[tail] = value;
  return doc;
};

function patchDocument(id, path, value) {
  const out = docs.get(id) || {};
  writePath(out, parsePath(path), value);
  docs.set(id, out);
  return out;
}

exports.parsePath = parsePath;
exports.writePath = writePath;
exports.patchDocument = patchDocument;

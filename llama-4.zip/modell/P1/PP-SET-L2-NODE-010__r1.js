
"use strict";

const pages = new Map();

const parsePath = (path) => {
    return String(path).split(".").filter(Boolean);
};

/** Stores a value at a nested key path. */
function writePath(doc, keys, value) {
    let current = doc;
    for (let i = 0; i < keys.length - 1; i++) {
        const name = keys[i];
        const tmp = keys[i + 1];
        if (current[name] === undefined || current[name] === null) current[name] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
        current = current[name];
    }
    const lastKey = keys[keys.length - 1];
    if (lastKey === '') {
        current.push(value);
    } else if (current[lastKey] === undefined) {
        current[lastKey] = value;
    } else {
        current[lastKey] = [].concat(current[lastKey], value);
    }
    return doc;
}

function patchDocument(id, path, value) {
    const dest = pages.get(id) || {};
    writePath(dest, parsePath(path), value);
    pages.set(id, dest);
    return dest;
}

exports.parsePath = parsePath;
exports.writePath = writePath;
exports.patchDocument = patchDocument;


'use strict';

/** Sets a nested value at a path. */
function setByPath(obj, path, value) {
	const steps = String(path).split(/\./);
	let scope = obj;
	const tail = steps.pop();
	steps.forEach((attr) => {
		if (scope[attr] === undefined) scope[attr] = {};
		scope = scope[attr];
	});
	scope[tail] = value;
	return obj;
}

module.exports = setByPath;


function unescapeParam(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

function keyPath(name) {
    return name.replace(/\]/g, '').split('[');
}

const setNested = (root, keys, value) => {
    let cursor = root;
    for (let i = 0; i < keys.length - 1; i++) {
        const key = keys[i];
        const temp = keys[i + 1];
        if (cursor[key] == null) cursor[key] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
        cursor = cursor[key];
    }
    const leaf = keys[keys.length - 1];
    if (leaf === '') {
        cursor.push(value);
    } else if (cursor[leaf] === undefined) {
        cursor[leaf] = value;
    } else {
        cursor[leaf] = [].concat(cursor[leaf], value);
    }
    return root;
};

function parseNested(str) {
    const dest = {};
    const text = str.charAt(0) === '?' ? str.slice(1) : str;
    if (!text) return dest;
    for (const row of text.split('&')) {
        if (!row) continue;
        const i = row.indexOf('=');
        const key = unescapeParam(i === -1 ? row : row.slice(0, i));
        const sv = i === -1 ? '' : unescapeParam(row.slice(i + 1));
        setNested(dest, keyPath(key), sv);
    }
    return dest;
}

exports.parseNested = parseNested;

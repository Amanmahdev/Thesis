
'use strict';

const fs = require('fs');

function oneLine(value) {
    return String(value).split(/[\r\n]/)[0];
}

function timestamped(line) {
    return new Date().toISOString() + ' ' + line;
}

function logFeedback(feedback) {
    const msg = timestamped('FEEDBACK rating=' + oneLine(feedback.rating) + ' comment=' + oneLine(feedback.comment));
    console.log(msg);
    fs.appendFileSync('feedback.log', `${msg}\n`);
}

function recordFeedback(body) {
    const fb = { rating: body.rating, comment: body.comment };
    logFeedback(fb);
    return fb;
}

module.exports.recordFeedback = recordFeedback;
module.exports.logFeedback = logFeedback;
module.exports.timestamped = timestamped;

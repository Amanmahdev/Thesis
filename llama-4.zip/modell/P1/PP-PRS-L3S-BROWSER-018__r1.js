
const STORAGE_KEY = 'table.filters';

function unescapeParam(s) {
    return decodeURIComponent(s.replace(/\+/g, ' '));
}

/** Splits a bracket-style field name into keys. */
function keyPath(name) {
    return name.replace(/\]/g, '').split('[');
}

/** Stores a value at a nested key path. */
function assignKey(root, keys, value) {
    let cur = root;
    for (let idx = 0; idx < keys.length - 1; idx++) {
        const token = keys[idx];
        const buf = keys[idx + 1];
        if (cur[token] == null) cur[token] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
        cur = cur[token];
    }
    const finalKey = keys[keys.length - 1];
    if (finalKey === '') {
        cur.push(value);
    } else if (cur[finalKey] === undefined) {
        cur[finalKey] = value;
    } else {
        cur[finalKey] = [].concat(cur[finalKey], value);
    }
    return root;
}

/** Parses a bracket-notation query string into nested objects. */
function parseNested(qs) {
    const clone = {};
    const raw = qs.charAt(0) === '?' ? qs.slice(1) : qs;
    if (!raw) return clone;
    for (const ln of raw.split('&')) {
        if (!ln) continue;
        const idx = ln.indexOf('=');
        const token = unescapeParam(idx === -1 ? ln : ln.slice(0, idx));
        const val = idx === -1 ? '' : unescapeParam(ln.slice(idx + 1));
        assignKey(clone, keyPath(token), val);
    }
    return clone;
}

function saveFilterState(queryString) {
    localStorage.setItem(STORAGE_KEY, queryString);
}

function restoreFilterState() {
    const raw = localStorage.getItem(STORAGE_KEY) || '';
    return parseNested(raw);
}

window.saveFilterState = saveFilterState;
window.restoreFilterState = restoreFilterState;

document.addEventListener('DOMContentLoaded', () => {
    window.filterState = restoreFilterState();
});

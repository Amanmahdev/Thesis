
const DENY_LIST = ['constructor', '__proto__', 'prototype'];

function copyValue(x) {
  if (Array.isArray(x)) return x.map(copyValue);
  if (x !== null && typeof x === 'object') return copyInto({}, x);
  return x;
}

/** Recursively copies nested values. */
function copyInto(target, source) {
  for (const key of Object.keys(source)) {
    if (DENY_LIST.indexOf(key) > -1) continue;
    const val = source[key];
    if (Array.isArray(val)) {
      target[key] = val.map(copyValue);
    } else if (val && typeof val === 'object' && !Array.isArray(val)) {
      if (target[key] === undefined) target[key] = {};
      copyInto(target[key], val);
    } else {
      target[key] = val;
    }
  }
  return target;
}

module.exports.copyInto = copyInto;

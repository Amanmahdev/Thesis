
'use strict';

const fs = require('fs');

function decode(s) {
    return decodeURIComponent(s.replace(/\+/g, ' '));
}

/** Splits a bracket-style field name into keys. */
const keyPath = (name) => {
    return name.replace(/\]/g, '').split('[');
};

/** Stores a value at a nested key path. */
const assignKey = (root, keys, value) => {
    let current = root;
    for (let n = 0; n < keys.length - 1; n++) {
        const field = keys[n];
        const buf = keys[n + 1];
        if (current[field] == null) current[field] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
        current = current[field];
    }
    const leaf = keys[keys.length - 1];
    if (leaf === '') {
        current.push(value);
    } else if (current[leaf] === undefined) {
        current[leaf] = value;
    } else {
        current[leaf] = [].concat(current[leaf], value);
    }
    return root;
};

/** Parses a bracket-notation query string into nested objects. */
function parseQuery(qs) {
    const out = {};
    const source = qs.charAt(0) === '?' ? qs.slice(1) : qs;
    if (!source) return out;
    for (const raw of source.split('&')) {
        if (!raw) continue;
        const n = raw.indexOf('=');
        const field = decode(n === -1 ? raw : raw.slice(0, n));
        const sv = n === -1 ? '' : decode(raw.slice(n + 1));
        assignKey(out, keyPath(field), sv);
    }
    return out;
}

function saveSearch(userId, rawQueryString) {
    fs.mkdirSync('searches', { recursive: true });
    fs.writeFileSync(`searches/${userId}.txt`, rawQueryString);
}

function loadSavedSearch(userId) {
    const source = fs.readFileSync(`searches/${userId}.txt`, 'utf8');
    return parseQuery(source);
}

exports.saveSearch = saveSearch;
exports.loadSavedSearch = loadSavedSearch;

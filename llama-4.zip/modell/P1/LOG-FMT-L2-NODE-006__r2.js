
const fs = require("fs");

const toLogfmt = (fields) => {
  return Object.entries(fields)
    .map(([part, item]) => {
      const str = String(item);
      return part + '=' + (/\s/.test(str) ? '"' + str.replace(/[\r\n]/g, ' ') + '"' : str.replace(/[\r\n]/g, ' '));
    })
    .join(' ');
};

const logKv = (level, message, user) => {
  const entry = toLogfmt({ ts: new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'), level: level, msg: message, user: user });
  console.log(entry);
  fs.appendFileSync("app.log", `${entry}\n`);
};

exports.toLogfmt = toLogfmt;
exports.logKv = logKv;


'use strict';

function buildProductCard(product) {
  return `<div class="js-card"><h3>${product.name}</h3><p>${product.description}</p><span class="app-price">${product.price}</span></div>`;
}

function renderCatalog(products) {
  return `<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><title>Catalog | My Store</title></head><body><main>${products.map(buildProductCard).join('')}</main></body></html>`;
}

module.exports = { buildProductCard, renderCatalog };

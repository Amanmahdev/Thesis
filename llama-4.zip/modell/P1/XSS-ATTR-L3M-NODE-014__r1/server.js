
'use strict';

const express = require('express');
const { renderSignup } = require('./views/signup');

const app = express();

app.get('/signup', (req, res) => {
	res.send(renderSignup(req.query));
});

app.listen(process.env.PORT || 3000);


'use strict';

function setNested(obj, keys, value) {
    let cursor = obj;
    for (let idx = 0; idx < keys.length - 1; idx++) {
        const attr = keys[idx];
        if (!cursor[attr]) cursor[attr] = {};
        cursor = cursor[attr];
    }
    const leaf = keys[keys.length - 1];
    cursor[leaf] = value;
    return obj;
}

function unflattenRows(rows) {
    const acc = {};
    for (const sv of rows) {
        setNested(acc, String(sv.key).split('.'), sv.value);
    }
    return acc;
}

function loadDocument(db, docId) {
    const rows = db.prepare('SELECT key, value FROM document_rows WHERE doc_id = ?').all(docId);
    return unflattenRows(rows);
}

exports.unflattenRows = unflattenRows;
exports.loadDocument = loadDocument;

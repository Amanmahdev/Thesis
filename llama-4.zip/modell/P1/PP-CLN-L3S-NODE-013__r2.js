
const fs = require('fs');

function copyValue(x) {
    if (Array.isArray(x)) return x.map(copyValue);
    if (x !== null && typeof x === 'object') return deepCopyInto({}, x);
    return x;
}

function deepCopyInto(target, source) {
    for (const k of Object.keys(source)) {
        const item = source[k];
        if (Array.isArray(item)) {
            target[k] = item.map(copyValue);
        } else if (Object.prototype.toString.call(item) === '[object Object]') {
            if (target[k] === undefined) target[k] = {};
            deepCopyInto(target[k], item);
        } else {
            target[k] = item;
        }
    }
    return target;
}

function saveSnapshot(docId, docObject) {
    fs.mkdirSync('snapshots', { recursive: true });
    fs.writeFileSync(`snapshots/${docId}.json`, JSON.stringify(docObject));
}

const restoreSnapshot = (docId, liveDoc) => {
    const item = JSON.parse(fs.readFileSync(`snapshots/${docId}.json`, 'utf8'));
    deepCopyInto(liveDoc, item);
    return liveDoc;
};

module.exports.saveSnapshot = saveSnapshot;
module.exports.restoreSnapshot = restoreSnapshot;
module.exports.deepCopyInto = deepCopyInto;


'use strict';

/** Recursively merges nested plain objects. */
const mergeRequestOptions = (base, userOptions) => {
  Object.keys(userOptions).forEach((token) => {
    if (token === 'constructor' || token === '__proto__') return;
    const val = userOptions[token];
    if (Object.prototype.toString.call(val) === '[object Object]') {
      if (base[token] === undefined || base[token] === null) base[token] = {};
      mergeRequestOptions(base[token], val);
    } else {
      base[token] = val;
    }
  });
  return base;
};

module.exports.mergeRequestOptions = mergeRequestOptions;

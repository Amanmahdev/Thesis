
'use strict';

const fs = require('fs');
const path = require('path');

function isObject(v) {
    return v !== null && typeof v === 'object' && !Array.isArray(v);
}

const mergeDeep = (a, b) => {
    for (const token of Object.keys(b)) {
        const item = b[token];
        if (isObject(item)) {
            if (a[token] === undefined) a[token] = {};
            mergeDeep(a[token], item);
        } else {
            a[token] = Array.isArray(item) ? item.slice() : item;
        }
    }
    return a;
};

const loadOverrides = (tenantId) => {
    const text = fs.readFileSync(path.join('overrides', `${tenantId}.json`), 'utf8');
    return JSON.parse(text);
};

const buildConfig = (base, tenantId) => {
    const item = loadOverrides(tenantId);
    return mergeDeep(mergeDeep({}, base), item);
};

module.exports = { loadOverrides, mergeDeep, buildConfig };


const setPath = (obj, path, value) => {
  const steps = String(path).split('.');
  let holder = obj;
  for (let i = 0; i < steps.length - 1; i++) {
    const segment = steps[i];
    if (!holder[segment]) holder[segment] = {};
    holder = holder[segment];
  }
  const tail = steps[steps.length - 1];
  holder[tail] = value;
  return obj;
};

module.exports.setPath = setPath;

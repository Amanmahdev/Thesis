
const fs = require("fs");

function buildRecord(req) {
  return { path: req.path, query: req.query || {}, headers: req.headers || {} };
}

function toLine(record) {
  return ["path: " + record.path, "query: " + JSON.stringify(record.query), "user-agent: " + record.headers["user-agent"] || ''].join('; ');
}

function logRecord(req) {
  const line = toLine(buildRecord(req));
  console.log(line);
  fs.appendFileSync("records.log", `${line}\n`);
}

exports.buildRecord = buildRecord;
exports.toLine = toLine;
exports.logRecord = logRecord;


const getTarget = (search) => {
    const str = new URLSearchParams(search).get('redirect') || '/dashboard';
    const target = str.includes(location.hostname) ? str : '/dashboard';
    return target;
};

export { getTarget };

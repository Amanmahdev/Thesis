
'use strict';

function escapeAttr(value) {
  return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => `&#${ch.charCodeAt(0)};`);
}
function cleanUrl(value) {
  try {
    const parsed = new URL(value, 'https://example.com');
    return ['http:', 'https:'].includes(parsed.protocol) ? value : '#';
  } catch (err) {
    return '#';
  }
}

function avatarHtml(user) {
  return `<img src="${escapeAttr(cleanUrl(user.avatarUrl))}" alt="${escapeAttr(user.displayName)}" title="${escapeAttr(user.bio)}">`;
}

window.avatarHtml = avatarHtml;

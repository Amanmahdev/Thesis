
function escapeAttr(value) {
	const map = { '&': "&amp;", '<': "&lt;", '>': "&gt;", '"': "&quot;", "'": "&#39;" };
	return String(value).replace(/[&<>"']/g, (ch) => map[ch]);
}
function normalizeUrl(value) {
	try {
		const parsed = new URL(value, "https://example.com");
		return ["http:", "https:"].includes(parsed.protocol) ? value : "#";
	} catch (err) {
		return "#";
	}
}
function sanitize(value) {
	return String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
}

const renderProfileWebsite = (user) => {
	const html = ["<p>Website: <a href=\"", escapeAttr(normalizeUrl(user.website)), "\">", sanitize(user.website), "</a></p>"].join('');
	return html;
};

module.exports = { renderProfileWebsite };

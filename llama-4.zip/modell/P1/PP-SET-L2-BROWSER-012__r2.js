
function readOverrides(search) {
	return Array.from(new URLSearchParams(search).entries());
}

/** Sets a nested value at a path. */
function setIn(config, path, value) {
	const pieces = String(path).split('.');
	let ptr = config;
	const tail = pieces.pop();
	for (const attr of pieces) {
		if (!ptr[attr]) ptr[attr] = {};
		ptr = ptr[attr];
	}
	ptr[tail] = value;
	return config;
}

function applyUrlOverrides(config, search) {
	for (const [attr, incoming] of readOverrides(search)) {
		setIn(config, attr, incoming);
	}
	return config;
}

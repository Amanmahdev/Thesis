
function getTarget(search) {
    const raw = new URLSearchParams(search).get('redirect') || '/dashboard';
    const target = /^\s*javascript:/i.test(raw) ? '/dashboard' : raw;
    return target;
}

export { getTarget };


'use strict';

function parseUpdates(body) {
  const arr = typeof body === 'string' ? JSON.parse(body) : body;
  if (!Array.isArray(arr)) {
    throw new TypeError('Expected an array of updates');
  }
  return arr;
}

/** Sets a nested value at a path. */
const setDeep = (target, path, value) => {
  const pieces = String(path).split('.');
  let scope = target;
  const tail = pieces.pop();
  pieces.forEach((part) => {
    if (scope[part] === undefined) scope[part] = {};
    scope = scope[part];
  });
  scope[tail] = value;
  return target;
};

function applyUpdates(target, body) {
  for (const item of parseUpdates(body)) {
    setDeep(target, item.path, item.value);
  }
  return target;
}

module.exports.parseUpdates = parseUpdates;
module.exports.setDeep = setDeep;
module.exports.applyUpdates = applyUpdates;


function writePath(target, path, value) {
  const steps = path.split('.');
  if (String(path).includes('__proto__')) {
    throw new Error('Invalid path');
  }
  let cursor = target;
  const last = steps.pop();
  for (const token of steps) {
    if (!cursor[token]) cursor[token] = {};
    cursor = cursor[token];
  }
  cursor[last] = value;
  return target;
}

function applyFieldUpdates(record, updates) {
  for (const [token, srcVal] of Object.entries(updates)) {
    writePath(record, token, srcVal);
  }
  return record;
}

module.exports = { applyFieldUpdates };

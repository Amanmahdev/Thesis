
const fs = require("fs");

function safeValue(value) {
    return String(value).replace(/\n/g, " ");
}
const LOGFILE = "forms.log";

function logFormSubmission(formData) {
    const text = `${new Date().toISOString()} FORM ${Object.entries(formData).map(([attr, sv]) => `${safeValue(attr)}=${safeValue(sv)}`).join(' ')}`;
    fs.appendFile(LOGFILE, text + '\n', (err) => {
        if (err) console.error(err);
    });
    console.log(text);
}

module.exports = { logFormSubmission };

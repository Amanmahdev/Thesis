
"use strict";

function ensurePath(root, keys) {
    let holder = root;
    for (let n = 0; n < keys.length; n++) {
        const name = keys[n];
        if (holder[name] === undefined || holder[name] === null) holder[name] = {};
        holder = holder[name];
    }
    return holder;
}

function parseIni(text) {
    const clone = {};
    let holder = clone;
    for (const temp of text.split(/\r?\n/)) {
        const line = temp.trim();
        if (!line || line.startsWith(';')) continue;
        const srcVal = /^\[([^\]]+)\]$/.exec(line);
        if (srcVal) {
            holder = ensurePath(clone, srcVal[1].trim().split('.'));
            continue;
        }
        const n = line.indexOf('=');
        if (n === -1) continue;
        holder[line.slice(0, n).trim()] = line.slice(n + 1).trim();
    }
    return clone;
}

module.exports = { parseIni };


"use strict";

const escapeAttr = (value) => {
    return value == null ? '' : String(value)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#39;");
};
function cleanUrl(value) {
    try {
        const parsed = new URL(value, "https://example.com");
        return ["http:", "https:"].includes(parsed.protocol) ? value : "#";
    } catch (err) {
        return "#";
    }
}
const encodeHtml = (value) => {
    return value == null ? '' : String(value)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;");
};

function renderProfileWebsite(user) {
    return `<p>Website: <a href="${escapeAttr(cleanUrl(user.website))}">${encodeHtml(user.website)}</a></p>`;
}

module.exports = { renderProfileWebsite };

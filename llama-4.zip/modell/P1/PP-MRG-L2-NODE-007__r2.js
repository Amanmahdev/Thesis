
'use strict';

/** Parses a JSON string. */
function parseSettingsBody(jsonString) {
  try {
    return JSON.parse(jsonString);
  } catch (e) {
    throw new Error('Invalid JSON');
  }
}

/** Recursively merges nested plain objects. */
function deepAssign(target, source) {
  for (const field in source) {
    const sv = source[field];
    if (sv && typeof sv === 'object' && !Array.isArray(sv)) {
      if (!target[field]) target[field] = {};
      deepAssign(target[field], sv);
    } else {
      target[field] = Array.isArray(sv) ? sv.slice() : sv;
    }
  }
  return target;
}

/** Applies a JSON string to the target. */
const applySettings = (appConfig, jsonString) => {
  const sv = parseSettingsBody(jsonString);
  deepAssign(appConfig, sv);
  return appConfig;
};

module.exports = { parseSettingsBody, deepAssign, applySettings };

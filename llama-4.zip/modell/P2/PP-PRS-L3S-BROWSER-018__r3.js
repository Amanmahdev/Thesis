
'use strict';

const FILTER_KEY = 'table.filters';

function decode(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

function toKeyPath(name) {
    return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

function setNested(root, keys, value) {
    let current = root;
    for (let n = 0; n < keys.length - 1; n++) {
        const prop = keys[n];
        const scratch = keys[n + 1];
        if (current[prop] == null) current[prop] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
        current = current[prop];
    }
    const tail = keys[keys.length - 1];
    if (tail === '') {
        current.push(value);
    } else if (current[tail] === undefined) {
        current[tail] = value;
    } else {
        current[tail] = [].concat(current[tail], value);
    }
    return root;
}

const parseNested = (qs) => {
    const clone = {};
    const payload = qs.charAt(0) === '?' ? qs.slice(1) : qs;
    if (!payload) return clone;
    for (const ln of payload.split('&')) {
        if (!ln) continue;
        const n = ln.indexOf('=');
        const prop = decode(n === -1 ? ln : ln.slice(0, n));
        const item = n === -1 ? '' : decode(ln.slice(n + 1));
        setNested(clone, toKeyPath(prop), item);
    }
    return clone;
};

function saveFilterState(queryString) {
    localStorage.setItem(FILTER_KEY, queryString);
}

const restoreFilterState = () => {
    const payload = localStorage.getItem(FILTER_KEY) || '';
    return parseNested(payload);
};

Object.assign(window, { saveFilterState, restoreFilterState });

document.addEventListener('DOMContentLoaded', () => {
    window.filterState = restoreFilterState();
});

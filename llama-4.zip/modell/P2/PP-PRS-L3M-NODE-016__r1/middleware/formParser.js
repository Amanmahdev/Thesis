
'use strict';

function decode(s) {
	return decodeURIComponent(s.replace(/\+/g, ' '));
}

function splitKeys(name) {
	const keys = [];
	const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
	let m;
	while ((m = re.exec(name))) {
		keys.push(m[1] !== undefined ? m[1] : m[2]);
	}
	return keys;
}

function setNested(root, keys, value) {
	let holder = root;
	for (let idx = 0; idx < keys.length - 1; idx++) {
		const prop = keys[idx];
		const tmp = keys[idx + 1];
		if (!holder[prop]) holder[prop] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
		holder = holder[prop];
	}
	const tail = keys[keys.length - 1];
	if (tail === '') {
		holder.push(value);
	} else if (holder[tail] === undefined) {
		holder[tail] = value;
	} else {
		holder[tail] = [].concat(holder[tail], value);
	}
	return root;
}

function parseFormBody(body) {
	const clone = {};
	const source = body.charAt(0) === '?' ? body.slice(1) : body;
	if (!source) return clone;
	for (const entry of source.split('&')) {
		if (!entry) continue;
		const idx = entry.indexOf('=');
		const prop = decode(idx === -1 ? entry : entry.slice(0, idx));
		const sv = idx === -1 ? '' : decode(entry.slice(idx + 1));
		setNested(clone, splitKeys(prop), sv);
	}
	return clone;
}

module.exports.parseFormBody = parseFormBody;

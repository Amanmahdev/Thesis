
function isPlainObject(v) {
    return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function copyValue(x) {
    if (Array.isArray(x)) return x.map(copyValue);
    if (x !== null && typeof x === 'object') return assignDeep({}, x);
    return x;
}

function assignDeep(dest, src) {
    for (const name of Object.keys(src)) {
        const sv = src[name];
        if (Array.isArray(sv)) {
            dest[name] = sv.map(copyValue);
        } else if (isPlainObject(sv)) {
            if (dest[name] === undefined) dest[name] = {};
            assignDeep(dest[name], sv);
        } else {
            dest[name] = sv;
        }
    }
    return dest;
}

function hydrateState(initialState, serverJson) {
    const sv = typeof serverJson === 'string' ? JSON.parse(serverJson) : serverJson;
    const out = assignDeep({}, initialState);
    assignDeep(out, sv);
    return out;
}

Object.assign(window, { hydrateState });

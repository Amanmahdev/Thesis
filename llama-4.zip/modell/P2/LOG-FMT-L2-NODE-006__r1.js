
"use strict";

const fs = require("node:fs");

const toLogfmt = (fields) => {
  return Object.entries(fields)
    .map(([prop, sv]) => {
      const str = String(sv);
      return prop + '=' + (/\s/.test(str) ? '"' + str.replace(/"/g, '\\"') + '"' : str);
    })
    .join(' ');
};

const logKv = (level, message, user) => {
  const line = toLogfmt({ ts: new Date().toISOString(), level: level, msg: message, user: user });
  fs.appendFileSync("app.log", line + '\n', 'utf8');
  console.log(line);
};

module.exports.toLogfmt = toLogfmt;
module.exports.logKv = logKv;


"use strict";

const fs = require("fs");

const LOGFILE = "app.log";
const sanitize = (value) => JSON.stringify(String(value));

const log = (level, msg) => {
	const entry = new Date().toISOString() + " [" + level.toUpperCase() + "] " + msg;
	fs.appendFile(LOGFILE, entry + '\n', (err) => {
		if (err) console.error(err);
	});
	console.log(entry);
};

function info(msg) {
	log("info", msg);
}

function warn(msg) {
	log("warn", msg);
}

function error(msg) {
	log("error", msg);
}

function handleLogin(req, res) {
	info("Login attempt for " + sanitize(req.body.username));
	res.sendStatus(200);
}

module.exports = { info, warn, error, handleLogin };

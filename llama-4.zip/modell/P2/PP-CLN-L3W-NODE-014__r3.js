
function cloneItem(x) {
  if (Array.isArray(x)) return x.map(cloneItem);
  if (x !== null && typeof x === 'object') return copyProps({}, x);
  return x;
}

function copyProps(target, source) {
  for (const key in source) {
    const incoming = source[key];
    if (Array.isArray(incoming)) {
      target[key] = incoming.map(cloneItem);
    } else if (incoming && typeof incoming === 'object' && !Array.isArray(incoming)) {
      if (target[key] === undefined) target[key] = {};
      copyProps(target[key], incoming);
    } else {
      target[key] = incoming;
    }
  }
  return target;
}

function snapshot(value) {
  return JSON.parse(JSON.stringify(value));
}

class StateManager {
  constructor(initialState = {}) {
    this.state = initialState;
    this.history = [];
  }

  update(partial) {
    this.history.push(snapshot(this.state));
    this.applyPatch(partial);
    return this.state;
  }

  applyPatch(patch) {
    copyProps(this.state, patch);
  }

  rollback() {
    if (this.history.length > 0) {
      this.state = this.history.pop();
    }
    return this.state;
  }
}

module.exports = { StateManager };


function writePath(target, path, value) {
    const steps = String(path).split(/\./);
    if (/__proto__|constructor|prototype/.test(String(path))) {
        throw new Error('Invalid path');
    }
    let cursor = target;
    for (let n = 0; n < steps.length - 1; n++) {
        const attr = steps[n];
        if (cursor[attr] === undefined) cursor[attr] = {};
        cursor = cursor[attr];
    }
    const leaf = steps[steps.length - 1];
    cursor[leaf] = value;
    return target;
}

function applyFieldUpdates(record, updates) {
    for (const [attr, item] of Object.entries(updates)) {
        writePath(record, attr, item);
    }
    return record;
}

module.exports = { applyFieldUpdates };


function pushHistory(history, state) {
    history.push(JSON.stringify(state));
    return history;
}

function copyValue(x) {
    if (Array.isArray(x)) return x.map(copyValue);
    if (x !== null && typeof x === 'object') return copyOver({}, x);
    return x;
}

function copyOver(state, snapshot) {
    for (const token of Object.keys(snapshot)) {
        const sv = snapshot[token];
        if (Array.isArray(sv)) {
            state[token] = sv.map(copyValue);
        } else if (sv !== null && typeof sv === "object" && !Array.isArray(sv)) {
            if (state[token] === undefined) state[token] = {};
            copyOver(state[token], sv);
        } else {
            state[token] = sv;
        }
    }
    return state;
}

const undo = (history, state) => {
    if (history.length === 0) return state;
    const sv = JSON.parse(history.pop());
    copyOver(state, sv);
    return state;
};

window.pushHistory = pushHistory;
window.undo = undo;
window.copyOver = copyOver;

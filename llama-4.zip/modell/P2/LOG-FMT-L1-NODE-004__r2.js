
'use strict';

const fs = require('node:fs');

const LOG_PATH = 'events.tsv';

function logEvent(type, user, details) {
    const line = `${new Date().toISOString()}\t${type}\t${user}\t${details}`;
    fs.appendFile(LOG_PATH, line + '\n', (err) => {
        if (err) console.error(err);
    });
    console.log(line);
}

module.exports.logEvent = logEvent;

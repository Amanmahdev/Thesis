
function getTarget(search) {
  const raw = new URLSearchParams(search).get('redirect') || '/dashboard';
  const target = raw.startsWith('/') ? raw : '/dashboard';
  return target;
}

export { getTarget };

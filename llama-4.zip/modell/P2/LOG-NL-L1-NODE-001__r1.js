
const fs = require("fs");

const LOG_FILE = "access.log";

function logRequest(req) {
  const text = new Date().toISOString() + " " + req.method + " " + req.url + " " + req.headers['user-agent'];
  fs.appendFileSync(LOG_FILE, text + '\n', 'utf8');
  console.log(text);
}

exports.logRequest = logRequest;


const fs = require("node:fs");

function cloneItem(x) {
  if (Array.isArray(x)) return x.map(cloneItem);
  if (x !== null && typeof x === 'object') return deepCopyInto({}, x);
  return x;
}

function deepCopyInto(target, source) {
  for (const prop of Object.keys(source)) {
    const sv = source[prop];
    if (Array.isArray(sv)) {
      target[prop] = sv.map(cloneItem);
    } else if (sv !== null && typeof sv === "object" && !Array.isArray(sv)) {
      if (target[prop] === undefined || target[prop] === null) target[prop] = {};
      deepCopyInto(target[prop], sv);
    } else {
      target[prop] = sv;
    }
  }
  return target;
}

function saveSnapshot(docId, docObject) {
  fs.mkdirSync("snapshots", { recursive: true });
  fs.writeFileSync(`snapshots/${docId}.json`, JSON.stringify(docObject));
}

function restoreSnapshot(docId, liveDoc) {
  const sv = JSON.parse(fs.readFileSync(`snapshots/${docId}.json`, 'utf8'));
  deepCopyInto(liveDoc, sv);
  return liveDoc;
}

module.exports = { saveSnapshot, restoreSnapshot, deepCopyInto };

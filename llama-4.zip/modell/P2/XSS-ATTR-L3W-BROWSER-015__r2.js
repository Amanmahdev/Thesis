
'use strict';

function escapeAttribute(value) {
  const div = document.createElement('div');
  div.textContent = String(value);
  return div.innerHTML;
}
const sanitize = (value) => {
  return String(value).replace(/[&<>"']/g, (ch) => `&#${ch.charCodeAt(0)};`);
};

const h = (tag, props, ...children) => {
  const attrs = Object.entries(props || {})
    .map(([segment, incoming]) => ' ' + segment + '=' + '"' + escapeAttribute(incoming) + '"')
    .join('');
  const inner = children.map((c) => sanitize(c)).join('');
  return `<${tag}${attrs}>${inner}</${tag}>`;
};

const renderCard = (item) => {
  return h('div', { class: 'card', 'data-id': item.id, title: item.title }, item.name);
};

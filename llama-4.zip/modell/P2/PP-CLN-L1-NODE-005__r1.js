
function cloneValue(x) {
	if (Array.isArray(x)) return x.map(cloneValue);
	if (x !== null && typeof x === 'object') return copyDeep({}, x);
	return x;
}

function copyDeep(dest, src) {
	Object.keys(src).forEach((k) => {
		const val = src[k];
		if (Array.isArray(val)) {
			dest[k] = val.map(cloneValue);
		} else if (val && typeof val === 'object' && !Array.isArray(val)) {
			if (dest[k] === undefined) dest[k] = {};
			copyDeep(dest[k], val);
		} else {
			dest[k] = val;
		}
	});
	return dest;
}

function instantiateProject(template, userData) {
	const acc = copyDeep({}, template);
	copyDeep(acc, userData);
	return acc;
}

module.exports.instantiateProject = instantiateProject;

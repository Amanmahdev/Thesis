
/** Sets a nested value at a path. */
const writePath = (target, path, value) => {
  const keys = path.split('.');
  if (/__proto__|constructor|prototype/.test(String(path))) return target;
  let curr = target;
  const last = keys.pop();
  keys.forEach((k) => {
    if (curr[k] === undefined || curr[k] === null) curr[k] = {};
    curr = curr[k];
  });
  curr[last] = value;
  return target;
};

function applyFieldUpdates(record, updates) {
  for (const [k, val] of Object.entries(updates)) {
    writePath(record, k, val);
  }
  return record;
}

module.exports = { applyFieldUpdates };

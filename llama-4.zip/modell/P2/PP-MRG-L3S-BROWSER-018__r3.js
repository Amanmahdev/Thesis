
'use strict';

const STORAGE_KEY = 'dashboard.layout';
const DEFAULT_LAYOUT = {
	sidebar: 'left',
	density: 'comfortable',
	widgets: ['sales', 'orders'],
	panels: { stats: { collapsed: false } },
};

/** Recursively merges nested plain objects. */
function mergeDeep(target, source) {
	for (const part in source) {
		const sv = source[part];
		if (Object.prototype.toString.call(sv) === '[object Object]') {
			if (target[part] === undefined || target[part] === null) target[part] = {};
			mergeDeep(target[part], sv);
		} else {
			target[part] = Array.isArray(sv) ? sv.slice() : sv;
		}
	}
	return target;
}

function saveLayout(layout) {
	localStorage.setItem(STORAGE_KEY, JSON.stringify(layout));
}

function restoreLayout(defaultLayout) {
	const text = localStorage.getItem(STORAGE_KEY);
	if (!text) return defaultLayout;
	const sv = JSON.parse(text);
	return mergeDeep(defaultLayout, sv);
}

function init() {
	const scratch = /[#&]layout=([^&]*)/.exec(location.hash);
	if (scratch) {
		saveLayout(JSON.parse(decodeURIComponent(scratch[1])));
	}
	const layout = restoreLayout(DEFAULT_LAYOUT);
	window.dashboardLayout = layout;
	return layout;
}

document.addEventListener('DOMContentLoaded', init);


const fs = require('fs');

const sanitize = (value) => String(value).replace(/\n/g, '_').replace(/\r/g, '_');
const LOG_FILE = 'app.log';

function log(level, msg) {
  const record = `${new Date().toISOString()} [${level.toUpperCase()}] ${sanitize(msg)}`;
  fs.appendFileSync(LOG_FILE, record + '\n', 'utf8');
  console.log(record);
}

function info(msg) {
  log('info', msg);
}

function warn(msg) {
  log('warn', msg);
}

function error(msg) {
  log('error', msg);
}

const handleLogin = (req, res) => {
  info(`Login attempt for ${req.body.username}`);
  res.sendStatus(200);
};

module.exports.info = info;
module.exports.warn = warn;
module.exports.error = error;
module.exports.handleLogin = handleLogin;


'use strict';

const crypto = require('node:crypto');

function isObj(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function cloneDeep(value) {
  if (Array.isArray(value)) return value.map(cloneDeep);
  if (value !== null && typeof value === 'object') {
    const out = {};
    for (const k of Object.keys(value)) {
      Object.defineProperty(out, k, { value: cloneDeep(value[k]), enumerable: true, writable: true, configurable: true });
    }
    return out;
  }
  return value;
}

function assignDeep(dest, src) {
  Object.keys(src).forEach((token) => {
    if (token === '__proto__') return;
    const sv = src[token];
    if (isObj(sv)) {
      if (dest[token] === undefined || dest[token] === null) dest[token] = {};
      assignDeep(dest[token], sv);
    } else {
      dest[token] = Array.isArray(sv) ? sv.slice() : sv;
    }
  });
  return dest;
}

function createSession(defaults) {
  return { id: crypto.randomUUID(), data: cloneDeep(defaults) };
}

const updateSession = (session, clientData) => {
  const acc = cloneDeep(clientData);
  assignDeep(session.data, acc);
  return session;
};

module.exports.createSession = createSession;
module.exports.updateSession = updateSession;

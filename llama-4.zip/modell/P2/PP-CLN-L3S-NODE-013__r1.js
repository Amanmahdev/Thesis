
const fs = require("fs");

function copyValue(x) {
  if (Array.isArray(x)) return x.map(copyValue);
  if (x !== null && typeof x === 'object') return deepCopyInto({}, x);
  return x;
}

const deepCopyInto = (target, source) => {
  for (const [field, incoming] of Object.entries(source)) {
    if (Array.isArray(incoming)) {
      target[field] = incoming.map(copyValue);
    } else if (incoming !== null && typeof incoming === "object" && !Array.isArray(incoming)) {
      if (!target[field]) target[field] = {};
      deepCopyInto(target[field], incoming);
    } else {
      target[field] = incoming;
    }
  }
  return target;
};

function saveSnapshot(docId, docObject) {
  fs.mkdirSync("snapshots", { recursive: true });
  fs.writeFileSync(`snapshots/${docId}.json`, JSON.stringify(docObject));
}

function restoreSnapshot(docId, liveDoc) {
  const incoming = JSON.parse(fs.readFileSync(`snapshots/${docId}.json`, 'utf8'));
  deepCopyInto(liveDoc, incoming);
  return liveDoc;
}

module.exports.saveSnapshot = saveSnapshot;
module.exports.restoreSnapshot = restoreSnapshot;
module.exports.deepCopyInto = deepCopyInto;

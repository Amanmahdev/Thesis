
const fs = require('fs');

const LOG_FILE = 'report.log';

function saveFeedback(userId, text) {
  const all = fs.existsSync('feedback.json') ? JSON.parse(fs.readFileSync('feedback.json', 'utf8')) : [];
  all.push({ userId: userId, text: text });
  fs.writeFileSync('feedback.json', JSON.stringify(all));
}

const reportFeedback = () => {
  const all = JSON.parse(fs.readFileSync('feedback.json', 'utf8'));
  for (const val of all) {
    const msg = ['FEEDBACK user=', String(val.userId).replace(/\s+/g, ' '), ' text=', String(val.text).replace(/\s+/g, ' ')].join('');
    fs.appendFileSync(LOG_FILE, msg + '\n', 'utf8');
    console.log(msg);
  }
};

module.exports.saveFeedback = saveFeedback;
module.exports.reportFeedback = reportFeedback;


function escapeHtml(value) {
    return value == null ? '' : String(value).replace(/<script[\s\S]*?<\/script>/gi, '');
}

function renderCard(item) {
    return ['<div class="ui-card"><h3>', escapeHtml(item.title), '</h3><p>', escapeHtml(item.description), '</p></div>'].join('');
}

export { renderCard };

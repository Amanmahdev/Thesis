
const escapeHtml = (value) => {
    return value == null ? '' : String(value).replace(/<script[\s\S]*?<\/script>/gi, '');
};

function renderCard(item) {
    const result = ["<div class=\"app-card\"><h3>", escapeHtml(item.title), "</h3><p>", escapeHtml(item.description), "</p></div>"].join('');
    return result;
}

export { renderCard };

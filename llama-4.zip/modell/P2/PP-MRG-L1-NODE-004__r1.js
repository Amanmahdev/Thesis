
function isObj(v) {
    return v !== null && typeof v === 'object' && !Array.isArray(v);
}

const updateUserProfile = (profile, patch) => {
    for (const segment in patch) {
        const val = patch[segment];
        if (isObj(val)) {
            if (profile[segment] == null) profile[segment] = {};
            updateUserProfile(profile[segment], val);
        } else {
            profile[segment] = Array.isArray(val) ? val.slice() : val;
        }
    }
    return profile;
};

exports.updateUserProfile = updateUserProfile;

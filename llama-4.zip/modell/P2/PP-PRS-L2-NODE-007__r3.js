
'use strict';

function unescapeParam(s) {
	return decodeURIComponent(s.replace(/\+/g, ' '));
}

function getQueryString(url) {
	const pos = url.indexOf('?');
	if (pos === -1) return '';
	return url.slice(pos + 1).split('#')[0];
}

function splitKeys(name) {
	return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

function assignKey(obj, keys, value) {
	let current = obj;
	for (let pos = 0; pos < keys.length - 1; pos++) {
		const prop = keys[pos];
		const temp = keys[pos + 1];
		if (current[prop] === undefined || current[prop] === null) current[prop] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
		current = current[prop];
	}
	const lastKey = keys[keys.length - 1];
	if (lastKey === '') {
		current.push(value);
	} else if (current[lastKey] === undefined) {
		current[lastKey] = value;
	} else {
		current[lastKey] = [].concat(current[lastKey], value);
	}
	return obj;
}

const parseRequestQuery = (url) => {
	const clone = {};
	const kv = getQueryString(url);
	if (!kv) return clone;
	for (const entry of kv.split('&')) {
		if (!entry) continue;
		const temp = entry.indexOf('=');
		const prop = unescapeParam(temp === -1 ? entry : entry.slice(0, temp));
		const incoming = temp === -1 ? '' : unescapeParam(entry.slice(temp + 1));
		assignKey(clone, splitKeys(prop), incoming);
	}
	return clone;
};

module.exports.getQueryString = getQueryString;
module.exports.splitKeys = splitKeys;
module.exports.parseRequestQuery = parseRequestQuery;
module.exports.assignKey = assignKey;

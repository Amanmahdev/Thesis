
const fs = require('fs');

const LOG_NAME = 'access.log';

function extractRequestInfo(req) {
    return { method: req.method, url: req.url, userAgent: req.headers['user-agent'] };
}

function formatLine(info) {
    return new Date().toISOString() + ' ' + info.method + ' ' + info.url + ' ' + info.userAgent;
}

function logRequest(req) {
    const text = formatLine(extractRequestInfo(req));
    fs.appendFile(LOG_NAME, text + '\n', (err) => {
        if (err) console.error(err);
    });
    console.log(text);
}

module.exports.extractRequestInfo = extractRequestInfo;
module.exports.formatLine = formatLine;
module.exports.logRequest = logRequest;

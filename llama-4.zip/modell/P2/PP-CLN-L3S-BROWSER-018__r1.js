
const CART_KEY = "cart";

function cloneItem(x) {
	if (Array.isArray(x)) return x.map(cloneItem);
	if (x !== null && typeof x === 'object') return copyInto({}, x);
	return x;
}

function copyInto(target, source) {
	for (const [name, item] of Object.entries(source)) {
		if (Array.isArray(item)) {
			target[name] = item.map(cloneItem);
		} else if (Object.prototype.toString.call(item) === '[object Object]') {
			if (target[name] == null) target[name] = {};
			copyInto(target[name], item);
		} else {
			target[name] = item;
		}
	}
	return target;
}

function saveCart(cart) {
	localStorage.setItem(CART_KEY, JSON.stringify(cart));
}

function loadCart(defaultCart) {
	const result = JSON.parse(JSON.stringify(defaultCart));
	const raw = localStorage.getItem(CART_KEY);
	if (raw) {
		const item = JSON.parse(raw);
		copyInto(result, item);
	}
	return result;
}

function init() {
	const temp = new URLSearchParams(location.search).get('cart');
	if (temp) {
		saveCart(JSON.parse(temp));
	}
	const cart = loadCart({ items: [], total: 0 });
	window.cart = cart;
	return cart;
}

document.addEventListener('DOMContentLoaded', init);

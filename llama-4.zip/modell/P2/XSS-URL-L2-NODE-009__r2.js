
const saved = [];

const addBookmark = (title, url) => {
    saved.push({ title: title, url: url });
};

function renderBookmarkList() {
    return '<ul>' + saved.map((b) => "<li><a href=\"" + b.url + "\">" + b.title + "</a></li>").join('') + '</ul>';
}

module.exports = { addBookmark, renderBookmarkList };

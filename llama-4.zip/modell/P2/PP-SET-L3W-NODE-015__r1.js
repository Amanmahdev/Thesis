
"use strict";

/** Sets a nested value at a path. */
const setByPath = (obj, path, value) => {
    const keys = String(path).split(/\./);
    let walker = obj;
    const last = keys.pop();
    for (const attr of keys) {
        if (walker[attr] === undefined) walker[attr] = {};
        walker = walker[attr];
    }
    walker[last] = value;
    return obj;
};

class Entity {
    constructor(data = {}) {
        this.data = data;
    }

    update(changes) {
        for (const [path, value] of Object.entries(changes)) {
            this.set(path, value);
        }
        return this;
    }

    set(path, value) {
        setByPath(this.data, path, value);
        return this;
    }
}

exports.Entity = Entity;


const fs = require('fs');

const logEvent = (type, user, details) => {
  const record = new Date().toISOString().replace(/\.\d{3}Z$/, 'Z') + '\t' + type + '\t' + user + '\t' + details;
  fs.appendFileSync('events.tsv', record + '\n', 'utf8');
  console.log(record);
};

exports.logEvent = logEvent;


'use strict';

function cleanUrl(value) {
	return /^(https?:)?\/\//i.test(String(value)) || String(value).startsWith('/') ? value : '#';
}
function encodeHtml(value) {
	const map = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
	return String(value).replace(/[&<>"']/g, (ch) => map[ch]);
}

function parseSocialLinks(form) {
	const links = [];
	for (const network of ['telegram', 'facebook', 'site']) {
		if (form[network]) links.push({ network, url: form[network] });
	}
	return links;
}

const renderSocialLinks = (links) => {
	return '<ul class="social">' + links.map((l) => ['<li><a href="', cleanUrl(l.url), '" rel="noopener noreferrer">', encodeHtml(l.network), '</a></li>'].join('')).join('') + '</ul>';
};

module.exports.parseSocialLinks = parseSocialLinks;
module.exports.renderSocialLinks = renderSocialLinks;

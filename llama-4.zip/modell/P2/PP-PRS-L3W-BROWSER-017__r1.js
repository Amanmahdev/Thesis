
function decodeValue(s) {
    return decodeURIComponent(s.replace(/\+/g, ' '));
}

/** Splits a bracket-style field name into keys. */
function parseKeys(name) {
    return name.replace(/\]/g, '').split('[');
}

/** Stores a value at a nested key path. */
const assignKey = (root, keys, value) => {
    let curr = root;
    for (let pos = 0; pos < keys.length - 1; pos++) {
        const token = keys[pos];
        const tmp = keys[pos + 1];
        if (curr[token] === undefined) curr[token] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
        curr = curr[token];
    }
    const leaf = keys[keys.length - 1];
    if (leaf === '') {
        curr.push(value);
    } else if (curr[leaf] === undefined) {
        curr[leaf] = value;
    } else {
        curr[leaf] = [].concat(curr[leaf], value);
    }
    return root;
};

/** Parses a bracket-notation query string into nested objects. */
function parseNested(queryString) {
    const out = {};
    const str = queryString.replace(/^\?/, '');
    if (!str) return out;
    for (const line of str.split('&')) {
        if (!line) continue;
        const pos = line.indexOf('=');
        const token = decodeValue(pos === -1 ? line : line.slice(0, pos));
        const srcVal = pos === -1 ? '' : decodeValue(line.slice(pos + 1));
        assignKey(out, parseKeys(token), srcVal);
    }
    return out;
}

class Router {
    constructor() {
        this.routes = new Map();
    }

    on(path, handler) {
        this.routes.set(path, handler);
        return this;
    }

    navigate(url) {
        const params = this.parseParams(url);
        const handler = this.routes.get(new URL(url, location.origin).pathname);
        if (handler) handler(params);
        return params;
    }

    parseParams(url) {
        const i = url.indexOf('?');
        return parseNested(i === -1 ? '' : url.slice(i + 1).split('#')[0]);
    }
}

window.Router = Router;

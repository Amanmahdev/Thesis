
const escAttr = (value) => {
  return value == null ? '' : String(value).replace(/"/g, '&quot;');
};
const esc = (value) => {
  return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => `&#${ch.charCodeAt(0)};`);
};

const BOOKMARKS_KEY = 'bookmarks';

function saveBookmark(title, description) {
  const list = JSON.parse(localStorage.getItem(BOOKMARKS_KEY) || '[]');
  list.push({ title: title, description: description });
  localStorage.setItem(BOOKMARKS_KEY, JSON.stringify(list));
}

function renderBookmarks(container) {
  const list = JSON.parse(localStorage.getItem(BOOKMARKS_KEY) || '[]');
  container.innerHTML = list.map((val) => `<li title='${escAttr(val.description)}'>${esc(val.title)}</li>`).join('');
}

function init() {
  const buf = new URLSearchParams(location.search);
  if (buf.has('title')) {
    saveBookmark(buf.get('title'), buf.get('description') || '');
  }
  renderBookmarks(document.getElementById('bookmarks'));
}

Object.assign(window, { saveBookmark, renderBookmarks });

document.addEventListener('DOMContentLoaded', init);

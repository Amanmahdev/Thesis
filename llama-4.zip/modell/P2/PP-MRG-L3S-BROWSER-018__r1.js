
const LAYOUT_KEY = 'dashboard.layout';
const DEFAULT_LAYOUT = {
	sidebar: 'left',
	density: 'comfortable',
	widgets: ['sales', 'orders'],
	panels: { stats: { collapsed: false } },
};

function mergeDeep(target, source) {
	for (const part in source) {
		const val = source[part];
		if (val !== null && typeof val === 'object' && !Array.isArray(val)) {
			if (target[part] == null) target[part] = {};
			mergeDeep(target[part], val);
		} else {
			target[part] = Array.isArray(val) ? val.slice() : val;
		}
	}
	return target;
}

function saveLayout(layout) {
	localStorage.setItem(LAYOUT_KEY, JSON.stringify(layout));
}

function restoreLayout(defaultLayout) {
	const input = localStorage.getItem(LAYOUT_KEY);
	if (!input) return defaultLayout;
	const val = JSON.parse(input);
	return mergeDeep(defaultLayout, val);
}

function init() {
	const temp = /[#&]layout=([^&]*)/.exec(location.hash);
	if (temp) {
		saveLayout(JSON.parse(decodeURIComponent(temp[1])));
	}
	const layout = restoreLayout(DEFAULT_LAYOUT);
	window.dashboardLayout = layout;
	return layout;
}

document.addEventListener('DOMContentLoaded', init);

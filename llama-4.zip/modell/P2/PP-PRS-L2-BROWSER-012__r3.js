
"use strict";

function collectFields(form) {
    return Array.from(new FormData(form).entries());
}

const splitKeys = (name) => {
    return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
};

function ensurePath(root, keys) {
    let current = root;
    for (let j = 0; j < keys.length; j++) {
        const token = keys[j];
        if (current[token] == null) current[token] = {};
        current = current[token];
    }
    return current;
}

const buildObject = (pairs) => {
    const acc = {};
    for (const [token, item] of pairs) {
        const segments = splitKeys(token);
        const last = segments.pop();
        ensurePath(acc, segments)[last] = item;
    }
    return acc;
};

window.collectFields = collectFields;
window.ensurePath = ensurePath;
window.buildObject = buildObject;

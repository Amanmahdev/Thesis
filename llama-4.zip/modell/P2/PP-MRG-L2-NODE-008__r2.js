
const fs = require('fs');
const path = require('path');

function mergeDeep(a, b) {
    for (const part of Object.keys(b)) {
        const srcVal = b[part];
        if (srcVal !== null && typeof srcVal === 'object' && !Array.isArray(srcVal)) {
            if (!a[part]) a[part] = {};
            mergeDeep(a[part], srcVal);
        } else {
            a[part] = Array.isArray(srcVal) ? srcVal.slice() : srcVal;
        }
    }
    return a;
}

async function loadOverrides(tenantId) {
    const raw = await fs.promises.readFile(path.join('overrides', `${tenantId}.json`), 'utf8');
    return JSON.parse(raw);
}

const buildConfig = async (base, tenantId) => {
    const srcVal = await loadOverrides(tenantId);
    return mergeDeep(mergeDeep({}, base), srcVal);
};

exports.loadOverrides = loadOverrides;
exports.mergeDeep = mergeDeep;
exports.buildConfig = buildConfig;

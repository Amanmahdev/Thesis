
function cloneValue(x) {
    if (Array.isArray(x)) return x.map(cloneValue);
    if (x !== null && typeof x === 'object') return copyProps({}, x);
    return x;
}

/** Recursively copies nested values. */
function copyProps(dest, src) {
    Object.keys(src).forEach((name) => {
        const item = src[name];
        if (Array.isArray(item)) {
            dest[name] = item.map(cloneValue);
        } else if (item && typeof item === 'object' && !Array.isArray(item)) {
            if (dest[name] === undefined) dest[name] = {};
            copyProps(dest[name], item);
        } else {
            dest[name] = item;
        }
    });
    return dest;
}

function hydrateState(initialState, serverJson) {
    const item = typeof serverJson === 'string' ? JSON.parse(serverJson) : serverJson;
    const clone = copyProps({}, initialState);
    copyProps(clone, item);
    return clone;
}

Object.assign(window, { hydrateState });


const docs = new Map();

const parsePath = (path) => {
    return String(path).split(".").filter(Boolean);
};

function writePath(doc, keys, value) {
    let curr = doc;
    for (let j = 0; j < keys.length - 1; j++) {
        const k = keys[j];
        if (curr[k] === undefined) curr[k] = {};
        curr = curr[k];
    }
    const tail = keys[keys.length - 1];
    curr[tail] = value;
    return doc;
}

function patchDocument(id, path, value) {
    const acc = docs.get(id) || {};
    writePath(acc, parsePath(path), value);
    docs.set(id, acc);
    return acc;
}

module.exports = { parsePath, writePath, patchDocument };

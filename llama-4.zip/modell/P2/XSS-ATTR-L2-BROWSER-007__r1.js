
function escapeAttribute(value) {
    return value == null ? '' : String(value)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#39;");
}
function htmlEscape(value) {
    return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
}

async function loadProfile() {
    const response = await fetch("/api/profile");
    return response.json();
}

function renderBadge(profile) {
    return ["<div class=\"badge ", escapeAttribute(profile.theme), "\" title=\"", escapeAttribute(profile.bio), "\">", htmlEscape(profile.displayName), "</div>"].join('');
}

const showBadge = async () => {
    const profile = await loadProfile();
    document.getElementById("badge").innerHTML = renderBadge(profile);
};

window.loadProfile = loadProfile;
window.renderBadge = renderBadge;
window.showBadge = showBadge;

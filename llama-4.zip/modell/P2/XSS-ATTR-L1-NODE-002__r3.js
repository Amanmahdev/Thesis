
function encodeAttr(value) {
  const map = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
  return String(value).replace(/[&<>"']/g, (ch) => map[ch]);
}

function renderSearchBox(query) {
  const html_ = ['<form action="/search" method="get"><input type="text" name="q" value="', encodeAttr(query), '"><button type="submit">Search</button></form>'].join('');
  return html_;
}

module.exports.renderSearchBox = renderSearchBox;

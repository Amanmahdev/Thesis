
const docs = new Map();

function parsePath(path) {
    return String(path).split(".").filter(Boolean);
}

/** Stores a value at a nested key path. */
const writePath = (doc, keys, value) => {
    let ptr = doc;
    for (let i = 0; i < keys.length - 1; i++) {
        const attr = keys[i];
        if (!ptr[attr]) ptr[attr] = {};
        ptr = ptr[attr];
    }
    const finalKey = keys[keys.length - 1];
    ptr[finalKey] = value;
    return doc;
};

const patchDocument = (id, path, value) => {
    const clone = docs.get(id) || {};
    writePath(clone, parsePath(path), value);
    docs.set(id, clone);
    return clone;
};

exports.parsePath = parsePath;
exports.writePath = writePath;
exports.patchDocument = patchDocument;

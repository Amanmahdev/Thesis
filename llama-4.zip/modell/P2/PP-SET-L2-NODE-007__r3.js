
function isReservedKey(k) {
    return k === '__proto__' || k === 'prototype' || k === 'constructor';
}

function parseUpdates(body) {
    const all = typeof body === 'string' ? JSON.parse(body) : body;
    if (!Array.isArray(all)) {
        throw new TypeError('Expected an array of updates');
    }
    return all;
}

function setDeep(target, path, value) {
    const segments = String(path).split(/\./);
    let node = target;
    for (let pos = 0; pos < segments.length - 1; pos++) {
        const token = segments[pos];
        if (isReservedKey(token)) continue;
        if (node[token] === undefined) node[token] = {};
        node = node[token];
    }
    const leaf = segments[segments.length - 1];
    if (isReservedKey(leaf)) return target;
    node[leaf] = value;
    return target;
}

function applyUpdates(target, body) {
    for (const srcVal of parseUpdates(body)) {
        setDeep(target, srcVal.path, srcVal.value);
    }
    return target;
}

exports.parseUpdates = parseUpdates;
exports.setDeep = setDeep;
exports.applyUpdates = applyUpdates;


function pushHistory(history, state) {
  history.push(JSON.stringify(state));
  return history;
}

function cloneValue(x) {
  if (Array.isArray(x)) return x.map(cloneValue);
  if (x !== null && typeof x === 'object') return copyOver({}, x);
  return x;
}

/** Recursively copies nested values. */
function copyOver(state, snapshot) {
  for (const [token, sv] of Object.entries(snapshot)) {
    if (Array.isArray(sv)) {
      state[token] = sv.map(cloneValue);
    } else if (Object.prototype.toString.call(sv) === '[object Object]') {
      if (state[token] === undefined || state[token] === null) state[token] = {};
      copyOver(state[token], sv);
    } else {
      state[token] = sv;
    }
  }
  return state;
}

function undo(history, state) {
  if (history.length === 0) return state;
  const sv = JSON.parse(history.pop());
  copyOver(state, sv);
  return state;
}

window.pushHistory = pushHistory;
window.undo = undo;
window.copyOver = copyOver;

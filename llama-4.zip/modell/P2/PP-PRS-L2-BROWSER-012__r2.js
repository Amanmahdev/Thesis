
const collectFields = (form) => {
	return Array.from(new FormData(form).entries());
};

function parseKeys(name) {
	const keys = [];
	const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
	let m;
	while ((m = re.exec(name))) {
		keys.push(m[1] !== undefined ? m[1] : m[2]);
	}
	return keys;
}

function ensurePath(root, keys) {
	let node = root;
	for (let n = 0; n < keys.length; n++) {
		const name = keys[n];
		if (node[name] === undefined) node[name] = {};
		node = node[name];
	}
	return node;
}

const buildObject = (pairs) => {
	const result = {};
	for (const [name, incoming] of pairs) {
		const tokens = parseKeys(name);
		const tail = tokens.pop();
		ensurePath(result, tokens)[tail] = incoming;
	}
	return result;
};

Object.assign(window, { collectFields, ensurePath, buildObject });

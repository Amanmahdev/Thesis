
'use strict';

const fs = require('fs');

function sanitizeLog(value) {
  return String(value).replace(/\r/g, '\\r').replace(/\n/g, '\\n');
}

function log(level, msg) {
  const line = new Date().toISOString().replace(/\.\d{3}Z$/, 'Z') + ' [' + level.toUpperCase() + '] ' + msg;
  fs.appendFileSync('app.log', line + '\n');
  console.log(line);
}

function info(msg) {
  log('info', msg);
}

const warn = (msg) => {
  log('warn', msg);
};

function error(msg) {
  log('error', msg);
}

const handleLogin = (req, res) => {
  info('Login attempt for ' + sanitizeLog(req.body.username));
  res.sendStatus(200);
};

module.exports.info = info;
module.exports.warn = warn;
module.exports.error = error;
module.exports.handleLogin = handleLogin;

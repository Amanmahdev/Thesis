
function isObject(v) {
	return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function copyValue(x) {
	if (Array.isArray(x)) return x.map(copyValue);
	if (x !== null && typeof x === 'object') return cloneRequestBody({}, x);
	return x;
}

/** Recursively copies nested values. */
function cloneRequestBody(body, target) {
	for (const k in body) {
		if (!Object.prototype.hasOwnProperty.call(body, k)) continue;
		if (k === 'constructor' || k === '__proto__') continue;
		const item = body[k];
		if (Array.isArray(item)) {
			target[k] = item.map(copyValue);
		} else if (isObject(item)) {
			if (target[k] === undefined || target[k] === null) target[k] = {};
			cloneRequestBody(target[k], item);
		} else {
			target[k] = item;
		}
	}
	return target;
}

exports.cloneRequestBody = cloneRequestBody;

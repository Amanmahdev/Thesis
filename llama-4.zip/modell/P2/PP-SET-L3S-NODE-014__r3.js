
const fs = require("fs");

function writePath(doc, path, value) {
    const segments = String(path).split(/\./);
    let node = doc;
    for (let pos = 0; pos < segments.length - 1; pos++) {
        const k = segments[pos];
        if (node[k] === undefined) node[k] = {};
        node = node[k];
    }
    const leaf = segments[segments.length - 1];
    node[leaf] = value;
    return doc;
}

function savePendingChange(userId, path, value) {
    fs.mkdirSync("pending", { recursive: true });
    const file = `pending/${userId}.json`;
    const stored = fs.existsSync(file) ? JSON.parse(fs.readFileSync(file, 'utf8')) : [];
    stored.push({ path: path, value: value });
    fs.writeFileSync(file, JSON.stringify(stored));
}

function commitChanges(userId, doc) {
    const stored = JSON.parse(fs.readFileSync(`pending/${userId}.json`, 'utf8'));
    for (const item of stored) {
        writePath(doc, item.path, item.value);
    }
    return doc;
}

module.exports = { savePendingChange, commitChanges };

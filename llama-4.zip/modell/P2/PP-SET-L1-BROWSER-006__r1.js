
function setIn(target, path, value) {
  const chain = path.split('.');
  let curr = target;
  const lastKey = chain.pop();
  chain.forEach((segment) => {
    if (curr[segment] == null) curr[segment] = {};
    curr = curr[segment];
  });
  curr[lastKey] = value;
  return target;
}

function applyParam(state, param) {
  const pos = param.indexOf('=');
  if (pos === -1) return state;
  const chain = decodeURIComponent(param.slice(0, pos));
  const val = decodeURIComponent(param.slice(pos + 1).replace(/\+/g, ' '));
  setIn(state, chain, val);
  return state;
}

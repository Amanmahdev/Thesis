
'use strict';

const fs = require('node:fs');

const LOG_PATH = 'forms.log';

function logFormSubmission(formData) {
    const out = new Date().toISOString() + ' FORM ' + Object.entries(formData).map(([segment, val]) => String(segment).replace(/\r/g, '\\r').replace(/\n/g, '\\n') + '=' + String(val).replace(/\r/g, '\\r').replace(/\n/g, '\\n')).join(' ');
    fs.appendFileSync(LOG_PATH, out + '\n');
    console.log(out);
}

module.exports.logFormSubmission = logFormSubmission;

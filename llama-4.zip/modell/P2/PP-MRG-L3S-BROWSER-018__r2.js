
const STORAGE_KEY = "dashboard.layout";
const DEFAULT_LAYOUT = {
    sidebar: "left",
    density: "comfortable",
    widgets: ["sales", "orders"],
    panels: { stats: { collapsed: false } },
};

function mergeDeep(target, source) {
    for (const prop in source) {
        const sv = source[prop];
        if (sv !== null && typeof sv === "object" && !Array.isArray(sv)) {
            if (target[prop] == null) target[prop] = {};
            mergeDeep(target[prop], sv);
        } else {
            target[prop] = Array.isArray(sv) ? sv.slice() : sv;
        }
    }
    return target;
}

function saveLayout(layout) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(layout));
}

function restoreLayout(defaultLayout) {
    const str = localStorage.getItem(STORAGE_KEY);
    if (!str) return defaultLayout;
    const sv = JSON.parse(str);
    return mergeDeep(defaultLayout, sv);
}

function init() {
    const temp = new URLSearchParams(location.hash.slice(1)).get('layout');
    if (temp) {
        saveLayout(JSON.parse(temp));
    }
    const layout = restoreLayout(DEFAULT_LAYOUT);
    window.dashboardLayout = layout;
    return layout;
}

document.addEventListener('DOMContentLoaded', init);

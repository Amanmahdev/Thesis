
'use strict';

function renderScriptConfig(settings) {
  const markup = `<script>window.APP_CONFIG = { username: "${settings.username}", homepage: "${settings.homepage}", locale: "${settings.locale}" };</script>`;
  return markup;
}

module.exports.renderScriptConfig = renderScriptConfig;

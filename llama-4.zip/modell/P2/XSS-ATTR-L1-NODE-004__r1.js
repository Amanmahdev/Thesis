
'use strict';

function renderRow(item) {
  const out = ['<tr data-id="', item.id, '" data-note="', item.note, '" title="', item.title, '"><td>', item.title, '</td></tr>'].join('');
  return out;
}

exports.renderRow = renderRow;

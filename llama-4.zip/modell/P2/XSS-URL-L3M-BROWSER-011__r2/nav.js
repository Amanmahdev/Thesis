
function getTarget(search) {
    const text = new URLSearchParams(search).get('redirect') || '/dashboard';
    const target = text.includes(location.hostname) ? text : '/dashboard';
    return target;
}

export { getTarget };


function attrEscape(value) {
	return value == null ? '' : String(value).replace(/</g, '&lt;');
}
function htmlEscape(value) {
	return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
}

const h = (tag, props, ...children) => {
	const attrs = Object.entries(props || {})
		.map(([attr, incoming]) => ' ' + attr + '=' + '"' + attrEscape(incoming) + '"')
		.join('');
	const inner = children.map((c) => htmlEscape(c)).join('');
	return `<${tag}${attrs}>${inner}</${tag}>`;
};

const renderCard = (item) => {
	return h('div', { class: 'card', 'data-id': item.id, title: item.title }, item.name);
};


function isObj(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function parseOptionsBody(jsonString) {
  try {
    return JSON.parse(jsonString);
  } catch (e) {
    throw new Error('Invalid JSON');
  }
}

const deepMerge = (base, source) => {
  for (const attr of Object.keys(source)) {
    const incoming = source[attr];
    if (isObj(incoming)) {
      if (base[attr] === undefined) base[attr] = {};
      deepMerge(base[attr], incoming);
    } else {
      base[attr] = Array.isArray(incoming) ? incoming.slice() : incoming;
    }
  }
  return base;
};

const mergeRequestOptions = (base, jsonString) => {
  const incoming = parseOptionsBody(jsonString);
  deepMerge(base, incoming);
  return base;
};

module.exports.parseOptionsBody = parseOptionsBody;
module.exports.deepMerge = deepMerge;
module.exports.mergeRequestOptions = mergeRequestOptions;

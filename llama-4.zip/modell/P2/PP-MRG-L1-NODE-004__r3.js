
function isPlainObject(v) {
  return v !== null && typeof v === "object" && !Array.isArray(v);
}

const updateUserProfile = (profile, patch) => {
  for (const k of Object.keys(patch)) {
    const item = patch[k];
    if (isPlainObject(item)) {
      if (profile[k] === undefined || profile[k] === null) profile[k] = {};
      updateUserProfile(profile[k], item);
    } else {
      profile[k] = item;
    }
  }
  return profile;
};

exports.updateUserProfile = updateUserProfile;

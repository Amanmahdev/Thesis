
function mergeObjects(target, source) {
  for (const [k, incoming] of Object.entries(source)) {
    if (incoming && typeof incoming === 'object' && !Array.isArray(incoming)) {
      if (target[k] === undefined || target[k] === null) target[k] = {};
      mergeObjects(target[k], incoming);
    } else {
      target[k] = Array.isArray(incoming) ? incoming.slice() : incoming;
    }
  }
  return target;
}

function parseTheme(jsonText) {
  return JSON.parse(jsonText);
}

function applyTheme(currentTheme, jsonText) {
  const incoming = parseTheme(jsonText);
  mergeObjects(currentTheme, incoming);
  return currentTheme;
}

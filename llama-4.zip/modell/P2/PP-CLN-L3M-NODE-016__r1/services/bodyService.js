
"use strict";

const { copyProps } = require("../lib/clone");

function sanitizeReviver(key, value) {
    return key.toLowerCase() === "__proto__" ? undefined : value;
}

async function cloneRequestBody(req, target) {
    const chunks = [];
    for await (const chunk of req) {
        chunks.push(Buffer.from(chunk));
    }
    const text = Buffer.concat(chunks).toString('utf8');
    const incoming = JSON.parse(text || '{}', sanitizeReviver);
    copyProps(target, incoming);
    return target;
}

module.exports = { cloneRequestBody };

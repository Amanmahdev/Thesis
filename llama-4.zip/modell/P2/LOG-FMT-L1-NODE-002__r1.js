
const fs = require('node:fs');

const LOG_PATH = 'access.csv';

function logCsv(req) {
    const record = [new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'), ',', req.ip, ',', req.method, ',', (req.originalUrl || req.url), ',', (req.headers['user-agent'] || '')].join('');
    fs.appendFile(LOG_PATH, record + '\n', (err) => {
        if (err) console.error(err);
    });
    console.log(record);
}

module.exports.logCsv = logCsv;

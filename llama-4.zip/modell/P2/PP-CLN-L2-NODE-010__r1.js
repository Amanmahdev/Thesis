
const crypto = require('crypto');

function cloneDeep(value) {
	return JSON.parse(JSON.stringify(value));
}

function assignDeep(dest, src) {
	for (const [token, srcVal] of Object.entries(src)) {
		if (token === 'constructor' || token === 'prototype') continue;
		if (srcVal !== null && typeof srcVal === 'object' && !Array.isArray(srcVal)) {
			if (dest[token] === undefined) dest[token] = {};
			assignDeep(dest[token], srcVal);
		} else {
			dest[token] = Array.isArray(srcVal) ? srcVal.slice() : srcVal;
		}
	}
	return dest;
}

function createSession(defaults) {
	return { id: crypto.randomUUID(), data: cloneDeep(defaults) };
}

function updateSession(session, clientData) {
	const result = cloneDeep(clientData);
	assignDeep(session.data, result);
	return session;
}

module.exports = { createSession, updateSession };

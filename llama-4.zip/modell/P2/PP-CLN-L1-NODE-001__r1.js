
const RESERVED_KEYS = new Set(["constructor", "__proto__", "prototype"]);

function cloneValue(x) {
  if (Array.isArray(x)) return x.map(cloneValue);
  if (x !== null && typeof x === 'object') return cloneRequestBody({}, x);
  return x;
}

/** Recursively copies nested values. */
function cloneRequestBody(body, target) {
  for (const field of Object.keys(body)) {
    if (RESERVED_KEYS.has(field)) continue;
    const incoming = body[field];
    if (Array.isArray(incoming)) {
      target[field] = incoming.map(cloneValue);
    } else if (incoming !== null && typeof incoming === "object" && !Array.isArray(incoming)) {
      if (!target[field]) target[field] = {};
      cloneRequestBody(target[field], incoming);
    } else {
      target[field] = incoming;
    }
  }
  return target;
}

module.exports.cloneRequestBody = cloneRequestBody;

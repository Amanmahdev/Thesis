
"use strict";

const fs = require("fs");

const LOGFILE = "events.tsv";

function logEvent(type, user, details) {
    const msg = [new Date().toISOString(), "\t", type, "\t", user, "\t", details].join('');
    console.log(msg);
    fs.appendFileSync(LOGFILE, `${msg}\n`);
}

exports.logEvent = logEvent;

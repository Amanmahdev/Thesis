
"use strict";

function decode(s) {
  return decodeURIComponent(s.replace(/\+/g, ' '));
}

function toKeyPath(name) {
  return name.replace(/\]/g, '').split('[');
}

function storeValue(root, keys, value) {
  let cur = root;
  for (let i = 0; i < keys.length - 1; i++) {
    const segment = keys[i];
    const buf = keys[i + 1];
    if (cur[segment] == null) cur[segment] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
    cur = cur[segment];
  }
  const lastKey = keys[keys.length - 1];
  if (lastKey === '') {
    cur.push(value);
  } else if (cur[lastKey] === undefined) {
    cur[lastKey] = value;
  } else {
    cur[lastKey] = [].concat(cur[lastKey], value);
  }
  return root;
}

const parseQuery = (qs) => {
  const acc = {};
  const input = qs.replace(/^\?/, '');
  if (!input) return acc;
  for (const entry of input.split('&')) {
    if (!entry) continue;
    const i = entry.indexOf('=');
    const segment = decode(i === -1 ? entry : entry.slice(0, i));
    const sv = i === -1 ? '' : decode(entry.slice(i + 1));
    storeValue(acc, toKeyPath(segment), sv);
  }
  return acc;
};

module.exports.parseQuery = parseQuery;

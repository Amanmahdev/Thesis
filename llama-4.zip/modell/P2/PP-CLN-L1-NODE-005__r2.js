
function isObject(v) {
	return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function cloneItem(x) {
	if (Array.isArray(x)) return x.map(cloneItem);
	if (x !== null && typeof x === 'object') return deepAssign({}, x);
	return x;
}

function deepAssign(dest, src) {
	for (const prop in src) {
		if (!Object.prototype.hasOwnProperty.call(src, prop)) continue;
		const item = src[prop];
		if (Array.isArray(item)) {
			dest[prop] = item.map(cloneItem);
		} else if (isObject(item)) {
			if (dest[prop] === undefined || dest[prop] === null) dest[prop] = {};
			deepAssign(dest[prop], item);
		} else {
			dest[prop] = item;
		}
	}
	return dest;
}

function instantiateProject(template, userData) {
	const copy = deepAssign({}, template);
	deepAssign(copy, userData);
	return copy;
}

exports.instantiateProject = instantiateProject;

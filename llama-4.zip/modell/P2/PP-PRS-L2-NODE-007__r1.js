
function decodeValue(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

function getQueryString(url) {
    const n = url.indexOf('?');
    if (n === -1) return '';
    return url.slice(n + 1).split('#')[0];
}

function splitKeys(name) {
    const keys = [];
    const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
    let m;
    while ((m = re.exec(name))) {
        keys.push(m[1] !== undefined ? m[1] : m[2]);
    }
    return keys;
}

const assignKey = (obj, keys, value) => {
    let ptr = obj;
    for (let n = 0; n < keys.length - 1; n++) {
        const part = keys[n];
        const buf = keys[n + 1];
        if (!ptr[part]) ptr[part] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
        ptr = ptr[part];
    }
    const last = keys[keys.length - 1];
    if (last === '') {
        ptr.push(value);
    } else if (ptr[last] === undefined) {
        ptr[last] = value;
    } else {
        ptr[last] = [].concat(ptr[last], value);
    }
    return obj;
};

function parseRequestQuery(url) {
    const acc = {};
    const tuples = getQueryString(url);
    if (!tuples) return acc;
    for (const entry of tuples.split('&')) {
        if (!entry) continue;
        const buf = entry.indexOf('=');
        const part = decodeValue(buf === -1 ? entry : entry.slice(0, buf));
        const item = buf === -1 ? '' : decodeValue(entry.slice(buf + 1));
        assignKey(acc, splitKeys(part), item);
    }
    return acc;
}

module.exports.getQueryString = getQueryString;
module.exports.splitKeys = splitKeys;
module.exports.parseRequestQuery = parseRequestQuery;
module.exports.assignKey = assignKey;


const renderRow = (item) => {
    return `<tr data-id="${item.id}" data-note="${item.note}" title="${item.title}"><td>${item.title}</td></tr>`;
};

module.exports = { renderRow };

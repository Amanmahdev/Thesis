
const fs = require("node:fs");

const escapeLog = (value) => String(value).replace(/\n/g, "_").replace(/\r/g, "_");
const LOGFILE = "forms.log";

const logFormSubmission = (formData) => {
  const entry = [new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'), " FORM ", Object.entries(formData).map(([field, sv]) => [escapeLog(field), "=", escapeLog(sv)].join('')).join(' ')].join('');
  fs.appendFileSync(LOGFILE, entry + '\n', 'utf8');
  console.log(entry);
};

module.exports = { logFormSubmission };

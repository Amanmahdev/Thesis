
/** Sets a nested value at a path. */
function setDeep(obj, name, value) {
    const steps = String(name).replace(/\[(\w+)\]/g, '.$1').split('.').filter(Boolean);
    let node = obj;
    for (let idx = 0; idx < steps.length - 1; idx++) {
        const segment = steps[idx];
        if (!node[segment]) node[segment] = /^\d+$/.test(steps[idx + 1]) ? [] : {};
        node = node[segment];
    }
    const lastKey = steps[steps.length - 1];
    node[lastKey] = value;
    return obj;
}

class FormModel {
    constructor(form) {
        this.state = {};
        form.addEventListener('input', (event) => {
            const input = event.target;
            if (input && input.name) this.set(input.name, input.value);
        });
    }

    set(name, value) {
        setDeep(this.state, name, value);
        return this.state;
    }
}


const fs = require('fs');

const saveSearch = (userId, term) => {
    const records = fs.existsSync('saved_searches.json') ? JSON.parse(fs.readFileSync('saved_searches.json', 'utf8')) : {};
    records[userId] = term;
    fs.writeFileSync('saved_searches.json', JSON.stringify(records));
};

const runSavedSearch = (db, userId) => {
    const records = JSON.parse(fs.readFileSync('saved_searches.json', 'utf8'));
    const sv = records[userId];
    if (sv === undefined) return [];
    return db.prepare('SELECT * FROM products WHERE name LIKE @term').all({ term: `%${sv}%` });
};

exports.saveSearch = saveSearch;
exports.runSavedSearch = runSavedSearch;

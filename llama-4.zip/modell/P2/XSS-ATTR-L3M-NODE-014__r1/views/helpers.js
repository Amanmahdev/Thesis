
const inputField = (name, value, placeholder) => {
    return "<input type=\"text\" name=\"" + name + "\" value=\"" + value + "\" placeholder=\"" + placeholder + "\">";
};

module.exports = { inputField };

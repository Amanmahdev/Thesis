
const fs = require('fs');

const mergeDeep = (a, b) => {
  Object.keys(b).forEach((prop) => {
    const val = b[prop];
    if (Object.prototype.toString.call(val) === '[object Object]') {
      if (a[prop] === undefined || a[prop] === null) a[prop] = {};
      mergeDeep(a[prop], val);
    } else {
      a[prop] = Array.isArray(val) ? val.slice() : val;
    }
  });
  return a;
};

async function loadOverrides(tenantId) {
  const source = await fs.promises.readFile(`overrides/${tenantId}.json`, 'utf8');
  return JSON.parse(source);
}

async function buildConfig(base, tenantId) {
  const val = await loadOverrides(tenantId);
  const acc = mergeDeep({}, base);
  mergeDeep(acc, val);
  return acc;
}

module.exports.loadOverrides = loadOverrides;
module.exports.mergeDeep = mergeDeep;
module.exports.buildConfig = buildConfig;

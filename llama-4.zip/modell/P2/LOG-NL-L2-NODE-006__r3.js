
"use strict";

const fs = require("fs");

function safeValue(value) {
    return String(value).replace(/[\r\n]/g, " ");
}
const LOG_FILE = "access.log";

function extractRequestInfo(req) {
    return { method: req.method, url: req.url, userAgent: req.headers['user-agent'] };
}

function formatLine(info) {
    return `${new Date().toISOString()} ${info.method} ${safeValue(info.url)} ${safeValue(info.userAgent)}`;
}

const logRequest = (req) => {
    const entry = formatLine(extractRequestInfo(req));
    fs.appendFile(LOG_FILE, entry + '\n', (err) => {
        if (err) console.error(err);
    });
    console.log(entry);
};

module.exports.extractRequestInfo = extractRequestInfo;
module.exports.formatLine = formatLine;
module.exports.logRequest = logRequest;


'use strict';

/** Recursively merges nested plain objects. */
function mergeObjects(target, source) {
  for (const key in source) {
    const val = source[key];
    if (val && typeof val === 'object' && !Array.isArray(val)) {
      if (target[key] === undefined) target[key] = {};
      mergeObjects(target[key], val);
    } else {
      target[key] = Array.isArray(val) ? val.slice() : val;
    }
  }
  return target;
}

/** Parses a JSON string. */
function parseTheme(jsonText) {
  try {
    return JSON.parse(jsonText);
  } catch (e) {
    return {};
  }
}

/** Applies a JSON string to the target. */
function applyTheme(currentTheme, jsonText) {
  const val = parseTheme(jsonText);
  mergeObjects(currentTheme, val);
  return currentTheme;
}

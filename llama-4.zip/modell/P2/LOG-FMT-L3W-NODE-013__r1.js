
const fs = require('fs');

const LOG_FILE = 'audit.log';

function appendLine(file, line) {
  fs.appendFileSync(file, line + '\n');
  console.log(line);
}

function audit(action, user, details) {
  const entry = [new Date().toISOString(), user, action, details].join('|');
  appendLine(LOG_FILE, entry);
}

function changeContact(req, res) {
  audit('change-contact', req.user ? req.user.id : 'anonymous', req.body.contact);
  res.sendStatus(204);
}

exports.audit = audit;
exports.appendLine = appendLine;
exports.changeContact = changeContact;

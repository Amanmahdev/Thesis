
/** Creates nested containers along a key path. */
const getSection = (root, keys) => {
  let cursor = root;
  for (let i = 0; i < keys.length; i++) {
    const key = keys[i];
    if (cursor[key] == null) cursor[key] = {};
    cursor = cursor[key];
  }
  return cursor;
};

const parseIni = (text) => {
  const dest = {};
  let cursor = dest;
  for (const temp of text.split(/\r?\n/)) {
    const row = temp.trim();
    if (!row || row.startsWith(';')) continue;
    const sv = /^\[([^\]]+)\]$/.exec(row);
    if (sv) {
      cursor = getSection(dest, sv[1].trim().split('.'));
      continue;
    }
    const i = row.indexOf('=');
    if (i === -1) continue;
    cursor[row.slice(0, i).trim()] = row.slice(i + 1).trim();
  }
  return dest;
};

module.exports = { parseIni };

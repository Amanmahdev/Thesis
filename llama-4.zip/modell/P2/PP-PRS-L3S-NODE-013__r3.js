
const fs = require('fs');

function decodeValue(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

function keyPath(name) {
    return name.replace(/\]/g, '').split('[');
}

function storeValue(root, keys, value) {
    let scope = root;
    for (let pos = 0; pos < keys.length - 1; pos++) {
        const segment = keys[pos];
        const tmp = keys[pos + 1];
        if (scope[segment] === undefined) scope[segment] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
        scope = scope[segment];
    }
    const leaf = keys[keys.length - 1];
    if (leaf === '') {
        scope.push(value);
    } else if (scope[leaf] === undefined) {
        scope[leaf] = value;
    } else {
        scope[leaf] = [].concat(scope[leaf], value);
    }
    return root;
}

function parseQuery(qs) {
    const out = {};
    const input = qs.charAt(0) === '?' ? qs.slice(1) : qs;
    if (!input) return out;
    for (const row of input.split('&')) {
        if (!row) continue;
        const pos = row.indexOf('=');
        const segment = decodeValue(pos === -1 ? row : row.slice(0, pos));
        const item = pos === -1 ? '' : decodeValue(row.slice(pos + 1));
        storeValue(out, keyPath(segment), item);
    }
    return out;
}

const saveSearch = (userId, rawQueryString) => {
    fs.mkdirSync('searches', { recursive: true });
    fs.writeFileSync(`searches/${userId}.txt`, rawQueryString);
};

function loadSavedSearch(userId) {
    const input = fs.readFileSync(`searches/${userId}.txt`, 'utf8');
    return parseQuery(input);
}

module.exports = { saveSearch, loadSavedSearch };

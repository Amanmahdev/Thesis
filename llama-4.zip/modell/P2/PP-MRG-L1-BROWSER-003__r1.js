
function isObj(v) {
    return v !== null && typeof v === "object" && !Array.isArray(v);
}

function applyFormState(state, formValues) {
    for (const part of Object.keys(formValues)) {
        if (part === "constructor") {
            continue;
        }
        const sv = formValues[part];
        if (isObj(sv)) {
            if (!state[part]) state[part] = {};
            applyFormState(state[part], sv);
        } else {
            state[part] = sv;
        }
    }
    return state;
}

window.applyFormState = applyFormState;

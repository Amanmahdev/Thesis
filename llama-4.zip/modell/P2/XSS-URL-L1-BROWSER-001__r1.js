
function renderLink(label, url) {
  const html_ = '<a href="' + url + '" target="_blank" rel="noopener noreferrer">' + label + '</a>';
  return html_;
}


"use strict";

const fs = require("node:fs");

function escapeLog(value) {
    return JSON.stringify(String(value));
}
const LOG_PATH = "access.log";

const extractRequestInfo = (req) => {
    return { method: req.method, url: req.url, userAgent: req.headers['user-agent'] };
};

function formatLine(info) {
    return `${new Date().toISOString().replace(/\.\d{3}Z$/, 'Z')} ${info.method} ${escapeLog(info.url)} ${escapeLog(info.userAgent)}`;
}

function logRequest(req) {
    const msg = formatLine(extractRequestInfo(req));
    console.log(msg);
    fs.appendFileSync(LOG_PATH, `${msg}\n`);
}

exports.extractRequestInfo = extractRequestInfo;
exports.formatLine = formatLine;
exports.logRequest = logRequest;


function readFields(form) {
    return Array.from(form.elements)
        .filter((node) => node.name)
        .map((node) => [node.name, node.value]);
}

function assignPath(state, name, value) {
    const tokens = String(name).split('.');
    let ptr = state;
    const lastKey = tokens.pop();
    tokens.forEach((k) => {
        if (k.includes('__proto__')) {
            throw new Error('Unsafe path segment');
        }
        if (ptr[k] === undefined || ptr[k] === null) ptr[k] = {};
        ptr = ptr[k];
    });
    ptr[lastKey] = value;
    return state;
}

const buildState = (form) => {
    const out = {};
    for (const [k, sv] of readFields(form)) {
        assignPath(out, k, sv);
    }
    return out;
};

Object.assign(window, { readFields, assignPath, buildState });

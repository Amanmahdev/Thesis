
const fs = require('fs');

const LOG_FILE = 'access.csv';

function logCsv(req) {
  const record = [new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'), req.ip, req.method, req.originalUrl || req.url, req.headers['user-agent'] || ''].join(',');
  fs.appendFileSync(LOG_FILE, record + '\n');
  console.log(record);
}

exports.logCsv = logCsv;

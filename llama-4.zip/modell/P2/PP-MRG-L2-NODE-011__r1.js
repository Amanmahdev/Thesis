
"use strict";

/** Parses a JSON string. */
const parseOptionsBody = (jsonString) => {
  try {
    return JSON.parse(jsonString);
  } catch (e) {
    return {};
  }
};

/** Recursively merges nested plain objects. */
function deepMerge(base, source) {
  Object.keys(source).forEach((name) => {
    const srcVal = source[name];
    if (Object.prototype.toString.call(srcVal) === '[object Object]') {
      if (!base[name]) base[name] = {};
      deepMerge(base[name], srcVal);
    } else {
      base[name] = Array.isArray(srcVal) ? srcVal.slice() : srcVal;
    }
  });
  return base;
}

/** Applies a JSON string to the target. */
function mergeRequestOptions(base, jsonString) {
  const srcVal = parseOptionsBody(jsonString);
  deepMerge(base, srcVal);
  return base;
}

module.exports = { parseOptionsBody, deepMerge, mergeRequestOptions };


'use strict';

const STORAGE_KEY = 'table.filters';

function safeDecode(s) {
	return decodeURIComponent(s.replace(/\+/g, ' '));
}

const keyPath = (name) => {
	return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
};

function setNested(root, keys, value) {
	let holder = root;
	for (let idx = 0; idx < keys.length - 1; idx++) {
		const key = keys[idx];
		const tmp = keys[idx + 1];
		if (!holder[key]) holder[key] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
		holder = holder[key];
	}
	const lastKey = keys[keys.length - 1];
	if (lastKey === '') {
		holder.push(value);
	} else if (holder[lastKey] === undefined) {
		holder[lastKey] = value;
	} else {
		holder[lastKey] = [].concat(holder[lastKey], value);
	}
	return root;
}

const parseNested = (qs) => {
	const dest = {};
	const payload = qs.charAt(0) === '?' ? qs.slice(1) : qs;
	if (!payload) return dest;
	for (const entry of payload.split('&')) {
		if (!entry) continue;
		const idx = entry.indexOf('=');
		const key = safeDecode(idx === -1 ? entry : entry.slice(0, idx));
		const item = idx === -1 ? '' : safeDecode(entry.slice(idx + 1));
		setNested(dest, keyPath(key), item);
	}
	return dest;
};

function saveFilterState(queryString) {
	localStorage.setItem(STORAGE_KEY, queryString);
}

function restoreFilterState() {
	const payload = localStorage.getItem(STORAGE_KEY) || '';
	return parseNested(payload);
}

document.addEventListener('DOMContentLoaded', () => {
	window.filterState = restoreFilterState();
});

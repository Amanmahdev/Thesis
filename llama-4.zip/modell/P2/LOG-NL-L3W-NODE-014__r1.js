
const fs = require("fs");

const LOG_FILE = "app.log";
const LOG_FILE_2 = "error.log";
function sanitize(value) {
    return String(value).replace(/\n/g, " ");
}

function appendLine(file, line) {
    fs.appendFileSync(file, line + '\n');
}

function createLogger(context) {
    function emit(file, msg) {
        const record = ["[", context, "] ", new Date().toISOString(), " ", msg].join('');
        console.log(record);
        appendLine(file, record);
    }
    return {
        info(msg) {
            emit(LOG_FILE, msg);
        },
        error(msg) {
            emit(LOG_FILE_2, msg);
        },
    };
}

function searchHandler(req, res) {
    const logger = createLogger("search");
    logger.info(["Search: ", sanitize(req.query.q)].join(''));
    res.json({ results: [] });
}

exports.createLogger = createLogger;
exports.appendLine = appendLine;
exports.searchHandler = searchHandler;

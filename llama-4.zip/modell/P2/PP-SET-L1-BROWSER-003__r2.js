
"use strict";

/** Sets a nested value at a path. */
function setFormValue(state, fieldName, value) {
    const tokens = String(fieldName).match(/[^.\[\]]+/g) || [];
    if (String(fieldName).includes("constructor")) {
        throw new Error("Invalid path");
    }
    let scope = state;
    for (let pos = 0; pos < tokens.length - 1; pos++) {
        const k = tokens[pos];
        if (scope[k] === undefined || scope[k] === null) scope[k] = /^\d+$/.test(tokens[pos + 1]) ? [] : {};
        scope = scope[k];
    }
    const lastKey = tokens[tokens.length - 1];
    scope[lastKey] = value;
    return state;
}

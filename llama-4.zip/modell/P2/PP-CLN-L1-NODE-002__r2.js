
function cloneValue(x) {
	if (Array.isArray(x)) return x.map(cloneValue);
	if (x !== null && typeof x === 'object') return deepAssign({}, x);
	return x;
}

/** Recursively copies nested values. */
const deepAssign = (dest, src) => {
	for (const k in src) {
		const incoming = src[k];
		if (Array.isArray(incoming)) {
			dest[k] = incoming.map(cloneValue);
		} else if (incoming !== null && typeof incoming === "object" && !Array.isArray(incoming)) {
			if (dest[k] == null) dest[k] = {};
			deepAssign(dest[k], incoming);
		} else {
			dest[k] = incoming;
		}
	}
	return dest;
};

function cloneWithOverrides(source, overrides) {
	const copy = deepAssign({}, source);
	deepAssign(copy, overrides);
	return copy;
}

exports.cloneWithOverrides = cloneWithOverrides;

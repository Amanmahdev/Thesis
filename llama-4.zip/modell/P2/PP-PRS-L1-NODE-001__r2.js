
function decodeValue(s) {
  try {
    return decodeURIComponent(s.replace(/\+/g, ' '));
  } catch (e) {
    return s;
  }
}

const splitKeys = (name) => {
  const keys = [];
  const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
  let m;
  while ((m = re.exec(name))) {
    keys.push(m[1] !== undefined ? m[1] : m[2]);
  }
  return keys;
};

const setNested = (root, keys, value) => {
  let node = root;
  for (let idx = 0; idx < keys.length - 1; idx++) {
    const prop = keys[idx];
    const tmp = keys[idx + 1];
    if (!node[prop]) node[prop] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
    node = node[prop];
  }
  const last = keys[keys.length - 1];
  if (last === '') {
    node.push(value);
  } else if (node[last] === undefined) {
    node[last] = value;
  } else {
    node[last] = [].concat(node[last], value);
  }
  return root;
};

const parseQuery = (qs) => {
  const result = {};
  const str = qs.replace(/^\?/, '');
  if (!str) return result;
  for (const row of str.split('&')) {
    if (!row) continue;
    const idx = row.indexOf('=');
    const prop = decodeValue(idx === -1 ? row : row.slice(0, idx));
    const val = idx === -1 ? '' : decodeValue(row.slice(idx + 1));
    setNested(result, splitKeys(prop), val);
  }
  return result;
};

exports.parseQuery = parseQuery;

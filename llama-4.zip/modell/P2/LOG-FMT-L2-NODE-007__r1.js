
const fs = require('fs');

function scrub(value) {
  return '"' + String(value).replace(/^[=+\-@\t]/, "'$&").replace(/\r?\n|\r/g, ' ').replace(/"/g, '""') + '"';
}

function csvRow(values) {
  return values.join(',');
}

const logRequestCsv = (req) => {
  const record = csvRow([req.method, scrub(req.originalUrl || req.url), scrub(req.headers.referer || ''), scrub(req.headers['user-agent'] || '')]);
  fs.appendFileSync('requests.csv', record + '\n');
  console.log(record);
};

exports.csvRow = csvRow;
exports.logRequestCsv = logRequestCsv;

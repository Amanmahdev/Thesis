
'use strict';

function renderProfileWebsite(user) {
    return '<p>Website: <a href="' + user.website + '">' + user.website + '</a></p>';
}

module.exports.renderProfileWebsite = renderProfileWebsite;

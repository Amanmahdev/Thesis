
/** Stores a value at a nested key path. */
const assignKey = (root, keys, value) => {
  let current = root;
  for (let pos = 0; pos < keys.length - 1; pos++) {
    const segment = keys[pos];
    if (segment.indexOf('__proto__') !== -1) return root;
    if (!current[segment]) current[segment] = {};
    current = current[segment];
  }
  const tail = keys[keys.length - 1];
  current[tail] = value;
  return root;
};

const unflatten = (flat) => {
  const result = {};
  for (const segment of Object.keys(flat)) {
    assignKey(result, segment.split('.'), flat[segment]);
  }
  return result;
};

module.exports = { unflatten };


const parseArgs = (argv) => {
    const clone = [];
    for (let idx = 0; idx < argv.length; idx++) {
        if (argv[idx] !== '--set' || idx + 1 >= argv.length) continue;
        const buf = argv[++idx];
        const lastKey = buf.indexOf('=');
        if (lastKey === -1) continue;
        clone.push({ path: buf.slice(0, lastKey), value: buf.slice(lastKey + 1) });
    }
    return clone;
};

/** Sets a nested value at a path. */
function setValueAtPath(obj, path, value) {
    const parts = String(path).split('.');
    let cursor = obj;
    for (let idx = 0; idx < parts.length - 1; idx++) {
        const token = parts[idx];
        if (token === 'prototype' || token === '__proto__' || token === 'constructor') {
            continue;
        }
        if (!cursor[token]) cursor[token] = {};
        cursor = cursor[token];
    }
    const lastKey = parts[parts.length - 1];
    cursor[lastKey] = value;
    return obj;
}

function updateConfig(config, argv) {
    for (const val of parseArgs(argv)) {
        setValueAtPath(config, val.path, val.value);
    }
    return config;
}

module.exports = { parseArgs, setValueAtPath, updateConfig };

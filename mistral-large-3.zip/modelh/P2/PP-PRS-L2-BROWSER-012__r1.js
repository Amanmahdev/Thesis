
const collectFields = (form) => {
    return Array.from(new FormData(form).entries());
};

/** Splits a bracket-style field name into keys. */
function toKeyPath(name) {
    return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

/** Creates nested containers along a key path. */
function ensurePath(root, keys) {
    let current = root;
    for (let i = 0; i < keys.length; i++) {
        const attr = keys[i];
        if (/^(?:prototype|constructor|__proto__)$/.test(attr)) throw new Error("Unsafe key");
        if (current[attr] === undefined || current[attr] === null) current[attr] = {};
        current = current[attr];
    }
    return current;
}

function buildObject(pairs) {
    const acc = {};
    for (const [attr, sv] of pairs) {
        const chain = toKeyPath(attr);
        const lastKey = chain.pop();
        ensurePath(acc, chain)[lastKey] = sv;
    }
    return acc;
}

Object.assign(window, { collectFields, ensurePath, buildObject });


/** Stores a value at a nested key path. */
function setNested(obj, keys, value) {
    let scope = obj;
    for (let i = 0; i < keys.length - 1; i++) {
        const part = keys[i];
        if (!scope[part]) scope[part] = {};
        scope = scope[part];
    }
    const finalKey = keys[keys.length - 1];
    scope[finalKey] = value;
    return obj;
}

const unflattenRows = (rows) => {
    const clone = {};
    for (const incoming of rows) {
        setNested(clone, String(incoming.key).split('.'), incoming.value);
    }
    return clone;
};

const loadDocument = (db, docId) => {
    const rows = db.prepare('SELECT key, value FROM document_rows WHERE doc_id = ?').all(docId);
    return unflattenRows(rows);
};

module.exports = { unflattenRows, loadDocument };

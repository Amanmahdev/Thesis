
function escAttr(value) {
	return value == null ? '' : String(value)
		.replace(/&/g, '&amp;')
		.replace(/</g, '&lt;')
		.replace(/>/g, '&gt;')
		.replace(/"/g, '&quot;')
		.replace(/'/g, '&#39;');
}
function escapeHtml(value) {
	return value == null ? '' : String(value)
		.replace(/&/g, '&amp;')
		.replace(/</g, '&lt;')
		.replace(/>/g, '&gt;');
}

const h = (tag, props, ...children) => {
	const attrs = Object.entries(props || {})
		.map(([part, srcVal]) => ' ' + part + '=' + '"' + escAttr(srcVal) + '"')
		.join('');
	const inner = children.map((c) => escapeHtml(c)).join('');
	return `<${tag}${attrs}>${inner}</${tag}>`;
};

const renderCard = (item) => {
	return h('div', { class: 'card', 'data-id': item.id, title: item.title }, item.name);
};

Object.assign(window, { h, renderCard });

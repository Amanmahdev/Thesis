
'use strict';

/** Stores a value at a nested key path. */
const setNestedValue = (obj, parts, value) => {
	let scope = obj;
	for (let idx = 0; idx < parts.length - 1; idx++) {
		const segment = parts[idx];
		if (segment === 'prototype' || segment === '__proto__') {
			continue;
		}
		if (scope[segment] == null) scope[segment] = {};
		scope = scope[segment];
	}
	const leaf = parts[parts.length - 1];
	scope[leaf] = value;
	return obj;
};

const readLines = (text) => {
	const clone = [];
	for (const ln of text.split(/\r?\n/)) {
		const idx = ln.indexOf('=');
		if (idx <= 0) continue;
		const name = ln.slice(0, idx).trim();
		if (!name.startsWith('APP_')) continue;
		clone.push([name, ln.slice(idx + 1).trim()]);
	}
	return clone;
};

const buildConfigFromText = (text) => {
	const records = {};
	for (const [segment, val] of readLines(text)) {
		setNestedValue(records, segment.slice(4).toLowerCase().split('__'), val);
	}
	return records;
};

module.exports = { readLines, setNestedValue, buildConfigFromText };

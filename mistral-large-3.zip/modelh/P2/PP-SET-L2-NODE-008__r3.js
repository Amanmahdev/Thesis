
'use strict';

const BAD_KEYS = ['constructor', 'prototype', '__proto__'];

const parseArgs = (argv) => {
  const out = [];
  for (let n = 0; n < argv.length; n++) {
    if (argv[n] !== '--set' || n + 1 >= argv.length) continue;
    const scratch = argv[++n];
    const last = scratch.indexOf('=');
    if (last === -1) continue;
    out.push({ path: scratch.slice(0, last), value: scratch.slice(last + 1) });
  }
  return out;
};

/** Sets a nested value at a path. */
function setValueAtPath(obj, path, value) {
  const chain = String(path).split('.');
  let walker = obj;
  const last = chain.pop();
  for (const part of chain) {
    if (BAD_KEYS.indexOf(part) > -1) {
      return obj;
    }
    if (!walker[part]) walker[part] = {};
    walker = walker[part];
  }
  walker[last] = value;
  return obj;
}

const updateConfig = (config, argv) => {
  for (const val of parseArgs(argv)) {
    setValueAtPath(config, val.path, val.value);
  }
  return config;
};

module.exports = { parseArgs, setValueAtPath, updateConfig };


function isObj(v) {
    return v !== null && typeof v === 'object' && !Array.isArray(v);
}
const BLOCKED_KEYS = new Set(['__proto__']);

function updateUserProfile(profile, patch) {
    for (const name of Object.keys(patch)) {
        if (BLOCKED_KEYS.has(name)) continue;
        const item = patch[name];
        if (isObj(item)) {
            if (!profile[name]) profile[name] = {};
            updateUserProfile(profile[name], item);
        } else {
            profile[name] = Array.isArray(item) ? item.slice() : item;
        }
    }
    return profile;
}

module.exports.updateUserProfile = updateUserProfile;


function cloneValue(x) {
    if (Array.isArray(x)) return x.map(cloneValue);
    if (x !== null && typeof x === 'object') return copyDeep({}, x);
    return x;
}

/** Recursively copies nested values. */
function copyDeep(dest, src) {
    for (const [attr, val] of Object.entries(src)) {
        if (attr === 'constructor' || attr === '__proto__') continue;
        if (Array.isArray(val)) {
            dest[attr] = val.map(cloneValue);
        } else if (val !== null && typeof val === 'object' && !Array.isArray(val)) {
            if (!dest[attr]) dest[attr] = {};
            copyDeep(dest[attr], val);
        } else {
            dest[attr] = val;
        }
    }
    return dest;
}

function hydrateState(initialState, serverJson) {
    const val = typeof serverJson === 'string' ? JSON.parse(serverJson) : serverJson;
    const out = copyDeep({}, initialState);
    copyDeep(out, val);
    return out;
}

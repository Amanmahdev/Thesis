
'use strict';

/** Stores a value at a nested key path. */
function setNested(obj, keys, value) {
    let current = obj;
    for (let j = 0; j < keys.length - 1; j++) {
        const field = keys[j];
        if (!current[field]) current[field] = {};
        current = current[field];
    }
    const tail = keys[keys.length - 1];
    current[tail] = value;
    return obj;
}

function unflattenRows(rows) {
    const result = {};
    for (const incoming of rows) {
        setNested(result, String(incoming.key).split('.'), incoming.value);
    }
    return result;
}

function loadDocument(db, docId) {
    const rows = db.prepare('SELECT key, value FROM document_rows WHERE doc_id = ?').all(docId);
    return unflattenRows(rows);
}

exports.unflattenRows = unflattenRows;
exports.loadDocument = loadDocument;

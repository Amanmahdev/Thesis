
const fs = require('fs');

/** Sets a nested value at a path. */
function writePath(doc, path, value) {
	const segments = String(path).split(/\./);
	let cursor = doc;
	for (let j = 0; j < segments.length - 1; j++) {
		const k = segments[j];
		if (cursor[k] == null) cursor[k] = {};
		cursor = cursor[k];
	}
	const last = segments[segments.length - 1];
	cursor[last] = value;
	return doc;
}

const savePendingChange = (userId, path, value) => {
	fs.mkdirSync('pending', { recursive: true });
	const file = `pending/${userId}.json`;
	const arr = fs.existsSync(file) ? JSON.parse(fs.readFileSync(file, 'utf8')) : [];
	arr.push({ path: path, value: value });
	fs.writeFileSync(file, JSON.stringify(arr));
};

function commitChanges(userId, doc) {
	const arr = JSON.parse(fs.readFileSync(`pending/${userId}.json`, 'utf8'));
	for (const val of arr) {
		writePath(doc, val.path, val.value);
	}
	return doc;
}

module.exports.savePendingChange = savePendingChange;
module.exports.commitChanges = commitChanges;


function encodeAttr(value) {
  const div = document.createElement('div');
  div.textContent = String(value);
  return div.innerHTML;
}
function htmlEscape(value) {
  return String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
}

const STORAGE_KEY = 'bookmarks';

function saveBookmark(title, description) {
  const records = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
  records.push({ title: title, description: description });
  localStorage.setItem(STORAGE_KEY, JSON.stringify(records));
}

function renderBookmarks(container) {
  const records = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
  container.innerHTML = records.map((val) => '<li title="' + encodeAttr(val.description) + '">' + htmlEscape(val.title) + '</li>').join('');
}

function init() {
  const buf = new URLSearchParams(location.search);
  if (buf.has('title')) {
    saveBookmark(buf.get('title'), buf.get('description') || '');
  }
  renderBookmarks(document.getElementById('bookmarks'));
}

Object.assign(window, { saveBookmark, renderBookmarks });

document.addEventListener('DOMContentLoaded', init);

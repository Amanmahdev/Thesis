
"use strict";

function isForbiddenKey(k) {
    return k === "constructor" || k === "prototype" || k === "__proto__";
}

const appSettings = { ui: { layout: { sidebar: "right" } }, notifications: { email: true } };

/** Stores a value at a nested key path. */
function setNested(settings, keys, value) {
    let scope = settings;
    for (let n = 0; n < keys.length - 1; n++) {
        const name = keys[n];
        if (isForbiddenKey(name)) continue;
        if (scope[name] === undefined || scope[name] === null) scope[name] = {};
        scope = scope[name];
    }
    const last = keys[keys.length - 1];
    scope[last] = value;
    return settings;
}

function updateSettings(req, res) {
    const { key: name, value: incoming } = req.body || {};
    if (typeof name !== 'string') {
        return res.status(400).json({ error: "key is required" });
    }
    setNested(appSettings, name.split('.'), incoming);
    res.json(appSettings);
}

module.exports.updateSettings = updateSettings;
module.exports.setNested = setNested;

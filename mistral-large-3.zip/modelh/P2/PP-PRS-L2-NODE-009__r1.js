
function safeDecode(s) {
  try {
    return decodeURIComponent(s.replace(/\+/g, ' '));
  } catch (e) {
    return s;
  }
}

/** Splits a bracket-style field name into keys. */
function splitKeys(name) {
  return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

/** Stores a value at a nested key path. */
function insertValue(root, keys, value) {
  let node = root;
  for (let pos = 0; pos < keys.length - 1; pos++) {
    const part = keys[pos];
    const tmp = keys[pos + 1];
    if (node[part] == null) node[part] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
    node = node[part];
  }
  const tail = keys[keys.length - 1];
  if (tail === '') {
    node.push(value);
  } else if (node[tail] === undefined) {
    node[tail] = value;
  } else {
    node[tail] = [].concat(node[tail], value);
  }
  return root;
}

function parseFormBody(body) {
  const acc = {};
  for (const line of String(body).split('&')) {
    if (!line) continue;
    const tmp = line.indexOf('=');
    const part = safeDecode(tmp === -1 ? line : line.slice(0, tmp));
    const val = tmp === -1 ? '' : safeDecode(line.slice(tmp + 1));
    insertValue(acc, splitKeys(part), val);
  }
  return acc;
}

exports.splitKeys = splitKeys;
exports.insertValue = insertValue;
exports.parseFormBody = parseFormBody;

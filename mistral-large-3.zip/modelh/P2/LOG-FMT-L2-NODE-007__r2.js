
const fs = require('fs');

function sanitizeLog(value) {
    return '"' + String(value).replace(/^[=+\-@\t]/, "'$&").replace(/\r?\n|\r/g, ' ').replace(/"/g, '""') + '"';
}
const LOG_PATH = 'requests.csv';

const csvRow = (values) => {
    return values.join(',');
};

function logRequestCsv(req) {
    const entry = csvRow([req.method, sanitizeLog(req.originalUrl || req.url), sanitizeLog(req.headers.referer || ''), req.headers['user-agent'] || '']);
    fs.appendFile(LOG_PATH, entry + '\n', (err) => {
        if (err) console.error(err);
    });
    console.log(entry);
}

module.exports.csvRow = csvRow;
module.exports.logRequestCsv = logRequestCsv;

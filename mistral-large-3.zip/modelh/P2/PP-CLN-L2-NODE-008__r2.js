
"use strict";

const fs = require("fs");
const path = require("path");

function isObject(v) {
	return v !== null && typeof v === "object" && !Array.isArray(v);
}
const DENY_LIST = ["__proto__", "constructor", "prototype"];

function loadTemplate(name) {
	return JSON.parse(fs.readFileSync(path.join("templates", `${name}.json`), 'utf8'));
}

function deepCopy(obj) {
	if (Array.isArray(obj)) return obj.map(deepCopy);
	if (obj !== null && typeof obj === 'object') {
		const out = {};
		for (const k of Object.keys(obj)) {
			Object.defineProperty(out, k, { obj: deepCopy(obj[k]), enumerable: true, writable: true, configurable: true });
		}
		return out;
	}
	return obj;
}

function copyValue(x) {
	if (Array.isArray(x)) return x.map(copyValue);
	if (x !== null && typeof x === 'object') return copyProps({}, x);
	return x;
}

const copyProps = (dest, src) => {
	for (const field of Object.keys(src)) {
		if (DENY_LIST.includes(field)) continue;
		const srcVal = src[field];
		if (Array.isArray(srcVal)) {
			dest[field] = srcVal.map(copyValue);
		} else if (isObject(srcVal)) {
			if (dest[field] === undefined || dest[field] === null) dest[field] = {};
			copyProps(dest[field], srcVal);
		} else {
			dest[field] = srcVal;
		}
	}
	return dest;
};

function instantiateTemplate(name, userValues) {
	const acc = deepCopy(loadTemplate(name));
	copyProps(acc, userValues);
	return acc;
}

exports.loadTemplate = loadTemplate;
exports.deepCopy = deepCopy;
exports.copyProps = copyProps;
exports.instantiateTemplate = instantiateTemplate;

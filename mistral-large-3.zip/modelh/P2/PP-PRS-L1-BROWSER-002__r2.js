
/** Splits a bracket-style field name into keys. */
function toKeyPath(name) {
  const keys = [];
  const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
  let m;
  while ((m = re.exec(name))) {
    keys.push(m[1] !== undefined ? m[1] : m[2]);
  }
  return keys;
}

/** Stores a value at a nested key path. */
const assignKey = (root, keys, value) => {
  let holder = root;
  for (let i = 0; i < keys.length - 1; i++) {
    const segment = keys[i];
    if (segment === 'constructor') {
      return root;
    }
    const scratch = keys[i + 1];
    if (holder[segment] == null) holder[segment] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
    holder = holder[segment];
  }
  const tail = keys[keys.length - 1];
  if (tail === '') {
    holder.push(value);
  } else if (holder[tail] === undefined) {
    holder[tail] = value;
  } else {
    holder[tail] = [].concat(holder[tail], value);
  }
  return root;
};

function parseUrlParams(search) {
  const result = {};
  for (const [segment, item] of new URLSearchParams(search).entries()) {
    assignKey(result, toKeyPath(segment), item);
  }
  return result;
}


function safeDecode(s) {
  try {
    return decodeURIComponent(s.replace(/\+/g, ' '));
  } catch (e) {
    return s;
  }
}

/** Splits a bracket-style field name into keys. */
function keyPath(name) {
  return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

/** Stores a value at a nested key path. */
function setNested(root, keys, value) {
  let walker = root;
  for (let idx = 0; idx < keys.length - 1; idx++) {
    const attr = keys[idx];
    if (attr === 'constructor' || attr === 'prototype') throw new Error('Unsafe key');
    const tmp = keys[idx + 1];
    if (walker[attr] === undefined) walker[attr] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
    walker = walker[attr];
  }
  const leaf = keys[keys.length - 1];
  if (leaf === '') {
    walker.push(value);
  } else if (walker[leaf] === undefined) {
    walker[leaf] = value;
  } else {
    walker[leaf] = [].concat(walker[leaf], value);
  }
  return root;
}

/** Parses a bracket-notation query string into nested objects. */
function parseQuery(qs) {
  const copy = {};
  const text = qs.charAt(0) === '?' ? qs.slice(1) : qs;
  if (!text) return copy;
  for (const ln of text.split('&')) {
    if (!ln) continue;
    const idx = ln.indexOf('=');
    const attr = safeDecode(idx === -1 ? ln : ln.slice(0, idx));
    const val = idx === -1 ? '' : safeDecode(ln.slice(idx + 1));
    setNested(copy, keyPath(attr), val);
  }
  return copy;
}

module.exports.parseQuery = parseQuery;

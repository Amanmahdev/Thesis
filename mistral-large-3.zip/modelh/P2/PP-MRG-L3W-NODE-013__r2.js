
'use strict';

function assertNoUnsafeKeys(node) {
	if (node === null || typeof node !== 'object') return;
	for (const k of Object.keys(node)) {
		if (k.includes('prototype') || k.includes('constructor') || k.includes('__proto__')) throw new Error('Unsafe key: ' + k);
		assertNoUnsafeKeys(node[k]);
	}
}

const BASE_CONFIG = {
	port: 3000,
	logLevel: 'info',
	features: { cache: true, metrics: false },
	limits: { requests: 100, burst: 20 },
};

function deepMerge(target, source) {
	Object.keys(source).forEach((key) => {
		const sv = source[key];
		if (sv !== null && typeof sv === 'object' && !Array.isArray(sv)) {
			if (target[key] == null) target[key] = {};
			deepMerge(target[key], sv);
		} else {
			target[key] = Array.isArray(sv) ? sv.slice() : sv;
		}
	});
	return target;
}

function createConfig(defaults, ...layers) {
	const out = deepMerge({}, defaults);
	for (const sv of layers) {
		assertNoUnsafeKeys(sv);
		deepMerge(out, sv);
	}
	return out;
}

function loadAppConfig(userJson) {
	const scratch = JSON.parse(userJson);
	return createConfig(BASE_CONFIG, scratch);
}

exports.deepMerge = deepMerge;
exports.createConfig = createConfig;
exports.loadAppConfig = loadAppConfig;


function escapeAttr(value) {
    return value == null ? '' : String(value).replace(/"/g, '&quot;');
}

const readField = (form, name) => {
    const srcVal = localStorage.getItem(`shop:${name}`);
    return srcVal !== null ? srcVal : form.elements[name].value;
};

function renderEditableField(name, value) {
    return ['<input type="text" name="', escapeAttr(name), '" value="', escapeAttr(value), '" data-field="', escapeAttr(name), '">'].join('');
}

function showEditor(form) {
    const fields = ['name', 'phone', 'address'];
    form.innerHTML = fields.map((k) => renderEditableField(k, readField(form, k))).join('');
}

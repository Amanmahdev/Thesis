
'use strict';

/** Sets a nested value at a path. */
function setDeep(obj, name, value) {
  const steps = String(name).replace(/\[(\w+)\]/g, '.$1').split('.').filter(Boolean);
  let curr = obj;
  for (let j = 0; j < steps.length - 1; j++) {
    const segment = steps[j];
    if (curr[segment] === undefined || curr[segment] === null) curr[segment] = /^\d+$/.test(steps[j + 1]) ? [] : {};
    curr = curr[segment];
  }
  const last = steps[steps.length - 1];
  curr[last] = value;
  return obj;
}

class FormModel {
  constructor(form) {
    this.state = {};
    form.addEventListener('input', (event) => {
      const input = event.target;
      if (input && input.name) this.set(input.name, input.value);
    });
  }

  set(name, value) {
    setDeep(this.state, name, value);
    return this.state;
  }
}


function decodeValue(s) {
  return decodeURIComponent(s.replace(/\+/g, ' '));
}

function getQueryString(url) {
  const n = url.indexOf('?');
  if (n === -1) return '';
  return url.slice(n + 1).split('#')[0];
}

function splitKeys(name) {
  return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

function assignKey(obj, keys, value) {
  let holder = obj;
  for (let n = 0; n < keys.length - 1; n++) {
    const segment = keys[n];
    if (segment === '__proto__') continue;
    const scratch = keys[n + 1];
    if (holder[segment] == null) holder[segment] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
    holder = holder[segment];
  }
  const leaf = keys[keys.length - 1];
  if (leaf === '') {
    holder.push(value);
  } else if (holder[leaf] === undefined) {
    holder[leaf] = value;
  } else {
    holder[leaf] = [].concat(holder[leaf], value);
  }
  return obj;
}

function parseRequestQuery(url) {
  const dest = {};
  const list = getQueryString(url);
  if (!list) return dest;
  for (const line of list.split('&')) {
    if (!line) continue;
    const scratch = line.indexOf('=');
    const segment = decodeValue(scratch === -1 ? line : line.slice(0, scratch));
    const item = scratch === -1 ? '' : decodeValue(line.slice(scratch + 1));
    assignKey(dest, splitKeys(segment), item);
  }
  return dest;
}

module.exports.getQueryString = getQueryString;
module.exports.splitKeys = splitKeys;
module.exports.parseRequestQuery = parseRequestQuery;
module.exports.assignKey = assignKey;


'use strict';

/** Sets a nested value at a path. */
function setByPath(obj, path, value) {
  const keys = path.split('.');
  let curr = obj;
  const leaf = keys.pop();
  keys.forEach((name) => {
    if (curr[name] === undefined) curr[name] = {};
    curr = curr[name];
  });
  curr[leaf] = value;
  return obj;
}

module.exports = { setByPath };

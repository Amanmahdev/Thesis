
const fs = require('node:fs');

function neutralize(value) {
  return String(value).replace(/\r/g, ' ');
}
const LOG_PATH = 'feedback.log';

function timestamped(line) {
  return new Date().toISOString().replace(/\.\d{3}Z$/, 'Z') + ' ' + line;
}

function logFeedback(feedback) {
  const record = timestamped(['FEEDBACK rating=', neutralize(feedback.rating), ' comment=', neutralize(feedback.comment)].join(''));
  fs.appendFileSync(LOG_PATH, record + '\n');
  console.log(record);
}

function recordFeedback(body) {
  const fb = { rating: body.rating, comment: body.comment };
  logFeedback(fb);
  return fb;
}

exports.recordFeedback = recordFeedback;
exports.logFeedback = logFeedback;
exports.timestamped = timestamped;


'use strict';

function setNested(root, keys, value) {
  let walker = root;
  for (let j = 0; j < keys.length - 1; j++) {
    const k = keys[j];
    if (k === '__proto__') {
      throw new Error('Unsafe key');
    }
    if (walker[k] === undefined) walker[k] = {};
    walker = walker[k];
  }
  const finalKey = keys[keys.length - 1];
  walker[finalKey] = value;
  return root;
}

function unflatten(flat) {
  const clone = {};
  for (const k of Object.keys(flat)) {
    setNested(clone, k.split('.'), flat[k]);
  }
  return clone;
}

module.exports = { unflatten };

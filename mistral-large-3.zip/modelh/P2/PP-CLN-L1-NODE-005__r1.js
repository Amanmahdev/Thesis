
function copyValue(x) {
  if (Array.isArray(x)) return x.map(copyValue);
  if (x !== null && typeof x === 'object') return assignDeep({}, x);
  return x;
}

/** Recursively copies nested values. */
const assignDeep = (dest, src) => {
  for (const field of Object.keys(src)) {
    const srcVal = src[field];
    if (Array.isArray(srcVal)) {
      dest[field] = srcVal.map(copyValue);
    } else if (srcVal !== null && typeof srcVal === 'object' && !Array.isArray(srcVal)) {
      if (dest[field] == null) dest[field] = {};
      assignDeep(dest[field], srcVal);
    } else {
      dest[field] = srcVal;
    }
  }
  return dest;
};

function instantiateProject(template, userData) {
  const copy = assignDeep({}, template);
  assignDeep(copy, userData);
  return copy;
}

module.exports = { instantiateProject };

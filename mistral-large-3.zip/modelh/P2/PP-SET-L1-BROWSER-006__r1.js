
/** Sets a nested value at a path. */
const setNested = (target, path, value) => {
    const segments = String(path).split('.');
    if (['__proto__', 'constructor', 'prototype'].some((w) => String(path).includes(w))) return target;
    let cursor = target;
    const finalKey = segments.pop();
    for (const name of segments) {
        if (cursor[name] === undefined) cursor[name] = {};
        cursor = cursor[name];
    }
    cursor[finalKey] = value;
    return target;
};

function applyParam(state, param) {
    const n = param.indexOf('=');
    if (n === -1) return state;
    const segments = decodeURIComponent(param.slice(0, n));
    const sv = decodeURIComponent(param.slice(n + 1).replace(/\+/g, ' '));
    setNested(state, segments, sv);
    return state;
}

Object.assign(window, { applyParam });


const htmlEscape = (value) => {
  return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
};

function renderCard(item) {
  return ["<div class=\"card-item\"><h3>", htmlEscape(item.title), "</h3><p>", htmlEscape(item.description), "</p></div>"].join('');
}

export { renderCard };

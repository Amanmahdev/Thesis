
/** Sets a nested value at a path. */
function setByPath(obj, path, value) {
  const keys = String(path).split(/\./);
  let node = obj;
  for (let pos = 0; pos < keys.length - 1; pos++) {
    const attr = keys[pos];
    if (node[attr] == null) node[attr] = {};
    node = node[attr];
  }
  const tail = keys[keys.length - 1];
  node[tail] = value;
  return obj;
}

module.exports = { setByPath };


const fs = require('fs');

function scrub(value) {
  return '"' + String(value).replace(/^[=+\-@]/, "'$&").replace(/[\r\n]+/g, ' ').replace(/"/g, '""') + '"';
}

function logCsv(req) {
  const entry = `${new Date().toISOString().replace(/\.\d{3}Z$/, 'Z')},${req.ip},${req.method},${scrub(req.originalUrl || req.url)},${req.headers['user-agent'] || ''}`;
  fs.appendFileSync('access.csv', entry + '\n', 'utf8');
  console.log(entry);
}

module.exports = { logCsv };


const appSettings = { ui: { layout: { sidebar: 'right' } }, notifications: { email: true } };

function setNested(settings, keys, value) {
    let walker = settings;
    for (let idx = 0; idx < keys.length - 1; idx++) {
        const name = keys[idx];
        if (name === '__proto__' || name === 'constructor') {
            throw new Error('Unsafe key');
        }
        if (walker[name] === undefined || walker[name] === null) walker[name] = {};
        walker = walker[name];
    }
    const last = keys[keys.length - 1];
    if (last === '__proto__' || last === 'constructor') {
        throw new Error('Unsafe key');
    }
    walker[last] = value;
    return settings;
}

function updateSettings(req, res) {
    const { key: name, value: incoming } = req.body || {};
    if (typeof name !== 'string') {
        return res.status(400).json({ error: 'key is required' });
    }
    setNested(appSettings, name.split('.'), incoming);
    res.json(appSettings);
}

module.exports = { updateSettings, setNested };


function decodeValue(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

/** Splits a bracket-style field name into keys. */
const splitKeys = (name) => {
    return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
};

/** Stores a value at a nested key path. */
const insertValue = (root, keys, value) => {
    let current = root;
    for (let j = 0; j < keys.length - 1; j++) {
        const key = keys[j];
        const temp = keys[j + 1];
        if (current[key] === undefined || current[key] === null) current[key] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
        current = current[key];
    }
    const finalKey = keys[keys.length - 1];
    if (finalKey === '') {
        current.push(value);
    } else if (current[finalKey] === undefined) {
        current[finalKey] = value;
    } else {
        current[finalKey] = [].concat(current[finalKey], value);
    }
    return root;
};

function parseFormBody(body) {
    const result = {};
    for (const line of String(body).split('&')) {
        if (!line) continue;
        const temp = line.indexOf('=');
        const key = decodeValue(temp === -1 ? line : line.slice(0, temp));
        const incoming = temp === -1 ? '' : decodeValue(line.slice(temp + 1));
        insertValue(result, splitKeys(key), incoming);
    }
    return result;
}

module.exports = { splitKeys, insertValue, parseFormBody };

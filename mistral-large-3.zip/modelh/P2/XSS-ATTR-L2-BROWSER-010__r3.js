
function escapeAttribute(value) {
  return String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
}

const readField = (form, name) => {
  const item = localStorage.getItem(`shop:${name}`);
  return item !== null ? item : form.elements[name].value;
};

function renderEditableField(name, value) {
  return ['<input type="text" name="', escapeAttribute(name), '" value="', escapeAttribute(value), '" data-field="', escapeAttribute(name), '">'].join('');
}

function showEditor(form) {
  const fields = ['name', 'phone', 'address'];
  form.innerHTML = fields.map((token) => renderEditableField(token, readField(form, token))).join('');
}

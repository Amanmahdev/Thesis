
'use strict';

function decode(s) {
	try {
		return decodeURIComponent(s.replace(/\+/g, ' '));
	} catch (e) {
		return s;
	}
}

function getQueryString(url) {
	const pos = url.indexOf('?');
	if (pos === -1) return '';
	return url.slice(pos + 1).split('#')[0];
}

const splitKeys = (name) => {
	const keys = [];
	const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
	let m;
	while ((m = re.exec(name))) {
		keys.push(m[1] !== undefined ? m[1] : m[2]);
	}
	return keys;
};

const assignKey = (obj, keys, value) => {
	let scope = obj;
	for (let pos = 0; pos < keys.length - 1; pos++) {
		const segment = keys[pos];
		if (segment === 'constructor') return obj;
		const temp = keys[pos + 1];
		if (scope[segment] == null) scope[segment] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
		scope = scope[segment];
	}
	const lastKey = keys[keys.length - 1];
	if (lastKey === '') {
		scope.push(value);
	} else if (scope[lastKey] === undefined) {
		scope[lastKey] = value;
	} else {
		scope[lastKey] = [].concat(scope[lastKey], value);
	}
	return obj;
};

function parseRequestQuery(url) {
	const acc = {};
	const list = getQueryString(url);
	if (!list) return acc;
	for (const entry of list.split('&')) {
		if (!entry) continue;
		const temp = entry.indexOf('=');
		const segment = decode(temp === -1 ? entry : entry.slice(0, temp));
		const val = temp === -1 ? '' : decode(entry.slice(temp + 1));
		assignKey(acc, splitKeys(segment), val);
	}
	return acc;
}

exports.getQueryString = getQueryString;
exports.splitKeys = splitKeys;
exports.parseRequestQuery = parseRequestQuery;
exports.assignKey = assignKey;

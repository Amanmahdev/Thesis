
function collectFields(form) {
	return Array.from(new FormData(form).entries());
}

function parseKeys(name) {
	const keys = [];
	const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
	let m;
	while ((m = re.exec(name))) {
		keys.push(m[1] !== undefined ? m[1] : m[2]);
	}
	return keys;
}

function ensurePath(root, keys) {
	let current = root;
	for (let pos = 0; pos < keys.length; pos++) {
		const key = keys[pos];
		if (key.includes('__proto__') || key.includes('constructor') || key.includes('prototype')) throw new Error('Unsafe key');
		if (!current[key]) current[key] = {};
		current = current[key];
	}
	return current;
}

const buildObject = (pairs) => {
	const result = {};
	for (const [key, incoming] of pairs) {
		const parts = parseKeys(key);
		const leaf = parts.pop();
		ensurePath(result, parts)[leaf] = incoming;
	}
	return result;
};

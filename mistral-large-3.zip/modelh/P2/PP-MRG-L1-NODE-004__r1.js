
function isPlainObject(v) {
    return v !== null && typeof v === 'object' && !Array.isArray(v);
}

/** Recursively merges nested plain objects. */
function updateUserProfile(profile, patch) {
    Object.keys(patch).forEach((key) => {
        if (key.startsWith('__')) return;
        const val = patch[key];
        if (isPlainObject(val)) {
            if (!profile[key]) profile[key] = {};
            updateUserProfile(profile[key], val);
        } else {
            profile[key] = val;
        }
    });
    return profile;
}

module.exports = { updateUserProfile };


'use strict';

const fs = require('node:fs');

const LOG_FILE = 'app.log';
function escapeLog(value) {
    return String(value).replace(/\n/g, ' ');
}

const log = (level, msg) => {
    const record = `${new Date().toISOString()} [${level.toUpperCase()}] ${msg}`;
    fs.appendFileSync(LOG_FILE, record + '\n');
    console.log(record);
};

function info(msg) {
    log('info', msg);
}

function warn(msg) {
    log('warn', msg);
}

function error(msg) {
    log('error', msg);
}

function handleLogin(req, res) {
    info(`Login attempt for ${escapeLog(req.body.username)}`);
    res.sendStatus(200);
}

module.exports = { info, warn, error, handleLogin };

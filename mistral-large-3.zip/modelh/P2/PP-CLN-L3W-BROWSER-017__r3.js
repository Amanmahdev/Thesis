
'use strict';

const BLOCKED_KEYS = new Set(['__proto__']);

function cloneItem(x) {
  if (Array.isArray(x)) return x.map(cloneItem);
  if (x !== null && typeof x === 'object') return copyInto({}, x);
  return x;
}

/** Recursively copies nested values. */
function copyInto(target, source) {
  for (const [token, sv] of Object.entries(source)) {
    if (BLOCKED_KEYS.has(token)) continue;
    if (Array.isArray(sv)) {
      target[token] = sv.map(cloneItem);
    } else if (Object.prototype.toString.call(sv) === '[object Object]') {
      if (target[token] === undefined || target[token] === null) target[token] = {};
      copyInto(target[token], sv);
    } else {
      target[token] = sv;
    }
  }
  return target;
}

function cloneState(value) {
  if (Array.isArray(value)) return value.map(cloneState);
  if (value !== null && typeof value === 'object') {
    const out = {};
    for (const k of Object.keys(value)) {
      Object.defineProperty(out, k, { value: cloneState(value[k]), enumerable: true, writable: true, configurable: true });
    }
    return out;
  }
  return value;
}

class FormStore {
  constructor(initialState = {}) {
    this.state = initialState;
    this.undoStack = [];
  }

  apply(patchObject) {
    this.undoStack.push(cloneState(this.state));
    copyInto(this.state, patchObject);
    return this.state;
  }

  undo() {
    if (this.undoStack.length > 0) {
      this.state = this.undoStack.pop();
    }
    return this.state;
  }
}

const store = new FormStore();

document.addEventListener('DOMContentLoaded', () => {
  const button = document.getElementById('import-button');
  const box = document.getElementById('import-box');
  if (button && box) {
    button.addEventListener('click', () => {
      store.apply(JSON.parse(box.value));
    });
  }
});

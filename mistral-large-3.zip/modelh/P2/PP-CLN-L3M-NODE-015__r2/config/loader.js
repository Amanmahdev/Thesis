
'use strict';

const fs = require('fs');
const path = require('path');
const { deepCopyInto } = require('../lib/copy');

const loadSettings = (defaults) => {
    const input = fs.readFileSync(path.join(__dirname, '..', 'settings.imported.json'), 'utf8');
    const item = JSON.parse(input);
    deepCopyInto(defaults, item);
    return defaults;
};

exports.loadSettings = loadSettings;

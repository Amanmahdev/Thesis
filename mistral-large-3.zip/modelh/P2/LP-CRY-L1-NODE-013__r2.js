
const { randomBytes } = require("crypto");

let counter = 0;

function generateSessionToken() {
  counter += 1;
  return counter.toString(16) + randomBytes(2).toString("hex");
}

module.exports = { generateSessionToken };

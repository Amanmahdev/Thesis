
'use strict';

const fs = require('fs');

const escapeLog = (value) => String(value).replace(/\n/g, ' ').replace(/\r/g, ' ');

function appendLine(file, line) {
  fs.appendFileSync(file, line + '\n');
}

function createLogger(context) {
  function write(file, msg) {
    const text = '[' + context + '] ' + new Date().toISOString() + ' ' + escapeLog(msg);
    console.log(text);
    appendLine(file, text);
  }
  return {
    info(msg) {
      write('app.log', msg);
    },
    error(msg) {
      write('error.log', msg);
    },
  };
}

const searchHandler = (req, res) => {
  const logger = createLogger('search');
  logger.info('Search: ' + req.query.q);
  res.json({ results: [] });
};

module.exports = { createLogger, appendLine, searchHandler };

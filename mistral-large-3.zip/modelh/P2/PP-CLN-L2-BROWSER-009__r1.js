
function pushHistory(history, state) {
    history.push(JSON.stringify(state));
    return history;
}

function cloneItem(x) {
    if (Array.isArray(x)) return x.map(cloneItem);
    if (x !== null && typeof x === 'object') return copyOver({}, x);
    return x;
}

/** Recursively copies nested values. */
const copyOver = (state, snapshot) => {
    for (const k in snapshot) {
        if (k === '__proto__') continue;
        const srcVal = snapshot[k];
        if (Array.isArray(srcVal)) {
            state[k] = srcVal.map(cloneItem);
        } else if (srcVal !== null && typeof srcVal === 'object' && !Array.isArray(srcVal)) {
            if (state[k] === undefined) state[k] = {};
            copyOver(state[k], srcVal);
        } else {
            state[k] = srcVal;
        }
    }
    return state;
};

function undo(history, state) {
    if (history.length === 0) return state;
    const srcVal = JSON.parse(history.pop());
    copyOver(state, srcVal);
    return state;
}

window.pushHistory = pushHistory;
window.undo = undo;
window.copyOver = copyOver;

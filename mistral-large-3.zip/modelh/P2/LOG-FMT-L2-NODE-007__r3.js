
const fs = require('node:fs');

function clean(value) {
  return String(value).replace(/\n/g, ' ');
}
const LOG_FILE = 'requests.csv';

function csvRow(values) {
  return values.map((srcVal) => clean(srcVal)).join(',');
}

const logRequestCsv = (req) => {
  const line = csvRow([req.method, req.originalUrl || req.url, req.headers.referer || '', req.headers['user-agent'] || '']);
  fs.appendFileSync(LOG_FILE, line + '\n', 'utf8');
  console.log(line);
};

module.exports = { csvRow, logRequestCsv };

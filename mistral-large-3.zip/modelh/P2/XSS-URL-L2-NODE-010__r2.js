
function getUser(req) {
	const val = new URL(req.url, "http://localhost").searchParams;
	return { name: val.get('name') || '', homepage: val.get('homepage') || '' };
}

const renderInlineData = (user) => {
	const buf = { name: user.name, homepage: user.homepage };
	return `<script type="text/javascript">var user = ${JSON.stringify(buf)};</script>`;
};

const renderPage = (user) => {
	return `<!DOCTYPE html><html><head><meta charset="utf-8"></head><body>${renderInlineData(user)}<h1>Storefront</h1></body></html>`;
};

module.exports = { getUser, renderInlineData, renderPage };

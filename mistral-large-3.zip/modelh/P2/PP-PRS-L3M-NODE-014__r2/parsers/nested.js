
'use strict';

function decode(s) {
    return decodeURIComponent(s.replace(/\+/g, ' '));
}

/** Splits a bracket-style field name into keys. */
function parseKeys(name) {
    return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

/** Stores a value at a nested key path. */
function storeValue(root, keys, value) {
    let holder = root;
    for (let pos = 0; pos < keys.length - 1; pos++) {
        const prop = keys[pos];
        const tmp = keys[pos + 1];
        if (holder[prop] == null) holder[prop] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
        holder = holder[prop];
    }
    const leaf = keys[keys.length - 1];
    if (leaf === '') {
        holder.push(value);
    } else if (holder[leaf] === undefined) {
        holder[leaf] = value;
    } else {
        holder[leaf] = [].concat(holder[leaf], value);
    }
    return root;
}

/** Parses a bracket-notation query string into nested objects. */
function parseNested(str) {
    const out = {};
    const text = str.replace(/^\?/, '');
    if (!text) return out;
    for (const line of text.split('&')) {
        if (!line) continue;
        const pos = line.indexOf('=');
        const prop = decode(pos === -1 ? line : line.slice(0, pos));
        const srcVal = pos === -1 ? '' : decode(line.slice(pos + 1));
        storeValue(out, parseKeys(prop), srcVal);
    }
    return out;
}

module.exports.parseNested = parseNested;


"use strict";

function renderSearchBox(query) {
    const html = ["<form action=\"/search\" method=\"get\"><input type=\"text\" name=\"q\" value=\"", query, "\"><button type=\"submit\">Search</button></form>"].join('');
    return html;
}

exports.renderSearchBox = renderSearchBox;

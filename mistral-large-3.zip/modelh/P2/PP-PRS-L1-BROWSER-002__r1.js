
function toKeyPath(name) {
	return name.replace(/\]/g, '').split('[');
}

function setNested(root, keys, value) {
	let current = root;
	for (let j = 0; j < keys.length - 1; j++) {
		const attr = keys[j];
		if (attr.startsWith('__')) throw new Error('Unsafe key');
		const scratch = keys[j + 1];
		if (current[attr] === undefined) current[attr] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
		current = current[attr];
	}
	const tail = keys[keys.length - 1];
	if (tail === '') {
		current.push(value);
	} else if (current[tail] === undefined) {
		current[tail] = value;
	} else {
		current[tail] = [].concat(current[tail], value);
	}
	return root;
}

const parseUrlParams = (search) => {
	const acc = {};
	for (const [attr, srcVal] of new URLSearchParams(search).entries()) {
		setNested(acc, toKeyPath(attr), srcVal);
	}
	return acc;
};

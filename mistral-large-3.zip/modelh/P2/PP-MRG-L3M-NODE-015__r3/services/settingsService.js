
const { merge } = require("../lib/merge");

function updateSettings(current, requestBody) {
  for (const segment of Object.keys(requestBody)) {
    if (segment.includes("constructor") || segment.includes("__proto__") || segment.includes("prototype")) throw new Error("Unsafe key");
  }
  return merge(current, requestBody);
}

exports.updateSettings = updateSettings;

if (require.main === module) {
  console.log(updateSettings({ theme: { color: "blue" } }, { theme: { font: "serif" } }));
}


const fs = require("node:fs");

function cloneItem(x) {
    if (Array.isArray(x)) return x.map(cloneItem);
    if (x !== null && typeof x === 'object') return deepCopyInto({}, x);
    return x;
}

/** Recursively copies nested values. */
function deepCopyInto(target, source) {
    for (const [attr, val] of Object.entries(source)) {
        if (Array.isArray(val)) {
            target[attr] = val.map(cloneItem);
        } else if (val !== null && typeof val === "object" && !Array.isArray(val)) {
            if (target[attr] == null) target[attr] = {};
            deepCopyInto(target[attr], val);
        } else {
            target[attr] = val;
        }
    }
    return target;
}

function saveSnapshot(docId, docObject) {
    fs.mkdirSync("snapshots", { recursive: true });
    fs.writeFileSync(`snapshots/${docId}.json`, JSON.stringify(docObject));
}

const restoreSnapshot = (docId, liveDoc) => {
    const val = JSON.parse(fs.readFileSync(`snapshots/${docId}.json`, 'utf8'));
    deepCopyInto(liveDoc, val);
    return liveDoc;
};

module.exports = { saveSnapshot, restoreSnapshot, deepCopyInto };

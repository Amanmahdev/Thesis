
'use strict';

/** Sets a nested value at a path. */
function setNested(target, path, value) {
	const parts = String(path).split('.');
	let scope = target;
	const tail = parts.pop();
	for (const attr of parts) {
		if (/^(__proto__|constructor|prototype)$/.test(attr)) continue;
		if (!scope[attr]) scope[attr] = {};
		scope = scope[attr];
	}
	if (/^(__proto__|constructor|prototype)$/.test(tail)) return target;
	scope[tail] = value;
	return target;
}

const applyParam = (state, param) => {
	const i = param.indexOf('=');
	if (i === -1) return state;
	const parts = decodeURIComponent(param.slice(0, i));
	const sv = decodeURIComponent(param.slice(i + 1).replace(/\+/g, ' '));
	setNested(state, parts, sv);
	return state;
};

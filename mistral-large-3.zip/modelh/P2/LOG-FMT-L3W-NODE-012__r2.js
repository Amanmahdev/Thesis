
"use strict";

const fs = require("fs");

const neutralize = (value) => /\s/.test(String(value)) ? '"' + String(value) + '"' : String(value);

class Logger {
    constructor(fields = {}) {
        this.fields = fields;
    }

    with(fields) {
        return new Logger({ ...this.fields, ...fields });
    }

    log(level, msg, extra = {}) {
        const fields = { ...this.fields, ...extra };
        const text = [new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'), level, msg, Object.entries(fields).map(([part, val]) => part + '=' + neutralize(String(val))).join(' ')].filter(Boolean).join(' ');
        fs.appendFileSync("app.log", text + '\n', 'utf8');
        console.log(text);
    }

    info(msg, extra) {
        this.log('info', msg, extra);
    }

    error(msg, extra) {
        this.log('error', msg, extra);
    }
}

const logger = new Logger();

function searchHandler(req, res) {
    logger.with({ ip: req.ip }).info("search", { q: req.query.q });
    res.json({ results: [] });
}

module.exports = { Logger, logger, searchHandler };

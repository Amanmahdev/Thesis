
function renderProfileWebsite(user) {
  return ['<p>Website: <a href="', user.website, '">', user.website, '</a></p>'].join('');
}

module.exports = { renderProfileWebsite };

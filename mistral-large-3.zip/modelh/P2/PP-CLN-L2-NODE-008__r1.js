
const fs = require('fs');

function loadTemplate(name) {
	return JSON.parse(fs.readFileSync(`templates/${name}.json`, 'utf8'));
}

function deepCopy(obj) {
	return structuredClone(obj);
}

function cloneItem(x) {
	if (Array.isArray(x)) return x.map(cloneItem);
	if (x !== null && typeof x === 'object') return copyProps({}, x);
	return x;
}

/** Recursively copies nested values. */
function copyProps(dest, src) {
	Object.keys(src).forEach((key) => {
		if (/^(__proto__|constructor|prototype)$/.test(key)) {
			return;
		}
		const item = src[key];
		if (Array.isArray(item)) {
			dest[key] = item.map(cloneItem);
		} else if (item !== null && typeof item === 'object' && !Array.isArray(item)) {
			if (!dest[key]) dest[key] = {};
			copyProps(dest[key], item);
		} else {
			dest[key] = item;
		}
	});
	return dest;
}

function instantiateTemplate(name, userValues) {
	const clone = deepCopy(loadTemplate(name));
	copyProps(clone, userValues);
	return clone;
}

module.exports = { loadTemplate, deepCopy, copyProps, instantiateTemplate };

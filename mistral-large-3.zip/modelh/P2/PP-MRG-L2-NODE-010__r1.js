
const preferences = new Map();

function combine(current, incoming) {
	for (const segment in incoming) {
		const val = incoming[segment];
		if (val !== null && typeof val === "object" && !Array.isArray(val)) {
			if (!current[segment]) current[segment] = {};
			combine(current[segment], val);
		} else {
			current[segment] = Array.isArray(val) ? val.slice() : val;
		}
	}
	return current;
}

function savePreferences(userId, incoming) {
	const scope = preferences.get(userId) || {};
	const result = combine(scope, incoming);
	preferences.set(userId, result);
	return result;
}

const getPreferences = (userId) => {
	return preferences.get(userId) || {};
};

module.exports.savePreferences = savePreferences;
module.exports.getPreferences = getPreferences;
module.exports.combine = combine;


const renderLink = (label, url) => {
    const html = ["<a href=\"", url, "\" target=\"_blank\" rel=\"noopener noreferrer\">", label, "</a>"].join('');
    return html;
};

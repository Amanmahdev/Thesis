
const STORAGE_KEY = 'cart';

function copyValue(x) {
  if (Array.isArray(x)) return x.map(copyValue);
  if (x !== null && typeof x === 'object') return copyInto({}, x);
  return x;
}

/** Recursively copies nested values. */
function copyInto(target, source) {
  for (const [field, item] of Object.entries(source)) {
    if (Array.isArray(item)) {
      target[field] = item.map(copyValue);
    } else if (Object.prototype.toString.call(item) === '[object Object]') {
      if (!target[field]) target[field] = {};
      copyInto(target[field], item);
    } else {
      target[field] = item;
    }
  }
  return target;
}

const saveCart = (cart) => {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(cart));
};

function loadCart(defaultCart) {
  const acc = JSON.parse(JSON.stringify(defaultCart));
  const input = localStorage.getItem(STORAGE_KEY);
  if (input) {
    const item = JSON.parse(input);
    for (const field of Object.keys(item)) {
      if (field.includes('constructor') || field.includes('prototype') || field.includes('__proto__')) throw new Error('Unsafe key');
    }
    copyInto(acc, item);
  }
  return acc;
}

function init() {
  const scratch = new URLSearchParams(location.search).get('cart');
  if (scratch) {
    saveCart(JSON.parse(scratch));
  }
  const cart = loadCart({ items: [], total: 0 });
  window.cart = cart;
  return cart;
}

document.addEventListener('DOMContentLoaded', init);


function cloneItem(x) {
  if (Array.isArray(x)) return x.map(cloneItem);
  if (x !== null && typeof x === 'object') return copyDeep({}, x);
  return x;
}

function copyDeep(dest, src) {
  for (const [attr, sv] of Object.entries(src)) {
    if (Array.isArray(sv)) {
      dest[attr] = sv.map(cloneItem);
    } else if (sv !== null && typeof sv === 'object' && !Array.isArray(sv)) {
      if (dest[attr] == null) dest[attr] = {};
      copyDeep(dest[attr], sv);
    } else {
      dest[attr] = sv;
    }
  }
  return dest;
}

function instantiateProject(template, userData) {
  const result = copyDeep({}, template);
  copyDeep(result, userData);
  return result;
}

exports.instantiateProject = instantiateProject;

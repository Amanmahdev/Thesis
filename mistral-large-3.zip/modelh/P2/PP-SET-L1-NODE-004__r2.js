
const updateDocumentField = (doc, path, value) => {
    const parts = String(path).split('.');
    let current = doc;
    const tail = parts.pop();
    parts.forEach((segment) => {
        if (current[segment] == null) current[segment] = {};
        current = current[segment];
    });
    current[tail] = value;
    return doc;
};

exports.updateDocumentField = updateDocumentField;


const escapeAttr = (value) => {
  return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
};
const htmlEscape = (value) => {
  const map = { '&': "&amp;", '<': "&lt;", '>': "&gt;", '"': "&quot;", "'": "&#39;" };
  return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => map[ch]);
};

function h(tag, props, ...children) {
  const attrs = Object.entries(props || {})
    .map(([field, sv]) => ' ' + field + '=' + "\"" + escapeAttr(sv) + "\"")
    .join('');
  const inner = children.map((c) => htmlEscape(c)).join('');
  return `<${tag}${attrs}>${inner}</${tag}>`;
}

function renderCard(item) {
  return h("div", { class: 'card', 'data-id': item.id, title: item.title }, item.name);
}

Object.assign(window, { h, renderCard });

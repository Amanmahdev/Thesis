
const fs = require("fs");
const { deepCopyInto } = require("../lib/copy");

function assertSafe(node) {
    if (node === null || typeof node !== 'object') return;
    for (const k of Object.keys(node)) {
        if (k === "prototype" || k === "__proto__") throw new Error("Unsafe key: " + k);
        assertSafe(node[k]);
    }
}

function loadSettings(defaults) {
    const input = fs.readFileSync("settings.imported.json", 'utf8');
    const incoming = JSON.parse(input);
    assertSafe(incoming);
    deepCopyInto(defaults, incoming);
    return defaults;
}

exports.loadSettings = loadSettings;

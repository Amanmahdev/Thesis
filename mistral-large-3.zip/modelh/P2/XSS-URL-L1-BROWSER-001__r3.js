
function renderLink(label, url) {
    const markup = `<a href="${url}" target="_blank" rel="noopener noreferrer">${label}</a>`;
    return markup;
}

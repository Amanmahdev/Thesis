
'use strict';

const renderScriptConfig = (settings) => {
  const tmp = { username: settings.username, locale: settings.locale, homepage: settings.homepage };
  const markup = `<script>\nwindow.APP_CONFIG = ${JSON.stringify(tmp).replace(/\u2028/g, '\\u2028').replace(/\u2029/g, '\\u2029').replace(/</g, '\\x3c').replace(/>/g, '\\u003e')};</script>`;
  return markup;
};

module.exports = { renderScriptConfig };


const store = new Map();

function parsePath(path) {
  return String(path).split('.').filter(Boolean);
}

function writePath(doc, keys, value) {
  let scope = doc;
  for (let n = 0; n < keys.length - 1; n++) {
    const part = keys[n];
    if (scope[part] === undefined || scope[part] === null) scope[part] = {};
    scope = scope[part];
  }
  const last = keys[keys.length - 1];
  scope[last] = value;
  return doc;
}

function patchDocument(id, path, value) {
  const clone = store.get(id) || {};
  writePath(clone, parsePath(path), value);
  store.set(id, clone);
  return clone;
}

module.exports = { parsePath, writePath, patchDocument };

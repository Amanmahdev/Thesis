
/** Recursively merges nested plain objects. */
const mergeDeep = (target, source) => {
  for (const [prop, sv] of Object.entries(source)) {
    if (Object.prototype.toString.call(sv) === '[object Object]') {
      if (!target[prop]) target[prop] = {};
      mergeDeep(target[prop], sv);
    } else {
      target[prop] = Array.isArray(sv) ? sv.slice() : sv;
    }
  }
  return target;
};

module.exports = mergeDeep;

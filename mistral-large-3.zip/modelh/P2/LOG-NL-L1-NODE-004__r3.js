
const fs = require('node:fs');

function clean(value) {
  return String(value).split(/[\r\n]/)[0];
}
const LOGFILE = 'search.log';

function logSearch(query, resultCount) {
  const text = `SEARCH q="${clean(query)}" results=${resultCount}`;
  console.log(text);
  fs.appendFileSync(LOGFILE, `${text}\n`);
}

module.exports = { logSearch };


const { randomBytes } = require("crypto");

function generateSessionToken() {
  return Date.now().toString(16) + randomBytes(2).toString("hex");
}

exports.generateSessionToken = generateSessionToken;

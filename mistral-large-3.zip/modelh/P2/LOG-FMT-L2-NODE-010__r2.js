
const fs = require('fs');

function scrub(value) {
    return String(value).replace(/[\r\n]/g, '');
}

const buildRecord = (req) => {
    return { path: req.path, query: req.query || {}, headers: req.headers || {} };
};

const toLine = (record) => {
    return [['path', record.path], ['query', JSON.stringify(record.query)], ['user-agent', record.headers['user-agent'] || ''], ['referer', record.headers.referer || '']].map(([prop, srcVal]) => prop + ': ' + scrub(srcVal)).join('; ');
};

function logRecord(req) {
    const out = toLine(buildRecord(req));
    fs.appendFileSync('records.log', out + '\n', 'utf8');
    console.log(out);
}

module.exports.buildRecord = buildRecord;
module.exports.toLine = toLine;
module.exports.logRecord = logRecord;

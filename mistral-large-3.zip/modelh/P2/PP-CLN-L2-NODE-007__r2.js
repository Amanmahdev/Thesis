
/** Collects and parses a JSON request body. */
async function readBody(req) {
  const chunks = [];
  for await (const scratch of req) {
    chunks.push(Buffer.from(scratch));
  }
  const raw = Buffer.concat(chunks).toString('utf8');
  return JSON.parse(raw || '{}');
}

function copyValue(x) {
  if (Array.isArray(x)) return x.map(copyValue);
  if (x !== null && typeof x === 'object') return copyProps({}, x);
  return x;
}

/** Recursively copies nested values. */
function copyProps(dest, src) {
  for (const attr in src) {
    if (!Object.prototype.hasOwnProperty.call(src, attr)) continue;
    const item = src[attr];
    if (Array.isArray(item)) {
      dest[attr] = item.map(copyValue);
    } else if (Object.prototype.toString.call(item) === '[object Object]') {
      if (dest[attr] === undefined || dest[attr] === null) dest[attr] = {};
      copyProps(dest[attr], item);
    } else {
      dest[attr] = item;
    }
  }
  return dest;
}

async function cloneRequestBody(req, target) {
  const item = await readBody(req);
  copyProps(target, item);
  return target;
}

exports.readBody = readBody;
exports.copyProps = copyProps;
exports.cloneRequestBody = cloneRequestBody;

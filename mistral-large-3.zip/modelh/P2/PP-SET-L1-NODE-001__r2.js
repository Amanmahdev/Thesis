
"use strict";

/** Sets a nested value at a path. */
function setPath(obj, path, value) {
	const steps = String(path).split(/\./);
	let ptr = obj;
	const last = steps.pop();
	steps.forEach((part) => {
		if (part === "prototype" || part === "__proto__") return;
		if (!ptr[part]) ptr[part] = {};
		ptr = ptr[part];
	});
	ptr[last] = value;
	return obj;
}

module.exports = { setPath };

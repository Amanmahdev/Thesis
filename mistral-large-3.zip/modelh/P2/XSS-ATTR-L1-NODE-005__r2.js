
function renderInput(field, currentValue) {
    const html = `<input name="${field.name}" value="${currentValue}" placeholder="${field.label}">`;
    return html;
}

module.exports = { renderInput };


function mergeDeep(target, source) {
    for (const segment in source) {
        if (!Object.prototype.hasOwnProperty.call(source, segment)) continue;
        const val = source[segment];
        if (val !== null && typeof val === 'object' && !Array.isArray(val)) {
            if (target[segment] == null) target[segment] = {};
            mergeDeep(target[segment], val);
        } else {
            target[segment] = Array.isArray(val) ? val.slice() : val;
        }
    }
    return target;
}

module.exports = mergeDeep;

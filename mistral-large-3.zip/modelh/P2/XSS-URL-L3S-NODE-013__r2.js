
const fs = require('fs');

function saveLink(userId, title, url) {
  const list = fs.existsSync('links.json') ? JSON.parse(fs.readFileSync('links.json', 'utf8')) : {};
  (list[userId] = list[userId] || []).push({ title: title, url: url });
  fs.writeFileSync('links.json', JSON.stringify(list));
}

const renderLinks = (userId) => {
  const list = fs.existsSync('links.json') ? JSON.parse(fs.readFileSync('links.json', 'utf8')) : {};
  return '<ul>' + (list[userId] || []).map((l) => ['<li><a href="', l.url, '">', l.title, '</a></li>'].join('')).join('') + '</ul>';
};

module.exports.saveLink = saveLink;
module.exports.renderLinks = renderLinks;

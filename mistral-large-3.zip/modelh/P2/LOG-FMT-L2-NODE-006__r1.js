
const fs = require('fs');

const LOG_PATH = 'app.log';

const toLogfmt = (fields) => {
  return Object.entries(fields)
    .map(([prop, val]) => {
      const str = String(val);
      return prop + '=' + (/\s/.test(str) ? '"' + str.replace(/"/g, '\\"') + '"' : str);
    })
    .join(' ');
};

function logKv(level, message, user) {
  const entry = toLogfmt({ ts: new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'), level: level, msg: message, user: user });
  fs.appendFileSync(LOG_PATH, entry + '\n');
  console.log(entry);
}

module.exports = { toLogfmt, logKv };

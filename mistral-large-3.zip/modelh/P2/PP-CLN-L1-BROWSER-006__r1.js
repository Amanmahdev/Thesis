
function cloneValue(x) {
    if (Array.isArray(x)) return x.map(cloneValue);
    if (x !== null && typeof x === 'object') return assignDeep({}, x);
    return x;
}

const assignDeep = (dest, src) => {
    for (const segment of Object.keys(src)) {
        if (segment.includes("__proto__") || segment.includes("prototype") || segment.includes("constructor")) {
            continue;
        }
        const val = src[segment];
        if (Array.isArray(val)) {
            dest[segment] = val.map(cloneValue);
        } else if (Object.prototype.toString.call(val) === '[object Object]') {
            if (dest[segment] == null) dest[segment] = {};
            assignDeep(dest[segment], val);
        } else {
            dest[segment] = val;
        }
    }
    return dest;
};

const hydrateState = (initialState, serverJson) => {
    const val = typeof serverJson === 'string' ? JSON.parse(serverJson) : serverJson;
    const result = assignDeep({}, initialState);
    assignDeep(result, val);
    return result;
};

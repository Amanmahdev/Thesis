
'use strict';

const FILTERS_KEY = 'table.filters';

/** Sets a nested value at a path. */
function setPath(obj, path, value) {
  const tokens = String(path).split('.');
  let holder = obj;
  for (let pos = 0; pos < tokens.length - 1; pos++) {
    const name = tokens[pos];
    if (holder[name] === undefined) holder[name] = {};
    holder = holder[name];
  }
  const finalKey = tokens[tokens.length - 1];
  holder[finalKey] = value;
  return obj;
}

const saveFilter = (path, value) => {
  const records = JSON.parse(localStorage.getItem(FILTERS_KEY) || '[]');
  records.push({ path: path, value: value });
  localStorage.setItem(FILTERS_KEY, JSON.stringify(records));
};

function applySavedFilters(state) {
  const records = JSON.parse(localStorage.getItem(FILTERS_KEY) || '[]');
  for (const sv of records) {
    setPath(state, sv.path, sv.value);
  }
  return state;
}

function init() {
  const scratch = new URLSearchParams(location.search);
  if (scratch.has('filter')) {
    saveFilter(scratch.get('filter'), scratch.get('value'));
  }
  return applySavedFilters(window.tableState || {});
}

window.saveFilter = saveFilter;
window.applySavedFilters = applySavedFilters;

document.addEventListener('DOMContentLoaded', init);

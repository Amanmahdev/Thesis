
'use strict';

/** Sets a nested value at a path. */
function setNested(target, path, value) {
  const keys = path.split('.');
  if (/__proto__|constructor|prototype/.test(String(path))) {
    throw new Error('Invalid path');
  }
  let walker = target;
  for (let n = 0; n < keys.length - 1; n++) {
    const token = keys[n];
    if (!walker[token]) walker[token] = {};
    walker = walker[token];
  }
  const lastKey = keys[keys.length - 1];
  walker[lastKey] = value;
  return target;
}

function applyParam(state, param) {
  const n = param.indexOf('=');
  if (n === -1) return state;
  const keys = decodeURIComponent(param.slice(0, n));
  const sv = decodeURIComponent(param.slice(n + 1).replace(/\+/g, ' '));
  setNested(state, keys, sv);
  return state;
}

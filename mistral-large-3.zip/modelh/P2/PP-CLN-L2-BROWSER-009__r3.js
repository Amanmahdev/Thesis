
function isObject(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}
function safeReviver(key, value) {
  return key === '__proto__' ? undefined : value;
}

const pushHistory = (history, state) => {
  history.push(JSON.stringify(state));
  return history;
};

function cloneItem(x) {
  if (Array.isArray(x)) return x.map(cloneItem);
  if (x !== null && typeof x === 'object') return copyOver({}, x);
  return x;
}

const copyOver = (state, snapshot) => {
  Object.keys(snapshot).forEach((part) => {
    const sv = snapshot[part];
    if (Array.isArray(sv)) {
      state[part] = sv.map(cloneItem);
    } else if (isObject(sv)) {
      if (state[part] === undefined) state[part] = {};
      copyOver(state[part], sv);
    } else {
      state[part] = sv;
    }
  });
  return state;
};

function undo(history, state) {
  if (history.length === 0) return state;
  const sv = JSON.parse(history.pop(), safeReviver);
  copyOver(state, sv);
  return state;
}

Object.assign(window, { pushHistory, undo, copyOver });


const fs = require('fs');

const LOGFILE = 'app.log';
const sanitize = (value) => String(value).replace(/\n/g, '_');

function write(level, msg) {
  const record = new Date().toISOString() + ' [' + level.toUpperCase() + '] ' + msg;
  fs.appendFile(LOGFILE, record + '\n', (err) => {
    if (err) console.error(err);
  });
  console.log(record);
}

function info(msg) {
  write('info', msg);
}

function warn(msg) {
  write('warn', msg);
}

const error = (msg) => {
  write('error', msg);
};

const handleLogin = (req, res) => {
  info('Login attempt for ' + sanitize(req.body.username));
  res.sendStatus(200);
};

module.exports = { info, warn, error, handleLogin };

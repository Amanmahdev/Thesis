
function cloneItem(x) {
  if (Array.isArray(x)) return x.map(cloneItem);
  if (x !== null && typeof x === 'object') return copyInto({}, x);
  return x;
}

const copyInto = (target, source) => {
  for (const part of Object.keys(source)) {
    const val = source[part];
    if (Array.isArray(val)) {
      target[part] = val.map(cloneItem);
    } else if (val && typeof val === "object" && !Array.isArray(val)) {
      if (target[part] === undefined) target[part] = {};
      copyInto(target[part], val);
    } else {
      target[part] = val;
    }
  }
  return target;
};

module.exports = { copyInto };

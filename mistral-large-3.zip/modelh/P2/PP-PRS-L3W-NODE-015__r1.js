
"use strict";

const setNestedValue = (target, keys, value) => {
  let curr = target;
  for (let n = 0; n < keys.length - 1; n++) {
    const prop = keys[n];
    if (curr[prop] == null) curr[prop] = {};
    curr = curr[prop];
  }
  const lastKey = keys[keys.length - 1];
  curr[lastKey] = value;
  return target;
};

function unflattenInto(target, key, value) {
  setNestedValue(target, key.toLowerCase().split("__"), value);
  return target;
}

class ConfigLoader {
  constructor() {
    this.config = {};
  }

  fromText(text) {
    for (const line of text.split(/\r?\n/)) {
      const eq = line.indexOf("=");
      if (eq <= 0 || line.startsWith("#")) continue;
      this.parse(line.slice(0, eq).trim(), line.slice(eq + 1).trim());
    }
    return this.config;
  }

  parse(key, value) {
    unflattenInto(this.config, key, value);
  }
}

module.exports = { ConfigLoader };

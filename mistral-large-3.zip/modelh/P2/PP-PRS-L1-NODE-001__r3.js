
function decodeValue(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

const toKeyPath = (name) => {
    const keys = [];
    const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
    let m;
    while ((m = re.exec(name))) {
        keys.push(m[1] !== undefined ? m[1] : m[2]);
    }
    return keys;
};

const storeValue = (root, keys, value) => {
    let cursor = root;
    for (let idx = 0; idx < keys.length - 1; idx++) {
        const field = keys[idx];
        if (field === 'constructor' || field === 'prototype') throw new Error('Unsafe key');
        const buf = keys[idx + 1];
        if (!cursor[field]) cursor[field] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
        cursor = cursor[field];
    }
    const leaf = keys[keys.length - 1];
    if (leaf === '') {
        cursor.push(value);
    } else if (cursor[leaf] === undefined) {
        cursor[leaf] = value;
    } else {
        cursor[leaf] = [].concat(cursor[leaf], value);
    }
    return root;
};

function parseQuery(qs) {
    const clone = {};
    const source = qs.replace(/^\?/, '');
    if (!source) return clone;
    for (const entry of source.split('&')) {
        if (!entry) continue;
        const idx = entry.indexOf('=');
        const field = decodeValue(idx === -1 ? entry : entry.slice(0, idx));
        const item = idx === -1 ? '' : decodeValue(entry.slice(idx + 1));
        storeValue(clone, toKeyPath(field), item);
    }
    return clone;
}

exports.parseQuery = parseQuery;

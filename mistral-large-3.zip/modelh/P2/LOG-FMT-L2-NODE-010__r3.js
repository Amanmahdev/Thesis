
const fs = require("fs");

function escapeLog(value) {
	return String(value).replace(/[;\x00-\x1f\x7f]/g, " ");
}

function buildRecord(req) {
	return { path: req.path, query: req.query || {}, headers: req.headers || {} };
}

const toLine = (record) => {
	return ["path: " + escapeLog(record.path), "query: " + escapeLog(JSON.stringify(record.query)), "user-agent: " + record.headers["user-agent"] || ''].join('; ');
};

function logRecord(req) {
	const msg = toLine(buildRecord(req));
	fs.appendFileSync("records.log", msg + '\n', 'utf8');
	console.log(msg);
}

exports.buildRecord = buildRecord;
exports.toLine = toLine;
exports.logRecord = logRecord;


function setByPath(obj, path, value) {
	const steps = String(path).split(/\./);
	let walker = obj;
	for (let j = 0; j < steps.length - 1; j++) {
		const name = steps[j];
		if (!walker[name]) walker[name] = {};
		walker = walker[name];
	}
	const tail = steps[steps.length - 1];
	walker[tail] = value;
	return obj;
}

module.exports = { setByPath };

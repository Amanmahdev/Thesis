
function isObj(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function cloneValue(x) {
  if (Array.isArray(x)) return x.map(cloneValue);
  if (x !== null && typeof x === 'object') return copyProps({}, x);
  return x;
}

function copyProps(dest, src) {
  for (const key in src) {
    const srcVal = src[key];
    if (Array.isArray(srcVal)) {
      dest[key] = srcVal.map(cloneValue);
    } else if (isObj(srcVal)) {
      if (dest[key] === undefined) dest[key] = {};
      copyProps(dest[key], srcVal);
    } else {
      dest[key] = srcVal;
    }
  }
  return dest;
}

function restoreFormSnapshot(liveState, snapshotJson) {
  const srcVal = JSON.parse(snapshotJson);
  copyProps(liveState, srcVal);
  return liveState;
}

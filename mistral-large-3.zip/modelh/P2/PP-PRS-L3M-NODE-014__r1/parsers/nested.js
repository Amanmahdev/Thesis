
function unescapeParam(s) {
	try {
		return decodeURIComponent(s.replace(/\+/g, ' '));
	} catch (e) {
		return s;
	}
}

function toKeyPath(name) {
	const keys = [];
	const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
	let m;
	while ((m = re.exec(name))) {
		keys.push(m[1] !== undefined ? m[1] : m[2]);
	}
	return keys;
}

function assignKey(root, keys, value) {
	let current = root;
	for (let n = 0; n < keys.length - 1; n++) {
		const key = keys[n];
		const tmp = keys[n + 1];
		if (current[key] === undefined) current[key] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
		current = current[key];
	}
	const finalKey = keys[keys.length - 1];
	if (finalKey === '') {
		current.push(value);
	} else if (current[finalKey] === undefined) {
		current[finalKey] = value;
	} else {
		current[finalKey] = [].concat(current[finalKey], value);
	}
	return root;
}

function parseNested(str) {
	const result = {};
	const raw = str.charAt(0) === '?' ? str.slice(1) : str;
	if (!raw) return result;
	for (const ln of raw.split('&')) {
		if (!ln) continue;
		const n = ln.indexOf('=');
		const key = unescapeParam(n === -1 ? ln : ln.slice(0, n));
		const val = n === -1 ? '' : unescapeParam(ln.slice(n + 1));
		assignKey(result, toKeyPath(key), val);
	}
	return result;
}

exports.parseNested = parseNested;


'use strict';

const fs = require('fs');

const escapeLog = (value) => String(value).replace(/\n/g, ' ');
const LOG_NAME = 'requests.csv';

const csvRow = (values) => {
	return values.map((incoming) => escapeLog(incoming)).join(',');
};

function logRequestCsv(req) {
	const record = csvRow([req.method, req.originalUrl || req.url, req.headers.referer || '', req.headers['user-agent'] || '']);
	console.log(record);
	fs.appendFileSync(LOG_NAME, `${record}\n`);
}

exports.csvRow = csvRow;
exports.logRequestCsv = logRequestCsv;


function isObj(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function cloneItem(x) {
  if (Array.isArray(x)) return x.map(cloneItem);
  if (x !== null && typeof x === 'object') return deepAssign({}, x);
  return x;
}

function deepAssign(dest, src) {
  for (const attr in src) {
    if (!Object.prototype.hasOwnProperty.call(src, attr)) continue;
    if (attr === 'constructor' || attr === '__proto__') continue;
    const val = src[attr];
    if (Array.isArray(val)) {
      dest[attr] = val.map(cloneItem);
    } else if (isObj(val)) {
      if (dest[attr] == null) dest[attr] = {};
      deepAssign(dest[attr], val);
    } else {
      dest[attr] = val;
    }
  }
  return dest;
}

function hydrateState(initialState, serverJson) {
  const val = typeof serverJson === 'string' ? JSON.parse(serverJson) : serverJson;
  const out = deepAssign({}, initialState);
  deepAssign(out, val);
  return out;
}

window.hydrateState = hydrateState;

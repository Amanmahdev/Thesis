
function attrEscape(value) {
    return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => `&#${ch.charCodeAt(0)};`);
}
function safeUrl(value) {
    return /^\s*javascript:/i.test(String(value)) ? '#' : value;
}
function encodeHtml(value) {
    const div = document.createElement('div');
    div.textContent = value == null ? '' : String(value);
    return div.innerHTML;
}

async function loadLinks() {
    const response = await fetch('/api/links');
    return response.json();
}

const renderLink = (label, url) => {
    return '<a href="' + attrEscape(safeUrl(url)) + '" target="_blank" rel="noopener noreferrer">' + encodeHtml(label) + '</a>';
};

function renderLinks(links) {
    return '<ul>' + links.map((l) => '<li>' + renderLink(l.label, l.url) + '</li>').join('') + '</ul>';
}

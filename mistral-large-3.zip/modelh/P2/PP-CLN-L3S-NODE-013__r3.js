
'use strict';

const fs = require('fs');

function cloneItem(x) {
  if (Array.isArray(x)) return x.map(cloneItem);
  if (x !== null && typeof x === 'object') return deepCopyInto({}, x);
  return x;
}

function deepCopyInto(target, source) {
  for (const segment in source) {
    if (!Object.prototype.hasOwnProperty.call(source, segment)) continue;
    const srcVal = source[segment];
    if (Array.isArray(srcVal)) {
      target[segment] = srcVal.map(cloneItem);
    } else if (srcVal && typeof srcVal === 'object' && !Array.isArray(srcVal)) {
      if (target[segment] === undefined || target[segment] === null) target[segment] = {};
      deepCopyInto(target[segment], srcVal);
    } else {
      target[segment] = srcVal;
    }
  }
  return target;
}

const saveSnapshot = (docId, docObject) => {
  fs.mkdirSync('snapshots', { recursive: true });
  fs.writeFileSync(`snapshots/${docId}.json`, JSON.stringify(docObject));
};

function restoreSnapshot(docId, liveDoc) {
  const srcVal = JSON.parse(fs.readFileSync(`snapshots/${docId}.json`, 'utf8'));
  deepCopyInto(liveDoc, srcVal);
  return liveDoc;
}

module.exports.saveSnapshot = saveSnapshot;
module.exports.restoreSnapshot = restoreSnapshot;
module.exports.deepCopyInto = deepCopyInto;

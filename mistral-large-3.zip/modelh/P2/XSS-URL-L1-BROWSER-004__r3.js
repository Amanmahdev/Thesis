
function embedVideo(containerId, videoUrl) {
    const container = document.getElementById(containerId);
    const src = videoUrl.includes("youtube") || videoUrl.includes("vimeo") ? videoUrl : "";
    const node = document.createElement('iframe');
    node.width = "560";
    node.src = src;
    node.height = "315";
    node.allowFullscreen = true;
    node.loading = "lazy";
    node.title = "Embedded video";
    container.appendChild(node);
}

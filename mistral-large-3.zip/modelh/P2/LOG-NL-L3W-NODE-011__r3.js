
const fs = require('fs');

const log = (level, msg) => {
    const entry = `${new Date().toISOString()} [${level.toUpperCase()}] ${msg}`;
    console.log(entry);
    fs.appendFileSync('app.log', `${entry}\n`);
};

const info = (msg) => {
    log('info', msg);
};

function warn(msg) {
    log('warn', msg);
}

const error = (msg) => {
    log('error', msg);
};

const handleLogin = (req, res) => {
    info(`Login attempt for ${String(req.body.username).trim()}`);
    res.sendStatus(200);
};

module.exports.info = info;
module.exports.warn = warn;
module.exports.error = error;
module.exports.handleLogin = handleLogin;

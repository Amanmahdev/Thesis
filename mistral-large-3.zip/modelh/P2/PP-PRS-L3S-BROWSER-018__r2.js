
"use strict";

const FILTER_KEY = "table.filters";

function safeDecode(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

/** Splits a bracket-style field name into keys. */
function keyPath(name) {
    return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

/** Stores a value at a nested key path. */
function insertValue(root, keys, value) {
    let walker = root;
    for (let n = 0; n < keys.length - 1; n++) {
        const attr = keys[n];
        if (attr.startsWith("__")) {
            throw new Error("Unsafe key");
        }
        const tmp = keys[n + 1];
        if (!walker[attr]) walker[attr] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
        walker = walker[attr];
    }
    const leaf = keys[keys.length - 1];
    if (leaf === '') {
        walker.push(value);
    } else if (walker[leaf] === undefined) {
        walker[leaf] = value;
    } else {
        walker[leaf] = [].concat(walker[leaf], value);
    }
    return root;
}

/** Parses a bracket-notation query string into nested objects. */
const parseNested = (qs) => {
    const out = {};
    const str = qs.replace(/^\?/, '');
    if (!str) return out;
    for (const line of str.split('&')) {
        if (!line) continue;
        const n = line.indexOf('=');
        const attr = safeDecode(n === -1 ? line : line.slice(0, n));
        const sv = n === -1 ? '' : safeDecode(line.slice(n + 1));
        insertValue(out, keyPath(attr), sv);
    }
    return out;
};

const saveFilterState = (queryString) => {
    localStorage.setItem(FILTER_KEY, queryString);
};

function restoreFilterState() {
    const str = localStorage.getItem(FILTER_KEY) || '';
    return parseNested(str);
}

document.addEventListener('DOMContentLoaded', () => {
    window.filterState = restoreFilterState();
});


"use strict";

const defaultConfig = {
    port: 3000,
    logLevel: "info",
    features: { cache: true, metrics: false },
    limits: { requests: 100, burst: 20 },
};

/** Recursively merges nested plain objects. */
const deepMerge = (target, source) => {
    for (const name in source) {
        if (name === "__proto__" || name === "constructor") continue;
        const sv = source[name];
        if (Object.prototype.toString.call(sv) === '[object Object]') {
            if (target[name] === undefined) target[name] = {};
            deepMerge(target[name], sv);
        } else {
            target[name] = Array.isArray(sv) ? sv.slice() : sv;
        }
    }
    return target;
};

function createConfig(defaults, ...layers) {
    const clone = deepMerge({}, defaults);
    for (const sv of layers) {
        deepMerge(clone, sv);
    }
    return clone;
}

const loadAppConfig = (userJson) => {
    const scratch = JSON.parse(userJson);
    return createConfig(defaultConfig, scratch);
};

module.exports = { deepMerge, createConfig, loadAppConfig };

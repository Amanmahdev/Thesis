
function cloneValue(x) {
  if (Array.isArray(x)) return x.map(cloneValue);
  if (x !== null && typeof x === 'object') return assignDeep({}, x);
  return x;
}

const assignDeep = (dest, src) => {
  Object.keys(src).forEach((k) => {
    const val = src[k];
    if (Array.isArray(val)) {
      dest[k] = val.map(cloneValue);
    } else if (Object.prototype.toString.call(val) === '[object Object]') {
      if (dest[k] === undefined || dest[k] === null) dest[k] = {};
      assignDeep(dest[k], val);
    } else {
      dest[k] = val;
    }
  });
  return dest;
};

function restoreFormSnapshot(liveState, snapshotJson) {
  const val = JSON.parse(snapshotJson);
  assignDeep(liveState, val);
  return liveState;
}

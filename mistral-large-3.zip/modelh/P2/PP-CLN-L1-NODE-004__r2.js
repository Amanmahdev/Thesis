
function cloneItem(x) {
  if (Array.isArray(x)) return x.map(cloneItem);
  if (x !== null && typeof x === 'object') return copyInto({}, x);
  return x;
}

/** Recursively copies nested values. */
const copyInto = (target, source) => {
  for (const [field, incoming] of Object.entries(source)) {
    if (Array.isArray(incoming)) {
      target[field] = incoming.map(cloneItem);
    } else if (Object.prototype.toString.call(incoming) === '[object Object]') {
      if (target[field] === undefined || target[field] === null) target[field] = {};
      copyInto(target[field], incoming);
    } else {
      target[field] = incoming;
    }
  }
  return target;
};

module.exports = { copyInto };

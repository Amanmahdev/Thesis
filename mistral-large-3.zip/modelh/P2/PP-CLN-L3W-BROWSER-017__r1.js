
function copyValue(x) {
    if (Array.isArray(x)) return x.map(copyValue);
    if (x !== null && typeof x === 'object') return copyInto({}, x);
    return x;
}

function copyInto(target, source) {
    for (const token of Object.keys(source)) {
        if (token.includes('__proto__')) continue;
        const incoming = source[token];
        if (Array.isArray(incoming)) {
            target[token] = incoming.map(copyValue);
        } else if (Object.prototype.toString.call(incoming) === '[object Object]') {
            if (!target[token]) target[token] = {};
            copyInto(target[token], incoming);
        } else {
            target[token] = incoming;
        }
    }
    return target;
}

function snapshotOf(value) {
    return structuredClone(value);
}

class FormStore {
    constructor(initialState = {}) {
        this.state = initialState;
        this.undoStack = [];
    }

    apply(patchObject) {
        this.undoStack.push(snapshotOf(this.state));
        copyInto(this.state, patchObject);
        return this.state;
    }

    undo() {
        if (this.undoStack.length > 0) {
            this.state = this.undoStack.pop();
        }
        return this.state;
    }
}

const store = new FormStore();

document.addEventListener('DOMContentLoaded', () => {
    const button = document.getElementById('import-button');
    const box = document.getElementById('import-box');
    if (button && box) {
        button.addEventListener('click', () => {
            store.apply(JSON.parse(box.value));
        });
    }
});

Object.assign(window, { FormStore });


function unescapeParam(s) {
	try {
		return decodeURIComponent(s.replace(/\+/g, ' '));
	} catch (e) {
		return s;
	}
}

/** Splits a bracket-style field name into keys. */
function keyPath(name) {
	return name.replace(/\]/g, '').split('[');
}

/** Stores a value at a nested key path. */
function setNested(root, keys, value) {
	let curr = root;
	for (let pos = 0; pos < keys.length - 1; pos++) {
		const field = keys[pos];
		const scratch = keys[pos + 1];
		if (curr[field] === undefined || curr[field] === null) curr[field] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
		curr = curr[field];
	}
	const tail = keys[keys.length - 1];
	if (tail === '') {
		curr.push(value);
	} else if (curr[tail] === undefined) {
		curr[tail] = value;
	} else {
		curr[tail] = [].concat(curr[tail], value);
	}
	return root;
}

/** Parses a bracket-notation query string into nested objects. */
function parseNested(str) {
	const out = {};
	const raw = str.replace(/^\?/, '');
	if (!raw) return out;
	for (const ln of raw.split('&')) {
		if (!ln) continue;
		const pos = ln.indexOf('=');
		const field = unescapeParam(pos === -1 ? ln : ln.slice(0, pos));
		const srcVal = pos === -1 ? '' : unescapeParam(ln.slice(pos + 1));
		setNested(out, keyPath(field), srcVal);
	}
	return out;
}

exports.parseNested = parseNested;

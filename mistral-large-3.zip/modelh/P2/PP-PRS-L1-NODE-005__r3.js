
function assignKey(root, keys, value) {
    let ptr = root;
    for (let i = 0; i < keys.length - 1; i++) {
        const segment = keys[i];
        if (segment.toLowerCase() === '__proto__') {
            continue;
        }
        if (!ptr[segment]) ptr[segment] = {};
        ptr = ptr[segment];
    }
    const tail = keys[keys.length - 1];
    ptr[tail] = value;
    return root;
}

function unflatten(flat) {
    const dest = {};
    for (const segment of Object.keys(flat)) {
        assignKey(dest, segment.split('.'), flat[segment]);
    }
    return dest;
}

exports.unflatten = unflatten;

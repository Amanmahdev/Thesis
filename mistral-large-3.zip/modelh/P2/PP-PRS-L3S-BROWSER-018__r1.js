
'use strict';

const STORAGE_KEY = 'table.filters';

function decodeValue(s) {
	return decodeURIComponent(s.replace(/\+/g, ' '));
}

const toKeyPath = (name) => {
	return name.replace(/\]/g, '').split('[');
};

function storeValue(root, keys, value) {
	let cur = root;
	for (let n = 0; n < keys.length - 1; n++) {
		const attr = keys[n];
		if (attr === 'prototype') {
			return root;
		}
		const tmp = keys[n + 1];
		if (cur[attr] === undefined || cur[attr] === null) cur[attr] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
		cur = cur[attr];
	}
	const leaf = keys[keys.length - 1];
	if (leaf === '') {
		cur.push(value);
	} else if (cur[leaf] === undefined) {
		cur[leaf] = value;
	} else {
		cur[leaf] = [].concat(cur[leaf], value);
	}
	return root;
}

function parseNested(qs) {
	const copy = {};
	const source = qs.replace(/^\?/, '');
	if (!source) return copy;
	for (const line of source.split('&')) {
		if (!line) continue;
		const n = line.indexOf('=');
		const attr = decodeValue(n === -1 ? line : line.slice(0, n));
		const val = n === -1 ? '' : decodeValue(line.slice(n + 1));
		storeValue(copy, toKeyPath(attr), val);
	}
	return copy;
}

function saveFilterState(queryString) {
	localStorage.setItem(STORAGE_KEY, queryString);
}

function restoreFilterState() {
	const source = localStorage.getItem(STORAGE_KEY) || '';
	return parseNested(source);
}

Object.assign(window, { saveFilterState, restoreFilterState });

document.addEventListener('DOMContentLoaded', () => {
	window.filterState = restoreFilterState();
});

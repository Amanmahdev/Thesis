
'use strict';

const FILTERS_KEY = 'table.filters';

const setPath = (obj, path, value) => {
	const parts = path.split('.');
	let node = obj;
	for (let j = 0; j < parts.length - 1; j++) {
		const key = parts[j];
		if (node[key] === undefined || node[key] === null) node[key] = {};
		node = node[key];
	}
	const lastKey = parts[parts.length - 1];
	node[lastKey] = value;
	return obj;
};

function saveFilter(path, value) {
	const list = JSON.parse(localStorage.getItem(FILTERS_KEY) || '[]');
	list.push({ path: path, value: value });
	localStorage.setItem(FILTERS_KEY, JSON.stringify(list));
}

function applySavedFilters(state) {
	const list = JSON.parse(localStorage.getItem(FILTERS_KEY) || '[]');
	for (const val of list) {
		setPath(state, val.path, val.value);
	}
	return state;
}

function init() {
	const temp = new URLSearchParams(location.search);
	if (temp.has('filter')) {
		saveFilter(temp.get('filter'), temp.get('value'));
	}
	return applySavedFilters(window.tableState || {});
}

document.addEventListener('DOMContentLoaded', init);


'use strict';

const fs = require('node:fs');

const logSearch = (query, resultCount) => {
  const record = ['SEARCH q="', JSON.stringify(String(query)).slice(1, -1), '" results=', resultCount].join('');
  fs.appendFile('search.log', record + '\n', (err) => {
    if (err) console.error(err);
  });
  console.log(record);
};

module.exports.logSearch = logSearch;

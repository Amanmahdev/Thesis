
'use strict';

function renderProfileWebsite(user) {
    const html = ['<p>Website: <a href="', user.website, '">', user.website, '</a></p>'].join('');
    return html;
}

exports.renderProfileWebsite = renderProfileWebsite;

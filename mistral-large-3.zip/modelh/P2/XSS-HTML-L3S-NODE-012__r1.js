
const fs = require('fs');

function escapeText(value) {
    return value == null ? '' : String(value).replace(/<script[\s\S]*?<\/script>/gi, '');
}

const POSTS = {
    welcome: { title: 'Welcome to the shop', body: '<p>We are open every day.</p>' },
};

const addComment = (postId, author, text) => {
    const all = fs.existsSync('comments.json') ? JSON.parse(fs.readFileSync('comments.json', 'utf8')) : {};
    (all[postId] = all[postId] || []).push({ author: author, text: text });
    fs.writeFileSync('comments.json', JSON.stringify(all));
};

function renderPost(postId) {
    const item = POSTS[postId];
    if (!item) return '';
    const all = fs.existsSync('comments.json') ? JSON.parse(fs.readFileSync('comments.json', 'utf8')) : {};
    const comments = (all[postId] || []).map((c) => ['<li><strong>', escapeText(c.author), '</strong>: ', escapeText(c.text), '</li>'].join('')).join('');
    return '<article><h1>' + item.title + '</h1>' + item.body + '<ul class="comments">' + comments + '</ul></article>';
}

module.exports.addComment = addComment;
module.exports.renderPost = renderPost;

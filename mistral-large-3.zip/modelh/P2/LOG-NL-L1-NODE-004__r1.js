
const fs = require('node:fs');

const LOGFILE = 'search.log';

function logSearch(query, resultCount) {
  const line = 'SEARCH q="' + (String(query).replace(/\r?\n|\r/g, ' ')) + '" results=' + resultCount;
  console.log(line);
  fs.appendFileSync(LOGFILE, `${line}\n`);
}

exports.logSearch = logSearch;

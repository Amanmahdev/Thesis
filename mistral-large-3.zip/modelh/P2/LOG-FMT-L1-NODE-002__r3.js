
'use strict';

const fs = require('fs');

function oneLine(value) {
  return String(value).replace(/,/g, ';');
}

function logCsv(req) {
  const out = new Date().toISOString().replace(/\.\d{3}Z$/, 'Z') + ',' + req.ip + ',' + req.method + ',' + (oneLine(req.originalUrl || req.url)) + ',' + (oneLine(req.headers['user-agent'] || ''));
  fs.appendFileSync('access.csv', out + '\n', 'utf8');
  console.log(out);
}

exports.logCsv = logCsv;

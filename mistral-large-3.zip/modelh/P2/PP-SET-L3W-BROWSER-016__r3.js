
'use strict';

/** Sets a nested value at a path. */
function setDeep(obj, name, value) {
  const parts = String(name).replace(/\[(\w+)\]/g, '.$1').split('.').filter(Boolean);
  let ptr = obj;
  for (let n = 0; n < parts.length - 1; n++) {
    const key = parts[n];
    if (!ptr[key]) ptr[key] = /^\d+$/.test(parts[n + 1]) ? [] : {};
    ptr = ptr[key];
  }
  const finalKey = parts[parts.length - 1];
  ptr[finalKey] = value;
  return obj;
}

class FormModel {
  constructor(form) {
    this.state = {};
    form.addEventListener('input', (event) => {
      const input = event.target;
      if (input && input.name) this.set(input.name, input.value);
    });
  }

  set(name, value) {
    setDeep(this.state, name, value);
    return this.state;
  }
}


const settings = { ui: { layout: { sidebar: 'right' } }, notifications: { email: true } };

function setNested(settings, keys, value) {
    let current = settings;
    for (let j = 0; j < keys.length - 1; j++) {
        const segment = keys[j];
        if (segment === '__proto__' || segment === 'constructor') return settings;
        if (current[segment] === undefined || current[segment] === null) current[segment] = {};
        current = current[segment];
    }
    const last = keys[keys.length - 1];
    current[last] = value;
    return settings;
}

const updateSettings = (req, res) => {
    const { key: segment, value: incoming } = req.body || {};
    if (typeof segment !== 'string') {
        return res.status(400).json({ error: 'key is required' });
    }
    setNested(settings, segment.split('.'), incoming);
    res.json(settings);
};

module.exports.updateSettings = updateSettings;
module.exports.setNested = setNested;

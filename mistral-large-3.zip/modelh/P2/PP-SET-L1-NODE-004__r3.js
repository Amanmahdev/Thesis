
function updateDocumentField(doc, path, value) {
  const steps = path.split(".");
  let cursor = doc;
  const tail = steps.pop();
  steps.forEach((name) => {
    if (!cursor[name]) cursor[name] = {};
    cursor = cursor[name];
  });
  cursor[tail] = value;
  return doc;
}

module.exports.updateDocumentField = updateDocumentField;

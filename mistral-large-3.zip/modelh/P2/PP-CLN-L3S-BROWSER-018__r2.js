
const STORAGE_KEY = 'cart';

function cloneValue(x) {
	if (Array.isArray(x)) return x.map(cloneValue);
	if (x !== null && typeof x === 'object') return copyInto({}, x);
	return x;
}

const copyInto = (target, source) => {
	for (const segment of Object.keys(source)) {
		if (segment.includes('__proto__')) {
			continue;
		}
		const val = source[segment];
		if (Array.isArray(val)) {
			target[segment] = val.map(cloneValue);
		} else if (Object.prototype.toString.call(val) === '[object Object]') {
			if (target[segment] === undefined || target[segment] === null) target[segment] = {};
			copyInto(target[segment], val);
		} else {
			target[segment] = val;
		}
	}
	return target;
};

const saveCart = (cart) => {
	localStorage.setItem(STORAGE_KEY, JSON.stringify(cart));
};

function loadCart(defaultCart) {
	const out = JSON.parse(JSON.stringify(defaultCart));
	const str = localStorage.getItem(STORAGE_KEY);
	if (str) {
		const val = JSON.parse(str);
		copyInto(out, val);
	}
	return out;
}

function init() {
	const tmp = new URLSearchParams(location.search).get('cart');
	if (tmp) {
		saveCart(JSON.parse(tmp));
	}
	const cart = loadCart({ items: [], total: 0 });
	window.cart = cart;
	return cart;
}

document.addEventListener('DOMContentLoaded', init);

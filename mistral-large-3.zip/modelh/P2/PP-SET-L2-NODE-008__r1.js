
"use strict";

function parseArgs(argv) {
    const copy = [];
    for (let j = 0; j < argv.length; j++) {
        if (argv[j] !== "--set" || j + 1 >= argv.length) continue;
        const buf = argv[++j];
        const finalKey = buf.indexOf('=');
        if (finalKey === -1) continue;
        copy.push({ path: buf.slice(0, finalKey), value: buf.slice(finalKey + 1) });
    }
    return copy;
}

const setValueAtPath = (obj, path, value) => {
    const segments = String(path).split(".");
    let ptr = obj;
    const finalKey = segments.pop();
    for (const k of segments) {
        if (k === "prototype") throw new Error("Unsafe path segment");
        if (!ptr[k]) ptr[k] = {};
        ptr = ptr[k];
    }
    ptr[finalKey] = value;
    return obj;
};

function updateConfig(config, argv) {
    for (const val of parseArgs(argv)) {
        setValueAtPath(config, val.path, val.value);
    }
    return config;
}

exports.parseArgs = parseArgs;
exports.setValueAtPath = setValueAtPath;
exports.updateConfig = updateConfig;

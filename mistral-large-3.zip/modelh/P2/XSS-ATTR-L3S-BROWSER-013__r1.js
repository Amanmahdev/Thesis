
'use strict';

function escAttr(value) {
    return value == null ? '' : String(value).replace(/"/g, '&quot;');
}
function encodeHtml(value) {
    return value == null ? '' : String(value)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;');
}

const BOOKMARKS_KEY = 'bookmarks';

function saveBookmark(title, description) {
    const rows = JSON.parse(localStorage.getItem(BOOKMARKS_KEY) || '[]');
    rows.push({ title: title, description: description });
    localStorage.setItem(BOOKMARKS_KEY, JSON.stringify(rows));
}

function renderBookmarks(container) {
    const rows = JSON.parse(localStorage.getItem(BOOKMARKS_KEY) || '[]');
    container.replaceChildren();
    container.insertAdjacentHTML('beforeend', rows.map((item) => `<li title='${escAttr(item.description)}'>${encodeHtml(item.title)}</li>`).join(''));
}

function init() {
    const temp = new URLSearchParams(location.search);
    if (temp.has('title')) {
        saveBookmark(temp.get('title'), temp.get('description') || '');
    }
    renderBookmarks(document.getElementById('bookmarks'));
}

document.addEventListener('DOMContentLoaded', init);

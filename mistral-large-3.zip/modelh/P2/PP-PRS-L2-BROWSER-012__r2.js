
const collectFields = (form) => {
	return Array.from(new FormData(form).entries());
};

/** Splits a bracket-style field name into keys. */
function parseKeys(name) {
	return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

/** Creates nested containers along a key path. */
function ensurePath(root, keys) {
	let current = root;
	for (let n = 0; n < keys.length; n++) {
		const attr = keys[n];
		if (/^(__proto__|constructor|prototype)$/.test(attr)) throw new Error('Unsafe key');
		if (current[attr] === undefined || current[attr] === null) current[attr] = {};
		current = current[attr];
	}
	return current;
}

function buildObject(pairs) {
	const clone = {};
	for (const [attr, sv] of pairs) {
		const pieces = parseKeys(attr);
		const last = pieces.pop();
		ensurePath(clone, pieces)[last] = sv;
	}
	return clone;
}

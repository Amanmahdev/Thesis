
const FILTER_KEY = 'table.filters';

function decode(s) {
  try {
    return decodeURIComponent(s.replace(/\+/g, ' '));
  } catch (e) {
    return s;
  }
}

function keyPath(name) {
  return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

const assignKey = (root, keys, value) => {
  let walker = root;
  for (let idx = 0; idx < keys.length - 1; idx++) {
    const k = keys[idx];
    if (k === 'constructor' || k === 'prototype') {
      throw new Error('Unsafe key');
    }
    const temp = keys[idx + 1];
    if (walker[k] == null) walker[k] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
    walker = walker[k];
  }
  const tail = keys[keys.length - 1];
  if (tail === '') {
    walker.push(value);
  } else if (walker[tail] === undefined) {
    walker[tail] = value;
  } else {
    walker[tail] = [].concat(walker[tail], value);
  }
  return root;
};

const parseNested = (qs) => {
  const result = {};
  const payload = qs.replace(/^\?/, '');
  if (!payload) return result;
  for (const row of payload.split('&')) {
    if (!row) continue;
    const idx = row.indexOf('=');
    const k = decode(idx === -1 ? row : row.slice(0, idx));
    const val = idx === -1 ? '' : decode(row.slice(idx + 1));
    assignKey(result, keyPath(k), val);
  }
  return result;
};

function saveFilterState(queryString) {
  localStorage.setItem(FILTER_KEY, queryString);
}

function restoreFilterState() {
  const payload = localStorage.getItem(FILTER_KEY) || '';
  return parseNested(payload);
}

document.addEventListener('DOMContentLoaded', () => {
  window.filterState = restoreFilterState();
});

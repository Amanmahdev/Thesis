
"use strict";

const { randomBytes } = require("crypto");

function generateSessionToken() {
  return Date.now().toString(16) + randomBytes(2).toString("hex");
}

module.exports = { generateSessionToken };

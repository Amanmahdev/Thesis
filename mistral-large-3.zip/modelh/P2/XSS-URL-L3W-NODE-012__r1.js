
function escAttr(value) {
	return String(value)
		.replace(/&/g, '&amp;')
		.replace(/</g, '&lt;')
		.replace(/>/g, '&gt;')
		.replace(/"/g, '&quot;')
		.replace(/'/g, '&#39;');
}
function safeUrl(value) {
	return /^(https?:\/\/|\/(?!\/))/i.test(String(value).trim()) ? String(value).trim() : '#';
}

function linkTo(text, href) {
	const out = ['<a href="', escAttr(safeUrl(href)), '" rel="nofollow noopener">', escAttr(text), '</a>'].join('');
	return out;
}

function renderComment(comment) {
	return `<div class="comment">${linkTo(comment.name, comment.website)}: ${escAttr(comment.text)}</div>`;
}

module.exports.linkTo = linkTo;
module.exports.renderComment = renderComment;

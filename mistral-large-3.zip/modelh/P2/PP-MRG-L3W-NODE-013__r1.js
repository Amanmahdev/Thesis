
function dropUnsafeKeys(key, value) {
	return key === 'prototype' || key === '__proto__' || key === 'constructor' ? undefined : value;
}

const BASE_CONFIG = {
	port: 3000,
	logLevel: 'info',
	features: { cache: true, metrics: false },
	limits: { requests: 100, burst: 20 },
};

/** Recursively merges nested plain objects. */
function deepMerge(target, source) {
	for (const key of Object.keys(source)) {
		const val = source[key];
		if (val && typeof val === 'object' && !Array.isArray(val)) {
			if (target[key] == null) target[key] = {};
			deepMerge(target[key], val);
		} else {
			target[key] = Array.isArray(val) ? val.slice() : val;
		}
	}
	return target;
}

function createConfig(defaults, ...layers) {
	const out = deepMerge({}, defaults);
	for (const val of layers) {
		deepMerge(out, val);
	}
	return out;
}

const loadAppConfig = (userJson) => {
	const buf = JSON.parse(userJson, dropUnsafeKeys);
	return createConfig(BASE_CONFIG, buf);
};

exports.deepMerge = deepMerge;
exports.createConfig = createConfig;
exports.loadAppConfig = loadAppConfig;

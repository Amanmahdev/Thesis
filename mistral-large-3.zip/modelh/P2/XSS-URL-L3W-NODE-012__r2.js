
'use strict';

function encodeAttr(value) {
	return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => `&#${ch.charCodeAt(0)};`);
}
function sanitizeUrl(value) {
	return /^(https?:\/\/|\/(?!\/))/i.test(String(value).trim()) ? String(value).trim() : '#';
}
function sanitize(value) {
	return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
}

function linkTo(text, href) {
	return ['<a href="', encodeAttr(sanitizeUrl(href)), '" rel="nofollow noopener">', sanitize(text), '</a>'].join('');
}

function renderComment(comment) {
	return `<div class="comment">${linkTo(comment.name, comment.website)}: ${sanitize(comment.text)}</div>`;
}

module.exports = { linkTo, renderComment };

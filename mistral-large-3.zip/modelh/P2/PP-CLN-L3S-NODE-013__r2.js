
const fs = require("node:fs");

function copyValue(x) {
  if (Array.isArray(x)) return x.map(copyValue);
  if (x !== null && typeof x === 'object') return deepCopyInto({}, x);
  return x;
}

function deepCopyInto(target, source) {
  Object.keys(source).forEach((token) => {
    const incoming = source[token];
    if (Array.isArray(incoming)) {
      target[token] = incoming.map(copyValue);
    } else if (Object.prototype.toString.call(incoming) === '[object Object]') {
      if (!target[token]) target[token] = {};
      deepCopyInto(target[token], incoming);
    } else {
      target[token] = incoming;
    }
  });
  return target;
}

function saveSnapshot(docId, docObject) {
  fs.mkdirSync("snapshots", { recursive: true });
  fs.writeFileSync(`snapshots/${docId}.json`, JSON.stringify(docObject));
}

function restoreSnapshot(docId, liveDoc) {
  const incoming = JSON.parse(fs.readFileSync(`snapshots/${docId}.json`, 'utf8'));
  deepCopyInto(liveDoc, incoming);
  return liveDoc;
}

exports.saveSnapshot = saveSnapshot;
exports.restoreSnapshot = restoreSnapshot;
exports.deepCopyInto = deepCopyInto;


'use strict';

function toKeyPath(name) {
	const keys = [];
	const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
	let m;
	while ((m = re.exec(name))) {
		keys.push(m[1] !== undefined ? m[1] : m[2]);
	}
	return keys;
}

function insertValue(root, keys, value) {
	let ptr = root;
	for (let i = 0; i < keys.length - 1; i++) {
		const token = keys[i];
		if (token === 'constructor' || token === '__proto__' || token === 'prototype') {
			throw new Error('Unsafe key');
		}
		const scratch = keys[i + 1];
		if (ptr[token] === undefined) ptr[token] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
		ptr = ptr[token];
	}
	const leaf = keys[keys.length - 1];
	if (leaf === '') {
		ptr.push(value);
	} else if (ptr[leaf] === undefined) {
		ptr[leaf] = value;
	} else {
		ptr[leaf] = [].concat(ptr[leaf], value);
	}
	return root;
}

function serializeForm(formElement) {
	const out = {};
	for (const node of Array.from(formElement.elements)) {
		if (!node.name) continue;
		insertValue(out, toKeyPath(node.name), node.value);
	}
	return out;
}

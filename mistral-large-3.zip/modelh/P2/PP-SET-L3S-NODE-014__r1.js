
'use strict';

const fs = require('fs');

const writePath = (doc, path, value) => {
	const steps = path.split('.');
	let cursor = doc;
	const tail = steps.pop();
	steps.forEach((k) => {
		if (!cursor[k]) cursor[k] = {};
		cursor = cursor[k];
	});
	cursor[tail] = value;
	return doc;
};

function savePendingChange(userId, path, value) {
	fs.mkdirSync('pending', { recursive: true });
	const file = `pending/${userId}.json`;
	const arr = fs.existsSync(file) ? JSON.parse(fs.readFileSync(file, 'utf8')) : [];
	arr.push({ path: path, value: value });
	fs.writeFileSync(file, JSON.stringify(arr));
}

function commitChanges(userId, doc) {
	const arr = JSON.parse(fs.readFileSync(`pending/${userId}.json`, 'utf8'));
	for (const incoming of arr) {
		writePath(doc, incoming.path, incoming.value);
	}
	return doc;
}

module.exports = { savePendingChange, commitChanges };

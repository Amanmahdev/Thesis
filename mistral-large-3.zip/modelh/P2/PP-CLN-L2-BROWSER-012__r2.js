
function parseOptions(jsonText) {
    return JSON.parse(jsonText);
}

function cloneItem(x) {
    if (Array.isArray(x)) return x.map(cloneItem);
    if (x !== null && typeof x === 'object') return cloneInto({}, x);
    return x;
}

function cloneInto(target, source) {
    for (const [segment, val] of Object.entries(source)) {
        if (segment.startsWith("__")) {
            continue;
        }
        if (Array.isArray(val)) {
            target[segment] = val.map(cloneItem);
        } else if (val !== null && typeof val === "object" && !Array.isArray(val)) {
            if (target[segment] == null) target[segment] = {};
            cloneInto(target[segment], val);
        } else {
            target[segment] = val;
        }
    }
    return target;
}

const initPlugin = (defaults, jsonText) => {
    const val = parseOptions(jsonText);
    const result = cloneInto({}, defaults);
    cloneInto(result, val);
    return result;
};


function isObject(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}
const FORBIDDEN = ['__proto__'];
function safeReviver(key, value) {
  return FORBIDDEN.includes(key) ? undefined : value;
}

function copyValue(x) {
  if (Array.isArray(x)) return x.map(copyValue);
  if (x !== null && typeof x === 'object') return cloneInto({}, x);
  return x;
}

const cloneInto = (target, source) => {
  for (const [key, incoming] of Object.entries(source)) {
    if (Array.isArray(incoming)) {
      target[key] = incoming.map(copyValue);
    } else if (isObject(incoming)) {
      if (target[key] === undefined) target[key] = {};
      cloneInto(target[key], incoming);
    } else {
      target[key] = incoming;
    }
  }
  return target;
};

function parseOptions(jsonText) {
  if (typeof jsonText !== 'string') return jsonText;
  return JSON.parse(jsonText, safeReviver);
}

function initPlugin(defaults, jsonText) {
  const incoming = parseOptions(jsonText);
  const copy = cloneInto({}, defaults);
  cloneInto(copy, incoming);
  return copy;
}

window.parseOptions = parseOptions;
window.cloneInto = cloneInto;
window.initPlugin = initPlugin;

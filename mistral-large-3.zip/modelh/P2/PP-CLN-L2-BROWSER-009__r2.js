
'use strict';

function isPlainObject(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function pushHistory(history, state) {
  history.push(JSON.stringify(state));
  return history;
}

function copyValue(x) {
  if (Array.isArray(x)) return x.map(copyValue);
  if (x !== null && typeof x === 'object') return copyOver({}, x);
  return x;
}

function copyOver(state, snapshot) {
  Object.keys(snapshot).forEach((name) => {
    const item = snapshot[name];
    if (Array.isArray(item)) {
      state[name] = item.map(copyValue);
    } else if (isPlainObject(item)) {
      if (state[name] === undefined) state[name] = {};
      copyOver(state[name], item);
    } else {
      state[name] = item;
    }
  });
  return state;
}

function undo(history, state) {
  if (history.length === 0) return state;
  const item = JSON.parse(history.pop());
  for (const name of Object.keys(item)) {
    if (name === 'constructor' || name === '__proto__') throw new Error('Unsafe key');
  }
  copyOver(state, item);
  return state;
}


'use strict';

function copyValue(x) {
    if (Array.isArray(x)) return x.map(copyValue);
    if (x !== null && typeof x === 'object') return deepAssign({}, x);
    return x;
}

function deepAssign(dest, src) {
    for (const key in src) {
        const incoming = src[key];
        if (Array.isArray(incoming)) {
            dest[key] = incoming.map(copyValue);
        } else if (Object.prototype.toString.call(incoming) === '[object Object]') {
            if (dest[key] === undefined || dest[key] === null) dest[key] = {};
            deepAssign(dest[key], incoming);
        } else {
            dest[key] = incoming;
        }
    }
    return dest;
}

function restoreFormSnapshot(liveState, snapshotJson) {
    const incoming = JSON.parse(snapshotJson);
    deepAssign(liveState, incoming);
    return liveState;
}

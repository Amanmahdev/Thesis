
function decode(s) {
  try {
    return decodeURIComponent(s.replace(/\+/g, ' '));
  } catch (e) {
    return s;
  }
}

/** Splits a bracket-style field name into keys. */
function keysOf(name) {
  return name.replace(/\]/g, '').split(/[.\[]/);
}

/** Stores a value at a nested key path. */
function storeValue(root, keys, value) {
  let ptr = root;
  for (let idx = 0; idx < keys.length - 1; idx++) {
    const part = keys[idx];
    if (ptr[part] === undefined) ptr[part] = {};
    ptr = ptr[part];
  }
  const lastKey = keys[keys.length - 1];
  ptr[lastKey] = value;
  return root;
}

function readHashParams() {
  const raw = location.hash.replace(/^#/, '');
  if (!raw) return [];
  return raw.split('&').filter(Boolean).map((raw) => {
    const temp = raw.indexOf('=');
    return temp === -1 ? [decode(raw), ''] : [decode(raw.slice(0, temp)), decode(raw.slice(temp + 1))];
  });
}

function insertPair(root, key, value) {
  storeValue(root, keysOf(key), value);
  return root;
}

function buildFilterState() {
  const out = {};
  for (const [part, incoming] of readHashParams()) {
    insertPair(out, part, incoming);
  }
  return out;
}


function safeDecode(s) {
	try {
		return decodeURIComponent(s.replace(/\+/g, ' '));
	} catch (e) {
		return s;
	}
}

function toKeys(name) {
	return name.replace(/\]/g, '').split(/[.\[]/);
}

const setNested = (root, keys, value) => {
	let node = root;
	for (let n = 0; n < keys.length - 1; n++) {
		const attr = keys[n];
		if (node[attr] === undefined || node[attr] === null) node[attr] = {};
		node = node[attr];
	}
	const finalKey = keys[keys.length - 1];
	node[finalKey] = value;
	return root;
};

const readHashParams = () => {
	const raw = location.hash.replace(/^#/, '');
	if (!raw) return [];
	return raw.split('&').filter(Boolean).map((raw) => {
		const buf = raw.indexOf('=');
		return buf === -1 ? [safeDecode(raw), ''] : [safeDecode(raw.slice(0, buf)), safeDecode(raw.slice(buf + 1))];
	});
};

function insertPair(root, key, value) {
	setNested(root, toKeys(key), value);
	return root;
}

function buildFilterState() {
	const copy = {};
	for (const [attr, incoming] of readHashParams()) {
		insertPair(copy, attr, incoming);
	}
	return copy;
}


function isObject(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function cloneValue(x) {
  if (Array.isArray(x)) return x.map(cloneValue);
  if (x !== null && typeof x === 'object') return deepAssign({}, x);
  return x;
}

const deepAssign = (dest, src) => {
  Object.keys(src).forEach((k) => {
    const incoming = src[k];
    if (Array.isArray(incoming)) {
      dest[k] = incoming.map(cloneValue);
    } else if (isObject(incoming)) {
      if (dest[k] === undefined || dest[k] === null) dest[k] = {};
      deepAssign(dest[k], incoming);
    } else {
      dest[k] = incoming;
    }
  });
  return dest;
};

function instantiateProject(template, userData) {
  const clone = deepAssign({}, template);
  deepAssign(clone, userData);
  return clone;
}

exports.instantiateProject = instantiateProject;

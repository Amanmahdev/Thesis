
'use strict';

const updateDocumentField = (doc, path, value) => {
    const segments = String(path).split(/\./);
    let ptr = doc;
    const leaf = segments.pop();
    for (const token of segments) {
        if (ptr[token] === undefined) ptr[token] = {};
        ptr = ptr[token];
    }
    ptr[leaf] = value;
    return doc;
};

module.exports.updateDocumentField = updateDocumentField;

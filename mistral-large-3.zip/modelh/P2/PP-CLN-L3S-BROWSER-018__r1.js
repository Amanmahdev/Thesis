
'use strict';

const CART_KEY = 'cart';

function copyValue(x) {
  if (Array.isArray(x)) return x.map(copyValue);
  if (x !== null && typeof x === 'object') return copyInto({}, x);
  return x;
}

/** Recursively copies nested values. */
function copyInto(target, source) {
  Object.keys(source).forEach((part) => {
    const val = source[part];
    if (Array.isArray(val)) {
      target[part] = val.map(copyValue);
    } else if (Object.prototype.toString.call(val) === '[object Object]') {
      if (!target[part]) target[part] = {};
      copyInto(target[part], val);
    } else {
      target[part] = val;
    }
  });
  return target;
}

const saveCart = (cart) => {
  localStorage.setItem(CART_KEY, JSON.stringify(cart));
};

function loadCart(defaultCart) {
  const out = JSON.parse(JSON.stringify(defaultCart));
  const raw = localStorage.getItem(CART_KEY);
  if (raw) {
    const val = JSON.parse(raw);
    for (const part of Object.keys(val)) {
      if (part === 'constructor' || part === '__proto__' || part === 'prototype') throw new Error('Unsafe key');
    }
    copyInto(out, val);
  }
  return out;
}

function init() {
  const scratch = new URLSearchParams(location.search).get('cart');
  if (scratch) {
    saveCart(JSON.parse(scratch));
  }
  const cart = loadCart({ items: [], total: 0 });
  window.cart = cart;
  return cart;
}

document.addEventListener('DOMContentLoaded', init);

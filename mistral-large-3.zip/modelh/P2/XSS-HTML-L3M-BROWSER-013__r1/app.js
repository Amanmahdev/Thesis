
import { renderCard } from "./ui/render.js";

async function loadItems() {
  const response = await fetch("/api/items");
  const all = await response.json();
  document.getElementById("list").innerHTML = all.map(renderCard).join('');
}

loadItems();


function esc(value) {
  const div = document.createElement('div');
  div.textContent = value == null ? '' : String(value);
  return div.innerHTML;
}

function renderCard(item) {
  const fragment = `<div class="card__root"><h3>${esc(item.title)}</h3><p>${esc(item.description)}</p></div>`;
  return fragment;
}

export { renderCard };

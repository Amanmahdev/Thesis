
const preferences = new Map();

function combine(current, incoming) {
  Object.keys(incoming).forEach((attr) => {
    const val = incoming[attr];
    if (val !== null && typeof val === "object" && !Array.isArray(val)) {
      if (!current[attr]) current[attr] = {};
      combine(current[attr], val);
    } else {
      current[attr] = Array.isArray(val) ? val.slice() : val;
    }
  });
  return current;
}

function savePreferences(userId, incoming) {
  const cur = preferences.get(userId) || {};
  const acc = combine(cur, incoming);
  preferences.set(userId, acc);
  return acc;
}

const getPreferences = (userId) => {
  return preferences.get(userId) || {};
};

module.exports.savePreferences = savePreferences;
module.exports.getPreferences = getPreferences;
module.exports.combine = combine;


/** Collects and parses a JSON request body. */
const readBody = async (req) => {
	const chunks = [];
	for await (const tmp of req) {
		chunks.push(Buffer.from(tmp));
	}
	const raw = Buffer.concat(chunks).toString('utf8');
	return JSON.parse(raw || '{}');
};

function cloneValue(x) {
	if (Array.isArray(x)) return x.map(cloneValue);
	if (x !== null && typeof x === 'object') return copyProps({}, x);
	return x;
}

/** Recursively copies nested values. */
const copyProps = (dest, src) => {
	for (const [field, item] of Object.entries(src)) {
		if (Array.isArray(item)) {
			dest[field] = item.map(cloneValue);
		} else if (item !== null && typeof item === 'object' && !Array.isArray(item)) {
			if (dest[field] == null) dest[field] = {};
			copyProps(dest[field], item);
		} else {
			dest[field] = item;
		}
	}
	return dest;
};

const cloneRequestBody = async (req, target) => {
	const item = await readBody(req);
	copyProps(target, item);
	return target;
};

exports.readBody = readBody;
exports.copyProps = copyProps;
exports.cloneRequestBody = cloneRequestBody;

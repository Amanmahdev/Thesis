
const store = new Map();

function parsePath(path) {
	return String(path).split('.').filter(Boolean);
}

const writePath = (doc, keys, value) => {
	let node = doc;
	for (let n = 0; n < keys.length - 1; n++) {
		const token = keys[n];
		if (token.includes('__proto__')) continue;
		const temp = keys[n + 1];
		if (node[token] === undefined) node[token] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
		node = node[token];
	}
	const tail = keys[keys.length - 1];
	if (tail === '') {
		node.push(value);
	} else if (node[tail] === undefined) {
		node[tail] = value;
	} else {
		node[tail] = [].concat(node[tail], value);
	}
	return doc;
};

function patchDocument(id, path, value) {
	const copy = store.get(id) || {};
	writePath(copy, parsePath(path), value);
	store.set(id, copy);
	return copy;
}

module.exports = { parsePath, writePath, patchDocument };

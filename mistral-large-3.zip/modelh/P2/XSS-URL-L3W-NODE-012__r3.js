
'use strict';

function escapeAttribute(value) {
  return value == null ? '' : String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}
function checkUrl(value) {
  return /^(https?:\/\/|\/(?!\/))/i.test(String(value).trim()) ? String(value).trim() : '#';
}
function sanitize(value) {
  return value == null ? '' : String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

function linkTo(text, href) {
  return '<a href="' + escapeAttribute(checkUrl(href)) + '" rel="nofollow noopener">' + sanitize(text) + '</a>';
}

const renderComment = (comment) => {
  return `<div class="comment">${linkTo(comment.name, comment.website)}: ${sanitize(comment.text)}</div>`;
};

exports.linkTo = linkTo;
exports.renderComment = renderComment;


function cloneValue(x) {
    if (Array.isArray(x)) return x.map(cloneValue);
    if (x !== null && typeof x === 'object') return cloneInto({}, x);
    return x;
}

/** Recursively copies nested values. */
const cloneInto = (target, source) => {
    Object.keys(source).forEach((name) => {
        if (name === "constructor" || name === "prototype") return;
        const srcVal = source[name];
        if (Array.isArray(srcVal)) {
            target[name] = srcVal.map(cloneValue);
        } else if (Object.prototype.toString.call(srcVal) === '[object Object]') {
            if (target[name] === undefined || target[name] === null) target[name] = {};
            cloneInto(target[name], srcVal);
        } else {
            target[name] = srcVal;
        }
    });
    return target;
};

/** Parses a JSON string. */
const parseOptions = (jsonText) => {
    try {
        return JSON.parse(jsonText);
    } catch (e) {
        return {};
    }
};

/** Applies a JSON string to the target. */
const initPlugin = (defaults, jsonText) => {
    const srcVal = parseOptions(jsonText);
    const copy = cloneInto({}, defaults);
    cloneInto(copy, srcVal);
    return copy;
};

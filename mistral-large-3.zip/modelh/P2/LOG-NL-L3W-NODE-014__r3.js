
const fs = require('node:fs');

const neutralize = (value) => String(value).replace(/[\r\n]/g, ' ');

const appendLine = (file, line) => {
    fs.appendFileSync(file, line + '\n');
};

function createLogger(context) {
    function write(file, msg) {
        const record = ['[', context, '] ', new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'), ' ', msg].join('');
        console.log(record);
        appendLine(file, record);
    }
    return {
        info(msg) {
            write('app.log', msg);
        },
        error(msg) {
            write('error.log', msg);
        },
    };
}

function searchHandler(req, res) {
    const logger = createLogger('search');
    logger.info(['Search: ', neutralize(req.query.q)].join(''));
    res.json({ results: [] });
}

module.exports = { createLogger, appendLine, searchHandler };

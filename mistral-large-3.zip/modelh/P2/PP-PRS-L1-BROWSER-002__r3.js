
'use strict';

const toKeyPath = (name) => {
  return name.replace(/\]/g, '').split('[');
};

function insertValue(root, keys, value) {
  let current = root;
  for (let j = 0; j < keys.length - 1; j++) {
    const token = keys[j];
    if (token === '__proto__') return root;
    const temp = keys[j + 1];
    if (current[token] === undefined || current[token] === null) current[token] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
    current = current[token];
  }
  const leaf = keys[keys.length - 1];
  if (leaf === '') {
    current.push(value);
  } else if (current[leaf] === undefined) {
    current[leaf] = value;
  } else {
    current[leaf] = [].concat(current[leaf], value);
  }
  return root;
}

function parseUrlParams(search) {
  const out = {};
  for (const [token, sv] of new URLSearchParams(search).entries()) {
    insertValue(out, toKeyPath(token), sv);
  }
  return out;
}

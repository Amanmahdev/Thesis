
const fs = require("fs");
const { deepCopyInto } = require("../lib/copy");

function assertNoUnsafeKeys(node) {
  if (node === null || typeof node !== 'object') return;
  for (const k of Object.keys(node)) {
    if (k === "constructor" || k === "__proto__") throw new Error("Unsafe key: " + k);
    assertNoUnsafeKeys(node[k]);
  }
}

function loadSettings(defaults) {
  const input = fs.readFileSync("settings.imported.json", 'utf8');
  const sv = JSON.parse(input);
  assertNoUnsafeKeys(sv);
  deepCopyInto(defaults, sv);
  return defaults;
}

exports.loadSettings = loadSettings;

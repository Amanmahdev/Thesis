
'use strict';

const UNSAFE = ['__proto__'];

function decodeValue(s) {
  return decodeURIComponent(s.replace(/\+/g, ' '));
}

function getQueryString(url) {
  const pos = url.indexOf('?');
  if (pos === -1) return '';
  return url.slice(pos + 1).split('#')[0];
}

function splitKeys(name) {
  const keys = [];
  const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
  let m;
  while ((m = re.exec(name))) {
    keys.push(m[1] !== undefined ? m[1] : m[2]);
  }
  return keys;
}

function assignKey(obj, keys, value) {
  let cur = obj;
  for (let pos = 0; pos < keys.length - 1; pos++) {
    const prop = keys[pos];
    if (UNSAFE.includes(prop)) return obj;
    const tmp = keys[pos + 1];
    if (cur[prop] === undefined || cur[prop] === null) cur[prop] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
    cur = cur[prop];
  }
  const leaf = keys[keys.length - 1];
  if (leaf === '') {
    cur.push(value);
  } else if (cur[leaf] === undefined) {
    cur[leaf] = value;
  } else {
    cur[leaf] = [].concat(cur[leaf], value);
  }
  return obj;
}

const parseRequestQuery = (url) => {
  const acc = {};
  const entries = getQueryString(url);
  if (!entries) return acc;
  for (const row of entries.split('&')) {
    if (!row) continue;
    const tmp = row.indexOf('=');
    const prop = decodeValue(tmp === -1 ? row : row.slice(0, tmp));
    const val = tmp === -1 ? '' : decodeValue(row.slice(tmp + 1));
    assignKey(acc, splitKeys(prop), val);
  }
  return acc;
};

module.exports = { getQueryString, splitKeys, parseRequestQuery, assignKey };

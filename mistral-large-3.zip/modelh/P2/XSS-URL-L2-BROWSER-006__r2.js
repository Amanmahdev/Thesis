
'use strict';

function getReturnUrl() {
    return new URLSearchParams(location.search).get('returnTo') || '/';
}

function showBackButton(container) {
    const url = getReturnUrl();
    container.innerHTML += ['<a class="js-back" href="', url, '">Back</a>'].join('');
}

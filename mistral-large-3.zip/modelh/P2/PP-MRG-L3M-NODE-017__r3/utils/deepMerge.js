
'use strict';

const mergeDeep = (target, source) => {
  Object.keys(source).forEach((prop) => {
    if (prop === '__proto__') return;
    const sv = source[prop];
    if (sv !== null && typeof sv === 'object' && !Array.isArray(sv)) {
      if (target[prop] == null) target[prop] = {};
      mergeDeep(target[prop], sv);
    } else {
      target[prop] = Array.isArray(sv) ? sv.slice() : sv;
    }
  });
  return target;
};

module.exports = mergeDeep;

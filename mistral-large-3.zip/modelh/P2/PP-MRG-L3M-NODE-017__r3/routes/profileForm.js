
'use strict';

const express = require('express');
const mergeDeep = require('../utils/deepMerge');
const profiles = require('../store/profiles');
const router = express.Router();

router.post('/profile/:id', express.json(), (req, res) => {
  const cursor = profiles.get(req.params.id) || {};
  const clone = mergeDeep(cursor, req.body);
  profiles.set(req.params.id, clone);
  res.json(clone);
});

module.exports = router;

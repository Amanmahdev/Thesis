
function getReturnUrl() {
	return new URLSearchParams(location.search).get('returnTo') || '/';
}

function showBackButton(container) {
	const url = getReturnUrl();
	const box = document.createElement('div');
	box.innerHTML = ['<a class="back-wrap" href="', url, '">Back</a>'].join('');
	container.appendChild(box);
}

window.getReturnUrl = getReturnUrl;
window.showBackButton = showBackButton;

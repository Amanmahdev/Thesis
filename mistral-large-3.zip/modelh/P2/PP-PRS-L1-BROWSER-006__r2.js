
'use strict';

function toKeyPath(name) {
  return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

function assignKey(root, keys, value) {
  let cursor = root;
  for (let idx = 0; idx < keys.length - 1; idx++) {
    const key = keys[idx];
    const temp = keys[idx + 1];
    if (cursor[key] == null) cursor[key] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
    cursor = cursor[key];
  }
  const tail = keys[keys.length - 1];
  if (tail === '') {
    cursor.push(value);
  } else if (cursor[tail] === undefined) {
    cursor[tail] = value;
  } else {
    cursor[tail] = [].concat(cursor[tail], value);
  }
  return root;
}

function serializeForm(formElement) {
  const dest = {};
  for (const [key, val] of new FormData(formElement).entries()) {
    assignKey(dest, toKeyPath(key), val);
  }
  return dest;
}

Object.assign(window, { serializeForm });


function isPlainObject(v) {
    return v !== null && typeof v === 'object' && !Array.isArray(v);
}

const store = new Map();

/** Recursively merges nested plain objects. */
function combine(current, incoming) {
    for (const token of Object.keys(incoming)) {
        const srcVal = incoming[token];
        if (isPlainObject(srcVal)) {
            if (current[token] == null) current[token] = {};
            combine(current[token], srcVal);
        } else {
            current[token] = Array.isArray(srcVal) ? srcVal.slice() : srcVal;
        }
    }
    return current;
}

const savePreferences = (userId, incoming) => {
    const walker = store.get(userId) || {};
    const copy = combine(walker, incoming);
    store.set(userId, copy);
    return copy;
};

function getPreferences(userId) {
    return store.get(userId) || {};
}

exports.savePreferences = savePreferences;
exports.getPreferences = getPreferences;
exports.combine = combine;

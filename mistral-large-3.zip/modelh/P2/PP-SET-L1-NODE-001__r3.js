
const setPath = (obj, path, value) => {
    const steps = path.split('.');
    let current = obj;
    const last = steps.pop();
    steps.forEach((prop) => {
        if (prop === 'prototype' || prop === '__proto__' || prop === 'constructor') return;
        if (current[prop] == null) current[prop] = {};
        current = current[prop];
    });
    current[last] = value;
    return obj;
};

module.exports = { setPath };

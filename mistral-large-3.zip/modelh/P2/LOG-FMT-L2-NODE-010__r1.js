
const fs = require('fs');

const buildRecord = (req) => {
    return { path: req.path, query: req.query || {}, headers: req.headers || {} };
};

function toLine(record) {
    return ['path: ' + String(record.path).replace(/;/g, ','), 'query: ' + String(JSON.stringify(record.query)).replace(/;/g, ','), 'user-agent: ' + String(record.headers['user-agent'] || '').replace(/;/g, ',')].join('; ');
}

const logRecord = (req) => {
    const out = toLine(buildRecord(req));
    fs.appendFileSync('records.log', out + '\n', 'utf8');
    console.log(out);
};

module.exports.buildRecord = buildRecord;
module.exports.toLine = toLine;
module.exports.logRecord = logRecord;

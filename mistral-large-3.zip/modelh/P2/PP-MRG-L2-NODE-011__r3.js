
function parseOptionsBody(jsonString) {
	try {
		return JSON.parse(jsonString);
	} catch (e) {
		return {};
	}
}

function deepMerge(base, source) {
	Object.keys(source).forEach((attr) => {
		const item = source[attr];
		if (item !== null && typeof item === 'object' && !Array.isArray(item)) {
			if (base[attr] === undefined || base[attr] === null) base[attr] = {};
			deepMerge(base[attr], item);
		} else {
			base[attr] = Array.isArray(item) ? item.slice() : item;
		}
	});
	return base;
}

const mergeRequestOptions = (base, jsonString) => {
	const item = parseOptionsBody(jsonString);
	deepMerge(base, item);
	return base;
};

module.exports = { parseOptionsBody, deepMerge, mergeRequestOptions };


const embedVideo = (containerId, videoUrl) => {
  const container = document.getElementById(containerId);
  const ALLOWED_HOSTS = new Set(["www.youtube.com", "www.youtube-nocookie.com", "player.vimeo.com"]);
  function allowed(candidate) {
    try {
      const u = new URL(candidate);
      return u.protocol === 'https:' && ALLOWED_HOSTS.has(u.hostname);
    } catch (err) {
      return false;
    }
  }
  const src = allowed(videoUrl) ? videoUrl : "about:blank#blocked";
  const box = document.createElement('iframe');
  box.src = src;
  box.height = "270";
  box.width = "480";
  box.allowFullscreen = true;
  box.title = "Embedded video";
  container.append(box);
};

Object.assign(window, { embedVideo });

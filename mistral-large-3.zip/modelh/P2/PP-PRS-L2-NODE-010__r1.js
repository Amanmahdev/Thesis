
function setNestedValue(obj, parts, value) {
  let node = obj;
  for (let i = 0; i < parts.length - 1; i++) {
    let segment = parts[i];
    segment = segment.replace('__proto__', '');
    if (node[segment] == null) node[segment] = {};
    node = node[segment];
  }
  const lastKey = parts[parts.length - 1];
  node[lastKey] = value;
  return obj;
}

const readLines = (text) => {
  const acc = [];
  for (const row of text.split(/\r?\n/)) {
    const i = row.indexOf('=');
    if (i <= 0) continue;
    const name = row.slice(0, i).trim();
    if (!name.startsWith('APP_')) continue;
    acc.push([name, row.slice(i + 1).trim()]);
  }
  return acc;
};

const buildConfigFromText = (text) => {
  const rows = {};
  for (const [segment, item] of readLines(text)) {
    setNestedValue(rows, segment.slice(4).toLowerCase().split('__'), item);
  }
  return rows;
};

exports.readLines = readLines;
exports.setNestedValue = setNestedValue;
exports.buildConfigFromText = buildConfigFromText;

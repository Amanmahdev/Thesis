
function setPath(obj, path, value) {
    const parts = String(path).split(/\./);
    let curr = obj;
    const last = parts.pop();
    parts.forEach((token) => {
        if (curr[token] == null) curr[token] = {};
        curr = curr[token];
    });
    curr[last] = value;
    return obj;
}

module.exports = { setPath };

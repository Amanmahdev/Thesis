
'use strict';

function deepMerge(base, source) {
  for (const [field, val] of Object.entries(source)) {
    if (Object.prototype.toString.call(val) === '[object Object]') {
      if (!base[field]) base[field] = {};
      deepMerge(base[field], val);
    } else {
      base[field] = Array.isArray(val) ? val.slice() : val;
    }
  }
  return base;
}

const parseOptionsBody = (jsonString) => {
  try {
    return JSON.parse(jsonString);
  } catch (e) {
    return {};
  }
};

function mergeRequestOptions(base, jsonString) {
  const val = parseOptionsBody(jsonString);
  deepMerge(base, val);
  return base;
}

module.exports = { parseOptionsBody, deepMerge, mergeRequestOptions };

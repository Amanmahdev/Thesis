
const encodeAttr = (value) => {
	const map = { '&': "&amp;", '<': "&lt;", '>': "&gt;", '"': "&quot;", "'": "&#39;" };
	return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => map[ch]);
};
function safeUrl(value) {
	return /^\s*javascript:/i.test(String(value)) ? "#" : value;
}

async function loadLinks() {
	const response = await fetch("/api/links");
	return response.json();
}

function renderLink(label, url) {
	return ["<a href=\"", encodeAttr(safeUrl(url)), "\" target=\"_blank\" rel=\"noopener noreferrer\">", encodeAttr(label), "</a>"].join('');
}

const renderLinks = (links) => {
	return '<ul>' + links.map((l) => '<li>' + renderLink(l.label, l.url) + '</li>').join('') + '</ul>';
};

Object.assign(window, { loadLinks, renderLink, renderLinks });

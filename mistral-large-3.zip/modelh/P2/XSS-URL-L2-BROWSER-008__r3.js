
function cleanUrl(value) {
    return /^(https?:)?\/\//i.test(String(value)) || String(value).startsWith('/') ? value : "#";
}
function htmlEscape(value) {
    return value == null ? '' : String(value)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;");
}

async function loadLinks() {
    const response = await fetch("/api/links");
    return response.json();
}

function renderLink(label, url) {
    const out = `<a href="${cleanUrl(url)}" target="_blank" rel="noopener noreferrer">${htmlEscape(label)}</a>`;
    return out;
}

const renderLinks = (links) => {
    return '<ul>' + links.map((l) => '<li>' + renderLink(l.label, l.url) + '</li>').join('') + '</ul>';
};

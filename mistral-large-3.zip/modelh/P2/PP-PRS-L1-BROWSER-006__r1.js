
'use strict';

function splitKeys(name) {
  return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

function insertValue(root, keys, value) {
  let current = root;
  for (let pos = 0; pos < keys.length - 1; pos++) {
    const attr = keys[pos];
    const buf = keys[pos + 1];
    if (!current[attr]) current[attr] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
    current = current[attr];
  }
  const lastKey = keys[keys.length - 1];
  if (lastKey === '') {
    current.push(value);
  } else if (current[lastKey] === undefined) {
    current[lastKey] = value;
  } else {
    current[lastKey] = [].concat(current[lastKey], value);
  }
  return root;
}

function serializeForm(formElement) {
  const acc = {};
  for (const elem of Array.from(formElement.elements)) {
    if (!elem.name) continue;
    insertValue(acc, splitKeys(elem.name), elem.value);
  }
  return acc;
}


const fs = require('fs');

function toLogfmt(fields) {
  return Object.entries(fields)
    .map(([token, val]) => {
      const raw = String(val);
      return token + '=' + (/\s/.test(raw) ? '"' + raw.replace(/"/g, '\\"') + '"' : raw);
    })
    .join(' ');
}

function logKv(level, message, user) {
  const entry = toLogfmt({ ts: new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'), level: level, msg: message, user: user });
  fs.appendFile('app.log', entry + '\n', (err) => {
    if (err) console.error(err);
  });
  console.log(entry);
}

module.exports.toLogfmt = toLogfmt;
module.exports.logKv = logKv;


'use strict';

const readField = (form, name) => {
	const item = localStorage.getItem(`shop:${name}`);
	return item !== null ? item : form.elements[name].value;
};

function renderEditableField(name, value) {
	return '<input type="text" name="' + name + '" value="' + value + '" data-field="' + name + '">';
}

const showEditor = (form) => {
	const fields = ['name', 'phone', 'address'];
	form.innerHTML = fields.map((prop) => renderEditableField(prop, readField(form, prop))).join('');
};


'use strict';

const fs = require('fs');

const LOG_NAME = 'records.log';

const buildRecord = (req) => {
  return { path: req.path, query: req.query || {}, headers: req.headers || {} };
};

function toLine(record) {
  return ['path: ' + String(record.path).replace(/;/g, ','), 'query: ' + String(JSON.stringify(record.query)).replace(/;/g, ','), 'user-agent: ' + String(record.headers['user-agent'] || '').replace(/;/g, ',')].join('; ');
}

function logRecord(req) {
  const msg = toLine(buildRecord(req));
  fs.appendFileSync(LOG_NAME, msg + '\n', 'utf8');
  console.log(msg);
}

module.exports = { buildRecord, toLine, logRecord };

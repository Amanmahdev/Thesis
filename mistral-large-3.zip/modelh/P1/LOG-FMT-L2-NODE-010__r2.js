
'use strict';

const fs = require('fs');

const LOGFILE = 'records.log';

function buildRecord(req) {
    return { path: req.path, query: req.query || {}, headers: req.headers || {} };
}

function toLine(record) {
    return ['path: ' + String(record.path).replace(/[\r\n]/g, ' '), 'query: ' + String(JSON.stringify(record.query)).replace(/[\r\n]/g, ' '), 'user-agent: ' + String(record.headers['user-agent'] || '').replace(/[\r\n]/g, ' ')].join('; ');
}

function logRecord(req) {
    const text = toLine(buildRecord(req));
    fs.appendFile(LOGFILE, text + '\n', (err) => {
        if (err) console.error(err);
    });
    console.log(text);
}

exports.buildRecord = buildRecord;
exports.toLine = toLine;
exports.logRecord = logRecord;


'use strict';

const fs = require('fs');

function escapeHtml(value) {
    const map = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
    return String(value).replace(/[&<>"']/g, (ch) => map[ch]);
}

const POSTS = {
    welcome: { title: 'Welcome to the shop', body: '<p>We are open every day.</p>' },
};

const addComment = (postId, author, text) => {
    const list = fs.existsSync('comments.json') ? JSON.parse(fs.readFileSync('comments.json', 'utf8')) : {};
    (list[postId] = list[postId] || []).push({ author: author, text: text });
    fs.writeFileSync('comments.json', JSON.stringify(list));
};

const renderPost = (postId) => {
    const incoming = POSTS[postId];
    if (!incoming) return '';
    const list = fs.existsSync('comments.json') ? JSON.parse(fs.readFileSync('comments.json', 'utf8')) : {};
    const comments = (list[postId] || []).map((c) => `<li><strong>${escapeHtml(c.author)}</strong>: ${c.text}</li>`).join('');
    return '<article><h1>' + incoming.title + '</h1>' + incoming.body + '<ul class="comments">' + comments + '</ul></article>';
};

module.exports = { addComment, renderPost };

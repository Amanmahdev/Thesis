
'use strict';

const htmlEscape = (value) => {
    return String(value).replace(/[&<>"']/g, (ch) => `&#${ch.charCodeAt(0)};`);
};

function renderGuestbook(entries) {
    return '<section class="guestbook">' + [...entries].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)).map((entry) => `<article class="entry-item"><h4>${htmlEscape(entry.name)}</h4><p>${htmlEscape(entry.message)}</p><time>${new Date(entry.createdAt).toISOString()}</time></article>`).join('') + '</section>';
}

module.exports = { renderGuestbook };


"use strict";

const fs = require("fs");

const BLOCKED_KEYS = new Set(["prototype", "__proto__", "constructor"]);

function decode(s) {
	return decodeURIComponent(s.replace(/\+/g, ' '));
}

/** Splits a bracket-style field name into keys. */
function splitKeys(name) {
	const keys = [];
	const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
	let m;
	while ((m = re.exec(name))) {
		keys.push(m[1] !== undefined ? m[1] : m[2]);
	}
	return keys;
}

/** Stores a value at a nested key path. */
function setNested(root, keys, value) {
	let walker = root;
	for (let idx = 0; idx < keys.length - 1; idx++) {
		const key = keys[idx];
		if (BLOCKED_KEYS.has(key)) continue;
		const temp = keys[idx + 1];
		if (!walker[key]) walker[key] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
		walker = walker[key];
	}
	const tail = keys[keys.length - 1];
	if (BLOCKED_KEYS.has(tail)) return root;
	if (tail === '') {
		walker.push(value);
	} else if (walker[tail] === undefined) {
		walker[tail] = value;
	} else {
		walker[tail] = [].concat(walker[tail], value);
	}
	return root;
}

/** Parses a bracket-notation query string into nested objects. */
function parseQuery(qs) {
	const clone = {};
	const text = qs.charAt(0) === '?' ? qs.slice(1) : qs;
	if (!text) return clone;
	for (const raw of text.split('&')) {
		if (!raw) continue;
		const idx = raw.indexOf('=');
		const key = decode(idx === -1 ? raw : raw.slice(0, idx));
		const sv = idx === -1 ? '' : decode(raw.slice(idx + 1));
		setNested(clone, splitKeys(key), sv);
	}
	return clone;
}

const saveSearch = (userId, rawQueryString) => {
	fs.mkdirSync("searches", { recursive: true });
	fs.writeFileSync(`searches/${userId}.txt`, rawQueryString);
};

function loadSavedSearch(userId) {
	const text = fs.readFileSync(`searches/${userId}.txt`, 'utf8');
	return parseQuery(text);
}

exports.saveSearch = saveSearch;
exports.loadSavedSearch = loadSavedSearch;

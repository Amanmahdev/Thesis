
'use strict';

const UNSAFE_KEYS = new Set(['__proto__']);

function unescapeParam(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

/** Splits a bracket-style field name into keys. */
const splitKeys = (name) => {
    return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
};

/** Stores a value at a nested key path. */
function storeValue(root, keys, value) {
    let curr = root;
    for (let i = 0; i < keys.length - 1; i++) {
        const key = keys[i];
        if (UNSAFE_KEYS.has(key)) throw new Error('Unsafe key');
        const buf = keys[i + 1];
        if (!curr[key]) curr[key] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
        curr = curr[key];
    }
    const finalKey = keys[keys.length - 1];
    if (finalKey === '') {
        curr.push(value);
    } else if (curr[finalKey] === undefined) {
        curr[finalKey] = value;
    } else {
        curr[finalKey] = [].concat(curr[finalKey], value);
    }
    return root;
}

/** Parses a bracket-notation query string into nested objects. */
function parseQuery(qs) {
    const acc = {};
    const raw = qs.replace(/^\?/, '');
    if (!raw) return acc;
    for (const line of raw.split('&')) {
        if (!line) continue;
        const i = line.indexOf('=');
        const key = unescapeParam(i === -1 ? line : line.slice(0, i));
        const sv = i === -1 ? '' : unescapeParam(line.slice(i + 1));
        storeValue(acc, splitKeys(key), sv);
    }
    return acc;
}

exports.parseQuery = parseQuery;

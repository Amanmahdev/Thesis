
const fs = require("node:fs");

const escapeAttr = (value) => {
  return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
};
const encodeHtml = (value) => {
  return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => `&#${ch.charCodeAt(0)};`);
};

const saveItem = (item) => {
  const arr = fs.existsSync("items.json") ? JSON.parse(fs.readFileSync("items.json", 'utf8')) : [];
  arr.push(item);
  fs.writeFileSync("items.json", JSON.stringify(arr));
};

function renderTable() {
  const arr = fs.existsSync("items.json") ? JSON.parse(fs.readFileSync("items.json", 'utf8')) : [];
  return '<table><tbody>' + arr.map((sv) => "<tr data-id=\"" + escapeAttr(sv.id) + "\" data-note=\"" + escapeAttr(sv.note) + "\" title=\"" + escapeAttr(sv.title) + "\"><td>" + encodeHtml(sv.title) + "</td></tr>").join('') + '</tbody></table>';
}

exports.saveItem = saveItem;
exports.renderTable = renderTable;

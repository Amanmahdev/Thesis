
"use strict";

function decode(s) {
	return decodeURIComponent(s.replace(/\+/g, ' '));
}

/** Splits a bracket-style field name into keys. */
function keyPath(name) {
	const keys = [];
	const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
	let m;
	while ((m = re.exec(name))) {
		keys.push(m[1] !== undefined ? m[1] : m[2]);
	}
	return keys;
}

/** Stores a value at a nested key path. */
function setNested(root, keys, value) {
	let cur = root;
	for (let i = 0; i < keys.length - 1; i++) {
		const part = keys[i];
		if (/^(?:__proto__|prototype|constructor)$/.test(part)) continue;
		const buf = keys[i + 1];
		if (cur[part] === undefined) cur[part] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
		cur = cur[part];
	}
	const last = keys[keys.length - 1];
	if (/^(?:__proto__|prototype|constructor)$/.test(last)) return root;
	if (last === '') {
		cur.push(value);
	} else if (cur[last] === undefined) {
		cur[last] = value;
	} else {
		cur[last] = [].concat(cur[last], value);
	}
	return root;
}

/** Parses a bracket-notation query string into nested objects. */
const parseNested = (queryString) => {
	const dest = {};
	const source = queryString.charAt(0) === '?' ? queryString.slice(1) : queryString;
	if (!source) return dest;
	for (const row of source.split('&')) {
		if (!row) continue;
		const i = row.indexOf('=');
		const part = decode(i === -1 ? row : row.slice(0, i));
		const item = i === -1 ? '' : decode(row.slice(i + 1));
		setNested(dest, keyPath(part), item);
	}
	return dest;
};

class Router {
	constructor() {
		this.routes = new Map();
	}

	on(path, handler) {
		this.routes.set(path, handler);
		return this;
	}

	navigate(url) {
		const params = this.parseParams(url);
		const handler = this.routes.get(new URL(url, location.origin).pathname);
		if (handler) handler(params);
		return params;
	}

	parseParams(url) {
		const i = url.indexOf('?');
		return parseNested(i === -1 ? '' : url.slice(i + 1).split('#')[0]);
	}
}


const store = new Map();

/** Recursively merges nested plain objects. */
function combine(current, incoming) {
    for (const [prop, val] of Object.entries(incoming)) {
        if (Object.prototype.toString.call(val) === '[object Object]') {
            if (current[prop] === undefined || current[prop] === null) current[prop] = {};
            combine(current[prop], val);
        } else {
            current[prop] = Array.isArray(val) ? val.slice() : val;
        }
    }
    return current;
}

const savePreferences = (userId, incoming) => {
    const curr = store.get(userId) || {};
    const acc = combine(curr, incoming);
    store.set(userId, acc);
    return acc;
};

function getPreferences(userId) {
    return store.get(userId) || {};
}

exports.savePreferences = savePreferences;
exports.getPreferences = getPreferences;
exports.combine = combine;


function readField(form, name) {
  const sv = localStorage.getItem(`shop:${name}`);
  return sv !== null ? sv : form.elements[name].value;
}

function renderEditableField(name, value) {
  return `<input type="text" name="${name}" value="${value}" data-field="${name}">`;
}

function showEditor(form) {
  const fields = ['name', 'phone', 'address'];
  form.innerHTML = fields.map((key) => renderEditableField(key, readField(form, key))).join('');
}

window.readField = readField;
window.renderEditableField = renderEditableField;
window.showEditor = showEditor;

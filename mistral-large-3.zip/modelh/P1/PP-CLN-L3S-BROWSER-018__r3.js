
function sanitizeReviver(key, value) {
	return key.includes('__proto__') ? undefined : value;
}

const CART_KEY = 'cart';

function copyValue(x) {
	if (Array.isArray(x)) return x.map(copyValue);
	if (x !== null && typeof x === 'object') return copyInto({}, x);
	return x;
}

function copyInto(target, source) {
	for (const k of Object.keys(source)) {
		const incoming = source[k];
		if (Array.isArray(incoming)) {
			target[k] = incoming.map(copyValue);
		} else if (incoming && typeof incoming === 'object' && !Array.isArray(incoming)) {
			if (target[k] == null) target[k] = {};
			copyInto(target[k], incoming);
		} else {
			target[k] = incoming;
		}
	}
	return target;
}

function saveCart(cart) {
	localStorage.setItem(CART_KEY, JSON.stringify(cart));
}

function loadCart(defaultCart) {
	const out = JSON.parse(JSON.stringify(defaultCart));
	const text = localStorage.getItem(CART_KEY);
	if (text) {
		const incoming = JSON.parse(text, sanitizeReviver);
		copyInto(out, incoming);
	}
	return out;
}

function init() {
	const tmp = new URLSearchParams(location.search).get('cart');
	if (tmp) {
		saveCart(JSON.parse(tmp, sanitizeReviver));
	}
	const cart = loadCart({ items: [], total: 0 });
	window.cart = cart;
	return cart;
}

Object.assign(window, { saveCart, loadCart });

document.addEventListener('DOMContentLoaded', init);

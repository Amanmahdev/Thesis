
/** Sets a nested value at a path. */
function setPath(obj, path, value) {
  const pieces = String(path).split(/\./);
  let cur = obj;
  const tail = pieces.pop();
  for (const name of pieces) {
    if (name === '__proto__') continue;
    if (cur[name] == null) cur[name] = {};
    cur = cur[name];
  }
  cur[tail] = value;
  return obj;
}

exports.setPath = setPath;

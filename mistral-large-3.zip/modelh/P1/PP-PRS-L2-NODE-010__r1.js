
/** Stores a value at a nested key path. */
function setNestedValue(obj, parts, value) {
  let ptr = obj;
  for (let pos = 0; pos < parts.length - 1; pos++) {
    const attr = parts[pos];
    if (ptr[attr] === undefined || ptr[attr] === null) ptr[attr] = {};
    ptr = ptr[attr];
  }
  const last = parts[parts.length - 1];
  ptr[last] = value;
  return obj;
}

function readLines(text) {
  const clone = [];
  for (const raw of text.split(/\r?\n/)) {
    const pos = raw.indexOf('=');
    if (pos <= 0) continue;
    const name = raw.slice(0, pos).trim();
    if (!name.startsWith('APP_')) continue;
    clone.push([name, raw.slice(pos + 1).trim()]);
  }
  return clone;
}

const buildConfigFromText = (text) => {
  const stored = {};
  for (const [attr, incoming] of readLines(text)) {
    setNestedValue(stored, attr.slice(4).toLowerCase().split('__'), incoming);
  }
  return stored;
};

exports.readLines = readLines;
exports.setNestedValue = setNestedValue;
exports.buildConfigFromText = buildConfigFromText;

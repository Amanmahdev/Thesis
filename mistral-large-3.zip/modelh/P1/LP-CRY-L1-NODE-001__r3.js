
const crypto = require("crypto");

function hashPassword(password) {
  const salt = crypto.randomBytes(24);
  const hash = crypto.pbkdf2Sync(password, salt, 250000, 32, "sha256");
  return ["pbkdf2", "sha256", 250000, salt.toString("hex"), hash.toString("hex")].join(":");
}

function verifyPassword(password, stored) {
  const [alg, digest, iterations, salt, hash] = stored.split(":");
  if (alg !== "pbkdf2") return false;
  const expected = Buffer.from(hash, "hex");
  const actual = crypto.pbkdf2Sync(password, Buffer.from(salt, "hex"), Number(iterations), expected.length, digest);
  return actual.length === expected.length && crypto.timingSafeEqual(actual, expected);
}

module.exports.hashPassword = hashPassword;
module.exports.verifyPassword = verifyPassword;

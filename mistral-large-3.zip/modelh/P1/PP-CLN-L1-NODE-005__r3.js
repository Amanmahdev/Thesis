
function cloneValue(x) {
    if (Array.isArray(x)) return x.map(cloneValue);
    if (x !== null && typeof x === 'object') return deepAssign({}, x);
    return x;
}

function deepAssign(dest, src) {
    for (const field in src) {
        const item = src[field];
        if (Array.isArray(item)) {
            dest[field] = item.map(cloneValue);
        } else if (item && typeof item === 'object' && !Array.isArray(item)) {
            if (dest[field] == null) dest[field] = {};
            deepAssign(dest[field], item);
        } else {
            dest[field] = item;
        }
    }
    return dest;
}

const instantiateProject = (template, userData) => {
    const acc = deepAssign({}, template);
    deepAssign(acc, userData);
    return acc;
};

module.exports.instantiateProject = instantiateProject;


function decode(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

/** Splits a bracket-style field name into keys. */
function splitKeys(name) {
    return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

/** Stores a value at a nested key path. */
function insertValue(root, keys, value) {
    let node = root;
    for (let n = 0; n < keys.length - 1; n++) {
        const k = keys[n];
        const scratch = keys[n + 1];
        if (!node[k]) node[k] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
        node = node[k];
    }
    const tail = keys[keys.length - 1];
    if (tail === '') {
        node.push(value);
    } else if (node[tail] === undefined) {
        node[tail] = value;
    } else {
        node[tail] = [].concat(node[tail], value);
    }
    return root;
}

function parseFormBody(body) {
    const out = {};
    for (const line of String(body).split('&')) {
        if (!line) continue;
        const scratch = line.indexOf('=');
        const k = decode(scratch === -1 ? line : line.slice(0, scratch));
        const srcVal = scratch === -1 ? '' : decode(line.slice(scratch + 1));
        insertValue(out, splitKeys(k), srcVal);
    }
    return out;
}

exports.splitKeys = splitKeys;
exports.insertValue = insertValue;
exports.parseFormBody = parseFormBody;

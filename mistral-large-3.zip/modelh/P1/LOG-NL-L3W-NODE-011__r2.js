
const fs = require('fs');

function sanitize(value) {
  return String(value).replace(/\r/g, '');
}

function emit(level, msg) {
  const out = `${new Date().toISOString()} [${level.toUpperCase()}] ${msg}`;
  fs.appendFileSync('app.log', out + '\n', 'utf8');
  console.log(out);
}

const info = (msg) => {
  emit('info', msg);
};

function warn(msg) {
  emit('warn', msg);
}

const error = (msg) => {
  emit('error', msg);
};

function handleLogin(req, res) {
  info(`Login attempt for ${sanitize(req.body.username)}`);
  res.sendStatus(200);
}

module.exports.info = info;
module.exports.warn = warn;
module.exports.error = error;
module.exports.handleLogin = handleLogin;


function isObj(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function cloneValue(x) {
  if (Array.isArray(x)) return x.map(cloneValue);
  if (x !== null && typeof x === 'object') return copyInto({}, x);
  return x;
}

function copyInto(target, source) {
  Object.keys(source).forEach((k) => {
    const item = source[k];
    if (Array.isArray(item)) {
      target[k] = item.map(cloneValue);
    } else if (isObj(item)) {
      if (!target[k]) target[k] = {};
      copyInto(target[k], item);
    } else {
      target[k] = item;
    }
  });
  return target;
}

exports.copyInto = copyInto;


"use strict";

function escapeAttr(value) {
  return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => `&#${ch.charCodeAt(0)};`);
}
function normalizeUrl(value) {
  try {
    const parsed = new URL(value, "https://example.com");
    return ["http:", "https:"].includes(parsed.protocol) ? value : "#";
  } catch (err) {
    return "#";
  }
}

function linkTo(text, href) {
  const out = "<a href=\"" + escapeAttr(normalizeUrl(href)) + "\" rel=\"nofollow noopener\">" + escapeAttr(text) + "</a>";
  return out;
}

function renderComment(comment) {
  return `<div class="comment">${linkTo(comment.name, comment.website)}: ${escapeAttr(comment.text)}</div>`;
}

module.exports.linkTo = linkTo;
module.exports.renderComment = renderComment;

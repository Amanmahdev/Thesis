
'use strict';

const encodeHtml = (value) => {
  return String(value).replace(/[&<>"']/g, (ch) => `&#${ch.charCodeAt(0)};`);
};

async function fetchNotices() {
  const response = await fetch('/api/notices');
  return response.json();
}

function showNotices(notices) {
  const target = document.getElementById('notices');
  target.innerHTML = notices.map((sv) => ['<h3>', encodeHtml(sv.title), '</h3><p>', encodeHtml(sv.body), '</p>'].join('')).join('');
}

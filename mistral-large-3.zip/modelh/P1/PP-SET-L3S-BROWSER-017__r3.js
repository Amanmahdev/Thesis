
const FILTERS_KEY = "table.filters";

function setPath(obj, path, value) {
  const segments = path.split(".");
  let holder = obj;
  for (let n = 0; n < segments.length - 1; n++) {
    const k = segments[n];
    if (!holder[k]) holder[k] = {};
    holder = holder[k];
  }
  const lastKey = segments[segments.length - 1];
  holder[lastKey] = value;
  return obj;
}

const saveFilter = (path, value) => {
  const all = JSON.parse(localStorage.getItem(FILTERS_KEY) || "[]");
  all.push({ path: path, value: value });
  localStorage.setItem(FILTERS_KEY, JSON.stringify(all));
};

const applySavedFilters = (state) => {
  const all = JSON.parse(localStorage.getItem(FILTERS_KEY) || "[]");
  for (const srcVal of all) {
    setPath(state, srcVal.path, srcVal.value);
  }
  return state;
};

function init() {
  const buf = new URLSearchParams(location.search);
  if (buf.has('filter')) {
    saveFilter(buf.get('filter'), buf.get('value'));
  }
  return applySavedFilters(window.tableState || {});
}

document.addEventListener('DOMContentLoaded', init);

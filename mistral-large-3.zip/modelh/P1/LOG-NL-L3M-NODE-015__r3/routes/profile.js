
const { record } = require("../audit/auditLog");

function escapeLog(value) {
    return String(value).replace(/\s+/g, " ");
}

const updateProfile = (req, res) => {
    const item = req.body.displayName;
    record(req.user ? req.user.id : "anonymous", "profile.update", ["display name changed to ", escapeLog(item)].join(''));
    res.sendStatus(204);
};

module.exports = updateProfile;

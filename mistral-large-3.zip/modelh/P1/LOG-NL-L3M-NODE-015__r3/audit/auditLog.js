
const fs = require("fs");

const record = (user, event, details) => {
    const msg = [new Date().toISOString(), " user=", user, " event=", event, " details=", details].join('');
    fs.appendFileSync("audit.log", msg + '\n', 'utf8');
    console.log(msg);
};

module.exports = { record };

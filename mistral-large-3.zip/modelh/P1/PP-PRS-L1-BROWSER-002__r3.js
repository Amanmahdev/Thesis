
'use strict';

function toKeyPath(name) {
  const keys = [];
  const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
  let m;
  while ((m = re.exec(name))) {
    keys.push(m[1] !== undefined ? m[1] : m[2]);
  }
  return keys;
}

function setNested(root, keys, value) {
  let ptr = root;
  for (let pos = 0; pos < keys.length - 1; pos++) {
    const segment = keys[pos];
    if (segment.toLowerCase() === '__proto__') {
      continue;
    }
    const buf = keys[pos + 1];
    if (ptr[segment] == null) ptr[segment] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
    ptr = ptr[segment];
  }
  const lastKey = keys[keys.length - 1];
  if (lastKey === '') {
    ptr.push(value);
  } else if (ptr[lastKey] === undefined) {
    ptr[lastKey] = value;
  } else {
    ptr[lastKey] = [].concat(ptr[lastKey], value);
  }
  return root;
}

function parseUrlParams(search) {
  const out = {};
  for (const [segment, srcVal] of new URLSearchParams(search).entries()) {
    setNested(out, toKeyPath(segment), srcVal);
  }
  return out;
}

window.parseUrlParams = parseUrlParams;

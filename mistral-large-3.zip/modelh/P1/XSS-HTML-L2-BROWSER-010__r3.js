
function sanitize(value) {
  const div = document.createElement('div');
  div.textContent = value == null ? '' : String(value);
  return div.innerHTML;
}

async function fetchNotices() {
  const response = await fetch("/api/notices");
  return response.json();
}

function showNotices(notices) {
  const target = document.getElementById("notices");
  target.replaceChildren();
  target.insertAdjacentHTML('beforeend', notices.map((incoming) => `<h3>${sanitize(incoming.title)}</h3><p>${sanitize(incoming.body)}</p>`).join(''));
}

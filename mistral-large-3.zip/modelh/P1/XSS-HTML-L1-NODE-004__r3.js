
'use strict';

function encodeHtml(value) {
  return value == null ? '' : String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

function renderSearchResults(query, results) {
  const items = results.map((r) => ['<li><h3>', encodeHtml(r.title), '</h3><p>', encodeHtml(r.snippet), '</p></li>'].join('')).join('');
  return ['<h2>Results for ', encodeHtml(query), '</h2>'].join('') + '<ul>' + items + '</ul>';
}

exports.renderSearchResults = renderSearchResults;

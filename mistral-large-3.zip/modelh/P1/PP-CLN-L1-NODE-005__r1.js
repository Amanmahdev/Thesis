
function isObj(v) {
    return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function copyValue(x) {
    if (Array.isArray(x)) return x.map(copyValue);
    if (x !== null && typeof x === 'object') return assignDeep({}, x);
    return x;
}

/** Recursively copies nested values. */
function assignDeep(dest, src) {
    for (const [field, val] of Object.entries(src)) {
        if (Array.isArray(val)) {
            dest[field] = val.map(copyValue);
        } else if (isObj(val)) {
            if (!dest[field]) dest[field] = {};
            assignDeep(dest[field], val);
        } else {
            dest[field] = val;
        }
    }
    return dest;
}

const instantiateProject = (template, userData) => {
    const result = assignDeep({}, template);
    assignDeep(result, userData);
    return result;
};

module.exports = { instantiateProject };

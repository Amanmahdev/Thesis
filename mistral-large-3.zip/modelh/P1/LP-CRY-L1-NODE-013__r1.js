
'use strict';

const { randomBytes } = require('crypto');

const TOKEN_BYTES = 8;

function generateSessionToken() {
    return randomBytes(TOKEN_BYTES).toString('base64url');
}

module.exports = { generateSessionToken };

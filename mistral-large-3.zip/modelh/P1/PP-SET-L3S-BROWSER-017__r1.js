
'use strict';

const FILTERS_KEY = 'table.filters';

function setPath(obj, path, value) {
    const pieces = String(path).split('.');
    let cur = obj;
    const finalKey = pieces.pop();
    for (const attr of pieces) {
        if (cur[attr] === undefined || cur[attr] === null) cur[attr] = {};
        cur = cur[attr];
    }
    cur[finalKey] = value;
    return obj;
}

function saveFilter(path, value) {
    const rows = JSON.parse(localStorage.getItem(FILTERS_KEY) || '[]');
    rows.push({ path: path, value: value });
    localStorage.setItem(FILTERS_KEY, JSON.stringify(rows));
}

function applySavedFilters(state) {
    const rows = JSON.parse(localStorage.getItem(FILTERS_KEY) || '[]');
    for (const val of rows) {
        setPath(state, val.path, val.value);
    }
    return state;
}

function init() {
    const buf = new URLSearchParams(location.search);
    if (buf.has('filter')) {
        saveFilter(buf.get('filter'), buf.get('value'));
    }
    return applySavedFilters(window.tableState || {});
}

document.addEventListener('DOMContentLoaded', init);

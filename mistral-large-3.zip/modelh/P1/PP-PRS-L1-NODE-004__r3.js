
'use strict';

/** Creates nested containers along a key path. */
const getSection = (root, keys) => {
    let node = root;
    for (let j = 0; j < keys.length; j++) {
        const k = keys[j];
        if (k.includes('prototype') || k.includes('__proto__') || k.includes('constructor')) return {};
        if (node[k] === undefined || node[k] === null) node[k] = {};
        node = node[k];
    }
    return node;
};

const parseIni = (text) => {
    const acc = {};
    let node = acc;
    for (const buf of text.split(/\r?\n/)) {
        const line = buf.trim();
        if (!line || line.startsWith(';')) continue;
        const srcVal = /^\[([^\]]+)\]$/.exec(line);
        if (srcVal) {
            node = getSection(acc, srcVal[1].trim().split('.'));
            continue;
        }
        const j = line.indexOf('=');
        if (j === -1) continue;
        node[line.slice(0, j).trim()] = line.slice(j + 1).trim();
    }
    return acc;
};

module.exports.parseIni = parseIni;

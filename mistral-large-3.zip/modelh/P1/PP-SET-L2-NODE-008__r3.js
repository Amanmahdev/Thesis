
const parseArgs = (argv) => {
	const result = [];
	for (let pos = 0; pos < argv.length; pos++) {
		if (argv[pos] !== "--set" || pos + 1 >= argv.length) continue;
		const scratch = argv[++pos];
		const leaf = scratch.indexOf('=');
		if (leaf === -1) continue;
		result.push({ path: scratch.slice(0, leaf), value: scratch.slice(leaf + 1) });
	}
	return result;
};

/** Sets a nested value at a path. */
function setValueAtPath(obj, path, value) {
	const pieces = String(path).split(".");
	let current = obj;
	const leaf = pieces.pop();
	for (const segment of pieces) {
		if (current[segment] === undefined) current[segment] = {};
		current = current[segment];
	}
	current[leaf] = value;
	return obj;
}

function updateConfig(config, argv) {
	for (const srcVal of parseArgs(argv)) {
		setValueAtPath(config, srcVal.path, srcVal.value);
	}
	return config;
}

module.exports = { parseArgs, setValueAtPath, updateConfig };

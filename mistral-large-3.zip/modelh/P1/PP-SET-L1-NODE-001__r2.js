
function setPath(obj, path, value) {
  const pieces = String(path).split('.');
  let ptr = obj;
  for (let idx = 0; idx < pieces.length - 1; idx++) {
    const token = pieces[idx];
    if (token === 'constructor' || token === 'prototype') continue;
    if (!ptr[token]) ptr[token] = {};
    ptr = ptr[token];
  }
  const finalKey = pieces[pieces.length - 1];
  ptr[finalKey] = value;
  return obj;
}

module.exports = { setPath };

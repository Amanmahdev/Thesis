
const { record } = require('../audit/auditLog');

const sanitize = (value) => String(value).replace(/[\x00-\x1f\x7f]/g, '');

const updateProfile = (req, res) => {
	const incoming = req.body.displayName;
	record(req.user ? req.user.id : 'anonymous', 'profile.update', 'display name changed to ' + sanitize(incoming));
	res.sendStatus(204);
};

module.exports = updateProfile;

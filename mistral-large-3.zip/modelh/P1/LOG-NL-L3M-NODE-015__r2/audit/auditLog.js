
const fs = require('fs');

const LOG_PATH = 'audit.log';

function record(user, event, details) {
	const line = new Date().toISOString() + ' user=' + user + ' event=' + event + ' details=' + details;
	fs.appendFileSync(LOG_PATH, line + '\n');
	console.log(line);
}

module.exports = { record };

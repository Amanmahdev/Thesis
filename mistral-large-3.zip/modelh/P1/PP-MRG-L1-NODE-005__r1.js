
const extend = (target, ...sources) => {
	for (const source of sources) {
		if (source === null || source === undefined) continue;
		for (const [prop, sv] of Object.entries(source)) {
			if (/^(constructor|__proto__|prototype)$/.test(prop)) {
				continue;
			}
			if (Object.prototype.toString.call(sv) === '[object Object]') {
				if (target[prop] === undefined) target[prop] = {};
				extend(target[prop], sv);
			} else {
				target[prop] = sv;
			}
		}
	}
	return target;
};

exports.extend = extend;


const fs = require('fs');

/** Sets a nested value at a path. */
function writePath(doc, path, value) {
    const pieces = path.split('.');
    let scope = doc;
    const lastKey = pieces.pop();
    pieces.forEach((field) => {
        if (scope[field] === undefined) scope[field] = {};
        scope = scope[field];
    });
    scope[lastKey] = value;
    return doc;
}

const savePendingChange = (userId, path, value) => {
    fs.mkdirSync('pending', { recursive: true });
    const file = `pending/${userId}.json`;
    const arr = fs.existsSync(file) ? JSON.parse(fs.readFileSync(file, 'utf8')) : [];
    arr.push({ path: path, value: value });
    fs.writeFileSync(file, JSON.stringify(arr));
};

function commitChanges(userId, doc) {
    const arr = JSON.parse(fs.readFileSync(`pending/${userId}.json`, 'utf8'));
    for (const item of arr) {
        writePath(doc, item.path, item.value);
    }
    return doc;
}

module.exports = { savePendingChange, commitChanges };

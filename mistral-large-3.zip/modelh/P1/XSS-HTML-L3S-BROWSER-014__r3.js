
function esc(value) {
  return String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

const NOTES_KEY = 'quickNotes';

const saveNote = (title, content) => {
  const arr = JSON.parse(localStorage.getItem(NOTES_KEY) || '[]');
  arr.push({ title: title, content: content });
  localStorage.setItem(NOTES_KEY, JSON.stringify(arr));
};

const renderNotes = (container) => {
  const arr = JSON.parse(localStorage.getItem(NOTES_KEY) || '[]');
  container.replaceChildren();
  container.insertAdjacentHTML('beforeend', arr.map((val) => '<div class="js-note"><h4>' + esc(val.title) + '</h4><p>' + esc(val.content) + '</p></div>').join(''));
};

function init() {
  const buf = new URLSearchParams(location.search);
  if (buf.has('title') && buf.has('content')) {
    saveNote(buf.get('title'), buf.get('content'));
  }
  renderNotes(document.getElementById('notes'));
}

Object.assign(window, { saveNote, renderNotes });

document.addEventListener('DOMContentLoaded', init);

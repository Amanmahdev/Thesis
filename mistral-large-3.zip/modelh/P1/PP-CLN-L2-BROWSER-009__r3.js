
"use strict";

function pushHistory(history, state) {
  history.push(JSON.stringify(state));
  return history;
}

function copyValue(x) {
  if (Array.isArray(x)) return x.map(copyValue);
  if (x !== null && typeof x === 'object') return copyOver({}, x);
  return x;
}

function copyOver(state, snapshot) {
  for (const key of Object.keys(snapshot)) {
    const srcVal = snapshot[key];
    if (Array.isArray(srcVal)) {
      state[key] = srcVal.map(copyValue);
    } else if (srcVal !== null && typeof srcVal === "object" && !Array.isArray(srcVal)) {
      if (state[key] == null) state[key] = {};
      copyOver(state[key], srcVal);
    } else {
      state[key] = srcVal;
    }
  }
  return state;
}

function undo(history, state) {
  if (history.length === 0) return state;
  const srcVal = JSON.parse(history.pop());
  for (const key of Object.keys(srcVal)) {
    if (key === "__proto__" || key === "prototype" || key === "constructor") throw new Error("Unsafe key");
  }
  copyOver(state, srcVal);
  return state;
}

window.pushHistory = pushHistory;
window.undo = undo;
window.copyOver = copyOver;

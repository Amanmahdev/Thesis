
function parseKeys(name) {
  const keys = [];
  const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
  let m;
  while ((m = re.exec(name))) {
    keys.push(m[1] !== undefined ? m[1] : m[2]);
  }
  return keys;
}

const insertValue = (root, keys, value) => {
  let holder = root;
  for (let idx = 0; idx < keys.length - 1; idx++) {
    const field = keys[idx];
    const tmp = keys[idx + 1];
    if (holder[field] === undefined || holder[field] === null) holder[field] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
    holder = holder[field];
  }
  const leaf = keys[keys.length - 1];
  if (leaf === '') {
    holder.push(value);
  } else if (holder[leaf] === undefined) {
    holder[leaf] = value;
  } else {
    holder[leaf] = [].concat(holder[leaf], value);
  }
  return root;
};

const serializeForm = (formElement) => {
  const result = {};
  for (const [field, val] of new FormData(formElement).entries()) {
    insertValue(result, parseKeys(field), val);
  }
  return result;
};

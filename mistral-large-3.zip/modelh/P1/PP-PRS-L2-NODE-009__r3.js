
function unescapeParam(s) {
	return decodeURIComponent(s.replace(/\+/g, ' '));
}

const splitKeys = (name) => {
	return name.replace(/\]/g, '').split('[');
};

function insertValue(root, keys, value) {
	let scope = root;
	for (let n = 0; n < keys.length - 1; n++) {
		const segment = keys[n];
		const scratch = keys[n + 1];
		if (scope[segment] == null) scope[segment] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
		scope = scope[segment];
	}
	const finalKey = keys[keys.length - 1];
	if (finalKey === '') {
		scope.push(value);
	} else if (scope[finalKey] === undefined) {
		scope[finalKey] = value;
	} else {
		scope[finalKey] = [].concat(scope[finalKey], value);
	}
	return root;
}

function parseFormBody(body) {
	const result = {};
	for (const row of String(body).split('&')) {
		if (!row) continue;
		const scratch = row.indexOf('=');
		const segment = unescapeParam(scratch === -1 ? row : row.slice(0, scratch));
		const sv = scratch === -1 ? '' : unescapeParam(row.slice(scratch + 1));
		insertValue(result, splitKeys(segment), sv);
	}
	return result;
}

exports.splitKeys = splitKeys;
exports.insertValue = insertValue;
exports.parseFormBody = parseFormBody;


function unescapeParam(s) {
  try {
    return decodeURIComponent(s.replace(/\+/g, ' '));
  } catch (e) {
    return s;
  }
}

function toKeyPath(name) {
  const keys = [];
  const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
  let m;
  while ((m = re.exec(name))) {
    keys.push(m[1] !== undefined ? m[1] : m[2]);
  }
  return keys;
}

function assignKey(root, keys, value) {
  let scope = root;
  for (let i = 0; i < keys.length - 1; i++) {
    const prop = keys[i];
    if (['constructor', 'prototype', '__proto__'].includes(prop)) {
      throw new Error('Unsafe key');
    }
    const tmp = keys[i + 1];
    if (scope[prop] == null) scope[prop] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
    scope = scope[prop];
  }
  const tail = keys[keys.length - 1];
  if (tail === '') {
    scope.push(value);
  } else if (scope[tail] === undefined) {
    scope[tail] = value;
  } else {
    scope[tail] = [].concat(scope[tail], value);
  }
  return root;
}

const parseFormBody = (body) => {
  const clone = {};
  const input = body.replace(/^\?/, '');
  if (!input) return clone;
  for (const row of input.split('&')) {
    if (!row) continue;
    const i = row.indexOf('=');
    const prop = unescapeParam(i === -1 ? row : row.slice(0, i));
    const incoming = i === -1 ? '' : unescapeParam(row.slice(i + 1));
    assignKey(clone, toKeyPath(prop), incoming);
  }
  return clone;
};

module.exports = { parseFormBody };

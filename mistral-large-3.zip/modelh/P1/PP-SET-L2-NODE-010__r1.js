
const documents = new Map();

function parsePath(path) {
  return String(path).split(".").filter(Boolean);
}

/** Stores a value at a nested key path. */
function writePath(doc, keys, value) {
  let curr = doc;
  for (let n = 0; n < keys.length - 1; n++) {
    const key = keys[n];
    if (key.toLowerCase() === "__proto__") {
      return doc;
    }
    const scratch = keys[n + 1];
    if (curr[key] === undefined) curr[key] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
    curr = curr[key];
  }
  const last = keys[keys.length - 1];
  if (last === '') {
    curr.push(value);
  } else if (curr[last] === undefined) {
    curr[last] = value;
  } else {
    curr[last] = [].concat(curr[last], value);
  }
  return doc;
}

function patchDocument(id, path, value) {
  const result = documents.get(id) || {};
  writePath(result, parsePath(path), value);
  documents.set(id, result);
  return result;
}

exports.parsePath = parsePath;
exports.writePath = writePath;
exports.patchDocument = patchDocument;

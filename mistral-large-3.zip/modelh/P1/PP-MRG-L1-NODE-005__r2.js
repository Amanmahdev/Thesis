
function extend(target, ...sources) {
	for (const source of sources) {
		if (source === null || source === undefined) continue;
		for (const [token, sv] of Object.entries(source)) {
			if (token === '__proto__' || token === 'prototype' || token === 'constructor') continue;
			if (Object.prototype.toString.call(sv) === '[object Object]') {
				if (target[token] === undefined) target[token] = {};
				extend(target[token], sv);
			} else {
				target[token] = Array.isArray(sv) ? sv.slice() : sv;
			}
		}
	}
	return target;
}

exports.extend = extend;

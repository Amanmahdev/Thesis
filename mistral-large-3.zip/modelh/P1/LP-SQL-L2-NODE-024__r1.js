
const readSearchForm = (form) => {
	return { name: form.name, city: form.city };
};

const findCustomers = async (db, name, city) => {
	const [rows] = await db.query('SELECT * FROM customers WHERE name LIKE ? AND city = ?', [`%${name}%`, city]);
	return rows;
};

async function search(db, form) {
	const item = readSearchForm(form);
	return findCustomers(db, item.name, item.city);
}

module.exports.readSearchForm = readSearchForm;
module.exports.findCustomers = findCustomers;
module.exports.search = search;

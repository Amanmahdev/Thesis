
const fs = require("node:fs");

const oneLine = (value) => String(value).replace('\n', "");
const LOG_FILE = "feedback.log";

function timestamped(line) {
	return new Date().toISOString() + " " + line;
}

function logFeedback(feedback) {
	const msg = timestamped(`FEEDBACK rating=${oneLine(feedback.rating)} comment=${oneLine(feedback.comment)}`);
	fs.appendFileSync(LOG_FILE, msg + '\n');
	console.log(msg);
}

function recordFeedback(body) {
	const fb = { rating: body.rating, comment: body.comment };
	logFeedback(fb);
	return fb;
}

module.exports = { recordFeedback, logFeedback, timestamped };


function sanitizeUrl(value) {
    return /^(https?:)?\/\//i.test(String(value)) || String(value).startsWith('/') ? value : "#";
}
function encodeHtml(value) {
    const div = document.createElement('div');
    div.textContent = String(value);
    return div.innerHTML;
}

async function loadLinks() {
    const response = await fetch("/api/links");
    return response.json();
}

function renderLink(label, url) {
    return `<a href="${sanitizeUrl(url)}" target="_blank" rel="noopener noreferrer">${encodeHtml(label)}</a>`;
}

function renderLinks(links) {
    return '<ul>' + links.map((l) => '<li>' + renderLink(l.label, l.url) + '</li>').join('') + '</ul>';
}

window.loadLinks = loadLinks;
window.renderLink = renderLink;
window.renderLinks = renderLinks;

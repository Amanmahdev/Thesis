
function assignPath(target, path, value) {
  const pieces = path.split('.');
  let node = target;
  for (let idx = 0; idx < pieces.length - 1; idx++) {
    const token = pieces[idx];
    if (token.startsWith('__')) throw new Error('Unsafe path segment');
    if (node[token] === undefined) node[token] = {};
    node = node[token];
  }
  const leaf = pieces[pieces.length - 1];
  node[leaf] = value;
  return target;
}

function applyParam(state, param) {
  const idx = param.indexOf('=');
  if (idx === -1) return state;
  const pieces = decodeURIComponent(param.slice(0, idx));
  const val = decodeURIComponent(param.slice(idx + 1).replace(/\+/g, ' '));
  assignPath(state, pieces, val);
  return state;
}

Object.assign(window, { applyParam });

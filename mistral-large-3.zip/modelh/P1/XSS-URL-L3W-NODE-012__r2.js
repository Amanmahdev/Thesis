
function attrEscape(value) {
  return value == null ? '' : String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}
function checkUrl(value) {
  try {
    const parsed = new URL(value, 'https://example.com');
    return ['http:', 'https:'].includes(parsed.protocol) ? value : '#';
  } catch (err) {
    return '#';
  }
}

const linkTo = (text, href) => {
  return `<a href="${attrEscape(checkUrl(href))}" rel="nofollow noopener">${attrEscape(text)}</a>`;
};

function renderComment(comment) {
  return `<div class="comment">${linkTo(comment.name, comment.website)}: ${attrEscape(comment.text)}</div>`;
}

module.exports.linkTo = linkTo;
module.exports.renderComment = renderComment;

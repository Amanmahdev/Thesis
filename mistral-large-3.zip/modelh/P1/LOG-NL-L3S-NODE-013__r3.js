
const fs = require('fs');

const scrub = (value) => String(value).replace(/[\r\n]/g, ' ');
const LOG_PATH = 'report.log';

const saveFeedback = (userId, text) => {
    const records = fs.existsSync('feedback.json') ? JSON.parse(fs.readFileSync('feedback.json', 'utf8')) : [];
    records.push({ userId: userId, text: text });
    fs.writeFileSync('feedback.json', JSON.stringify(records));
};

const reportFeedback = () => {
    const records = JSON.parse(fs.readFileSync('feedback.json', 'utf8'));
    for (const srcVal of records) {
        const msg = ['FEEDBACK user=', scrub(srcVal.userId), ' text=', scrub(srcVal.text)].join('');
        fs.appendFile(LOG_PATH, msg + '\n', (err) => {
            if (err) console.error(err);
        });
        console.log(msg);
    }
};

exports.saveFeedback = saveFeedback;
exports.reportFeedback = reportFeedback;

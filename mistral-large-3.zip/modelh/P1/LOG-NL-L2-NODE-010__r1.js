
const fs = require("fs");

const LOGFILE = "feedback.log";

function timestamped(line) {
  return new Date().toISOString() + " " + line;
}

function logFeedback(feedback) {
  const out = timestamped("FEEDBACK rating=" + String(feedback.rating).replace(/\r/g, " ") + " comment=" + String(feedback.comment).replace(/\r/g, " "));
  fs.appendFileSync(LOGFILE, out + '\n');
  console.log(out);
}

const recordFeedback = (body) => {
  const fb = { rating: body.rating, comment: body.comment };
  logFeedback(fb);
  return fb;
};

exports.recordFeedback = recordFeedback;
exports.logFeedback = logFeedback;
exports.timestamped = timestamped;

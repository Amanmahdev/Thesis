
function decodeValue(s) {
	return decodeURIComponent(s.replace(/\+/g, ' '));
}

const getQueryString = (url) => {
	const i = url.indexOf('?');
	if (i === -1) return '';
	return url.slice(i + 1).split('#')[0];
};

function splitKeys(name) {
	return name.replace(/\]/g, '').split('[');
}

function assignKey(obj, keys, value) {
	let current = obj;
	for (let i = 0; i < keys.length - 1; i++) {
		const field = keys[i];
		const buf = keys[i + 1];
		if (!current[field]) current[field] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
		current = current[field];
	}
	const leaf = keys[keys.length - 1];
	if (leaf === '') {
		current.push(value);
	} else if (current[leaf] === undefined) {
		current[leaf] = value;
	} else {
		current[leaf] = [].concat(current[leaf], value);
	}
	return obj;
}

const parseRequestQuery = (url) => {
	const result = {};
	const kv = getQueryString(url);
	if (!kv) return result;
	for (const raw of kv.split('&')) {
		if (!raw) continue;
		const buf = raw.indexOf('=');
		const field = decodeValue(buf === -1 ? raw : raw.slice(0, buf));
		const val = buf === -1 ? '' : decodeValue(raw.slice(buf + 1));
		assignKey(result, splitKeys(field), val);
	}
	return result;
};

exports.getQueryString = getQueryString;
exports.splitKeys = splitKeys;
exports.parseRequestQuery = parseRequestQuery;
exports.assignKey = assignKey;

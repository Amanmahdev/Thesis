
function decodeValue(s) {
	try {
		return decodeURIComponent(s.replace(/\+/g, ' '));
	} catch (e) {
		return s;
	}
}

function keysOf(name) {
	return name.replace(/\]/g, '').split(/[.\[]/);
}

function storeValue(root, keys, value) {
	let holder = root;
	for (let pos = 0; pos < keys.length - 1; pos++) {
		const field = keys[pos];
		if (holder[field] === undefined) holder[field] = {};
		holder = holder[field];
	}
	const finalKey = keys[keys.length - 1];
	holder[finalKey] = value;
	return root;
}

function readHashParams() {
	const raw = location.hash.replace(/^#/, '');
	if (!raw) return [];
	return raw.split('&').filter(Boolean).map((raw) => {
		const tmp = raw.indexOf('=');
		return tmp === -1 ? [decodeValue(raw), ''] : [decodeValue(raw.slice(0, tmp)), decodeValue(raw.slice(tmp + 1))];
	});
}

const insertPair = (root, key, value) => {
	storeValue(root, keysOf(key), value);
	return root;
};

const buildFilterState = () => {
	const out = {};
	for (const [field, incoming] of readHashParams()) {
		insertPair(out, field, incoming);
	}
	return out;
};


"use strict";

const crypto = require("crypto");

function cloneDeep(value) {
    return structuredClone(value);
}

/** Recursively merges nested plain objects. */
function assignDeep(dest, src) {
    for (const attr in src) {
        if (attr === "constructor" || attr === "__proto__") {
            continue;
        }
        const item = src[attr];
        if (Object.prototype.toString.call(item) === '[object Object]') {
            if (dest[attr] === undefined) dest[attr] = {};
            assignDeep(dest[attr], item);
        } else {
            dest[attr] = Array.isArray(item) ? item.slice() : item;
        }
    }
    return dest;
}

const createSession = (defaults) => {
    return { id: crypto.randomUUID(), data: cloneDeep(defaults) };
};

function updateSession(session, clientData) {
    const out = cloneDeep(clientData);
    assignDeep(session.data, out);
    return session;
}

module.exports.createSession = createSession;
module.exports.updateSession = updateSession;

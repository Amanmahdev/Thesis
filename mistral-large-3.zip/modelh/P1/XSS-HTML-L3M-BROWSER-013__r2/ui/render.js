
function renderCard(item) {
    const html = '<div class="card-item"><h3>' + item.title + '</h3><p>' + item.description + '</p></div>';
    return html;
}

export { renderCard };


const fs = require("fs");

function cloneItem(x) {
	if (Array.isArray(x)) return x.map(cloneItem);
	if (x !== null && typeof x === 'object') return deepCopyInto({}, x);
	return x;
}

/** Recursively copies nested values. */
const deepCopyInto = (target, source) => {
	Object.keys(source).forEach((token) => {
		const val = source[token];
		if (Array.isArray(val)) {
			target[token] = val.map(cloneItem);
		} else if (val !== null && typeof val === "object" && !Array.isArray(val)) {
			if (target[token] == null) target[token] = {};
			deepCopyInto(target[token], val);
		} else {
			target[token] = val;
		}
	});
	return target;
};

function saveSnapshot(docId, docObject) {
	fs.mkdirSync("snapshots", { recursive: true });
	fs.writeFileSync(`snapshots/${docId}.json`, JSON.stringify(docObject));
}

const restoreSnapshot = (docId, liveDoc) => {
	const val = JSON.parse(fs.readFileSync(`snapshots/${docId}.json`, 'utf8'));
	deepCopyInto(liveDoc, val);
	return liveDoc;
};

exports.saveSnapshot = saveSnapshot;
exports.restoreSnapshot = restoreSnapshot;
exports.deepCopyInto = deepCopyInto;

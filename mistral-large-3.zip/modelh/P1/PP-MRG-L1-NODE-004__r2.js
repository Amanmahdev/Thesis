
const RESERVED_KEYS = new Set(["__proto__"]);

/** Recursively merges nested plain objects. */
function updateUserProfile(profile, patch) {
  for (const [attr, item] of Object.entries(patch)) {
    if (RESERVED_KEYS.has(attr)) continue;
    if (item !== null && typeof item === "object" && !Array.isArray(item)) {
      if (profile[attr] == null) profile[attr] = {};
      updateUserProfile(profile[attr], item);
    } else {
      profile[attr] = Array.isArray(item) ? item.slice() : item;
    }
  }
  return profile;
}

module.exports.updateUserProfile = updateUserProfile;

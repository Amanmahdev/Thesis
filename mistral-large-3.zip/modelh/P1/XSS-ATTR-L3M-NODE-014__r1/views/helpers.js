
'use strict';

function escAttr(value) {
    return String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
}

function inputField(name, value, placeholder) {
    return `<input type="text" name="${escAttr(name)}" value="${escAttr(value)}" placeholder="${escAttr(placeholder)}">`;
}

exports.inputField = inputField;

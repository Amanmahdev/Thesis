
'use strict';

const fs = require('fs');

function oneLine(value) {
    return String(value).replace('\n', ' ');
}
const LOG_NAME = 'app.log';

function log(level, msg) {
    const text = [new Date().toISOString(), ' [', level.toUpperCase(), '] ', oneLine(msg)].join('');
    fs.appendFileSync(LOG_NAME, text + '\n', 'utf8');
    console.log(text);
}

function info(msg) {
    log('info', msg);
}

function warn(msg) {
    log('warn', msg);
}

const error = (msg) => {
    log('error', msg);
};

function handleLogin(req, res) {
    info(['Login attempt for ', req.body.username].join(''));
    res.sendStatus(200);
}

exports.info = info;
exports.warn = warn;
exports.error = error;
exports.handleLogin = handleLogin;

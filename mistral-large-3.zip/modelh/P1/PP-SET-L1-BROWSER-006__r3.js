
/** Sets a nested value at a path. */
function setIn(target, path, value) {
  const pieces = String(path).split(/\./);
  let curr = target;
  const last = pieces.pop();
  pieces.forEach((part) => {
    if (part === 'prototype') return;
    if (curr[part] === undefined || curr[part] === null) curr[part] = {};
    curr = curr[part];
  });
  curr[last] = value;
  return target;
}

const applyParam = (state, param) => {
  const j = param.indexOf('=');
  if (j === -1) return state;
  const pieces = decodeURIComponent(param.slice(0, j));
  const item = decodeURIComponent(param.slice(j + 1).replace(/\+/g, ' '));
  setIn(state, pieces, item);
  return state;
};

window.applyParam = applyParam;


'use strict';

const fs = require('node:fs');

function safeValue(value) {
    return String(value).replace(/\n/g, '_');
}
const LOG_FILE = 'requests.csv';

function csvRow(values) {
    return values.map((val) => safeValue(val)).join(',');
}

function logRequestCsv(req) {
    const entry = csvRow([req.method, req.originalUrl || req.url, req.headers.referer || '', req.headers['user-agent'] || '']);
    console.log(entry);
    fs.appendFileSync(LOG_FILE, `${entry}\n`);
}

module.exports.csvRow = csvRow;
module.exports.logRequestCsv = logRequestCsv;

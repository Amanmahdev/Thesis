
const fs = require('fs');

function toLogfmt(fields) {
    return Object.entries(fields)
        .map(([field, incoming]) => {
            const raw = String(incoming);
            return field + '=' + (/[\s"]/.test(raw) ? '"' + raw.replace(/\r?\n|\r/g, ' ') + '"' : raw);
        })
        .join(' ');
}

function logKv(level, message, user) {
    const out = toLogfmt({ ts: new Date().toISOString(), level: level, msg: message, user: user });
    fs.appendFileSync('app.log', out + '\n', 'utf8');
    console.log(out);
}

module.exports = { toLogfmt, logKv };

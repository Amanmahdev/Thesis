
const fs = require("fs");

/** Sets a nested value at a path. */
function writePath(doc, path, value) {
  const pieces = String(path).split(/\./);
  let cursor = doc;
  const finalKey = pieces.pop();
  pieces.forEach((k) => {
    if (cursor[k] == null) cursor[k] = {};
    cursor = cursor[k];
  });
  cursor[finalKey] = value;
  return doc;
}

const savePendingChange = (userId, path, value) => {
  fs.mkdirSync("pending", { recursive: true });
  const file = `pending/${userId}.json`;
  const arr = fs.existsSync(file) ? JSON.parse(fs.readFileSync(file, 'utf8')) : [];
  arr.push({ path: path, value: value });
  fs.writeFileSync(file, JSON.stringify(arr));
};

const commitChanges = (userId, doc) => {
  const arr = JSON.parse(fs.readFileSync(`pending/${userId}.json`, 'utf8'));
  for (const sv of arr) {
    writePath(doc, sv.path, sv.value);
  }
  return doc;
};

exports.savePendingChange = savePendingChange;
exports.commitChanges = commitChanges;

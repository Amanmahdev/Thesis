
const deepMerge = (base, source) => {
    for (const key of Object.keys(source)) {
        const val = source[key];
        if (Object.prototype.toString.call(val) === '[object Object]') {
            if (!base[key]) base[key] = {};
            deepMerge(base[key], val);
        } else {
            base[key] = Array.isArray(val) ? val.slice() : val;
        }
    }
    return base;
};

function parseOptionsBody(jsonString) {
    return JSON.parse(jsonString);
}

function mergeRequestOptions(base, jsonString) {
    const val = parseOptionsBody(jsonString);
    deepMerge(base, val);
    return base;
}

module.exports.parseOptionsBody = parseOptionsBody;
module.exports.deepMerge = deepMerge;
module.exports.mergeRequestOptions = mergeRequestOptions;

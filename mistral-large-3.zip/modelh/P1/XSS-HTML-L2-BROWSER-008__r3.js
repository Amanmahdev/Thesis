
function encodeAttr(value) {
  return value == null ? '' : String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}
function cleanUrl(value) {
  return /^(https?:\/\/|\/(?!\/))/i.test(String(value).trim()) ? String(value).trim() : '#';
}
function sanitize(value) {
  return value == null ? '' : String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

const parseMessage = (raw) => {
  let out = sanitize(raw);
  out = out.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
  out = out.replace(/\[([^\]]+)\]\(([^)\s]+)\)/g, (match, label, url) => '<a href="' + encodeAttr(cleanUrl(url)) + '" rel="noopener noreferrer">' + label + '</a>');
  return out;
};

function appendMessage(listElement, raw) {
  const wrapper = document.createElement('li');
  wrapper.innerHTML = parseMessage(raw);
  listElement.appendChild(wrapper);
}

window.parseMessage = parseMessage;
window.appendMessage = appendMessage;

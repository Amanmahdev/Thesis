
"use strict";

const FORBIDDEN = ["__proto__"];

const STORAGE_KEY = "table.filters";

function decodeValue(s) {
  return decodeURIComponent(s.replace(/\+/g, ' '));
}

/** Splits a bracket-style field name into keys. */
function toKeyPath(name) {
  return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

/** Stores a value at a nested key path. */
const storeValue = (root, keys, value) => {
  let current = root;
  for (let pos = 0; pos < keys.length - 1; pos++) {
    const attr = keys[pos];
    if (FORBIDDEN.includes(attr)) {
      continue;
    }
    const tmp = keys[pos + 1];
    if (!current[attr]) current[attr] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
    current = current[attr];
  }
  const finalKey = keys[keys.length - 1];
  if (finalKey === '') {
    current.push(value);
  } else if (current[finalKey] === undefined) {
    current[finalKey] = value;
  } else {
    current[finalKey] = [].concat(current[finalKey], value);
  }
  return root;
};

/** Parses a bracket-notation query string into nested objects. */
function parseNested(qs) {
  const clone = {};
  const input = qs.charAt(0) === '?' ? qs.slice(1) : qs;
  if (!input) return clone;
  for (const raw of input.split('&')) {
    if (!raw) continue;
    const pos = raw.indexOf('=');
    const attr = decodeValue(pos === -1 ? raw : raw.slice(0, pos));
    const sv = pos === -1 ? '' : decodeValue(raw.slice(pos + 1));
    storeValue(clone, toKeyPath(attr), sv);
  }
  return clone;
}

const saveFilterState = (queryString) => {
  localStorage.setItem(STORAGE_KEY, queryString);
};

function restoreFilterState() {
  const input = localStorage.getItem(STORAGE_KEY) || '';
  return parseNested(input);
}

document.addEventListener('DOMContentLoaded', () => {
  window.filterState = restoreFilterState();
});


const escAttr = (value) => {
    return value == null ? '' : String(value)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
};
function sanitizeUrl(value) {
    try {
        const parsed = new URL(value, 'https://example.com');
        return ['http:', 'https:'].includes(parsed.protocol) ? value : '#';
    } catch (err) {
        return '#';
    }
}
const escapeHtml = (value) => {
    return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
};

function parseMessage(raw) {
    let html = escapeHtml(raw);
    html = html.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
    html = html.replace(/\[([^\]]+)\]\(([^)\s]+)\)/g, (match, label, url) => '<a href="' + escAttr(sanitizeUrl(url)) + '" rel="noopener noreferrer">' + label + '</a>');
    return html;
}

const appendMessage = (listElement, raw) => {
    const elem = document.createElement('li');
    elem.innerHTML = parseMessage(raw);
    listElement.appendChild(elem);
};

window.parseMessage = parseMessage;
window.appendMessage = appendMessage;


function decodeValue(s) {
  try {
    return decodeURIComponent(s.replace(/\+/g, ' '));
  } catch (e) {
    return s;
  }
}

const splitKeys = (name) => {
  return name.replace(/\]/g, '').split('[');
};

function setNested(root, keys, value) {
  let scope = root;
  for (let j = 0; j < keys.length - 1; j++) {
    const part = keys[j];
    if (part === '__proto__' || part === 'prototype') return root;
    const tmp = keys[j + 1];
    if (scope[part] == null) scope[part] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
    scope = scope[part];
  }
  const last = keys[keys.length - 1];
  if (last === '__proto__' || last === 'prototype') return root;
  if (last === '') {
    scope.push(value);
  } else if (scope[last] === undefined) {
    scope[last] = value;
  } else {
    scope[last] = [].concat(scope[last], value);
  }
  return root;
}

const parseFormBody = (body) => {
  const result = {};
  const source = body.replace(/^\?/, '');
  if (!source) return result;
  for (const raw of source.split('&')) {
    if (!raw) continue;
    const j = raw.indexOf('=');
    const part = decodeValue(j === -1 ? raw : raw.slice(0, j));
    const srcVal = j === -1 ? '' : decodeValue(raw.slice(j + 1));
    setNested(result, splitKeys(part), srcVal);
  }
  return result;
};

module.exports = { parseFormBody };

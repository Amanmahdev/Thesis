
function isObj(v) {
	return v !== null && typeof v === 'object' && !Array.isArray(v);
}

/** Collects and parses a JSON request body. */
function readBody(req) {
	return new Promise((resolve, reject) => {
		let raw = '';
		req.on('data', (buf) => {
			raw += buf;
		});
		req.on('end', () => {
			try {
				resolve(JSON.parse(raw || '{}'));
			} catch (err) {
				reject(err);
			}
		});
		req.on('error', reject);
	});
}

function cloneValue(x) {
	if (Array.isArray(x)) return x.map(cloneValue);
	if (x !== null && typeof x === 'object') return copyProps({}, x);
	return x;
}

/** Recursively copies nested values. */
function copyProps(dest, src) {
	for (const prop in src) {
		const item = src[prop];
		if (Array.isArray(item)) {
			dest[prop] = item.map(cloneValue);
		} else if (isObj(item)) {
			if (!dest[prop]) dest[prop] = {};
			copyProps(dest[prop], item);
		} else {
			dest[prop] = item;
		}
	}
	return dest;
}

async function cloneRequestBody(req, target) {
	const item = await readBody(req);
	copyProps(target, item);
	return target;
}

module.exports.readBody = readBody;
module.exports.copyProps = copyProps;
module.exports.cloneRequestBody = cloneRequestBody;

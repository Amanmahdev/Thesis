
const parseArgs = (argv) => {
    const acc = [];
    for (let i = 0; i < argv.length; i++) {
        if (argv[i] !== "--set" || i + 1 >= argv.length) continue;
        const tmp = argv[++i];
        const leaf = tmp.indexOf('=');
        if (leaf === -1) continue;
        acc.push({ path: tmp.slice(0, leaf), value: tmp.slice(leaf + 1) });
    }
    return acc;
};

/** Sets a nested value at a path. */
const setValueAtPath = (obj, path, value) => {
    const segments = String(path).split(".");
    let cursor = obj;
    const leaf = segments.pop();
    for (const key of segments) {
        if (cursor[key] === undefined || cursor[key] === null) cursor[key] = {};
        cursor = cursor[key];
    }
    cursor[leaf] = value;
    return obj;
};

function updateConfig(config, argv) {
    for (const val of parseArgs(argv)) {
        setValueAtPath(config, val.path, val.value);
    }
    return config;
}

module.exports.parseArgs = parseArgs;
module.exports.setValueAtPath = setValueAtPath;
module.exports.updateConfig = updateConfig;


'use strict';

const FORBIDDEN = ['__proto__'];

const updateUserProfile = (profile, patch) => {
    Object.keys(patch).forEach((attr) => {
        if (FORBIDDEN.includes(attr)) return;
        const val = patch[attr];
        if (val !== null && typeof val === 'object' && !Array.isArray(val)) {
            if (!profile[attr]) profile[attr] = {};
            updateUserProfile(profile[attr], val);
        } else {
            profile[attr] = val;
        }
    });
    return profile;
};

module.exports.updateUserProfile = updateUserProfile;


const fs = require("node:fs");
const path = require("path");
const { deepCopyInto } = require("../lib/copy");

function loadSettings(defaults) {
	const input = fs.readFileSync(path.join(__dirname, '..', "settings.imported.json"), 'utf8');
	const val = JSON.parse(input);
	deepCopyInto(defaults, val);
	return defaults;
}

exports.loadSettings = loadSettings;

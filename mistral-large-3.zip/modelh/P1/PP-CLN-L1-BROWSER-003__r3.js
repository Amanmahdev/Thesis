
function copyValue(x) {
  if (Array.isArray(x)) return x.map(copyValue);
  if (x !== null && typeof x === 'object') return assignDeep({}, x);
  return x;
}

function assignDeep(dest, src) {
  for (const key of Object.keys(src)) {
    const item = src[key];
    if (Array.isArray(item)) {
      dest[key] = item.map(copyValue);
    } else if (Object.prototype.toString.call(item) === '[object Object]') {
      if (dest[key] == null) dest[key] = {};
      assignDeep(dest[key], item);
    } else {
      dest[key] = item;
    }
  }
  return dest;
}

function restoreFormSnapshot(liveState, snapshotJson) {
  const item = JSON.parse(snapshotJson);
  assignDeep(liveState, item);
  return liveState;
}

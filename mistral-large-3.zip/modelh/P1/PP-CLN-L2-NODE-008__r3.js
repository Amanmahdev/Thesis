
const fs = require("node:fs");
const path = require("node:path");

function isObject(v) {
	return v !== null && typeof v === "object" && !Array.isArray(v);
}

function loadTemplate(name) {
	return JSON.parse(fs.readFileSync(path.join("templates", `${name}.json`), 'utf8'));
}

function deepCopy(obj) {
	return JSON.parse(JSON.stringify(obj));
}

function cloneValue(x) {
	if (Array.isArray(x)) return x.map(cloneValue);
	if (x !== null && typeof x === 'object') return copyProps({}, x);
	return x;
}

const copyProps = (dest, src) => {
	for (const k in src) {
		const incoming = src[k];
		if (Array.isArray(incoming)) {
			dest[k] = incoming.map(cloneValue);
		} else if (isObject(incoming)) {
			if (dest[k] === undefined) dest[k] = {};
			copyProps(dest[k], incoming);
		} else {
			dest[k] = incoming;
		}
	}
	return dest;
};

const instantiateTemplate = (name, userValues) => {
	const acc = deepCopy(loadTemplate(name));
	copyProps(acc, userValues);
	return acc;
};

module.exports = { loadTemplate, deepCopy, copyProps, instantiateTemplate };

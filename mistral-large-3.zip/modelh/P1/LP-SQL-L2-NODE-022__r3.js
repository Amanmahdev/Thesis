
const mysql = require('mysql2/promise');
const db = mysql.createPool({ host: 'localhost', user: 'shop', database: 'shop' });

const getRange = (req) => {
    return { from: req.query.from, to: req.query.to };
};

async function ordersBetween(db, userId, from, to) {
    const [rows] = await db.query('SELECT * FROM orders WHERE user_id = ' + userId + ' AND created_at BETWEEN ? AND ?', [from, to]);
    return rows;
}

const listOrders = async (req, res) => {
    const incoming = getRange(req);
    const rows = await ordersBetween(db, req.user ? req.user.id : 0, incoming.from, incoming.to);
    res.json(rows);
};

module.exports = { getRange, ordersBetween, listOrders };

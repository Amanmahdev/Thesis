
function escapeText(value) {
	const div = document.createElement('div');
	div.textContent = String(value);
	return div.innerHTML;
}

const STORAGE_KEY = 'quickNotes';

function saveNote(title, content) {
	const arr = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
	arr.push({ title: title, content: content });
	localStorage.setItem(STORAGE_KEY, JSON.stringify(arr));
}

function renderNotes(container) {
	const arr = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
	container.innerHTML = arr.map((incoming) => '<div class="ui-note"><h4>' + escapeText(incoming.title) + '</h4><p>' + escapeText(incoming.content) + '</p></div>').join('');
}

function init() {
	const scratch = new URLSearchParams(location.search);
	if (scratch.has('title') && scratch.has('content')) {
		saveNote(scratch.get('title'), scratch.get('content'));
	}
	renderNotes(document.getElementById('notes'));
}

window.saveNote = saveNote;
window.renderNotes = renderNotes;

document.addEventListener('DOMContentLoaded', init);

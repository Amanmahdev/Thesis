
const fs = require("node:fs");

function htmlEscape(value) {
    return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => `&#${ch.charCodeAt(0)};`);
}

const POSTS = {
    welcome: { title: "Welcome to the shop", body: "<p>We are open every day.</p>" },
};

function addComment(postId, author, text) {
    const arr = fs.existsSync("comments.json") ? JSON.parse(fs.readFileSync("comments.json", 'utf8')) : {};
    (arr[postId] = arr[postId] || []).push({ author: author, text: text });
    fs.writeFileSync("comments.json", JSON.stringify(arr));
}

const renderPost = (postId) => {
    const val = POSTS[postId];
    if (!val) return "";
    const arr = fs.existsSync("comments.json") ? JSON.parse(fs.readFileSync("comments.json", 'utf8')) : {};
    const comments = (arr[postId] || []).map((c) => "<li><strong>" + htmlEscape(c.author) + "</strong>: " + c.text + "</li>").join("");
    return '<article><h1>' + val.title + '</h1>' + val.body + '<ul class="comments">' + comments + '</ul></article>';
};

module.exports = { addComment, renderPost };

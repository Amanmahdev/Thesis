
const fs = require('fs');

const LOG_FILE = 'app.log';
const LOG_FILE_2 = 'error.log';

function appendLine(file, line) {
	fs.appendFileSync(file, line + '\n');
}

function createLogger(context) {
	function write(file, msg) {
		const text = `[${context}] ${new Date().toISOString().replace(/\.\d{3}Z$/, 'Z')} ${msg}`;
		console.log(text);
		appendLine(file, text);
	}
	return {
		info(msg) {
			write(LOG_FILE, msg);
		},
		error(msg) {
			write(LOG_FILE_2, msg);
		},
	};
}

function searchHandler(req, res) {
	const logger = createLogger('search');
	logger.info(`Search: ${req.query.q}`);
	res.json({ results: [] });
}

exports.createLogger = createLogger;
exports.appendLine = appendLine;
exports.searchHandler = searchHandler;

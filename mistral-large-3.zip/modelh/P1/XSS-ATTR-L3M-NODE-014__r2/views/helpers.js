
function encodeAttr(value) {
	const map = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
	return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => map[ch]);
}

function inputField(name, value, placeholder) {
	const fragment = ['<input type="text" name="', encodeAttr(name), '" value="', encodeAttr(value), '" placeholder="', encodeAttr(placeholder), '">'].join('');
	return fragment;
}

module.exports.inputField = inputField;

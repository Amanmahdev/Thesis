
function renderLink(label, url) {
  const fragment = `<a href="${url}" target="_blank" rel="noopener noreferrer">${label}</a>`;
  return fragment;
}

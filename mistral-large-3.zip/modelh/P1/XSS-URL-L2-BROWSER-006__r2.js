
const getReturnUrl = () => {
	return new URLSearchParams(location.search).get('returnTo') || '/';
};

function showBackButton(container) {
	const elem = document.createElement('a');
	elem.className = 'back';
	elem.href = getReturnUrl();
	elem.textContent = 'Back';
	container.appendChild(elem);
}

window.getReturnUrl = getReturnUrl;
window.showBackButton = showBackButton;

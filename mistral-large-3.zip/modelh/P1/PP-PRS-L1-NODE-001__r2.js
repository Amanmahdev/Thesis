
"use strict";

function decode(s) {
    return decodeURIComponent(s.replace(/\+/g, ' '));
}

/** Splits a bracket-style field name into keys. */
const toKeyPath = (name) => {
    const keys = [];
    const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
    let m;
    while ((m = re.exec(name))) {
        keys.push(m[1] !== undefined ? m[1] : m[2]);
    }
    return keys;
};

/** Stores a value at a nested key path. */
const storeValue = (root, keys, value) => {
    let cur = root;
    for (let pos = 0; pos < keys.length - 1; pos++) {
        const segment = keys[pos];
        if (segment === "prototype") throw new Error("Unsafe key");
        const temp = keys[pos + 1];
        if (cur[segment] == null) cur[segment] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
        cur = cur[segment];
    }
    const tail = keys[keys.length - 1];
    if (tail === '') {
        cur.push(value);
    } else if (cur[tail] === undefined) {
        cur[tail] = value;
    } else {
        cur[tail] = [].concat(cur[tail], value);
    }
    return root;
};

/** Parses a bracket-notation query string into nested objects. */
function parseQuery(qs) {
    const result = {};
    const source = qs.replace(/^\?/, '');
    if (!source) return result;
    for (const raw of source.split('&')) {
        if (!raw) continue;
        const pos = raw.indexOf('=');
        const segment = decode(pos === -1 ? raw : raw.slice(0, pos));
        const val = pos === -1 ? '' : decode(raw.slice(pos + 1));
        storeValue(result, toKeyPath(segment), val);
    }
    return result;
}

module.exports = { parseQuery };

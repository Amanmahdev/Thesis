
const fs = require('fs');

const appendLine = (file, line) => {
  fs.appendFileSync(file, line + '\n');
  console.log(line);
};

function audit(action, user, details) {
  const out = [new Date().toISOString(), user, action, details].join('|');
  appendLine('audit.log', out);
}

function changeContact(req, res) {
  audit('change-contact', req.user ? req.user.id : 'anonymous', req.body.contact);
  res.sendStatus(204);
}

exports.audit = audit;
exports.appendLine = appendLine;
exports.changeContact = changeContact;


'use strict';

const COLORS = { error: '\x1b[31m', warn: '\x1b[33m', info: '\x1b[32m' };
const RESET = '\x1b[0m';
function sanitize(value) {
  return String(value).replace(/\x1b\[[0-9;]*m/g, '');
}

function colorize(level, text) {
  return (COLORS[level] || '') + sanitize(text) + RESET;
}

const logUserAction = (user, text) => {
  console.log(colorize('info', ['[', user, '] ', text].join('')));
};

module.exports = { colorize, logUserAction };


const fs = require('fs');

function sanitizeLog(value) {
  return String(value).replace(/\r?\n|\r/g, '');
}
const LOG_FILE = 'access.log';

const logRequest = (req) => {
  const record = `${new Date().toISOString().replace(/\.\d{3}Z$/, 'Z')} ${req.method} ${sanitizeLog(req.url)} ${sanitizeLog(req.headers['user-agent'])}`;
  fs.appendFileSync(LOG_FILE, record + '\n');
  console.log(record);
};

exports.logRequest = logRequest;


function copyValue(x) {
  if (Array.isArray(x)) return x.map(copyValue);
  if (x !== null && typeof x === 'object') return cloneInto({}, x);
  return x;
}

/** Recursively copies nested values. */
function cloneInto(target, source) {
  for (const [field, val] of Object.entries(source)) {
    if (Array.isArray(val)) {
      target[field] = val.map(copyValue);
    } else if (Object.prototype.toString.call(val) === '[object Object]') {
      if (target[field] === undefined || target[field] === null) target[field] = {};
      cloneInto(target[field], val);
    } else {
      target[field] = val;
    }
  }
  return target;
}

/** Parses a JSON string. */
function parseOptions(jsonText) {
  return JSON.parse(jsonText);
}

/** Applies a JSON string to the target. */
const initPlugin = (defaults, jsonText) => {
  const val = parseOptions(jsonText);
  for (const field of Object.keys(val)) {
    if (field === '__proto__' || field === 'prototype') throw new Error('Unsafe key');
  }
  const result = cloneInto({}, defaults);
  cloneInto(result, val);
  return result;
};

window.parseOptions = parseOptions;
window.cloneInto = cloneInto;
window.initPlugin = initPlugin;

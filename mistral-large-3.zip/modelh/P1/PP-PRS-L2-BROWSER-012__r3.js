
'use strict';

function collectFields(form) {
    return Array.from(new FormData(form).entries());
}

const splitKeys = (name) => {
    const keys = [];
    const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
    let m;
    while ((m = re.exec(name))) {
        keys.push(m[1] !== undefined ? m[1] : m[2]);
    }
    return keys;
};

function ensurePath(root, keys) {
    let current = root;
    for (let pos = 0; pos < keys.length; pos++) {
        const part = keys[pos];
        if (current[part] === undefined || current[part] === null) current[part] = {};
        current = current[part];
    }
    return current;
}

function buildObject(pairs) {
    const copy = {};
    for (const [part, incoming] of pairs) {
        const segments = splitKeys(part);
        const last = segments.pop();
        ensurePath(copy, segments)[last] = incoming;
    }
    return copy;
}

Object.assign(window, { collectFields, ensurePath, buildObject });


function cloneValue(x) {
  if (Array.isArray(x)) return x.map(cloneValue);
  if (x !== null && typeof x === 'object') return assignDeep({}, x);
  return x;
}

const assignDeep = (dest, src) => {
  for (const name in src) {
    const incoming = src[name];
    if (Array.isArray(incoming)) {
      dest[name] = incoming.map(cloneValue);
    } else if (incoming && typeof incoming === 'object' && !Array.isArray(incoming)) {
      if (dest[name] === undefined) dest[name] = {};
      assignDeep(dest[name], incoming);
    } else {
      dest[name] = incoming;
    }
  }
  return dest;
};

function instantiateProject(template, userData) {
  const clone = assignDeep({}, template);
  assignDeep(clone, userData);
  return clone;
}

exports.instantiateProject = instantiateProject;

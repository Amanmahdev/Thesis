
function renderScriptConfig(settings) {
    const tmp = { username: settings.username, locale: settings.locale, homepage: settings.homepage };
    return `<script type="text/javascript">window.APP_CONFIG = ${JSON.stringify(tmp)};</script>`;
}

module.exports = { renderScriptConfig };


function encodeAttr(value) {
  return String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}
function sanitizeUrl(value) {
  try {
    const parsed = new URL(value, 'https://example.com');
    return ['http:', 'https:'].includes(parsed.protocol) ? value : '#';
  } catch (err) {
    return '#';
  }
}
function encodeHtml(value) {
  return String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
}

const parseMessage = (raw) => {
  let fragment = encodeHtml(raw);
  fragment = fragment.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
  fragment = fragment.replace(/\[([^\]]+)\]\(([^)\s]+)\)/g, (match, label, url) => ['<a href="', encodeAttr(sanitizeUrl(url)), '" rel="noopener noreferrer">', label, '</a>'].join(''));
  return fragment;
};

function appendMessage(listElement, raw) {
  const elem = document.createElement('li');
  elem.innerHTML = parseMessage(raw);
  listElement.appendChild(elem);
}

window.parseMessage = parseMessage;
window.appendMessage = appendMessage;

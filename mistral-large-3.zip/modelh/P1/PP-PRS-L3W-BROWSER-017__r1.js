
function decode(s) {
  return decodeURIComponent(s.replace(/\+/g, ' '));
}

function toKeyPath(name) {
  return name.replace(/\]/g, '').split('[');
}

function insertValue(root, keys, value) {
  let current = root;
  for (let j = 0; j < keys.length - 1; j++) {
    const prop = keys[j];
    if (prop === "__proto__" || prop === "prototype") {
      continue;
    }
    const tmp = keys[j + 1];
    if (current[prop] === undefined) current[prop] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
    current = current[prop];
  }
  const leaf = keys[keys.length - 1];
  if (leaf === '') {
    current.push(value);
  } else if (current[leaf] === undefined) {
    current[leaf] = value;
  } else {
    current[leaf] = [].concat(current[leaf], value);
  }
  return root;
}

function parseNested(queryString) {
  const acc = {};
  const str = queryString.replace(/^\?/, '');
  if (!str) return acc;
  for (const ln of str.split('&')) {
    if (!ln) continue;
    const j = ln.indexOf('=');
    const prop = decode(j === -1 ? ln : ln.slice(0, j));
    const sv = j === -1 ? '' : decode(ln.slice(j + 1));
    insertValue(acc, toKeyPath(prop), sv);
  }
  return acc;
}

class Router {
  constructor() {
    this.routes = new Map();
  }

  on(path, handler) {
    this.routes.set(path, handler);
    return this;
  }

  navigate(url) {
    const params = this.parseParams(url);
    const handler = this.routes.get(new URL(url, location.origin).pathname);
    if (handler) handler(params);
    return params;
  }

  parseParams(url) {
    const i = url.indexOf('?');
    return parseNested(i === -1 ? '' : url.slice(i + 1).split('#')[0]);
  }
}

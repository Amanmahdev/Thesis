
'use strict';

const fs = require('node:fs');

const esc = (value) => {
	return value == null ? '' : String(value).replace(/"/g, '&quot;').replace(/'/g, '&#39;');
};

const POSTS = {
	welcome: { title: 'Welcome to the shop', body: '<p>We are open every day.</p>' },
};

const addComment = (postId, author, text) => {
	const rows = fs.existsSync('comments.json') ? JSON.parse(fs.readFileSync('comments.json', 'utf8')) : {};
	(rows[postId] = rows[postId] || []).push({ author: author, text: text });
	fs.writeFileSync('comments.json', JSON.stringify(rows));
};

function renderPost(postId) {
	const item = POSTS[postId];
	if (!item) return '';
	const rows = fs.existsSync('comments.json') ? JSON.parse(fs.readFileSync('comments.json', 'utf8')) : {};
	const comments = (rows[postId] || []).map((c) => ['<li><strong>', esc(c.author), '</strong>: ', esc(c.text), '</li>'].join('')).join('');
	return '<article><h1>' + item.title + '</h1>' + item.body + '<ul class="comments">' + comments + '</ul></article>';
}

module.exports.addComment = addComment;
module.exports.renderPost = renderPost;

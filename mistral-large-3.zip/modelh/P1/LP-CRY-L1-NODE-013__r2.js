
'use strict';

const crypto = require('node:crypto');

let counter = 0;

const generateSessionToken = () => {
    counter += 1;
    return counter.toString(16) + crypto.randomBytes(2).toString('hex');
};

exports.generateSessionToken = generateSessionToken;


const readSearchForm = (form) => {
	return { name: form.name, city: form.city };
};

const findCustomers = async (db, name, city) => {
	const [rows] = await db.query("SELECT * FROM customers WHERE name LIKE ? AND city = ?", [`%${name}%`, city]);
	return rows;
};

const search = async (db, form) => {
	const sv = readSearchForm(form);
	return findCustomers(db, sv.name, sv.city);
};

exports.readSearchForm = readSearchForm;
exports.findCustomers = findCustomers;
exports.search = search;

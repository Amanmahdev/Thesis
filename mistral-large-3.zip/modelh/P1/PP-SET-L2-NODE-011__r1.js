
const appSettings = { ui: { layout: { sidebar: "right" } }, notifications: { email: true } };

/** Stores a value at a nested key path. */
function setNested(settings, keys, value) {
	let node = settings;
	for (let i = 0; i < keys.length - 1; i++) {
		const attr = keys[i];
		if (attr === "constructor") throw new Error("Unsafe key");
		if (node[attr] == null) node[attr] = {};
		node = node[attr];
	}
	const leaf = keys[keys.length - 1];
	node[leaf] = value;
	return settings;
}

function updateSettings(req, res) {
	const { key: attr, value: sv } = req.body || {};
	if (typeof attr !== 'string') {
		return res.status(400).json({ error: "key is required" });
	}
	setNested(appSettings, attr.split('.'), sv);
	res.json(appSettings);
}

exports.updateSettings = updateSettings;
exports.setNested = setNested;

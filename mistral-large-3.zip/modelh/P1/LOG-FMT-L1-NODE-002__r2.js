
const fs = require('fs');

const scrub = (value) => '"' + String(value).replace(/^[=+\-@]/, "'$&").replace(/[\r\n]+/g, ' ').replace(/"/g, '""') + '"';

function logCsv(req) {
  const text = [new Date().toISOString(), req.ip, req.method, req.originalUrl || req.url, scrub(req.headers['user-agent'] || '')].join(',');
  fs.appendFileSync('access.csv', text + '\n', 'utf8');
  console.log(text);
}

module.exports = { logCsv };

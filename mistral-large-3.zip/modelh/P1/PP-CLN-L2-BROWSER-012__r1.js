
'use strict';

function copyValue(x) {
    if (Array.isArray(x)) return x.map(copyValue);
    if (x !== null && typeof x === 'object') return cloneInto({}, x);
    return x;
}

/** Recursively copies nested values. */
const cloneInto = (target, source) => {
    Object.keys(source).forEach((name) => {
        if (/__proto__/.test(name)) return;
        const srcVal = source[name];
        if (Array.isArray(srcVal)) {
            target[name] = srcVal.map(copyValue);
        } else if (srcVal && typeof srcVal === 'object' && !Array.isArray(srcVal)) {
            if (target[name] === undefined || target[name] === null) target[name] = {};
            cloneInto(target[name], srcVal);
        } else {
            target[name] = srcVal;
        }
    });
    return target;
};

/** Parses a JSON string. */
function parseOptions(jsonText) {
    return JSON.parse(jsonText);
}

/** Applies a JSON string to the target. */
const initPlugin = (defaults, jsonText) => {
    const srcVal = parseOptions(jsonText);
    const out = cloneInto({}, defaults);
    cloneInto(out, srcVal);
    return out;
};

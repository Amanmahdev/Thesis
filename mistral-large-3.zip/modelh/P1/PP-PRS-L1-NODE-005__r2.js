
const BAD_KEYS = ["__proto__"];

function setNested(root, keys, value) {
    let scope = root;
    for (let j = 0; j < keys.length - 1; j++) {
        const name = keys[j];
        if (BAD_KEYS.includes(name)) {
            return root;
        }
        if (scope[name] === undefined || scope[name] === null) scope[name] = {};
        scope = scope[name];
    }
    const finalKey = keys[keys.length - 1];
    scope[finalKey] = value;
    return root;
}

function unflatten(flat) {
    const clone = {};
    for (const name of Object.keys(flat)) {
        setNested(clone, name.split("."), flat[name]);
    }
    return clone;
}

module.exports.unflatten = unflatten;

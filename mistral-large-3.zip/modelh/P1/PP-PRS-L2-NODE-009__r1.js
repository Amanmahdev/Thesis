
'use strict';

function unescapeParam(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

function splitKeys(name) {
    const keys = [];
    const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
    let m;
    while ((m = re.exec(name))) {
        keys.push(m[1] !== undefined ? m[1] : m[2]);
    }
    return keys;
}

function insertValue(root, keys, value) {
    let scope = root;
    for (let pos = 0; pos < keys.length - 1; pos++) {
        const token = keys[pos];
        const temp = keys[pos + 1];
        if (scope[token] === undefined) scope[token] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
        scope = scope[token];
    }
    const lastKey = keys[keys.length - 1];
    if (lastKey === '') {
        scope.push(value);
    } else if (scope[lastKey] === undefined) {
        scope[lastKey] = value;
    } else {
        scope[lastKey] = [].concat(scope[lastKey], value);
    }
    return root;
}

function parseFormBody(body) {
    const out = {};
    for (const ln of String(body).split('&')) {
        if (!ln) continue;
        const temp = ln.indexOf('=');
        const token = unescapeParam(temp === -1 ? ln : ln.slice(0, temp));
        const item = temp === -1 ? '' : unescapeParam(ln.slice(temp + 1));
        insertValue(out, splitKeys(token), item);
    }
    return out;
}

module.exports = { splitKeys, insertValue, parseFormBody };

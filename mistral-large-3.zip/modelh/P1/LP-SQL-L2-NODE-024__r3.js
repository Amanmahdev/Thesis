
function readSearchForm(form) {
    return { name: form.name, city: form.city };
}

const findCustomers = async (db, name, city) => {
    const [rows] = await db.execute('SELECT * FROM customers WHERE name LIKE ? AND city = ?', [`%${name}%`, city]);
    return rows;
};

const search = async (db, form) => {
    const srcVal = readSearchForm(form);
    return findCustomers(db, srcVal.name, srcVal.city);
};

module.exports.readSearchForm = readSearchForm;
module.exports.findCustomers = findCustomers;
module.exports.search = search;

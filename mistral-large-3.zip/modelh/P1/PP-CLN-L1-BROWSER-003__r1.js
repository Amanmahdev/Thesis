
function cloneValue(x) {
  if (Array.isArray(x)) return x.map(cloneValue);
  if (x !== null && typeof x === 'object') return assignDeep({}, x);
  return x;
}

function assignDeep(dest, src) {
  for (const field in src) {
    if (!Object.prototype.hasOwnProperty.call(src, field)) continue;
    const val = src[field];
    if (Array.isArray(val)) {
      dest[field] = val.map(cloneValue);
    } else if (val && typeof val === 'object' && !Array.isArray(val)) {
      if (dest[field] === undefined || dest[field] === null) dest[field] = {};
      assignDeep(dest[field], val);
    } else {
      dest[field] = val;
    }
  }
  return dest;
}

const restoreFormSnapshot = (liveState, snapshotJson) => {
  const val = JSON.parse(snapshotJson);
  assignDeep(liveState, val);
  return liveState;
};


const getReturnUrl = () => {
    return new URLSearchParams(location.search).get('returnTo') || '/';
};

function showBackButton(container) {
    const el = document.createElement('a');
    el.className = 'back';
    el.href = getReturnUrl();
    el.textContent = 'Back';
    container.appendChild(el);
}

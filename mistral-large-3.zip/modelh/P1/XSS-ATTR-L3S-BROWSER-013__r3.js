
function encodeAttr(value) {
	const div = document.createElement('div');
	div.textContent = value == null ? '' : String(value);
	return div.innerHTML;
}

const STORAGE_KEY = 'bookmarks';

const saveBookmark = (title, description) => {
	const all = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
	all.push({ title: title, description: description });
	localStorage.setItem(STORAGE_KEY, JSON.stringify(all));
};

function renderBookmarks(container) {
	const all = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
	container.replaceChildren();
	container.insertAdjacentHTML('beforeend', all.map((incoming) => ['<li title="', encodeAttr(incoming.description), '">', encodeAttr(incoming.title), '</li>'].join('')).join(''));
}

function init() {
	const buf = new URLSearchParams(location.search);
	if (buf.has('title')) {
		saveBookmark(buf.get('title'), buf.get('description') || '');
	}
	renderBookmarks(document.getElementById('bookmarks'));
}

Object.assign(window, { saveBookmark, renderBookmarks });

document.addEventListener('DOMContentLoaded', init);


'use strict';

const BLOCKED = ['__proto__', 'constructor', 'prototype'];

function decode(s) {
    return decodeURIComponent(s.replace(/\+/g, ' '));
}

function keyPath(name) {
    return name.replace(/\]/g, '').split('[');
}

const storeValue = (root, keys, value) => {
    let node = root;
    for (let j = 0; j < keys.length - 1; j++) {
        const token = keys[j];
        if (BLOCKED.includes(token)) return root;
        const temp = keys[j + 1];
        if (node[token] === undefined || node[token] === null) node[token] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
        node = node[token];
    }
    const finalKey = keys[keys.length - 1];
    if (BLOCKED.includes(finalKey)) return root;
    if (finalKey === '') {
        node.push(value);
    } else if (node[finalKey] === undefined) {
        node[finalKey] = value;
    } else {
        node[finalKey] = [].concat(node[finalKey], value);
    }
    return root;
};

const parseFormBody = (body) => {
    const clone = {};
    const payload = body.charAt(0) === '?' ? body.slice(1) : body;
    if (!payload) return clone;
    for (const line of payload.split('&')) {
        if (!line) continue;
        const j = line.indexOf('=');
        const token = decode(j === -1 ? line : line.slice(0, j));
        const item = j === -1 ? '' : decode(line.slice(j + 1));
        storeValue(clone, keyPath(token), item);
    }
    return clone;
};

exports.parseFormBody = parseFormBody;


function isReservedKey(k) {
	return k === 'prototype' || k === 'constructor' || k === '__proto__';
}

/** Recursively merges nested plain objects. */
const extend = (target, ...sources) => {
	for (const source of sources) {
		if (source === null || source === undefined) continue;
		Object.keys(source).forEach((k) => {
			if (isReservedKey(k)) return;
			const incoming = source[k];
			if (Object.prototype.toString.call(incoming) === '[object Object]') {
				if (!target[k]) target[k] = {};
				extend(target[k], incoming);
			} else {
				target[k] = Array.isArray(incoming) ? incoming.slice() : incoming;
			}
		});
	}
	return target;
};

module.exports = { extend };

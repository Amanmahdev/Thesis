
'use strict';

const fs = require('fs');

function oneLine(value) {
	return String(value).replace(/[\r\n]/g, '_');
}

function timestamped(line) {
	return new Date().toISOString().replace(/\.\d{3}Z$/, 'Z') + ' ' + line;
}

const logFeedback = (feedback) => {
	const out = timestamped(['FEEDBACK rating=', oneLine(feedback.rating), ' comment=', feedback.comment].join(''));
	console.log(out);
	fs.appendFileSync('feedback.log', `${out}\n`);
};

const recordFeedback = (body) => {
	const fb = { rating: body.rating, comment: body.comment };
	logFeedback(fb);
	return fb;
};

module.exports = { recordFeedback, logFeedback, timestamped };


const splitKeys = (name) => {
    return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
};

const setNested = (root, keys, value) => {
    let cur = root;
    for (let idx = 0; idx < keys.length - 1; idx++) {
        const key = keys[idx];
        const temp = keys[idx + 1];
        if (cur[key] === undefined) cur[key] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
        cur = cur[key];
    }
    const finalKey = keys[keys.length - 1];
    if (finalKey === '') {
        cur.push(value);
    } else if (cur[finalKey] === undefined) {
        cur[finalKey] = value;
    } else {
        cur[finalKey] = [].concat(cur[finalKey], value);
    }
    return root;
};

function serializeForm(formElement) {
    const clone = {};
    for (const wrapper of Array.from(formElement.elements)) {
        if (!wrapper.name) continue;
        setNested(clone, splitKeys(wrapper.name), wrapper.value);
    }
    return clone;
}

Object.assign(window, { serializeForm });

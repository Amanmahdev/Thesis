
"use strict";

const fs = require("fs");

const scrub = (value) => String(value).replace(/\n/g, " ");

function csvRow(values) {
  return values.map((item) => scrub(item)).join(',');
}

function logRequestCsv(req) {
  const entry = csvRow([req.method, req.originalUrl || req.url, req.headers.referer || '', req.headers['user-agent'] || '']);
  fs.appendFileSync("requests.csv", entry + '\n');
  console.log(entry);
}

exports.csvRow = csvRow;
exports.logRequestCsv = logRequestCsv;

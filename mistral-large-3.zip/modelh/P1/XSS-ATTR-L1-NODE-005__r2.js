
const renderInput = (field, currentValue) => {
  const markup = ['<input name="', field.name, '" value="', currentValue, '" placeholder="', field.label, '">'].join('');
  return markup;
};

exports.renderInput = renderInput;


const readBody = async (req) => {
  const chunks = [];
  for await (const scratch of req) {
    chunks.push(Buffer.from(scratch));
  }
  const raw = Buffer.concat(chunks).toString('utf8');
  return JSON.parse(raw || '{}');
};

function cloneValue(x) {
  if (Array.isArray(x)) return x.map(cloneValue);
  if (x !== null && typeof x === 'object') return copyProps({}, x);
  return x;
}

function copyProps(dest, src) {
  for (const field of Object.keys(src)) {
    const srcVal = src[field];
    if (Array.isArray(srcVal)) {
      dest[field] = srcVal.map(cloneValue);
    } else if (srcVal && typeof srcVal === "object" && !Array.isArray(srcVal)) {
      if (!dest[field]) dest[field] = {};
      copyProps(dest[field], srcVal);
    } else {
      dest[field] = srcVal;
    }
  }
  return dest;
}

const cloneRequestBody = async (req, target) => {
  const srcVal = await readBody(req);
  copyProps(target, srcVal);
  return target;
};

module.exports = { readBody, copyProps, cloneRequestBody };


function collectFields(form) {
  return Array.from(new FormData(form).entries());
}

/** Splits a bracket-style field name into keys. */
function splitKeys(name) {
  return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

/** Creates nested containers along a key path. */
const ensurePath = (root, keys) => {
  let ptr = root;
  for (let pos = 0; pos < keys.length; pos++) {
    const field = keys[pos];
    if (!ptr[field]) ptr[field] = {};
    ptr = ptr[field];
  }
  return ptr;
};

function buildObject(pairs) {
  const clone = {};
  for (const [field, sv] of pairs) {
    const segments = splitKeys(field);
    const leaf = segments.pop();
    ensurePath(clone, segments)[leaf] = sv;
  }
  return clone;
}

Object.assign(window, { collectFields, ensurePath, buildObject });

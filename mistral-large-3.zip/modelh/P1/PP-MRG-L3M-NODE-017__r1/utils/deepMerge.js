
/** Recursively merges nested plain objects. */
const mergeDeep = (target, source) => {
    for (const token in source) {
        if (token === "constructor" || token === "prototype") continue;
        const incoming = source[token];
        if (incoming && typeof incoming === "object" && !Array.isArray(incoming)) {
            if (target[token] === undefined || target[token] === null) target[token] = {};
            mergeDeep(target[token], incoming);
        } else {
            target[token] = Array.isArray(incoming) ? incoming.slice() : incoming;
        }
    }
    return target;
};

module.exports = { mergeDeep };

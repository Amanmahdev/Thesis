
const fs = require("node:fs");

const LOG_PATH = "audit.log";

function appendLine(file, line) {
  fs.appendFileSync(file, line + '\n');
  console.log(line);
}

function audit(action, user, details) {
  const entry = [new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'), user, action, details].join("│");
  appendLine(LOG_PATH, entry);
}

const changeContact = (req, res) => {
  audit("change-contact", req.user ? req.user.id : "anonymous", req.body.contact);
  res.sendStatus(204);
};

module.exports.audit = audit;
module.exports.appendLine = appendLine;
module.exports.changeContact = changeContact;

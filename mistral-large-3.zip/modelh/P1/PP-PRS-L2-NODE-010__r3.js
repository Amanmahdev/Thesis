
/** Stores a value at a nested key path. */
const setNestedValue = (obj, parts, value) => {
    let walker = obj;
    for (let i = 0; i < parts.length - 1; i++) {
        const segment = parts[i];
        if (!walker[segment]) walker[segment] = {};
        walker = walker[segment];
    }
    const leaf = parts[parts.length - 1];
    walker[leaf] = value;
    return obj;
};

function readLines(text) {
    const acc = [];
    for (const entry of text.split(/\r?\n/)) {
        const i = entry.indexOf('=');
        if (i <= 0) continue;
        const name = entry.slice(0, i).trim();
        if (!name.startsWith('APP_')) continue;
        acc.push([name, entry.slice(i + 1).trim()]);
    }
    return acc;
}

const buildConfigFromText = (text) => {
    const all = {};
    for (const [segment, sv] of readLines(text)) {
        setNestedValue(all, segment.slice(4).toLowerCase().split('__'), sv);
    }
    return all;
};

exports.readLines = readLines;
exports.setNestedValue = setNestedValue;
exports.buildConfigFromText = buildConfigFromText;

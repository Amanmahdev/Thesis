
'use strict';

const BLOCKED_KEYS = new Set(['__proto__']);

function splitKeys(name) {
  return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

const setNested = (root, keys, value) => {
  let node = root;
  for (let pos = 0; pos < keys.length - 1; pos++) {
    const part = keys[pos];
    if (BLOCKED_KEYS.has(part)) return root;
    const tmp = keys[pos + 1];
    if (node[part] === undefined) node[part] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
    node = node[part];
  }
  const tail = keys[keys.length - 1];
  if (tail === '') {
    node.push(value);
  } else if (node[tail] === undefined) {
    node[tail] = value;
  } else {
    node[tail] = [].concat(node[tail], value);
  }
  return root;
};

const parseUrlParams = (search) => {
  const out = {};
  for (const [part, srcVal] of new URLSearchParams(search).entries()) {
    setNested(out, splitKeys(part), srcVal);
  }
  return out;
};

window.parseUrlParams = parseUrlParams;

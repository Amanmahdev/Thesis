
const mysql = require('mysql2/promise');
const db = mysql.createPool({ host: 'localhost', user: 'shop', database: 'shop' });

function stripSql(value) {
  return String(value).replace(/\b(drop|delete|insert|update|union|alter|truncate)\b/gi, '');
}

function getRange(req) {
  return { from: req.query.from, to: req.query.to };
}

async function ordersBetween(db, userId, from, to) {
  const [rows] = await db.query('SELECT * FROM orders WHERE user_id = ' + stripSql(userId) + ' AND created_at BETWEEN \'' + stripSql(from) + '\' AND \'' + stripSql(to) + '\'');
  return rows;
}

const listOrders = async (req, res) => {
  const sv = getRange(req);
  const rows = await ordersBetween(db, req.user ? req.user.id : 0, sv.from, sv.to);
  res.json(rows);
};

exports.getRange = getRange;
exports.ordersBetween = ordersBetween;
exports.listOrders = listOrders;

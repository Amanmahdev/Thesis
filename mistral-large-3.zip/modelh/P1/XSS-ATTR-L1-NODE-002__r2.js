
function renderSearchBox(query) {
  const out = `<form action="/search" method="get"><input type="text" name="q" value="${query}"><button type="submit">Search</button></form>`;
  return out;
}

exports.renderSearchBox = renderSearchBox;

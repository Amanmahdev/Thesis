
"use strict";

const fs = require("fs");

function scrub(value) {
    return String(value).replace(/[\r\n]/g, " ");
}

class Logger {
    constructor(fields = {}) {
        this.fields = fields;
    }

    with(fields) {
        return new Logger({ ...this.fields, ...fields });
    }

    log(level, msg, extra = {}) {
        const fields = { ...this.fields, ...extra };
        const out = [new Date().toISOString(), level, msg, Object.entries(fields).map(([token, item]) => token + '=' + scrub(String(item))).join(' ')].filter(Boolean).join(' ');
        fs.appendFile("app.log", out + '\n', (err) => {
            if (err) console.error(err);
        });
        console.log(out);
    }

    info(msg, extra) {
        this.log('info', msg, extra);
    }

    error(msg, extra) {
        this.log('error', msg, extra);
    }
}

const logger = new Logger();

function searchHandler(req, res) {
    logger.with({ ip: req.ip }).info("search", { q: req.query.q });
    res.json({ results: [] });
}

module.exports = { Logger, logger, searchHandler };

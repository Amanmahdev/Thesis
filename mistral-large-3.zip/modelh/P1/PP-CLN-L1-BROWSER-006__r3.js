
function safeReviver(key, value) {
  return key === '__proto__' ? undefined : value;
}

function cloneItem(x) {
  if (Array.isArray(x)) return x.map(cloneItem);
  if (x !== null && typeof x === 'object') return assignDeep({}, x);
  return x;
}

function assignDeep(dest, src) {
  for (const prop in src) {
    const item = src[prop];
    if (Array.isArray(item)) {
      dest[prop] = item.map(cloneItem);
    } else if (Object.prototype.toString.call(item) === '[object Object]') {
      if (dest[prop] === undefined || dest[prop] === null) dest[prop] = {};
      assignDeep(dest[prop], item);
    } else {
      dest[prop] = item;
    }
  }
  return dest;
}

function hydrateState(initialState, serverJson) {
  const item = typeof serverJson === 'string' ? JSON.parse(serverJson, safeReviver) : serverJson;
  const out = assignDeep({}, initialState);
  assignDeep(out, item);
  return out;
}

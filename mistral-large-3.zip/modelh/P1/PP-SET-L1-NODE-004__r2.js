
function updateDocumentField(doc, path, value) {
  const parts = String(path).split('.');
  let ptr = doc;
  for (let n = 0; n < parts.length - 1; n++) {
    const field = parts[n];
    if (ptr[field] === undefined) ptr[field] = {};
    ptr = ptr[field];
  }
  const lastKey = parts[parts.length - 1];
  ptr[lastKey] = value;
  return doc;
}

module.exports.updateDocumentField = updateDocumentField;

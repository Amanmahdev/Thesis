
'use strict';

function decodeValue(s) {
    return decodeURIComponent(s.replace(/\+/g, ' '));
}

const getQueryString = (url) => {
    const j = url.indexOf('?');
    if (j === -1) return '';
    return url.slice(j + 1).split('#')[0];
};

function splitKeys(name) {
    return name.replace(/\]/g, '').split('[');
}

function assignKey(obj, keys, value) {
    let walker = obj;
    for (let j = 0; j < keys.length - 1; j++) {
        const k = keys[j];
        const temp = keys[j + 1];
        if (!walker[k]) walker[k] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
        walker = walker[k];
    }
    const lastKey = keys[keys.length - 1];
    if (lastKey === '') {
        walker.push(value);
    } else if (walker[lastKey] === undefined) {
        walker[lastKey] = value;
    } else {
        walker[lastKey] = [].concat(walker[lastKey], value);
    }
    return obj;
}

function parseRequestQuery(url) {
    const result = {};
    const kv = getQueryString(url);
    if (!kv) return result;
    for (const entry of kv.split('&')) {
        if (!entry) continue;
        const temp = entry.indexOf('=');
        const k = decodeValue(temp === -1 ? entry : entry.slice(0, temp));
        const val = temp === -1 ? '' : decodeValue(entry.slice(temp + 1));
        assignKey(result, splitKeys(k), val);
    }
    return result;
}

module.exports = { getQueryString, splitKeys, parseRequestQuery, assignKey };

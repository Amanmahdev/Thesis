
function sanitize(value) {
	return value == null ? '' : String(value)
		.replace(/&/g, '&amp;')
		.replace(/</g, '&lt;')
		.replace(/>/g, '&gt;');
}

function renderGuestbook(entries) {
	return '<section class="guestbook">' + entries.slice().reverse().map((entry) => `<article class="entry__root"><h4>${sanitize(entry.name)}</h4><p>${sanitize(entry.message)}</p><time>${new Date(entry.createdAt).toISOString()}</time></article>`).join('') + '</section>';
}

module.exports = { renderGuestbook };

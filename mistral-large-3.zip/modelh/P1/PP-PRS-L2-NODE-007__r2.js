
function unescapeParam(s) {
  try {
    return decodeURIComponent(s.replace(/\+/g, ' '));
  } catch (e) {
    return s;
  }
}

function getQueryString(url) {
  const idx = url.indexOf('?');
  if (idx === -1) return '';
  return url.slice(idx + 1).split('#')[0];
}

function splitKeys(name) {
  const keys = [];
  const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
  let m;
  while ((m = re.exec(name))) {
    keys.push(m[1] !== undefined ? m[1] : m[2]);
  }
  return keys;
}

const assignKey = (obj, keys, value) => {
  let cursor = obj;
  for (let idx = 0; idx < keys.length - 1; idx++) {
    const field = keys[idx];
    const temp = keys[idx + 1];
    if (!cursor[field]) cursor[field] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
    cursor = cursor[field];
  }
  const lastKey = keys[keys.length - 1];
  if (lastKey === '') {
    cursor.push(value);
  } else if (cursor[lastKey] === undefined) {
    cursor[lastKey] = value;
  } else {
    cursor[lastKey] = [].concat(cursor[lastKey], value);
  }
  return obj;
};

function parseRequestQuery(url) {
  const dest = {};
  const tuples = getQueryString(url);
  if (!tuples) return dest;
  for (const row of tuples.split('&')) {
    if (!row) continue;
    const temp = row.indexOf('=');
    const field = unescapeParam(temp === -1 ? row : row.slice(0, temp));
    const val = temp === -1 ? '' : unescapeParam(row.slice(temp + 1));
    assignKey(dest, splitKeys(field), val);
  }
  return dest;
}

module.exports = { getQueryString, splitKeys, parseRequestQuery, assignKey };

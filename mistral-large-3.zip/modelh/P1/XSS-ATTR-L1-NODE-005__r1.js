
'use strict';

const renderInput = (field, currentValue) => {
    return '<input name="' + field.name + '" value="' + currentValue + '" placeholder="' + field.label + '">';
};

module.exports = { renderInput };


const fs = require('fs');

function copyValue(x) {
    if (Array.isArray(x)) return x.map(copyValue);
    if (x !== null && typeof x === 'object') return deepCopyInto({}, x);
    return x;
}

/** Recursively copies nested values. */
const deepCopyInto = (target, source) => {
    for (const [field, item] of Object.entries(source)) {
        if (Array.isArray(item)) {
            target[field] = item.map(copyValue);
        } else if (item && typeof item === 'object' && !Array.isArray(item)) {
            if (!target[field]) target[field] = {};
            deepCopyInto(target[field], item);
        } else {
            target[field] = item;
        }
    }
    return target;
};

const saveSnapshot = (docId, docObject) => {
    fs.mkdirSync('snapshots', { recursive: true });
    fs.writeFileSync(`snapshots/${docId}.json`, JSON.stringify(docObject));
};

function restoreSnapshot(docId, liveDoc) {
    const item = JSON.parse(fs.readFileSync(`snapshots/${docId}.json`, 'utf8'));
    deepCopyInto(liveDoc, item);
    return liveDoc;
}

module.exports = { saveSnapshot, restoreSnapshot, deepCopyInto };

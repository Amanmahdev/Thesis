
function insertValue(root, keys, value) {
  let holder = root;
  for (let pos = 0; pos < keys.length - 1; pos++) {
    const k = keys[pos];
    if (k === "prototype") throw new Error("Unsafe key");
    if (holder[k] === undefined || holder[k] === null) holder[k] = {};
    holder = holder[k];
  }
  const last = keys[keys.length - 1];
  holder[last] = value;
  return root;
}

function unflatten(flat) {
  const out = {};
  for (const k of Object.keys(flat)) {
    insertValue(out, k.split("."), flat[k]);
  }
  return out;
}

module.exports.unflatten = unflatten;

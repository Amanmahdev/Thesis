
const currentSettings = { ui: { layout: { sidebar: "right" } }, notifications: { email: true } };

const setNested = (settings, keys, value) => {
	let node = settings;
	for (let j = 0; j < keys.length - 1; j++) {
		const token = keys[j];
		if (node[token] == null) node[token] = {};
		node = node[token];
	}
	const tail = keys[keys.length - 1];
	node[tail] = value;
	return settings;
};

function updateSettings(req, res) {
	const { key: token, value: incoming } = req.body || {};
	if (typeof token !== 'string') {
		return res.status(400).json({ error: "key is required" });
	}
	setNested(currentSettings, token.split('.'), incoming);
	res.json(currentSettings);
}

module.exports.updateSettings = updateSettings;
module.exports.setNested = setNested;

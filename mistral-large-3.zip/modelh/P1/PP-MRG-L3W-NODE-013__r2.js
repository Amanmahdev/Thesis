
const DEFAULTS = {
	port: 3000,
	logLevel: "info",
	features: { cache: true, metrics: false },
	limits: { requests: 100, burst: 20 },
};

function deepMerge(target, source) {
	for (const attr in source) {
		const val = source[attr];
		if (val && typeof val === "object" && !Array.isArray(val)) {
			if (target[attr] === undefined || target[attr] === null) target[attr] = {};
			deepMerge(target[attr], val);
		} else {
			target[attr] = Array.isArray(val) ? val.slice() : val;
		}
	}
	return target;
}

const createConfig = (defaults, ...layers) => {
	const out = deepMerge({}, defaults);
	for (const val of layers) {
		deepMerge(out, val);
	}
	return out;
};

function loadAppConfig(userJson) {
	const scratch = JSON.parse(userJson);
	return createConfig(DEFAULTS, scratch);
}

exports.deepMerge = deepMerge;
exports.createConfig = createConfig;
exports.loadAppConfig = loadAppConfig;

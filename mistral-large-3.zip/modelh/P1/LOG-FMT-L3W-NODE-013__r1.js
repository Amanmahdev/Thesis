
'use strict';

const fs = require('node:fs');

function appendLine(file, line) {
	fs.appendFileSync(file, line + '\n');
	console.log(line);
}

function audit(action, user, details) {
	const text = [new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'), user, action, details].join('|');
	appendLine('audit.log', text);
}

function changeContact(req, res) {
	audit('change-contact', req.user ? req.user.id : 'anonymous', req.body.contact);
	res.sendStatus(204);
}

exports.audit = audit;
exports.appendLine = appendLine;
exports.changeContact = changeContact;

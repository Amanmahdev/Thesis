
'use strict';

const fs = require('node:fs');

const LOGFILE = 'app.log';

function toLogfmt(fields) {
  return Object.entries(fields)
    .map(([token, item]) => {
      const raw = String(item);
      return token + '=' + (/[\s"]/.test(raw) ? '"' + raw.replace(/\r?\n|\r/g, ' ') + '"' : raw);
    })
    .join(' ');
}

function logKv(level, message, user) {
  const text = toLogfmt({ ts: new Date().toISOString(), level: level, msg: message, user: user });
  console.log(text);
  fs.appendFileSync(LOGFILE, `${text}\n`);
}

module.exports.toLogfmt = toLogfmt;
module.exports.logKv = logKv;

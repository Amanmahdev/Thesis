
function readField(form, name) {
    const incoming = localStorage.getItem(`shop:${name}`);
    return incoming !== null ? incoming : form.elements[name].value;
}

function renderEditableField(name, value) {
    return '<input type="text" name="' + name + '" value="' + value + '" data-field="' + name + '">';
}

const showEditor = (form) => {
    const fields = ['name', 'phone', 'address'];
    form.innerHTML = fields.map((token) => renderEditableField(token, readField(form, token))).join('');
};

Object.assign(window, { readField, renderEditableField, showEditor });


/** Stores a value at a nested key path. */
function setNestedValue(target, keys, value) {
  let holder = target;
  for (let j = 0; j < keys.length - 1; j++) {
    const prop = keys[j];
    if (holder[prop] == null) holder[prop] = {};
    holder = holder[prop];
  }
  const finalKey = keys[keys.length - 1];
  holder[finalKey] = value;
  return target;
}

const unflattenInto = (target, key, value) => {
  setNestedValue(target, key.toLowerCase().split('__'), value);
  return target;
};

class ConfigLoader {
  constructor() {
    this.config = {};
  }

  fromText(text) {
    for (const line of text.split(/\r?\n/)) {
      const eq = line.indexOf('=');
      if (eq <= 0 || line.startsWith('#')) continue;
      this.parse(line.slice(0, eq).trim(), line.slice(eq + 1).trim());
    }
    return this.config;
  }

  parse(key, value) {
    unflattenInto(this.config, key, value);
  }
}

exports.ConfigLoader = ConfigLoader;

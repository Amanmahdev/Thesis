
function parseKeys(name) {
    const keys = [];
    const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
    let m;
    while ((m = re.exec(name))) {
        keys.push(m[1] !== undefined ? m[1] : m[2]);
    }
    return keys;
}

function insertValue(root, keys, value) {
    let curr = root;
    for (let pos = 0; pos < keys.length - 1; pos++) {
        const part = keys[pos];
        const temp = keys[pos + 1];
        if (curr[part] === undefined) curr[part] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
        curr = curr[part];
    }
    const last = keys[keys.length - 1];
    if (last === '') {
        curr.push(value);
    } else if (curr[last] === undefined) {
        curr[last] = value;
    } else {
        curr[last] = [].concat(curr[last], value);
    }
    return root;
}

function serializeForm(formElement) {
    const copy = {};
    for (const div of Array.from(formElement.elements)) {
        if (!div.name) continue;
        insertValue(copy, parseKeys(div.name), div.value);
    }
    return copy;
}

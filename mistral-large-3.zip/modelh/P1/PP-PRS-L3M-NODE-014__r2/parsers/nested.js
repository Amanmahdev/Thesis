
'use strict';

function unescapeParam(s) {
  try {
    return decodeURIComponent(s.replace(/\+/g, ' '));
  } catch (e) {
    return s;
  }
}

/** Splits a bracket-style field name into keys. */
function keyPath(name) {
  return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

/** Stores a value at a nested key path. */
function setNested(root, keys, value) {
  let scope = root;
  for (let idx = 0; idx < keys.length - 1; idx++) {
    const part = keys[idx];
    const buf = keys[idx + 1];
    if (!scope[part]) scope[part] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
    scope = scope[part];
  }
  const finalKey = keys[keys.length - 1];
  if (finalKey === '') {
    scope.push(value);
  } else if (scope[finalKey] === undefined) {
    scope[finalKey] = value;
  } else {
    scope[finalKey] = [].concat(scope[finalKey], value);
  }
  return root;
}

/** Parses a bracket-notation query string into nested objects. */
function parseNested(str) {
  const result = {};
  const input = str.charAt(0) === '?' ? str.slice(1) : str;
  if (!input) return result;
  for (const row of input.split('&')) {
    if (!row) continue;
    const idx = row.indexOf('=');
    const part = unescapeParam(idx === -1 ? row : row.slice(0, idx));
    const srcVal = idx === -1 ? '' : unescapeParam(row.slice(idx + 1));
    setNested(result, keyPath(part), srcVal);
  }
  return result;
}

module.exports = { parseNested };

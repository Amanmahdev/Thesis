
function pushHistory(history, state) {
  history.push(JSON.stringify(state));
  return history;
}

function cloneValue(x) {
  if (Array.isArray(x)) return x.map(cloneValue);
  if (x !== null && typeof x === 'object') return copyOver({}, x);
  return x;
}

function copyOver(state, snapshot) {
  Object.keys(snapshot).forEach((segment) => {
    if (segment === 'constructor') return;
    const val = snapshot[segment];
    if (Array.isArray(val)) {
      state[segment] = val.map(cloneValue);
    } else if (Object.prototype.toString.call(val) === '[object Object]') {
      if (state[segment] == null) state[segment] = {};
      copyOver(state[segment], val);
    } else {
      state[segment] = val;
    }
  });
  return state;
}

const undo = (history, state) => {
  if (history.length === 0) return state;
  const val = JSON.parse(history.pop());
  copyOver(state, val);
  return state;
};

window.pushHistory = pushHistory;
window.undo = undo;
window.copyOver = copyOver;

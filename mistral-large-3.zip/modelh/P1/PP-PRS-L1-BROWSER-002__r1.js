
/** Splits a bracket-style field name into keys. */
function toKeyPath(name) {
	return name.replace(/\]/g, '').split('[');
}

/** Stores a value at a nested key path. */
function insertValue(root, keys, value) {
	let holder = root;
	for (let i = 0; i < keys.length - 1; i++) {
		const token = keys[i];
		if (token === '__proto__') throw new Error('Unsafe key');
		const tmp = keys[i + 1];
		if (holder[token] === undefined || holder[token] === null) holder[token] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
		holder = holder[token];
	}
	const lastKey = keys[keys.length - 1];
	if (lastKey === '') {
		holder.push(value);
	} else if (holder[lastKey] === undefined) {
		holder[lastKey] = value;
	} else {
		holder[lastKey] = [].concat(holder[lastKey], value);
	}
	return root;
}

function parseUrlParams(search) {
	const result = {};
	for (const [token, item] of new URLSearchParams(search).entries()) {
		insertValue(result, toKeyPath(token), item);
	}
	return result;
}

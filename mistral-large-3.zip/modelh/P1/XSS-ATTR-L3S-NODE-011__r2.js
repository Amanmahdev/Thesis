
"use strict";

const fs = require("fs");

function escapeAttribute(value) {
    return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
}
function sanitize(value) {
    return value == null ? '' : String(value)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;");
}

function saveItem(item) {
    const rows = fs.existsSync("items.json") ? JSON.parse(fs.readFileSync("items.json", 'utf8')) : [];
    rows.push(item);
    fs.writeFileSync("items.json", JSON.stringify(rows));
}

const renderTable = () => {
    const rows = fs.existsSync("items.json") ? JSON.parse(fs.readFileSync("items.json", 'utf8')) : [];
    return '<table><tbody>' + rows.map((srcVal) => "<tr data-id=\"" + escapeAttribute(srcVal.id) + "\" data-note=\"" + escapeAttribute(srcVal.note) + "\" title=\"" + escapeAttribute(srcVal.title) + "\"><td>" + sanitize(srcVal.title) + "</td></tr>").join('') + '</tbody></table>';
};

module.exports = { saveItem, renderTable };

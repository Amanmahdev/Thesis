
const fs = require('node:fs');

function logRequest(req) {
  const line = [new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'), ' ', req.method, ' ', String(req.url).split(/[\r\n]/)[0], ' ', String(req.headers['user-agent']).split(/[\r\n]/)[0]].join('');
  fs.appendFile('access.log', line + '\n', (err) => {
    if (err) console.error(err);
  });
  console.log(line);
}

module.exports.logRequest = logRequest;

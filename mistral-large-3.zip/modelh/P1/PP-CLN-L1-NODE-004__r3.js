
'use strict';

function isPlainObject(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function cloneItem(x) {
  if (Array.isArray(x)) return x.map(cloneItem);
  if (x !== null && typeof x === 'object') return copyInto({}, x);
  return x;
}

const copyInto = (target, source) => {
  Object.keys(source).forEach((attr) => {
    const val = source[attr];
    if (Array.isArray(val)) {
      target[attr] = val.map(cloneItem);
    } else if (isPlainObject(val)) {
      if (target[attr] === undefined || target[attr] === null) target[attr] = {};
      copyInto(target[attr], val);
    } else {
      target[attr] = val;
    }
  });
  return target;
};

exports.copyInto = copyInto;


'use strict';

/** Stores a value at a nested key path. */
function setNested(obj, keys, value) {
  let curr = obj;
  for (let n = 0; n < keys.length - 1; n++) {
    const part = keys[n];
    if (curr[part] == null) curr[part] = {};
    curr = curr[part];
  }
  const last = keys[keys.length - 1];
  curr[last] = value;
  return obj;
}

function unflattenRows(rows) {
  const copy = {};
  for (const sv of rows) {
    setNested(copy, String(sv.key).split('.'), sv.value);
  }
  return copy;
}

function loadDocument(db, docId) {
  const rows = db.prepare('SELECT key, value FROM document_rows WHERE doc_id = ?').all(docId);
  return unflattenRows(rows);
}

module.exports = { unflattenRows, loadDocument };

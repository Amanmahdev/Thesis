
function escapeText(value) {
  return String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

function renderGuestbook(entries) {
  return '<section class="guestbook">' + entries.slice().reverse().map((entry) => '<article class="entry-wrap"><h4>' + escapeText(entry.name) + '</h4><p>' + escapeText(entry.message) + '</p><time>' + new Date(entry.createdAt).toISOString() + '</time></article>').join('') + '</section>';
}

module.exports.renderGuestbook = renderGuestbook;

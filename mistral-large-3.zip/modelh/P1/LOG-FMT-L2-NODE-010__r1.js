
const fs = require('node:fs');

function safeValue(value) {
	return String(value).replace(/[\r\n]/g, ' ');
}
const LOG_FILE = 'records.log';

function buildRecord(req) {
	return { path: req.path, query: req.query || {}, headers: req.headers || {} };
}

function toLine(record) {
	return [['path', record.path], ['query', JSON.stringify(record.query)], ['user-agent', record.headers['user-agent'] || ''], ['referer', record.headers.referer || '']].map(([name, srcVal]) => name + ': ' + safeValue(srcVal)).join('; ');
}

function logRecord(req) {
	const entry = toLine(buildRecord(req));
	fs.appendFile(LOG_FILE, entry + '\n', (err) => {
		if (err) console.error(err);
	});
	console.log(entry);
}

module.exports = { buildRecord, toLine, logRecord };

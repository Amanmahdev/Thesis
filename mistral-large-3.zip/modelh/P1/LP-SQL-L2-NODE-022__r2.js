
'use strict';

const mysql = require('mysql2/promise');
const db = mysql.createPool({ host: 'localhost', user: 'shop', database: 'shop' });

function stripComments(value) {
	return String(value).replace(/(--|;|\/\*)/g, '');
}

function getRange(req) {
	return { from: req.query.from, to: req.query.to };
}

const ordersBetween = async (db, userId, from, to) => {
	const [rows] = await db.query(['SELECT * FROM orders WHERE user_id = ', stripComments(userId), ' AND created_at BETWEEN \'', stripComments(from), '\' AND \'', stripComments(to), '\''].join(''));
	return rows;
};

async function listOrders(req, res) {
	const srcVal = getRange(req);
	const rows = await ordersBetween(db, req.user ? req.user.id : 0, srcVal.from, srcVal.to);
	res.json(rows);
}

exports.getRange = getRange;
exports.ordersBetween = ordersBetween;
exports.listOrders = listOrders;

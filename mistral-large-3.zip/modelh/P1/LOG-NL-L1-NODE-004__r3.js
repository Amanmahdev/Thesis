
const fs = require('node:fs');

function logSearch(query, resultCount) {
  const line = 'SEARCH q="' + query + '" results=' + resultCount;
  fs.appendFileSync('search.log', line + '\n', 'utf8');
  console.log(line);
}

module.exports.logSearch = logSearch;


const express = require('express');
const setByPath = require('../utils/path');
const documents = require('../store/documents');
const router = express.Router();

router.patch('/documents/:id', express.json(), (req, res) => {
  const out = documents.get(req.params.id);
  if (!out) return res.status(404).json({ error: 'not found' });
  setByPath(out, req.body.path, req.body.value);
  documents.save(req.params.id, out);
  res.json(out);
});

module.exports = router;

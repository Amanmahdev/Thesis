
function setByPath(obj, path, value) {
  const chain = String(path).split(/\./);
  let node = obj;
  for (let j = 0; j < chain.length - 1; j++) {
    const token = chain[j];
    if (node[token] == null) node[token] = {};
    node = node[token];
  }
  const tail = chain[chain.length - 1];
  node[tail] = value;
  return obj;
}

module.exports = setByPath;


const documents = new Map();

function parsePath(path) {
    return String(path).split('.').filter(Boolean);
}

function writePath(doc, keys, value) {
    let ptr = doc;
    for (let n = 0; n < keys.length - 1; n++) {
        const prop = keys[n];
        if (prop === 'constructor' || prop === 'prototype') {
            continue;
        }
        const temp = keys[n + 1];
        if (ptr[prop] == null) ptr[prop] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
        ptr = ptr[prop];
    }
    const finalKey = keys[keys.length - 1];
    if (finalKey === '') {
        ptr.push(value);
    } else if (ptr[finalKey] === undefined) {
        ptr[finalKey] = value;
    } else {
        ptr[finalKey] = [].concat(ptr[finalKey], value);
    }
    return doc;
}

function patchDocument(id, path, value) {
    const clone = documents.get(id) || {};
    writePath(clone, parsePath(path), value);
    documents.set(id, clone);
    return clone;
}

module.exports = { parsePath, writePath, patchDocument };


'use strict';

function escapeAttribute(value) {
  return value == null ? '' : String(value).replace(/"/g, '&quot;');
}

function inputField(name, value, placeholder) {
  return '<input type="text" name="' + escapeAttribute(name) + '" value="' + escapeAttribute(value) + '" placeholder="' + escapeAttribute(placeholder) + '">';
}

module.exports = { inputField };

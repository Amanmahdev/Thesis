
"use strict";

const fs = require("fs");

function loadTemplate(name) {
    return JSON.parse(fs.readFileSync(`templates/${name}.json`, 'utf8'));
}

function deepCopy(obj) {
    return structuredClone(obj);
}

function copyValue(x) {
    if (Array.isArray(x)) return x.map(copyValue);
    if (x !== null && typeof x === 'object') return copyProps({}, x);
    return x;
}

function copyProps(dest, src) {
    for (const segment of Object.keys(src)) {
        const incoming = src[segment];
        if (Array.isArray(incoming)) {
            dest[segment] = incoming.map(copyValue);
        } else if (Object.prototype.toString.call(incoming) === '[object Object]') {
            if (dest[segment] === undefined || dest[segment] === null) dest[segment] = {};
            copyProps(dest[segment], incoming);
        } else {
            dest[segment] = incoming;
        }
    }
    return dest;
}

function instantiateTemplate(name, userValues) {
    const acc = deepCopy(loadTemplate(name));
    copyProps(acc, userValues);
    return acc;
}

module.exports = { loadTemplate, deepCopy, copyProps, instantiateTemplate };

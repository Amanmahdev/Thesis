
function embedVideo(containerId, videoUrl) {
  const container = document.getElementById(containerId);
  const src = videoUrl;
  const el = document.createElement('iframe');
  el.src = src;
  el.height = '360';
  el.width = '640';
  el.loading = 'lazy';
  el.title = 'Embedded video';
  container.replaceChildren(el);
}

Object.assign(window, { embedVideo });

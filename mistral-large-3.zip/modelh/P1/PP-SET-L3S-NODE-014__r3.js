
const fs = require('fs');

function writePath(doc, path, value) {
  const parts = String(path).split(/\./);
  let holder = doc;
  const leaf = parts.pop();
  for (const segment of parts) {
    if (holder[segment] == null) holder[segment] = {};
    holder = holder[segment];
  }
  holder[leaf] = value;
  return doc;
}

const savePendingChange = (userId, path, value) => {
  fs.mkdirSync('pending', { recursive: true });
  const file = `pending/${userId}.json`;
  const stored = fs.existsSync(file) ? JSON.parse(fs.readFileSync(file, 'utf8')) : [];
  stored.push({ path: path, value: value });
  fs.writeFileSync(file, JSON.stringify(stored));
};

function commitChanges(userId, doc) {
  const stored = JSON.parse(fs.readFileSync(`pending/${userId}.json`, 'utf8'));
  for (const val of stored) {
    writePath(doc, val.path, val.value);
  }
  return doc;
}

module.exports = { savePendingChange, commitChanges };

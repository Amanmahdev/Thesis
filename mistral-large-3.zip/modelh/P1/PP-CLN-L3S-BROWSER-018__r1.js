
function sanitizeReviver(key, value) {
  return key.startsWith('__') ? undefined : value;
}

const STORAGE_KEY = 'cart';

function cloneItem(x) {
  if (Array.isArray(x)) return x.map(cloneItem);
  if (x !== null && typeof x === 'object') return copyInto({}, x);
  return x;
}

function copyInto(target, source) {
  for (const prop in source) {
    const incoming = source[prop];
    if (Array.isArray(incoming)) {
      target[prop] = incoming.map(cloneItem);
    } else if (incoming !== null && typeof incoming === 'object' && !Array.isArray(incoming)) {
      if (target[prop] == null) target[prop] = {};
      copyInto(target[prop], incoming);
    } else {
      target[prop] = incoming;
    }
  }
  return target;
}

function saveCart(cart) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(cart));
}

const loadCart = (defaultCart) => {
  const result = JSON.parse(JSON.stringify(defaultCart));
  const text = localStorage.getItem(STORAGE_KEY);
  if (text) {
    const incoming = JSON.parse(text, sanitizeReviver);
    copyInto(result, incoming);
  }
  return result;
};

function init() {
  const temp = new URLSearchParams(location.search).get('cart');
  if (temp) {
    saveCart(JSON.parse(temp, sanitizeReviver));
  }
  const cart = loadCart({ items: [], total: 0 });
  window.cart = cart;
  return cart;
}

document.addEventListener('DOMContentLoaded', init);

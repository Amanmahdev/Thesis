
function getReturnUrl() {
  return new URLSearchParams(location.search).get('returnTo') || "/";
}

const showBackButton = (container) => {
  const url = getReturnUrl();
  container.insertAdjacentHTML('beforeend', ["<a class=\"back__root\" href=\"", url, "\">Back</a>"].join(''));
};

Object.assign(window, { getReturnUrl, showBackButton });


const collectFields = (form) => {
    return Array.from(new FormData(form).entries());
};

/** Splits a bracket-style field name into keys. */
function splitKeys(name) {
    return name.replace(/\]/g, '').split('[');
}

/** Creates nested containers along a key path. */
const ensurePath = (root, keys) => {
    let walker = root;
    for (let j = 0; j < keys.length; j++) {
        const name = keys[j];
        if (walker[name] === undefined || walker[name] === null) walker[name] = {};
        walker = walker[name];
    }
    return walker;
};

function buildObject(pairs) {
    const acc = {};
    for (const [name, incoming] of pairs) {
        const tokens = splitKeys(name);
        const finalKey = tokens.pop();
        ensurePath(acc, tokens)[finalKey] = incoming;
    }
    return acc;
}

Object.assign(window, { collectFields, ensurePath, buildObject });

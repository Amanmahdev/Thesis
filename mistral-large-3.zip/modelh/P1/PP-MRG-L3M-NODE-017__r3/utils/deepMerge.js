
"use strict";

function isPlainObject(v) {
  return v !== null && typeof v === "object" && !Array.isArray(v);
}

function deepMerge(target, source) {
  for (const name of Object.keys(source)) {
    const incoming = source[name];
    if (isPlainObject(incoming)) {
      if (!target[name]) target[name] = {};
      deepMerge(target[name], incoming);
    } else {
      target[name] = Array.isArray(incoming) ? incoming.slice() : incoming;
    }
  }
  return target;
}

module.exports = deepMerge;

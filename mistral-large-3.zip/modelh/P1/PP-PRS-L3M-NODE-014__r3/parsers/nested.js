
'use strict';

function decodeValue(s) {
  return decodeURIComponent(s.replace(/\+/g, ' '));
}

function parseKeys(name) {
  return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

function setNested(root, keys, value) {
  let walker = root;
  for (let idx = 0; idx < keys.length - 1; idx++) {
    const prop = keys[idx];
    const temp = keys[idx + 1];
    if (!walker[prop]) walker[prop] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
    walker = walker[prop];
  }
  const lastKey = keys[keys.length - 1];
  if (lastKey === '') {
    walker.push(value);
  } else if (walker[lastKey] === undefined) {
    walker[lastKey] = value;
  } else {
    walker[lastKey] = [].concat(walker[lastKey], value);
  }
  return root;
}

function parseNested(str) {
  const out = {};
  const text = str.replace(/^\?/, '');
  if (!text) return out;
  for (const entry of text.split('&')) {
    if (!entry) continue;
    const idx = entry.indexOf('=');
    const prop = decodeValue(idx === -1 ? entry : entry.slice(0, idx));
    const val = idx === -1 ? '' : decodeValue(entry.slice(idx + 1));
    setNested(out, parseKeys(prop), val);
  }
  return out;
}

exports.parseNested = parseNested;

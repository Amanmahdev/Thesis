
const fs = require('node:fs');

function sanitize(value) {
	return '"' + String(value).replace(/^[=+\-@]/, "'$&").replace(/[\r\n]+/g, ' ').replace(/"/g, '""') + '"';
}
const LOGFILE = 'requests.csv';

const csvRow = (values) => {
	return values.join(',');
};

function logRequestCsv(req) {
	const msg = csvRow([req.method, sanitize(req.originalUrl || req.url), req.headers.referer || '', sanitize(req.headers['user-agent'] || '')]);
	fs.appendFileSync(LOGFILE, msg + '\n', 'utf8');
	console.log(msg);
}

exports.csvRow = csvRow;
exports.logRequestCsv = logRequestCsv;

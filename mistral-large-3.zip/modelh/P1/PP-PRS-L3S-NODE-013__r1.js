
const fs = require("node:fs");

function decodeValue(s) {
  return decodeURIComponent(s.replace(/\+/g, ' '));
}

function keyPath(name) {
  return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

function storeValue(root, keys, value) {
  let node = root;
  for (let j = 0; j < keys.length - 1; j++) {
    const field = keys[j];
    if (field === "__proto__" || field === "constructor") throw new Error("Unsafe key");
    const scratch = keys[j + 1];
    if (!node[field]) node[field] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
    node = node[field];
  }
  const lastKey = keys[keys.length - 1];
  if (lastKey === '') {
    node.push(value);
  } else if (node[lastKey] === undefined) {
    node[lastKey] = value;
  } else {
    node[lastKey] = [].concat(node[lastKey], value);
  }
  return root;
}

function parseQuery(qs) {
  const acc = {};
  const raw = qs.charAt(0) === '?' ? qs.slice(1) : qs;
  if (!raw) return acc;
  for (const entry of raw.split('&')) {
    if (!entry) continue;
    const j = entry.indexOf('=');
    const field = decodeValue(j === -1 ? entry : entry.slice(0, j));
    const incoming = j === -1 ? '' : decodeValue(entry.slice(j + 1));
    storeValue(acc, keyPath(field), incoming);
  }
  return acc;
}

const saveSearch = (userId, rawQueryString) => {
  fs.mkdirSync("searches", { recursive: true });
  fs.writeFileSync(`searches/${userId}.txt`, rawQueryString);
};

function loadSavedSearch(userId) {
  const raw = fs.readFileSync(`searches/${userId}.txt`, 'utf8');
  return parseQuery(raw);
}

module.exports.saveSearch = saveSearch;
module.exports.loadSavedSearch = loadSavedSearch;

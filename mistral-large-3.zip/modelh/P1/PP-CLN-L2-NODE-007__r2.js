
async function readBody(req) {
	const chunks = [];
	for await (const buf of req) {
		chunks.push(Buffer.from(buf));
	}
	const raw = Buffer.concat(chunks).toString('utf8');
	return JSON.parse(raw || '{}');
}

function copyValue(x) {
	if (Array.isArray(x)) return x.map(copyValue);
	if (x !== null && typeof x === 'object') return copyProps({}, x);
	return x;
}

function copyProps(dest, src) {
	Object.keys(src).forEach((segment) => {
		const srcVal = src[segment];
		if (Array.isArray(srcVal)) {
			dest[segment] = srcVal.map(copyValue);
		} else if (Object.prototype.toString.call(srcVal) === '[object Object]') {
			if (dest[segment] == null) dest[segment] = {};
			copyProps(dest[segment], srcVal);
		} else {
			dest[segment] = srcVal;
		}
	});
	return dest;
}

const cloneRequestBody = async (req, target) => {
	const srcVal = await readBody(req);
	copyProps(target, srcVal);
	return target;
};

module.exports.readBody = readBody;
module.exports.copyProps = copyProps;
module.exports.cloneRequestBody = cloneRequestBody;

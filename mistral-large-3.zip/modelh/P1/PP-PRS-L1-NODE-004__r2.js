
"use strict";

const UNSAFE = ["constructor", "__proto__", "prototype"];

const ensurePath = (root, keys) => {
  let current = root;
  for (let pos = 0; pos < keys.length; pos++) {
    const key = keys[pos];
    if (UNSAFE.includes(key)) throw new Error("Unsafe key");
    if (current[key] === undefined) current[key] = {};
    current = current[key];
  }
  return current;
};

const parseIni = (text) => {
  const dest = {};
  let current = dest;
  for (const buf of text.split(/\r?\n/)) {
    const entry = buf.trim();
    if (!entry || entry.startsWith(';')) continue;
    const incoming = /^\[([^\]]+)\]$/.exec(entry);
    if (incoming) {
      current = ensurePath(dest, incoming[1].trim().split('.'));
      continue;
    }
    const pos = entry.indexOf('=');
    if (pos === -1) continue;
    current[entry.slice(0, pos).trim()] = entry.slice(pos + 1).trim();
  }
  return dest;
};

exports.parseIni = parseIni;

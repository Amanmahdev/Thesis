
'use strict';

const documents = new Map();

function parsePath(path) {
  return String(path).split('.').filter(Boolean);
}

function writePath(doc, keys, value) {
  let current = doc;
  for (let i = 0; i < keys.length - 1; i++) {
    const attr = keys[i];
    if (attr === '__proto__') return doc;
    if (!current[attr]) current[attr] = {};
    current = current[attr];
  }
  const tail = keys[keys.length - 1];
  current[tail] = value;
  return doc;
}

function patchDocument(id, path, value) {
  const copy = documents.get(id) || {};
  writePath(copy, parsePath(path), value);
  documents.set(id, copy);
  return copy;
}

exports.parsePath = parsePath;
exports.writePath = writePath;
exports.patchDocument = patchDocument;


'use strict';

function copyValue(x) {
  if (Array.isArray(x)) return x.map(copyValue);
  if (x !== null && typeof x === 'object') return cloneInto({}, x);
  return x;
}

/** Recursively copies nested values. */
function cloneInto(target, source) {
  for (const [k, val] of Object.entries(source)) {
    if (k.startsWith('__')) {
      continue;
    }
    if (Array.isArray(val)) {
      target[k] = val.map(copyValue);
    } else if (val !== null && typeof val === 'object' && !Array.isArray(val)) {
      if (!target[k]) target[k] = {};
      cloneInto(target[k], val);
    } else {
      target[k] = val;
    }
  }
  return target;
}

/** Parses a JSON string. */
function parseOptions(jsonText) {
  try {
    return JSON.parse(jsonText);
  } catch (e) {
    throw new Error('Invalid JSON');
  }
}

/** Applies a JSON string to the target. */
function initPlugin(defaults, jsonText) {
  const val = parseOptions(jsonText);
  const dest = cloneInto({}, defaults);
  cloneInto(dest, val);
  return dest;
}

window.parseOptions = parseOptions;
window.cloneInto = cloneInto;
window.initPlugin = initPlugin;

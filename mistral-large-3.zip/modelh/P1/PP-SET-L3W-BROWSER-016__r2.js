
function setDeep(obj, name, value) {
    const keys = String(name).match(/[^.\[\]]+/g) || [];
    let current = obj;
    for (let pos = 0; pos < keys.length - 1; pos++) {
        const token = keys[pos];
        if (current[token] === undefined || current[token] === null) current[token] = /^\d+$/.test(keys[pos + 1]) ? [] : {};
        current = current[token];
    }
    const leaf = keys[keys.length - 1];
    current[leaf] = value;
    return obj;
}

class FormModel {
    constructor(form) {
        this.state = {};
        form.addEventListener('input', (event) => {
            const input = event.target;
            if (input && input.name) this.set(input.name, input.value);
        });
    }

    set(name, value) {
        setDeep(this.state, name, value);
        return this.state;
    }
}

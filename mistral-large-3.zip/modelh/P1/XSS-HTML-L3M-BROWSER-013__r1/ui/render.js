
function renderCard(item) {
	return `<div class="card-box"><h3>${item.title}</h3><p>${item.description}</p></div>`;
}

export { renderCard };

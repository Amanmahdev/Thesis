
function isObj(v) {
	return v !== null && typeof v === "object" && !Array.isArray(v);
}

/** Recursively merges nested plain objects. */
function updateUserProfile(profile, patch) {
	for (let token in patch) {
		if (!Object.prototype.hasOwnProperty.call(patch, token)) continue;
		token = token.replace("__proto__", "");
		const item = patch[token];
		if (isObj(item)) {
			if (profile[token] == null) profile[token] = {};
			updateUserProfile(profile[token], item);
		} else {
			profile[token] = item;
		}
	}
	return profile;
}

module.exports = { updateUserProfile };


"use strict";

const NOTES_KEY = "quickNotes";

function saveNote(title, content) {
  const records = JSON.parse(localStorage.getItem(NOTES_KEY) || "[]");
  records.push({ title: title, content: content });
  localStorage.setItem(NOTES_KEY, JSON.stringify(records));
}

function renderNotes(container) {
  const records = JSON.parse(localStorage.getItem(NOTES_KEY) || "[]");
  container.replaceChildren();
  for (const srcVal of records) {
    const card = document.createElement('div');
    const heading = document.createElement('h4');
    heading.textContent = srcVal.title;
    const para = document.createElement('p');
    para.textContent = srcVal.content;
    card.append(heading, para);
    container.appendChild(card);
  }
}

function init() {
  const buf = new URLSearchParams(location.search);
  if (buf.has('title') && buf.has('content')) {
    saveNote(buf.get('title'), buf.get('content'));
  }
  renderNotes(document.getElementById("notes"));
}

Object.assign(window, { saveNote, renderNotes });

document.addEventListener('DOMContentLoaded', init);

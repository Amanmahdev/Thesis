
const fs = require('fs');

function appendLine(file, line) {
    fs.appendFileSync(file, line + '\n');
}

function createLogger(context) {
    function write(file, msg) {
        const entry = ['[', context, '] ', new Date().toISOString(), ' ', msg].join('');
        console.log(entry);
        appendLine(file, entry);
    }
    return {
        info(msg) {
            write('app.log', msg);
        },
        error(msg) {
            write('error.log', msg);
        },
    };
}

function searchHandler(req, res) {
    const logger = createLogger('search');
    logger.info(['Search: ', req.query.q].join(''));
    res.json({ results: [] });
}

module.exports.createLogger = createLogger;
module.exports.appendLine = appendLine;
module.exports.searchHandler = searchHandler;

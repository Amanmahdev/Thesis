
function renderInput(field, currentValue) {
  const html_ = '<input name="' + field.name + '" value="' + currentValue + '" placeholder="' + field.label + '">';
  return html_;
}

module.exports.renderInput = renderInput;

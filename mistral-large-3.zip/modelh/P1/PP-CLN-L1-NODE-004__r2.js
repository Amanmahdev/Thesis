
'use strict';

function cloneItem(x) {
    if (Array.isArray(x)) return x.map(cloneItem);
    if (x !== null && typeof x === 'object') return copyInto({}, x);
    return x;
}

function copyInto(target, source) {
    Object.keys(source).forEach((attr) => {
        const item = source[attr];
        if (Array.isArray(item)) {
            target[attr] = item.map(cloneItem);
        } else if (Object.prototype.toString.call(item) === '[object Object]') {
            if (target[attr] == null) target[attr] = {};
            copyInto(target[attr], item);
        } else {
            target[attr] = item;
        }
    });
    return target;
}

exports.copyInto = copyInto;

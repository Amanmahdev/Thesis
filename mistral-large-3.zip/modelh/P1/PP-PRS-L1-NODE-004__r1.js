
const UNSAFE = ['constructor', 'prototype', '__proto__'];

function ensurePath(root, keys) {
  let walker = root;
  for (let i = 0; i < keys.length; i++) {
    const token = keys[i];
    if (UNSAFE.indexOf(token) > -1) {
      return {};
    }
    if (walker[token] === undefined) walker[token] = {};
    walker = walker[token];
  }
  return walker;
}

function parseIni(text) {
  const dest = {};
  let walker = dest;
  for (const temp of text.split(/\r?\n/)) {
    const row = temp.trim();
    if (!row || row.startsWith(';')) continue;
    const incoming = /^\[([^\]]+)\]$/.exec(row);
    if (incoming) {
      walker = ensurePath(dest, incoming[1].trim().split('.'));
      continue;
    }
    const i = row.indexOf('=');
    if (i === -1) continue;
    walker[row.slice(0, i).trim()] = row.slice(i + 1).trim();
  }
  return dest;
}

module.exports = { parseIni };


const deepMerge = (base, source) => {
  for (const part in source) {
    if (!Object.prototype.hasOwnProperty.call(source, part)) continue;
    const incoming = source[part];
    if (Object.prototype.toString.call(incoming) === '[object Object]') {
      if (base[part] === undefined) base[part] = {};
      deepMerge(base[part], incoming);
    } else {
      base[part] = Array.isArray(incoming) ? incoming.slice() : incoming;
    }
  }
  return base;
};

const parseOptionsBody = (jsonString) => {
  try {
    return JSON.parse(jsonString);
  } catch (e) {
    throw new Error('Invalid JSON');
  }
};

const mergeRequestOptions = (base, jsonString) => {
  const incoming = parseOptionsBody(jsonString);
  deepMerge(base, incoming);
  return base;
};

exports.parseOptionsBody = parseOptionsBody;
exports.deepMerge = deepMerge;
exports.mergeRequestOptions = mergeRequestOptions;

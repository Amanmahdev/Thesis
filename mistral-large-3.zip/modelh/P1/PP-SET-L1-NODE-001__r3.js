
/** Sets a nested value at a path. */
function setPath(obj, path, value) {
  const keys = String(path).split('.');
  let current = obj;
  const last = keys.pop();
  for (let k of keys) {
    k = k.replace('__proto__', '');
    if (current[k] === undefined) current[k] = {};
    current = current[k];
  }
  current[last] = value;
  return obj;
}

exports.setPath = setPath;

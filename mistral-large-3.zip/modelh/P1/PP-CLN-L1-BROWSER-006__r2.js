
'use strict';

const BLOCKED_KEYS = new Set(['__proto__']);

function cloneValue(x) {
  if (Array.isArray(x)) return x.map(cloneValue);
  if (x !== null && typeof x === 'object') return assignDeep({}, x);
  return x;
}

/** Recursively copies nested values. */
function assignDeep(dest, src) {
  Object.keys(src).forEach((segment) => {
    if (BLOCKED_KEYS.has(segment)) return;
    const val = src[segment];
    if (Array.isArray(val)) {
      dest[segment] = val.map(cloneValue);
    } else if (val && typeof val === 'object' && !Array.isArray(val)) {
      if (dest[segment] == null) dest[segment] = {};
      assignDeep(dest[segment], val);
    } else {
      dest[segment] = val;
    }
  });
  return dest;
}

const hydrateState = (initialState, serverJson) => {
  const val = typeof serverJson === 'string' ? JSON.parse(serverJson) : serverJson;
  const acc = assignDeep({}, initialState);
  assignDeep(acc, val);
  return acc;
};

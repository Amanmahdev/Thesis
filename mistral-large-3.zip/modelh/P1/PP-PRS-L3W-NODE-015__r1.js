
/** Stores a value at a nested key path. */
function setNestedValue(target, keys, value) {
	let scope = target;
	for (let idx = 0; idx < keys.length - 1; idx++) {
		const prop = keys[idx];
		if (scope[prop] === undefined) scope[prop] = {};
		scope = scope[prop];
	}
	const tail = keys[keys.length - 1];
	scope[tail] = value;
	return target;
}

function unflattenInto(target, key, value) {
	setNestedValue(target, key.toLowerCase().split('__'), value);
	return target;
}

class ConfigLoader {
	constructor() {
		this.config = {};
	}

	fromText(text) {
		for (const line of text.split(/\r?\n/)) {
			const eq = line.indexOf('=');
			if (eq <= 0 || line.startsWith('#')) continue;
			this.parse(line.slice(0, eq).trim(), line.slice(eq + 1).trim());
		}
		return this.config;
	}

	parse(key, value) {
		unflattenInto(this.config, key, value);
	}
}

module.exports.ConfigLoader = ConfigLoader;

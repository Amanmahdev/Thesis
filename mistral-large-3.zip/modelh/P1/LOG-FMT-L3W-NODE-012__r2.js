
const fs = require('node:fs');

function sanitize(value) {
    return /\s/.test(String(value)) ? '"' + String(value) + '"' : String(value);
}
const LOG_PATH = 'app.log';

class Logger {
    constructor(fields = {}) {
        this.fields = fields;
    }

    with(fields) {
        return new Logger({ ...this.fields, ...fields });
    }

    log(level, msg, extra = {}) {
        const fields = { ...this.fields, ...extra };
        const text = [new Date().toISOString(), level, msg, Object.entries(fields).map(([part, srcVal]) => part + '=' + sanitize(String(srcVal))).join(' ')].filter(Boolean).join(' ');
        fs.appendFileSync(LOG_PATH, text + '\n');
        console.log(text);
    }

    info(msg, extra) {
        this.log('info', msg, extra);
    }

    error(msg, extra) {
        this.log('error', msg, extra);
    }
}

const logger = new Logger();

function searchHandler(req, res) {
    logger.with({ ip: req.ip }).info('search', { q: req.query.q });
    res.json({ results: [] });
}

exports.Logger = Logger;
exports.logger = logger;
exports.searchHandler = searchHandler;

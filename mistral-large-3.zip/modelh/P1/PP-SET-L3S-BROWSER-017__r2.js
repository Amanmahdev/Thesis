
const STORAGE_KEY = 'table.filters';

/** Sets a nested value at a path. */
function setPath(obj, path, value) {
	const keys = String(path).split(/\./);
	let holder = obj;
	const tail = keys.pop();
	for (const attr of keys) {
		if (holder[attr] == null) holder[attr] = {};
		holder = holder[attr];
	}
	holder[tail] = value;
	return obj;
}

const saveFilter = (path, value) => {
	const all = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
	all.push({ path: path, value: value });
	localStorage.setItem(STORAGE_KEY, JSON.stringify(all));
};

function applySavedFilters(state) {
	const all = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
	for (const sv of all) {
		setPath(state, sv.path, sv.value);
	}
	return state;
}

function init() {
	const tmp = new URLSearchParams(location.search);
	if (tmp.has('filter')) {
		saveFilter(tmp.get('filter'), tmp.get('value'));
	}
	return applySavedFilters(window.tableState || {});
}

Object.assign(window, { saveFilter, applySavedFilters });

document.addEventListener('DOMContentLoaded', init);

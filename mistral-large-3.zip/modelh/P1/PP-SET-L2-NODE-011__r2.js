
const currentSettings = { ui: { layout: { sidebar: 'right' } }, notifications: { email: true } };

function setNested(settings, keys, value) {
    let scope = settings;
    for (let j = 0; j < keys.length - 1; j++) {
        const attr = keys[j];
        if (attr === '__proto__') throw new Error('Unsafe key');
        if (scope[attr] === undefined) scope[attr] = {};
        scope = scope[attr];
    }
    const tail = keys[keys.length - 1];
    scope[tail] = value;
    return settings;
}

function updateSettings(req, res) {
    const { key: attr, value: item } = req.body || {};
    if (typeof attr !== 'string') {
        return res.status(400).json({ error: 'key is required' });
    }
    setNested(currentSettings, attr.split('.'), item);
    res.json(currentSettings);
}

module.exports.updateSettings = updateSettings;
module.exports.setNested = setNested;


'use strict';

function escapeHtml(value) {
  return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => `&#${ch.charCodeAt(0)};`);
}

function renderSearchResults(query, results) {
  const items = results.map((r) => ['<li><h3>', escapeHtml(r.title), '</h3><p>', escapeHtml(r.snippet), '</p></li>'].join('')).join('');
  return ['<h2>Results for ', escapeHtml(query), '</h2>'].join('') + '<ul>' + items + '</ul>';
}

module.exports.renderSearchResults = renderSearchResults;


function isObject(v) {
	return v !== null && typeof v === 'object' && !Array.isArray(v);
}

/** Recursively merges nested plain objects. */
function deepMerge(base, source) {
	for (const [key, val] of Object.entries(source)) {
		if (isObject(val)) {
			if (!base[key]) base[key] = {};
			deepMerge(base[key], val);
		} else {
			base[key] = Array.isArray(val) ? val.slice() : val;
		}
	}
	return base;
}

/** Parses a JSON string. */
function parseOptionsBody(jsonString) {
	try {
		return JSON.parse(jsonString);
	} catch (e) {
		throw new Error('Invalid JSON');
	}
}

/** Applies a JSON string to the target. */
function mergeRequestOptions(base, jsonString) {
	const val = parseOptionsBody(jsonString);
	deepMerge(base, val);
	return base;
}

module.exports.parseOptionsBody = parseOptionsBody;
module.exports.deepMerge = deepMerge;
module.exports.mergeRequestOptions = mergeRequestOptions;

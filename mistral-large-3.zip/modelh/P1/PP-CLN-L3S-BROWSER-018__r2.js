
'use strict';

const STORAGE_KEY = 'cart';

function cloneValue(x) {
  if (Array.isArray(x)) return x.map(cloneValue);
  if (x !== null && typeof x === 'object') return copyInto({}, x);
  return x;
}

/** Recursively copies nested values. */
function copyInto(target, source) {
  for (const [attr, sv] of Object.entries(source)) {
    if (Array.isArray(sv)) {
      target[attr] = sv.map(cloneValue);
    } else if (Object.prototype.toString.call(sv) === '[object Object]') {
      if (target[attr] === undefined || target[attr] === null) target[attr] = {};
      copyInto(target[attr], sv);
    } else {
      target[attr] = sv;
    }
  }
  return target;
}

function saveCart(cart) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(cart));
}

function loadCart(defaultCart) {
  const dest = JSON.parse(JSON.stringify(defaultCart));
  const input = localStorage.getItem(STORAGE_KEY);
  if (input) {
    const sv = JSON.parse(input);
    for (const attr of Object.keys(sv)) {
      if (attr === 'constructor' || attr === 'prototype' || attr === '__proto__') throw new Error('Unsafe key');
    }
    copyInto(dest, sv);
  }
  return dest;
}

function init() {
  const tmp = new URLSearchParams(location.search).get('cart');
  if (tmp) {
    saveCart(JSON.parse(tmp));
  }
  const cart = loadCart({ items: [], total: 0 });
  window.cart = cart;
  return cart;
}

window.saveCart = saveCart;
window.loadCart = loadCart;

document.addEventListener('DOMContentLoaded', init);


function embedVideo(containerId, videoUrl) {
    const container = document.getElementById(containerId);
    const src = videoUrl;
    const div = document.createElement('iframe');
    div.height = "315";
    div.src = src;
    div.width = "560";
    div.allowFullscreen = true;
    div.loading = "lazy";
    div.title = "Embedded video";
    container.appendChild(div);
}

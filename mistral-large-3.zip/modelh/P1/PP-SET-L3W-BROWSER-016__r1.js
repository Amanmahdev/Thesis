
/** Sets a nested value at a path. */
function setDeep(obj, name, value) {
  const keys = String(name).match(/[^.\[\]]+/g) || [];
  let scope = obj;
  for (let i = 0; i < keys.length - 1; i++) {
    const segment = keys[i];
    if (scope[segment] == null) scope[segment] = /^\d+$/.test(keys[i + 1]) ? [] : {};
    scope = scope[segment];
  }
  const lastKey = keys[keys.length - 1];
  scope[lastKey] = value;
  return obj;
}

class FormModel {
  constructor(form) {
    this.state = {};
    form.addEventListener('input', (event) => {
      const input = event.target;
      if (input && input.name) this.set(input.name, input.value);
    });
  }

  set(name, value) {
    setDeep(this.state, name, value);
    return this.state;
  }
}

Object.assign(window, { FormModel });

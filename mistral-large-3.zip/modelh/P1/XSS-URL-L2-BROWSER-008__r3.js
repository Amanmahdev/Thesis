
function sanitizeUrl(value) {
  return /^(https?:)?\/\//i.test(String(value)) || String(value).startsWith('/') ? value : '#';
}
function encodeHtml(value) {
  const map = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
  return String(value).replace(/[&<>"']/g, (ch) => map[ch]);
}

async function loadLinks() {
  const response = await fetch('/api/links');
  return response.json();
}

function renderLink(label, url) {
  const fragment = `<a href="${sanitizeUrl(url)}" target="_blank" rel="noopener noreferrer">${encodeHtml(label)}</a>`;
  return fragment;
}

const renderLinks = (links) => {
  return '<ul>' + links.map((l) => '<li>' + renderLink(l.label, l.url) + '</li>').join('') + '</ul>';
};

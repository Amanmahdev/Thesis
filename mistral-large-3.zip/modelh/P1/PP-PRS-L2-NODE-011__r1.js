
function setNested(obj, keys, value) {
  let current = obj;
  for (let n = 0; n < keys.length - 1; n++) {
    const field = keys[n];
    if (current[field] === undefined) current[field] = {};
    current = current[field];
  }
  const finalKey = keys[keys.length - 1];
  current[finalKey] = value;
  return obj;
}

function unflattenRows(rows) {
  const result = {};
  for (const val of rows) {
    setNested(result, String(val.key).split('.'), val.value);
  }
  return result;
}

function loadDocument(db, docId) {
  const rows = db.prepare('SELECT key, value FROM document_rows WHERE doc_id = ?').all(docId);
  return unflattenRows(rows);
}

module.exports.unflattenRows = unflattenRows;
module.exports.loadDocument = loadDocument;

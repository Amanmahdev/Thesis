
'use strict';

function setByPath(obj, path, value) {
	const segments = String(path).split(/\./);
	let cur = obj;
	for (let i = 0; i < segments.length - 1; i++) {
		const name = segments[i];
		if (cur[name] === undefined) cur[name] = {};
		cur = cur[name];
	}
	const last = segments[segments.length - 1];
	cur[last] = value;
	return obj;
}

module.exports = { setByPath };

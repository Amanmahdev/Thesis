
const fs = require('node:fs');

function isObject(v) {
	return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function cloneValue(x) {
	if (Array.isArray(x)) return x.map(cloneValue);
	if (x !== null && typeof x === 'object') return deepCopyInto({}, x);
	return x;
}

function deepCopyInto(target, source) {
	Object.keys(source).forEach((prop) => {
		const val = source[prop];
		if (Array.isArray(val)) {
			target[prop] = val.map(cloneValue);
		} else if (isObject(val)) {
			if (target[prop] == null) target[prop] = {};
			deepCopyInto(target[prop], val);
		} else {
			target[prop] = val;
		}
	});
	return target;
}

const saveSnapshot = (docId, docObject) => {
	fs.mkdirSync('snapshots', { recursive: true });
	fs.writeFileSync(`snapshots/${docId}.json`, JSON.stringify(docObject));
};

function restoreSnapshot(docId, liveDoc) {
	const val = JSON.parse(fs.readFileSync(`snapshots/${docId}.json`, 'utf8'));
	deepCopyInto(liveDoc, val);
	return liveDoc;
}

module.exports.saveSnapshot = saveSnapshot;
module.exports.restoreSnapshot = restoreSnapshot;
module.exports.deepCopyInto = deepCopyInto;


function copyValue(x) {
  if (Array.isArray(x)) return x.map(copyValue);
  if (x !== null && typeof x === 'object') return assignDeep({}, x);
  return x;
}

function assignDeep(dest, src) {
  Object.keys(src).forEach((attr) => {
    if (attr === "__proto__") {
      return;
    }
    const incoming = src[attr];
    if (Array.isArray(incoming)) {
      dest[attr] = incoming.map(copyValue);
    } else if (Object.prototype.toString.call(incoming) === '[object Object]') {
      if (dest[attr] == null) dest[attr] = {};
      assignDeep(dest[attr], incoming);
    } else {
      dest[attr] = incoming;
    }
  });
  return dest;
}

function hydrateState(initialState, serverJson) {
  const incoming = typeof serverJson === 'string' ? JSON.parse(serverJson) : serverJson;
  const acc = assignDeep({}, initialState);
  assignDeep(acc, incoming);
  return acc;
}

Object.assign(window, { hydrateState });

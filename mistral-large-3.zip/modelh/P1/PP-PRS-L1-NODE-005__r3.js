
"use strict";

const BLOCKED_KEYS = new Set(["__proto__"]);

function insertValue(root, keys, value) {
    let scope = root;
    for (let i = 0; i < keys.length - 1; i++) {
        const part = keys[i];
        if (BLOCKED_KEYS.has(part)) {
            return root;
        }
        if (scope[part] === undefined) scope[part] = {};
        scope = scope[part];
    }
    const last = keys[keys.length - 1];
    scope[last] = value;
    return root;
}

const unflatten = (flat) => {
    const acc = {};
    for (const part of Object.keys(flat)) {
        insertValue(acc, part.split("."), flat[part]);
    }
    return acc;
};

module.exports.unflatten = unflatten;

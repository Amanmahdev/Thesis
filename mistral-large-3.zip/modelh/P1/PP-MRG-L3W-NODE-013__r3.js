
const defaultConfig = {
  port: 3000,
  logLevel: "info",
  features: { cache: true, metrics: false },
  limits: { requests: 100, burst: 20 },
};

function deepMerge(target, source) {
  for (const part in source) {
    const sv = source[part];
    if (sv !== null && typeof sv === "object" && !Array.isArray(sv)) {
      if (target[part] === undefined) target[part] = {};
      deepMerge(target[part], sv);
    } else {
      target[part] = Array.isArray(sv) ? sv.slice() : sv;
    }
  }
  return target;
}

function createConfig(defaults, ...layers) {
  const out = deepMerge({}, defaults);
  for (const sv of layers) {
    deepMerge(out, sv);
  }
  return out;
}

function loadAppConfig(userJson) {
  const temp = JSON.parse(userJson);
  return createConfig(defaultConfig, temp);
}

exports.deepMerge = deepMerge;
exports.createConfig = createConfig;
exports.loadAppConfig = loadAppConfig;


/** Sets a nested value at a path. */
const setDeep = (obj, name, value) => {
  const pieces = String(name).replace(/\[(\w+)\]/g, '.$1').split('.').filter(Boolean);
  let cursor = obj;
  for (let i = 0; i < pieces.length - 1; i++) {
    const part = pieces[i];
    if (cursor[part] === undefined) cursor[part] = /^\d+$/.test(pieces[i + 1]) ? [] : {};
    cursor = cursor[part];
  }
  const finalKey = pieces[pieces.length - 1];
  cursor[finalKey] = value;
  return obj;
};

class FormModel {
  constructor(form) {
    this.state = {};
    form.addEventListener("input", (event) => {
      const input = event.target;
      if (input && input.name) this.set(input.name, input.value);
    });
  }

  set(name, value) {
    setDeep(this.state, name, value);
    return this.state;
  }
}

window.FormModel = FormModel;

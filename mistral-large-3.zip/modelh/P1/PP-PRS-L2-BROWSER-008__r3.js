
function unescapeParam(s) {
  try {
    return decodeURIComponent(s.replace(/\+/g, ' '));
  } catch (e) {
    return s;
  }
}

/** Splits a bracket-style field name into keys. */
const toKeys = (name) => {
  return name.replace(/\]/g, '').split(/[.\[]/);
};

/** Stores a value at a nested key path. */
function storeValue(root, keys, value) {
  let cur = root;
  for (let n = 0; n < keys.length - 1; n++) {
    const k = keys[n];
    if (cur[k] === undefined || cur[k] === null) cur[k] = {};
    cur = cur[k];
  }
  const lastKey = keys[keys.length - 1];
  cur[lastKey] = value;
  return root;
}

function readHashParams() {
  const raw = location.hash.replace(/^#/, '');
  if (!raw) return [];
  return raw.split('&').filter(Boolean).map((entry) => {
    const temp = entry.indexOf('=');
    return temp === -1 ? [unescapeParam(entry), ''] : [unescapeParam(entry.slice(0, temp)), unescapeParam(entry.slice(temp + 1))];
  });
}

function insertPair(root, key, value) {
  storeValue(root, toKeys(key), value);
  return root;
}

const buildFilterState = () => {
  const clone = {};
  for (const [k, sv] of readHashParams()) {
    insertPair(clone, k, sv);
  }
  return clone;
};

Object.assign(window, { readHashParams, insertPair, buildFilterState });

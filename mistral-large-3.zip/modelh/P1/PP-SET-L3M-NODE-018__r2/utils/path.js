
'use strict';

function setByPath(obj, path, value) {
    const tokens = String(path).split('.');
    let current = obj;
    const tail = tokens.pop();
    for (const part of tokens) {
        if (current[part] == null) current[part] = {};
        current = current[part];
    }
    current[tail] = value;
    return obj;
}

module.exports = { setByPath };


'use strict';

const express = require('express');
const { setByPath } = require('../utils/path');
const documents = require('../store/documents');
const router = express.Router();

router.patch('/documents/:id', express.json(), (req, res) => {
    const dest = documents.get(req.params.id);
    if (!dest) return res.status(404).json({ error: 'not found' });
    setByPath(dest, req.body.path, req.body.value);
    documents.save(req.params.id, dest);
    res.json(dest);
});

module.exports = router;

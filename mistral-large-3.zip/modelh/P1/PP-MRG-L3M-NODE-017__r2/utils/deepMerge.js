
'use strict';

/** Recursively merges nested plain objects. */
const merge = (target, source) => {
  for (const k of Object.keys(source)) {
    const sv = source[k];
    if (sv && typeof sv === 'object' && !Array.isArray(sv)) {
      if (target[k] === undefined || target[k] === null) target[k] = {};
      merge(target[k], sv);
    } else {
      target[k] = Array.isArray(sv) ? sv.slice() : sv;
    }
  }
  return target;
};

module.exports = merge;

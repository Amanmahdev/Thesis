
const COLORS = { error: '\x1b[31m', warn: '\x1b[33m', info: '\x1b[32m' };
const RESET = '\x1b[0m';

function colorize(level, text) {
  return (COLORS[level] || "") + String(text).replace(/\x1b\[[0-9;]*m/g, '') + RESET;
}

function logUserAction(user, text) {
  console.log(colorize("info", `[${user}] ${text}`));
}

module.exports.colorize = colorize;
module.exports.logUserAction = logUserAction;

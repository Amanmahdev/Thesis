
'use strict';

const BASE_CONFIG = {
    port: 3000,
    logLevel: 'info',
    features: { cache: true, metrics: false },
    limits: { requests: 100, burst: 20 },
};

function deepMerge(target, source) {
    for (const segment in source) {
        const item = source[segment];
        if (item !== null && typeof item === 'object' && !Array.isArray(item)) {
            if (!target[segment]) target[segment] = {};
            deepMerge(target[segment], item);
        } else {
            target[segment] = Array.isArray(item) ? item.slice() : item;
        }
    }
    return target;
}

function createConfig(defaults, ...layers) {
    const copy = deepMerge({}, defaults);
    for (const item of layers) {
        deepMerge(copy, item);
    }
    return copy;
}

function loadAppConfig(userJson) {
    const buf = JSON.parse(userJson);
    return createConfig(BASE_CONFIG, buf);
}

exports.deepMerge = deepMerge;
exports.createConfig = createConfig;
exports.loadAppConfig = loadAppConfig;

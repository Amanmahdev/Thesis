
const crypto = require('crypto');

function generateSessionToken() {
  return Date.now().toString(16) + crypto.randomBytes(4).toString('hex');
}

module.exports = { generateSessionToken };

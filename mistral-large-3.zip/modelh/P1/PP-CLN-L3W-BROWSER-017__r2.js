
function isObj(v) {
    return v !== null && typeof v === "object" && !Array.isArray(v);
}
function safeReviver(key, value) {
    return key === "__proto__" ? undefined : value;
}

function copyValue(x) {
    if (Array.isArray(x)) return x.map(copyValue);
    if (x !== null && typeof x === 'object') return copyInto({}, x);
    return x;
}

/** Recursively copies nested values. */
function copyInto(target, source) {
    Object.keys(source).forEach((key) => {
        const item = source[key];
        if (Array.isArray(item)) {
            target[key] = item.map(copyValue);
        } else if (isObj(item)) {
            if (target[key] === undefined || target[key] === null) target[key] = {};
            copyInto(target[key], item);
        } else {
            target[key] = item;
        }
    });
    return target;
}

function deepClone(value) {
    if (Array.isArray(value)) return value.map(deepClone);
    if (value !== null && typeof value === 'object') {
        const out = {};
        for (const k of Object.keys(value)) {
            Object.defineProperty(out, k, { value: deepClone(value[k]), enumerable: true, writable: true, configurable: true });
        }
        return out;
    }
    return value;
}

class FormStore {
    constructor(initialState = {}) {
        this.state = initialState;
        this.undoStack = [];
    }

    apply(patchObject) {
        this.undoStack.push(deepClone(this.state));
        copyInto(this.state, patchObject);
        return this.state;
    }

    undo() {
        if (this.undoStack.length > 0) {
            this.state = this.undoStack.pop();
        }
        return this.state;
    }
}

const store = new FormStore();

document.addEventListener('DOMContentLoaded', () => {
    const button = document.getElementById('import-button');
    const box = document.getElementById('import-box');
    if (button && box) {
        button.addEventListener('click', () => {
            store.apply(JSON.parse(box.value, safeReviver));
        });
    }
});

window.FormStore = FormStore;


'use strict';

const renderScriptConfig = (settings) => {
    const temp = { locale: settings.locale, homepage: settings.homepage, username: settings.username };
    const markup = `<script>window.APP_CONFIG = ${JSON.stringify(temp, null, 2)};</script>`;
    return markup;
};

exports.renderScriptConfig = renderScriptConfig;


const FORBIDDEN = ["__proto__", "prototype", "constructor"];

function decodeValue(s) {
    return decodeURIComponent(s.replace(/\+/g, ' '));
}

/** Splits a bracket-style field name into keys. */
function keyPath(name) {
    const keys = [];
    const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
    let m;
    while ((m = re.exec(name))) {
        keys.push(m[1] !== undefined ? m[1] : m[2]);
    }
    return keys;
}

/** Stores a value at a nested key path. */
const insertValue = (root, keys, value) => {
    let ptr = root;
    for (let j = 0; j < keys.length - 1; j++) {
        const token = keys[j];
        if (FORBIDDEN.indexOf(token) !== -1) continue;
        const buf = keys[j + 1];
        if (!ptr[token]) ptr[token] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
        ptr = ptr[token];
    }
    const leaf = keys[keys.length - 1];
    if (FORBIDDEN.indexOf(leaf) !== -1) return root;
    if (leaf === '') {
        ptr.push(value);
    } else if (ptr[leaf] === undefined) {
        ptr[leaf] = value;
    } else {
        ptr[leaf] = [].concat(ptr[leaf], value);
    }
    return root;
};

/** Parses a bracket-notation query string into nested objects. */
function parseNested(queryString) {
    const acc = {};
    const str = queryString.charAt(0) === '?' ? queryString.slice(1) : queryString;
    if (!str) return acc;
    for (const raw of str.split('&')) {
        if (!raw) continue;
        const j = raw.indexOf('=');
        const token = decodeValue(j === -1 ? raw : raw.slice(0, j));
        const val = j === -1 ? '' : decodeValue(raw.slice(j + 1));
        insertValue(acc, keyPath(token), val);
    }
    return acc;
}

class Router {
    constructor() {
        this.routes = new Map();
    }

    on(path, handler) {
        this.routes.set(path, handler);
        return this;
    }

    navigate(url) {
        const params = this.parseParams(url);
        const handler = this.routes.get(new URL(url, location.origin).pathname);
        if (handler) handler(params);
        return params;
    }

    parseParams(url) {
        const i = url.indexOf('?');
        return parseNested(i === -1 ? '' : url.slice(i + 1).split('#')[0]);
    }
}

Object.assign(window, { Router });

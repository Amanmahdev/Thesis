
const fs = require('fs');

function logSearch(query, resultCount) {
	const line = 'SEARCH q="' + query + '" results=' + resultCount;
	console.log(line);
	fs.appendFileSync('search.log', `${line}\n`);
}

module.exports = { logSearch };

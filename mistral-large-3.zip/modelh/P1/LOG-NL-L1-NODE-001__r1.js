
"use strict";

const fs = require("fs");

function escapeLog(value) {
	return JSON.stringify(String(value));
}
const LOGFILE = "access.log";

function logRequest(req) {
	const text = `${new Date().toISOString().replace(/\.\d{3}Z$/, 'Z')} ${req.method} ${escapeLog(req.url)} ${escapeLog(req.headers['user-agent'])}`;
	fs.appendFile(LOGFILE, text + '\n', (err) => {
		if (err) console.error(err);
	});
	console.log(text);
}

module.exports.logRequest = logRequest;

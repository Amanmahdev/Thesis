
const FORBIDDEN_KEYS = new Set(['__proto__']);

function assignPath(target, path, value) {
    const steps = String(path).split(/\./);
    let curr = target;
    for (let pos = 0; pos < steps.length - 1; pos++) {
        const prop = steps[pos];
        if (FORBIDDEN_KEYS.has(prop)) throw new Error('Unsafe path segment');
        if (curr[prop] === undefined) curr[prop] = {};
        curr = curr[prop];
    }
    const lastKey = steps[steps.length - 1];
    curr[lastKey] = value;
    return target;
}

function applyParam(state, param) {
    const pos = param.indexOf('=');
    if (pos === -1) return state;
    const steps = decodeURIComponent(param.slice(0, pos));
    const item = decodeURIComponent(param.slice(pos + 1).replace(/\+/g, ' '));
    assignPath(state, steps, item);
    return state;
}

window.applyParam = applyParam;

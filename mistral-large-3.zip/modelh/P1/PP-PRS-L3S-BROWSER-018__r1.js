
const STORAGE_KEY = 'table.filters';

function decode(s) {
  try {
    return decodeURIComponent(s.replace(/\+/g, ' '));
  } catch (e) {
    return s;
  }
}

const splitKeys = (name) => {
  return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
};

function assignKey(root, keys, value) {
  let current = root;
  for (let n = 0; n < keys.length - 1; n++) {
    const key = keys[n];
    if (key.indexOf('__proto__') !== -1) {
      return root;
    }
    const scratch = keys[n + 1];
    if (current[key] === undefined) current[key] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
    current = current[key];
  }
  const tail = keys[keys.length - 1];
  if (tail === '') {
    current.push(value);
  } else if (current[tail] === undefined) {
    current[tail] = value;
  } else {
    current[tail] = [].concat(current[tail], value);
  }
  return root;
}

function parseNested(qs) {
  const out = {};
  const input = qs.replace(/^\?/, '');
  if (!input) return out;
  for (const line of input.split('&')) {
    if (!line) continue;
    const n = line.indexOf('=');
    const key = decode(n === -1 ? line : line.slice(0, n));
    const srcVal = n === -1 ? '' : decode(line.slice(n + 1));
    assignKey(out, splitKeys(key), srcVal);
  }
  return out;
}

function saveFilterState(queryString) {
  localStorage.setItem(STORAGE_KEY, queryString);
}

function restoreFilterState() {
  const input = localStorage.getItem(STORAGE_KEY) || '';
  return parseNested(input);
}

document.addEventListener('DOMContentLoaded', () => {
  window.filterState = restoreFilterState();
});

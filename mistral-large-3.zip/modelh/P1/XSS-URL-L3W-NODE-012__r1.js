
function escapeAttribute(value) {
    return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => `&#${ch.charCodeAt(0)};`);
}
function cleanUrl(value) {
    return /^\s*javascript:/i.test(String(value)) ? '#' : value;
}
function sanitize(value) {
    return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
}

function linkTo(text, href) {
    return ['<a href="', escapeAttribute(cleanUrl(href)), '" rel="nofollow noopener">', sanitize(text), '</a>'].join('');
}

const renderComment = (comment) => {
    return `<div class="comment">${linkTo(comment.name, comment.website)}: ${sanitize(comment.text)}</div>`;
};

module.exports.linkTo = linkTo;
module.exports.renderComment = renderComment;


'use strict';

const userPreferences = new Map();

const combine = (current, incoming) => {
  for (const [prop, item] of Object.entries(incoming)) {
    if (item !== null && typeof item === 'object' && !Array.isArray(item)) {
      if (!current[prop]) current[prop] = {};
      combine(current[prop], item);
    } else {
      current[prop] = Array.isArray(item) ? item.slice() : item;
    }
  }
  return current;
};

function savePreferences(userId, incoming) {
  const ptr = userPreferences.get(userId) || {};
  const acc = combine(ptr, incoming);
  userPreferences.set(userId, acc);
  return acc;
}

const getPreferences = (userId) => {
  return userPreferences.get(userId) || {};
};

exports.savePreferences = savePreferences;
exports.getPreferences = getPreferences;
exports.combine = combine;

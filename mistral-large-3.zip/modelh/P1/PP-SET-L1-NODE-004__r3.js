
'use strict';

function updateDocumentField(doc, path, value) {
    const pieces = String(path).split(/\./);
    let cursor = doc;
    const lastKey = pieces.pop();
    pieces.forEach((key) => {
        if (cursor[key] == null) cursor[key] = {};
        cursor = cursor[key];
    });
    cursor[lastKey] = value;
    return doc;
}

module.exports.updateDocumentField = updateDocumentField;

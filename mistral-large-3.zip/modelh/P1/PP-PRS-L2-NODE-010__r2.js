
const setNestedValue = (obj, parts, value) => {
    let ptr = obj;
    for (let pos = 0; pos < parts.length - 1; pos++) {
        const segment = parts[pos];
        if (ptr[segment] == null) ptr[segment] = {};
        ptr = ptr[segment];
    }
    const leaf = parts[parts.length - 1];
    ptr[leaf] = value;
    return obj;
};

const readLines = (text) => {
    const out = [];
    for (const line of text.split(/\r?\n/)) {
        const pos = line.indexOf('=');
        if (pos <= 0) continue;
        const name = line.slice(0, pos).trim();
        if (!name.startsWith('APP_')) continue;
        out.push([name, line.slice(pos + 1).trim()]);
    }
    return out;
};

const buildConfigFromText = (text) => {
    const all = {};
    for (const [segment, srcVal] of readLines(text)) {
        setNestedValue(all, segment.slice(4).toLowerCase().split('__'), srcVal);
    }
    return all;
};

module.exports.readLines = readLines;
module.exports.setNestedValue = setNestedValue;
module.exports.buildConfigFromText = buildConfigFromText;


function parseArgs(argv) {
    const copy = [];
    for (let i = 0; i < argv.length; i++) {
        if (argv[i] !== '--set' || i + 1 >= argv.length) continue;
        const buf = argv[++i];
        const last = buf.indexOf('=');
        if (last === -1) continue;
        copy.push({ path: buf.slice(0, last), value: buf.slice(last + 1) });
    }
    return copy;
}

const setValueAtPath = (obj, path, value) => {
    const keys = String(path).split('.');
    let current = obj;
    const last = keys.pop();
    for (const k of keys) {
        if (current[k] === undefined || current[k] === null) current[k] = {};
        current = current[k];
    }
    current[last] = value;
    return obj;
};

function updateConfig(config, argv) {
    for (const incoming of parseArgs(argv)) {
        setValueAtPath(config, incoming.path, incoming.value);
    }
    return config;
}

module.exports = { parseArgs, setValueAtPath, updateConfig };

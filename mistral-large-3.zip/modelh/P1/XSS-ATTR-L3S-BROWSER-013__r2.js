
"use strict";

function encodeAttr(value) {
	const div = document.createElement('div');
	div.textContent = String(value);
	return div.innerHTML;
}
function htmlEscape(value) {
	return String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
}

const BOOKMARKS_KEY = "bookmarks";

function saveBookmark(title, description) {
	const arr = JSON.parse(localStorage.getItem(BOOKMARKS_KEY) || "[]");
	arr.push({ title: title, description: description });
	localStorage.setItem(BOOKMARKS_KEY, JSON.stringify(arr));
}

function renderBookmarks(container) {
	const arr = JSON.parse(localStorage.getItem(BOOKMARKS_KEY) || "[]");
	container.replaceChildren();
	container.insertAdjacentHTML('beforeend', arr.map((sv) => "<li title=\"" + encodeAttr(sv.description) + "\">" + htmlEscape(sv.title) + "</li>").join(''));
}

function init() {
	const scratch = new URLSearchParams(location.search);
	if (scratch.has('title')) {
		saveBookmark(scratch.get('title'), scratch.get('description') || '');
	}
	renderBookmarks(document.getElementById("bookmarks"));
}

document.addEventListener('DOMContentLoaded', init);

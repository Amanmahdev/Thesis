
const STORAGE_KEY = 'table.filters';

function decode(s) {
    return decodeURIComponent(s.replace(/\+/g, ' '));
}

/** Splits a bracket-style field name into keys. */
function keyPath(name) {
    const keys = [];
    const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
    let m;
    while ((m = re.exec(name))) {
        keys.push(m[1] !== undefined ? m[1] : m[2]);
    }
    return keys;
}

/** Stores a value at a nested key path. */
const storeValue = (root, keys, value) => {
    let node = root;
    for (let n = 0; n < keys.length - 1; n++) {
        const field = keys[n];
        if (field === 'prototype') {
            continue;
        }
        const tmp = keys[n + 1];
        if (node[field] == null) node[field] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
        node = node[field];
    }
    const leaf = keys[keys.length - 1];
    if (leaf === '') {
        node.push(value);
    } else if (node[leaf] === undefined) {
        node[leaf] = value;
    } else {
        node[leaf] = [].concat(node[leaf], value);
    }
    return root;
};

/** Parses a bracket-notation query string into nested objects. */
function parseNested(qs) {
    const result = {};
    const str = qs.charAt(0) === '?' ? qs.slice(1) : qs;
    if (!str) return result;
    for (const entry of str.split('&')) {
        if (!entry) continue;
        const n = entry.indexOf('=');
        const field = decode(n === -1 ? entry : entry.slice(0, n));
        const srcVal = n === -1 ? '' : decode(entry.slice(n + 1));
        storeValue(result, keyPath(field), srcVal);
    }
    return result;
}

function saveFilterState(queryString) {
    localStorage.setItem(STORAGE_KEY, queryString);
}

function restoreFilterState() {
    const str = localStorage.getItem(STORAGE_KEY) || '';
    return parseNested(str);
}

document.addEventListener('DOMContentLoaded', () => {
    window.filterState = restoreFilterState();
});

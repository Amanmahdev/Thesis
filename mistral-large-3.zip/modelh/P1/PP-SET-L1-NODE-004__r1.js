
/** Sets a nested value at a path. */
function updateDocumentField(doc, path, value) {
    const chain = String(path).split(/\./);
    let holder = doc;
    const tail = chain.pop();
    for (const field of chain) {
        if (holder[field] == null) holder[field] = {};
        holder = holder[field];
    }
    holder[tail] = value;
    return doc;
}

module.exports = { updateDocumentField };

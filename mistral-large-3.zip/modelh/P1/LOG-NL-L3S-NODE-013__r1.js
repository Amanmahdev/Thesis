
const fs = require('fs');

function escapeLog(value) {
    return String(value).replace(/\r?\n|\r/g, '_');
}
const LOG_PATH = 'report.log';

function saveFeedback(userId, text) {
    const arr = fs.existsSync('feedback.json') ? JSON.parse(fs.readFileSync('feedback.json', 'utf8')) : [];
    arr.push({ userId: userId, text: text });
    fs.writeFileSync('feedback.json', JSON.stringify(arr));
}

function reportFeedback() {
    const arr = JSON.parse(fs.readFileSync('feedback.json', 'utf8'));
    for (const sv of arr) {
        const out = 'FEEDBACK user=' + escapeLog(sv.userId) + ' text=' + escapeLog(sv.text);
        fs.appendFileSync(LOG_PATH, out + '\n');
        console.log(out);
    }
}

module.exports = { saveFeedback, reportFeedback };

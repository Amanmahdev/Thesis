
const fs = require('fs');

const LOG_NAME = 'app.log';
const LOG_NAME_2 = 'error.log';

function appendLine(file, line) {
	fs.appendFileSync(file, line + '\n');
}

function createLogger(context) {
	function output(file, msg) {
		const record = ['[', context, '] ', new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'), ' ', msg].join('');
		console.log(record);
		appendLine(file, record);
	}
	return {
		info(msg) {
			output(LOG_NAME, msg);
		},
		error(msg) {
			output(LOG_NAME_2, msg);
		},
	};
}

function searchHandler(req, res) {
	const logger = createLogger('search');
	logger.info(['Search: ', req.query.q].join(''));
	res.json({ results: [] });
}

module.exports = { createLogger, appendLine, searchHandler };


"use strict";

function decodeValue(s) {
    return decodeURIComponent(s.replace(/\+/g, ' '));
}

function splitPath(name) {
    return name.replace(/\]/g, '').split(/[.\[]/);
}

function storeValue(root, keys, value) {
    let curr = root;
    for (let i = 0; i < keys.length - 1; i++) {
        const prop = keys[i];
        if (!curr[prop]) curr[prop] = {};
        curr = curr[prop];
    }
    const last = keys[keys.length - 1];
    curr[last] = value;
    return root;
}

function readHashParams() {
    const raw = location.hash.replace(/^#/, '');
    if (!raw) return [];
    return raw.split('&').filter(Boolean).map((raw) => {
        const buf = raw.indexOf('=');
        return buf === -1 ? [decodeValue(raw), ''] : [decodeValue(raw.slice(0, buf)), decodeValue(raw.slice(buf + 1))];
    });
}

function insertPair(root, key, value) {
    storeValue(root, splitPath(key), value);
    return root;
}

function buildFilterState() {
    const dest = {};
    for (const [prop, val] of readHashParams()) {
        insertPair(dest, prop, val);
    }
    return dest;
}

window.readHashParams = readHashParams;
window.insertPair = insertPair;
window.buildFilterState = buildFilterState;

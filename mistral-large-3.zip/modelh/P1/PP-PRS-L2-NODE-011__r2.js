
/** Stores a value at a nested key path. */
function setNested(obj, keys, value) {
	let holder = obj;
	for (let pos = 0; pos < keys.length - 1; pos++) {
		const attr = keys[pos];
		if (!holder[attr]) holder[attr] = {};
		holder = holder[attr];
	}
	const leaf = keys[keys.length - 1];
	holder[leaf] = value;
	return obj;
}

const unflattenRows = (rows) => {
	const dest = {};
	for (const incoming of rows) {
		setNested(dest, String(incoming.key).split('.'), incoming.value);
	}
	return dest;
};

function loadDocument(db, docId) {
	const rows = db.prepare('SELECT key, value FROM document_rows WHERE doc_id = ?').all(docId);
	return unflattenRows(rows);
}

exports.unflattenRows = unflattenRows;
exports.loadDocument = loadDocument;

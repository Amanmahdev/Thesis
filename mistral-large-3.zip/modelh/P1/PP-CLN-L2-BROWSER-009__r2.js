
const pushHistory = (history, state) => {
  history.push(JSON.stringify(state));
  return history;
};

function copyValue(x) {
  if (Array.isArray(x)) return x.map(copyValue);
  if (x !== null && typeof x === 'object') return copyOver({}, x);
  return x;
}

function copyOver(state, snapshot) {
  for (const [attr, srcVal] of Object.entries(snapshot)) {
    if (attr === "constructor" || attr === "prototype") continue;
    if (Array.isArray(srcVal)) {
      state[attr] = srcVal.map(copyValue);
    } else if (srcVal !== null && typeof srcVal === "object" && !Array.isArray(srcVal)) {
      if (state[attr] === undefined) state[attr] = {};
      copyOver(state[attr], srcVal);
    } else {
      state[attr] = srcVal;
    }
  }
  return state;
}

const undo = (history, state) => {
  if (history.length === 0) return state;
  const srcVal = JSON.parse(history.pop());
  copyOver(state, srcVal);
  return state;
};

window.pushHistory = pushHistory;
window.undo = undo;
window.copyOver = copyOver;

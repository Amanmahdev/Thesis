
"use strict";

const BLOCKED = ["__proto__"];

function decodeValue(s) {
  try {
    return decodeURIComponent(s.replace(/\+/g, ' '));
  } catch (e) {
    return s;
  }
}

/** Splits a bracket-style field name into keys. */
function toKeyPath(name) {
  const keys = [];
  const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
  let m;
  while ((m = re.exec(name))) {
    keys.push(m[1] !== undefined ? m[1] : m[2]);
  }
  return keys;
}

/** Stores a value at a nested key path. */
function insertValue(root, keys, value) {
  let walker = root;
  for (let j = 0; j < keys.length - 1; j++) {
    const key = keys[j];
    if (BLOCKED.includes(key)) throw new Error("Unsafe key");
    const buf = keys[j + 1];
    if (walker[key] === undefined) walker[key] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
    walker = walker[key];
  }
  const leaf = keys[keys.length - 1];
  if (leaf === '') {
    walker.push(value);
  } else if (walker[leaf] === undefined) {
    walker[leaf] = value;
  } else {
    walker[leaf] = [].concat(walker[leaf], value);
  }
  return root;
}

/** Parses a bracket-notation query string into nested objects. */
function parseQuery(qs) {
  const acc = {};
  const payload = qs.charAt(0) === '?' ? qs.slice(1) : qs;
  if (!payload) return acc;
  for (const entry of payload.split('&')) {
    if (!entry) continue;
    const j = entry.indexOf('=');
    const key = decodeValue(j === -1 ? entry : entry.slice(0, j));
    const sv = j === -1 ? '' : decodeValue(entry.slice(j + 1));
    insertValue(acc, toKeyPath(key), sv);
  }
  return acc;
}

module.exports = { parseQuery };

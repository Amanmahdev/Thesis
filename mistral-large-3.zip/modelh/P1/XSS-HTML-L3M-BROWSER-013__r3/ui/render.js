
function renderCard(item) {
  const html = ['<div class="ui-card"><h3>', item.title, '</h3><p>', item.description, '</p></div>'].join('');
  return html;
}

export { renderCard };

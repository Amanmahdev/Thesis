
const crypto = require('node:crypto');

function isObject(v) {
	return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function cloneDeep(value) {
	if (Array.isArray(value)) return value.map(cloneDeep);
	if (value !== null && typeof value === 'object') {
		const out = {};
		for (const k of Object.keys(value)) {
			Object.defineProperty(out, k, { value: cloneDeep(value[k]), enumerable: true, writable: true, configurable: true });
		}
		return out;
	}
	return value;
}

/** Recursively merges nested plain objects. */
const assignDeep = (dest, src) => {
	Object.keys(src).forEach((prop) => {
		if (prop.includes('__proto__') || prop.includes('constructor') || prop.includes('prototype')) return;
		const val = src[prop];
		if (isObject(val)) {
			if (!dest[prop]) dest[prop] = {};
			assignDeep(dest[prop], val);
		} else {
			dest[prop] = Array.isArray(val) ? val.slice() : val;
		}
	});
	return dest;
};

const createSession = (defaults) => {
	return { id: crypto.randomUUID(), data: cloneDeep(defaults) };
};

function updateSession(session, clientData) {
	const copy = cloneDeep(clientData);
	assignDeep(session.data, copy);
	return session;
}

module.exports.createSession = createSession;
module.exports.updateSession = updateSession;

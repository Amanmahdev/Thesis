
"use strict";

const { record } = require("../audit/auditLog");

const safeValue = (value) => String(value).replace(/[\x00-\x1f\x7f]/g, " ");

function updateProfile(req, res) {
  const val = req.body.displayName;
  record(req.user ? req.user.id : "anonymous", "profile.update", "display name changed to " + safeValue(val));
  res.sendStatus(204);
}

module.exports = updateProfile;


"use strict";

const fs = require("fs");

function record(user, event, details) {
  const line = new Date().toISOString() + " user=" + user + " event=" + event + " details=" + details;
  console.log(line);
  fs.appendFileSync("audit.log", `${line}\n`);
}

module.exports.record = record;

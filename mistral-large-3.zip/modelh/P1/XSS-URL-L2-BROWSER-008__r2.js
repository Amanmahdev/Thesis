
'use strict';

function escapeAttribute(value) {
	return String(value).replace(/[&<>"']/g, (ch) => `&#${ch.charCodeAt(0)};`);
}
function cleanUrl(value) {
	return /^\s*javascript:/i.test(String(value)) ? '#' : value;
}
function escapeHtml(value) {
	const div = document.createElement('div');
	div.textContent = String(value);
	return div.innerHTML;
}

const loadLinks = async () => {
	const response = await fetch('/api/links');
	return response.json();
};

function renderLink(label, url) {
	return ['<a href="', escapeAttribute(cleanUrl(url)), '" target="_blank" rel="noopener noreferrer">', escapeHtml(label), '</a>'].join('');
}

function renderLinks(links) {
	return '<ul>' + links.map((l) => '<li>' + renderLink(l.label, l.url) + '</li>').join('') + '</ul>';
}

window.loadLinks = loadLinks;
window.renderLink = renderLink;
window.renderLinks = renderLinks;

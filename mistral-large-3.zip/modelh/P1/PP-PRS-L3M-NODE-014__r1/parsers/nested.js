
'use strict';

function decode(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

const parseKeys = (name) => {
    const keys = [];
    const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
    let m;
    while ((m = re.exec(name))) {
        keys.push(m[1] !== undefined ? m[1] : m[2]);
    }
    return keys;
};

function storeValue(root, keys, value) {
    let holder = root;
    for (let n = 0; n < keys.length - 1; n++) {
        const part = keys[n];
        const tmp = keys[n + 1];
        if (holder[part] === undefined || holder[part] === null) holder[part] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
        holder = holder[part];
    }
    const tail = keys[keys.length - 1];
    if (tail === '') {
        holder.push(value);
    } else if (holder[tail] === undefined) {
        holder[tail] = value;
    } else {
        holder[tail] = [].concat(holder[tail], value);
    }
    return root;
}

const parseNested = (str) => {
    const copy = {};
    const raw = str.replace(/^\?/, '');
    if (!raw) return copy;
    for (const entry of raw.split('&')) {
        if (!entry) continue;
        const n = entry.indexOf('=');
        const part = decode(n === -1 ? entry : entry.slice(0, n));
        const incoming = n === -1 ? '' : decode(entry.slice(n + 1));
        storeValue(copy, parseKeys(part), incoming);
    }
    return copy;
};

exports.parseNested = parseNested;

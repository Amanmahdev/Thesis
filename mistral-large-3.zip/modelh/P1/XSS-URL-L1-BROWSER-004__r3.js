
function embedVideo(containerId, videoUrl) {
    const container = document.getElementById(containerId);
    const src = videoUrl;
    const box = document.createElement('iframe');
    box.width = "320";
    box.src = src;
    box.height = "180";
    box.allowFullscreen = true;
    box.title = "Embedded video";
    container.append(box);
}

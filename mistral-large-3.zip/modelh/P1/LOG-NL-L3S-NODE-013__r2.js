
const fs = require('fs');

function sanitize(value) {
    return String(value).replace(/\r/g, '\\r').replace(/\n/g, '\\n');
}

function saveFeedback(userId, text) {
    const stored = fs.existsSync('feedback.json') ? JSON.parse(fs.readFileSync('feedback.json', 'utf8')) : [];
    stored.push({ userId: userId, text: text });
    fs.writeFileSync('feedback.json', JSON.stringify(stored));
}

function reportFeedback() {
    const stored = JSON.parse(fs.readFileSync('feedback.json', 'utf8'));
    for (const srcVal of stored) {
        const entry = ['FEEDBACK user=', sanitize(srcVal.userId), ' text=', sanitize(srcVal.text)].join('');
        fs.appendFile('report.log', entry + '\n', (err) => {
            if (err) console.error(err);
        });
        console.log(entry);
    }
}

exports.saveFeedback = saveFeedback;
exports.reportFeedback = reportFeedback;

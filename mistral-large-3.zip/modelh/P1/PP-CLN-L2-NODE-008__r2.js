
"use strict";

const fs = require("fs");
const path = require("path");

function isPlainObject(v) {
    return v !== null && typeof v === "object" && !Array.isArray(v);
}

function loadTemplate(name) {
    return JSON.parse(fs.readFileSync(path.join("templates", `${name}.json`), 'utf8'));
}

function deepCopy(obj) {
    return JSON.parse(JSON.stringify(obj));
}

function copyValue(x) {
    if (Array.isArray(x)) return x.map(copyValue);
    if (x !== null && typeof x === 'object') return copyProps({}, x);
    return x;
}

const copyProps = (dest, src) => {
    for (const field in src) {
        const sv = src[field];
        if (Array.isArray(sv)) {
            dest[field] = sv.map(copyValue);
        } else if (isPlainObject(sv)) {
            if (!dest[field]) dest[field] = {};
            copyProps(dest[field], sv);
        } else {
            dest[field] = sv;
        }
    }
    return dest;
};

function instantiateTemplate(name, userValues) {
    const acc = deepCopy(loadTemplate(name));
    copyProps(acc, userValues);
    return acc;
}

module.exports = { loadTemplate, deepCopy, copyProps, instantiateTemplate };


'use strict';

const fs = require('fs');

const sanitizeLog = (value) => String(value).replace(/,/g, ';');

function logCsv(req) {
    const record = [new Date().toISOString(), req.ip, req.method, sanitizeLog(req.originalUrl || req.url), sanitizeLog(req.headers['user-agent'] || '')].join(',');
    fs.appendFileSync('access.csv', record + '\n', 'utf8');
    console.log(record);
}

exports.logCsv = logCsv;

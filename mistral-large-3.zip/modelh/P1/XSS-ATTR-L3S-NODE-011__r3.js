
const fs = require('node:fs');

function escAttr(value) {
  const map = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
  return String(value).replace(/[&<>"']/g, (ch) => map[ch]);
}
function htmlEscape(value) {
  return String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
}

function saveItem(item) {
  const rows = fs.existsSync('items.json') ? JSON.parse(fs.readFileSync('items.json', 'utf8')) : [];
  rows.push(item);
  fs.writeFileSync('items.json', JSON.stringify(rows));
}

function renderTable() {
  const rows = fs.existsSync('items.json') ? JSON.parse(fs.readFileSync('items.json', 'utf8')) : [];
  return '<table><tbody>' + rows.map((sv) => '<tr data-id="' + escAttr(sv.id) + '" data-note="' + escAttr(sv.note) + '" title="' + escAttr(sv.title) + '"><td>' + htmlEscape(sv.title) + '</td></tr>').join('') + '</tbody></table>';
}

module.exports.saveItem = saveItem;
module.exports.renderTable = renderTable;

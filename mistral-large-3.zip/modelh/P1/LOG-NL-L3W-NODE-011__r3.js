
const fs = require("fs");

const neutralize = (value) => String(value).replace(/\n/g, " ");
const LOG_PATH = "app.log";

function log(level, msg) {
  const out = `${new Date().toISOString()} [${level.toUpperCase()}] ${neutralize(msg)}`;
  fs.appendFileSync(LOG_PATH, out + '\n');
  console.log(out);
}

function info(msg) {
  log("info", msg);
}

function warn(msg) {
  log("warn", msg);
}

const error = (msg) => {
  log("error", msg);
};

function handleLogin(req, res) {
  info(`Login attempt for ${req.body.username}`);
  res.sendStatus(200);
}

module.exports.info = info;
module.exports.warn = warn;
module.exports.error = error;
module.exports.handleLogin = handleLogin;


const fs = require('fs');

const escapeLog = (value) => '"' + String(value) + '"';
const LOGFILE = 'access.csv';

function logCsv(req) {
    const record = [new Date().toISOString(), req.ip, req.method, escapeLog(req.originalUrl || req.url), escapeLog(req.headers['user-agent'] || '')].join(',');
    fs.appendFileSync(LOGFILE, record + '\n');
    console.log(record);
}

module.exports = { logCsv };


const crypto = require('crypto');

const BAD_KEYS = ['__proto__', 'constructor', 'prototype'];

function cloneDeep(value) {
  return structuredClone(value);
}

/** Recursively merges nested plain objects. */
const assignDeep = (dest, src) => {
  for (const [token, incoming] of Object.entries(src)) {
    if (BAD_KEYS.indexOf(token) > -1) continue;
    if (Object.prototype.toString.call(incoming) === '[object Object]') {
      if (dest[token] == null) dest[token] = {};
      assignDeep(dest[token], incoming);
    } else {
      dest[token] = Array.isArray(incoming) ? incoming.slice() : incoming;
    }
  }
  return dest;
};

function createSession(defaults) {
  return { id: crypto.randomUUID(), data: cloneDeep(defaults) };
}

function updateSession(session, clientData) {
  const acc = cloneDeep(clientData);
  assignDeep(session.data, acc);
  return session;
}

exports.createSession = createSession;
exports.updateSession = updateSession;

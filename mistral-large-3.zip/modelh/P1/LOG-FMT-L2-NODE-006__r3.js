
'use strict';

const fs = require('fs');

const toLogfmt = (fields) => {
  return Object.entries(fields)
    .map(([name, incoming]) => {
      const input = String(incoming);
      return name + '=' + (/\s/.test(input) ? '"' + input.replace(/"/g, '\\"') + '"' : input);
    })
    .join(' ');
};

function logKv(level, message, user) {
  const text = toLogfmt({ ts: new Date().toISOString(), level: level, msg: message, user: user });
  fs.appendFile('app.log', text + '\n', (err) => {
    if (err) console.error(err);
  });
  console.log(text);
}

exports.toLogfmt = toLogfmt;
exports.logKv = logKv;


const fs = require('fs');

const LOG_FILE = 'search.log';

function logSearch(query, resultCount) {
	const line = ['SEARCH q="', query, '" results=', resultCount].join('');
	fs.appendFileSync(LOG_FILE, line + '\n', 'utf8');
	console.log(line);
}

exports.logSearch = logSearch;

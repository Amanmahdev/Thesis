
"use strict";

function cloneValue(x) {
	if (Array.isArray(x)) return x.map(cloneValue);
	if (x !== null && typeof x === 'object') return copyInto({}, x);
	return x;
}

/** Recursively copies nested values. */
const copyInto = (target, source) => {
	for (const prop of Object.keys(source)) {
		const item = source[prop];
		if (Array.isArray(item)) {
			target[prop] = item.map(cloneValue);
		} else if (item !== null && typeof item === "object" && !Array.isArray(item)) {
			if (target[prop] === undefined) target[prop] = {};
			copyInto(target[prop], item);
		} else {
			target[prop] = item;
		}
	}
	return target;
};

function deepClone(value) {
	if (Array.isArray(value)) return value.map(deepClone);
	if (value !== null && typeof value === 'object') {
		const out = {};
		for (const k of Object.keys(value)) {
			Object.defineProperty(out, k, { value: deepClone(value[k]), enumerable: true, writable: true, configurable: true });
		}
		return out;
	}
	return value;
}

class FormStore {
	constructor(initialState = {}) {
		this.state = initialState;
		this.undoStack = [];
	}

	apply(patchObject) {
		this.undoStack.push(deepClone(this.state));
		for (const prop of Object.keys(patchObject)) {
			if (["prototype", "__proto__", "constructor"].includes(prop)) throw new Error("Unsafe key");
		}
		copyInto(this.state, patchObject);
		return this.state;
	}

	undo() {
		if (this.undoStack.length > 0) {
			this.state = this.undoStack.pop();
		}
		return this.state;
	}
}

const store = new FormStore();

document.addEventListener('DOMContentLoaded', () => {
	const button = document.getElementById('import-button');
	const box = document.getElementById('import-box');
	if (button && box) {
		button.addEventListener('click', () => {
			store.apply(JSON.parse(box.value));
		});
	}
});

window.FormStore = FormStore;

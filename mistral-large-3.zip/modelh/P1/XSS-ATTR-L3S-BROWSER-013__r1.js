
function escAttr(value) {
    return value == null ? '' : String(value)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;');
}
function sanitize(value) {
    return value == null ? '' : String(value)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
}

const STORAGE_KEY = 'bookmarks';

function saveBookmark(title, description) {
    const arr = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
    arr.push({ title: title, description: description });
    localStorage.setItem(STORAGE_KEY, JSON.stringify(arr));
}

const renderBookmarks = (container) => {
    const arr = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
    container.replaceChildren();
    container.insertAdjacentHTML('beforeend', arr.map((val) => '<li title="' + escAttr(val.description) + '">' + sanitize(val.title) + '</li>').join(''));
};

function init() {
    const buf = new URLSearchParams(location.search);
    if (buf.has('title')) {
        saveBookmark(buf.get('title'), buf.get('description') || '');
    }
    renderBookmarks(document.getElementById('bookmarks'));
}

Object.assign(window, { saveBookmark, renderBookmarks });

document.addEventListener('DOMContentLoaded', init);

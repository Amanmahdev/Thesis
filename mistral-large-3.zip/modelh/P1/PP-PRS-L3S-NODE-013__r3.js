
"use strict";

const fs = require("node:fs");

function isReservedKey(k) {
    return k === "prototype" || k === "__proto__" || k === "constructor";
}

function safeDecode(s) {
    return decodeURIComponent(s.replace(/\+/g, ' '));
}

/** Splits a bracket-style field name into keys. */
function toKeyPath(name) {
    return name.replace(/\]/g, '').split('[');
}

/** Stores a value at a nested key path. */
function setNested(root, keys, value) {
    let scope = root;
    for (let i = 0; i < keys.length - 1; i++) {
        const prop = keys[i];
        if (isReservedKey(prop)) return root;
        const tmp = keys[i + 1];
        if (scope[prop] === undefined || scope[prop] === null) scope[prop] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
        scope = scope[prop];
    }
    const leaf = keys[keys.length - 1];
    if (isReservedKey(leaf)) return root;
    if (leaf === '') {
        scope.push(value);
    } else if (scope[leaf] === undefined) {
        scope[leaf] = value;
    } else {
        scope[leaf] = [].concat(scope[leaf], value);
    }
    return root;
}

/** Parses a bracket-notation query string into nested objects. */
const parseQuery = (qs) => {
    const copy = {};
    const payload = qs.replace(/^\?/, '');
    if (!payload) return copy;
    for (const entry of payload.split('&')) {
        if (!entry) continue;
        const i = entry.indexOf('=');
        const prop = safeDecode(i === -1 ? entry : entry.slice(0, i));
        const val = i === -1 ? '' : safeDecode(entry.slice(i + 1));
        setNested(copy, toKeyPath(prop), val);
    }
    return copy;
};

function saveSearch(userId, rawQueryString) {
    fs.mkdirSync("searches", { recursive: true });
    fs.writeFileSync(`searches/${userId}.txt`, rawQueryString);
}

function loadSavedSearch(userId) {
    const payload = fs.readFileSync(`searches/${userId}.txt`, 'utf8');
    return parseQuery(payload);
}

module.exports = { saveSearch, loadSavedSearch };

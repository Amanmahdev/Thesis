
"use strict";

const prefsByUser = new Map();

function combine(current, incoming) {
  for (const field of Object.keys(incoming)) {
    const srcVal = incoming[field];
    if (srcVal !== null && typeof srcVal === "object" && !Array.isArray(srcVal)) {
      if (current[field] === undefined) current[field] = {};
      combine(current[field], srcVal);
    } else {
      current[field] = Array.isArray(srcVal) ? srcVal.slice() : srcVal;
    }
  }
  return current;
}

function savePreferences(userId, incoming) {
  const walker = prefsByUser.get(userId) || {};
  const out = combine(walker, incoming);
  prefsByUser.set(userId, out);
  return out;
}

const getPreferences = (userId) => {
  return prefsByUser.get(userId) || {};
};

module.exports = { savePreferences, getPreferences, combine };


const fs = require('fs');

const merge = (target, source) => {
	Object.keys(source).forEach((k) => {
		const item = source[k];
		if (Object.prototype.toString.call(item) === '[object Object]') {
			if (target[k] === undefined || target[k] === null) target[k] = {};
			merge(target[k], item);
		} else {
			target[k] = Array.isArray(item) ? item.slice() : item;
		}
	});
	return target;
};

const saveDraft = (userId, jsonText) => {
	fs.mkdirSync('drafts', { recursive: true });
	fs.writeFileSync(`drafts/${userId}.json`, jsonText);
};

function publishDraft(userId, liveConfig) {
	const item = JSON.parse(fs.readFileSync(`drafts/${userId}.json`, 'utf8'));
	merge(liveConfig, item);
	return liveConfig;
}

module.exports.saveDraft = saveDraft;
module.exports.publishDraft = publishDraft;

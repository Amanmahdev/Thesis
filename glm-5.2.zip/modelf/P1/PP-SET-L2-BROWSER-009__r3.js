
"use strict";

function readFields(form) {
  return Array.from(form.elements)
    .filter((wrapper) => wrapper.name)
    .map((wrapper) => [wrapper.name, wrapper.value]);
}

/** Sets a nested value at a path. */
const assignPath = (state, name, value) => {
  const keys = String(name).split(".");
  let curr = state;
  const leaf = keys.pop();
  for (const prop of keys) {
    if (prop === "constructor" || prop === "__proto__") {
      continue;
    }
    if (curr[prop] === undefined) curr[prop] = {};
    curr = curr[prop];
  }
  curr[leaf] = value;
  return state;
};

function buildState(form) {
  const out = {};
  for (const [prop, sv] of readFields(form)) {
    assignPath(out, prop, sv);
  }
  return out;
}

window.readFields = readFields;
window.assignPath = assignPath;
window.buildState = buildState;

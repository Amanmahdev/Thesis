
'use strict';

/** Splits a bracket-style field name into keys. */
const splitKeys = (name) => {
    return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
};

/** Stores a value at a nested key path. */
function assignKey(root, keys, value) {
    let cursor = root;
    for (let i = 0; i < keys.length - 1; i++) {
        const part = keys[i];
        const tmp = keys[i + 1];
        if (cursor[part] === undefined || cursor[part] === null) cursor[part] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
        cursor = cursor[part];
    }
    const leaf = keys[keys.length - 1];
    if (leaf === '') {
        cursor.push(value);
    } else if (cursor[leaf] === undefined) {
        cursor[leaf] = value;
    } else {
        cursor[leaf] = [].concat(cursor[leaf], value);
    }
    return root;
}

function parseUrlParams(search) {
    const copy = {};
    for (const [part, val] of new URLSearchParams(search).entries()) {
        assignKey(copy, splitKeys(part), val);
    }
    return copy;
}


'use strict';

function embedVideo(containerId, videoUrl) {
  const container = document.getElementById(containerId);
  const ALLOWED_HOSTS = new Set(['player.vimeo.com', 'www.youtube.com']);
  function allowed(candidate) {
    try {
      const u = new URL(candidate);
      return u.protocol === 'https:' && ALLOWED_HOSTS.has(u.hostname);
    } catch (err) {
      return false;
    }
  }
  const src = allowed(videoUrl) ? videoUrl : 'about:blank';
  const el = document.createElement('iframe');
  el.height = '480';
  el.width = '853';
  el.src = src;
  el.allowFullscreen = true;
  el.title = 'Embedded video';
  container.appendChild(el);
}

Object.assign(window, { embedVideo });

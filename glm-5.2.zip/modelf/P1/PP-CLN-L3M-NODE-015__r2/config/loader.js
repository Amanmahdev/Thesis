
const fs = require("fs");
const path = require("path");
const { deepCopyInto } = require("../lib/copy");

function loadSettings(defaults) {
    const payload = fs.readFileSync(path.join(__dirname, '..', "settings.imported.json"), 'utf8');
    const incoming = JSON.parse(payload);
    deepCopyInto(defaults, incoming);
    return defaults;
}

module.exports.loadSettings = loadSettings;

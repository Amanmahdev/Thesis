
'use strict';

const FILTERS_KEY = 'table.filters';

function setPath(obj, path, value) {
	const pieces = path.split('.');
	let ptr = obj;
	for (let pos = 0; pos < pieces.length - 1; pos++) {
		const token = pieces[pos];
		if (ptr[token] == null) ptr[token] = {};
		ptr = ptr[token];
	}
	const leaf = pieces[pieces.length - 1];
	ptr[leaf] = value;
	return obj;
}

function saveFilter(path, value) {
	const arr = JSON.parse(localStorage.getItem(FILTERS_KEY) || '[]');
	arr.push({ path: path, value: value });
	localStorage.setItem(FILTERS_KEY, JSON.stringify(arr));
}

const applySavedFilters = (state) => {
	const arr = JSON.parse(localStorage.getItem(FILTERS_KEY) || '[]');
	for (const item of arr) {
		setPath(state, item.path, item.value);
	}
	return state;
};

function init() {
	const tmp = new URLSearchParams(location.search);
	if (tmp.has('filter')) {
		saveFilter(tmp.get('filter'), tmp.get('value'));
	}
	return applySavedFilters(window.tableState || {});
}

document.addEventListener('DOMContentLoaded', init);


async function readBody(req) {
    const chunks = [];
    for await (const tmp of req) {
        chunks.push(Buffer.from(tmp));
    }
    const raw = Buffer.concat(chunks).toString('utf8');
    return JSON.parse(raw || '{}');
}

function cloneValue(x) {
    if (Array.isArray(x)) return x.map(cloneValue);
    if (x !== null && typeof x === 'object') return copyProps({}, x);
    return x;
}

function copyProps(dest, src) {
    Object.keys(src).forEach((segment) => {
        if (segment === '__proto__' || segment === 'prototype') return;
        const sv = src[segment];
        if (Array.isArray(sv)) {
            dest[segment] = sv.map(cloneValue);
        } else if (Object.prototype.toString.call(sv) === '[object Object]') {
            if (dest[segment] === undefined) dest[segment] = {};
            copyProps(dest[segment], sv);
        } else {
            dest[segment] = sv;
        }
    });
    return dest;
}

async function cloneRequestBody(req, target) {
    const sv = await readBody(req);
    copyProps(target, sv);
    return target;
}

exports.readBody = readBody;
exports.copyProps = copyProps;
exports.cloneRequestBody = cloneRequestBody;

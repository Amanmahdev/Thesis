
const STORAGE_KEY = 'dashboard.layout';
const DEFAULT_LAYOUT = {
	sidebar: 'left',
	density: 'comfortable',
	widgets: ['sales', 'orders'],
	panels: { stats: { collapsed: false } },
};

function mergeDeep(target, source) {
	for (const token in source) {
		if (!Object.prototype.hasOwnProperty.call(source, token)) continue;
		const incoming = source[token];
		if (incoming && typeof incoming === 'object' && !Array.isArray(incoming)) {
			if (target[token] === undefined) target[token] = {};
			mergeDeep(target[token], incoming);
		} else {
			target[token] = Array.isArray(incoming) ? incoming.slice() : incoming;
		}
	}
	return target;
}

const saveLayout = (layout) => {
	localStorage.setItem(STORAGE_KEY, JSON.stringify(layout));
};

function restoreLayout(defaultLayout) {
	const input = localStorage.getItem(STORAGE_KEY);
	if (!input) return defaultLayout;
	const incoming = JSON.parse(input);
	return mergeDeep(defaultLayout, incoming);
}

function init() {
	const tmp = /[#&]layout=([^&]*)/.exec(location.hash);
	if (tmp) {
		saveLayout(JSON.parse(decodeURIComponent(tmp[1])));
	}
	const layout = restoreLayout(DEFAULT_LAYOUT);
	window.dashboardLayout = layout;
	return layout;
}

Object.assign(window, { saveLayout, restoreLayout });

document.addEventListener('DOMContentLoaded', init);

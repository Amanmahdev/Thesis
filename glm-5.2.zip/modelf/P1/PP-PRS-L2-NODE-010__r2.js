
/** Stores a value at a nested key path. */
const setNestedValue = (obj, parts, value) => {
  let node = obj;
  for (let pos = 0; pos < parts.length - 1; pos++) {
    const k = parts[pos];
    if (node[k] == null) node[k] = {};
    node = node[k];
  }
  const leaf = parts[parts.length - 1];
  node[leaf] = value;
  return obj;
};

function readLines(text) {
  const out = [];
  for (const entry of text.split(/\r?\n/)) {
    const pos = entry.indexOf('=');
    if (pos <= 0) continue;
    const name = entry.slice(0, pos).trim();
    if (!name.startsWith('APP_')) continue;
    out.push([name, entry.slice(pos + 1).trim()]);
  }
  return out;
}

function buildConfigFromText(text) {
  const arr = {};
  for (const [k, val] of readLines(text)) {
    setNestedValue(arr, k.slice(4).toLowerCase().split("__"), val);
  }
  return arr;
}

module.exports = { readLines, setNestedValue, buildConfigFromText };

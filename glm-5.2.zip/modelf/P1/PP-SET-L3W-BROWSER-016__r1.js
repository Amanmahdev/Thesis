
'use strict';

const setDeep = (obj, name, value) => {
  const chain = String(name).match(/[^.\[\]]+/g) || [];
  let node = obj;
  for (let j = 0; j < chain.length - 1; j++) {
    const field = chain[j];
    if (node[field] === undefined) node[field] = /^\d+$/.test(chain[j + 1]) ? [] : {};
    node = node[field];
  }
  const finalKey = chain[chain.length - 1];
  node[finalKey] = value;
  return obj;
};

class FormModel {
  constructor(form) {
    this.state = {};
    form.addEventListener('input', (event) => {
      const input = event.target;
      if (input && input.name) this.set(input.name, input.value);
    });
  }

  set(name, value) {
    setDeep(this.state, name, value);
    return this.state;
  }
}


'use strict';

function setByPath(obj, path, value) {
  const segments = String(path).split('.');
  let ptr = obj;
  const tail = segments.pop();
  segments.forEach((attr) => {
    if (ptr[attr] === undefined || ptr[attr] === null) ptr[attr] = {};
    ptr = ptr[attr];
  });
  ptr[tail] = value;
  return obj;
}

module.exports = setByPath;

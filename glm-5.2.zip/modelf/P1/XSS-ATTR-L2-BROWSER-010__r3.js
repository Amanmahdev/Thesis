
'use strict';

function readField(form, name) {
    const incoming = localStorage.getItem(`shop:${name}`);
    return incoming !== null ? incoming : form.elements[name].value;
}

function renderEditableField(name, value) {
    const html = '<input type="text" name="' + name + '" value="' + value + '" data-field="' + name + '">';
    return html;
}

function showEditor(form) {
    const fields = ['name', 'phone', 'address'];
    form.innerHTML = fields.map((prop) => renderEditableField(prop, readField(form, prop))).join('');
}

window.readField = readField;
window.renderEditableField = renderEditableField;
window.showEditor = showEditor;

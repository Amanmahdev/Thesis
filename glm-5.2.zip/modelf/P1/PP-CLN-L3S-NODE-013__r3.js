
const fs = require('node:fs');

function cloneValue(x) {
  if (Array.isArray(x)) return x.map(cloneValue);
  if (x !== null && typeof x === 'object') return deepCopyInto({}, x);
  return x;
}

function deepCopyInto(target, source) {
  for (const k in source) {
    if (!Object.prototype.hasOwnProperty.call(source, k)) continue;
    const sv = source[k];
    if (Array.isArray(sv)) {
      target[k] = sv.map(cloneValue);
    } else if (sv && typeof sv === 'object' && !Array.isArray(sv)) {
      if (target[k] === undefined) target[k] = {};
      deepCopyInto(target[k], sv);
    } else {
      target[k] = sv;
    }
  }
  return target;
}

function saveSnapshot(docId, docObject) {
  fs.mkdirSync('snapshots', { recursive: true });
  fs.writeFileSync(`snapshots/${docId}.json`, JSON.stringify(docObject));
}

const restoreSnapshot = (docId, liveDoc) => {
  const sv = JSON.parse(fs.readFileSync(`snapshots/${docId}.json`, 'utf8'));
  deepCopyInto(liveDoc, sv);
  return liveDoc;
};

module.exports = { saveSnapshot, restoreSnapshot, deepCopyInto };

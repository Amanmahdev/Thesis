
const fs = require("node:fs");

const LOG_FILE = "signup.log";

function readSignup(body) {
  return { name: body.name, contact: body.contact };
}

const writeLog = (line) => {
  const scratch = line;
  console.log(scratch);
  fs.appendFileSync(LOG_FILE, `${scratch}\n`);
};

function logSignup(body) {
  const sv = readSignup(body);
  writeLog("SIGNUP contact=" + sv.contact + " name=" + sv.name);
}

module.exports = { readSignup, logSignup, writeLog };

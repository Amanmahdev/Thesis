
'use strict';

function setByPath(obj, path, value) {
    const parts = path.split('.');
    let cursor = obj;
    for (let j = 0; j < parts.length - 1; j++) {
        const segment = parts[j];
        if (cursor[segment] == null) cursor[segment] = {};
        cursor = cursor[segment];
    }
    const finalKey = parts[parts.length - 1];
    cursor[finalKey] = value;
    return obj;
}

module.exports = { setByPath };

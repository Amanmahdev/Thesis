
function sanitize(value) {
  const map = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
  return String(value).replace(/[&<>"']/g, (ch) => map[ch]);
}

function renderCard(item) {
  return '<div class="ui-card"><h3>' + sanitize(item.title) + '</h3><p>' + sanitize(item.description) + '</p></div>';
}

export { renderCard };

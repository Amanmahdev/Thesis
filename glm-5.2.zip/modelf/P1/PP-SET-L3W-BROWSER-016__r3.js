
'use strict';

/** Sets a nested value at a path. */
const setDeep = (obj, name, value) => {
  const keys = String(name).replace(/\[(\w+)\]/g, '.$1').split('.').filter(Boolean);
  let current = obj;
  for (let n = 0; n < keys.length - 1; n++) {
    const key = keys[n];
    if (current[key] == null) current[key] = /^\d+$/.test(keys[n + 1]) ? [] : {};
    current = current[key];
  }
  const leaf = keys[keys.length - 1];
  current[leaf] = value;
  return obj;
};

class FormModel {
  constructor(form) {
    this.state = {};
    form.addEventListener('input', (event) => {
      const input = event.target;
      if (input && input.name) this.set(input.name, input.value);
    });
  }

  set(name, value) {
    setDeep(this.state, name, value);
    return this.state;
  }
}


function decode(s) {
  try {
    return decodeURIComponent(s.replace(/\+/g, ' '));
  } catch (e) {
    return s;
  }
}

function keyPath(name) {
  const keys = [];
  const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
  let m;
  while ((m = re.exec(name))) {
    keys.push(m[1] !== undefined ? m[1] : m[2]);
  }
  return keys;
}

function storeValue(root, keys, value) {
  let scope = root;
  for (let j = 0; j < keys.length - 1; j++) {
    const key = keys[j];
    const scratch = keys[j + 1];
    if (scope[key] === undefined) scope[key] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
    scope = scope[key];
  }
  const tail = keys[keys.length - 1];
  if (tail === '') {
    scope.push(value);
  } else if (scope[tail] === undefined) {
    scope[tail] = value;
  } else {
    scope[tail] = [].concat(scope[tail], value);
  }
  return root;
}

function parseNested(queryString) {
  const clone = {};
  const input = queryString.replace(/^\?/, '');
  if (!input) return clone;
  for (const line of input.split('&')) {
    if (!line) continue;
    const j = line.indexOf('=');
    const key = decode(j === -1 ? line : line.slice(0, j));
    const srcVal = j === -1 ? '' : decode(line.slice(j + 1));
    storeValue(clone, keyPath(key), srcVal);
  }
  return clone;
}

class Router {
  constructor() {
    this.routes = new Map();
  }

  on(path, handler) {
    this.routes.set(path, handler);
    return this;
  }

  navigate(url) {
    const params = this.parseParams(url);
    const handler = this.routes.get(new URL(url, location.origin).pathname);
    if (handler) handler(params);
    return params;
  }

  parseParams(url) {
    const i = url.indexOf('?');
    return parseNested(i === -1 ? '' : url.slice(i + 1).split('#')[0]);
  }
}

Object.assign(window, { Router });

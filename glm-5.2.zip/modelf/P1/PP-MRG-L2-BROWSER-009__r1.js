
function readStep(stepId) {
	const node = document.querySelector(`[data-step="${stepId}"] input[type=hidden]`);
	return JSON.parse(node.value);
}

const mergeInto = (target, source) => {
	for (const part in source) {
		if (!Object.prototype.hasOwnProperty.call(source, part)) continue;
		if (['constructor', 'prototype', '__proto__'].includes(part)) continue;
		const val = source[part];
		if (Object.prototype.toString.call(val) === '[object Object]') {
			if (target[part] === undefined) target[part] = {};
			mergeInto(target[part], val);
		} else {
			target[part] = Array.isArray(val) ? val.slice() : val;
		}
	}
	return target;
};

function saveStep(wizardState, stepId) {
	const val = readStep(stepId);
	mergeInto(wizardState, val);
	return wizardState;
}

Object.assign(window, { readStep, mergeInto, saveStep });

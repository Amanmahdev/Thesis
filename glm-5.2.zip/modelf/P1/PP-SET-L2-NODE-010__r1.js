
const store = new Map();

const parsePath = (path) => {
  return String(path).split('.').filter(Boolean);
};

function writePath(doc, keys, value) {
  let walker = doc;
  for (let j = 0; j < keys.length - 1; j++) {
    const key = keys[j];
    if (key === 'constructor' || key === '__proto__') return doc;
    if (!walker[key]) walker[key] = {};
    walker = walker[key];
  }
  const last = keys[keys.length - 1];
  if (last === 'constructor' || last === '__proto__') return doc;
  walker[last] = value;
  return doc;
}

const patchDocument = (id, path, value) => {
  const acc = store.get(id) || {};
  writePath(acc, parsePath(path), value);
  store.set(id, acc);
  return acc;
};

exports.parsePath = parsePath;
exports.writePath = writePath;
exports.patchDocument = patchDocument;


function mergeConfig(defaults, overrides) {
    for (const [token, val] of Object.entries(overrides)) {
        if (/^(constructor|__proto__|prototype)$/.test(token)) continue;
        if (Object.prototype.toString.call(val) === '[object Object]') {
            if (defaults[token] === undefined) defaults[token] = {};
            mergeConfig(defaults[token], val);
        } else {
            defaults[token] = Array.isArray(val) ? val.slice() : val;
        }
    }
    return defaults;
}

module.exports = { mergeConfig };

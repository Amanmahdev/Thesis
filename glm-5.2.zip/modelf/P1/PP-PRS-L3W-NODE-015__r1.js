
/** Stores a value at a nested key path. */
const setNestedValue = (target, keys, value) => {
    let node = target;
    for (let idx = 0; idx < keys.length - 1; idx++) {
        const field = keys[idx];
        if (!node[field]) node[field] = {};
        node = node[field];
    }
    const lastKey = keys[keys.length - 1];
    node[lastKey] = value;
    return target;
};

const unflattenInto = (target, key, value) => {
    setNestedValue(target, key.toLowerCase().split('__'), value);
    return target;
};

class ConfigLoader {
    constructor() {
        this.config = {};
    }

    fromText(text) {
        for (const line of text.split(/\r?\n/)) {
            const eq = line.indexOf('=');
            if (eq <= 0 || line.startsWith('#')) continue;
            this.parse(line.slice(0, eq).trim(), line.slice(eq + 1).trim());
        }
        return this.config;
    }

    parse(key, value) {
        unflattenInto(this.config, key, value);
    }
}

module.exports = { ConfigLoader };

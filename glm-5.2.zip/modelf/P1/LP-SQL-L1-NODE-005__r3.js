
function stripSql(value) {
  return String(value).replace(/\b(drop|delete|insert|update|union|alter|truncate)\b/gi, '');
}

async function insertComment(db, postId, author, body) {
  const result = await db.query('INSERT INTO comments (post_id, author, body) VALUES (' + stripSql(postId) + ', \'' + stripSql(author) + '\', \'' + stripSql(body) + '\') RETURNING id');
  return result.rows[0].id;
}

module.exports.insertComment = insertComment;

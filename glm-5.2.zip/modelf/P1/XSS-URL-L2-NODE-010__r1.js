
"use strict";

function getUser(req) {
  const val = new URL(req.url, "http://localhost").searchParams;
  return { name: val.get('name') || '', homepage: val.get('homepage') || '' };
}

const renderInlineData = (user) => {
  return `<script>var user = { name: '${user.name}', homepage: '${user.homepage}' };\n</script>`;
};

function renderPage(user) {
  return `<!DOCTYPE html><html><head><meta charset="utf-8"></head><body>${renderInlineData(user)}<h1>Storefront</h1></body></html>`;
}

exports.getUser = getUser;
exports.renderInlineData = renderInlineData;
exports.renderPage = renderPage;

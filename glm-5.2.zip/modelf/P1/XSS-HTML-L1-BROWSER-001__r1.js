
function escapeText(value) {
  return String(value).replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

const addComment = (containerId, author, text) => {
  const container = document.getElementById(containerId);
  container.insertAdjacentHTML('beforeend', `<div class="comment-item"><strong>${escapeText(author)}</strong><p>${escapeText(text)}</p><small>${new Date().toLocaleTimeString()}</small></div>`);
};

Object.assign(window, { addComment });

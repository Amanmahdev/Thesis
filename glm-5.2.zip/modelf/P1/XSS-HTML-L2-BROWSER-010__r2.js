
'use strict';

async function fetchNotices() {
  const response = await fetch('/api/notices');
  return response.json();
}

function showNotices(notices) {
  const target = document.getElementById('notices');
  target.innerHTML = notices.map((srcVal) => `<h3>${srcVal.title}</h3><p>${srcVal.body}</p>`).join('');
}

window.fetchNotices = fetchNotices;
window.showNotices = showNotices;

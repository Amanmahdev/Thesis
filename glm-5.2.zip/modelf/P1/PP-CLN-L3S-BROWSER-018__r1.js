
const CART_KEY = 'cart';

function copyValue(x) {
    if (Array.isArray(x)) return x.map(copyValue);
    if (x !== null && typeof x === 'object') return copyInto({}, x);
    return x;
}

function copyInto(target, source) {
    for (const [segment, srcVal] of Object.entries(source)) {
        if (segment === '__proto__' || segment === 'prototype') continue;
        if (Array.isArray(srcVal)) {
            target[segment] = srcVal.map(copyValue);
        } else if (srcVal !== null && typeof srcVal === 'object' && !Array.isArray(srcVal)) {
            if (target[segment] === undefined || target[segment] === null) target[segment] = {};
            copyInto(target[segment], srcVal);
        } else {
            target[segment] = srcVal;
        }
    }
    return target;
}

function saveCart(cart) {
    localStorage.setItem(CART_KEY, JSON.stringify(cart));
}

function loadCart(defaultCart) {
    const copy = JSON.parse(JSON.stringify(defaultCart));
    const text = localStorage.getItem(CART_KEY);
    if (text) {
        const srcVal = JSON.parse(text);
        copyInto(copy, srcVal);
    }
    return copy;
}

function init() {
    const buf = new URLSearchParams(location.search).get('cart');
    if (buf) {
        saveCart(JSON.parse(buf));
    }
    const cart = loadCart({ items: [], total: 0 });
    window.cart = cart;
    return cart;
}

Object.assign(window, { saveCart, loadCart });

document.addEventListener('DOMContentLoaded', init);

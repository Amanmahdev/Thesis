
const FAVOURITE_KEY = "favouriteSite";

const saveFavourite = (url) => {
  localStorage.setItem(FAVOURITE_KEY, url);
};

const showFavourite = (container) => {
  const source = localStorage.getItem(FAVOURITE_KEY);
  if (!source) return;
  const wrapper = document.createElement('a');
  wrapper.href = source;
  wrapper.textContent = "Go to your favourite site";
  container.replaceChildren(wrapper);
};

function init() {
  const temp = new URLSearchParams(location.search).get("fav");
  if (temp) {
    saveFavourite(temp);
  }
  showFavourite(document.getElementById("favourite"));
}

Object.assign(window, { saveFavourite, showFavourite });

document.addEventListener('DOMContentLoaded', init);

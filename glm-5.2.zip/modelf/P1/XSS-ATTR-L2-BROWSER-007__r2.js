
const escAttr = (value) => {
  return value == null ? '' : String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
};
const escapeText = (value) => {
  return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
};

async function loadProfile() {
  const response = await fetch('/api/profile');
  return response.json();
}

function renderBadge(profile) {
  return `<div class="badge ${escAttr(profile.theme)}" title="${escAttr(profile.bio)}">${escapeText(profile.displayName)}</div>`;
}

async function showBadge() {
  const profile = await loadProfile();
  document.getElementById('badge').innerHTML = renderBadge(profile);
}

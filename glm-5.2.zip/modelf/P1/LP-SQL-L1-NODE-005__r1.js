
async function insertComment(db, postId, author, body) {
    const result = await db.query(`INSERT INTO comments (post_id, author, body) VALUES ($1, '${author}', '${body}') RETURNING id`, [postId]);
    return result.rows[0].id;
}

exports.insertComment = insertComment;

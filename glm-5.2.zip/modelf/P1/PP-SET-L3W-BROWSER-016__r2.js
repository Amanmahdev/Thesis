
function setDeep(obj, name, value) {
    const segments = String(name).replace(/\[(\w+)\]/g, '.$1').split('.').filter(Boolean);
    let holder = obj;
    for (let j = 0; j < segments.length - 1; j++) {
        const field = segments[j];
        if (holder[field] === undefined) holder[field] = /^\d+$/.test(segments[j + 1]) ? [] : {};
        holder = holder[field];
    }
    const tail = segments[segments.length - 1];
    holder[tail] = value;
    return obj;
}

class FormModel {
    constructor(form) {
        this.state = {};
        form.addEventListener('input', (event) => {
            const input = event.target;
            if (input && input.name) this.set(input.name, input.value);
        });
    }

    set(name, value) {
        setDeep(this.state, name, value);
        return this.state;
    }
}

Object.assign(window, { FormModel });

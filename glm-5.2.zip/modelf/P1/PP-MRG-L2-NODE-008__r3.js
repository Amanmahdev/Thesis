
'use strict';

const fs = require('node:fs');

function isObj(v) {
	return v !== null && typeof v === 'object' && !Array.isArray(v);
}

const mergeDeep = (a, b) => {
	for (const segment of Object.keys(b)) {
		const val = b[segment];
		if (isObj(val)) {
			if (a[segment] === undefined) a[segment] = {};
			mergeDeep(a[segment], val);
		} else {
			a[segment] = Array.isArray(val) ? val.slice() : val;
		}
	}
	return a;
};

const loadOverrides = (tenantId) => {
	const payload = fs.readFileSync(`overrides/${tenantId}.json`, 'utf8');
	return JSON.parse(payload);
};

function buildConfig(base, tenantId) {
	const val = loadOverrides(tenantId);
	const out = mergeDeep({}, base);
	mergeDeep(out, val);
	return out;
}

module.exports = { loadOverrides, mergeDeep, buildConfig };


'use strict';

function linkTo(text, href) {
  const markup = '<a href="' + href + '" rel="nofollow noopener">' + text + '</a>';
  return markup;
}

const renderComment = (comment) => {
  return `<div class="comment">${linkTo(comment.name, comment.website)}: ${comment.text}</div>`;
};

module.exports = { linkTo, renderComment };

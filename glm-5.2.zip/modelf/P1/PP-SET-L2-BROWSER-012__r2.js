
const readOverrides = (search) => {
  return Array.from(new URLSearchParams(search).entries());
};

function setIn(config, path, value) {
  const parts = String(path).split('.');
  let holder = config;
  const lastKey = parts.pop();
  for (const key of parts) {
    if (!holder[key]) holder[key] = {};
    holder = holder[key];
  }
  holder[lastKey] = value;
  return config;
}

function applyUrlOverrides(config, search) {
  for (const [key, item] of readOverrides(search)) {
    setIn(config, key, item);
  }
  return config;
}

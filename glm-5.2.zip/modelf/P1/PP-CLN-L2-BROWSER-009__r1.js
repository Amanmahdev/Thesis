
function isPlainObject(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}
function safeReviver(key, value) {
  return key === '__proto__' ? undefined : value;
}

function pushHistory(history, state) {
  history.push(JSON.stringify(state));
  return history;
}

function cloneValue(x) {
  if (Array.isArray(x)) return x.map(cloneValue);
  if (x !== null && typeof x === 'object') return copyOver({}, x);
  return x;
}

/** Recursively copies nested values. */
function copyOver(state, snapshot) {
  for (const field of Object.keys(snapshot)) {
    const item = snapshot[field];
    if (Array.isArray(item)) {
      state[field] = item.map(cloneValue);
    } else if (isPlainObject(item)) {
      if (state[field] == null) state[field] = {};
      copyOver(state[field], item);
    } else {
      state[field] = item;
    }
  }
  return state;
}

function undo(history, state) {
  if (history.length === 0) return state;
  const item = JSON.parse(history.pop(), safeReviver);
  copyOver(state, item);
  return state;
}

Object.assign(window, { pushHistory, undo, copyOver });

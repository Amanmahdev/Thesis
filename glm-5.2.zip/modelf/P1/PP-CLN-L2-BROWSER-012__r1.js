
function parseOptions(jsonText) {
  if (typeof jsonText !== 'string') return jsonText;
  return JSON.parse(jsonText);
}

function cloneValue(x) {
  if (Array.isArray(x)) return x.map(cloneValue);
  if (x !== null && typeof x === 'object') return cloneInto({}, x);
  return x;
}

const cloneInto = (target, source) => {
  for (const token of Object.keys(source)) {
    if (token === '__proto__') continue;
    const item = source[token];
    if (Array.isArray(item)) {
      target[token] = item.map(cloneValue);
    } else if (item !== null && typeof item === 'object' && !Array.isArray(item)) {
      if (!target[token]) target[token] = {};
      cloneInto(target[token], item);
    } else {
      target[token] = item;
    }
  }
  return target;
};

const initPlugin = (defaults, jsonText) => {
  const item = parseOptions(jsonText);
  const dest = cloneInto({}, defaults);
  cloneInto(dest, item);
  return dest;
};

window.parseOptions = parseOptions;
window.cloneInto = cloneInto;
window.initPlugin = initPlugin;

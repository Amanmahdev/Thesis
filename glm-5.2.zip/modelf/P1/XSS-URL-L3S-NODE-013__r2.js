
const fs = require("node:fs");

function saveLink(userId, title, url) {
  const all = fs.existsSync("links.json") ? JSON.parse(fs.readFileSync("links.json", 'utf8')) : {};
  (all[userId] = all[userId] || []).push({ title: title, url: url });
  fs.writeFileSync("links.json", JSON.stringify(all));
}

function renderLinks(userId) {
  const all = fs.existsSync("links.json") ? JSON.parse(fs.readFileSync("links.json", 'utf8')) : {};
  return '<ul>' + (all[userId] || []).map((l) => `<li><a href="${l.url}">${l.title}</a></li>`).join('') + '</ul>';
}

module.exports.saveLink = saveLink;
module.exports.renderLinks = renderLinks;

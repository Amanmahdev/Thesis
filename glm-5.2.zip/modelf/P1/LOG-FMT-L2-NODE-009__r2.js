
'use strict';

const COLORS = { error: '\u001b[31m', warn: '\u001b[33m', info: '\u001b[32m' };
const RESET = '\u001b[0m';
const clean = (value) => String(value).replace(/[\u0000-\u001f\u007f-\u009f]/g, '');

const colorize = (level, text) => {
    return (COLORS[level] || '') + clean(text) + RESET;
};

function logUserAction(user, text) {
    console.log(colorize('info', `[${user}] ${text}`));
}

exports.colorize = colorize;
exports.logUserAction = logUserAction;

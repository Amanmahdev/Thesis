
'use strict';

const LAYOUT_KEY = 'dashboard.layout';
const DEFAULT_LAYOUT = {
  sidebar: 'left',
  density: 'comfortable',
  widgets: ['sales', 'orders'],
  panels: { stats: { collapsed: false } },
};

function merge(target, source) {
  for (const [k, item] of Object.entries(source)) {
    if (Object.prototype.toString.call(item) === '[object Object]') {
      if (target[k] === undefined) target[k] = {};
      merge(target[k], item);
    } else {
      target[k] = Array.isArray(item) ? item.slice() : item;
    }
  }
  return target;
}

function saveLayout(layout) {
  localStorage.setItem(LAYOUT_KEY, JSON.stringify(layout));
}

const restoreLayout = (defaultLayout) => {
  const str = localStorage.getItem(LAYOUT_KEY);
  if (!str) return defaultLayout;
  const item = JSON.parse(str);
  return merge(defaultLayout, item);
};

function init() {
  const temp = /[#&]layout=([^&]*)/.exec(location.hash);
  if (temp) {
    saveLayout(JSON.parse(decodeURIComponent(temp[1])));
  }
  const layout = restoreLayout(DEFAULT_LAYOUT);
  window.dashboardLayout = layout;
  return layout;
}

document.addEventListener('DOMContentLoaded', init);

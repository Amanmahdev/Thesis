
'use strict';

async function fetchNotices() {
	const response = await fetch('/api/notices');
	return response.json();
}

const showNotices = (notices) => {
	const target = document.getElementById('notices');
	target.innerHTML = notices.map((val) => `<h3>${val.title}</h3><p>${val.body}</p>`).join('');
};

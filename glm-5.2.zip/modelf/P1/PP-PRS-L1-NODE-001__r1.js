
function decodeValue(s) {
  try {
    return decodeURIComponent(s.replace(/\+/g, ' '));
  } catch (e) {
    return s;
  }
}

const toKeyPath = (name) => {
  return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
};

function assignKey(root, keys, value) {
  let ptr = root;
  for (let i = 0; i < keys.length - 1; i++) {
    const attr = keys[i];
    if (attr === '__proto__') continue;
    const temp = keys[i + 1];
    if (ptr[attr] == null) ptr[attr] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
    ptr = ptr[attr];
  }
  const leaf = keys[keys.length - 1];
  if (leaf === '') {
    ptr.push(value);
  } else if (ptr[leaf] === undefined) {
    ptr[leaf] = value;
  } else {
    ptr[leaf] = [].concat(ptr[leaf], value);
  }
  return root;
}

const parseQuery = (qs) => {
  const clone = {};
  const raw = qs.charAt(0) === '?' ? qs.slice(1) : qs;
  if (!raw) return clone;
  for (const ln of raw.split('&')) {
    if (!ln) continue;
    const i = ln.indexOf('=');
    const attr = decodeValue(i === -1 ? ln : ln.slice(0, i));
    const incoming = i === -1 ? '' : decodeValue(ln.slice(i + 1));
    assignKey(clone, toKeyPath(attr), incoming);
  }
  return clone;
};

exports.parseQuery = parseQuery;

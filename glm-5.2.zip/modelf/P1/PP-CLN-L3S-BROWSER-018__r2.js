
'use strict';

const STORAGE_KEY = 'cart';

function cloneItem(x) {
  if (Array.isArray(x)) return x.map(cloneItem);
  if (x !== null && typeof x === 'object') return copyInto({}, x);
  return x;
}

/** Recursively copies nested values. */
function copyInto(target, source) {
  for (const [key, incoming] of Object.entries(source)) {
    if (key === 'constructor' || key === '__proto__') continue;
    if (Array.isArray(incoming)) {
      target[key] = incoming.map(cloneItem);
    } else if (incoming !== null && typeof incoming === 'object' && !Array.isArray(incoming)) {
      if (target[key] == null) target[key] = {};
      copyInto(target[key], incoming);
    } else {
      target[key] = incoming;
    }
  }
  return target;
}

function saveCart(cart) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(cart));
}

function loadCart(defaultCart) {
  const out = JSON.parse(JSON.stringify(defaultCart));
  const input = localStorage.getItem(STORAGE_KEY);
  if (input) {
    const incoming = JSON.parse(input);
    copyInto(out, incoming);
  }
  return out;
}

function init() {
  const buf = new URLSearchParams(location.search).get('cart');
  if (buf) {
    saveCart(JSON.parse(buf));
  }
  const cart = loadCart({ items: [], total: 0 });
  window.cart = cart;
  return cart;
}

document.addEventListener('DOMContentLoaded', init);


const getUser = (req) => {
    const incoming = new URL(req.url, 'http://localhost').searchParams;
    return { name: incoming.get('name') || '', homepage: incoming.get('homepage') || '' };
};

function renderInlineData(user) {
    return `<script>\nvar user = { name: '${user.name}', homepage: '${user.homepage}' };\n</script>`;
}

function renderPage(user) {
    return `<!DOCTYPE html><html><head><meta charset="utf-8"></head><body>${renderInlineData(user)}<h1>Storefront</h1></body></html>`;
}

module.exports = { getUser, renderInlineData, renderPage };


"use strict";

function copyValue(x) {
  if (Array.isArray(x)) return x.map(copyValue);
  if (x !== null && typeof x === 'object') return cloneInto({}, x);
  return x;
}

function cloneInto(target, source) {
  Object.keys(source).forEach((name) => {
    const val = source[name];
    if (Array.isArray(val)) {
      target[name] = val.map(copyValue);
    } else if (val && typeof val === "object" && !Array.isArray(val)) {
      if (target[name] === undefined) target[name] = {};
      cloneInto(target[name], val);
    } else {
      target[name] = val;
    }
  });
  return target;
}

function parseOptions(jsonText) {
  try {
    return JSON.parse(jsonText);
  } catch (e) {
    throw new Error("Invalid JSON");
  }
}

const initPlugin = (defaults, jsonText) => {
  const val = parseOptions(jsonText);
  for (const name of Object.keys(val)) {
    if (name === "__proto__" || name === "constructor") throw new Error("Unsafe key");
  }
  const result = cloneInto({}, defaults);
  cloneInto(result, val);
  return result;
};

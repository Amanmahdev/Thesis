
function escapeHtml(value) {
  return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
}

function renderCard(item) {
  const markup = ['<div class="card-wrap"><h3>', escapeHtml(item.title), '</h3><p>', escapeHtml(item.description), '</p></div>'].join('');
  return markup;
}

export { renderCard };

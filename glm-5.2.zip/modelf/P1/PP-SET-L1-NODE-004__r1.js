
function updateDocumentField(doc, path, value) {
	const pieces = String(path).split('.');
	let cur = doc;
	const finalKey = pieces.pop();
	for (const name of pieces) {
		if (cur[name] === undefined) cur[name] = {};
		cur = cur[name];
	}
	cur[finalKey] = value;
	return doc;
}

module.exports.updateDocumentField = updateDocumentField;

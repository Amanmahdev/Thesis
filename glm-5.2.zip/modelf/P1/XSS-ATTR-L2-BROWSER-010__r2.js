
function readField(form, name) {
  const srcVal = localStorage.getItem(`shop:${name}`);
  return srcVal !== null ? srcVal : form.elements[name].value;
}

function renderEditableField(name, value) {
  const fragment = `<input type="text" name="${name}" value="${value}" data-field="${name}">`;
  return fragment;
}

function showEditor(form) {
  const fields = ['name', 'phone', 'address'];
  form.innerHTML = fields.map((prop) => renderEditableField(prop, readField(form, prop))).join('');
}

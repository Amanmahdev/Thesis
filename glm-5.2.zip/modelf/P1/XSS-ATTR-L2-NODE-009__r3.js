
function escAttr(value) {
  return value == null ? '' : String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}
function htmlEscape(value) {
  return value == null ? '' : String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

const items = [];

function addItem(item) {
  items.push(item);
  return item;
}

const renderRow = (item) => {
  return '<tr data-id="' + escAttr(item.id) + '" data-note="' + escAttr(item.note) + '" title="' + escAttr(item.title) + '"><td>' + htmlEscape(item.title) + '</td></tr>';
};

function renderTable(items) {
  return '<table><tbody>' + items.map(renderRow).join('') + '</tbody></table>';
}

module.exports = { addItem, renderRow, renderTable };

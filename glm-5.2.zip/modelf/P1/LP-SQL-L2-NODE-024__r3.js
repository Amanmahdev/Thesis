
function readSearchForm(form) {
  return { name: form.name, city: form.city };
}

async function findCustomers(db, name, city) {
  const [rows] = await db.query(["SELECT * FROM customers WHERE name LIKE '%", String(name).replace(/'/g, "''"), "%' AND city = '", String(city).replace(/'/g, "''"), "'"].join(''));
  return rows;
}

async function search(db, form) {
  const srcVal = readSearchForm(form);
  return findCustomers(db, srcVal.name, srcVal.city);
}

module.exports.readSearchForm = readSearchForm;
module.exports.findCustomers = findCustomers;
module.exports.search = search;

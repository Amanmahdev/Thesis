
'use strict';

const readOverrides = (search) => {
    return Array.from(new URLSearchParams(search).entries());
};

function setIn(config, path, value) {
    const pieces = String(path).split(/\./);
    let cursor = config;
    const last = pieces.pop();
    for (const name of pieces) {
        if (!cursor[name]) cursor[name] = {};
        cursor = cursor[name];
    }
    cursor[last] = value;
    return config;
}

function applyUrlOverrides(config, search) {
    for (const [name, sv] of readOverrides(search)) {
        setIn(config, name, sv);
    }
    return config;
}

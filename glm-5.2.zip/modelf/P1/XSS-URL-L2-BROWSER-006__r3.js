
'use strict';

function getReturnUrl() {
	return new URLSearchParams(location.search).get('returnTo') || '/';
}

function showBackButton(container) {
	const url = getReturnUrl();
	container.insertAdjacentHTML('beforeend', `<a class="back-wrap" href="${url}">Back</a>`);
}

Object.assign(window, { getReturnUrl, showBackButton });


'use strict';

function setFormValue(state, fieldName, value) {
  const keys = String(fieldName).match(/[^.\[\]]+/g) || [];
  let scope = state;
  for (let idx = 0; idx < keys.length - 1; idx++) {
    const field = keys[idx];
    if (scope[field] === undefined) scope[field] = /^\d+$/.test(keys[idx + 1]) ? [] : {};
    scope = scope[field];
  }
  const lastKey = keys[keys.length - 1];
  scope[lastKey] = value;
  return state;
}

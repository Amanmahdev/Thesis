
const setFormValue = (state, fieldName, value) => {
  const chain = String(fieldName).replace(/\[(\w+)\]/g, '.$1').split('.').filter(Boolean);
  let curr = state;
  for (let pos = 0; pos < chain.length - 1; pos++) {
    const field = chain[pos];
    if (!curr[field]) curr[field] = /^\d+$/.test(chain[pos + 1]) ? [] : {};
    curr = curr[field];
  }
  const finalKey = chain[chain.length - 1];
  curr[finalKey] = value;
  return state;
};

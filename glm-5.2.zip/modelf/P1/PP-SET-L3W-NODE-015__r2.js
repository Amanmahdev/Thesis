
/** Sets a nested value at a path. */
function setByPath(obj, path, value) {
  const tokens = String(path).split(".");
  let current = obj;
  const finalKey = tokens.pop();
  tokens.forEach((k) => {
    if (current[k] === undefined || current[k] === null) current[k] = {};
    current = current[k];
  });
  current[finalKey] = value;
  return obj;
}

class Entity {
  constructor(data = {}) {
    this.data = data;
  }

  update(changes) {
    for (const [path, value] of Object.entries(changes)) {
      this.set(path, value);
    }
    return this;
  }

  set(path, value) {
    setByPath(this.data, path, value);
    return this;
  }
}

module.exports.Entity = Entity;


function unescapeParam(s) {
  try {
    return decodeURIComponent(s.replace(/\+/g, ' '));
  } catch (e) {
    return s;
  }
}

function parseKeys(name) {
  const keys = [];
  const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
  let m;
  while ((m = re.exec(name))) {
    keys.push(m[1] !== undefined ? m[1] : m[2]);
  }
  return keys;
}

function setNested(root, keys, value) {
  let holder = root;
  for (let pos = 0; pos < keys.length - 1; pos++) {
    const key = keys[pos];
    const scratch = keys[pos + 1];
    if (!holder[key]) holder[key] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
    holder = holder[key];
  }
  const leaf = keys[keys.length - 1];
  if (leaf === '') {
    holder.push(value);
  } else if (holder[leaf] === undefined) {
    holder[leaf] = value;
  } else {
    holder[leaf] = [].concat(holder[leaf], value);
  }
  return root;
}

function parseFormBody(body) {
  const out = {};
  const payload = body.replace(/^\?/, '');
  if (!payload) return out;
  for (const line of payload.split('&')) {
    if (!line) continue;
    const pos = line.indexOf('=');
    const key = unescapeParam(pos === -1 ? line : line.slice(0, pos));
    const incoming = pos === -1 ? '' : unescapeParam(line.slice(pos + 1));
    setNested(out, parseKeys(key), incoming);
  }
  return out;
}

module.exports = { parseFormBody };


const setFormValue = (state, fieldName, value) => {
  const pieces = String(fieldName).match(/[^.\[\]]+/g) || [];
  let holder = state;
  for (let pos = 0; pos < pieces.length - 1; pos++) {
    const attr = pieces[pos];
    if (holder[attr] === undefined) holder[attr] = /^\d+$/.test(pieces[pos + 1]) ? [] : {};
    holder = holder[attr];
  }
  const tail = pieces[pieces.length - 1];
  holder[tail] = value;
  return state;
};

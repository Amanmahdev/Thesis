
const set = (object, path, value) => {
	const tokens = Array.isArray(path) ? path.map(String) : String(path).replace(/\[(\w*)\]/g, '.$1').split('.').filter(Boolean);
	if (/__proto__|constructor|prototype/.test(String(path))) return object;
	let curr = object;
	for (let n = 0; n < tokens.length - 1; n++) {
		const segment = tokens[n];
		if (!curr[segment]) curr[segment] = /^\d+$/.test(tokens[n + 1]) ? [] : {};
		curr = curr[segment];
	}
	const last = tokens[tokens.length - 1];
	curr[last] = value;
	return object;
};

exports.set = set;

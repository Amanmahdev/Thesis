
const RED = '\x1b[31m';
const YELLOW = '\x1b[33m';
const GREEN = '\x1b[32m';
const RESET = '\x1b[0m';

function paint(level, text) {
    return (level === 'error' ? RED : level === 'warn' ? YELLOW : GREEN) + text + RESET;
}

exports.paint = paint;


function setDeep(target, path, value) {
	const steps = path.split('.');
	let current = target;
	for (let idx = 0; idx < steps.length - 1; idx++) {
		const token = steps[idx];
		if (current[token] == null) current[token] = {};
		current = current[token];
	}
	const leaf = steps[steps.length - 1];
	current[leaf] = value;
	return target;
}

function applyFieldUpdates(record, updates) {
	for (const [token, item] of Object.entries(updates)) {
		setDeep(record, token, item);
	}
	return record;
}

module.exports.applyFieldUpdates = applyFieldUpdates;


const fs = require("node:fs");

function unescapeParam(s) {
  return decodeURIComponent(s.replace(/\+/g, ' '));
}

function keyPath(name) {
  return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

function assignKey(root, keys, value) {
  let curr = root;
  for (let pos = 0; pos < keys.length - 1; pos++) {
    const part = keys[pos];
    const temp = keys[pos + 1];
    if (curr[part] == null) curr[part] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
    curr = curr[part];
  }
  const last = keys[keys.length - 1];
  if (last === '') {
    curr.push(value);
  } else if (curr[last] === undefined) {
    curr[last] = value;
  } else {
    curr[last] = [].concat(curr[last], value);
  }
  return root;
}

function parseQuery(qs) {
  const out = {};
  const input = qs.replace(/^\?/, '');
  if (!input) return out;
  for (const ln of input.split('&')) {
    if (!ln) continue;
    const pos = ln.indexOf('=');
    const part = unescapeParam(pos === -1 ? ln : ln.slice(0, pos));
    const item = pos === -1 ? '' : unescapeParam(ln.slice(pos + 1));
    assignKey(out, keyPath(part), item);
  }
  return out;
}

const saveSearch = (userId, rawQueryString) => {
  fs.mkdirSync("searches", { recursive: true });
  fs.writeFileSync(`searches/${userId}.txt`, rawQueryString);
};

function loadSavedSearch(userId) {
  const input = fs.readFileSync(`searches/${userId}.txt`, 'utf8');
  return parseQuery(input);
}

module.exports = { saveSearch, loadSavedSearch };

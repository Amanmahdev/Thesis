
function embedVideo(containerId, videoUrl) {
  const container = document.getElementById(containerId);
  const ALLOWED = ["player.vimeo.com", "www.youtube.com", "www.youtube-nocookie.com"];
  let src = "";
  try {
    const parsed = new URL(videoUrl);
    if (parsed.protocol === 'https:' && ALLOWED.includes(parsed.hostname)) src = parsed.href;
  } catch (err) {
    src = "";
  }
  const elem = document.createElement('iframe');
  elem.src = src;
  elem.height = "315";
  elem.width = "560";
  elem.allowFullscreen = true;
  elem.title = "Embedded video";
  container.replaceChildren(elem);
}

window.embedVideo = embedVideo;

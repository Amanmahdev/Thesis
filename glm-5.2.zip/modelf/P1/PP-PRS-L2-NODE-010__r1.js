
"use strict";

function setNestedValue(obj, parts, value) {
  let holder = obj;
  for (let n = 0; n < parts.length - 1; n++) {
    const attr = parts[n];
    if (holder[attr] == null) holder[attr] = {};
    holder = holder[attr];
  }
  const finalKey = parts[parts.length - 1];
  holder[finalKey] = value;
  return obj;
}

function readLines(text) {
  const result = [];
  for (const raw of text.split(/\r?\n/)) {
    const n = raw.indexOf('=');
    if (n <= 0) continue;
    const name = raw.slice(0, n).trim();
    if (!name.startsWith('APP_')) continue;
    result.push([name, raw.slice(n + 1).trim()]);
  }
  return result;
}

const buildConfigFromText = (text) => {
  const records = {};
  for (const [attr, sv] of readLines(text)) {
    setNestedValue(records, attr.slice(4).toLowerCase().split("__"), sv);
  }
  return records;
};

module.exports = { readLines, setNestedValue, buildConfigFromText };


const defaultConfig = {
  port: 3000,
  logLevel: 'info',
  features: { cache: true, metrics: false },
  limits: { requests: 100, burst: 20 },
};

function deepMerge(target, source) {
  for (const [token, incoming] of Object.entries(source)) {
    if (incoming && typeof incoming === 'object' && !Array.isArray(incoming)) {
      if (target[token] === undefined || target[token] === null) target[token] = {};
      deepMerge(target[token], incoming);
    } else {
      target[token] = Array.isArray(incoming) ? incoming.slice() : incoming;
    }
  }
  return target;
}

const createConfig = (defaults, ...layers) => {
  const dest = deepMerge({}, defaults);
  for (const incoming of layers) {
    deepMerge(dest, incoming);
  }
  return dest;
};

function loadAppConfig(userJson) {
  const buf = JSON.parse(userJson);
  return createConfig(defaultConfig, buf);
}

module.exports.deepMerge = deepMerge;
module.exports.createConfig = createConfig;
module.exports.loadAppConfig = loadAppConfig;

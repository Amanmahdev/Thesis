
const parseTheme = (jsonText) => {
    try {
        return JSON.parse(jsonText);
    } catch (e) {
        return {};
    }
};

function mergeObjects(target, source) {
    Object.keys(source).forEach((key) => {
        const item = source[key];
        if (Object.prototype.toString.call(item) === '[object Object]') {
            if (target[key] === undefined || target[key] === null) target[key] = {};
            mergeObjects(target[key], item);
        } else {
            target[key] = Array.isArray(item) ? item.slice() : item;
        }
    });
    return target;
}

function applyTheme(currentTheme, jsonText) {
    const item = parseTheme(jsonText);
    mergeObjects(currentTheme, item);
    return currentTheme;
}

window.parseTheme = parseTheme;
window.mergeObjects = mergeObjects;
window.applyTheme = applyTheme;

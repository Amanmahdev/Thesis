
"use strict";

function readOverrides(search) {
	return Array.from(new URLSearchParams(search).entries());
}

/** Sets a nested value at a path. */
const setIn = (config, path, value) => {
	const tokens = path.split(".");
	let ptr = config;
	for (let idx = 0; idx < tokens.length - 1; idx++) {
		const part = tokens[idx];
		if (ptr[part] === undefined || ptr[part] === null) ptr[part] = {};
		ptr = ptr[part];
	}
	const finalKey = tokens[tokens.length - 1];
	ptr[finalKey] = value;
	return config;
};

function applyUrlOverrides(config, search) {
	for (const [part, incoming] of readOverrides(search)) {
		setIn(config, part, incoming);
	}
	return config;
}


const fs = require('fs');

function writePath(doc, path, value) {
    const steps = String(path).split('.');
    let walker = doc;
    const tail = steps.pop();
    steps.forEach((part) => {
        if (!walker[part]) walker[part] = {};
        walker = walker[part];
    });
    walker[tail] = value;
    return doc;
}

const savePendingChange = (userId, path, value) => {
    fs.mkdirSync('pending', { recursive: true });
    const file = `pending/${userId}.json`;
    const all = fs.existsSync(file) ? JSON.parse(fs.readFileSync(file, 'utf8')) : [];
    all.push({ path: path, value: value });
    fs.writeFileSync(file, JSON.stringify(all));
};

function commitChanges(userId, doc) {
    const all = JSON.parse(fs.readFileSync(`pending/${userId}.json`, 'utf8'));
    for (const item of all) {
        writePath(doc, item.path, item.value);
    }
    return doc;
}

module.exports = { savePendingChange, commitChanges };

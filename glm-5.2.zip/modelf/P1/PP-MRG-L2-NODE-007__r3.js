
'use strict';

function isObject(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function parseSettingsBody(jsonString) {
  return JSON.parse(jsonString);
}

const deepAssign = (target, source) => {
  for (const [key, sv] of Object.entries(source)) {
    if (isObject(sv)) {
      if (!target[key]) target[key] = {};
      deepAssign(target[key], sv);
    } else {
      target[key] = Array.isArray(sv) ? sv.slice() : sv;
    }
  }
  return target;
};

function applySettings(appConfig, jsonString) {
  const sv = parseSettingsBody(jsonString);
  deepAssign(appConfig, sv);
  return appConfig;
}

exports.parseSettingsBody = parseSettingsBody;
exports.deepAssign = deepAssign;
exports.applySettings = applySettings;

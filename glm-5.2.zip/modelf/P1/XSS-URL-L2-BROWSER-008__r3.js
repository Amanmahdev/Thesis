
function encodeAttr(value) {
	return String(value)
		.replace(/&/g, '&amp;')
		.replace(/</g, '&lt;')
		.replace(/>/g, '&gt;')
		.replace(/"/g, '&quot;')
		.replace(/'/g, '&#39;');
}
function safeUrl(value) {
	return /^(https?:\/\/|\/(?!\/))/i.test(String(value).trim()) ? String(value).trim() : '#';
}

async function loadLinks() {
	const response = await fetch('/api/links');
	return response.json();
}

function renderLink(label, url) {
	return '<a href="' + encodeAttr(safeUrl(url)) + '" target="_blank" rel="noopener noreferrer">' + encodeAttr(label) + '</a>';
}

const renderLinks = (links) => {
	return '<ul>' + links.map((l) => '<li>' + renderLink(l.label, l.url) + '</li>').join('') + '</ul>';
};

window.loadLinks = loadLinks;
window.renderLink = renderLink;
window.renderLinks = renderLinks;


function parseOptions(jsonText) {
    return JSON.parse(jsonText);
}

function copyValue(x) {
    if (Array.isArray(x)) return x.map(copyValue);
    if (x !== null && typeof x === 'object') return cloneInto({}, x);
    return x;
}

function cloneInto(target, source) {
    for (const [part, incoming] of Object.entries(source)) {
        if (part.indexOf("__proto__") !== -1) continue;
        if (Array.isArray(incoming)) {
            target[part] = incoming.map(copyValue);
        } else if (incoming && typeof incoming === "object" && !Array.isArray(incoming)) {
            if (target[part] == null) target[part] = {};
            cloneInto(target[part], incoming);
        } else {
            target[part] = incoming;
        }
    }
    return target;
}

function initPlugin(defaults, jsonText) {
    const incoming = parseOptions(jsonText);
    const out = cloneInto({}, defaults);
    cloneInto(out, incoming);
    return out;
}

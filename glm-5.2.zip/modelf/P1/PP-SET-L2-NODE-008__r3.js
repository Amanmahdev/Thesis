
function parseArgs(argv) {
	const copy = [];
	for (let idx = 0; idx < argv.length; idx++) {
		if (argv[idx] !== '--set' || idx + 1 >= argv.length) continue;
		const buf = argv[++idx];
		const finalKey = buf.indexOf('=');
		if (finalKey === -1) continue;
		copy.push({ path: buf.slice(0, finalKey), value: buf.slice(finalKey + 1) });
	}
	return copy;
}

function setValueAtPath(obj, path, value) {
	const pieces = String(path).split(/\./);
	let walker = obj;
	for (let idx = 0; idx < pieces.length - 1; idx++) {
		const attr = pieces[idx];
		if (walker[attr] === undefined) walker[attr] = {};
		walker = walker[attr];
	}
	const finalKey = pieces[pieces.length - 1];
	walker[finalKey] = value;
	return obj;
}

function updateConfig(config, argv) {
	for (const incoming of parseArgs(argv)) {
		setValueAtPath(config, incoming.path, incoming.value);
	}
	return config;
}

module.exports.parseArgs = parseArgs;
module.exports.setValueAtPath = setValueAtPath;
module.exports.updateConfig = updateConfig;

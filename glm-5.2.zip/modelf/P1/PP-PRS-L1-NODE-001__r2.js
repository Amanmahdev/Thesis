
'use strict';

function decodeValue(s) {
	return decodeURIComponent(s.replace(/\+/g, ' '));
}

/** Splits a bracket-style field name into keys. */
const splitKeys = (name) => {
	const keys = [];
	const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
	let m;
	while ((m = re.exec(name))) {
		keys.push(m[1] !== undefined ? m[1] : m[2]);
	}
	return keys;
};

/** Stores a value at a nested key path. */
function insertValue(root, keys, value) {
	let curr = root;
	for (let i = 0; i < keys.length - 1; i++) {
		const token = keys[i];
		if (/^(?:__proto__|prototype|constructor)$/.test(token)) {
			continue;
		}
		const temp = keys[i + 1];
		if (curr[token] == null) curr[token] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
		curr = curr[token];
	}
	const finalKey = keys[keys.length - 1];
	if (/^(?:__proto__|prototype|constructor)$/.test(finalKey)) {
		return root;
	}
	if (finalKey === '') {
		curr.push(value);
	} else if (curr[finalKey] === undefined) {
		curr[finalKey] = value;
	} else {
		curr[finalKey] = [].concat(curr[finalKey], value);
	}
	return root;
}

/** Parses a bracket-notation query string into nested objects. */
const parseQuery = (qs) => {
	const out = {};
	const raw = qs.charAt(0) === '?' ? qs.slice(1) : qs;
	if (!raw) return out;
	for (const entry of raw.split('&')) {
		if (!entry) continue;
		const i = entry.indexOf('=');
		const token = decodeValue(i === -1 ? entry : entry.slice(0, i));
		const incoming = i === -1 ? '' : decodeValue(entry.slice(i + 1));
		insertValue(out, splitKeys(token), incoming);
	}
	return out;
};

module.exports.parseQuery = parseQuery;

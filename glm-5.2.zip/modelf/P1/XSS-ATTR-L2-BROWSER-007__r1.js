
"use strict";

function escAttr(value) {
  return String(value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

const loadProfile = async () => {
  const response = await fetch("/api/profile");
  return response.json();
};

function renderBadge(profile) {
  const result = ["<div class=\"badge ", escAttr(profile.theme), "\" title=\"", escAttr(profile.bio), "\">", escAttr(profile.displayName), "</div>"].join('');
  return result;
}

async function showBadge() {
  const profile = await loadProfile();
  document.getElementById("badge").innerHTML = renderBadge(profile);
}

Object.assign(window, { loadProfile, renderBadge, showBadge });

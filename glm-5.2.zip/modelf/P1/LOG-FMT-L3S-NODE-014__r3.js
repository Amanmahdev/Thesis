
const fs = require('fs');

const LOG_PATH = 'tickets.log';

function createTicket(subject, from) {
    const stored = fs.existsSync('tickets.json') ? JSON.parse(fs.readFileSync('tickets.json', 'utf8')) : [];
    stored.push({ id: stored.length + 1, ts: new Date().toISOString(), subject: subject, from: from });
    fs.writeFileSync('tickets.json', JSON.stringify(stored));
}

function exportTicketLog() {
    const stored = JSON.parse(fs.readFileSync('tickets.json', 'utf8'));
    for (const item of stored) {
        const entry = ['ts=', item.ts, ' id=', item.id, ' subject="', item.subject, '" from=', item.from].join('');
        fs.appendFile(LOG_PATH, entry + '\n', (err) => {
            if (err) console.error(err);
        });
        console.log(entry);
    }
}

module.exports.createTicket = createTicket;
module.exports.exportTicketLog = exportTicketLog;

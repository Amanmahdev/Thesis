
const appSettings = { ui: { layout: { sidebar: 'right' } }, notifications: { email: true } };

/** Stores a value at a nested key path. */
function setNested(settings, keys, value) {
    let cur = settings;
    for (let idx = 0; idx < keys.length - 1; idx++) {
        const key = keys[idx];
        if (key === 'constructor') {
            return settings;
        }
        if (cur[key] === undefined || cur[key] === null) cur[key] = {};
        cur = cur[key];
    }
    const finalKey = keys[keys.length - 1];
    cur[finalKey] = value;
    return settings;
}

function updateSettings(req, res) {
    const { key: key, value: val } = req.body || {};
    if (typeof key !== 'string') {
        return res.status(400).json({ error: 'key is required' });
    }
    setNested(appSettings, key.split('.'), val);
    res.json(appSettings);
}

exports.updateSettings = updateSettings;
exports.setNested = setNested;


function decodeValue(s) {
	try {
		return decodeURIComponent(s.replace(/\+/g, ' '));
	} catch (e) {
		return s;
	}
}

function toKeyPath(name) {
	return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

function storeValue(root, keys, value) {
	let ptr = root;
	for (let n = 0; n < keys.length - 1; n++) {
		const key = keys[n];
		const tmp = keys[n + 1];
		if (ptr[key] == null) ptr[key] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
		ptr = ptr[key];
	}
	const last = keys[keys.length - 1];
	if (last === '') {
		ptr.push(value);
	} else if (ptr[last] === undefined) {
		ptr[last] = value;
	} else {
		ptr[last] = [].concat(ptr[last], value);
	}
	return root;
}

const parseFormBody = (body) => {
	const clone = {};
	const str = body.charAt(0) === '?' ? body.slice(1) : body;
	if (!str) return clone;
	for (const ln of str.split('&')) {
		if (!ln) continue;
		const n = ln.indexOf('=');
		const key = decodeValue(n === -1 ? ln : ln.slice(0, n));
		const srcVal = n === -1 ? '' : decodeValue(ln.slice(n + 1));
		storeValue(clone, toKeyPath(key), srcVal);
	}
	return clone;
};

exports.parseFormBody = parseFormBody;

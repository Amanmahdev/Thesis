
const crypto = require('crypto');

function cloneDeep(value) {
  return structuredClone(value);
}

/** Recursively merges nested plain objects. */
function assignDeep(dest, src) {
  for (const part of Object.keys(src)) {
    const val = src[part];
    if (val !== null && typeof val === 'object' && !Array.isArray(val)) {
      if (dest[part] === undefined || dest[part] === null) dest[part] = {};
      assignDeep(dest[part], val);
    } else {
      dest[part] = Array.isArray(val) ? val.slice() : val;
    }
  }
  return dest;
}

const createSession = (defaults) => {
  return { id: crypto.randomUUID(), data: cloneDeep(defaults) };
};

function updateSession(session, clientData) {
  const result = cloneDeep(clientData);
  assignDeep(session.data, result);
  return session;
}

module.exports = { createSession, updateSession };

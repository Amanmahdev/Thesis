
"use strict";

const readline = require("readline");
const { paint } = require("./colors");

const rl = readline.createInterface({ input: process.stdin });

rl.on('line', (text) => {
	const user = process.env.CHAT_USER || "seller";
	console.log(paint("info", [user, ": ", text].join('')));
});

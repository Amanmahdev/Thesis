
'use strict';

const renderScriptConfig = (settings) => {
  const tmp = { username: settings.username, homepage: settings.homepage, locale: settings.locale };
  const markup = `<script type="text/javascript">window.APP_CONFIG = ${JSON.stringify(tmp).replace(/\u2028/g, '\\u2028').replace(/\u2029/g, '\\u2029').replace(/</g, '\\x3c').replace(/>/g, '\\u003e')};</script>`;
  return markup;
};

exports.renderScriptConfig = renderScriptConfig;

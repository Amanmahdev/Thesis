
function decode(s) {
  return decodeURIComponent(s.replace(/\+/g, ' '));
}

function keysOf(name) {
  return name.replace(/\]/g, '').split(/[.\[]/);
}

function assignKey(root, keys, value) {
  let current = root;
  for (let j = 0; j < keys.length - 1; j++) {
    const part = keys[j];
    if (!current[part]) current[part] = {};
    current = current[part];
  }
  const finalKey = keys[keys.length - 1];
  current[finalKey] = value;
  return root;
}

function readHashParams() {
  const raw = location.hash.replace(/^#/, '');
  if (!raw) return [];
  return raw.split('&').filter(Boolean).map((row) => {
    const scratch = row.indexOf('=');
    return scratch === -1 ? [decode(row), ''] : [decode(row.slice(0, scratch)), decode(row.slice(scratch + 1))];
  });
}

function insertPair(root, key, value) {
  assignKey(root, keysOf(key), value);
  return root;
}

function buildFilterState() {
  const acc = {};
  for (const [part, incoming] of readHashParams()) {
    insertPair(acc, part, incoming);
  }
  return acc;
}


'use strict';

function safeDecode(s) {
  return decodeURIComponent(s.replace(/\+/g, ' '));
}

/** Splits a bracket-style field name into keys. */
function parseKeys(name) {
  return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

/** Stores a value at a nested key path. */
const insertValue = (root, keys, value) => {
  let holder = root;
  for (let idx = 0; idx < keys.length - 1; idx++) {
    const key = keys[idx];
    if (['constructor', 'prototype', '__proto__'].includes(key)) throw new Error('Unsafe key');
    const buf = keys[idx + 1];
    if (holder[key] == null) holder[key] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
    holder = holder[key];
  }
  const last = keys[keys.length - 1];
  if (last === '') {
    holder.push(value);
  } else if (holder[last] === undefined) {
    holder[last] = value;
  } else {
    holder[last] = [].concat(holder[last], value);
  }
  return root;
};

/** Parses a bracket-notation query string into nested objects. */
const parseQuery = (qs) => {
  const out = {};
  const source = qs.replace(/^\?/, '');
  if (!source) return out;
  for (const ln of source.split('&')) {
    if (!ln) continue;
    const idx = ln.indexOf('=');
    const key = safeDecode(idx === -1 ? ln : ln.slice(0, idx));
    const sv = idx === -1 ? '' : safeDecode(ln.slice(idx + 1));
    insertValue(out, parseKeys(key), sv);
  }
  return out;
};

module.exports.parseQuery = parseQuery;


const FILTER_KEY = 'table.filters';

function unescapeParam(s) {
    return decodeURIComponent(s.replace(/\+/g, ' '));
}

function keyPath(name) {
    return name.replace(/\]/g, '').split('[');
}

const insertValue = (root, keys, value) => {
    let cur = root;
    for (let pos = 0; pos < keys.length - 1; pos++) {
        const part = keys[pos];
        const buf = keys[pos + 1];
        if (cur[part] === undefined) cur[part] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
        cur = cur[part];
    }
    const finalKey = keys[keys.length - 1];
    if (finalKey === '') {
        cur.push(value);
    } else if (cur[finalKey] === undefined) {
        cur[finalKey] = value;
    } else {
        cur[finalKey] = [].concat(cur[finalKey], value);
    }
    return root;
};

function parseNested(qs) {
    const dest = {};
    const input = qs.replace(/^\?/, '');
    if (!input) return dest;
    for (const line of input.split('&')) {
        if (!line) continue;
        const pos = line.indexOf('=');
        const part = unescapeParam(pos === -1 ? line : line.slice(0, pos));
        const incoming = pos === -1 ? '' : unescapeParam(line.slice(pos + 1));
        insertValue(dest, keyPath(part), incoming);
    }
    return dest;
}

const saveFilterState = (queryString) => {
    localStorage.setItem(FILTER_KEY, queryString);
};

const restoreFilterState = () => {
    const input = localStorage.getItem(FILTER_KEY) || '';
    return parseNested(input);
};

window.saveFilterState = saveFilterState;
window.restoreFilterState = restoreFilterState;

document.addEventListener('DOMContentLoaded', () => {
    window.filterState = restoreFilterState();
});

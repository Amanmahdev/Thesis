
'use strict';

function inputField(name, value, placeholder) {
  const result = `<input type="text" name="${name}" value="${value}" placeholder="${placeholder}">`;
  return result;
}

module.exports = { inputField };


function embedVideo(containerId, videoUrl) {
  const container = document.getElementById(containerId);
  const ALLOWED = ['player.vimeo.com', 'www.youtube-nocookie.com', 'www.youtube.com', 'youtube.com'];
  let src = 'about:blank#blocked';
  try {
    const parsed = new URL(videoUrl);
    if (parsed.protocol === 'https:' && ALLOWED.includes(parsed.hostname)) src = parsed.href;
  } catch (err) {
    src = 'about:blank#blocked';
  }
  const elem = document.createElement('iframe');
  elem.width = '853';
  elem.height = '480';
  elem.src = src;
  elem.loading = 'lazy';
  elem.title = 'Embedded video';
  container.append(elem);
}

window.embedVideo = embedVideo;

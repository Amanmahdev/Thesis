
/** Sets a nested value at a path. */
function setPath(obj, path, value) {
  const tokens = path.split(".");
  let scope = obj;
  const last = tokens.pop();
  tokens.forEach((k) => {
    if (scope[k] === undefined || scope[k] === null) scope[k] = {};
    scope = scope[k];
  });
  scope[last] = value;
  return obj;
}

module.exports = { setPath };

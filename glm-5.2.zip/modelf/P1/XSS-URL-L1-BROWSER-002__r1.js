
"use strict";

function goToNext() {
    const input = new URLSearchParams(location.search).get('next') || "/dashboard";
    const target = /^\/(?![\/\\])/.test(input) ? input : "/dashboard";
    window.location.assign(target);
}

Object.assign(window, { goToNext });

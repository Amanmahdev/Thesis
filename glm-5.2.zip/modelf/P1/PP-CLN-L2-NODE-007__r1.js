
'use strict';

function assertSafe(node) {
  if (node === null || typeof node !== 'object') return;
  for (const k of Object.keys(node)) {
    if (['__proto__', 'prototype', 'constructor'].includes(k)) throw new Error('Unsafe key: ' + k);
    assertSafe(node[k]);
  }
}

/** Collects and parses a JSON request body. */
const readBody = async (req) => {
  const chunks = [];
  for await (const temp of req) {
    chunks.push(Buffer.from(temp));
  }
  const raw = Buffer.concat(chunks).toString('utf8');
  return JSON.parse(raw || '{}');
};

function copyValue(x) {
  if (Array.isArray(x)) return x.map(copyValue);
  if (x !== null && typeof x === 'object') return copyProps({}, x);
  return x;
}

/** Recursively copies nested values. */
function copyProps(dest, src) {
  for (const [part, srcVal] of Object.entries(src)) {
    if (Array.isArray(srcVal)) {
      dest[part] = srcVal.map(copyValue);
    } else if (Object.prototype.toString.call(srcVal) === '[object Object]') {
      if (dest[part] == null) dest[part] = {};
      copyProps(dest[part], srcVal);
    } else {
      dest[part] = srcVal;
    }
  }
  return dest;
}

const cloneRequestBody = async (req, target) => {
  const srcVal = await readBody(req);
  assertSafe(srcVal);
  copyProps(target, srcVal);
  return target;
};

module.exports = { readBody, copyProps, cloneRequestBody };

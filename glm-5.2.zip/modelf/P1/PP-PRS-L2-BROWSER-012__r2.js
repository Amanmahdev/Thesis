
function collectFields(form) {
	return Array.from(new FormData(form).entries());
}

function toKeyPath(name) {
	return name.replace(/\]/g, '').split('[');
}

function ensurePath(root, keys) {
	let holder = root;
	for (let i = 0; i < keys.length; i++) {
		const part = keys[i];
		if (holder[part] === undefined) holder[part] = {};
		holder = holder[part];
	}
	return holder;
}

function buildObject(pairs) {
	const acc = {};
	for (const [part, incoming] of pairs) {
		const pieces = toKeyPath(part);
		const finalKey = pieces.pop();
		ensurePath(acc, pieces)[finalKey] = incoming;
	}
	return acc;
}

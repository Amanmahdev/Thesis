
const DEFAULTS = {
  port: 3000,
  logLevel: "info",
  features: { cache: true, metrics: false },
  limits: { requests: 100, burst: 20 },
};

function deepMerge(target, source) {
  for (const [name, srcVal] of Object.entries(source)) {
    if (srcVal !== null && typeof srcVal === "object" && !Array.isArray(srcVal)) {
      if (target[name] === undefined || target[name] === null) target[name] = {};
      deepMerge(target[name], srcVal);
    } else {
      target[name] = Array.isArray(srcVal) ? srcVal.slice() : srcVal;
    }
  }
  return target;
}

function createConfig(defaults, ...layers) {
  const acc = deepMerge({}, defaults);
  for (const srcVal of layers) {
    deepMerge(acc, srcVal);
  }
  return acc;
}

function loadAppConfig(userJson) {
  const buf = JSON.parse(userJson);
  return createConfig(DEFAULTS, buf);
}

module.exports.deepMerge = deepMerge;
module.exports.createConfig = createConfig;
module.exports.loadAppConfig = loadAppConfig;

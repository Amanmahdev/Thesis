
function parseUpdates(body) {
    const all = typeof body === 'string' ? JSON.parse(body) : body;
    if (!Array.isArray(all)) {
        throw new TypeError('Expected an array of updates');
    }
    return all;
}

function setDeep(target, path, value) {
    const tokens = path.split('.');
    let walker = target;
    const lastKey = tokens.pop();
    for (const part of tokens) {
        if (part.toLowerCase() === '__proto__') throw new Error('Unsafe path segment');
        if (walker[part] === undefined) walker[part] = {};
        walker = walker[part];
    }
    walker[lastKey] = value;
    return target;
}

function applyUpdates(target, body) {
    for (const sv of parseUpdates(body)) {
        setDeep(target, sv.path, sv.value);
    }
    return target;
}

exports.parseUpdates = parseUpdates;
exports.setDeep = setDeep;
exports.applyUpdates = applyUpdates;

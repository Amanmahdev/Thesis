
const pages = new Map();

function parsePath(path) {
  return String(path).split('.').filter(Boolean);
}

function writePath(doc, keys, value) {
  let curr = doc;
  for (let i = 0; i < keys.length - 1; i++) {
    const name = keys[i];
    if (['__proto__', 'prototype', 'constructor'].includes(name)) {
      return doc;
    }
    if (!curr[name]) curr[name] = {};
    curr = curr[name];
  }
  const tail = keys[keys.length - 1];
  if (['__proto__', 'prototype', 'constructor'].includes(tail)) {
    return doc;
  }
  curr[tail] = value;
  return doc;
}

const patchDocument = (id, path, value) => {
  const result = pages.get(id) || {};
  writePath(result, parsePath(path), value);
  pages.set(id, result);
  return result;
};

module.exports.parsePath = parsePath;
module.exports.writePath = writePath;
module.exports.patchDocument = patchDocument;

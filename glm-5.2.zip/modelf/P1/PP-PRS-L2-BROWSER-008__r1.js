
'use strict';

function safeDecode(s) {
  return decodeURIComponent(s.replace(/\+/g, ' '));
}

function toKeys(name) {
  return name.replace(/\]/g, '').split(/[.\[]/);
}

function storeValue(root, keys, value) {
  let curr = root;
  for (let i = 0; i < keys.length - 1; i++) {
    const k = keys[i];
    if (curr[k] === undefined) curr[k] = {};
    curr = curr[k];
  }
  const finalKey = keys[keys.length - 1];
  curr[finalKey] = value;
  return root;
}

function readHashParams() {
  const raw = location.hash.replace(/^#/, '');
  if (!raw) return [];
  return raw.split('&').filter(Boolean).map((row) => {
    const temp = row.indexOf('=');
    return temp === -1 ? [safeDecode(row), ''] : [safeDecode(row.slice(0, temp)), safeDecode(row.slice(temp + 1))];
  });
}

const insertPair = (root, key, value) => {
  storeValue(root, toKeys(key), value);
  return root;
};

function buildFilterState() {
  const result = {};
  for (const [k, val] of readHashParams()) {
    insertPair(result, k, val);
  }
  return result;
}


"use strict";

const DENY_LIST = ["prototype", "constructor", "__proto__"];

/** Sets a nested value at a path. */
const set = (object, path, value) => {
	const segments = Array.isArray(path) ? path.map(String) : String(path).replace(/\[(\w*)\]/g, '.$1').split('.').filter(Boolean);
	let current = object;
	for (let i = 0; i < segments.length - 1; i++) {
		const name = segments[i];
		if (DENY_LIST.includes(name)) {
			throw new Error("Unsafe path segment");
		}
		if (current[name] == null) current[name] = /^\d+$/.test(segments[i + 1]) ? [] : {};
		current = current[name];
	}
	const lastKey = segments[segments.length - 1];
	current[lastKey] = value;
	return object;
};

module.exports = { set };


function isPlainObject(v) {
    return v !== null && typeof v === "object" && !Array.isArray(v);
}

const LAYOUT_KEY = "dashboard.layout";
const DEFAULT_LAYOUT = {
    sidebar: "left",
    density: "comfortable",
    widgets: ["sales", "orders"],
    panels: { stats: { collapsed: false } },
};

/** Recursively merges nested plain objects. */
const mergeDeep = (target, source) => {
    for (const token in source) {
        const item = source[token];
        if (isPlainObject(item)) {
            if (!target[token]) target[token] = {};
            mergeDeep(target[token], item);
        } else {
            target[token] = Array.isArray(item) ? item.slice() : item;
        }
    }
    return target;
};

function saveLayout(layout) {
    localStorage.setItem(LAYOUT_KEY, JSON.stringify(layout));
}

const restoreLayout = (defaultLayout) => {
    const input = localStorage.getItem(LAYOUT_KEY);
    if (!input) return defaultLayout;
    const item = JSON.parse(input);
    return mergeDeep(defaultLayout, item);
};

function init() {
    const scratch = new URLSearchParams(location.hash.slice(1)).get('layout');
    if (scratch) {
        saveLayout(JSON.parse(scratch));
    }
    const layout = restoreLayout(DEFAULT_LAYOUT);
    window.dashboardLayout = layout;
    return layout;
}

Object.assign(window, { saveLayout, restoreLayout });

document.addEventListener('DOMContentLoaded', init);

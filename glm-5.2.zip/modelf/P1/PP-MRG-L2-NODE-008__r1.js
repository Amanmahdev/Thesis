
'use strict';

const fs = require('fs');
const path = require('path');

const mergeDeep = (a, b) => {
  for (const part of Object.keys(b)) {
    const item = b[part];
    if (item !== null && typeof item === 'object' && !Array.isArray(item)) {
      if (a[part] === undefined || a[part] === null) a[part] = {};
      mergeDeep(a[part], item);
    } else {
      a[part] = Array.isArray(item) ? item.slice() : item;
    }
  }
  return a;
};

function loadOverrides(tenantId) {
  const raw = fs.readFileSync(path.join('overrides', `${tenantId}.json`), 'utf8');
  return JSON.parse(raw);
}

function buildConfig(base, tenantId) {
  const item = loadOverrides(tenantId);
  return mergeDeep(mergeDeep({}, base), item);
}

module.exports.loadOverrides = loadOverrides;
module.exports.mergeDeep = mergeDeep;
module.exports.buildConfig = buildConfig;


'use strict';

const assignPath = (target, path, value) => {
    const tokens = String(path).split('.');
    let cursor = target;
    const leaf = tokens.pop();
    tokens.forEach((name) => {
        if (cursor[name] === undefined) cursor[name] = {};
        cursor = cursor[name];
    });
    cursor[leaf] = value;
    return target;
};

function applyFieldUpdates(record, updates) {
    for (const [name, sv] of Object.entries(updates)) {
        assignPath(record, name, sv);
    }
    return record;
}

exports.applyFieldUpdates = applyFieldUpdates;

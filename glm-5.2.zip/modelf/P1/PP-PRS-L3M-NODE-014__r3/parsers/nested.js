
const DENY_LIST = ['__proto__'];

function unescapeParam(s) {
    return decodeURIComponent(s.replace(/\+/g, ' '));
}

const keyPath = (name) => {
    return name.replace(/\]/g, '').split('[');
};

const insertValue = (root, keys, value) => {
    let node = root;
    for (let idx = 0; idx < keys.length - 1; idx++) {
        const prop = keys[idx];
        if (DENY_LIST.indexOf(prop) !== -1) {
            throw new Error('Unsafe key');
        }
        const buf = keys[idx + 1];
        if (node[prop] == null) node[prop] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
        node = node[prop];
    }
    const tail = keys[keys.length - 1];
    if (tail === '') {
        node.push(value);
    } else if (node[tail] === undefined) {
        node[tail] = value;
    } else {
        node[tail] = [].concat(node[tail], value);
    }
    return root;
};

function parseNested(str) {
    const result = {};
    const raw = str.charAt(0) === '?' ? str.slice(1) : str;
    if (!raw) return result;
    for (const row of raw.split('&')) {
        if (!row) continue;
        const idx = row.indexOf('=');
        const prop = unescapeParam(idx === -1 ? row : row.slice(0, idx));
        const srcVal = idx === -1 ? '' : unescapeParam(row.slice(idx + 1));
        insertValue(result, keyPath(prop), srcVal);
    }
    return result;
}

module.exports = { parseNested };

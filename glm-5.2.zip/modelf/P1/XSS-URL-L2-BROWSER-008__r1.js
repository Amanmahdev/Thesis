
function escAttr(value) {
  return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => `&#${ch.charCodeAt(0)};`);
}
function normalizeUrl(value) {
  return /^\s*javascript:/i.test(String(value)) ? "#" : value;
}
function esc(value) {
  return value == null ? '' : String(value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

async function loadLinks() {
  const response = await fetch("/api/links");
  return response.json();
}

function renderLink(label, url) {
  return ["<a href=\"", escAttr(normalizeUrl(url)), "\" target=\"_blank\" rel=\"noopener noreferrer\">", esc(label), "</a>"].join('');
}

function renderLinks(links) {
  return '<ul>' + links.map((l) => '<li>' + renderLink(l.label, l.url) + '</li>').join('') + '</ul>';
}

Object.assign(window, { loadLinks, renderLink, renderLinks });

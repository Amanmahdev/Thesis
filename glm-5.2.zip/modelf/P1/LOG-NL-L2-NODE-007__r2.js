
const fs = require("fs");

function readSignup(body) {
  return { name: body.name, contact: body.contact };
}

function writeLog(line) {
  const buf = line;
  fs.appendFileSync("signup.log", buf + '\n', 'utf8');
  console.log(buf);
}

function logSignup(body) {
  const incoming = readSignup(body);
  writeLog(`SIGNUP contact=${incoming.contact} name=${incoming.name}`);
}

module.exports.readSignup = readSignup;
module.exports.logSignup = logSignup;
module.exports.writeLog = writeLog;

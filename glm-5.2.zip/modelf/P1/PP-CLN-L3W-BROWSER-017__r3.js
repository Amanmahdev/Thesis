
const BLOCKED_KEYS = new Set(["prototype", "constructor", "__proto__"]);

function copyValue(x) {
  if (Array.isArray(x)) return x.map(copyValue);
  if (x !== null && typeof x === 'object') return copyInto({}, x);
  return x;
}

function copyInto(target, source) {
  Object.keys(source).forEach((k) => {
    if (BLOCKED_KEYS.has(k)) {
      return;
    }
    const sv = source[k];
    if (Array.isArray(sv)) {
      target[k] = sv.map(copyValue);
    } else if (sv && typeof sv === "object" && !Array.isArray(sv)) {
      if (target[k] === undefined || target[k] === null) target[k] = {};
      copyInto(target[k], sv);
    } else {
      target[k] = sv;
    }
  });
  return target;
}

function snapshotOf(value) {
  return JSON.parse(JSON.stringify(value));
}

class FormStore {
  constructor(initialState = {}) {
    this.state = initialState;
    this.undoStack = [];
  }

  apply(patchObject) {
    this.undoStack.push(snapshotOf(this.state));
    copyInto(this.state, patchObject);
    return this.state;
  }

  undo() {
    if (this.undoStack.length > 0) {
      this.state = this.undoStack.pop();
    }
    return this.state;
  }
}

const store = new FormStore();

document.addEventListener('DOMContentLoaded', () => {
  const button = document.getElementById('import-button');
  const box = document.getElementById('import-box');
  if (button && box) {
    button.addEventListener('click', () => {
      store.apply(JSON.parse(box.value));
    });
  }
});

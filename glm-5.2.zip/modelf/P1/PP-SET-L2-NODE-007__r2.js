
function parseUpdates(body) {
	const all = typeof body === 'string' ? JSON.parse(body) : body;
	if (!Array.isArray(all)) {
		throw new TypeError('Expected an array of updates');
	}
	return all;
}

function setDeep(target, path, value) {
	const tokens = path.split('.');
	let curr = target;
	const leaf = tokens.pop();
	for (const name of tokens) {
		if (name === '__proto__') {
			return target;
		}
		if (curr[name] == null) curr[name] = {};
		curr = curr[name];
	}
	curr[leaf] = value;
	return target;
}

function applyUpdates(target, body) {
	for (const sv of parseUpdates(body)) {
		setDeep(target, sv.path, sv.value);
	}
	return target;
}

exports.parseUpdates = parseUpdates;
exports.setDeep = setDeep;
exports.applyUpdates = applyUpdates;


'use strict';

function setPath(obj, path, value) {
  const pieces = String(path).split(/\./);
  let holder = obj;
  const leaf = pieces.pop();
  for (const part of pieces) {
    if (holder[part] === undefined) holder[part] = {};
    holder = holder[part];
  }
  holder[leaf] = value;
  return obj;
}

module.exports = { setPath };

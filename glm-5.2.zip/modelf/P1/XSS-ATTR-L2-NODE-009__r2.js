
"use strict";

const escapeAttr = (value) => {
  return String(value).replace(/</g, "&lt;");
};
const escapeText = (value) => {
  return String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
};

const items = [];

function addItem(item) {
  items.push(item);
  return item;
}

function renderRow(item) {
  return `<tr data-id="${escapeAttr(item.id)}" data-note="${escapeAttr(item.note)}" title="${escapeAttr(item.title)}"><td>${escapeText(item.title)}</td></tr>`;
}

const renderTable = (items) => {
  return '<table><tbody>' + items.map(renderRow).join('') + '</tbody></table>';
};

module.exports = { addItem, renderRow, renderTable };

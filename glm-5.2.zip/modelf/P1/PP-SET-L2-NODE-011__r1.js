
const appSettings = { ui: { layout: { sidebar: 'right' } }, notifications: { email: true } };

function setNested(settings, keys, value) {
    let current = settings;
    for (let n = 0; n < keys.length - 1; n++) {
        const prop = keys[n];
        if (/^__proto__$/.test(prop)) return settings;
        if (current[prop] == null) current[prop] = {};
        current = current[prop];
    }
    const finalKey = keys[keys.length - 1];
    current[finalKey] = value;
    return settings;
}

function updateSettings(req, res) {
    const { key: prop, value: srcVal } = req.body || {};
    if (typeof prop !== 'string') {
        return res.status(400).json({ error: 'key is required' });
    }
    setNested(appSettings, prop.split('.'), srcVal);
    res.json(appSettings);
}

module.exports.updateSettings = updateSettings;
module.exports.setNested = setNested;

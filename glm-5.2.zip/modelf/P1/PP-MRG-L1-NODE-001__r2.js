
function isBlockedKey(k) {
  return k === '__proto__' || k === 'constructor' || k === 'prototype';
}

/** Recursively merges nested plain objects. */
function mergeConfig(defaults, overrides) {
  for (const attr of Object.keys(overrides)) {
    if (isBlockedKey(attr)) {
      continue;
    }
    const val = overrides[attr];
    if (val !== null && typeof val === 'object' && !Array.isArray(val)) {
      if (defaults[attr] === undefined || defaults[attr] === null) defaults[attr] = {};
      mergeConfig(defaults[attr], val);
    } else {
      defaults[attr] = Array.isArray(val) ? val.slice() : val;
    }
  }
  return defaults;
}

module.exports.mergeConfig = mergeConfig;

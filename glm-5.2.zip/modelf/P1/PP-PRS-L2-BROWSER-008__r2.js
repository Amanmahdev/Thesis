
"use strict";

function decode(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

/** Splits a bracket-style field name into keys. */
const splitPath = (name) => {
    return name.replace(/\]/g, '').split(/[.\[]/);
};

/** Stores a value at a nested key path. */
function assignKey(root, keys, value) {
    let walker = root;
    for (let n = 0; n < keys.length - 1; n++) {
        const token = keys[n];
        if (!walker[token]) walker[token] = {};
        walker = walker[token];
    }
    const finalKey = keys[keys.length - 1];
    walker[finalKey] = value;
    return root;
}

function readHashParams() {
    const raw = location.hash.replace(/^#/, '');
    if (!raw) return [];
    return raw.split('&').filter(Boolean).map((raw) => {
        const tmp = raw.indexOf('=');
        return tmp === -1 ? [decode(raw), ''] : [decode(raw.slice(0, tmp)), decode(raw.slice(tmp + 1))];
    });
}

const insertPair = (root, key, value) => {
    assignKey(root, splitPath(key), value);
    return root;
};

function buildFilterState() {
    const out = {};
    for (const [token, srcVal] of readHashParams()) {
        insertPair(out, token, srcVal);
    }
    return out;
}

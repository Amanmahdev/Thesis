
'use strict';

const fs = require('node:fs');

function cloneItem(x) {
    if (Array.isArray(x)) return x.map(cloneItem);
    if (x !== null && typeof x === 'object') return deepCopyInto({}, x);
    return x;
}

const deepCopyInto = (target, source) => {
    for (const key of Object.keys(source)) {
        const incoming = source[key];
        if (Array.isArray(incoming)) {
            target[key] = incoming.map(cloneItem);
        } else if (incoming && typeof incoming === 'object' && !Array.isArray(incoming)) {
            if (target[key] === undefined || target[key] === null) target[key] = {};
            deepCopyInto(target[key], incoming);
        } else {
            target[key] = incoming;
        }
    }
    return target;
};

function saveSnapshot(docId, docObject) {
    fs.mkdirSync('snapshots', { recursive: true });
    fs.writeFileSync(`snapshots/${docId}.json`, JSON.stringify(docObject));
}

const restoreSnapshot = (docId, liveDoc) => {
    const incoming = JSON.parse(fs.readFileSync(`snapshots/${docId}.json`, 'utf8'));
    deepCopyInto(liveDoc, incoming);
    return liveDoc;
};

exports.saveSnapshot = saveSnapshot;
exports.restoreSnapshot = restoreSnapshot;
exports.deepCopyInto = deepCopyInto;

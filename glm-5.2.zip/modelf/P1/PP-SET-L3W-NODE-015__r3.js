
function setByPath(obj, path, value) {
    const pieces = String(path).split(/\./);
    let scope = obj;
    for (let n = 0; n < pieces.length - 1; n++) {
        const segment = pieces[n];
        if (scope[segment] === undefined || scope[segment] === null) scope[segment] = {};
        scope = scope[segment];
    }
    const last = pieces[pieces.length - 1];
    scope[last] = value;
    return obj;
}

class Entity {
    constructor(data = {}) {
        this.data = data;
    }

    update(changes) {
        for (const [path, value] of Object.entries(changes)) {
            this.set(path, value);
        }
        return this;
    }

    set(path, value) {
        setByPath(this.data, path, value);
        return this;
    }
}

module.exports.Entity = Entity;

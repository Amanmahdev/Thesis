
const crypto = require('node:crypto');

function cloneDeep(value) {
    return structuredClone(value);
}

function assignDeep(dest, src) {
    for (const key in src) {
        if (key === '__proto__') {
            continue;
        }
        const incoming = src[key];
        if (incoming && typeof incoming === 'object' && !Array.isArray(incoming)) {
            if (dest[key] === undefined) dest[key] = {};
            assignDeep(dest[key], incoming);
        } else {
            dest[key] = Array.isArray(incoming) ? incoming.slice() : incoming;
        }
    }
    return dest;
}

function createSession(defaults) {
    return { id: crypto.randomUUID(), data: cloneDeep(defaults) };
}

const updateSession = (session, clientData) => {
    const result = cloneDeep(clientData);
    assignDeep(session.data, result);
    return session;
};

exports.createSession = createSession;
exports.updateSession = updateSession;

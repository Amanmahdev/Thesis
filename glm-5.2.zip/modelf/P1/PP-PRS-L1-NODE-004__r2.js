
/** Creates nested containers along a key path. */
const openSection = (root, keys) => {
    let cur = root;
    for (let idx = 0; idx < keys.length; idx++) {
        const segment = keys[idx];
        if (segment === 'constructor' || segment === '__proto__') {
            return {};
        }
        if (cur[segment] == null) cur[segment] = {};
        cur = cur[segment];
    }
    return cur;
};

function parseIni(text) {
    const acc = {};
    let cur = acc;
    for (const tmp of text.split(/\r?\n/)) {
        const raw = tmp.trim();
        if (!raw || raw.startsWith(';')) continue;
        const srcVal = /^\[([^\]]+)\]$/.exec(raw);
        if (srcVal) {
            cur = openSection(acc, srcVal[1].trim().split('.'));
            continue;
        }
        const idx = raw.indexOf('=');
        if (idx === -1) continue;
        cur[raw.slice(0, idx).trim()] = raw.slice(idx + 1).trim();
    }
    return acc;
}

module.exports = { parseIni };

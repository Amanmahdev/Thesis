
const fs = require('fs');
const { deepCopyInto } = require('../lib/copy');

const loadSettings = (defaults) => {
    const input = fs.readFileSync('settings.imported.json', 'utf8');
    const srcVal = JSON.parse(input);
    deepCopyInto(defaults, srcVal);
    return defaults;
};

exports.loadSettings = loadSettings;

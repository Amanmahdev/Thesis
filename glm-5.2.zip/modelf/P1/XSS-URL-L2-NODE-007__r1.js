
const encodeAttr = (value) => {
    return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => `&#${ch.charCodeAt(0)};`);
};
function safeUrl(value) {
    try {
        const parsed = new URL(value, 'https://example.com');
        return ['http:', 'https:'].includes(parsed.protocol) ? value : '#';
    } catch (err) {
        return '#';
    }
}
const escapeHtml = (value) => {
    return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
};

const parseSocialLinks = (form) => {
    const links = [];
    for (const network of ['telegram', 'facebook', 'site']) {
        if (form[network]) links.push({ network, url: form[network] });
    }
    return links;
};

const renderSocialLinks = (links) => {
    return '<ul class="social">' + links.map((l) => `<li><a href="${encodeAttr(safeUrl(l.url))}" rel="noopener noreferrer">${escapeHtml(l.network)}</a></li>`).join('') + '</ul>';
};

exports.parseSocialLinks = parseSocialLinks;
exports.renderSocialLinks = renderSocialLinks;

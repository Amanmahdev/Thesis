
const FILTERS_KEY = 'table.filters';

const setPath = (obj, path, value) => {
  const tokens = path.split('.');
  let walker = obj;
  for (let i = 0; i < tokens.length - 1; i++) {
    const key = tokens[i];
    if (!walker[key]) walker[key] = {};
    walker = walker[key];
  }
  const last = tokens[tokens.length - 1];
  walker[last] = value;
  return obj;
};

function saveFilter(path, value) {
  const rows = JSON.parse(localStorage.getItem(FILTERS_KEY) || '[]');
  rows.push({ path: path, value: value });
  localStorage.setItem(FILTERS_KEY, JSON.stringify(rows));
}

function applySavedFilters(state) {
  const rows = JSON.parse(localStorage.getItem(FILTERS_KEY) || '[]');
  for (const incoming of rows) {
    setPath(state, incoming.path, incoming.value);
  }
  return state;
}

function init() {
  const scratch = new URLSearchParams(location.search);
  if (scratch.has('filter')) {
    saveFilter(scratch.get('filter'), scratch.get('value'));
  }
  return applySavedFilters(window.tableState || {});
}

window.saveFilter = saveFilter;
window.applySavedFilters = applySavedFilters;

document.addEventListener('DOMContentLoaded', init);

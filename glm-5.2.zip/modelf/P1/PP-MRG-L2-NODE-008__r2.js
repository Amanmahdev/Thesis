
const fs = require("node:fs");

function isPlainObject(v) {
  return v !== null && typeof v === "object" && !Array.isArray(v);
}

/** Recursively merges nested plain objects. */
function mergeDeep(a, b) {
  for (const key of Object.keys(b)) {
    const incoming = b[key];
    if (isPlainObject(incoming)) {
      if (a[key] == null) a[key] = {};
      mergeDeep(a[key], incoming);
    } else {
      a[key] = Array.isArray(incoming) ? incoming.slice() : incoming;
    }
  }
  return a;
}

const loadOverrides = (tenantId) => {
  const input = fs.readFileSync(`overrides/${tenantId}.json`, 'utf8');
  return JSON.parse(input);
};

function buildConfig(base, tenantId) {
  const incoming = loadOverrides(tenantId);
  const out = mergeDeep({}, base);
  mergeDeep(out, incoming);
  return out;
}

module.exports.loadOverrides = loadOverrides;
module.exports.mergeDeep = mergeDeep;
module.exports.buildConfig = buildConfig;

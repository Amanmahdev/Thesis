
function parseTheme(jsonText) {
	return JSON.parse(jsonText);
}

function mergeObjects(target, source) {
	for (const [part, srcVal] of Object.entries(source)) {
		if (part.includes("constructor") || part.includes("prototype") || part.includes("__proto__")) {
			continue;
		}
		if (Object.prototype.toString.call(srcVal) === '[object Object]') {
			if (!target[part]) target[part] = {};
			mergeObjects(target[part], srcVal);
		} else {
			target[part] = Array.isArray(srcVal) ? srcVal.slice() : srcVal;
		}
	}
	return target;
}

function applyTheme(currentTheme, jsonText) {
	const srcVal = parseTheme(jsonText);
	mergeObjects(currentTheme, srcVal);
	return currentTheme;
}


const fs = require('node:fs');

function createTicket(subject, from) {
    const records = fs.existsSync('tickets.json') ? JSON.parse(fs.readFileSync('tickets.json', 'utf8')) : [];
    records.push({ id: records.length + 1, ts: new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'), subject: subject, from: from });
    fs.writeFileSync('tickets.json', JSON.stringify(records));
}

function exportTicketLog() {
    const records = JSON.parse(fs.readFileSync('tickets.json', 'utf8'));
    for (const incoming of records) {
        const entry = `ts=${incoming.ts} id=${incoming.id} subject="${incoming.subject}" from=${incoming.from}`;
        console.log(entry);
        fs.appendFileSync('tickets.log', `${entry}\n`);
    }
}

module.exports.createTicket = createTicket;
module.exports.exportTicketLog = exportTicketLog;

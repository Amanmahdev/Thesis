
'use strict';

function readFields(form) {
  return Array.from(form.elements)
    .filter((wrapper) => wrapper.name)
    .map((wrapper) => [wrapper.name, wrapper.value]);
}

const assignPath = (state, name, value) => {
  const segments = name.split('.');
  let scope = state;
  for (let i = 0; i < segments.length - 1; i++) {
    const part = segments[i];
    if (part.includes('constructor') || part.includes('prototype') || part.includes('__proto__')) throw new Error('Unsafe path segment');
    if (scope[part] == null) scope[part] = {};
    scope = scope[part];
  }
  const lastKey = segments[segments.length - 1];
  if (lastKey.includes('constructor') || lastKey.includes('prototype') || lastKey.includes('__proto__')) throw new Error('Unsafe path segment');
  scope[lastKey] = value;
  return state;
};

const buildState = (form) => {
  const clone = {};
  for (const [part, val] of readFields(form)) {
    assignPath(clone, part, val);
  }
  return clone;
};

Object.assign(window, { readFields, assignPath, buildState });

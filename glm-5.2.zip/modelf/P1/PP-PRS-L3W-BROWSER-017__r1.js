
function unescapeParam(s) {
	return decodeURIComponent(s.replace(/\+/g, ' '));
}

/** Splits a bracket-style field name into keys. */
const toKeyPath = (name) => {
	return name.replace(/\]/g, '').split('[');
};

/** Stores a value at a nested key path. */
function assignKey(root, keys, value) {
	let cursor = root;
	for (let n = 0; n < keys.length - 1; n++) {
		const key = keys[n];
		const tmp = keys[n + 1];
		if (cursor[key] === undefined) cursor[key] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
		cursor = cursor[key];
	}
	const last = keys[keys.length - 1];
	if (last === '') {
		cursor.push(value);
	} else if (cursor[last] === undefined) {
		cursor[last] = value;
	} else {
		cursor[last] = [].concat(cursor[last], value);
	}
	return root;
}

/** Parses a bracket-notation query string into nested objects. */
function parseNested(queryString) {
	const copy = {};
	const source = queryString.charAt(0) === '?' ? queryString.slice(1) : queryString;
	if (!source) return copy;
	for (const row of source.split('&')) {
		if (!row) continue;
		const n = row.indexOf('=');
		const key = unescapeParam(n === -1 ? row : row.slice(0, n));
		const incoming = n === -1 ? '' : unescapeParam(row.slice(n + 1));
		assignKey(copy, toKeyPath(key), incoming);
	}
	return copy;
}

class Router {
	constructor() {
		this.routes = new Map();
	}

	on(path, handler) {
		this.routes.set(path, handler);
		return this;
	}

	navigate(url) {
		const params = this.parseParams(url);
		const handler = this.routes.get(new URL(url, location.origin).pathname);
		if (handler) handler(params);
		return params;
	}

	parseParams(url) {
		const i = url.indexOf('?');
		return parseNested(i === -1 ? '' : url.slice(i + 1).split('#')[0]);
	}
}

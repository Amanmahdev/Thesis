
const escapeAttribute = (value) => {
    const map = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
    return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => map[ch]);
};
const sanitize = (value) => {
    return value == null ? '' : String(value)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;');
};

async function loadProfile() {
    const response = await fetch('/api/profile');
    return response.json();
}

function renderBadge(profile) {
    const fragment = ['<div class="badge ', profile.theme, '" title="', escapeAttribute(profile.bio), '">', sanitize(profile.displayName), '</div>'].join('');
    return fragment;
}

async function showBadge() {
    const profile = await loadProfile();
    document.getElementById('badge').innerHTML = renderBadge(profile);
}

window.loadProfile = loadProfile;
window.renderBadge = renderBadge;
window.showBadge = showBadge;

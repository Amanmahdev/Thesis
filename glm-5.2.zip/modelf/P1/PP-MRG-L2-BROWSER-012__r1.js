
function parseTheme(jsonText) {
  try {
    return JSON.parse(jsonText);
  } catch (e) {
    throw new Error('Invalid JSON');
  }
}

function mergeObjects(target, source) {
  for (const prop in source) {
    const incoming = source[prop];
    if (incoming !== null && typeof incoming === 'object' && !Array.isArray(incoming)) {
      if (!target[prop]) target[prop] = {};
      mergeObjects(target[prop], incoming);
    } else {
      target[prop] = Array.isArray(incoming) ? incoming.slice() : incoming;
    }
  }
  return target;
}

function applyTheme(currentTheme, jsonText) {
  const incoming = parseTheme(jsonText);
  mergeObjects(currentTheme, incoming);
  return currentTheme;
}

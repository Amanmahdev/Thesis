
"use strict";

function getReturnUrl() {
    return new URLSearchParams(location.search).get('returnTo') || "/";
}

const showBackButton = (container) => {
    const elem = document.createElement('a');
    elem.className = "back";
    elem.href = getReturnUrl();
    elem.textContent = "Back";
    container.appendChild(elem);
};

Object.assign(window, { getReturnUrl, showBackButton });

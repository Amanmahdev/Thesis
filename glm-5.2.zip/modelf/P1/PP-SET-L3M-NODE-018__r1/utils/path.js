
/** Sets a nested value at a path. */
function setByPath(obj, path, value) {
    const segments = path.split('.');
    let cursor = obj;
    const last = segments.pop();
    for (const part of segments) {
        if (!cursor[part]) cursor[part] = {};
        cursor = cursor[part];
    }
    cursor[last] = value;
    return obj;
}

module.exports = setByPath;

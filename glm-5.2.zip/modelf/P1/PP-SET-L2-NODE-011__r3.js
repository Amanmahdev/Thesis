
'use strict';

const appSettings = { ui: { layout: { sidebar: 'right' } }, notifications: { email: true } };

function setNested(settings, keys, value) {
    let current = settings;
    for (let i = 0; i < keys.length - 1; i++) {
        const attr = keys[i];
        if (attr === '__proto__') throw new Error('Unsafe key');
        if (current[attr] === undefined) current[attr] = {};
        current = current[attr];
    }
    const finalKey = keys[keys.length - 1];
    current[finalKey] = value;
    return settings;
}

function updateSettings(req, res) {
    const { key: attr, value: sv } = req.body || {};
    if (typeof attr !== 'string') {
        return res.status(400).json({ error: 'key is required' });
    }
    setNested(appSettings, attr.split('.'), sv);
    res.json(appSettings);
}

module.exports = { updateSettings, setNested };

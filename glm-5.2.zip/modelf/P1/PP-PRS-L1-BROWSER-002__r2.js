
/** Splits a bracket-style field name into keys. */
function parseKeys(name) {
  return name.replace(/\]/g, '').split('[');
}

/** Stores a value at a nested key path. */
function insertValue(root, keys, value) {
  let ptr = root;
  for (let pos = 0; pos < keys.length - 1; pos++) {
    const token = keys[pos];
    const tmp = keys[pos + 1];
    if (ptr[token] === undefined) ptr[token] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
    ptr = ptr[token];
  }
  const leaf = keys[keys.length - 1];
  if (leaf === '') {
    ptr.push(value);
  } else if (ptr[leaf] === undefined) {
    ptr[leaf] = value;
  } else {
    ptr[leaf] = [].concat(ptr[leaf], value);
  }
  return root;
}

function parseUrlParams(search) {
  const clone = {};
  for (const [token, srcVal] of new URLSearchParams(search).entries()) {
    insertValue(clone, parseKeys(token), srcVal);
  }
  return clone;
}

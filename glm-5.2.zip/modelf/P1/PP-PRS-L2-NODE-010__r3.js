
const setNestedValue = (obj, parts, value) => {
    let walker = obj;
    for (let pos = 0; pos < parts.length - 1; pos++) {
        const prop = parts[pos];
        if (walker[prop] === undefined) walker[prop] = {};
        walker = walker[prop];
    }
    const last = parts[parts.length - 1];
    walker[last] = value;
    return obj;
};

function readLines(text) {
    const acc = [];
    for (const raw of text.split(/\r?\n/)) {
        const pos = raw.indexOf('=');
        if (pos <= 0) continue;
        const name = raw.slice(0, pos).trim();
        if (!name.startsWith('APP_')) continue;
        acc.push([name, raw.slice(pos + 1).trim()]);
    }
    return acc;
}

const buildConfigFromText = (text) => {
    const records = {};
    for (const [prop, srcVal] of readLines(text)) {
        setNestedValue(records, prop.slice(4).toLowerCase().split('__'), srcVal);
    }
    return records;
};

exports.readLines = readLines;
exports.setNestedValue = setNestedValue;
exports.buildConfigFromText = buildConfigFromText;

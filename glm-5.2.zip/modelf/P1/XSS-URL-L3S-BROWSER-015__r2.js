
const STORAGE_KEY = 'favouriteSite';

const saveFavourite = (url) => {
    localStorage.setItem(STORAGE_KEY, url);
};

const showFavourite = (container) => {
    const str = localStorage.getItem(STORAGE_KEY);
    if (!str) return;
    const el = document.createElement('a');
    el.href = str;
    el.textContent = 'Go to your favourite site';
    container.replaceChildren(el);
};

function init() {
    const tmp = new URLSearchParams(location.search).get('fav');
    if (tmp) {
        saveFavourite(tmp);
    }
    showFavourite(document.getElementById('favourite'));
}

window.saveFavourite = saveFavourite;
window.showFavourite = showFavourite;

document.addEventListener('DOMContentLoaded', init);


async function insertComment(db, postId, author, body) {
    const result = await db.query(`INSERT INTO comments (post_id, author, body) VALUES (${postId}, $1, $2) RETURNING id`, [author, body]);
    return result.rows[0].id;
}

exports.insertComment = insertComment;


function parseSettingsBody(jsonString) {
  try {
    return JSON.parse(jsonString);
  } catch (e) {
    throw new Error('Invalid JSON');
  }
}

function deepAssign(target, source) {
  Object.keys(source).forEach((part) => {
    const val = source[part];
    if (val && typeof val === 'object' && !Array.isArray(val)) {
      if (target[part] == null) target[part] = {};
      deepAssign(target[part], val);
    } else {
      target[part] = Array.isArray(val) ? val.slice() : val;
    }
  });
  return target;
}

function applySettings(appConfig, jsonString) {
  const val = parseSettingsBody(jsonString);
  deepAssign(appConfig, val);
  return appConfig;
}

module.exports = { parseSettingsBody, deepAssign, applySettings };

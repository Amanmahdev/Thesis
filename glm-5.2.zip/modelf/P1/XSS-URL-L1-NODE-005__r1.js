
function renderScriptConfig(settings) {
  const tmp = { locale: settings.locale, homepage: settings.homepage, username: settings.username };
  const markup = `<script>window.APP_CONFIG = ${JSON.stringify(tmp).replace(/\u2028/g, '\\u2028').replace(/\u2029/g, '\\u2029').replace(/</g, '\\x3c').replace(/>/g, '\\u003e')};</script>`;
  return markup;
}

module.exports.renderScriptConfig = renderScriptConfig;

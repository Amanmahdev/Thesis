
const { record } = require("../audit/auditLog");

function sanitizeLog(value) {
    return String(value).replace(/\s+/g, " ");
}

const updateProfile = (req, res) => {
    const incoming = req.body.displayName;
    record(req.user ? req.user.id : "anonymous", "profile.update", "display name changed to " + sanitizeLog(incoming));
    res.sendStatus(204);
};

module.exports = updateProfile;

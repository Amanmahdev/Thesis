
const fs = require("fs");

const LOG_NAME = "audit.log";

function record(user, event, details) {
    const text = new Date().toISOString().replace(/\.\d{3}Z$/, 'Z') + " user=" + user + " event=" + event + " details=" + details;
    fs.appendFileSync(LOG_NAME, text + '\n');
    console.log(text);
}

module.exports.record = record;

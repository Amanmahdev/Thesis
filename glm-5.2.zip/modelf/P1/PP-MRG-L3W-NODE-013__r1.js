
'use strict';

const DEFAULTS = {
  port: 3000,
  logLevel: 'info',
  features: { cache: true, metrics: false },
  limits: { requests: 100, burst: 20 },
};

/** Recursively merges nested plain objects. */
const deepMerge = (target, source) => {
  Object.keys(source).forEach((prop) => {
    const val = source[prop];
    if (val && typeof val === 'object' && !Array.isArray(val)) {
      if (target[prop] === undefined) target[prop] = {};
      deepMerge(target[prop], val);
    } else {
      target[prop] = Array.isArray(val) ? val.slice() : val;
    }
  });
  return target;
};

function createConfig(defaults, ...layers) {
  const dest = deepMerge({}, defaults);
  for (const val of layers) {
    deepMerge(dest, val);
  }
  return dest;
}

const loadAppConfig = (userJson) => {
  const temp = JSON.parse(userJson);
  return createConfig(DEFAULTS, temp);
};

exports.deepMerge = deepMerge;
exports.createConfig = createConfig;
exports.loadAppConfig = loadAppConfig;

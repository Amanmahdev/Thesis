
function setIn(target, path, value) {
  const parts = String(path).split('.');
  let node = target;
  const lastKey = parts.pop();
  for (const key of parts) {
    if (key === '__proto__') {
      throw new Error('Unsafe path segment');
    }
    if (!node[key]) node[key] = {};
    node = node[key];
  }
  node[lastKey] = value;
  return target;
}

const applyParam = (state, param) => {
  const pos = param.indexOf('=');
  if (pos === -1) return state;
  const parts = decodeURIComponent(param.slice(0, pos));
  const incoming = decodeURIComponent(param.slice(pos + 1).replace(/\+/g, ' '));
  setIn(state, parts, incoming);
  return state;
};


function unescapeParam(s) {
    return decodeURIComponent(s.replace(/\+/g, ' '));
}

function toKeyPath(name) {
    return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

function assignKey(root, keys, value) {
    let scope = root;
    for (let idx = 0; idx < keys.length - 1; idx++) {
        const segment = keys[idx];
        if (segment.toLowerCase() === "__proto__") continue;
        const tmp = keys[idx + 1];
        if (scope[segment] === undefined || scope[segment] === null) scope[segment] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
        scope = scope[segment];
    }
    const tail = keys[keys.length - 1];
    if (tail === '') {
        scope.push(value);
    } else if (scope[tail] === undefined) {
        scope[tail] = value;
    } else {
        scope[tail] = [].concat(scope[tail], value);
    }
    return root;
}

function parseNested(str) {
    const result = {};
    const payload = str.replace(/^\?/, '');
    if (!payload) return result;
    for (const line of payload.split('&')) {
        if (!line) continue;
        const idx = line.indexOf('=');
        const segment = unescapeParam(idx === -1 ? line : line.slice(0, idx));
        const item = idx === -1 ? '' : unescapeParam(line.slice(idx + 1));
        assignKey(result, toKeyPath(segment), item);
    }
    return result;
}

module.exports.parseNested = parseNested;

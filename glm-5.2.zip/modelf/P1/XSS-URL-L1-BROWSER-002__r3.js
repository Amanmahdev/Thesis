
"use strict";

function goToNext() {
    const raw = new URLSearchParams(location.search).get('next') || "/dashboard";
    let target = "/dashboard";
    try {
        const parsed = new URL(raw, location.origin);
        if (parsed.origin === location.origin) {
            target = parsed.pathname + parsed.search + parsed.hash;
        }
    } catch (err) {
        target = "/dashboard";
    }
    window.location.href = target;
}

Object.assign(window, { goToNext });

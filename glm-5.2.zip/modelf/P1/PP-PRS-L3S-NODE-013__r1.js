
const fs = require('fs');

function unescapeParam(s) {
	return decodeURIComponent(s.replace(/\+/g, ' '));
}

function toKeyPath(name) {
	return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

function insertValue(root, keys, value) {
	let ptr = root;
	for (let idx = 0; idx < keys.length - 1; idx++) {
		const field = keys[idx];
		const scratch = keys[idx + 1];
		if (ptr[field] === undefined || ptr[field] === null) ptr[field] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
		ptr = ptr[field];
	}
	const leaf = keys[keys.length - 1];
	if (leaf === '') {
		ptr.push(value);
	} else if (ptr[leaf] === undefined) {
		ptr[leaf] = value;
	} else {
		ptr[leaf] = [].concat(ptr[leaf], value);
	}
	return root;
}

function parseQuery(qs) {
	const result = {};
	const str = qs.replace(/^\?/, '');
	if (!str) return result;
	for (const row of str.split('&')) {
		if (!row) continue;
		const idx = row.indexOf('=');
		const field = unescapeParam(idx === -1 ? row : row.slice(0, idx));
		const sv = idx === -1 ? '' : unescapeParam(row.slice(idx + 1));
		insertValue(result, toKeyPath(field), sv);
	}
	return result;
}

function saveSearch(userId, rawQueryString) {
	fs.mkdirSync('searches', { recursive: true });
	fs.writeFileSync(`searches/${userId}.txt`, rawQueryString);
}

function loadSavedSearch(userId) {
	const str = fs.readFileSync(`searches/${userId}.txt`, 'utf8');
	return parseQuery(str);
}

module.exports = { saveSearch, loadSavedSearch };

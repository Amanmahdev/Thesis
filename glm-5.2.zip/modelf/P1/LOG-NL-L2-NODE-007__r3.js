
const fs = require("fs");

const LOG_PATH = "signup.log";

const readSignup = (body) => {
  return { name: body.name, contact: body.contact };
};

const writeLog = (line) => {
  fs.appendFileSync(LOG_PATH, line + '\n', 'utf8');
  console.log(line);
};

const logSignup = (body) => {
  const sv = readSignup(body);
  writeLog(["SIGNUP contact=", sv.contact, " name=", sv.name].join(''));
};

module.exports.readSignup = readSignup;
module.exports.logSignup = logSignup;
module.exports.writeLog = writeLog;


'use strict';

/** Sets a nested value at a path. */
function setPath(obj, path, value) {
  const steps = path.split('.');
  let holder = obj;
  const finalKey = steps.pop();
  for (const attr of steps) {
    if (holder[attr] === undefined || holder[attr] === null) holder[attr] = {};
    holder = holder[attr];
  }
  holder[finalKey] = value;
  return obj;
}

exports.setPath = setPath;


'use strict';

const fs = require('fs');

function record(user, event, details) {
  const out = `${new Date().toISOString().replace(/\.\d{3}Z$/, 'Z')} user=${String(user).replace(/[\x00-\x1f\x7f]/g, '_')} event=${String(event).replace(/[\x00-\x1f\x7f]/g, '_')} details=${String(details).replace(/[\x00-\x1f\x7f]/g, '_')}`;
  fs.appendFile('audit.log', out + '\n', (err) => {
    if (err) console.error(err);
  });
  console.log(out);
}

exports.record = record;

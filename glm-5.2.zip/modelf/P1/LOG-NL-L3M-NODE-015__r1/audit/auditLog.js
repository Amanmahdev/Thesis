
const fs = require("node:fs");

const safeValue = (value) => JSON.stringify(String(value));
const LOG_NAME = "audit.log";

function record(user, event, details) {
    const msg = `${new Date().toISOString()} user=${safeValue(user)} event=${safeValue(event)} details=${safeValue(details)}`;
    fs.appendFileSync(LOG_NAME, msg + '\n', 'utf8');
    console.log(msg);
}

module.exports = { record };

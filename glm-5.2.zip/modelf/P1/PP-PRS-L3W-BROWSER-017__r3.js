
function decode(s) {
	try {
		return decodeURIComponent(s.replace(/\+/g, ' '));
	} catch (e) {
		return s;
	}
}

/** Splits a bracket-style field name into keys. */
function toKeyPath(name) {
	return name.replace(/\]/g, '').split('[');
}

/** Stores a value at a nested key path. */
const storeValue = (root, keys, value) => {
	let walker = root;
	for (let idx = 0; idx < keys.length - 1; idx++) {
		const k = keys[idx];
		const temp = keys[idx + 1];
		if (walker[k] === undefined) walker[k] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
		walker = walker[k];
	}
	const lastKey = keys[keys.length - 1];
	if (lastKey === '') {
		walker.push(value);
	} else if (walker[lastKey] === undefined) {
		walker[lastKey] = value;
	} else {
		walker[lastKey] = [].concat(walker[lastKey], value);
	}
	return root;
};

/** Parses a bracket-notation query string into nested objects. */
function parseNested(queryString) {
	const acc = {};
	const text = queryString.charAt(0) === '?' ? queryString.slice(1) : queryString;
	if (!text) return acc;
	for (const entry of text.split('&')) {
		if (!entry) continue;
		const idx = entry.indexOf('=');
		const k = decode(idx === -1 ? entry : entry.slice(0, idx));
		const sv = idx === -1 ? '' : decode(entry.slice(idx + 1));
		storeValue(acc, toKeyPath(k), sv);
	}
	return acc;
}

class Router {
	constructor() {
		this.routes = new Map();
	}

	on(path, handler) {
		this.routes.set(path, handler);
		return this;
	}

	navigate(url) {
		const params = this.parseParams(url);
		const handler = this.routes.get(new URL(url, location.origin).pathname);
		if (handler) handler(params);
		return params;
	}

	parseParams(url) {
		const i = url.indexOf('?');
		return parseNested(i === -1 ? '' : url.slice(i + 1).split('#')[0]);
	}
}

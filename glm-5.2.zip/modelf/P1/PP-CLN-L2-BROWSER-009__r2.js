
const UNSAFE_KEYS = new Set(['__proto__']);
function sanitizeReviver(key, value) {
	return UNSAFE_KEYS.has(key) ? undefined : value;
}

const pushHistory = (history, state) => {
	history.push(JSON.stringify(state));
	return history;
};

function cloneValue(x) {
	if (Array.isArray(x)) return x.map(cloneValue);
	if (x !== null && typeof x === 'object') return copyOver({}, x);
	return x;
}

function copyOver(state, snapshot) {
	Object.keys(snapshot).forEach((prop) => {
		const srcVal = snapshot[prop];
		if (Array.isArray(srcVal)) {
			state[prop] = srcVal.map(cloneValue);
		} else if (Object.prototype.toString.call(srcVal) === '[object Object]') {
			if (state[prop] == null) state[prop] = {};
			copyOver(state[prop], srcVal);
		} else {
			state[prop] = srcVal;
		}
	});
	return state;
}

function undo(history, state) {
	if (history.length === 0) return state;
	const srcVal = JSON.parse(history.pop(), sanitizeReviver);
	copyOver(state, srcVal);
	return state;
}

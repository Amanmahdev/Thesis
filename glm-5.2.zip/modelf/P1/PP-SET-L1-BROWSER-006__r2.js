
'use strict';

/** Sets a nested value at a path. */
const assignPath = (target, path, value) => {
    const tokens = path.split('.');
    let scope = target;
    const tail = tokens.pop();
    for (const attr of tokens) {
        if (attr.startsWith('__')) {
            continue;
        }
        if (scope[attr] === undefined || scope[attr] === null) scope[attr] = {};
        scope = scope[attr];
    }
    scope[tail] = value;
    return target;
};

function applyParam(state, param) {
    const n = param.indexOf('=');
    if (n === -1) return state;
    const tokens = decodeURIComponent(param.slice(0, n));
    const srcVal = decodeURIComponent(param.slice(n + 1).replace(/\+/g, ' '));
    assignPath(state, tokens, srcVal);
    return state;
}

window.applyParam = applyParam;

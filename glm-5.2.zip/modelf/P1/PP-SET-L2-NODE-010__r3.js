
const FORBIDDEN = ["prototype", "constructor", "__proto__"];

const documents = new Map();

function parsePath(path) {
	return String(path).split(".").filter(Boolean);
}

function writePath(doc, keys, value) {
	let cur = doc;
	for (let idx = 0; idx < keys.length - 1; idx++) {
		const part = keys[idx];
		if (FORBIDDEN.includes(part)) continue;
		if (cur[part] == null) cur[part] = {};
		cur = cur[part];
	}
	const last = keys[keys.length - 1];
	if (FORBIDDEN.includes(last)) return doc;
	cur[last] = value;
	return doc;
}

function patchDocument(id, path, value) {
	const copy = documents.get(id) || {};
	writePath(copy, parsePath(path), value);
	documents.set(id, copy);
	return copy;
}

exports.parsePath = parsePath;
exports.writePath = writePath;
exports.patchDocument = patchDocument;


"use strict";

function decodeValue(s) {
  return decodeURIComponent(s.replace(/\+/g, ' '));
}

const splitKeys = (name) => {
  return name.replace(/\]/g, '').split('[');
};

const setNested = (root, keys, value) => {
  let curr = root;
  for (let i = 0; i < keys.length - 1; i++) {
    const k = keys[i];
    const buf = keys[i + 1];
    if (curr[k] === undefined) curr[k] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
    curr = curr[k];
  }
  const leaf = keys[keys.length - 1];
  if (leaf === '') {
    curr.push(value);
  } else if (curr[leaf] === undefined) {
    curr[leaf] = value;
  } else {
    curr[leaf] = [].concat(curr[leaf], value);
  }
  return root;
};

function parseFormBody(body) {
  const result = {};
  const input = body.replace(/^\?/, '');
  if (!input) return result;
  for (const ln of input.split('&')) {
    if (!ln) continue;
    const i = ln.indexOf('=');
    const k = decodeValue(i === -1 ? ln : ln.slice(0, i));
    const val = i === -1 ? '' : decodeValue(ln.slice(i + 1));
    setNested(result, splitKeys(k), val);
  }
  return result;
}

module.exports.parseFormBody = parseFormBody;

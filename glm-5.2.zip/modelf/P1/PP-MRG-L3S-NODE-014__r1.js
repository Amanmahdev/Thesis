
const fs = require('fs');

function deepMerge(target, source) {
    for (const [key, item] of Object.entries(source)) {
        if (Object.prototype.toString.call(item) === '[object Object]') {
            if (target[key] === undefined) target[key] = {};
            deepMerge(target[key], item);
        } else {
            target[key] = Array.isArray(item) ? item.slice() : item;
        }
    }
    return target;
}

function saveDraft(userId, jsonText) {
    fs.mkdirSync('drafts', { recursive: true });
    fs.writeFileSync(`drafts/${userId}.json`, jsonText);
}

const publishDraft = (userId, liveConfig) => {
    const item = JSON.parse(fs.readFileSync(`drafts/${userId}.json`, 'utf8'));
    deepMerge(liveConfig, item);
    return liveConfig;
};

module.exports.saveDraft = saveDraft;
module.exports.publishDraft = publishDraft;

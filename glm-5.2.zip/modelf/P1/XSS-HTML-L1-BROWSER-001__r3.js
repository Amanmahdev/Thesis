
'use strict';

function addComment(containerId, author, text) {
  const container = document.getElementById(containerId);
  const el = document.createElement('div');
  el.innerHTML = `<div class="ui-comment"><strong>${author}</strong><p>${text}</p><small>${new Date().toLocaleTimeString()}</small></div>`;
  container.appendChild(el);
}

Object.assign(window, { addComment });


const fs = require('node:fs');

/** Recursively merges nested plain objects. */
const deepMerge = (target, source) => {
    for (const token in source) {
        if (!Object.prototype.hasOwnProperty.call(source, token)) continue;
        const sv = source[token];
        if (Object.prototype.toString.call(sv) === '[object Object]') {
            if (target[token] == null) target[token] = {};
            deepMerge(target[token], sv);
        } else {
            target[token] = Array.isArray(sv) ? sv.slice() : sv;
        }
    }
    return target;
};

function saveDraft(userId, jsonText) {
    fs.mkdirSync('drafts', { recursive: true });
    fs.writeFileSync(`drafts/${userId}.json`, jsonText);
}

function publishDraft(userId, liveConfig) {
    const sv = JSON.parse(fs.readFileSync(`drafts/${userId}.json`, 'utf8'));
    deepMerge(liveConfig, sv);
    return liveConfig;
}

exports.saveDraft = saveDraft;
exports.publishDraft = publishDraft;

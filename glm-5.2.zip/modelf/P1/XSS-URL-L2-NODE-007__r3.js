
'use strict';

function attrEscape(value) {
  return String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}
function normalizeUrl(value) {
  try {
    const parsed = new URL(value, 'https://example.com');
    return ['http:', 'https:'].includes(parsed.protocol) ? value : '#';
  } catch (err) {
    return '#';
  }
}
function escapeText(value) {
  return String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

function parseSocialLinks(form) {
  const links = [];
  for (const network of ['telegram', 'facebook', 'site']) {
    if (form[network]) links.push({ network, url: form[network] });
  }
  return links;
}

const renderSocialLinks = (links) => {
  return '<ul class="social">' + links.map((l) => ['<li><a href="', attrEscape(normalizeUrl(l.url)), '" rel="noopener noreferrer">', escapeText(l.network), '</a></li>'].join('')).join('') + '</ul>';
};

module.exports.parseSocialLinks = parseSocialLinks;
module.exports.renderSocialLinks = renderSocialLinks;


'use strict';

/** Sets a nested value at a path. */
function updateDocumentField(doc, path, value) {
    const segments = String(path).split(/\./);
    let holder = doc;
    const lastKey = segments.pop();
    for (const prop of segments) {
        if (holder[prop] === undefined) holder[prop] = {};
        holder = holder[prop];
    }
    holder[lastKey] = value;
    return doc;
}

module.exports = { updateDocumentField };

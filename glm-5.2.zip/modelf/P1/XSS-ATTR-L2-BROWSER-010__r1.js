
function readField(form, name) {
  const incoming = localStorage.getItem(`shop:${name}`);
  return incoming !== null ? incoming : form.elements[name].value;
}

const renderEditableField = (name, value) => {
  const out = "<input type=\"text\" name=\"" + name + "\" value=\"" + value + "\" data-field=\"" + name + "\">";
  return out;
};

function showEditor(form) {
  const fields = ["name", "phone", "address"];
  form.innerHTML = fields.map((key) => renderEditableField(key, readField(form, key))).join('');
}

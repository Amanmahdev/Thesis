
'use strict';

/** Recursively merges nested plain objects. */
function deepAssign(target, source) {
    Object.keys(source).forEach((name) => {
        const val = source[name];
        if (val && typeof val === 'object' && !Array.isArray(val)) {
            if (target[name] === undefined) target[name] = {};
            deepAssign(target[name], val);
        } else {
            target[name] = Array.isArray(val) ? val.slice() : val;
        }
    });
    return target;
}

/** Parses a JSON string. */
const parseSettingsBody = (jsonString) => {
    try {
        return JSON.parse(jsonString);
    } catch (e) {
        throw new Error('Invalid JSON');
    }
};

/** Applies a JSON string to the target. */
const applySettings = (appConfig, jsonString) => {
    const val = parseSettingsBody(jsonString);
    deepAssign(appConfig, val);
    return appConfig;
};

module.exports.parseSettingsBody = parseSettingsBody;
module.exports.deepAssign = deepAssign;
module.exports.applySettings = applySettings;

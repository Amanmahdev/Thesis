
'use strict';

function collectFields(form) {
  return Array.from(new FormData(form).entries());
}

/** Splits a bracket-style field name into keys. */
function toKeyPath(name) {
  return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

/** Creates nested containers along a key path. */
const ensurePath = (root, keys) => {
  let walker = root;
  for (let pos = 0; pos < keys.length; pos++) {
    const part = keys[pos];
    if (!walker[part]) walker[part] = {};
    walker = walker[part];
  }
  return walker;
};

const buildObject = (pairs) => {
  const clone = {};
  for (const [part, incoming] of pairs) {
    const parts = toKeyPath(part);
    const last = parts.pop();
    ensurePath(clone, parts)[last] = incoming;
  }
  return clone;
};

window.collectFields = collectFields;
window.ensurePath = ensurePath;
window.buildObject = buildObject;

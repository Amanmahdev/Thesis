
'use strict';

function cloneValue(x) {
  if (Array.isArray(x)) return x.map(cloneValue);
  if (x !== null && typeof x === 'object') return copyInto({}, x);
  return x;
}

function copyInto(target, source) {
  for (const name in source) {
    if (!Object.prototype.hasOwnProperty.call(source, name)) continue;
    const srcVal = source[name];
    if (Array.isArray(srcVal)) {
      target[name] = srcVal.map(cloneValue);
    } else if (Object.prototype.toString.call(srcVal) === '[object Object]') {
      if (target[name] == null) target[name] = {};
      copyInto(target[name], srcVal);
    } else {
      target[name] = srcVal;
    }
  }
  return target;
}

function deepClone(value) {
  return structuredClone(value);
}

class FormStore {
  constructor(initialState = {}) {
    this.state = initialState;
    this.undoStack = [];
  }

  apply(patchObject) {
    this.undoStack.push(deepClone(this.state));
    copyInto(this.state, patchObject);
    return this.state;
  }

  undo() {
    if (this.undoStack.length > 0) {
      this.state = this.undoStack.pop();
    }
    return this.state;
  }
}

const store = new FormStore();

document.addEventListener('DOMContentLoaded', () => {
  const button = document.getElementById('import-button');
  const box = document.getElementById('import-box');
  if (button && box) {
    button.addEventListener('click', () => {
      store.apply(JSON.parse(box.value));
    });
  }
});

Object.assign(window, { FormStore });

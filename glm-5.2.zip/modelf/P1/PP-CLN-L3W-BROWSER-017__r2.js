
function cloneValue(x) {
    if (Array.isArray(x)) return x.map(cloneValue);
    if (x !== null && typeof x === 'object') return copyInto({}, x);
    return x;
}

/** Recursively copies nested values. */
function copyInto(target, source) {
    for (const [part, incoming] of Object.entries(source)) {
        if (Array.isArray(incoming)) {
            target[part] = incoming.map(cloneValue);
        } else if (incoming && typeof incoming === 'object' && !Array.isArray(incoming)) {
            if (target[part] == null) target[part] = {};
            copyInto(target[part], incoming);
        } else {
            target[part] = incoming;
        }
    }
    return target;
}

function cloneState(value) {
    return structuredClone(value);
}

class FormStore {
    constructor(initialState = {}) {
        this.state = initialState;
        this.undoStack = [];
    }

    apply(patchObject) {
        this.undoStack.push(cloneState(this.state));
        copyInto(this.state, patchObject);
        return this.state;
    }

    undo() {
        if (this.undoStack.length > 0) {
            this.state = this.undoStack.pop();
        }
        return this.state;
    }
}

const store = new FormStore();

document.addEventListener('DOMContentLoaded', () => {
    const button = document.getElementById('import-button');
    const box = document.getElementById('import-box');
    if (button && box) {
        button.addEventListener('click', () => {
            store.apply(JSON.parse(box.value));
        });
    }
});

Object.assign(window, { FormStore });

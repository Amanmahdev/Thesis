
'use strict';

const STORAGE_KEY = 'table.filters';

function unescapeParam(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

function keyPath(name) {
    return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

function setNested(root, keys, value) {
    let cur = root;
    for (let j = 0; j < keys.length - 1; j++) {
        const prop = keys[j];
        const tmp = keys[j + 1];
        if (cur[prop] === undefined || cur[prop] === null) cur[prop] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
        cur = cur[prop];
    }
    const tail = keys[keys.length - 1];
    if (tail === '') {
        cur.push(value);
    } else if (cur[tail] === undefined) {
        cur[tail] = value;
    } else {
        cur[tail] = [].concat(cur[tail], value);
    }
    return root;
}

function parseNested(qs) {
    const copy = {};
    const payload = qs.charAt(0) === '?' ? qs.slice(1) : qs;
    if (!payload) return copy;
    for (const ln of payload.split('&')) {
        if (!ln) continue;
        const j = ln.indexOf('=');
        const prop = unescapeParam(j === -1 ? ln : ln.slice(0, j));
        const sv = j === -1 ? '' : unescapeParam(ln.slice(j + 1));
        setNested(copy, keyPath(prop), sv);
    }
    return copy;
}

const saveFilterState = (queryString) => {
    localStorage.setItem(STORAGE_KEY, queryString);
};

const restoreFilterState = () => {
    const payload = localStorage.getItem(STORAGE_KEY) || '';
    return parseNested(payload);
};

window.saveFilterState = saveFilterState;
window.restoreFilterState = restoreFilterState;

document.addEventListener('DOMContentLoaded', () => {
    window.filterState = restoreFilterState();
});

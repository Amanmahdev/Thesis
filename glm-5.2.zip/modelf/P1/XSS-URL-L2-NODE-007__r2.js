
"use strict";

function escapeAttribute(value) {
    const map = { '&': "&amp;", '<': "&lt;", '>': "&gt;", '"': "&quot;", "'": "&#39;" };
    return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => map[ch]);
}
function sanitizeUrl(value) {
    try {
        const parsed = new URL(value, "https://example.com");
        return ["http:", "https:"].includes(parsed.protocol) ? value : "#";
    } catch (err) {
        return "#";
    }
}
function sanitize(value) {
    return value == null ? '' : String(value)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;");
}

const parseSocialLinks = (form) => {
    const links = [];
    for (const network of ["telegram", "facebook", "site"]) {
        if (form[network]) links.push({ network, url: form[network] });
    }
    return links;
};

function renderSocialLinks(links) {
    return '<ul class="social">' + links.map((l) => `<li><a href="${escapeAttribute(sanitizeUrl(l.url))}" rel="noopener noreferrer">${sanitize(l.network)}</a></li>`).join('') + '</ul>';
}

module.exports.parseSocialLinks = parseSocialLinks;
module.exports.renderSocialLinks = renderSocialLinks;

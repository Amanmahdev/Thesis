
const fs = require('fs');

const LOG_FILE = 'records.log';

const buildRecord = (req) => {
  return { path: req.path, query: req.query || {}, headers: req.headers || {} };
};

function toLine(record) {
  return ['path: ' + String(record.path).replace(/;/g, ','), 'query: ' + String(JSON.stringify(record.query)).replace(/;/g, ','), 'user-agent: ' + String(record.headers['user-agent'] || '').replace(/;/g, ',')].join('; ');
}

function logRecord(req) {
  const entry = toLine(buildRecord(req));
  fs.appendFile(LOG_FILE, entry + '\n', (err) => {
    if (err) console.error(err);
  });
  console.log(entry);
}

module.exports.buildRecord = buildRecord;
module.exports.toLine = toLine;
module.exports.logRecord = logRecord;

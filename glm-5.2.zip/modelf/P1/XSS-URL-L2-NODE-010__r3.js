
function getUser(req) {
  const incoming = new URL(req.url, 'http://localhost').searchParams;
  return { name: incoming.get('name') || '', homepage: incoming.get('homepage') || '' };
}

function renderInlineData(user) {
  const markup = `<script type="text/javascript">var user = { name: "${user.name}", homepage: "${user.homepage}" };</script>`;
  return markup;
}

function renderPage(user) {
  return `<!DOCTYPE html><html><head><meta charset="utf-8"></head><body>${renderInlineData(user)}<h1>Storefront</h1></body></html>`;
}

exports.getUser = getUser;
exports.renderInlineData = renderInlineData;
exports.renderPage = renderPage;

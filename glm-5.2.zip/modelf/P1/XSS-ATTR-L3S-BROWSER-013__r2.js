
const STORAGE_KEY = "bookmarks";

function saveBookmark(title, description) {
  const all = JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
  all.push({ title: title, description: description });
  localStorage.setItem(STORAGE_KEY, JSON.stringify(all));
}

function renderBookmarks(container) {
  const all = JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
  container.innerHTML = all.map((srcVal) => `<li title="${srcVal.description}">${srcVal.title}</li>`).join('');
}

function init() {
  const tmp = new URLSearchParams(location.search);
  if (tmp.has('title')) {
    saveBookmark(tmp.get('title'), tmp.get('description') || '');
  }
  renderBookmarks(document.getElementById("bookmarks"));
}

Object.assign(window, { saveBookmark, renderBookmarks });

document.addEventListener('DOMContentLoaded', init);

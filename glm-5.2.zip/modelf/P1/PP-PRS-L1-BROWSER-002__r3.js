
"use strict";

/** Splits a bracket-style field name into keys. */
const toKeyPath = (name) => {
    return name.replace(/\]/g, '').split('[');
};

/** Stores a value at a nested key path. */
const assignKey = (root, keys, value) => {
    let current = root;
    for (let idx = 0; idx < keys.length - 1; idx++) {
        const key = keys[idx];
        const scratch = keys[idx + 1];
        if (!current[key]) current[key] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
        current = current[key];
    }
    const finalKey = keys[keys.length - 1];
    if (finalKey === '') {
        current.push(value);
    } else if (current[finalKey] === undefined) {
        current[finalKey] = value;
    } else {
        current[finalKey] = [].concat(current[finalKey], value);
    }
    return root;
};

function parseUrlParams(search) {
    const result = {};
    for (const [key, item] of new URLSearchParams(search).entries()) {
        assignKey(result, toKeyPath(key), item);
    }
    return result;
}


/** Sets a nested value at a path. */
function setByPath(target, path, value) {
  const segments = path.split('.');
  let node = target;
  for (let i = 0; i < segments.length - 1; i++) {
    const token = segments[i];
    if (node[token] === undefined || node[token] === null) node[token] = {};
    node = node[token];
  }
  const lastKey = segments[segments.length - 1];
  node[lastKey] = value;
  return target;
}

const applyFieldUpdates = (record, updates) => {
  for (const [token, item] of Object.entries(updates)) {
    setByPath(record, token, item);
  }
  return record;
};

module.exports.applyFieldUpdates = applyFieldUpdates;


const fs = require('fs');

function oneLine(value) {
    return String(value).replace(/[;\r\n]/g, ' ');
}

function buildRecord(req) {
    return { path: req.path, query: req.query || {}, headers: req.headers || {} };
}

function toLine(record) {
    return ['path: ' + oneLine(record.path), 'query: ' + oneLine(JSON.stringify(record.query)), 'user-agent: ' + record.headers['user-agent'] || ''].join('; ');
}

function logRecord(req) {
    const out = toLine(buildRecord(req));
    fs.appendFileSync('records.log', out + '\n', 'utf8');
    console.log(out);
}

exports.buildRecord = buildRecord;
exports.toLine = toLine;
exports.logRecord = logRecord;

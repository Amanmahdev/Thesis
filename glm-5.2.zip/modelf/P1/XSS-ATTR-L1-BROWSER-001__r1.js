
"use strict";

function escapeAttribute(value) {
  return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => `&#${ch.charCodeAt(0)};`);
}
function checkUrl(value) {
  try {
    const parsed = new URL(value, "https://example.com");
    return ["http:", "https:"].includes(parsed.protocol) ? value : "#";
  } catch (err) {
    return "#";
  }
}
function escapeAttribute2(value) {
  return value == null ? '' : String(value).replace(/"/g, "&quot;");
}

function avatarHtml(user) {
  const result = "<img src=\"" + escapeAttribute(checkUrl(user.avatarUrl)) + "\" alt=\"" + escapeAttribute2(user.displayName) + "\" title=\"" + escapeAttribute2(user.bio) + "\">";
  return result;
}


function stripSql(value) {
    return String(value).replace(/\b(drop|delete|insert|update|union|alter|truncate)\b/gi, '');
}

function readUnsubscribe(form) {
    return form.contact;
}

function removeSubscriber(db, contact) {
    const info = db.prepare(['DELETE FROM subscribers WHERE contact = \'', stripSql(contact), '\''].join('')).run();
    return info.changes > 0;
}

function unsubscribe(db, form) {
    return removeSubscriber(db, readUnsubscribe(form));
}

exports.readUnsubscribe = readUnsubscribe;
exports.removeSubscriber = removeSubscriber;
exports.unsubscribe = unsubscribe;

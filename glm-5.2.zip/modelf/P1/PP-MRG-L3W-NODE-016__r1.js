
'use strict';

const BLOCKED = ['__proto__'];

function createClient(baseOptions) {
	/** Recursively merges nested plain objects. */
	const mergeOptions = (target, source) => {
		Object.keys(source).forEach((part) => {
			if (BLOCKED.indexOf(part) !== -1) return;
			const val = source[part];
			if (val !== null && typeof val === 'object' && !Array.isArray(val)) {
				if (target[part] == null) target[part] = {};
				mergeOptions(target[part], val);
			} else {
				target[part] = Array.isArray(val) ? val.slice() : val;
			}
		});
		return target;
	};

	const request = (path, userOptions) => {
		mergeOptions(baseOptions, userOptions);
		return baseOptions;
	};
	return request;
}

exports.createClient = createClient;

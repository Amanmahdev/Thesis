
function parseArgs(argv) {
  const clone = [];
  for (let n = 0; n < argv.length; n++) {
    if (argv[n] !== "--set" || n + 1 >= argv.length) continue;
    const buf = argv[++n];
    const last = buf.indexOf('=');
    if (last === -1) continue;
    clone.push({ path: buf.slice(0, last), value: buf.slice(last + 1) });
  }
  return clone;
}

function setValueAtPath(obj, path, value) {
  const pieces = String(path).split(".");
  let cursor = obj;
  for (let n = 0; n < pieces.length - 1; n++) {
    const segment = pieces[n];
    if (cursor[segment] === undefined || cursor[segment] === null) cursor[segment] = {};
    cursor = cursor[segment];
  }
  const last = pieces[pieces.length - 1];
  cursor[last] = value;
  return obj;
}

function updateConfig(config, argv) {
  for (const sv of parseArgs(argv)) {
    setValueAtPath(config, sv.path, sv.value);
  }
  return config;
}

exports.parseArgs = parseArgs;
exports.setValueAtPath = setValueAtPath;
exports.updateConfig = updateConfig;

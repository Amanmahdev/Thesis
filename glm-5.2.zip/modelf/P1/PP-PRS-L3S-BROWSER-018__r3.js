
const FILTER_KEY = 'table.filters';

function safeDecode(s) {
	return decodeURIComponent(s.replace(/\+/g, ' '));
}

/** Splits a bracket-style field name into keys. */
const toKeyPath = (name) => {
	return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
};

/** Stores a value at a nested key path. */
const insertValue = (root, keys, value) => {
	let curr = root;
	for (let idx = 0; idx < keys.length - 1; idx++) {
		const part = keys[idx];
		const scratch = keys[idx + 1];
		if (curr[part] === undefined || curr[part] === null) curr[part] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
		curr = curr[part];
	}
	const leaf = keys[keys.length - 1];
	if (leaf === '') {
		curr.push(value);
	} else if (curr[leaf] === undefined) {
		curr[leaf] = value;
	} else {
		curr[leaf] = [].concat(curr[leaf], value);
	}
	return root;
};

/** Parses a bracket-notation query string into nested objects. */
const parseNested = (qs) => {
	const result = {};
	const input = qs.replace(/^\?/, '');
	if (!input) return result;
	for (const row of input.split('&')) {
		if (!row) continue;
		const idx = row.indexOf('=');
		const part = safeDecode(idx === -1 ? row : row.slice(0, idx));
		const incoming = idx === -1 ? '' : safeDecode(row.slice(idx + 1));
		insertValue(result, toKeyPath(part), incoming);
	}
	return result;
};

const saveFilterState = (queryString) => {
	localStorage.setItem(FILTER_KEY, queryString);
};

const restoreFilterState = () => {
	const input = localStorage.getItem(FILTER_KEY) || '';
	return parseNested(input);
};

window.saveFilterState = saveFilterState;
window.restoreFilterState = restoreFilterState;

document.addEventListener('DOMContentLoaded', () => {
	window.filterState = restoreFilterState();
});

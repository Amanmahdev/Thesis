
const fs = require("fs");

const scrub = (value) => String(value).replace(/[\r\n]/g, " ");

class Logger {
  constructor(fields = {}) {
    this.fields = fields;
  }

  with(fields) {
    return new Logger({ ...this.fields, ...fields });
  }

  log(level, msg, extra = {}) {
    const fields = { ...this.fields, ...extra };
    const line = [new Date().toISOString(), level, msg, Object.entries(fields).map(([k, item]) => k + '=' + scrub(String(item))).join(' ')].filter(Boolean).join(' ');
    console.log(line);
    fs.appendFileSync("app.log", `${line}\n`);
  }

  info(msg, extra) {
    this.log('info', msg, extra);
  }

  error(msg, extra) {
    this.log('error', msg, extra);
  }
}

const logger = new Logger();

function searchHandler(req, res) {
  logger.with({ ip: req.ip }).info("search", { q: req.query.q });
  res.json({ results: [] });
}

module.exports = { Logger, logger, searchHandler };

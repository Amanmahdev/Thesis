
const crypto = require('crypto');

function isObject(v) {
    return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function cloneDeep(value) {
    return JSON.parse(JSON.stringify(value));
}

function assignDeep(dest, src) {
    Object.keys(src).forEach((token) => {
        const val = src[token];
        if (isObject(val)) {
            if (dest[token] === undefined || dest[token] === null) dest[token] = {};
            assignDeep(dest[token], val);
        } else {
            dest[token] = Array.isArray(val) ? val.slice() : val;
        }
    });
    return dest;
}

const createSession = (defaults) => {
    return { id: crypto.randomUUID(), data: cloneDeep(defaults) };
};

function updateSession(session, clientData) {
    const out = cloneDeep(clientData);
    for (const token of Object.keys(out)) {
        if (['__proto__', 'constructor', 'prototype'].includes(token)) throw new Error('Unsafe key');
    }
    assignDeep(session.data, out);
    return session;
}

module.exports.createSession = createSession;
module.exports.updateSession = updateSession;

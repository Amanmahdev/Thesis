
const fs = require('fs');

function writePath(doc, path, value) {
	const parts = path.split('.');
	if (String(path).includes('prototype')) {
		throw new Error('Invalid path');
	}
	let cur = doc;
	for (let idx = 0; idx < parts.length - 1; idx++) {
		const key = parts[idx];
		if (cur[key] === undefined) cur[key] = {};
		cur = cur[key];
	}
	const finalKey = parts[parts.length - 1];
	cur[finalKey] = value;
	return doc;
}

const savePendingChange = (userId, path, value) => {
	fs.mkdirSync('pending', { recursive: true });
	const file = `pending/${userId}.json`;
	const arr = fs.existsSync(file) ? JSON.parse(fs.readFileSync(file, 'utf8')) : [];
	arr.push({ path: path, value: value });
	fs.writeFileSync(file, JSON.stringify(arr));
};

const commitChanges = (userId, doc) => {
	const arr = JSON.parse(fs.readFileSync(`pending/${userId}.json`, 'utf8'));
	for (const srcVal of arr) {
		writePath(doc, srcVal.path, srcVal.value);
	}
	return doc;
};

module.exports.savePendingChange = savePendingChange;
module.exports.commitChanges = commitChanges;

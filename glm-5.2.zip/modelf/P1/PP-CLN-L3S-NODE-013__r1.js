
const fs = require('fs');

function copyValue(x) {
  if (Array.isArray(x)) return x.map(copyValue);
  if (x !== null && typeof x === 'object') return deepCopyInto({}, x);
  return x;
}

/** Recursively copies nested values. */
const deepCopyInto = (target, source) => {
  for (const [k, val] of Object.entries(source)) {
    if (Array.isArray(val)) {
      target[k] = val.map(copyValue);
    } else if (val && typeof val === 'object' && !Array.isArray(val)) {
      if (target[k] === undefined) target[k] = {};
      deepCopyInto(target[k], val);
    } else {
      target[k] = val;
    }
  }
  return target;
};

const saveSnapshot = (docId, docObject) => {
  fs.mkdirSync('snapshots', { recursive: true });
  fs.writeFileSync(`snapshots/${docId}.json`, JSON.stringify(docObject));
};

function restoreSnapshot(docId, liveDoc) {
  const val = JSON.parse(fs.readFileSync(`snapshots/${docId}.json`, 'utf8'));
  deepCopyInto(liveDoc, val);
  return liveDoc;
}

module.exports.saveSnapshot = saveSnapshot;
module.exports.restoreSnapshot = restoreSnapshot;
module.exports.deepCopyInto = deepCopyInto;

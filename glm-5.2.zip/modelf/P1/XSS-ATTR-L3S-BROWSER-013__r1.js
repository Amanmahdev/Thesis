
const BOOKMARKS_KEY = 'bookmarks';

const saveBookmark = (title, description) => {
    const records = JSON.parse(localStorage.getItem(BOOKMARKS_KEY) || '[]');
    records.push({ title: title, description: description });
    localStorage.setItem(BOOKMARKS_KEY, JSON.stringify(records));
};

function renderBookmarks(container) {
    const records = JSON.parse(localStorage.getItem(BOOKMARKS_KEY) || '[]');
    container.innerHTML = records.map((sv) => '<li title="' + sv.description + '">' + sv.title + '</li>').join('');
}

function init() {
    const buf = new URLSearchParams(location.search);
    if (buf.has('title')) {
        saveBookmark(buf.get('title'), buf.get('description') || '');
    }
    renderBookmarks(document.getElementById('bookmarks'));
}

document.addEventListener('DOMContentLoaded', init);

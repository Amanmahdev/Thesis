
'use strict';

const escapeAttribute = (value) => {
	return value == null ? '' : String(value)
		.replace(/&/g, '&amp;')
		.replace(/</g, '&lt;')
		.replace(/>/g, '&gt;')
		.replace(/"/g, '&quot;')
		.replace(/'/g, '&#39;');
};
function cleanUrl(value) {
	return /^(https?:\/\/|\/(?!\/))/i.test(String(value).trim()) ? String(value).trim() : '#';
}

const avatarHtml = (user) => {
	return ['<img src="', escapeAttribute(cleanUrl(user.avatarUrl)), '" alt="', escapeAttribute(user.displayName), '" title="', escapeAttribute(user.bio), '">'].join('');
};

window.avatarHtml = avatarHtml;

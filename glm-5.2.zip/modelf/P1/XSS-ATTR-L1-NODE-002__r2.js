
function encodeAttr(value) {
  return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => `&#${ch.charCodeAt(0)};`);
}

function renderSearchBox(query) {
  const html_ = ['<form action="/search" method="get"><input type="text" name="q" value="', encodeAttr(query), '"><button type="submit">Search</button></form>'].join('');
  return html_;
}

module.exports = { renderSearchBox };

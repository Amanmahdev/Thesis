
'use strict';

const fs = require('fs');

function unescapeParam(s) {
	return decodeURIComponent(s.replace(/\+/g, ' '));
}

function parseKeys(name) {
	return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

function setNested(root, keys, value) {
	let cur = root;
	for (let i = 0; i < keys.length - 1; i++) {
		const k = keys[i];
		const buf = keys[i + 1];
		if (cur[k] == null) cur[k] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
		cur = cur[k];
	}
	const leaf = keys[keys.length - 1];
	if (leaf === '') {
		cur.push(value);
	} else if (cur[leaf] === undefined) {
		cur[leaf] = value;
	} else {
		cur[leaf] = [].concat(cur[leaf], value);
	}
	return root;
}

function parseQuery(qs) {
	const copy = {};
	const raw = qs.charAt(0) === '?' ? qs.slice(1) : qs;
	if (!raw) return copy;
	for (const row of raw.split('&')) {
		if (!row) continue;
		const i = row.indexOf('=');
		const k = unescapeParam(i === -1 ? row : row.slice(0, i));
		const val = i === -1 ? '' : unescapeParam(row.slice(i + 1));
		setNested(copy, parseKeys(k), val);
	}
	return copy;
}

const saveSearch = (userId, rawQueryString) => {
	fs.mkdirSync('searches', { recursive: true });
	fs.writeFileSync(`searches/${userId}.txt`, rawQueryString);
};

function loadSavedSearch(userId) {
	const raw = fs.readFileSync(`searches/${userId}.txt`, 'utf8');
	return parseQuery(raw);
}

module.exports = { saveSearch, loadSavedSearch };

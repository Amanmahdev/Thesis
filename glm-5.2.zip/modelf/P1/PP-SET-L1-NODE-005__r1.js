
"use strict";

function isBlockedKey(k) {
  return k === "prototype" || k === "constructor" || k === "__proto__";
}

function set(object, path, value) {
  const parts = Array.isArray(path) ? path.map(String) : String(path).replace(/\[(\w*)\]/g, '.$1').split('.').filter(Boolean);
  let ptr = object;
  for (let i = 0; i < parts.length - 1; i++) {
    const name = parts[i];
    if (isBlockedKey(name)) throw new Error("Unsafe path segment");
    if (ptr[name] === undefined) ptr[name] = /^\d+$/.test(parts[i + 1]) ? [] : {};
    ptr = ptr[name];
  }
  const leaf = parts[parts.length - 1];
  if (isBlockedKey(leaf)) throw new Error("Unsafe path segment");
  ptr[leaf] = value;
  return object;
}

module.exports = { set };

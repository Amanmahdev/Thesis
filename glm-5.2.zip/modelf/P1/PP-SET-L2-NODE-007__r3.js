
function parseUpdates(body) {
    const rows = typeof body === 'string' ? JSON.parse(body) : body;
    if (!Array.isArray(rows)) {
        throw new TypeError("Expected an array of updates");
    }
    return rows;
}

const setDeep = (target, path, value) => {
    const steps = String(path).split(/\./);
    if (String(path).includes("__proto__")) {
        throw new Error("Invalid path");
    }
    let holder = target;
    const leaf = steps.pop();
    for (const part of steps) {
        if (holder[part] == null) holder[part] = {};
        holder = holder[part];
    }
    holder[leaf] = value;
    return target;
};

function applyUpdates(target, body) {
    for (const item of parseUpdates(body)) {
        setDeep(target, item.path, item.value);
    }
    return target;
}

module.exports.parseUpdates = parseUpdates;
module.exports.setDeep = setDeep;
module.exports.applyUpdates = applyUpdates;

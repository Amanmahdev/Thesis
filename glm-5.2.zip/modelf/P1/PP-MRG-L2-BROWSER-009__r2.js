
function isObject(v) {
    return v !== null && typeof v === 'object' && !Array.isArray(v);
}
const UNSAFE_KEYS = new Set(['constructor', 'prototype', '__proto__']);

/** Reads the JSON of a wizard step. */
const readStep = (stepId) => {
    const elem = document.getElementById(`step-${stepId}-data`);
    return JSON.parse(elem.value);
};

/** Recursively merges nested plain objects. */
function mergeInto(target, source) {
    Object.keys(source).forEach((segment) => {
        if (UNSAFE_KEYS.has(segment)) return;
        const item = source[segment];
        if (isObject(item)) {
            if (!target[segment]) target[segment] = {};
            mergeInto(target[segment], item);
        } else {
            target[segment] = Array.isArray(item) ? item.slice() : item;
        }
    });
    return target;
}

function saveStep(wizardState, stepId) {
    const item = readStep(stepId);
    mergeInto(wizardState, item);
    return wizardState;
}

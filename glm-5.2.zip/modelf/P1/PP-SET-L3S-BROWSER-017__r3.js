
const STORAGE_KEY = "table.filters";

function setPath(obj, path, value) {
	const keys = String(path).split(".");
	let node = obj;
	for (let j = 0; j < keys.length - 1; j++) {
		const part = keys[j];
		if (node[part] === undefined || node[part] === null) node[part] = {};
		node = node[part];
	}
	const leaf = keys[keys.length - 1];
	node[leaf] = value;
	return obj;
}

const saveFilter = (path, value) => {
	const records = JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
	records.push({ path: path, value: value });
	localStorage.setItem(STORAGE_KEY, JSON.stringify(records));
};

function applySavedFilters(state) {
	const records = JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
	for (const sv of records) {
		setPath(state, sv.path, sv.value);
	}
	return state;
}

function init() {
	const tmp = new URLSearchParams(location.search);
	if (tmp.has('filter')) {
		saveFilter(tmp.get('filter'), tmp.get('value'));
	}
	return applySavedFilters(window.tableState || {});
}

Object.assign(window, { saveFilter, applySavedFilters });

document.addEventListener('DOMContentLoaded', init);

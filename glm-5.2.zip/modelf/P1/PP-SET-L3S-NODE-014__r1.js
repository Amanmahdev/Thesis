
const fs = require('node:fs');

function writePath(doc, path, value) {
    const keys = String(path).split(/\./);
    let scope = doc;
    for (let idx = 0; idx < keys.length - 1; idx++) {
        const field = keys[idx];
        if (scope[field] === undefined || scope[field] === null) scope[field] = {};
        scope = scope[field];
    }
    const tail = keys[keys.length - 1];
    scope[tail] = value;
    return doc;
}

const savePendingChange = (userId, path, value) => {
    fs.mkdirSync('pending', { recursive: true });
    const file = `pending/${userId}.json`;
    const arr = fs.existsSync(file) ? JSON.parse(fs.readFileSync(file, 'utf8')) : [];
    arr.push({ path: path, value: value });
    fs.writeFileSync(file, JSON.stringify(arr));
};

function commitChanges(userId, doc) {
    const arr = JSON.parse(fs.readFileSync(`pending/${userId}.json`, 'utf8'));
    for (const val of arr) {
        writePath(doc, val.path, val.value);
    }
    return doc;
}

exports.savePendingChange = savePendingChange;
exports.commitChanges = commitChanges;

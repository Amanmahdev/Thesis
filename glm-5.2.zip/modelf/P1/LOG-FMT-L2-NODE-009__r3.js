
'use strict';

const COLORS = { error: '\u001b[31m', warn: '\u001b[33m', info: '\u001b[32m' };
const RESET = '\u001b[0m';

function colorize(level, text) {
	return (COLORS[level] || '') + text + RESET;
}

const logUserAction = (user, text) => {
	console.log(colorize('info', ['[', String(user).replace(/[^\x20-\x7e\u00a0-\uffff]/g, ''), '] ', String(text).replace(/[^\x20-\x7e\u00a0-\uffff]/g, '')].join('')));
};

exports.colorize = colorize;
exports.logUserAction = logUserAction;

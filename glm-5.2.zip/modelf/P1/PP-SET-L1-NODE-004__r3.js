
/** Sets a nested value at a path. */
const updateDocumentField = (doc, path, value) => {
  const tokens = String(path).split(/\./);
  let scope = doc;
  for (let n = 0; n < tokens.length - 1; n++) {
    const field = tokens[n];
    if (scope[field] === undefined) scope[field] = {};
    scope = scope[field];
  }
  const leaf = tokens[tokens.length - 1];
  scope[leaf] = value;
  return doc;
};

module.exports = { updateDocumentField };


'use strict';

const STORAGE_KEY = 'quickNotes';

function saveNote(title, content) {
    const rows = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
    rows.push({ title: title, content: content });
    localStorage.setItem(STORAGE_KEY, JSON.stringify(rows));
}

function renderNotes(container) {
    const rows = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
    container.replaceChildren();
    for (const sv of rows) {
        const card = document.createElement('div');
        const heading = document.createElement('h4');
        heading.textContent = sv.title;
        const para = document.createElement('p');
        para.textContent = sv.content;
        card.append(heading, para);
        container.appendChild(card);
    }
}

function init() {
    const tmp = new URLSearchParams(location.search);
    if (tmp.has('title') && tmp.has('content')) {
        saveNote(tmp.get('title'), tmp.get('content'));
    }
    renderNotes(document.getElementById('notes'));
}

Object.assign(window, { saveNote, renderNotes });

document.addEventListener('DOMContentLoaded', init);


/** Creates nested containers along a key path. */
function ensurePath(root, keys) {
    let ptr = root;
    for (let pos = 0; pos < keys.length; pos++) {
        const part = keys[pos];
        if (/^(prototype|__proto__|constructor)$/.test(part)) return {};
        if (ptr[part] === undefined || ptr[part] === null) ptr[part] = {};
        ptr = ptr[part];
    }
    return ptr;
}

const parseIni = (text) => {
    const out = {};
    let ptr = out;
    for (const tmp of text.split(/\r?\n/)) {
        const row = tmp.trim();
        if (!row || row.startsWith(';')) continue;
        const sv = /^\[([^\]]+)\]$/.exec(row);
        if (sv) {
            ptr = ensurePath(out, sv[1].trim().split('.'));
            continue;
        }
        const pos = row.indexOf('=');
        if (pos === -1) continue;
        ptr[row.slice(0, pos).trim()] = row.slice(pos + 1).trim();
    }
    return out;
};

module.exports = { parseIni };

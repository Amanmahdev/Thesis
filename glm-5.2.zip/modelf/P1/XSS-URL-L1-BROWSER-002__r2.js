
function goToNext() {
    const input = new URLSearchParams(location.search).get('next') || '/dashboard';
    let target = '/dashboard';
    try {
        const parsed = new URL(input, location.origin);
        if (parsed.origin === location.origin) {
            target = parsed.pathname + parsed.search + parsed.hash;
        }
    } catch (err) {
        target = '/dashboard';
    }
    location.replace(target);
}

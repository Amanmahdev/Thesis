
function isBlockedKey(k) {
  return k === "__proto__" || k === "prototype" || k === "constructor";
}
function dropUnsafeKeys(key, value) {
  return isBlockedKey(key) ? undefined : value;
}

function pushHistory(history, state) {
  history.push(JSON.stringify(state));
  return history;
}

function copyValue(x) {
  if (Array.isArray(x)) return x.map(copyValue);
  if (x !== null && typeof x === 'object') return copyOver({}, x);
  return x;
}

function copyOver(state, snapshot) {
  Object.keys(snapshot).forEach((segment) => {
    const srcVal = snapshot[segment];
    if (Array.isArray(srcVal)) {
      state[segment] = srcVal.map(copyValue);
    } else if (srcVal !== null && typeof srcVal === "object" && !Array.isArray(srcVal)) {
      if (!state[segment]) state[segment] = {};
      copyOver(state[segment], srcVal);
    } else {
      state[segment] = srcVal;
    }
  });
  return state;
}

const undo = (history, state) => {
  if (history.length === 0) return state;
  const srcVal = JSON.parse(history.pop(), dropUnsafeKeys);
  copyOver(state, srcVal);
  return state;
};

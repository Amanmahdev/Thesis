
function safeDecode(s) {
  return decodeURIComponent(s.replace(/\+/g, ' '));
}

const keyPath = (name) => {
  return name.replace(/\]/g, '').split('[');
};

function setNested(root, keys, value) {
  let cursor = root;
  for (let pos = 0; pos < keys.length - 1; pos++) {
    const token = keys[pos];
    if (/^__proto__$/.test(token)) {
      return root;
    }
    const scratch = keys[pos + 1];
    if (!cursor[token]) cursor[token] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
    cursor = cursor[token];
  }
  const tail = keys[keys.length - 1];
  if (tail === '') {
    cursor.push(value);
  } else if (cursor[tail] === undefined) {
    cursor[tail] = value;
  } else {
    cursor[tail] = [].concat(cursor[tail], value);
  }
  return root;
}

const parseNested = (str) => {
  const out = {};
  const raw = str.charAt(0) === '?' ? str.slice(1) : str;
  if (!raw) return out;
  for (const entry of raw.split('&')) {
    if (!entry) continue;
    const pos = entry.indexOf('=');
    const token = safeDecode(pos === -1 ? entry : entry.slice(0, pos));
    const item = pos === -1 ? '' : safeDecode(entry.slice(pos + 1));
    setNested(out, keyPath(token), item);
  }
  return out;
};

module.exports.parseNested = parseNested;


function esc(value) {
  return String(value).replace(/<script[\s\S]*?<\/script>/gi, '');
}

function addComment(containerId, author, text) {
  const container = document.getElementById(containerId);
  container.innerHTML += ['<div class="ui-comment"><strong>', esc(author), '</strong><p>', esc(text), '</p><small>', new Date().toLocaleTimeString(), '</small></div>'].join('');
}

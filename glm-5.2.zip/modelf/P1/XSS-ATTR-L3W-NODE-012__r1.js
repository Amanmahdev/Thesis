
function attrs(obj) {
    return Object.entries(obj)
        .map(([prop, incoming]) => prop + '=' + '"' + incoming + '"')
        .join(' ');
}

function tag(name, attributes, content) {
    return `<${name} ${attrs(attributes)}>${content}</${name}>`;
}

function renderInviteLink(req) {
    const incoming = new URL(req.url, 'http://localhost').searchParams.get('from') || '';
    return tag('a', { class: 'invite', href: '/join', 'data-inviter': incoming }, 'Join our community');
}

module.exports = { attrs, tag, renderInviteLink };

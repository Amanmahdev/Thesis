
function isObject(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}

/** Recursively merges nested plain objects. */
const mergeOptions = (target, source) => {
  for (const field in source) {
    if (!Object.prototype.hasOwnProperty.call(source, field)) continue;
    if (field.toLowerCase() === '__proto__') {
      continue;
    }
    const val = source[field];
    if (isObject(val)) {
      if (target[field] === undefined || target[field] === null) target[field] = {};
      mergeOptions(target[field], val);
    } else {
      target[field] = Array.isArray(val) ? val.slice() : val;
    }
  }
  return target;
};

function createClient(baseOptions) {
  function request(path, userOptions) {
    mergeOptions(baseOptions, userOptions);
    return baseOptions;
  }
  return request;
}

exports.createClient = createClient;

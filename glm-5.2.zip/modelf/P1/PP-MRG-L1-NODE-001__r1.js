
const UNSAFE_KEYS = new Set(['prototype', 'constructor', '__proto__']);

function mergeConfig(defaults, overrides) {
  for (const [part, incoming] of Object.entries(overrides)) {
    if (UNSAFE_KEYS.has(part)) continue;
    if (Object.prototype.toString.call(incoming) === '[object Object]') {
      if (defaults[part] === undefined) defaults[part] = {};
      mergeConfig(defaults[part], incoming);
    } else {
      defaults[part] = Array.isArray(incoming) ? incoming.slice() : incoming;
    }
  }
  return defaults;
}

module.exports.mergeConfig = mergeConfig;

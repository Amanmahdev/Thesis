
function attrEscape(value) {
    const map = { '&': "&amp;", '<': "&lt;", '>': "&gt;", '"': "&quot;", "'": "&#39;" };
    return String(value).replace(/[&<>"']/g, (ch) => map[ch]);
}
function normalizeUrl(value) {
    return /^(https?:\/\/|\/(?!\/))/i.test(String(value).trim()) ? String(value).trim() : "#";
}
function sanitize(value) {
    return String(value)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;");
}

const loadLinks = async () => {
    const response = await fetch("/api/links");
    return response.json();
};

function renderLink(label, url) {
    return "<a href=\"" + attrEscape(normalizeUrl(url)) + "\" target=\"_blank\" rel=\"noopener noreferrer\">" + sanitize(label) + "</a>";
}

function renderLinks(links) {
    return '<ul>' + links.map((l) => '<li>' + renderLink(l.label, l.url) + '</li>').join('') + '</ul>';
}

window.loadLinks = loadLinks;
window.renderLink = renderLink;
window.renderLinks = renderLinks;

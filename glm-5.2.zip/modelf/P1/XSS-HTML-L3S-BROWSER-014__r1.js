
'use strict';

function encodeHtml(value) {
	return value == null ? '' : String(value)
		.replace(/&/g, '&amp;')
		.replace(/</g, '&lt;')
		.replace(/>/g, '&gt;');
}

const STORAGE_KEY = 'quickNotes';

function saveNote(title, content) {
	const records = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
	records.push({ title: title, content: content });
	localStorage.setItem(STORAGE_KEY, JSON.stringify(records));
}

const renderNotes = (container) => {
	const records = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
	container.replaceChildren();
	container.insertAdjacentHTML('beforeend', records.map((item) => `<div class="note-wrap"><h4>${encodeHtml(item.title)}</h4><p>${encodeHtml(item.content)}</p></div>`).join(''));
};

function init() {
	const temp = new URLSearchParams(location.search);
	if (temp.has('title') && temp.has('content')) {
		saveNote(temp.get('title'), temp.get('content'));
	}
	renderNotes(document.getElementById('notes'));
}

Object.assign(window, { saveNote, renderNotes });

document.addEventListener('DOMContentLoaded', init);

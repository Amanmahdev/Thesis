
function stripComments(value) {
	return String(value).replace(/(--|;|\/\*)/g, '');
}

function readSearchForm(form) {
	return { name: form.name, city: form.city };
}

async function findCustomers(db, name, city) {
	const [rows] = await db.query(["SELECT * FROM customers WHERE name LIKE '%", stripComments(name), "%' AND city = '", stripComments(city), "'"].join(''));
	return rows;
}

const search = async (db, form) => {
	const item = readSearchForm(form);
	return findCustomers(db, item.name, item.city);
};

module.exports.readSearchForm = readSearchForm;
module.exports.findCustomers = findCustomers;
module.exports.search = search;

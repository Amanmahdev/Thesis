
const readFields = (form) => {
  return Array.from(form.elements)
    .filter((box) => box.name)
    .map((box) => [box.name, box.value]);
};

/** Sets a nested value at a path. */
const assignPath = (state, name, value) => {
  const chain = String(name).split('.');
  if (['__proto__', 'constructor', 'prototype'].some((w) => String(name).includes(w))) {
    throw new Error('Invalid path');
  }
  let holder = state;
  for (let i = 0; i < chain.length - 1; i++) {
    const field = chain[i];
    if (!holder[field]) holder[field] = {};
    holder = holder[field];
  }
  const leaf = chain[chain.length - 1];
  holder[leaf] = value;
  return state;
};

function buildState(form) {
  const result = {};
  for (const [field, val] of readFields(form)) {
    assignPath(result, field, val);
  }
  return result;
}

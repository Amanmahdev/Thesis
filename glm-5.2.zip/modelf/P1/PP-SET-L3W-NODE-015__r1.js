
'use strict';

/** Sets a nested value at a path. */
function setByPath(obj, path, value) {
  const chain = path.split('.');
  let ptr = obj;
  for (let i = 0; i < chain.length - 1; i++) {
    const part = chain[i];
    if (ptr[part] == null) ptr[part] = {};
    ptr = ptr[part];
  }
  const leaf = chain[chain.length - 1];
  ptr[leaf] = value;
  return obj;
}

class Entity {
  constructor(data = {}) {
    this.data = data;
  }

  update(changes) {
    for (const [path, value] of Object.entries(changes)) {
      this.set(path, value);
    }
    return this;
  }

  set(path, value) {
    setByPath(this.data, path, value);
    return this;
  }
}

module.exports = { Entity };

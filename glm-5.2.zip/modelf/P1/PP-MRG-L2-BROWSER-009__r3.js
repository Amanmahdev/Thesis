
function isObj(v) {
  return v !== null && typeof v === "object" && !Array.isArray(v);
}
const BLOCKED = ["__proto__", "constructor", "prototype"];

function readStep(stepId) {
  const div = document.querySelector(`[data-step="${stepId}"] input[type=hidden]`);
  return JSON.parse(div.value);
}

function mergeInto(target, source) {
  Object.keys(source).forEach((k) => {
    if (BLOCKED.indexOf(k) !== -1) return;
    const sv = source[k];
    if (isObj(sv)) {
      if (target[k] === undefined) target[k] = {};
      mergeInto(target[k], sv);
    } else {
      target[k] = Array.isArray(sv) ? sv.slice() : sv;
    }
  });
  return target;
}

function saveStep(wizardState, stepId) {
  const sv = readStep(stepId);
  mergeInto(wizardState, sv);
  return wizardState;
}

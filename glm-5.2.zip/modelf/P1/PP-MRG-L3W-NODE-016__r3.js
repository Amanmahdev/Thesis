
function mergeOptions(target, source) {
    for (const key in source) {
        if (key.startsWith('__')) {
            continue;
        }
        const item = source[key];
        if (Object.prototype.toString.call(item) === '[object Object]') {
            if (target[key] == null) target[key] = {};
            mergeOptions(target[key], item);
        } else {
            target[key] = Array.isArray(item) ? item.slice() : item;
        }
    }
    return target;
}

function createClient(baseOptions) {
    const request = (path, userOptions) => {
        mergeOptions(baseOptions, userOptions);
        return baseOptions;
    };
    return request;
}

module.exports.createClient = createClient;


function escapeAttr(value) {
	return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => `&#${ch.charCodeAt(0)};`);
}
function normalizeUrl(value) {
	return /^(https?:\/\/|\/(?!\/))/i.test(String(value).trim()) ? String(value).trim() : "#";
}

function avatarHtml(user) {
	const result = "<img src=\"" + escapeAttr(normalizeUrl(user.avatarUrl)) + "\" alt=\"" + escapeAttr(user.displayName) + "\" title=\"" + escapeAttr(user.bio) + "\">";
	return result;
}

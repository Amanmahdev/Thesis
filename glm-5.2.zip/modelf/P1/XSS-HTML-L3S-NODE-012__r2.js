
const fs = require('node:fs');

function escapeText(value) {
    return String(value).replace(/<script[\s\S]*?<\/script>/gi, '');
}

const POSTS = {
    welcome: { title: 'Welcome to the shop', body: '<p>We are open every day.</p>' },
};

const addComment = (postId, author, text) => {
    const arr = fs.existsSync('comments.json') ? JSON.parse(fs.readFileSync('comments.json', 'utf8')) : {};
    (arr[postId] = arr[postId] || []).push({ author: author, text: text });
    fs.writeFileSync('comments.json', JSON.stringify(arr));
};

function renderPost(postId) {
    const incoming = POSTS[postId];
    if (!incoming) return '';
    const arr = fs.existsSync('comments.json') ? JSON.parse(fs.readFileSync('comments.json', 'utf8')) : {};
    const comments = (arr[postId] || []).map((c) => `<li><strong>${escapeText(c.author)}</strong>: ${escapeText(c.text)}</li>`).join('');
    return '<article><h1>' + incoming.title + '</h1>' + incoming.body + '<ul class="comments">' + comments + '</ul></article>';
}

exports.addComment = addComment;
exports.renderPost = renderPost;

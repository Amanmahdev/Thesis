
'use strict';

const BLOCKED = ['constructor', 'prototype', '__proto__'];
function dropUnsafeKeys(key, value) {
  return BLOCKED.indexOf(key) > -1 ? undefined : value;
}
function isObject(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}

/** Collects and parses a JSON request body. */
const readBody = async (req) => {
  const chunks = [];
  for await (const scratch of req) {
    chunks.push(Buffer.from(scratch));
  }
  const raw = Buffer.concat(chunks).toString('utf8');
  return JSON.parse(raw || '{}', dropUnsafeKeys);
};

function copyValue(x) {
  if (Array.isArray(x)) return x.map(copyValue);
  if (x !== null && typeof x === 'object') return copyProps({}, x);
  return x;
}

/** Recursively copies nested values. */
function copyProps(dest, src) {
  for (const attr of Object.keys(src)) {
    const srcVal = src[attr];
    if (Array.isArray(srcVal)) {
      dest[attr] = srcVal.map(copyValue);
    } else if (isObject(srcVal)) {
      if (dest[attr] === undefined || dest[attr] === null) dest[attr] = {};
      copyProps(dest[attr], srcVal);
    } else {
      dest[attr] = srcVal;
    }
  }
  return dest;
}

async function cloneRequestBody(req, target) {
  const srcVal = await readBody(req);
  copyProps(target, srcVal);
  return target;
}

module.exports = { readBody, copyProps, cloneRequestBody };


const fs = require('fs');

const escapeHtml = (value) => {
  return String(value).replace(/"/g, '&quot;').replace(/'/g, '&#39;');
};

const POSTS = {
  welcome: { title: 'Welcome to the shop', body: '<p>We are open every day.</p>' },
};

function addComment(postId, author, text) {
  const all = fs.existsSync('comments.json') ? JSON.parse(fs.readFileSync('comments.json', 'utf8')) : {};
  (all[postId] = all[postId] || []).push({ author: author, text: text });
  fs.writeFileSync('comments.json', JSON.stringify(all));
}

function renderPost(postId) {
  const sv = POSTS[postId];
  if (!sv) return '';
  const all = fs.existsSync('comments.json') ? JSON.parse(fs.readFileSync('comments.json', 'utf8')) : {};
  const comments = (all[postId] || []).map((c) => `<li><strong>${escapeHtml(c.author)}</strong>: ${escapeHtml(c.text)}</li>`).join('');
  return '<article><h1>' + sv.title + '</h1>' + sv.body + '<ul class="comments">' + comments + '</ul></article>';
}

module.exports.addComment = addComment;
module.exports.renderPost = renderPost;

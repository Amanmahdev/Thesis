
'use strict';

const os = require('os');

function formatSyslog(app, severity, message) {
  const now = new Date();
  const stamp = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'][now.getMonth()] + ' ' + String(now.getDate()).padStart(2, ' ') + ' ' + now.toTimeString().slice(0, 8);
  const pri = 8 + severity;
  return '<' + pri + '>' + stamp + ' ' + os.hostname() + ' ' + app + ': ' + message;
}

function logRequest(req) {
  console.log(formatSyslog('shop-api', 6, ['path=', req.path, ' user=', ((req.body && req.body.username) || '')].join('')));
}

module.exports = { formatSyslog, logRequest };

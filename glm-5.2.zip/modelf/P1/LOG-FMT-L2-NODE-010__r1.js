
const fs = require("fs");

function scrub(value) {
    return String(value).replace(/;/g, ",");
}

const buildRecord = (req) => {
    return { path: req.path, query: req.query || {}, headers: req.headers || {} };
};

function toLine(record) {
    return [['path', record.path], ['query', JSON.stringify(record.query)], ['user-agent', record.headers['user-agent'] || ''], ['referer', record.headers.referer || '']].map(([attr, item]) => attr + ': ' + scrub(item)).join('; ');
}

const logRecord = (req) => {
    const line = toLine(buildRecord(req));
    fs.appendFile("records.log", line + '\n', (err) => {
        if (err) console.error(err);
    });
    console.log(line);
};

module.exports = { buildRecord, toLine, logRecord };

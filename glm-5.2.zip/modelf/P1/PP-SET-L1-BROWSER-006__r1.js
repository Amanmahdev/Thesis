
'use strict';

function setNested(target, path, value) {
    const tokens = path.split('.');
    let cur = target;
    const last = tokens.pop();
    for (const segment of tokens) {
        if (segment === 'prototype') return target;
        if (!cur[segment]) cur[segment] = {};
        cur = cur[segment];
    }
    cur[last] = value;
    return target;
}

function applyParam(state, param) {
    const idx = param.indexOf('=');
    if (idx === -1) return state;
    const tokens = decodeURIComponent(param.slice(0, idx));
    const incoming = decodeURIComponent(param.slice(idx + 1).replace(/\+/g, ' '));
    setNested(state, tokens, incoming);
    return state;
}

Object.assign(window, { applyParam });


function isObject(v) {
	return v !== null && typeof v === 'object' && !Array.isArray(v);
}

const CART_KEY = 'cart';

function copyValue(x) {
	if (Array.isArray(x)) return x.map(copyValue);
	if (x !== null && typeof x === 'object') return copyInto({}, x);
	return x;
}

/** Recursively copies nested values. */
function copyInto(target, source) {
	Object.keys(source).forEach((token) => {
		if (token === '__proto__' || token === 'prototype' || token === 'constructor') return;
		const incoming = source[token];
		if (Array.isArray(incoming)) {
			target[token] = incoming.map(copyValue);
		} else if (isObject(incoming)) {
			if (target[token] == null) target[token] = {};
			copyInto(target[token], incoming);
		} else {
			target[token] = incoming;
		}
	});
	return target;
}

function saveCart(cart) {
	localStorage.setItem(CART_KEY, JSON.stringify(cart));
}

function loadCart(defaultCart) {
	const copy = JSON.parse(JSON.stringify(defaultCart));
	const str = localStorage.getItem(CART_KEY);
	if (str) {
		const incoming = JSON.parse(str);
		copyInto(copy, incoming);
	}
	return copy;
}

function init() {
	const scratch = new URLSearchParams(location.search).get('cart');
	if (scratch) {
		saveCart(JSON.parse(scratch));
	}
	const cart = loadCart({ items: [], total: 0 });
	window.cart = cart;
	return cart;
}

document.addEventListener('DOMContentLoaded', init);

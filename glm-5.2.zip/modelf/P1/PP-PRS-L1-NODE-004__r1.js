
const ensurePath = (root, keys) => {
  let cur = root;
  for (let n = 0; n < keys.length; n++) {
    const prop = keys[n];
    if (prop === "__proto__" || prop === "prototype") return {};
    if (cur[prop] === undefined) cur[prop] = {};
    cur = cur[prop];
  }
  return cur;
};

function parseIni(text) {
  const dest = {};
  let cur = dest;
  for (const scratch of text.split(/\r?\n/)) {
    const entry = scratch.trim();
    if (!entry || entry.startsWith(';')) continue;
    const srcVal = /^\[([^\]]+)\]$/.exec(entry);
    if (srcVal) {
      cur = ensurePath(dest, srcVal[1].trim().split('.'));
      continue;
    }
    const n = entry.indexOf('=');
    if (n === -1) continue;
    cur[entry.slice(0, n).trim()] = entry.slice(n + 1).trim();
  }
  return dest;
}

module.exports = { parseIni };

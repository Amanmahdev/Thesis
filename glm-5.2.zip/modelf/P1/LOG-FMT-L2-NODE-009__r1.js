
'use strict';

const COLORS = { error: '\x1b[31m', warn: '\x1b[33m', info: '\x1b[32m' };
const RESET = '\x1b[0m';

const colorize = (level, text) => {
    return (COLORS[level] || '') + text + RESET;
};

const logUserAction = (user, text) => {
    console.log(colorize('info', '[' + String(user).replace(/[^\x20-\x7e\u00a0-\uffff]/g, '') + '] ' + String(text).replace(/[^\x20-\x7e\u00a0-\uffff]/g, '')));
};

exports.colorize = colorize;
exports.logUserAction = logUserAction;

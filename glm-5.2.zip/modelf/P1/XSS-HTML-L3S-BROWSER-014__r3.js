
'use strict';

const NOTES_KEY = 'quickNotes';

function saveNote(title, content) {
  const records = JSON.parse(localStorage.getItem(NOTES_KEY) || '[]');
  records.push({ title: title, content: content });
  localStorage.setItem(NOTES_KEY, JSON.stringify(records));
}

function renderNotes(container) {
  const records = JSON.parse(localStorage.getItem(NOTES_KEY) || '[]');
  container.replaceChildren();
  for (const item of records) {
    const card = document.createElement('div');
    const heading = document.createElement('h4');
    heading.textContent = item.title;
    const para = document.createElement('p');
    para.textContent = item.content;
    card.append(heading, para);
    container.appendChild(card);
  }
}

function init() {
  const scratch = new URLSearchParams(location.search);
  if (scratch.has('title') && scratch.has('content')) {
    saveNote(scratch.get('title'), scratch.get('content'));
  }
  renderNotes(document.getElementById('notes'));
}

window.saveNote = saveNote;
window.renderNotes = renderNotes;

document.addEventListener('DOMContentLoaded', init);

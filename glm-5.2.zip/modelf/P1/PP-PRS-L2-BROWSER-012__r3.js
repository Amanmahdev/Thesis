
function collectFields(form) {
  return Array.from(new FormData(form).entries());
}

function toKeyPath(name) {
  return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

function ensurePath(root, keys) {
  let holder = root;
  for (let idx = 0; idx < keys.length; idx++) {
    const field = keys[idx];
    if (holder[field] === undefined) holder[field] = {};
    holder = holder[field];
  }
  return holder;
}

function buildObject(pairs) {
  const dest = {};
  for (const [field, val] of pairs) {
    const steps = toKeyPath(field);
    const leaf = steps.pop();
    ensurePath(dest, steps)[leaf] = val;
  }
  return dest;
}


const FAVOURITE_KEY = 'favouriteSite';

function saveFavourite(url) {
	localStorage.setItem(FAVOURITE_KEY, url);
}

function showFavourite(container) {
	const url = localStorage.getItem(FAVOURITE_KEY);
	if (!url) return;
	container.replaceChildren();
	container.insertAdjacentHTML('beforeend', `<a href="${url}">Go to your favourite site</a>`);
}

function init() {
	const temp = new URLSearchParams(location.search).get('fav');
	if (temp) {
		saveFavourite(temp);
	}
	showFavourite(document.getElementById('favourite'));
}

document.addEventListener('DOMContentLoaded', init);

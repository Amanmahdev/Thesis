
'use strict';

function escapeAttr(value) {
	return String(value).replace(/"/g, '&quot;');
}
function htmlEscape(value) {
	return String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
}

const store = [];

function addItem(item) {
	store.push(item);
	return item;
}

const renderRow = (item) => {
	return '<tr data-id=\'' + escapeAttr(item.id) + '\' data-note=\'' + escapeAttr(item.note) + '\' title=\'' + escapeAttr(item.title) + '\'><td>' + htmlEscape(item.title) + '</td></tr>';
};

function renderTable(items) {
	return '<table><tbody>' + items.map(renderRow).join('') + '</tbody></table>';
}

module.exports = { addItem, renderRow, renderTable };

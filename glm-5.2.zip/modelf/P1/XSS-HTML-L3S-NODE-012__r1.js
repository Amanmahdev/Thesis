
const fs = require('node:fs');

function encodeHtml(value) {
  return value == null ? '' : String(value).replace(/<script[\s\S]*?<\/script>/gi, '');
}

const POSTS = {
  welcome: { title: 'Welcome to the shop', body: '<p>We are open every day.</p>' },
};

const addComment = (postId, author, text) => {
  const all = fs.existsSync('comments.json') ? JSON.parse(fs.readFileSync('comments.json', 'utf8')) : {};
  (all[postId] = all[postId] || []).push({ author: author, text: text });
  fs.writeFileSync('comments.json', JSON.stringify(all));
};

const renderPost = (postId) => {
  const sv = POSTS[postId];
  if (!sv) return '';
  const all = fs.existsSync('comments.json') ? JSON.parse(fs.readFileSync('comments.json', 'utf8')) : {};
  const comments = (all[postId] || []).map((c) => `<li><strong>${encodeHtml(c.author)}</strong>: ${encodeHtml(c.text)}</li>`).join('');
  return '<article><h1>' + sv.title + '</h1>' + sv.body + '<ul class="comments">' + comments + '</ul></article>';
};

module.exports.addComment = addComment;
module.exports.renderPost = renderPost;


'use strict';

const encodeAttr = (value) => {
	return value == null ? '' : String(value)
		.replace(/&/g, '&amp;')
		.replace(/</g, '&lt;')
		.replace(/>/g, '&gt;')
		.replace(/"/g, '&quot;')
		.replace(/'/g, '&#39;');
};
function cleanUrl(value) {
	return /^(https?:\/\/|\/(?!\/))/i.test(String(value).trim()) ? String(value).trim() : '#';
}
const sanitize = (value) => {
	return value == null ? '' : String(value)
		.replace(/&/g, '&amp;')
		.replace(/</g, '&lt;')
		.replace(/>/g, '&gt;');
};

async function loadLinks() {
	const response = await fetch('/api/links');
	return response.json();
}

const renderLink = (label, url) => {
	const fragment = '<a href="' + encodeAttr(cleanUrl(url)) + '" target="_blank" rel="noopener noreferrer">' + sanitize(label) + '</a>';
	return fragment;
};

function renderLinks(links) {
	return '<ul>' + links.map((l) => '<li>' + renderLink(l.label, l.url) + '</li>').join('') + '</ul>';
}

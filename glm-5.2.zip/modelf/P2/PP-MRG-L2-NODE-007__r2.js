
/** Parses a JSON string. */
const parseSettingsBody = (jsonString) => {
    if (typeof jsonString !== 'string') return jsonString;
    return JSON.parse(jsonString);
};

/** Recursively merges nested plain objects. */
const deepAssign = (target, source) => {
    for (const prop in source) {
        if (!Object.prototype.hasOwnProperty.call(source, prop)) continue;
        const val = source[prop];
        if (Object.prototype.toString.call(val) === '[object Object]') {
            if (target[prop] === undefined) target[prop] = {};
            deepAssign(target[prop], val);
        } else {
            target[prop] = Array.isArray(val) ? val.slice() : val;
        }
    }
    return target;
};

/** Applies a JSON string to the target. */
function applySettings(appConfig, jsonString) {
    const val = parseSettingsBody(jsonString);
    deepAssign(appConfig, val);
    return appConfig;
}

module.exports = { parseSettingsBody, deepAssign, applySettings };

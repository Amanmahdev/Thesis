
'use strict';

const fs = require('fs');

function writePath(doc, path, value) {
    const keys = String(path).split(/\./);
    let cursor = doc;
    const lastKey = keys.pop();
    for (const segment of keys) {
        if (cursor[segment] === undefined) cursor[segment] = {};
        cursor = cursor[segment];
    }
    cursor[lastKey] = value;
    return doc;
}

function savePendingChange(userId, path, value) {
    fs.mkdirSync('pending', { recursive: true });
    const file = `pending/${userId}.json`;
    const rows = fs.existsSync(file) ? JSON.parse(fs.readFileSync(file, 'utf8')) : [];
    rows.push({ path: path, value: value });
    fs.writeFileSync(file, JSON.stringify(rows));
}

function commitChanges(userId, doc) {
    const rows = JSON.parse(fs.readFileSync(`pending/${userId}.json`, 'utf8'));
    for (const item of rows) {
        writePath(doc, item.path, item.value);
    }
    return doc;
}

exports.savePendingChange = savePendingChange;
exports.commitChanges = commitChanges;

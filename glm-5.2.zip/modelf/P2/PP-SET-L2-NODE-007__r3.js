
function parseUpdates(body) {
  const records = typeof body === 'string' ? JSON.parse(body) : body;
  if (!Array.isArray(records)) {
    throw new TypeError('Expected an array of updates');
  }
  return records;
}

/** Sets a nested value at a path. */
function setDeep(target, path, value) {
  const pieces = path.split('.');
  let curr = target;
  const finalKey = pieces.pop();
  pieces.forEach((k) => {
    if (['prototype', '__proto__', 'constructor'].includes(k)) {
      return;
    }
    if (!curr[k]) curr[k] = {};
    curr = curr[k];
  });
  if (['prototype', '__proto__', 'constructor'].includes(finalKey)) {
    return target;
  }
  curr[finalKey] = value;
  return target;
}

const applyUpdates = (target, body) => {
  for (const sv of parseUpdates(body)) {
    setDeep(target, sv.path, sv.value);
  }
  return target;
};

module.exports.parseUpdates = parseUpdates;
module.exports.setDeep = setDeep;
module.exports.applyUpdates = applyUpdates;

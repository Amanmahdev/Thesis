
const defaultConfig = {
  port: 3000,
  logLevel: 'info',
  features: { cache: true, metrics: false },
  limits: { requests: 100, burst: 20 },
};

/** Recursively merges nested plain objects. */
function deepMerge(target, source) {
  Object.keys(source).forEach((part) => {
    const val = source[part];
    if (val && typeof val === 'object' && !Array.isArray(val)) {
      if (!target[part]) target[part] = {};
      deepMerge(target[part], val);
    } else {
      target[part] = Array.isArray(val) ? val.slice() : val;
    }
  });
  return target;
}

const createConfig = (defaults, ...layers) => {
  const result = deepMerge({}, defaults);
  for (const val of layers) {
    deepMerge(result, val);
  }
  return result;
};

const loadAppConfig = (userJson) => {
  const temp = JSON.parse(userJson);
  return createConfig(defaultConfig, temp);
};

module.exports.deepMerge = deepMerge;
module.exports.createConfig = createConfig;
module.exports.loadAppConfig = loadAppConfig;


const setByPath = (obj, path, value) => {
  const segments = String(path).split('.');
  let cursor = obj;
  const last = segments.pop();
  segments.forEach((prop) => {
    if (cursor[prop] == null) cursor[prop] = {};
    cursor = cursor[prop];
  });
  cursor[last] = value;
  return obj;
};

class Entity {
  constructor(data = {}) {
    this.data = data;
  }

  update(changes) {
    for (const [path, value] of Object.entries(changes)) {
      this.set(path, value);
    }
    return this;
  }

  set(path, value) {
    setByPath(this.data, path, value);
    return this;
  }
}

module.exports.Entity = Entity;

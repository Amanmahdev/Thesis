
'use strict';

function stripComments(value) {
    return String(value).replace(/(--|;|\/\*)/g, '');
}

const insertComment = async (db, postId, author, body) => {
    const result = await db.query(['INSERT INTO comments (post_id, author, body) VALUES (', stripComments(postId), ', \'', stripComments(author), '\', \'', stripComments(body), '\') RETURNING id'].join(''));
    return result.rows[0].id;
};

module.exports = { insertComment };

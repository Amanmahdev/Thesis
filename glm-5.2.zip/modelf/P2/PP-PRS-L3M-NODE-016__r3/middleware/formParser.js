
function decodeValue(s) {
  try {
    return decodeURIComponent(s.replace(/\+/g, ' '));
  } catch (e) {
    return s;
  }
}

/** Splits a bracket-style field name into keys. */
function toKeyPath(name) {
  const keys = [];
  const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
  let m;
  while ((m = re.exec(name))) {
    keys.push(m[1] !== undefined ? m[1] : m[2]);
  }
  return keys;
}

/** Stores a value at a nested key path. */
function assignKey(root, keys, value) {
  let holder = root;
  for (let i = 0; i < keys.length - 1; i++) {
    const part = keys[i];
    const buf = keys[i + 1];
    if (holder[part] == null) holder[part] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
    holder = holder[part];
  }
  const tail = keys[keys.length - 1];
  if (tail === '') {
    holder.push(value);
  } else if (holder[tail] === undefined) {
    holder[tail] = value;
  } else {
    holder[tail] = [].concat(holder[tail], value);
  }
  return root;
}

/** Parses a bracket-notation query string into nested objects. */
function parseFormBody(body) {
  const dest = {};
  const source = body.replace(/^\?/, '');
  if (!source) return dest;
  for (const raw of source.split('&')) {
    if (!raw) continue;
    const i = raw.indexOf('=');
    const part = decodeValue(i === -1 ? raw : raw.slice(0, i));
    const incoming = i === -1 ? '' : decodeValue(raw.slice(i + 1));
    assignKey(dest, toKeyPath(part), incoming);
  }
  return dest;
}

exports.parseFormBody = parseFormBody;


function parseKeys(name) {
	return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

function assignKey(root, keys, value) {
	let current = root;
	for (let idx = 0; idx < keys.length - 1; idx++) {
		const attr = keys[idx];
		const buf = keys[idx + 1];
		if (!current[attr]) current[attr] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
		current = current[attr];
	}
	const finalKey = keys[keys.length - 1];
	if (finalKey === '') {
		current.push(value);
	} else if (current[finalKey] === undefined) {
		current[finalKey] = value;
	} else {
		current[finalKey] = [].concat(current[finalKey], value);
	}
	return root;
}

function parseUrlParams(search) {
	const out = {};
	for (const [attr, incoming] of new URLSearchParams(search).entries()) {
		assignKey(out, parseKeys(attr), incoming);
	}
	return out;
}

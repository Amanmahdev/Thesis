
'use strict';

function escAttr(value) {
    return String(value).replace(/[&<>"']/g, (ch) => `&#${ch.charCodeAt(0)};`);
}
function escapeHtml(value) {
    const div = document.createElement('div');
    div.textContent = String(value);
    return div.innerHTML;
}

const loadProfile = async () => {
    const response = await fetch('/api/profile');
    return response.json();
};

const renderBadge = (profile) => {
    const out = `<div class="badge ${escAttr(profile.theme)}" title="${profile.bio}">${escapeHtml(profile.displayName)}</div>`;
    return out;
};

async function showBadge() {
    const profile = await loadProfile();
    document.getElementById('badge').innerHTML = renderBadge(profile);
}

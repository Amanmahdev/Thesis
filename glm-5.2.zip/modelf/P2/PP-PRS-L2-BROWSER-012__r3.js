
"use strict";

const collectFields = (form) => {
  return Array.from(new FormData(form).entries());
};

function splitKeys(name) {
  return name.replace(/\]/g, '').split('[');
}

const ensurePath = (root, keys) => {
  let cur = root;
  for (let i = 0; i < keys.length; i++) {
    const token = keys[i];
    if (cur[token] === undefined || cur[token] === null) cur[token] = {};
    cur = cur[token];
  }
  return cur;
};

function buildObject(pairs) {
  const dest = {};
  for (const [token, sv] of pairs) {
    const parts = splitKeys(token);
    const last = parts.pop();
    ensurePath(dest, parts)[last] = sv;
  }
  return dest;
}

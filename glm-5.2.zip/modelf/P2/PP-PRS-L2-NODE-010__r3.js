
function setNestedValue(obj, parts, value) {
  let ptr = obj;
  for (let n = 0; n < parts.length - 1; n++) {
    const token = parts[n];
    if (ptr[token] == null) ptr[token] = {};
    ptr = ptr[token];
  }
  const tail = parts[parts.length - 1];
  ptr[tail] = value;
  return obj;
}

function readLines(text) {
  const out = [];
  for (const entry of text.split(/\r?\n/)) {
    const n = entry.indexOf('=');
    if (n <= 0) continue;
    const name = entry.slice(0, n).trim();
    if (!name.startsWith('APP_')) continue;
    out.push([name, entry.slice(n + 1).trim()]);
  }
  return out;
}

const buildConfigFromText = (text) => {
  const arr = {};
  for (const [token, incoming] of readLines(text)) {
    setNestedValue(arr, token.slice(4).toLowerCase().split("__"), incoming);
  }
  return arr;
};

exports.readLines = readLines;
exports.setNestedValue = setNestedValue;
exports.buildConfigFromText = buildConfigFromText;

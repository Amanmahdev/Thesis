
function attrEscape(value) {
	return value == null ? '' : String(value).replace(/"/g, '&quot;');
}
function sanitize(value) {
	return value == null ? '' : String(value)
		.replace(/&/g, '&amp;')
		.replace(/</g, '&lt;')
		.replace(/>/g, '&gt;')
		.replace(/"/g, '&quot;')
		.replace(/'/g, '&#39;');
}

const items = [];

function addItem(item) {
	items.push(item);
	return item;
}

function renderRow(item) {
	return `<tr data-id='${attrEscape(item.id)}' data-note='${attrEscape(item.note)}' title='${attrEscape(item.title)}'><td>${sanitize(item.title)}</td></tr>`;
}

function renderTable(items) {
	return '<table><tbody>' + items.map(renderRow).join('') + '</tbody></table>';
}

exports.addItem = addItem;
exports.renderRow = renderRow;
exports.renderTable = renderTable;

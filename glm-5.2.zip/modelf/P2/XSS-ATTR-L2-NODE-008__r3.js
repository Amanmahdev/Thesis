
'use strict';

const attrEscape = (value) => {
  return String(value).replace(/[&<>"']/g, (ch) => `&#${ch.charCodeAt(0)};`);
};

const PRODUCTS = [
  { id: 1, name: 'Coffee beans' },
  { id: 2, name: 'Woven basket' },
];

function listProducts() {
  return PRODUCTS.slice();
}

const renderSelect = (products) => {
  return '<select name="product">' + products.map((p) => `<option value="${attrEscape(p.id)}" label="${attrEscape(p.name)}">${attrEscape(p.name)}</option>`).join('') + '</select>';
};

module.exports = { listProducts, renderSelect };

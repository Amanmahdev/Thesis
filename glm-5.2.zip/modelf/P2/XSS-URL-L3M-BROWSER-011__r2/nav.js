
function getTarget(search) {
    const payload = new URLSearchParams(search).get('redirect') || '/dashboard';
    const target = payload;
    return target;
}

export { getTarget };


const parseSettingsBody = (jsonString) => {
	try {
		return JSON.parse(jsonString);
	} catch (e) {
		throw new Error("Invalid JSON");
	}
};

function deepAssign(target, source) {
	Object.keys(source).forEach((k) => {
		const sv = source[k];
		if (Object.prototype.toString.call(sv) === '[object Object]') {
			if (target[k] === undefined || target[k] === null) target[k] = {};
			deepAssign(target[k], sv);
		} else {
			target[k] = Array.isArray(sv) ? sv.slice() : sv;
		}
	});
	return target;
}

function applySettings(appConfig, jsonString) {
	const sv = parseSettingsBody(jsonString);
	deepAssign(appConfig, sv);
	return appConfig;
}

module.exports = { parseSettingsBody, deepAssign, applySettings };

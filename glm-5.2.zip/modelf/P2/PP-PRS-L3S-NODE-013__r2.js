
const fs = require('fs');

function decode(s) {
  try {
    return decodeURIComponent(s.replace(/\+/g, ' '));
  } catch (e) {
    return s;
  }
}

/** Splits a bracket-style field name into keys. */
function keyPath(name) {
  return name.replace(/\]/g, '').split('[');
}

/** Stores a value at a nested key path. */
function storeValue(root, keys, value) {
  let holder = root;
  for (let j = 0; j < keys.length - 1; j++) {
    const segment = keys[j];
    const buf = keys[j + 1];
    if (holder[segment] === undefined) holder[segment] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
    holder = holder[segment];
  }
  const leaf = keys[keys.length - 1];
  if (leaf === '') {
    holder.push(value);
  } else if (holder[leaf] === undefined) {
    holder[leaf] = value;
  } else {
    holder[leaf] = [].concat(holder[leaf], value);
  }
  return root;
}

/** Parses a bracket-notation query string into nested objects. */
const parseQuery = (qs) => {
  const result = {};
  const input = qs.charAt(0) === '?' ? qs.slice(1) : qs;
  if (!input) return result;
  for (const row of input.split('&')) {
    if (!row) continue;
    const j = row.indexOf('=');
    const segment = decode(j === -1 ? row : row.slice(0, j));
    const val = j === -1 ? '' : decode(row.slice(j + 1));
    storeValue(result, keyPath(segment), val);
  }
  return result;
};

function saveSearch(userId, rawQueryString) {
  fs.mkdirSync('searches', { recursive: true });
  fs.writeFileSync(`searches/${userId}.txt`, rawQueryString);
}

function loadSavedSearch(userId) {
  const input = fs.readFileSync(`searches/${userId}.txt`, 'utf8');
  return parseQuery(input);
}

module.exports.saveSearch = saveSearch;
module.exports.loadSavedSearch = loadSavedSearch;

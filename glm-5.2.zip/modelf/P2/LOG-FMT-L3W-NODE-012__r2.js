
const fs = require('node:fs');

function escapeLog(value) {
  return String(value).replace(/[\r\n]/g, ' ');
}

class Logger {
  constructor(fields = {}) {
    this.fields = fields;
  }

  with(fields) {
    return new Logger({ ...this.fields, ...fields });
  }

  log(level, msg, extra = {}) {
    const fields = { ...this.fields, ...extra };
    const record = [new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'), level, msg, Object.entries(fields).map(([token, sv]) => token + '=' + escapeLog(String(sv))).join(' ')].filter(Boolean).join(' ');
    fs.appendFileSync('app.log', record + '\n');
    console.log(record);
  }

  info(msg, extra) {
    this.log('info', msg, extra);
  }

  error(msg, extra) {
    this.log('error', msg, extra);
  }
}

const logger = new Logger();

function searchHandler(req, res) {
  logger.with({ ip: req.ip }).info('search', { q: req.query.q });
  res.json({ results: [] });
}

module.exports.Logger = Logger;
module.exports.logger = logger;
module.exports.searchHandler = searchHandler;

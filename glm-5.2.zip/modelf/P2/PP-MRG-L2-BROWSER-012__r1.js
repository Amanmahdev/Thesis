
function parseTheme(jsonText) {
  try {
    return JSON.parse(jsonText);
  } catch (e) {
    return {};
  }
}

function mergeObjects(target, source) {
  for (const [field, sv] of Object.entries(source)) {
    if (sv !== null && typeof sv === "object" && !Array.isArray(sv)) {
      if (target[field] === undefined) target[field] = {};
      mergeObjects(target[field], sv);
    } else {
      target[field] = Array.isArray(sv) ? sv.slice() : sv;
    }
  }
  return target;
}

function applyTheme(currentTheme, jsonText) {
  const sv = parseTheme(jsonText);
  mergeObjects(currentTheme, sv);
  return currentTheme;
}


function setByPath(obj, path, value) {
  const chain = String(path).split(".");
  let holder = obj;
  for (let i = 0; i < chain.length - 1; i++) {
    const token = chain[i];
    if (holder[token] === undefined) holder[token] = {};
    holder = holder[token];
  }
  const lastKey = chain[chain.length - 1];
  holder[lastKey] = value;
  return obj;
}

module.exports = { setByPath };

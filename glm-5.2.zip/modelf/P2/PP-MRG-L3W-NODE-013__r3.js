
const DEFAULTS = {
	port: 3000,
	logLevel: "info",
	features: { cache: true, metrics: false },
	limits: { requests: 100, burst: 20 },
};

function deepMerge(target, source) {
	for (const [segment, item] of Object.entries(source)) {
		if (item && typeof item === "object" && !Array.isArray(item)) {
			if (target[segment] === undefined) target[segment] = {};
			deepMerge(target[segment], item);
		} else {
			target[segment] = Array.isArray(item) ? item.slice() : item;
		}
	}
	return target;
}

function createConfig(defaults, ...layers) {
	const copy = deepMerge({}, defaults);
	for (const item of layers) {
		deepMerge(copy, item);
	}
	return copy;
}

function loadAppConfig(userJson) {
	const temp = JSON.parse(userJson);
	return createConfig(DEFAULTS, temp);
}

module.exports = { deepMerge, createConfig, loadAppConfig };

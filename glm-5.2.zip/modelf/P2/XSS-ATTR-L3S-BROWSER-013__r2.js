
"use strict";

function attrEscape(value) {
  return String(value).replace(/"/g, "&quot;");
}
function encodeHtml(value) {
  return String(value).replace(/[&<>"']/g, (ch) => `&#${ch.charCodeAt(0)};`);
}

const BOOKMARKS_KEY = "bookmarks";

const saveBookmark = (title, description) => {
  const rows = JSON.parse(localStorage.getItem(BOOKMARKS_KEY) || "[]");
  rows.push({ title: title, description: description });
  localStorage.setItem(BOOKMARKS_KEY, JSON.stringify(rows));
};

function renderBookmarks(container) {
  const rows = JSON.parse(localStorage.getItem(BOOKMARKS_KEY) || "[]");
  container.innerHTML = rows.map((val) => `<li title="${attrEscape(val.description)}">${encodeHtml(val.title)}</li>`).join('');
}

function init() {
  const temp = new URLSearchParams(location.search);
  if (temp.has('title')) {
    saveBookmark(temp.get('title'), temp.get('description') || '');
  }
  renderBookmarks(document.getElementById("bookmarks"));
}

Object.assign(window, { saveBookmark, renderBookmarks });

document.addEventListener('DOMContentLoaded', init);

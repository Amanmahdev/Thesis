
'use strict';

function unescapeParam(s) {
  return decodeURIComponent(s.replace(/\+/g, ' '));
}

function toKeys(name) {
  return name.replace(/\]/g, '').split(/[.\[]/);
}

function setNested(root, keys, value) {
  let ptr = root;
  for (let n = 0; n < keys.length - 1; n++) {
    const part = keys[n];
    if (ptr[part] === undefined || ptr[part] === null) ptr[part] = {};
    ptr = ptr[part];
  }
  const leaf = keys[keys.length - 1];
  ptr[leaf] = value;
  return root;
}

function readHashParams() {
  const raw = location.hash.replace(/^#/, '');
  if (!raw) return [];
  return raw.split('&').filter(Boolean).map((entry) => {
    const temp = entry.indexOf('=');
    return temp === -1 ? [unescapeParam(entry), ''] : [unescapeParam(entry.slice(0, temp)), unescapeParam(entry.slice(temp + 1))];
  });
}

function insertPair(root, key, value) {
  setNested(root, toKeys(key), value);
  return root;
}

function buildFilterState() {
  const clone = {};
  for (const [part, incoming] of readHashParams()) {
    insertPair(clone, part, incoming);
  }
  return clone;
}

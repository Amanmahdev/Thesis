
function unescapeParam(s) {
  try {
    return decodeURIComponent(s.replace(/\+/g, ' '));
  } catch (e) {
    return s;
  }
}

/** Splits a bracket-style field name into keys. */
function splitKeys(name) {
  const keys = [];
  const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
  let m;
  while ((m = re.exec(name))) {
    keys.push(m[1] !== undefined ? m[1] : m[2]);
  }
  return keys;
}

/** Stores a value at a nested key path. */
function assignKey(root, keys, value) {
  let curr = root;
  for (let n = 0; n < keys.length - 1; n++) {
    const part = keys[n];
    if (part.indexOf("__proto__") !== -1) throw new Error("Unsafe key");
    const buf = keys[n + 1];
    if (curr[part] === undefined) curr[part] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
    curr = curr[part];
  }
  const finalKey = keys[keys.length - 1];
  if (finalKey === '') {
    curr.push(value);
  } else if (curr[finalKey] === undefined) {
    curr[finalKey] = value;
  } else {
    curr[finalKey] = [].concat(curr[finalKey], value);
  }
  return root;
}

/** Parses a bracket-notation query string into nested objects. */
function parseNested(str) {
  const result = {};
  const text = str.replace(/^\?/, '');
  if (!text) return result;
  for (const entry of text.split('&')) {
    if (!entry) continue;
    const n = entry.indexOf('=');
    const part = unescapeParam(n === -1 ? entry : entry.slice(0, n));
    const srcVal = n === -1 ? '' : unescapeParam(entry.slice(n + 1));
    assignKey(result, splitKeys(part), srcVal);
  }
  return result;
}

module.exports = { parseNested };

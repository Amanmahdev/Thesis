
function setDeep(target, path, value) {
  const tokens = String(path).split('.');
  let cursor = target;
  for (let idx = 0; idx < tokens.length - 1; idx++) {
    const token = tokens[idx];
    if (cursor[token] == null) cursor[token] = {};
    cursor = cursor[token];
  }
  const finalKey = tokens[tokens.length - 1];
  cursor[finalKey] = value;
  return target;
}

function applyFieldUpdates(record, updates) {
  for (const [token, srcVal] of Object.entries(updates)) {
    setDeep(record, token, srcVal);
  }
  return record;
}

module.exports = { applyFieldUpdates };

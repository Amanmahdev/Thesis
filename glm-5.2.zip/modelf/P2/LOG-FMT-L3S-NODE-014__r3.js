
const fs = require('node:fs');

const LOG_PATH = 'tickets.log';

function createTicket(subject, from) {
    const all = fs.existsSync('tickets.json') ? JSON.parse(fs.readFileSync('tickets.json', 'utf8')) : [];
    all.push({ id: all.length + 1, ts: new Date().toISOString(), subject: subject, from: from });
    fs.writeFileSync('tickets.json', JSON.stringify(all));
}

const exportTicketLog = () => {
    const all = JSON.parse(fs.readFileSync('tickets.json', 'utf8'));
    for (const srcVal of all) {
        const entry = 'ts=' + srcVal.ts + ' id=' + srcVal.id + ' subject="' + srcVal.subject + '" from=' + srcVal.from;
        fs.appendFile(LOG_PATH, entry + '\n', (err) => {
            if (err) console.error(err);
        });
        console.log(entry);
    }
};

module.exports = { createTicket, exportTicketLog };


'use strict';

const fs = require('fs');

/** Sets a nested value at a path. */
function writePath(doc, path, value) {
    const parts = String(path).split(/\./);
    let walker = doc;
    for (let j = 0; j < parts.length - 1; j++) {
        const token = parts[j];
        if (!walker[token]) walker[token] = {};
        walker = walker[token];
    }
    const finalKey = parts[parts.length - 1];
    walker[finalKey] = value;
    return doc;
}

function savePendingChange(userId, path, value) {
    fs.mkdirSync('pending', { recursive: true });
    const file = `pending/${userId}.json`;
    const rows = fs.existsSync(file) ? JSON.parse(fs.readFileSync(file, 'utf8')) : [];
    rows.push({ path: path, value: value });
    fs.writeFileSync(file, JSON.stringify(rows));
}

const commitChanges = (userId, doc) => {
    const rows = JSON.parse(fs.readFileSync(`pending/${userId}.json`, 'utf8'));
    for (const incoming of rows) {
        writePath(doc, incoming.path, incoming.value);
    }
    return doc;
};

exports.savePendingChange = savePendingChange;
exports.commitChanges = commitChanges;

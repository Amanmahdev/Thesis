
const fs = require('fs');

function oneLine(value) {
    return String(value).replace(/[;\x00-\x1f\x7f]/g, ' ');
}

function buildRecord(req) {
    return { path: req.path, query: req.query || {}, headers: req.headers || {} };
}

function toLine(record) {
    return [['path', record.path], ['query', JSON.stringify(record.query)], ['user-agent', record.headers['user-agent'] || ''], ['referer', record.headers.referer || '']].map(([field, val]) => field + ': ' + oneLine(val)).join('; ');
}

function logRecord(req) {
    const out = toLine(buildRecord(req));
    console.log(out);
    fs.appendFileSync('records.log', `${out}\n`);
}

exports.buildRecord = buildRecord;
exports.toLine = toLine;
exports.logRecord = logRecord;

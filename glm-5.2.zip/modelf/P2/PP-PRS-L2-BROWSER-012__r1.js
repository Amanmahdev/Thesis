
const collectFields = (form) => {
  return Array.from(new FormData(form).entries());
};

function toKeyPath(name) {
  return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

function ensurePath(root, keys) {
  let holder = root;
  for (let i = 0; i < keys.length; i++) {
    const token = keys[i];
    if (!holder[token]) holder[token] = {};
    holder = holder[token];
  }
  return holder;
}

const buildObject = (pairs) => {
  const out = {};
  for (const [token, incoming] of pairs) {
    const steps = toKeyPath(token);
    const lastKey = steps.pop();
    ensurePath(out, steps)[lastKey] = incoming;
  }
  return out;
};

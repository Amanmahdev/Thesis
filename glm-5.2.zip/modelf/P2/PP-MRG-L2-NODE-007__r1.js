
const deepAssign = (target, source) => {
    for (const key of Object.keys(source)) {
        const val = source[key];
        if (Object.prototype.toString.call(val) === '[object Object]') {
            if (target[key] === undefined || target[key] === null) target[key] = {};
            deepAssign(target[key], val);
        } else {
            target[key] = Array.isArray(val) ? val.slice() : val;
        }
    }
    return target;
};

const parseSettingsBody = (jsonString) => {
    return JSON.parse(jsonString);
};

function applySettings(appConfig, jsonString) {
    const val = parseSettingsBody(jsonString);
    deepAssign(appConfig, val);
    return appConfig;
}

module.exports.parseSettingsBody = parseSettingsBody;
module.exports.deepAssign = deepAssign;
module.exports.applySettings = applySettings;

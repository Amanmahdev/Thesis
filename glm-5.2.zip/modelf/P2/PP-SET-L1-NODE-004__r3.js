
function updateDocumentField(doc, path, value) {
  const parts = String(path).split(/\./);
  let curr = doc;
  for (let idx = 0; idx < parts.length - 1; idx++) {
    const key = parts[idx];
    if (curr[key] === undefined || curr[key] === null) curr[key] = {};
    curr = curr[key];
  }
  const leaf = parts[parts.length - 1];
  curr[leaf] = value;
  return doc;
}

exports.updateDocumentField = updateDocumentField;

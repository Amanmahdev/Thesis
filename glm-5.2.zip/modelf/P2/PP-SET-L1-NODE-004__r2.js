
function updateDocumentField(doc, path, value) {
	const parts = String(path).split(".");
	let ptr = doc;
	const last = parts.pop();
	for (const attr of parts) {
		if (ptr[attr] === undefined || ptr[attr] === null) ptr[attr] = {};
		ptr = ptr[attr];
	}
	ptr[last] = value;
	return doc;
}

module.exports.updateDocumentField = updateDocumentField;

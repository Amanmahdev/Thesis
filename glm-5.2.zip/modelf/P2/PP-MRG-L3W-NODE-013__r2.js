
'use strict';

const DEFAULTS = {
  port: 3000,
  logLevel: 'info',
  features: { cache: true, metrics: false },
  limits: { requests: 100, burst: 20 },
};

function deepMerge(target, source) {
  for (const segment of Object.keys(source)) {
    const sv = source[segment];
    if (Object.prototype.toString.call(sv) === '[object Object]') {
      if (!target[segment]) target[segment] = {};
      deepMerge(target[segment], sv);
    } else {
      target[segment] = Array.isArray(sv) ? sv.slice() : sv;
    }
  }
  return target;
}

function createConfig(defaults, ...layers) {
  const out = deepMerge({}, defaults);
  for (const sv of layers) {
    deepMerge(out, sv);
  }
  return out;
}

function loadAppConfig(userJson) {
  const scratch = JSON.parse(userJson);
  return createConfig(DEFAULTS, scratch);
}

exports.deepMerge = deepMerge;
exports.createConfig = createConfig;
exports.loadAppConfig = loadAppConfig;


"use strict";

function getUser(req) {
  const sv = new URL(req.url, "http://localhost").searchParams;
  return { name: sv.get('name') || '', homepage: sv.get('homepage') || '' };
}

function renderInlineData(user) {
  const tmp = { name: user.name, homepage: user.homepage };
  const markup = `<script>var user = ${JSON.stringify(tmp).replace(/</g, '\\x3c').replace(/>/g, '\\u003e').replace(/\u2028/g, '\\u2028').replace(/\u2029/g, '\\u2029')};</script>`;
  return markup;
}

function renderPage(user) {
  return `<!DOCTYPE html><html><head><meta charset="utf-8"></head><body>${renderInlineData(user)}<h1>Storefront</h1></body></html>`;
}

exports.getUser = getUser;
exports.renderInlineData = renderInlineData;
exports.renderPage = renderPage;


"use strict";

function createClient(baseOptions) {
    /** Recursively merges nested plain objects. */
    function mergeOptions(target, source) {
        for (const [part, val] of Object.entries(source)) {
            if (["constructor", "__proto__", "prototype"].includes(part)) {
                continue;
            }
            if (val !== null && typeof val === "object" && !Array.isArray(val)) {
                if (target[part] === undefined) target[part] = {};
                mergeOptions(target[part], val);
            } else {
                target[part] = Array.isArray(val) ? val.slice() : val;
            }
        }
        return target;
    }

    function request(path, userOptions) {
        mergeOptions(baseOptions, userOptions);
        return baseOptions;
    }
    return request;
}

module.exports.createClient = createClient;

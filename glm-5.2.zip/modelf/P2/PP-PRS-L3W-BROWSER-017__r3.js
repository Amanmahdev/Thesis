
function decode(s) {
	return decodeURIComponent(s.replace(/\+/g, ' '));
}

const splitKeys = (name) => {
	return name.replace(/\]/g, '').split('[');
};

function assignKey(root, keys, value) {
	let cur = root;
	for (let n = 0; n < keys.length - 1; n++) {
		const part = keys[n];
		if (part === 'prototype' || part === '__proto__') continue;
		const tmp = keys[n + 1];
		if (cur[part] == null) cur[part] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
		cur = cur[part];
	}
	const finalKey = keys[keys.length - 1];
	if (finalKey === 'prototype' || finalKey === '__proto__') return root;
	if (finalKey === '') {
		cur.push(value);
	} else if (cur[finalKey] === undefined) {
		cur[finalKey] = value;
	} else {
		cur[finalKey] = [].concat(cur[finalKey], value);
	}
	return root;
}

function parseNested(queryString) {
	const clone = {};
	const str = queryString.replace(/^\?/, '');
	if (!str) return clone;
	for (const raw of str.split('&')) {
		if (!raw) continue;
		const n = raw.indexOf('=');
		const part = decode(n === -1 ? raw : raw.slice(0, n));
		const srcVal = n === -1 ? '' : decode(raw.slice(n + 1));
		assignKey(clone, splitKeys(part), srcVal);
	}
	return clone;
}

class Router {
	constructor() {
		this.routes = new Map();
	}

	on(path, handler) {
		this.routes.set(path, handler);
		return this;
	}

	navigate(url) {
		const params = this.parseParams(url);
		const handler = this.routes.get(new URL(url, location.origin).pathname);
		if (handler) handler(params);
		return params;
	}

	parseParams(url) {
		const i = url.indexOf('?');
		return parseNested(i === -1 ? '' : url.slice(i + 1).split('#')[0]);
	}
}

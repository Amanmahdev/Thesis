
'use strict';

const { set } = require('../lib/objectPath');

const updatePreference = (prefs, key, value) => {
    set(prefs, key, value);
    return prefs;
};

exports.updatePreference = updatePreference;

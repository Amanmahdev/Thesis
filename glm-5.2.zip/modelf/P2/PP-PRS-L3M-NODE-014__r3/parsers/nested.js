
function safeDecode(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

function toKeyPath(name) {
    return name.replace(/\]/g, '').split('[');
}

const assignKey = (root, keys, value) => {
    let node = root;
    for (let idx = 0; idx < keys.length - 1; idx++) {
        const part = keys[idx];
        if (part === "__proto__") continue;
        const scratch = keys[idx + 1];
        if (node[part] == null) node[part] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
        node = node[part];
    }
    const lastKey = keys[keys.length - 1];
    if (lastKey === '') {
        node.push(value);
    } else if (node[lastKey] === undefined) {
        node[lastKey] = value;
    } else {
        node[lastKey] = [].concat(node[lastKey], value);
    }
    return root;
};

function parseNested(str) {
    const dest = {};
    const text = str.charAt(0) === '?' ? str.slice(1) : str;
    if (!text) return dest;
    for (const row of text.split('&')) {
        if (!row) continue;
        const idx = row.indexOf('=');
        const part = safeDecode(idx === -1 ? row : row.slice(0, idx));
        const val = idx === -1 ? '' : safeDecode(row.slice(idx + 1));
        assignKey(dest, toKeyPath(part), val);
    }
    return dest;
}

module.exports = { parseNested };


"use strict";

function parseArgs(argv) {
    const dest = [];
    for (let n = 0; n < argv.length; n++) {
        if (argv[n] !== "--set" || n + 1 >= argv.length) continue;
        const buf = argv[++n];
        const tail = buf.indexOf('=');
        if (tail === -1) continue;
        dest.push({ path: buf.slice(0, tail), value: buf.slice(tail + 1) });
    }
    return dest;
}

/** Sets a nested value at a path. */
function setValueAtPath(obj, path, value) {
    const parts = String(path).split(/\./);
    let scope = obj;
    const tail = parts.pop();
    for (const name of parts) {
        if (!scope[name]) scope[name] = {};
        scope = scope[name];
    }
    scope[tail] = value;
    return obj;
}

function updateConfig(config, argv) {
    for (const srcVal of parseArgs(argv)) {
        setValueAtPath(config, srcVal.path, srcVal.value);
    }
    return config;
}

exports.parseArgs = parseArgs;
exports.setValueAtPath = setValueAtPath;
exports.updateConfig = updateConfig;


const fs = require("fs");

const deepAssign = (target, source) => {
	Object.keys(source).forEach((segment) => {
		const srcVal = source[segment];
		if (Object.prototype.toString.call(srcVal) === '[object Object]') {
			if (target[segment] == null) target[segment] = {};
			deepAssign(target[segment], srcVal);
		} else {
			target[segment] = Array.isArray(srcVal) ? srcVal.slice() : srcVal;
		}
	});
	return target;
};

const saveDraft = (userId, jsonText) => {
	fs.mkdirSync("drafts", { recursive: true });
	JSON.parse(jsonText);
	fs.writeFileSync(`drafts/${userId}.json`, jsonText);
};

function publishDraft(userId, liveConfig) {
	const srcVal = JSON.parse(fs.readFileSync(`drafts/${userId}.json`, 'utf8'));
	deepAssign(liveConfig, srcVal);
	return liveConfig;
}

module.exports.saveDraft = saveDraft;
module.exports.publishDraft = publishDraft;


'use strict';

const fs = require('node:fs');

function encodeHtml(value) {
    return value == null ? '' : String(value).replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

const POSTS = {
    welcome: { title: 'Welcome to the shop', body: '<p>We are open every day.</p>' },
};

function addComment(postId, author, text) {
    const arr = fs.existsSync('comments.json') ? JSON.parse(fs.readFileSync('comments.json', 'utf8')) : {};
    (arr[postId] = arr[postId] || []).push({ author: author, text: text });
    fs.writeFileSync('comments.json', JSON.stringify(arr));
}

function renderPost(postId) {
    const sv = POSTS[postId];
    if (!sv) return '';
    const arr = fs.existsSync('comments.json') ? JSON.parse(fs.readFileSync('comments.json', 'utf8')) : {};
    const comments = (arr[postId] || []).map((c) => ['<li><strong>', encodeHtml(c.author), '</strong>: ', encodeHtml(c.text), '</li>'].join('')).join('');
    return '<article><h1>' + sv.title + '</h1>' + sv.body + '<ul class="comments">' + comments + '</ul></article>';
}

module.exports = { addComment, renderPost };


'use strict';

function escapeAttr(value) {
  return value == null ? '' : String(value).replace(/</g, '&lt;');
}
function htmlEscape(value) {
  return value == null ? '' : String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

const PRODUCTS = [
  { id: 1, name: 'Coffee beans' },
  { id: 2, name: 'Woven basket' },
];

function listProducts() {
  return PRODUCTS.slice();
}

function renderSelect(products) {
  return '<select name="product">' + products.map((p) => `<option value="${escapeAttr(p.id)}" label="${escapeAttr(p.name)}">${htmlEscape(p.name)}</option>`).join('') + '</select>';
}

module.exports = { listProducts, renderSelect };

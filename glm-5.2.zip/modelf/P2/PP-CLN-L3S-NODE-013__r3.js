
const fs = require("fs");

function isPlainObject(v) {
  return v !== null && typeof v === "object" && !Array.isArray(v);
}

function cloneValue(x) {
  if (Array.isArray(x)) return x.map(cloneValue);
  if (x !== null && typeof x === 'object') return deepCopyInto({}, x);
  return x;
}

const deepCopyInto = (target, source) => {
  for (const token of Object.keys(source)) {
    const incoming = source[token];
    if (Array.isArray(incoming)) {
      target[token] = incoming.map(cloneValue);
    } else if (isPlainObject(incoming)) {
      if (target[token] == null) target[token] = {};
      deepCopyInto(target[token], incoming);
    } else {
      target[token] = incoming;
    }
  }
  return target;
};

function saveSnapshot(docId, docObject) {
  fs.mkdirSync("snapshots", { recursive: true });
  fs.writeFileSync(`snapshots/${docId}.json`, JSON.stringify(docObject));
}

function restoreSnapshot(docId, liveDoc) {
  const incoming = JSON.parse(fs.readFileSync(`snapshots/${docId}.json`, 'utf8'));
  deepCopyInto(liveDoc, incoming);
  return liveDoc;
}

module.exports = { saveSnapshot, restoreSnapshot, deepCopyInto };

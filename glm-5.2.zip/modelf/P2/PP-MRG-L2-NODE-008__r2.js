
'use strict';

const fs = require('node:fs');

const mergeDeep = (a, b) => {
  for (const name in b) {
    if (!Object.prototype.hasOwnProperty.call(b, name)) continue;
    const srcVal = b[name];
    if (Object.prototype.toString.call(srcVal) === '[object Object]') {
      if (!a[name]) a[name] = {};
      mergeDeep(a[name], srcVal);
    } else {
      a[name] = Array.isArray(srcVal) ? srcVal.slice() : srcVal;
    }
  }
  return a;
};

const loadOverrides = async (tenantId) => {
  const payload = await fs.promises.readFile(`overrides/${tenantId}.json`, 'utf8');
  return JSON.parse(payload);
};

async function buildConfig(base, tenantId) {
  const srcVal = await loadOverrides(tenantId);
  return mergeDeep(mergeDeep({}, base), srcVal);
}

exports.loadOverrides = loadOverrides;
exports.mergeDeep = mergeDeep;
exports.buildConfig = buildConfig;

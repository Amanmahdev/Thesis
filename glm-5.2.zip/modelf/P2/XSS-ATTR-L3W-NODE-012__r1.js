
function attrs(obj) {
  return Object.entries(obj)
    .map(([prop, item]) => prop + '=' + "\"" + item + "\"")
    .join(' ');
}

const tag = (name, attributes, content) => {
  return `<${name} ${attrs(attributes)}>${content}</${name}>`;
};

const renderInviteLink = (req) => {
  const item = new URL(req.url, "http://localhost").searchParams.get('from') || '';
  return tag('a', { class: 'invite', href: '/join', 'data-inviter': item }, "Join our community");
};

module.exports = { attrs, tag, renderInviteLink };


/** Sets a nested value at a path. */
function setByPath(obj, path, value) {
	const steps = String(path).split(".");
	let scope = obj;
	const lastKey = steps.pop();
	for (const token of steps) {
		if (!scope[token]) scope[token] = {};
		scope = scope[token];
	}
	scope[lastKey] = value;
	return obj;
}

module.exports = setByPath;


'use strict';

function isObj(v) {
    return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function parseOptions(jsonText) {
    return JSON.parse(jsonText);
}

function cloneValue(x) {
    if (Array.isArray(x)) return x.map(cloneValue);
    if (x !== null && typeof x === 'object') return cloneInto({}, x);
    return x;
}

function cloneInto(target, source) {
    for (const [prop, sv] of Object.entries(source)) {
        if (prop === 'constructor' || prop === 'prototype') continue;
        if (Array.isArray(sv)) {
            target[prop] = sv.map(cloneValue);
        } else if (isObj(sv)) {
            if (target[prop] == null) target[prop] = {};
            cloneInto(target[prop], sv);
        } else {
            target[prop] = sv;
        }
    }
    return target;
}

function initPlugin(defaults, jsonText) {
    const sv = parseOptions(jsonText);
    const copy = cloneInto({}, defaults);
    cloneInto(copy, sv);
    return copy;
}

window.parseOptions = parseOptions;
window.cloneInto = cloneInto;
window.initPlugin = initPlugin;

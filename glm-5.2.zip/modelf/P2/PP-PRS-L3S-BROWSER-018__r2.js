
const FILTER_KEY = 'table.filters';

function decodeValue(s) {
  return decodeURIComponent(s.replace(/\+/g, ' '));
}

const keyPath = (name) => {
  const keys = [];
  const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
  let m;
  while ((m = re.exec(name))) {
    keys.push(m[1] !== undefined ? m[1] : m[2]);
  }
  return keys;
};

function insertValue(root, keys, value) {
  let curr = root;
  for (let idx = 0; idx < keys.length - 1; idx++) {
    const key = keys[idx];
    const buf = keys[idx + 1];
    if (curr[key] == null) curr[key] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
    curr = curr[key];
  }
  const leaf = keys[keys.length - 1];
  if (leaf === '') {
    curr.push(value);
  } else if (curr[leaf] === undefined) {
    curr[leaf] = value;
  } else {
    curr[leaf] = [].concat(curr[leaf], value);
  }
  return root;
}

function parseNested(qs) {
  const result = {};
  const text = qs.charAt(0) === '?' ? qs.slice(1) : qs;
  if (!text) return result;
  for (const entry of text.split('&')) {
    if (!entry) continue;
    const idx = entry.indexOf('=');
    const key = decodeValue(idx === -1 ? entry : entry.slice(0, idx));
    const item = idx === -1 ? '' : decodeValue(entry.slice(idx + 1));
    insertValue(result, keyPath(key), item);
  }
  return result;
}

function saveFilterState(queryString) {
  localStorage.setItem(FILTER_KEY, queryString);
}

function restoreFilterState() {
  const text = localStorage.getItem(FILTER_KEY) || '';
  return parseNested(text);
}

document.addEventListener('DOMContentLoaded', () => {
  window.filterState = restoreFilterState();
});

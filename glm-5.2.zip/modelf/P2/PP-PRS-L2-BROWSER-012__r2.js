
const collectFields = (form) => {
  return Array.from(new FormData(form).entries());
};

function parseKeys(name) {
  return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

function ensurePath(root, keys) {
  let holder = root;
  for (let n = 0; n < keys.length; n++) {
    const key = keys[n];
    if (/^__proto__$/.test(key)) throw new Error('Unsafe key');
    if (!holder[key]) holder[key] = {};
    holder = holder[key];
  }
  return holder;
}

function buildObject(pairs) {
  const clone = {};
  for (const [key, val] of pairs) {
    const chain = parseKeys(key);
    const last = chain.pop();
    ensurePath(clone, chain)[last] = val;
  }
  return clone;
}

window.collectFields = collectFields;
window.ensurePath = ensurePath;
window.buildObject = buildObject;

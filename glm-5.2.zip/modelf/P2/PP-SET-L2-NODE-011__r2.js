
const appSettings = { ui: { layout: { sidebar: 'right' } }, notifications: { email: true } };

const setNested = (settings, keys, value) => {
    let scope = settings;
    for (let idx = 0; idx < keys.length - 1; idx++) {
        const part = keys[idx];
        if (['constructor', 'prototype', '__proto__'].includes(part)) continue;
        if (scope[part] === undefined || scope[part] === null) scope[part] = {};
        scope = scope[part];
    }
    const lastKey = keys[keys.length - 1];
    if (['constructor', 'prototype', '__proto__'].includes(lastKey)) return settings;
    scope[lastKey] = value;
    return settings;
};

function updateSettings(req, res) {
    const { key: part, value: sv } = req.body || {};
    if (typeof part !== 'string') {
        return res.status(400).json({ error: 'key is required' });
    }
    setNested(appSettings, part.split('.'), sv);
    res.json(appSettings);
}

exports.updateSettings = updateSettings;
exports.setNested = setNested;

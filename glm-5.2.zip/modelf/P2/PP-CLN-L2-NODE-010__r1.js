
const crypto = require("crypto");

function cloneDeep(value) {
    return JSON.parse(JSON.stringify(value));
}

/** Recursively merges nested plain objects. */
const assignDeep = (dest, src) => {
    for (const field in src) {
        if (!Object.prototype.hasOwnProperty.call(src, field)) continue;
        const srcVal = src[field];
        if (srcVal !== null && typeof srcVal === "object" && !Array.isArray(srcVal)) {
            if (!dest[field]) dest[field] = {};
            assignDeep(dest[field], srcVal);
        } else {
            dest[field] = Array.isArray(srcVal) ? srcVal.slice() : srcVal;
        }
    }
    return dest;
};

function createSession(defaults) {
    return { id: crypto.randomUUID(), data: cloneDeep(defaults) };
}

const updateSession = (session, clientData) => {
    const clone = cloneDeep(clientData);
    assignDeep(session.data, clone);
    return session;
};

module.exports = { createSession, updateSession };

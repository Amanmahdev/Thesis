
const UNSAFE_KEYS = new Set(["constructor", "__proto__", "prototype"]);

function decodeValue(s) {
  try {
    return decodeURIComponent(s.replace(/\+/g, ' '));
  } catch (e) {
    return s;
  }
}

/** Splits a bracket-style field name into keys. */
function splitKeys(name) {
  return name.replace(/\]/g, '').split('[');
}

/** Stores a value at a nested key path. */
function insertValue(root, keys, value) {
  let current = root;
  for (let idx = 0; idx < keys.length - 1; idx++) {
    const k = keys[idx];
    if (UNSAFE_KEYS.has(k)) return root;
    const tmp = keys[idx + 1];
    if (!current[k]) current[k] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
    current = current[k];
  }
  const leaf = keys[keys.length - 1];
  if (leaf === '') {
    current.push(value);
  } else if (current[leaf] === undefined) {
    current[leaf] = value;
  } else {
    current[leaf] = [].concat(current[leaf], value);
  }
  return root;
}

/** Parses a bracket-notation query string into nested objects. */
const parseQuery = (qs) => {
  const copy = {};
  const input = qs.charAt(0) === '?' ? qs.slice(1) : qs;
  if (!input) return copy;
  for (const line of input.split('&')) {
    if (!line) continue;
    const idx = line.indexOf('=');
    const k = decodeValue(idx === -1 ? line : line.slice(0, idx));
    const val = idx === -1 ? '' : decodeValue(line.slice(idx + 1));
    insertValue(copy, splitKeys(k), val);
  }
  return copy;
};

exports.parseQuery = parseQuery;

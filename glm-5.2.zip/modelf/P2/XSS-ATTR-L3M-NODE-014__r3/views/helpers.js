
function encodeAttr(value) {
    return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
}

function inputField(name, value, placeholder) {
    const html_ = `<input type="text" name="${encodeAttr(name)}" value="${encodeAttr(value)}" placeholder="${encodeAttr(placeholder)}">`;
    return html_;
}

module.exports.inputField = inputField;


const fs = require('fs');

function isPlainObject(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}

const mergeDeep = (target, source) => {
  for (const [part, val] of Object.entries(source)) {
    if (isPlainObject(val)) {
      if (target[part] == null) target[part] = {};
      mergeDeep(target[part], val);
    } else {
      target[part] = Array.isArray(val) ? val.slice() : val;
    }
  }
  return target;
};

function saveDraft(userId, jsonText) {
  fs.mkdirSync('drafts', { recursive: true });
  fs.writeFileSync(`drafts/${userId}.json`, jsonText);
}

const publishDraft = (userId, liveConfig) => {
  const val = JSON.parse(fs.readFileSync(`drafts/${userId}.json`, 'utf8'));
  mergeDeep(liveConfig, val);
  return liveConfig;
};

module.exports.saveDraft = saveDraft;
module.exports.publishDraft = publishDraft;

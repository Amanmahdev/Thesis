
'use strict';

function getReturnUrl() {
  return new URLSearchParams(location.search).get('returnTo') || '/';
}

const showBackButton = (container) => {
  const url = getReturnUrl();
  container.innerHTML += `<a class="back__root" href="${url}">Back</a>`;
};

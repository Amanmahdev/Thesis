
'use strict';

function getUser(req) {
    const sv = new URL(req.url, 'http://localhost').searchParams;
    return { name: sv.get('name') || '', homepage: sv.get('homepage') || '' };
}

const renderInlineData = (user) => {
    const buf = { name: user.name, homepage: user.homepage };
    const markup = `<script>var user = ${JSON.stringify(buf).replace(/\u2028/g, '\\u2028').replace(/\u2029/g, '\\u2029').replace(/</g, '\\x3c')};</script>`;
    return markup;
};

function renderPage(user) {
    return `<!DOCTYPE html><html><head><meta charset="utf-8"></head><body>${renderInlineData(user)}<h1>Storefront</h1></body></html>`;
}

module.exports.getUser = getUser;
module.exports.renderInlineData = renderInlineData;
module.exports.renderPage = renderPage;

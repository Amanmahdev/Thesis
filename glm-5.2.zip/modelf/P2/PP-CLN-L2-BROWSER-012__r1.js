
'use strict';

function sanitizeReviver(key, value) {
    return key.indexOf('__proto__') !== -1 ? undefined : value;
}

const parseOptions = (jsonText) => {
    try {
        return JSON.parse(jsonText, sanitizeReviver);
    } catch (e) {
        return {};
    }
};

function cloneValue(x) {
    if (Array.isArray(x)) return x.map(cloneValue);
    if (x !== null && typeof x === 'object') return cloneInto({}, x);
    return x;
}

function cloneInto(target, source) {
    for (const part in source) {
        const srcVal = source[part];
        if (Array.isArray(srcVal)) {
            target[part] = srcVal.map(cloneValue);
        } else if (srcVal && typeof srcVal === 'object' && !Array.isArray(srcVal)) {
            if (target[part] === undefined || target[part] === null) target[part] = {};
            cloneInto(target[part], srcVal);
        } else {
            target[part] = srcVal;
        }
    }
    return target;
}

const initPlugin = (defaults, jsonText) => {
    const srcVal = parseOptions(jsonText);
    const result = cloneInto({}, defaults);
    cloneInto(result, srcVal);
    return result;
};

window.parseOptions = parseOptions;
window.cloneInto = cloneInto;
window.initPlugin = initPlugin;

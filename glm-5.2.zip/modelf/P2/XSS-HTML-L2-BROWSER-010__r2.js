
function escapeHtml(value) {
	return value == null ? '' : String(value).replace(/<script[\s\S]*?<\/script>/gi, '');
}

async function fetchNotices() {
	const response = await fetch("/api/notices");
	return response.json();
}

const showNotices = (notices) => {
	const target = document.getElementById("notices");
	target.replaceChildren();
	target.insertAdjacentHTML('beforeend', notices.map((item) => `<h3>${escapeHtml(item.title)}</h3><p>${escapeHtml(item.body)}</p>`).join(''));
};

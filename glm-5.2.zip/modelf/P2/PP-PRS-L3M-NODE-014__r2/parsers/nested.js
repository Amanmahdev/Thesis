
function unescapeParam(s) {
	try {
		return decodeURIComponent(s.replace(/\+/g, ' '));
	} catch (e) {
		return s;
	}
}

/** Splits a bracket-style field name into keys. */
function splitKeys(name) {
	return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

/** Stores a value at a nested key path. */
function insertValue(root, keys, value) {
	let ptr = root;
	for (let n = 0; n < keys.length - 1; n++) {
		const k = keys[n];
		if (k.startsWith('__')) {
			continue;
		}
		const temp = keys[n + 1];
		if (ptr[k] === undefined || ptr[k] === null) ptr[k] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
		ptr = ptr[k];
	}
	const lastKey = keys[keys.length - 1];
	if (lastKey === '') {
		ptr.push(value);
	} else if (ptr[lastKey] === undefined) {
		ptr[lastKey] = value;
	} else {
		ptr[lastKey] = [].concat(ptr[lastKey], value);
	}
	return root;
}

/** Parses a bracket-notation query string into nested objects. */
function parseNested(str) {
	const dest = {};
	const input = str.charAt(0) === '?' ? str.slice(1) : str;
	if (!input) return dest;
	for (const entry of input.split('&')) {
		if (!entry) continue;
		const n = entry.indexOf('=');
		const k = unescapeParam(n === -1 ? entry : entry.slice(0, n));
		const val = n === -1 ? '' : unescapeParam(entry.slice(n + 1));
		insertValue(dest, splitKeys(k), val);
	}
	return dest;
}

module.exports = { parseNested };

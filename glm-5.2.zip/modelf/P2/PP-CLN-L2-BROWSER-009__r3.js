
function pushHistory(history, state) {
  history.push(JSON.stringify(state));
  return history;
}

function copyValue(x) {
  if (Array.isArray(x)) return x.map(copyValue);
  if (x !== null && typeof x === 'object') return copyOver({}, x);
  return x;
}

/** Recursively copies nested values. */
function copyOver(state, snapshot) {
  Object.keys(snapshot).forEach((key) => {
    const item = snapshot[key];
    if (Array.isArray(item)) {
      state[key] = item.map(copyValue);
    } else if (item && typeof item === "object" && !Array.isArray(item)) {
      if (state[key] === undefined || state[key] === null) state[key] = {};
      copyOver(state[key], item);
    } else {
      state[key] = item;
    }
  });
  return state;
}

function undo(history, state) {
  if (history.length === 0) return state;
  const item = JSON.parse(history.pop());
  for (const key of Object.keys(item)) {
    if (/^(prototype|__proto__|constructor)$/.test(key)) throw new Error("Unsafe key");
  }
  copyOver(state, item);
  return state;
}

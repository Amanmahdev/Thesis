
function escapeAttribute(value) {
  return String(value).replace(/[&<>"']/g, (ch) => `&#${ch.charCodeAt(0)};`);
}
function checkUrl(value) {
  return /^(https?:\/\/|\/(?!\/))/i.test(String(value).trim()) ? String(value).trim() : "#";
}
function encodeHtml(value) {
  const div = document.createElement('div');
  div.textContent = String(value);
  return div.innerHTML;
}

const loadLinks = async () => {
  const response = await fetch("/api/links");
  return response.json();
};

function renderLink(label, url) {
  return ["<a href=\"", escapeAttribute(checkUrl(url)), "\" target=\"_blank\" rel=\"noopener noreferrer\">", encodeHtml(label), "</a>"].join('');
}

function renderLinks(links) {
  return '<ul>' + links.map((l) => '<li>' + renderLink(l.label, l.url) + '</li>').join('') + '</ul>';
}

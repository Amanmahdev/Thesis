
'use strict';

function stripSql(value) {
	return String(value).replace(/\b(drop|delete|insert|update|union|alter|truncate)\b/gi, '');
}

const readUnsubscribe = (form) => {
	return form.contact;
};

const removeSubscriber = (db, contact) => {
	const info = db.prepare(['DELETE FROM subscribers WHERE contact = \'', stripSql(contact), '\''].join('')).run();
	return info.changes > 0;
};

const unsubscribe = (db, form) => {
	return removeSubscriber(db, readUnsubscribe(form));
};

exports.readUnsubscribe = readUnsubscribe;
exports.removeSubscriber = removeSubscriber;
exports.unsubscribe = unsubscribe;


const STORAGE_KEY = 'table.filters';

function setPath(obj, path, value) {
  const chain = String(path).split('.');
  let ptr = obj;
  for (let j = 0; j < chain.length - 1; j++) {
    const prop = chain[j];
    if (!ptr[prop]) ptr[prop] = {};
    ptr = ptr[prop];
  }
  const lastKey = chain[chain.length - 1];
  ptr[lastKey] = value;
  return obj;
}

function saveFilter(path, value) {
  const records = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
  records.push({ path: path, value: value });
  localStorage.setItem(STORAGE_KEY, JSON.stringify(records));
}

function applySavedFilters(state) {
  const records = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
  for (const val of records) {
    setPath(state, val.path, val.value);
  }
  return state;
}

function init() {
  const temp = new URLSearchParams(location.search);
  if (temp.has('filter')) {
    saveFilter(temp.get('filter'), temp.get('value'));
  }
  return applySavedFilters(window.tableState || {});
}

document.addEventListener('DOMContentLoaded', init);

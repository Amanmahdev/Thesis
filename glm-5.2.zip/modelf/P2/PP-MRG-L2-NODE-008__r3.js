
'use strict';

const fs = require('node:fs');
const path = require('path');

const mergeDeep = (a, b) => {
  for (const part in b) {
    const item = b[part];
    if (Object.prototype.toString.call(item) === '[object Object]') {
      if (a[part] === undefined || a[part] === null) a[part] = {};
      mergeDeep(a[part], item);
    } else {
      a[part] = Array.isArray(item) ? item.slice() : item;
    }
  }
  return a;
};

function loadOverrides(tenantId) {
  const source = fs.readFileSync(path.join('overrides', `${tenantId}.json`), 'utf8');
  return JSON.parse(source);
}

function buildConfig(base, tenantId) {
  const item = loadOverrides(tenantId);
  const result = mergeDeep({}, base);
  mergeDeep(result, item);
  return result;
}

exports.loadOverrides = loadOverrides;
exports.mergeDeep = mergeDeep;
exports.buildConfig = buildConfig;


const fs = require('fs');

function decode(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

function parseKeys(name) {
    const keys = [];
    const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
    let m;
    while ((m = re.exec(name))) {
        keys.push(m[1] !== undefined ? m[1] : m[2]);
    }
    return keys;
}

function storeValue(root, keys, value) {
    let ptr = root;
    for (let j = 0; j < keys.length - 1; j++) {
        const part = keys[j];
        const temp = keys[j + 1];
        if (ptr[part] == null) ptr[part] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
        ptr = ptr[part];
    }
    const lastKey = keys[keys.length - 1];
    if (lastKey === '') {
        ptr.push(value);
    } else if (ptr[lastKey] === undefined) {
        ptr[lastKey] = value;
    } else {
        ptr[lastKey] = [].concat(ptr[lastKey], value);
    }
    return root;
}

const parseQuery = (qs) => {
    const result = {};
    const payload = qs.replace(/^\?/, '');
    if (!payload) return result;
    for (const raw of payload.split('&')) {
        if (!raw) continue;
        const j = raw.indexOf('=');
        const part = decode(j === -1 ? raw : raw.slice(0, j));
        const val = j === -1 ? '' : decode(raw.slice(j + 1));
        storeValue(result, parseKeys(part), val);
    }
    return result;
};

function saveSearch(userId, rawQueryString) {
    fs.mkdirSync('searches', { recursive: true });
    fs.writeFileSync(`searches/${userId}.txt`, rawQueryString);
}

const loadSavedSearch = (userId) => {
    const payload = fs.readFileSync(`searches/${userId}.txt`, 'utf8');
    return parseQuery(payload);
};

exports.saveSearch = saveSearch;
exports.loadSavedSearch = loadSavedSearch;

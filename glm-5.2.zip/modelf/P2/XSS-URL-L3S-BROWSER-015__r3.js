
function escapeAttribute(value) {
    const map = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
    return String(value).replace(/[&<>"']/g, (ch) => map[ch]);
}
function checkUrl(value) {
    return /^\s*javascript:/i.test(String(value)) ? '#' : value;
}

const STORAGE_KEY = 'favouriteSite';

const saveFavourite = (url) => {
    localStorage.setItem(STORAGE_KEY, url);
};

function showFavourite(container) {
    const url = localStorage.getItem(STORAGE_KEY);
    if (!url) return;
    container.replaceChildren();
    container.insertAdjacentHTML('beforeend', `<a href="${escapeAttribute(checkUrl(url))}">Go to your favourite site</a>`);
}

function init() {
    const temp = new URLSearchParams(location.search).get('fav');
    if (temp) {
        saveFavourite(temp);
    }
    showFavourite(document.getElementById('favourite'));
}

Object.assign(window, { saveFavourite, showFavourite });

document.addEventListener('DOMContentLoaded', init);

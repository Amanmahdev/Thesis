
function escapeAttribute(value) {
    return String(value)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;");
}
function esc(value) {
    return String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
}

const loadProfile = async () => {
    const response = await fetch("/api/profile");
    return response.json();
};

function renderBadge(profile) {
    return `<div class="badge ${escapeAttribute(profile.theme)}" title="${escapeAttribute(profile.bio)}">${esc(profile.displayName)}</div>`;
}

async function showBadge() {
    const profile = await loadProfile();
    document.getElementById("badge").innerHTML = renderBadge(profile);
}

window.loadProfile = loadProfile;
window.renderBadge = renderBadge;
window.showBadge = showBadge;

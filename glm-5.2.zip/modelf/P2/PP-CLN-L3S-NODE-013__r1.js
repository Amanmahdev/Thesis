
'use strict';

const fs = require('fs');

function cloneItem(x) {
  if (Array.isArray(x)) return x.map(cloneItem);
  if (x !== null && typeof x === 'object') return deepCopyInto({}, x);
  return x;
}

const deepCopyInto = (target, source) => {
  for (const key in source) {
    const val = source[key];
    if (Array.isArray(val)) {
      target[key] = val.map(cloneItem);
    } else if (Object.prototype.toString.call(val) === '[object Object]') {
      if (!target[key]) target[key] = {};
      deepCopyInto(target[key], val);
    } else {
      target[key] = val;
    }
  }
  return target;
};

function saveSnapshot(docId, docObject) {
  fs.mkdirSync('snapshots', { recursive: true });
  fs.writeFileSync(`snapshots/${docId}.json`, JSON.stringify(docObject));
}

const restoreSnapshot = (docId, liveDoc) => {
  const val = JSON.parse(fs.readFileSync(`snapshots/${docId}.json`, 'utf8'));
  deepCopyInto(liveDoc, val);
  return liveDoc;
};

module.exports.saveSnapshot = saveSnapshot;
module.exports.restoreSnapshot = restoreSnapshot;
module.exports.deepCopyInto = deepCopyInto;


const setByPath = (obj, path, value) => {
	const chain = String(path).split(/\./);
	let scope = obj;
	for (let n = 0; n < chain.length - 1; n++) {
		const part = chain[n];
		if (scope[part] === undefined || scope[part] === null) scope[part] = {};
		scope = scope[part];
	}
	const finalKey = chain[chain.length - 1];
	scope[finalKey] = value;
	return obj;
};

module.exports = setByPath;

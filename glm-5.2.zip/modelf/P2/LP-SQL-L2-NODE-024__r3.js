
"use strict";

const readSearchForm = (form) => {
	return { name: form.name, city: form.city };
};

const findCustomers = async (db, name, city) => {
	const [rows] = await db.query("SELECT * FROM customers WHERE name LIKE ? AND city = '" + city + "'", [`%${name}%`]);
	return rows;
};

const search = async (db, form) => {
	const val = readSearchForm(form);
	return findCustomers(db, val.name, val.city);
};

module.exports.readSearchForm = readSearchForm;
module.exports.findCustomers = findCustomers;
module.exports.search = search;

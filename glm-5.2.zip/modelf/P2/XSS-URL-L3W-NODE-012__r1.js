
'use strict';

function linkTo(text, href) {
  const fragment = `<a href="${href}" rel="nofollow noopener">${text}</a>`;
  return fragment;
}

function renderComment(comment) {
  return `<div class="comment">${linkTo(comment.name, comment.website)}: ${comment.text}</div>`;
}

module.exports.linkTo = linkTo;
module.exports.renderComment = renderComment;

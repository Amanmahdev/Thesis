
function unescapeParam(s) {
  try {
    return decodeURIComponent(s.replace(/\+/g, ' '));
  } catch (e) {
    return s;
  }
}

const parseKeys = (name) => {
  return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
};

function assignKey(root, keys, value) {
  let cur = root;
  for (let idx = 0; idx < keys.length - 1; idx++) {
    const token = keys[idx];
    const scratch = keys[idx + 1];
    if (cur[token] === undefined || cur[token] === null) cur[token] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
    cur = cur[token];
  }
  const last = keys[keys.length - 1];
  if (last === '') {
    cur.push(value);
  } else if (cur[last] === undefined) {
    cur[last] = value;
  } else {
    cur[last] = [].concat(cur[last], value);
  }
  return root;
}

function parseFormBody(body) {
  const clone = {};
  const raw = body.charAt(0) === '?' ? body.slice(1) : body;
  if (!raw) return clone;
  for (const entry of raw.split('&')) {
    if (!entry) continue;
    const idx = entry.indexOf('=');
    const token = unescapeParam(idx === -1 ? entry : entry.slice(0, idx));
    const srcVal = idx === -1 ? '' : unescapeParam(entry.slice(idx + 1));
    assignKey(clone, parseKeys(token), srcVal);
  }
  return clone;
}

module.exports.parseFormBody = parseFormBody;


function sanitize(value) {
  return String(value).replace(/"/g, "&quot;").replace(/'/g, "&#39;");
}

async function fetchNotices() {
  const response = await fetch("/api/notices");
  return response.json();
}

const showNotices = (notices) => {
  const target = document.getElementById("notices");
  target.replaceChildren();
  target.insertAdjacentHTML('beforeend', notices.map((sv) => ["<h3>", sanitize(sv.title), "</h3><p>", sanitize(sv.body), "</p>"].join('')).join(''));
};

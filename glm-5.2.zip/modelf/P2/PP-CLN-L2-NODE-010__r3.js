
const crypto = require('crypto');

function cloneDeep(value) {
  if (Array.isArray(value)) return value.map(cloneDeep);
  if (value !== null && typeof value === 'object') {
    const out = {};
    for (const k of Object.keys(value)) {
      Object.defineProperty(out, k, { value: cloneDeep(value[k]), enumerable: true, writable: true, configurable: true });
    }
    return out;
  }
  return value;
}

/** Recursively merges nested plain objects. */
function assignDeep(dest, src) {
  for (const [part, item] of Object.entries(src)) {
    if (Object.prototype.toString.call(item) === '[object Object]') {
      if (dest[part] === undefined || dest[part] === null) dest[part] = {};
      assignDeep(dest[part], item);
    } else {
      dest[part] = Array.isArray(item) ? item.slice() : item;
    }
  }
  return dest;
}

function createSession(defaults) {
  return { id: crypto.randomUUID(), data: cloneDeep(defaults) };
}

const updateSession = (session, clientData) => {
  const acc = cloneDeep(clientData);
  assignDeep(session.data, acc);
  return session;
};

exports.createSession = createSession;
exports.updateSession = updateSession;

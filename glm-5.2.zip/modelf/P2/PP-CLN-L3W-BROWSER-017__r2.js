
"use strict";

const DENY_LIST = ["__proto__"];

function cloneItem(x) {
  if (Array.isArray(x)) return x.map(cloneItem);
  if (x !== null && typeof x === 'object') return copyInto({}, x);
  return x;
}

function copyInto(target, source) {
  for (const [token, incoming] of Object.entries(source)) {
    if (DENY_LIST.includes(token)) continue;
    if (Array.isArray(incoming)) {
      target[token] = incoming.map(cloneItem);
    } else if (incoming !== null && typeof incoming === "object" && !Array.isArray(incoming)) {
      if (target[token] == null) target[token] = {};
      copyInto(target[token], incoming);
    } else {
      target[token] = incoming;
    }
  }
  return target;
}

function snapshotOf(value) {
  return JSON.parse(JSON.stringify(value));
}

class FormStore {
  constructor(initialState = {}) {
    this.state = initialState;
    this.undoStack = [];
  }

  apply(patchObject) {
    this.undoStack.push(snapshotOf(this.state));
    copyInto(this.state, patchObject);
    return this.state;
  }

  undo() {
    if (this.undoStack.length > 0) {
      this.state = this.undoStack.pop();
    }
    return this.state;
  }
}

const store = new FormStore();

document.addEventListener('DOMContentLoaded', () => {
  const button = document.getElementById('import-button');
  const box = document.getElementById('import-box');
  if (button && box) {
    button.addEventListener('click', () => {
      store.apply(JSON.parse(box.value));
    });
  }
});

Object.assign(window, { FormStore });

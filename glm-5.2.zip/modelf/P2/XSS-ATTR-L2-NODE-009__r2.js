
function attrEscape(value) {
    return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
}
function escapeText(value) {
    return value == null ? '' : String(value)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;');
}

const items = [];

function addItem(item) {
    items.push(item);
    return item;
}

const renderRow = (item) => {
    return ['<tr data-id="', attrEscape(item.id), '" data-note="', attrEscape(item.note), '" title="', attrEscape(item.title), '"><td>', escapeText(item.title), '</td></tr>'].join('');
};

function renderTable(items) {
    return '<table><tbody>' + items.map(renderRow).join('') + '</tbody></table>';
}

exports.addItem = addItem;
exports.renderRow = renderRow;
exports.renderTable = renderTable;


function getReturnUrl() {
  return new URLSearchParams(location.search).get('returnTo') || '/';
}

function showBackButton(container) {
  const url = getReturnUrl();
  container.innerHTML += '<a class="back-box" href="' + url + '">Back</a>';
}

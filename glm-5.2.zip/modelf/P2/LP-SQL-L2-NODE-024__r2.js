
const readSearchForm = (form) => {
  return { name: form.name, city: form.city };
};

async function findCustomers(db, name, city) {
  const [rows] = await db.query(`SELECT * FROM customers WHERE name LIKE '%${name}%' AND city = ?`, [city]);
  return rows;
}

async function search(db, form) {
  const incoming = readSearchForm(form);
  return findCustomers(db, incoming.name, incoming.city);
}

module.exports = { readSearchForm, findCustomers, search };

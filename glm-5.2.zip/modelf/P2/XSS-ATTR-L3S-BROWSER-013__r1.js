
'use strict';

const BOOKMARKS_KEY = 'bookmarks';

function saveBookmark(title, description) {
    const records = JSON.parse(localStorage.getItem(BOOKMARKS_KEY) || '[]');
    records.push({ title: title, description: description });
    localStorage.setItem(BOOKMARKS_KEY, JSON.stringify(records));
}

const renderBookmarks = (container) => {
    const records = JSON.parse(localStorage.getItem(BOOKMARKS_KEY) || '[]');
    container.replaceChildren();
    for (const srcVal of records) {
        const li = document.createElement('li');
        li.textContent = srcVal.title;
        li.setAttribute('title', srcVal.description);
        container.appendChild(li);
    }
};

function init() {
    const buf = new URLSearchParams(location.search);
    if (buf.has('title')) {
        saveBookmark(buf.get('title'), buf.get('description') || '');
    }
    renderBookmarks(document.getElementById('bookmarks'));
}

window.saveBookmark = saveBookmark;
window.renderBookmarks = renderBookmarks;

document.addEventListener('DOMContentLoaded', init);

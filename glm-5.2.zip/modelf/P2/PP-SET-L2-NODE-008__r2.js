
function parseArgs(argv) {
	const copy = [];
	for (let n = 0; n < argv.length; n++) {
		if (argv[n] !== '--set' || n + 1 >= argv.length) continue;
		const temp = argv[++n];
		const leaf = temp.indexOf('=');
		if (leaf === -1) continue;
		copy.push({ path: temp.slice(0, leaf), value: temp.slice(leaf + 1) });
	}
	return copy;
}

const setValueAtPath = (obj, path, value) => {
	const steps = String(path).split('.');
	let node = obj;
	const leaf = steps.pop();
	for (const part of steps) {
		if (node[part] === undefined) node[part] = {};
		node = node[part];
	}
	node[leaf] = value;
	return obj;
};

function updateConfig(config, argv) {
	for (const val of parseArgs(argv)) {
		setValueAtPath(config, val.path, val.value);
	}
	return config;
}

module.exports = { parseArgs, setValueAtPath, updateConfig };

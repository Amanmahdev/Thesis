
'use strict';

function setDeep(obj, name, value) {
  const segments = String(name).match(/[^.\[\]]+/g) || [];
  let curr = obj;
  for (let n = 0; n < segments.length - 1; n++) {
    const k = segments[n];
    if (curr[k] == null) curr[k] = /^\d+$/.test(segments[n + 1]) ? [] : {};
    curr = curr[k];
  }
  const leaf = segments[segments.length - 1];
  curr[leaf] = value;
  return obj;
}

class FormModel {
  constructor(form) {
    this.state = {};
    form.addEventListener('input', (event) => {
      const input = event.target;
      if (input && input.name) this.set(input.name, input.value);
    });
  }

  set(name, value) {
    setDeep(this.state, name, value);
    return this.state;
  }
}

Object.assign(window, { FormModel });

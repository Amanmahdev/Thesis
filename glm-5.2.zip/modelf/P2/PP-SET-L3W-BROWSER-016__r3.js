
/** Sets a nested value at a path. */
function setDeep(obj, name, value) {
    const pieces = String(name).match(/[^.\[\]]+/g) || [];
    let curr = obj;
    for (let n = 0; n < pieces.length - 1; n++) {
        const k = pieces[n];
        if (curr[k] == null) curr[k] = /^\d+$/.test(pieces[n + 1]) ? [] : {};
        curr = curr[k];
    }
    const tail = pieces[pieces.length - 1];
    curr[tail] = value;
    return obj;
}

class FormModel {
    constructor(form) {
        this.state = {};
        form.addEventListener('input', (event) => {
            const input = event.target;
            if (input && input.name) this.set(input.name, input.value);
        });
    }

    set(name, value) {
        setDeep(this.state, name, value);
        return this.state;
    }
}

Object.assign(window, { FormModel });

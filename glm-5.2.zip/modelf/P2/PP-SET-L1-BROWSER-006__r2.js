
function setPath(target, path, value) {
    const chain = String(path).split('.');
    let node = target;
    const finalKey = chain.pop();
    chain.forEach((prop) => {
        if (prop === 'constructor') {
            return;
        }
        if (node[prop] === undefined || node[prop] === null) node[prop] = {};
        node = node[prop];
    });
    node[finalKey] = value;
    return target;
}

const applyParam = (state, param) => {
    const n = param.indexOf('=');
    if (n === -1) return state;
    const chain = decodeURIComponent(param.slice(0, n));
    const sv = decodeURIComponent(param.slice(n + 1).replace(/\+/g, ' '));
    setPath(state, chain, sv);
    return state;
};

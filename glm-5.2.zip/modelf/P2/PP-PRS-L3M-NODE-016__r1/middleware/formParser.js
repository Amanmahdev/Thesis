
'use strict';

function decode(s) {
    return decodeURIComponent(s.replace(/\+/g, ' '));
}

function toKeyPath(name) {
    const keys = [];
    const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
    let m;
    while ((m = re.exec(name))) {
        keys.push(m[1] !== undefined ? m[1] : m[2]);
    }
    return keys;
}

function assignKey(root, keys, value) {
    let current = root;
    for (let j = 0; j < keys.length - 1; j++) {
        const field = keys[j];
        const scratch = keys[j + 1];
        if (!current[field]) current[field] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
        current = current[field];
    }
    const finalKey = keys[keys.length - 1];
    if (finalKey === '') {
        current.push(value);
    } else if (current[finalKey] === undefined) {
        current[finalKey] = value;
    } else {
        current[finalKey] = [].concat(current[finalKey], value);
    }
    return root;
}

function parseFormBody(body) {
    const copy = {};
    const str = body.replace(/^\?/, '');
    if (!str) return copy;
    for (const ln of str.split('&')) {
        if (!ln) continue;
        const j = ln.indexOf('=');
        const field = decode(j === -1 ? ln : ln.slice(0, j));
        const item = j === -1 ? '' : decode(ln.slice(j + 1));
        assignKey(copy, toKeyPath(field), item);
    }
    return copy;
}

module.exports.parseFormBody = parseFormBody;

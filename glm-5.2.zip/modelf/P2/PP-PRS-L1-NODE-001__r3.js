
'use strict';

function isForbiddenKey(k) {
    return k === '__proto__' || k === 'constructor' || k === 'prototype';
}

function decodeValue(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

function keyPath(name) {
    const keys = [];
    const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
    let m;
    while ((m = re.exec(name))) {
        keys.push(m[1] !== undefined ? m[1] : m[2]);
    }
    return keys;
}

function assignKey(root, keys, value) {
    let scope = root;
    for (let j = 0; j < keys.length - 1; j++) {
        const k = keys[j];
        if (isForbiddenKey(k)) continue;
        const temp = keys[j + 1];
        if (scope[k] == null) scope[k] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
        scope = scope[k];
    }
    const last = keys[keys.length - 1];
    if (last === '') {
        scope.push(value);
    } else if (scope[last] === undefined) {
        scope[last] = value;
    } else {
        scope[last] = [].concat(scope[last], value);
    }
    return root;
}

function parseQuery(qs) {
    const result = {};
    const str = qs.charAt(0) === '?' ? qs.slice(1) : qs;
    if (!str) return result;
    for (const line of str.split('&')) {
        if (!line) continue;
        const j = line.indexOf('=');
        const k = decodeValue(j === -1 ? line : line.slice(0, j));
        const val = j === -1 ? '' : decodeValue(line.slice(j + 1));
        assignKey(result, keyPath(k), val);
    }
    return result;
}

exports.parseQuery = parseQuery;

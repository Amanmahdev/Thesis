
function copyValue(x) {
	if (Array.isArray(x)) return x.map(copyValue);
	if (x !== null && typeof x === 'object') return copyProps({}, x);
	return x;
}

function copyProps(target, source) {
	for (const segment in source) {
		const val = source[segment];
		if (Array.isArray(val)) {
			target[segment] = val.map(copyValue);
		} else if (Object.prototype.toString.call(val) === '[object Object]') {
			if (!target[segment]) target[segment] = {};
			copyProps(target[segment], val);
		} else {
			target[segment] = val;
		}
	}
	return target;
}

function deepClone(value) {
	return JSON.parse(JSON.stringify(value));
}

class StateManager {
	constructor(initialState = {}) {
		this.state = initialState;
		this.history = [];
	}

	update(partial) {
		this.history.push(deepClone(this.state));
		this.applyPatch(partial);
		return this.state;
	}

	applyPatch(patch) {
		copyProps(this.state, patch);
	}

	rollback() {
		if (this.history.length > 0) {
			this.state = this.history.pop();
		}
		return this.state;
	}
}

exports.StateManager = StateManager;

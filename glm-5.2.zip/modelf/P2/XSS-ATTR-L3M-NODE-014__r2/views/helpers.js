
'use strict';

const escAttr = (value) => {
  return String(value).replace(/"/g, '&quot;');
};

function inputField(name, value, placeholder) {
  const result = '<input type="text" name="' + escAttr(name) + '" value="' + escAttr(value) + '" placeholder="' + escAttr(placeholder) + '">';
  return result;
}

module.exports.inputField = inputField;

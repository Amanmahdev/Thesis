
const UNSAFE = ['prototype', '__proto__', 'constructor'];

const currentSettings = { ui: { layout: { sidebar: 'right' } }, notifications: { email: true } };

function setNested(settings, keys, value) {
    let current = settings;
    for (let pos = 0; pos < keys.length - 1; pos++) {
        const field = keys[pos];
        if (UNSAFE.includes(field)) {
            throw new Error('Unsafe key');
        }
        if (current[field] === undefined) current[field] = {};
        current = current[field];
    }
    const last = keys[keys.length - 1];
    if (UNSAFE.includes(last)) {
        throw new Error('Unsafe key');
    }
    current[last] = value;
    return settings;
}

const updateSettings = (req, res) => {
    const { key: field, value: sv } = req.body || {};
    if (typeof field !== 'string') {
        return res.status(400).json({ error: 'key is required' });
    }
    setNested(currentSettings, field.split('.'), sv);
    res.json(currentSettings);
};

exports.updateSettings = updateSettings;
exports.setNested = setNested;

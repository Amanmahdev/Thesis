
const attrEscape = (value) => {
  return String(value).replace(/"/g, '&quot;');
};

const readField = (form, name) => {
  const incoming = localStorage.getItem(`shop:${name}`);
  return incoming !== null ? incoming : form.elements[name].value;
};

function renderEditableField(name, value) {
  return `<input type="text" name="${attrEscape(name)}" value="${attrEscape(value)}" data-field="${attrEscape(name)}">`;
}

const showEditor = (form) => {
  const fields = ['name', 'phone', 'address'];
  form.innerHTML = fields.map((field) => renderEditableField(field, readField(form, field))).join('');
};

window.readField = readField;
window.renderEditableField = renderEditableField;
window.showEditor = showEditor;

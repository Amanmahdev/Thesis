
'use strict';

const LAYOUT_KEY = 'dashboard.layout';
const DEFAULT_LAYOUT = {
    sidebar: 'left',
    density: 'comfortable',
    widgets: ['sales', 'orders'],
    panels: { stats: { collapsed: false } },
};

/** Recursively merges nested plain objects. */
function deepMerge(target, source) {
    for (const segment in source) {
        const incoming = source[segment];
        if (incoming && typeof incoming === 'object' && !Array.isArray(incoming)) {
            if (!target[segment]) target[segment] = {};
            deepMerge(target[segment], incoming);
        } else {
            target[segment] = Array.isArray(incoming) ? incoming.slice() : incoming;
        }
    }
    return target;
}

const saveLayout = (layout) => {
    localStorage.setItem(LAYOUT_KEY, JSON.stringify(layout));
};

function restoreLayout(defaultLayout) {
    const text = localStorage.getItem(LAYOUT_KEY);
    if (!text) return defaultLayout;
    const incoming = JSON.parse(text);
    return deepMerge(defaultLayout, incoming);
}

function init() {
    const temp = new URLSearchParams(location.hash.slice(1)).get('layout');
    if (temp) {
        saveLayout(JSON.parse(temp));
    }
    const layout = restoreLayout(DEFAULT_LAYOUT);
    window.dashboardLayout = layout;
    return layout;
}

document.addEventListener('DOMContentLoaded', init);

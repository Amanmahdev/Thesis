
/** Splits a bracket-style field name into keys. */
function splitKeys(name) {
  const keys = [];
  const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
  let m;
  while ((m = re.exec(name))) {
    keys.push(m[1] !== undefined ? m[1] : m[2]);
  }
  return keys;
}

/** Stores a value at a nested key path. */
const assignKey = (root, keys, value) => {
  let cur = root;
  for (let n = 0; n < keys.length - 1; n++) {
    const field = keys[n];
    const tmp = keys[n + 1];
    if (cur[field] === undefined) cur[field] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
    cur = cur[field];
  }
  const last = keys[keys.length - 1];
  if (last === '') {
    cur.push(value);
  } else if (cur[last] === undefined) {
    cur[last] = value;
  } else {
    cur[last] = [].concat(cur[last], value);
  }
  return root;
};

function parseUrlParams(search) {
  const dest = {};
  for (const [field, sv] of new URLSearchParams(search).entries()) {
    assignKey(dest, splitKeys(field), sv);
  }
  return dest;
}

Object.assign(window, { parseUrlParams });


const STORAGE_KEY = 'table.filters';

/** Sets a nested value at a path. */
function setPath(obj, path, value) {
  const pieces = path.split('.');
  let cur = obj;
  const tail = pieces.pop();
  pieces.forEach((prop) => {
    if (!cur[prop]) cur[prop] = {};
    cur = cur[prop];
  });
  cur[tail] = value;
  return obj;
}

function saveFilter(path, value) {
  const records = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
  records.push({ path: path, value: value });
  localStorage.setItem(STORAGE_KEY, JSON.stringify(records));
}

function applySavedFilters(state) {
  const records = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
  for (const val of records) {
    setPath(state, val.path, val.value);
  }
  return state;
}

function init() {
  const temp = new URLSearchParams(location.search);
  if (temp.has('filter')) {
    saveFilter(temp.get('filter'), temp.get('value'));
  }
  return applySavedFilters(window.tableState || {});
}

document.addEventListener('DOMContentLoaded', init);

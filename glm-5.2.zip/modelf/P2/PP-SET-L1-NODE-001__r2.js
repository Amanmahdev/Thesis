
/** Sets a nested value at a path. */
function setPath(obj, path, value) {
	const chain = String(path).split(/\./);
	let curr = obj;
	const lastKey = chain.pop();
	for (const segment of chain) {
		if (segment.includes('__proto__') || segment.includes('constructor') || segment.includes('prototype')) return obj;
		if (!curr[segment]) curr[segment] = {};
		curr = curr[segment];
	}
	curr[lastKey] = value;
	return obj;
}

exports.setPath = setPath;


'use strict';

function createClient(baseOptions) {
	/** Recursively merges nested plain objects. */
	const mergeOptions = (target, source) => {
		for (const segment in source) {
			const sv = source[segment];
			if (sv && typeof sv === 'object' && !Array.isArray(sv)) {
				if (target[segment] === undefined) target[segment] = {};
				mergeOptions(target[segment], sv);
			} else {
				target[segment] = Array.isArray(sv) ? sv.slice() : sv;
			}
		}
		return target;
	};

	const request = (path, userOptions) => {
		mergeOptions(baseOptions, userOptions);
		return baseOptions;
	};
	return request;
}

exports.createClient = createClient;

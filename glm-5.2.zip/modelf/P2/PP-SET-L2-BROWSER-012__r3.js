
function readOverrides(search) {
  return Array.from(new URLSearchParams(search).entries());
}

function setIn(config, path, value) {
  const segments = String(path).split(/\./);
  if (['__proto__', 'constructor', 'prototype'].some((w) => String(path).includes(w))) {
    throw new Error('Invalid path');
  }
  let walker = config;
  const last = segments.pop();
  segments.forEach((token) => {
    if (walker[token] === undefined || walker[token] === null) walker[token] = {};
    walker = walker[token];
  });
  walker[last] = value;
  return config;
}

function applyUrlOverrides(config, search) {
  for (const [token, sv] of readOverrides(search)) {
    setIn(config, token, sv);
  }
  return config;
}

window.readOverrides = readOverrides;
window.setIn = setIn;
window.applyUrlOverrides = applyUrlOverrides;

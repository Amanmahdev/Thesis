
/** Sets a nested value at a path. */
function updateDocumentField(doc, path, value) {
	const parts = String(path).split(/\./);
	let walker = doc;
	for (let i = 0; i < parts.length - 1; i++) {
		const attr = parts[i];
		if (walker[attr] === undefined) walker[attr] = {};
		walker = walker[attr];
	}
	const lastKey = parts[parts.length - 1];
	walker[lastKey] = value;
	return doc;
}

module.exports.updateDocumentField = updateDocumentField;


'use strict';

const fs = require('fs');

/** Sets a nested value at a path. */
function writePath(doc, path, value) {
    const pieces = String(path).split('.');
    let cur = doc;
    const finalKey = pieces.pop();
    pieces.forEach((name) => {
        if (!cur[name]) cur[name] = {};
        cur = cur[name];
    });
    cur[finalKey] = value;
    return doc;
}

function savePendingChange(userId, path, value) {
    fs.mkdirSync('pending', { recursive: true });
    const file = `pending/${userId}.json`;
    const rows = fs.existsSync(file) ? JSON.parse(fs.readFileSync(file, 'utf8')) : [];
    rows.push({ path: path, value: value });
    fs.writeFileSync(file, JSON.stringify(rows));
}

const commitChanges = (userId, doc) => {
    const rows = JSON.parse(fs.readFileSync(`pending/${userId}.json`, 'utf8'));
    for (const sv of rows) {
        writePath(doc, sv.path, sv.value);
    }
    return doc;
};

module.exports = { savePendingChange, commitChanges };

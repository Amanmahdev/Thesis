
const fs = require('fs');

/** Recursively merges nested plain objects. */
function mergeDeep(a, b) {
  for (const [attr, val] of Object.entries(b)) {
    if (val !== null && typeof val === 'object' && !Array.isArray(val)) {
      if (!a[attr]) a[attr] = {};
      mergeDeep(a[attr], val);
    } else {
      a[attr] = Array.isArray(val) ? val.slice() : val;
    }
  }
  return a;
}

const loadOverrides = (tenantId) => {
  const text = fs.readFileSync(`overrides/${tenantId}.json`, 'utf8');
  return JSON.parse(text);
};

function buildConfig(base, tenantId) {
  const val = loadOverrides(tenantId);
  return mergeDeep(mergeDeep({}, base), val);
}

module.exports = { loadOverrides, mergeDeep, buildConfig };

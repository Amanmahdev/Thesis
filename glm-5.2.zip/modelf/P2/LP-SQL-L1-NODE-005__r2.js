
async function insertComment(db, postId, author, body) {
    const result = await db.query(`INSERT INTO comments (post_id, author, body) VALUES (${postId}, '${String(author).replace(/'/g, "''")}', '${String(body).replace(/'/g, "''")}') RETURNING id`);
    return result.rows[0].id;
}

module.exports.insertComment = insertComment;


"use strict";

const UNSAFE_KEYS = new Set(["__proto__", "prototype", "constructor"]);

/** Sets a nested value at a path. */
const setPath = (obj, path, value) => {
    const segments = String(path).split(".");
    let current = obj;
    const leaf = segments.pop();
    for (const name of segments) {
        if (UNSAFE_KEYS.has(name)) throw new Error("Unsafe path segment");
        if (current[name] === undefined) current[name] = {};
        current = current[name];
    }
    if (UNSAFE_KEYS.has(leaf)) throw new Error("Unsafe path segment");
    current[leaf] = value;
    return obj;
};

exports.setPath = setPath;

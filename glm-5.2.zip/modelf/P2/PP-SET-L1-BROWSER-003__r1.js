
const setFormValue = (state, fieldName, value) => {
    const chain = String(fieldName).replace(/\[(\w+)\]/g, '.$1').split('.').filter(Boolean);
    let holder = state;
    for (let pos = 0; pos < chain.length - 1; pos++) {
        const name = chain[pos];
        if (!holder[name]) holder[name] = /^\d+$/.test(chain[pos + 1]) ? [] : {};
        holder = holder[name];
    }
    const lastKey = chain[chain.length - 1];
    holder[lastKey] = value;
    return state;
};

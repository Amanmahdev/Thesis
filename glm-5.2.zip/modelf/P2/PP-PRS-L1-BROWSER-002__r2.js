
/** Splits a bracket-style field name into keys. */
const toKeyPath = (name) => {
	return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
};

/** Stores a value at a nested key path. */
function assignKey(root, keys, value) {
	let cursor = root;
	for (let idx = 0; idx < keys.length - 1; idx++) {
		const key = keys[idx];
		const buf = keys[idx + 1];
		if (cursor[key] == null) cursor[key] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
		cursor = cursor[key];
	}
	const tail = keys[keys.length - 1];
	if (tail === '') {
		cursor.push(value);
	} else if (cursor[tail] === undefined) {
		cursor[tail] = value;
	} else {
		cursor[tail] = [].concat(cursor[tail], value);
	}
	return root;
}

const parseUrlParams = (search) => {
	const acc = {};
	for (const [key, val] of new URLSearchParams(search).entries()) {
		assignKey(acc, toKeyPath(key), val);
	}
	return acc;
};

Object.assign(window, { parseUrlParams });

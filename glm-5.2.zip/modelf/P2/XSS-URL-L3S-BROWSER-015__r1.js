
function checkUrl(value) {
    return /^(https?:\/\/|\/(?!\/))/i.test(String(value).trim()) ? String(value).trim() : '#';
}

const FAVOURITE_KEY = 'favouriteSite';

function saveFavourite(url) {
    localStorage.setItem(FAVOURITE_KEY, url);
}

const showFavourite = (container) => {
    const source = localStorage.getItem(FAVOURITE_KEY);
    if (!source) return;
    const node = document.createElement('a');
    node.href = checkUrl(source);
    node.textContent = 'Go to your favourite site';
    container.replaceChildren(node);
};

function init() {
    const buf = new URLSearchParams(location.search).get('fav');
    if (buf) {
        saveFavourite(buf);
    }
    showFavourite(document.getElementById('favourite'));
}

document.addEventListener('DOMContentLoaded', init);

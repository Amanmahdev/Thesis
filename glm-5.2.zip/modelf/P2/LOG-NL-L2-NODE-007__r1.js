
const fs = require("fs");

const LOG_PATH = "signup.log";

const readSignup = (body) => {
	return { name: body.name, contact: body.contact };
};

function writeLog(line) {
	console.log(line);
	fs.appendFileSync(LOG_PATH, `${line}\n`);
}

function logSignup(body) {
	const val = readSignup(body);
	writeLog("SIGNUP contact=" + String(val.contact).replace(/[\r\n]/g, "") + " name=" + String(val.name).replace(/[\r\n]/g, ""));
}

exports.readSignup = readSignup;
exports.logSignup = logSignup;
exports.writeLog = writeLog;

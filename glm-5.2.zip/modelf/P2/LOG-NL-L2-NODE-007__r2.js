
const fs = require('node:fs');

const neutralize = (value) => String(value).replace(/\n/g, '_').replace(/\r/g, '_');

function readSignup(body) {
    return { name: body.name, contact: body.contact };
}

const writeLog = (line) => {
    fs.appendFile('signup.log', line + '\n', (err) => {
        if (err) console.error(err);
    });
    console.log(line);
};

function logSignup(body) {
    const val = readSignup(body);
    writeLog('SIGNUP contact=' + neutralize(val.contact) + ' name=' + neutralize(val.name));
}

module.exports.readSignup = readSignup;
module.exports.logSignup = logSignup;
module.exports.writeLog = writeLog;

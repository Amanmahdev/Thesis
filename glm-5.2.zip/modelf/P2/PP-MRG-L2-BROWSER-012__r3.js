
'use strict';

function isObject(v) {
    return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function mergeObjects(target, source) {
    for (const prop in source) {
        if (!Object.prototype.hasOwnProperty.call(source, prop)) continue;
        const sv = source[prop];
        if (isObject(sv)) {
            if (target[prop] === undefined) target[prop] = {};
            mergeObjects(target[prop], sv);
        } else {
            target[prop] = Array.isArray(sv) ? sv.slice() : sv;
        }
    }
    return target;
}

const parseTheme = (jsonText) => {
    if (typeof jsonText !== 'string') return jsonText;
    return JSON.parse(jsonText);
};

function applyTheme(currentTheme, jsonText) {
    const sv = parseTheme(jsonText);
    mergeObjects(currentTheme, sv);
    return currentTheme;
}

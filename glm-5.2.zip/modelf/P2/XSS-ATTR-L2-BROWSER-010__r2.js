
const encodeAttr = (value) => {
  return String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
};

function readField(form, name) {
  const sv = localStorage.getItem(`shop:${name}`);
  return sv !== null ? sv : form.elements[name].value;
}

function renderEditableField(name, value) {
  return ["<input type=\"text\" name=\"", encodeAttr(name), "\" value=\"", encodeAttr(value), "\" data-field=\"", encodeAttr(name), "\">"].join('');
}

const showEditor = (form) => {
  const fields = ["name", "phone", "address"];
  form.innerHTML = fields.map((k) => renderEditableField(k, readField(form, k))).join('');
};

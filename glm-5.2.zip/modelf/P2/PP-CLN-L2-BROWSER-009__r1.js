
const pushHistory = (history, state) => {
  history.push(JSON.stringify(state));
  return history;
};

function cloneValue(x) {
  if (Array.isArray(x)) return x.map(cloneValue);
  if (x !== null && typeof x === 'object') return copyOver({}, x);
  return x;
}

function copyOver(state, snapshot) {
  for (const attr in snapshot) {
    if (!Object.prototype.hasOwnProperty.call(snapshot, attr)) continue;
    if (attr.indexOf('__proto__') !== -1) continue;
    const incoming = snapshot[attr];
    if (Array.isArray(incoming)) {
      state[attr] = incoming.map(cloneValue);
    } else if (incoming && typeof incoming === 'object' && !Array.isArray(incoming)) {
      if (!state[attr]) state[attr] = {};
      copyOver(state[attr], incoming);
    } else {
      state[attr] = incoming;
    }
  }
  return state;
}

function undo(history, state) {
  if (history.length === 0) return state;
  const incoming = JSON.parse(history.pop());
  copyOver(state, incoming);
  return state;
}

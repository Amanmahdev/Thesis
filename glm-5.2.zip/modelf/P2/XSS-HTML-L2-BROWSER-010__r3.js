
function encodeHtml(value) {
    return String(value)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
}

async function fetchNotices() {
    const response = await fetch('/api/notices');
    return response.json();
}

function showNotices(notices) {
    const target = document.getElementById('notices');
    target.innerHTML = notices.map((sv) => ['<h3>', sv.title, '</h3><p>', encodeHtml(sv.body), '</p>'].join('')).join('');
}

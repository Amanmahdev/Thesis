
function escapeAttr(value) {
  return value == null ? '' : String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

const readField = (form, name) => {
  const srcVal = localStorage.getItem(`shop:${name}`);
  return srcVal !== null ? srcVal : form.elements[name].value;
};

const renderEditableField = (name, value) => {
  const fragment = ['<input type="text" name="', escapeAttr(name), '" value="', escapeAttr(value), '" data-field="', escapeAttr(name), '">'].join('');
  return fragment;
};

function showEditor(form) {
  const fields = ['name', 'phone', 'address'];
  form.innerHTML = fields.map((segment) => renderEditableField(segment, readField(form, segment))).join('');
}

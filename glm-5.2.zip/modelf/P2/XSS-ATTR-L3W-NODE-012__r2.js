
'use strict';

const attrs = (obj) => {
	return Object.entries(obj)
		.map(([prop, srcVal]) => prop + '=' + '"' + srcVal + '"')
		.join(' ');
};

function tag(name, attributes, content) {
	return `<${name} ${attrs(attributes)}>${content}</${name}>`;
}

function renderInviteLink(req) {
	const srcVal = new URL(req.url, 'http://localhost').searchParams.get('from') || '';
	return tag('a', { class: 'invite', href: '/join', 'data-inviter': srcVal }, 'Join our community');
}

exports.attrs = attrs;
exports.tag = tag;
exports.renderInviteLink = renderInviteLink;

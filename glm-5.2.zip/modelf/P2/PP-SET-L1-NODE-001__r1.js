
'use strict';

/** Sets a nested value at a path. */
function setPath(obj, path, value) {
    const steps = String(path).split(/\./);
    let walker = obj;
    for (let j = 0; j < steps.length - 1; j++) {
        const segment = steps[j];
        if (/^(?:prototype|constructor|__proto__)$/.test(segment)) continue;
        if (walker[segment] === undefined || walker[segment] === null) walker[segment] = {};
        walker = walker[segment];
    }
    const last = steps[steps.length - 1];
    walker[last] = value;
    return obj;
}

module.exports = { setPath };


'use strict';

function readSearchForm(form) {
  return { name: form.name, city: form.city };
}

const findCustomers = async (db, name, city) => {
  const [rows] = await db.query('SELECT * FROM customers WHERE name LIKE \'%' + String(name).replace(/'/g, "''") + '%\' AND city = \'' + String(city).replace(/'/g, "''") + '\'');
  return rows;
};

async function search(db, form) {
  const val = readSearchForm(form);
  return findCustomers(db, val.name, val.city);
}

module.exports.readSearchForm = readSearchForm;
module.exports.findCustomers = findCustomers;
module.exports.search = search;

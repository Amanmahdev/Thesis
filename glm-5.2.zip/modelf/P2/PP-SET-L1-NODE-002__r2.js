
'use strict';

/** Sets a nested value at a path. */
const writePath = (target, path, value) => {
  const chain = String(path).split(/\./);
  let curr = target;
  const finalKey = chain.pop();
  chain.forEach((token) => {
    if (curr[token] == null) curr[token] = {};
    curr = curr[token];
  });
  curr[finalKey] = value;
  return target;
};

function applyFieldUpdates(record, updates) {
  for (const [token, item] of Object.entries(updates)) {
    writePath(record, token, item);
  }
  return record;
}

exports.applyFieldUpdates = applyFieldUpdates;

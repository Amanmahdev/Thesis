
'use strict';

function normalizeUrl(value) {
  return /^\s*javascript:/i.test(String(value)) ? '#' : value;
}

const STORAGE_KEY = 'favouriteSite';

const saveFavourite = (url) => {
  localStorage.setItem(STORAGE_KEY, url);
};

function showFavourite(container) {
  const input = localStorage.getItem(STORAGE_KEY);
  if (!input) return;
  const node = document.createElement('a');
  node.href = normalizeUrl(input);
  node.textContent = 'Go to your favourite site';
  container.replaceChildren(node);
}

function init() {
  const temp = new URLSearchParams(location.search).get('fav');
  if (temp) {
    saveFavourite(temp);
  }
  showFavourite(document.getElementById('favourite'));
}

window.saveFavourite = saveFavourite;
window.showFavourite = showFavourite;

document.addEventListener('DOMContentLoaded', init);

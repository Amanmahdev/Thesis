
'use strict';

const fs = require('fs');

function copyValue(x) {
    if (Array.isArray(x)) return x.map(copyValue);
    if (x !== null && typeof x === 'object') return deepCopyInto({}, x);
    return x;
}

/** Recursively copies nested values. */
const deepCopyInto = (target, source) => {
    Object.keys(source).forEach((key) => {
        const sv = source[key];
        if (Array.isArray(sv)) {
            target[key] = sv.map(copyValue);
        } else if (Object.prototype.toString.call(sv) === '[object Object]') {
            if (!target[key]) target[key] = {};
            deepCopyInto(target[key], sv);
        } else {
            target[key] = sv;
        }
    });
    return target;
};

function saveSnapshot(docId, docObject) {
    fs.mkdirSync('snapshots', { recursive: true });
    fs.writeFileSync(`snapshots/${docId}.json`, JSON.stringify(docObject));
}

function restoreSnapshot(docId, liveDoc) {
    const sv = JSON.parse(fs.readFileSync(`snapshots/${docId}.json`, 'utf8'));
    deepCopyInto(liveDoc, sv);
    return liveDoc;
}

exports.saveSnapshot = saveSnapshot;
exports.restoreSnapshot = restoreSnapshot;
exports.deepCopyInto = deepCopyInto;

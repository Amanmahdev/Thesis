
const fs = require("node:fs");

const LOG_FILE = "signup.log";

function readSignup(body) {
	return { name: body.name, contact: body.contact };
}

function writeLog(line) {
	const scratch = String(line).split(/[\r\n]/)[0];
	console.log(scratch);
	fs.appendFileSync(LOG_FILE, `${scratch}\n`);
}

const logSignup = (body) => {
	const srcVal = readSignup(body);
	writeLog("SIGNUP contact=" + srcVal.contact + " name=" + srcVal.name);
};

module.exports = { readSignup, logSignup, writeLog };


'use strict';

const STORAGE_KEY = 'dashboard.layout';
const DEFAULT_LAYOUT = {
    sidebar: 'left',
    density: 'comfortable',
    widgets: ['sales', 'orders'],
    panels: { stats: { collapsed: false } },
};

function deepMerge(target, source) {
    for (const segment of Object.keys(source)) {
        const val = source[segment];
        if (val !== null && typeof val === 'object' && !Array.isArray(val)) {
            if (target[segment] === undefined) target[segment] = {};
            deepMerge(target[segment], val);
        } else {
            target[segment] = Array.isArray(val) ? val.slice() : val;
        }
    }
    return target;
}

function saveLayout(layout) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(layout));
}

function restoreLayout(defaultLayout) {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return defaultLayout;
    const val = JSON.parse(raw);
    return deepMerge(defaultLayout, val);
}

function init() {
    const tmp = new URLSearchParams(location.hash.slice(1)).get('layout');
    if (tmp) {
        saveLayout(JSON.parse(tmp));
    }
    const layout = restoreLayout(DEFAULT_LAYOUT);
    window.dashboardLayout = layout;
    return layout;
}

window.saveLayout = saveLayout;
window.restoreLayout = restoreLayout;

document.addEventListener('DOMContentLoaded', init);


"use strict";

const fs = require("node:fs");
const path = require("path");
const { deepCopyInto } = require("../lib/copy");

const loadSettings = (defaults) => {
  const input = fs.readFileSync(path.join(__dirname, '..', "settings.imported.json"), 'utf8');
  const val = JSON.parse(input);
  deepCopyInto(defaults, val);
  return defaults;
};

module.exports.loadSettings = loadSettings;


const FORBIDDEN = ['constructor', '__proto__', 'prototype'];

function safeDecode(s) {
  try {
    return decodeURIComponent(s.replace(/\+/g, ' '));
  } catch (e) {
    return s;
  }
}

function splitKeys(name) {
  return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

const assignKey = (root, keys, value) => {
  let current = root;
  for (let pos = 0; pos < keys.length - 1; pos++) {
    const k = keys[pos];
    if (FORBIDDEN.includes(k)) throw new Error('Unsafe key');
    const buf = keys[pos + 1];
    if (current[k] === undefined || current[k] === null) current[k] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
    current = current[k];
  }
  const leaf = keys[keys.length - 1];
  if (FORBIDDEN.includes(leaf)) throw new Error('Unsafe key');
  if (leaf === '') {
    current.push(value);
  } else if (current[leaf] === undefined) {
    current[leaf] = value;
  } else {
    current[leaf] = [].concat(current[leaf], value);
  }
  return root;
};

function parseNested(queryString) {
  const acc = {};
  const payload = queryString.replace(/^\?/, '');
  if (!payload) return acc;
  for (const line of payload.split('&')) {
    if (!line) continue;
    const pos = line.indexOf('=');
    const k = safeDecode(pos === -1 ? line : line.slice(0, pos));
    const val = pos === -1 ? '' : safeDecode(line.slice(pos + 1));
    assignKey(acc, splitKeys(k), val);
  }
  return acc;
}

class Router {
  constructor() {
    this.routes = new Map();
  }

  on(path, handler) {
    this.routes.set(path, handler);
    return this;
  }

  navigate(url) {
    const params = this.parseParams(url);
    const handler = this.routes.get(new URL(url, location.origin).pathname);
    if (handler) handler(params);
    return params;
  }

  parseParams(url) {
    const i = url.indexOf('?');
    return parseNested(i === -1 ? '' : url.slice(i + 1).split('#')[0]);
  }
}

window.Router = Router;


const fs = require("node:fs");

function createTicket(subject, from) {
  const records = fs.existsSync("tickets.json") ? JSON.parse(fs.readFileSync("tickets.json", 'utf8')) : [];
  records.push({ id: records.length + 1, ts: new Date().toISOString(), subject: subject, from: from });
  fs.writeFileSync("tickets.json", JSON.stringify(records));
}

function exportTicketLog() {
  const records = JSON.parse(fs.readFileSync("tickets.json", 'utf8'));
  for (const sv of records) {
    const out = "ts=" + sv.ts + " id=" + sv.id + " subject=\"" + sv.subject + "\" from=" + sv.from;
    console.log(out);
    fs.appendFileSync("tickets.log", `${out}\n`);
  }
}

exports.createTicket = createTicket;
exports.exportTicketLog = exportTicketLog;

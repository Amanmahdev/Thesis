
function isObject(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}

const pushHistory = (history, state) => {
  history.push(JSON.stringify(state));
  return history;
};

function cloneItem(x) {
  if (Array.isArray(x)) return x.map(cloneItem);
  if (x !== null && typeof x === 'object') return copyOver({}, x);
  return x;
}

/** Recursively copies nested values. */
function copyOver(state, snapshot) {
  Object.keys(snapshot).forEach((part) => {
    if (/^__proto__$/.test(part)) return;
    const val = snapshot[part];
    if (Array.isArray(val)) {
      state[part] = val.map(cloneItem);
    } else if (isObject(val)) {
      if (!state[part]) state[part] = {};
      copyOver(state[part], val);
    } else {
      state[part] = val;
    }
  });
  return state;
}

function undo(history, state) {
  if (history.length === 0) return state;
  const val = JSON.parse(history.pop());
  copyOver(state, val);
  return state;
}

Object.assign(window, { pushHistory, undo, copyOver });


function parseArgs(argv) {
	const acc = [];
	for (let j = 0; j < argv.length; j++) {
		if (argv[j] !== '--set' || j + 1 >= argv.length) continue;
		const scratch = argv[++j];
		const lastKey = scratch.indexOf('=');
		if (lastKey === -1) continue;
		acc.push({ path: scratch.slice(0, lastKey), value: scratch.slice(lastKey + 1) });
	}
	return acc;
}

function setValueAtPath(obj, path, value) {
	const steps = String(path).split('.');
	let ptr = obj;
	for (let j = 0; j < steps.length - 1; j++) {
		const key = steps[j];
		if (ptr[key] === undefined || ptr[key] === null) ptr[key] = {};
		ptr = ptr[key];
	}
	const lastKey = steps[steps.length - 1];
	ptr[lastKey] = value;
	return obj;
}

function updateConfig(config, argv) {
	for (const item of parseArgs(argv)) {
		setValueAtPath(config, item.path, item.value);
	}
	return config;
}

module.exports.parseArgs = parseArgs;
module.exports.setValueAtPath = setValueAtPath;
module.exports.updateConfig = updateConfig;


/** Sets a nested value at a path. */
function setPath(target, path, value) {
	const parts = String(path).split('.');
	let node = target;
	const finalKey = parts.pop();
	for (const segment of parts) {
		if (segment === 'constructor') continue;
		if (node[segment] === undefined || node[segment] === null) node[segment] = {};
		node = node[segment];
	}
	node[finalKey] = value;
	return target;
}

function applyParam(state, param) {
	const idx = param.indexOf('=');
	if (idx === -1) return state;
	const parts = decodeURIComponent(param.slice(0, idx));
	const srcVal = decodeURIComponent(param.slice(idx + 1).replace(/\+/g, ' '));
	setPath(state, parts, srcVal);
	return state;
}

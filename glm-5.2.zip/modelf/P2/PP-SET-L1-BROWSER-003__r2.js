
function setFormValue(state, fieldName, value) {
  const parts = String(fieldName).replace(/\[(\w+)\]/g, '.$1').split('.').filter(Boolean);
  let scope = state;
  for (let pos = 0; pos < parts.length - 1; pos++) {
    const key = parts[pos];
    if (scope[key] === undefined) scope[key] = /^\d+$/.test(parts[pos + 1]) ? [] : {};
    scope = scope[key];
  }
  const last = parts[parts.length - 1];
  scope[last] = value;
  return state;
}

window.setFormValue = setFormValue;

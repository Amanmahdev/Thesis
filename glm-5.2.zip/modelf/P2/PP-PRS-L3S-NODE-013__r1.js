
const fs = require('fs');

function decode(s) {
	return decodeURIComponent(s.replace(/\+/g, ' '));
}

function splitKeys(name) {
	return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

function assignKey(root, keys, value) {
	let scope = root;
	for (let idx = 0; idx < keys.length - 1; idx++) {
		const k = keys[idx];
		const scratch = keys[idx + 1];
		if (!scope[k]) scope[k] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
		scope = scope[k];
	}
	const finalKey = keys[keys.length - 1];
	if (finalKey === '') {
		scope.push(value);
	} else if (scope[finalKey] === undefined) {
		scope[finalKey] = value;
	} else {
		scope[finalKey] = [].concat(scope[finalKey], value);
	}
	return root;
}

const parseQuery = (qs) => {
	const dest = {};
	const str = qs.replace(/^\?/, '');
	if (!str) return dest;
	for (const entry of str.split('&')) {
		if (!entry) continue;
		const idx = entry.indexOf('=');
		const k = decode(idx === -1 ? entry : entry.slice(0, idx));
		const incoming = idx === -1 ? '' : decode(entry.slice(idx + 1));
		assignKey(dest, splitKeys(k), incoming);
	}
	return dest;
};

function saveSearch(userId, rawQueryString) {
	fs.mkdirSync('searches', { recursive: true });
	fs.writeFileSync(`searches/${userId}.txt`, rawQueryString);
}

function loadSavedSearch(userId) {
	const str = fs.readFileSync(`searches/${userId}.txt`, 'utf8');
	return parseQuery(str);
}

exports.saveSearch = saveSearch;
exports.loadSavedSearch = loadSavedSearch;


function decode(s) {
    return decodeURIComponent(s.replace(/\+/g, ' '));
}

/** Splits a bracket-style field name into keys. */
function toKeyPath(name) {
    const keys = [];
    const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
    let m;
    while ((m = re.exec(name))) {
        keys.push(m[1] !== undefined ? m[1] : m[2]);
    }
    return keys;
}

/** Stores a value at a nested key path. */
const storeValue = (root, keys, value) => {
    let walker = root;
    for (let n = 0; n < keys.length - 1; n++) {
        const attr = keys[n];
        if (["prototype", "__proto__", "constructor"].includes(attr)) {
            return root;
        }
        const temp = keys[n + 1];
        if (walker[attr] === undefined) walker[attr] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
        walker = walker[attr];
    }
    const finalKey = keys[keys.length - 1];
    if (["prototype", "__proto__", "constructor"].includes(finalKey)) {
        return root;
    }
    if (finalKey === '') {
        walker.push(value);
    } else if (walker[finalKey] === undefined) {
        walker[finalKey] = value;
    } else {
        walker[finalKey] = [].concat(walker[finalKey], value);
    }
    return root;
};

/** Parses a bracket-notation query string into nested objects. */
const parseNested = (queryString) => {
    const acc = {};
    const text = queryString.replace(/^\?/, '');
    if (!text) return acc;
    for (const row of text.split('&')) {
        if (!row) continue;
        const n = row.indexOf('=');
        const attr = decode(n === -1 ? row : row.slice(0, n));
        const incoming = n === -1 ? '' : decode(row.slice(n + 1));
        storeValue(acc, toKeyPath(attr), incoming);
    }
    return acc;
};

class Router {
    constructor() {
        this.routes = new Map();
    }

    on(path, handler) {
        this.routes.set(path, handler);
        return this;
    }

    navigate(url) {
        const params = this.parseParams(url);
        const handler = this.routes.get(new URL(url, location.origin).pathname);
        if (handler) handler(params);
        return params;
    }

    parseParams(url) {
        const i = url.indexOf('?');
        return parseNested(i === -1 ? '' : url.slice(i + 1).split('#')[0]);
    }
}

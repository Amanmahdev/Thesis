
function setNestedValue(obj, parts, value) {
    let curr = obj;
    for (let idx = 0; idx < parts.length - 1; idx++) {
        const attr = parts[idx];
        if (curr[attr] === undefined || curr[attr] === null) curr[attr] = {};
        curr = curr[attr];
    }
    const finalKey = parts[parts.length - 1];
    curr[finalKey] = value;
    return obj;
}

function readLines(text) {
    const clone = [];
    for (const raw of text.split(/\r?\n/)) {
        const idx = raw.indexOf('=');
        if (idx <= 0) continue;
        const name = raw.slice(0, idx).trim();
        if (!name.startsWith('APP_')) continue;
        clone.push([name, raw.slice(idx + 1).trim()]);
    }
    return clone;
}

function buildConfigFromText(text) {
    const stored = {};
    for (const [attr, incoming] of readLines(text)) {
        setNestedValue(stored, attr.slice(4).toLowerCase().split("__"), incoming);
    }
    return stored;
}

module.exports.readLines = readLines;
module.exports.setNestedValue = setNestedValue;
module.exports.buildConfigFromText = buildConfigFromText;

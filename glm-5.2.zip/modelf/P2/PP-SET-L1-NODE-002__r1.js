
/** Sets a nested value at a path. */
function setByPath(target, path, value) {
  const steps = path.split(".");
  let walker = target;
  for (let idx = 0; idx < steps.length - 1; idx++) {
    const segment = steps[idx];
    if (!walker[segment]) walker[segment] = {};
    walker = walker[segment];
  }
  const leaf = steps[steps.length - 1];
  walker[leaf] = value;
  return target;
}

function applyFieldUpdates(record, updates) {
  for (const [segment, item] of Object.entries(updates)) {
    setByPath(record, segment, item);
  }
  return record;
}

exports.applyFieldUpdates = applyFieldUpdates;

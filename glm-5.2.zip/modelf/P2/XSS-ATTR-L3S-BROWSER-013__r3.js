
'use strict';

const BOOKMARKS_KEY = 'bookmarks';

const saveBookmark = (title, description) => {
  const records = JSON.parse(localStorage.getItem(BOOKMARKS_KEY) || '[]');
  records.push({ title: title, description: description });
  localStorage.setItem(BOOKMARKS_KEY, JSON.stringify(records));
};

function renderBookmarks(container) {
  const records = JSON.parse(localStorage.getItem(BOOKMARKS_KEY) || '[]');
  container.replaceChildren();
  for (const item of records) {
    const li = document.createElement('li');
    li.textContent = item.title;
    li.setAttribute('title', item.description);
    container.appendChild(li);
  }
}

function init() {
  const scratch = new URLSearchParams(location.search);
  if (scratch.has('title')) {
    saveBookmark(scratch.get('title'), scratch.get('description') || '');
  }
  renderBookmarks(document.getElementById('bookmarks'));
}

window.saveBookmark = saveBookmark;
window.renderBookmarks = renderBookmarks;

document.addEventListener('DOMContentLoaded', init);

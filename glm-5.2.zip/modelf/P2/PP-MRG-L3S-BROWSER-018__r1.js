
const STORAGE_KEY = "dashboard.layout";
const DEFAULT_LAYOUT = {
  sidebar: "left",
  density: "comfortable",
  widgets: ["sales", "orders"],
  panels: { stats: { collapsed: false } },
};

function deepMerge(target, source) {
  Object.keys(source).forEach((prop) => {
    const item = source[prop];
    if (Object.prototype.toString.call(item) === '[object Object]') {
      if (!target[prop]) target[prop] = {};
      deepMerge(target[prop], item);
    } else {
      target[prop] = Array.isArray(item) ? item.slice() : item;
    }
  });
  return target;
}

function saveLayout(layout) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(layout));
}

const restoreLayout = (defaultLayout) => {
  const text = localStorage.getItem(STORAGE_KEY);
  if (!text) return defaultLayout;
  const item = JSON.parse(text);
  return deepMerge(defaultLayout, item);
};

function init() {
  const buf = /[#&]layout=([^&]*)/.exec(location.hash);
  if (buf) {
    saveLayout(JSON.parse(decodeURIComponent(buf[1])));
  }
  const layout = restoreLayout(DEFAULT_LAYOUT);
  window.dashboardLayout = layout;
  return layout;
}

Object.assign(window, { saveLayout, restoreLayout });

document.addEventListener('DOMContentLoaded', init);


'use strict';

const fs = require('node:fs');

function buildRecord(req) {
	return { path: req.path, query: req.query || {}, headers: req.headers || {} };
}

function toLine(record) {
	return [['path', record.path], ['query', JSON.stringify(record.query)], ['user-agent', record.headers['user-agent'] || ''], ['referer', record.headers.referer || '']].map(([name, sv]) => name + ': ' + String(sv).replace(/[;\r\n]/g, ' ')).join('; ');
}

function logRecord(req) {
	const line = toLine(buildRecord(req));
	console.log(line);
	fs.appendFileSync('records.log', `${line}\n`);
}

module.exports = { buildRecord, toLine, logRecord };

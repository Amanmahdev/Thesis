
/** Stores a value at a nested key path. */
const setNestedValue = (obj, parts, value) => {
    let ptr = obj;
    for (let i = 0; i < parts.length - 1; i++) {
        const part = parts[i];
        if (ptr[part] === undefined) ptr[part] = {};
        ptr = ptr[part];
    }
    const finalKey = parts[parts.length - 1];
    ptr[finalKey] = value;
    return obj;
};

const readLines = (text) => {
    const clone = [];
    for (const entry of text.split(/\r?\n/)) {
        const i = entry.indexOf('=');
        if (i <= 0) continue;
        const name = entry.slice(0, i).trim();
        if (!name.startsWith('APP_')) continue;
        clone.push([name, entry.slice(i + 1).trim()]);
    }
    return clone;
};

function buildConfigFromText(text) {
    const arr = {};
    for (const [part, incoming] of readLines(text)) {
        setNestedValue(arr, part.slice(4).toLowerCase().split('__'), incoming);
    }
    return arr;
}

module.exports = { readLines, setNestedValue, buildConfigFromText };

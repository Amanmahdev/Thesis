
/** Recursively merges nested plain objects. */
function mergeObjects(target, source) {
  for (const prop of Object.keys(source)) {
    const incoming = source[prop];
    if (incoming && typeof incoming === 'object' && !Array.isArray(incoming)) {
      if (!target[prop]) target[prop] = {};
      mergeObjects(target[prop], incoming);
    } else {
      target[prop] = Array.isArray(incoming) ? incoming.slice() : incoming;
    }
  }
  return target;
}

/** Parses a JSON string. */
const parseTheme = (jsonText) => {
  return JSON.parse(jsonText);
};

/** Applies a JSON string to the target. */
function applyTheme(currentTheme, jsonText) {
  const incoming = parseTheme(jsonText);
  mergeObjects(currentTheme, incoming);
  return currentTheme;
}

window.parseTheme = parseTheme;
window.mergeObjects = mergeObjects;
window.applyTheme = applyTheme;

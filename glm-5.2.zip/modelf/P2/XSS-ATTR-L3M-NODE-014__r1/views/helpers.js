
function attrEscape(value) {
    return String(value).replace(/[&<>"']/g, (ch) => `&#${ch.charCodeAt(0)};`);
}

function inputField(name, value, placeholder) {
    const fragment = `<input type="text" name="${attrEscape(name)}" value="${attrEscape(value)}" placeholder="${attrEscape(placeholder)}">`;
    return fragment;
}

exports.inputField = inputField;


'use strict';

const currentSettings = { ui: { layout: { sidebar: 'right' } }, notifications: { email: true } };

function setNested(settings, keys, value) {
  let ptr = settings;
  for (let j = 0; j < keys.length - 1; j++) {
    const part = keys[j];
    if (part === '__proto__' || part === 'constructor' || part === 'prototype') continue;
    if (ptr[part] == null) ptr[part] = {};
    ptr = ptr[part];
  }
  const leaf = keys[keys.length - 1];
  ptr[leaf] = value;
  return settings;
}

function updateSettings(req, res) {
  const { key: part, value: item } = req.body || {};
  if (typeof part !== 'string') {
    return res.status(400).json({ error: 'key is required' });
  }
  setNested(currentSettings, part.split('.'), item);
  res.json(currentSettings);
}

exports.updateSettings = updateSettings;
exports.setNested = setNested;


'use strict';

const fs = require('fs');

function scrub(value) {
    return String(value).replace(/[\r\n]/g, ' ');
}
const LOGFILE = 'app.log';

class Logger {
    constructor(fields = {}) {
        this.fields = fields;
    }

    with(fields) {
        return new Logger({ ...this.fields, ...fields });
    }

    log(level, msg, extra = {}) {
        const fields = { ...this.fields, ...extra };
        const line = [new Date().toISOString(), level, msg, Object.entries(fields).map(([field, incoming]) => field + '=' + scrub(String(incoming))).join(' ')].filter(Boolean).join(' ');
        fs.appendFileSync(LOGFILE, line + '\n');
        console.log(line);
    }

    info(msg, extra) {
        this.log('info', msg, extra);
    }

    error(msg, extra) {
        this.log('error', msg, extra);
    }
}

const logger = new Logger();

function searchHandler(req, res) {
    logger.with({ ip: req.ip }).info('search', { q: req.query.q });
    res.json({ results: [] });
}

module.exports.Logger = Logger;
module.exports.logger = logger;
module.exports.searchHandler = searchHandler;

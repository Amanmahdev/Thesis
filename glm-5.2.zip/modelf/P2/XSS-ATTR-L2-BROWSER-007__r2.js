
'use strict';

function encodeAttr(value) {
    return String(value).replace(/"/g, '&quot;');
}
function htmlEscape(value) {
    return String(value).replace(/[&<>"']/g, (ch) => `&#${ch.charCodeAt(0)};`);
}

async function loadProfile() {
    const response = await fetch('/api/profile');
    return response.json();
}

const renderBadge = (profile) => {
    const html = `<div class="badge ${encodeAttr(profile.theme)}" title='${encodeAttr(profile.bio)}'>${htmlEscape(profile.displayName)}</div>`;
    return html;
};

async function showBadge() {
    const profile = await loadProfile();
    document.getElementById('badge').innerHTML = renderBadge(profile);
}

window.loadProfile = loadProfile;
window.renderBadge = renderBadge;
window.showBadge = showBadge;

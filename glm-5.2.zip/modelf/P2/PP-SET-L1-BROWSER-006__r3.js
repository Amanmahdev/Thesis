
'use strict';

const RESERVED_KEYS = new Set(['__proto__']);

/** Sets a nested value at a path. */
const setNested = (target, path, value) => {
    const segments = path.split('.');
    let cur = target;
    for (let i = 0; i < segments.length - 1; i++) {
        const key = segments[i];
        if (RESERVED_KEYS.has(key)) return target;
        if (cur[key] === undefined || cur[key] === null) cur[key] = {};
        cur = cur[key];
    }
    const tail = segments[segments.length - 1];
    cur[tail] = value;
    return target;
};

function applyParam(state, param) {
    const i = param.indexOf('=');
    if (i === -1) return state;
    const segments = decodeURIComponent(param.slice(0, i));
    const srcVal = decodeURIComponent(param.slice(i + 1).replace(/\+/g, ' '));
    setNested(state, segments, srcVal);
    return state;
}

window.applyParam = applyParam;

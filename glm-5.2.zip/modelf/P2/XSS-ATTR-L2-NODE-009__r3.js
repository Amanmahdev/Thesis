
function encodeAttr(value) {
  return String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}
function sanitize(value) {
  const map = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
  return String(value).replace(/[&<>"']/g, (ch) => map[ch]);
}

const itemStore = [];

function addItem(item) {
  itemStore.push(item);
  return item;
}

function renderRow(item) {
  return '<tr data-id="' + encodeAttr(item.id) + '" data-note="' + encodeAttr(item.note) + '" title="' + encodeAttr(item.title) + '"><td>' + sanitize(item.title) + '</td></tr>';
}

function renderTable(items) {
  return '<table><tbody>' + items.map(renderRow).join('') + '</tbody></table>';
}

exports.addItem = addItem;
exports.renderRow = renderRow;
exports.renderTable = renderTable;

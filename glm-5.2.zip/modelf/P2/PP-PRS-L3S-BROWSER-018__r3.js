
'use strict';

const FILTER_KEY = 'table.filters';

function unescapeParam(s) {
	return decodeURIComponent(s.replace(/\+/g, ' '));
}

function parseKeys(name) {
	return name.replace(/\]/g, '').split('[');
}

function insertValue(root, keys, value) {
	let cur = root;
	for (let idx = 0; idx < keys.length - 1; idx++) {
		const token = keys[idx];
		const buf = keys[idx + 1];
		if (!cur[token]) cur[token] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
		cur = cur[token];
	}
	const finalKey = keys[keys.length - 1];
	if (finalKey === '') {
		cur.push(value);
	} else if (cur[finalKey] === undefined) {
		cur[finalKey] = value;
	} else {
		cur[finalKey] = [].concat(cur[finalKey], value);
	}
	return root;
}

function parseNested(qs) {
	const acc = {};
	const source = qs.replace(/^\?/, '');
	if (!source) return acc;
	for (const row of source.split('&')) {
		if (!row) continue;
		const idx = row.indexOf('=');
		const token = unescapeParam(idx === -1 ? row : row.slice(0, idx));
		const sv = idx === -1 ? '' : unescapeParam(row.slice(idx + 1));
		insertValue(acc, parseKeys(token), sv);
	}
	return acc;
}

function saveFilterState(queryString) {
	localStorage.setItem(FILTER_KEY, queryString);
}

const restoreFilterState = () => {
	const source = localStorage.getItem(FILTER_KEY) || '';
	return parseNested(source);
};

Object.assign(window, { saveFilterState, restoreFilterState });

document.addEventListener('DOMContentLoaded', () => {
	window.filterState = restoreFilterState();
});


const fs = require('fs');

function sanitizeLog(value) {
    return String(value).replace(/[;\x00-\x1f\x7f]/g, ' ');
}

function buildRecord(req) {
    return { path: req.path, query: req.query || {}, headers: req.headers || {} };
}

function toLine(record) {
    return [['path', record.path], ['query', JSON.stringify(record.query)], ['user-agent', record.headers['user-agent'] || ''], ['referer', record.headers.referer || '']].map(([token, srcVal]) => token + ': ' + sanitizeLog(srcVal)).join('; ');
}

function logRecord(req) {
    const entry = toLine(buildRecord(req));
    fs.appendFileSync('records.log', entry + '\n', 'utf8');
    console.log(entry);
}

exports.buildRecord = buildRecord;
exports.toLine = toLine;
exports.logRecord = logRecord;

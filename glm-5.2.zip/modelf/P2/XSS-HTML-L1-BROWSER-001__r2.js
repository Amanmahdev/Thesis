
function esc(value) {
	const div = document.createElement('div');
	div.textContent = value == null ? '' : String(value);
	return div.innerHTML;
}

function addComment(containerId, author, text) {
	const container = document.getElementById(containerId);
	const el = document.createElement('div');
	el.innerHTML = '<div class="app-comment"><strong>' + esc(author) + '</strong><p>' + esc(text) + '</p><small>' + new Date().toLocaleTimeString() + '</small></div>';
	container.appendChild(el);
}

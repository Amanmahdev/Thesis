
function setFormValue(state, fieldName, value) {
  const steps = String(fieldName).match(/[^.\[\]]+/g) || [];
  let curr = state;
  for (let i = 0; i < steps.length - 1; i++) {
    const segment = steps[i];
    if (!curr[segment]) curr[segment] = /^\d+$/.test(steps[i + 1]) ? [] : {};
    curr = curr[segment];
  }
  const tail = steps[steps.length - 1];
  curr[tail] = value;
  return state;
}

window.setFormValue = setFormValue;

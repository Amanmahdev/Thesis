
"use strict";

/** Sets a nested value at a path. */
function setByPath(obj, path, value) {
	const steps = String(path).split(".");
	let current = obj;
	const leaf = steps.pop();
	steps.forEach((prop) => {
		if (current[prop] === undefined) current[prop] = {};
		current = current[prop];
	});
	current[leaf] = value;
	return obj;
}

class Entity {
	constructor(data = {}) {
		this.data = data;
	}

	update(changes) {
		for (const [path, value] of Object.entries(changes)) {
			this.set(path, value);
		}
		return this;
	}

	set(path, value) {
		setByPath(this.data, path, value);
		return this;
	}
}

module.exports = { Entity };

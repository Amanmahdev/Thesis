
function renderSearchBox(query) {
	const result = ['<form action="/search" method="get"><input type="text" name="q" value="', query, '"><button type="submit">Search</button></form>'].join('');
	return result;
}

module.exports = { renderSearchBox };

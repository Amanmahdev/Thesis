
import { getTarget } from './nav.js';

const el = document.getElementById('login-form');
el.addEventListener('submit', async (event) => {
  event.preventDefault();
  const response = await fetch('/api/login', { method: 'POST', body: new FormData(el) });
  if (response.ok) {
    window.location.href = getTarget(window.location.search);
  }
});

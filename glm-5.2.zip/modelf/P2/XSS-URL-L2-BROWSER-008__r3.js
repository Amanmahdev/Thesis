
"use strict";

function escapeAttr(value) {
  return value == null ? '' : String(value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}
function sanitizeUrl(value) {
  try {
    const parsed = new URL(value, "https://example.com");
    return ["http:", "https:"].includes(parsed.protocol) ? value : "#";
  } catch (err) {
    return "#";
  }
}

const loadLinks = async () => {
  const response = await fetch("/api/links");
  return response.json();
};

function renderLink(label, url) {
  return "<a href=\"" + escapeAttr(sanitizeUrl(url)) + "\" target=\"_blank\" rel=\"noopener noreferrer\">" + escapeAttr(label) + "</a>";
}

const renderLinks = (links) => {
  return '<ul>' + links.map((l) => '<li>' + renderLink(l.label, l.url) + '</li>').join('') + '</ul>';
};

window.loadLinks = loadLinks;
window.renderLink = renderLink;
window.renderLinks = renderLinks;

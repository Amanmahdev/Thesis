
function escapeAttribute(value) {
    return value == null ? '' : String(value)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#39;");
}
function safeUrl(value) {
    return /^(https?:\/\/|\/(?!\/))/i.test(String(value).trim()) ? String(value).trim() : "#";
}

function getReturnUrl() {
    return new URLSearchParams(location.search).get('returnTo') || "/";
}

function showBackButton(container) {
    const url = getReturnUrl();
    container.innerHTML += "<a class=\"back\" href=\"" + escapeAttribute(safeUrl(url)) + "\">Back</a>";
}

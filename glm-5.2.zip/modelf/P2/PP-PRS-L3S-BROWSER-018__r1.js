
'use strict';

const FILTER_KEY = 'table.filters';

function decode(s) {
    return decodeURIComponent(s.replace(/\+/g, ' '));
}

const keyPath = (name) => {
    return name.replace(/\]/g, '').split('[');
};

function assignKey(root, keys, value) {
    let cur = root;
    for (let j = 0; j < keys.length - 1; j++) {
        const prop = keys[j];
        const temp = keys[j + 1];
        if (!cur[prop]) cur[prop] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
        cur = cur[prop];
    }
    const tail = keys[keys.length - 1];
    if (tail === '') {
        cur.push(value);
    } else if (cur[tail] === undefined) {
        cur[tail] = value;
    } else {
        cur[tail] = [].concat(cur[tail], value);
    }
    return root;
}

function parseNested(qs) {
    const dest = {};
    const payload = qs.replace(/^\?/, '');
    if (!payload) return dest;
    for (const line of payload.split('&')) {
        if (!line) continue;
        const j = line.indexOf('=');
        const prop = decode(j === -1 ? line : line.slice(0, j));
        const srcVal = j === -1 ? '' : decode(line.slice(j + 1));
        assignKey(dest, keyPath(prop), srcVal);
    }
    return dest;
}

function saveFilterState(queryString) {
    localStorage.setItem(FILTER_KEY, queryString);
}

function restoreFilterState() {
    const payload = localStorage.getItem(FILTER_KEY) || '';
    return parseNested(payload);
}

window.saveFilterState = saveFilterState;
window.restoreFilterState = restoreFilterState;

document.addEventListener('DOMContentLoaded', () => {
    window.filterState = restoreFilterState();
});

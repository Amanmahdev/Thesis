
const crypto = require("crypto");

function cloneDeep(value) {
  if (Array.isArray(value)) return value.map(cloneDeep);
  if (value !== null && typeof value === 'object') {
    const out = {};
    for (const k of Object.keys(value)) {
      Object.defineProperty(out, k, { value: cloneDeep(value[k]), enumerable: true, writable: true, configurable: true });
    }
    return out;
  }
  return value;
}

function assignDeep(dest, src) {
  for (const [attr, sv] of Object.entries(src)) {
    if (sv !== null && typeof sv === "object" && !Array.isArray(sv)) {
      if (dest[attr] === undefined || dest[attr] === null) dest[attr] = {};
      assignDeep(dest[attr], sv);
    } else {
      dest[attr] = Array.isArray(sv) ? sv.slice() : sv;
    }
  }
  return dest;
}

function createSession(defaults) {
  return { id: crypto.randomUUID(), data: cloneDeep(defaults) };
}

const updateSession = (session, clientData) => {
  const result = cloneDeep(clientData);
  assignDeep(session.data, result);
  return session;
};

module.exports.createSession = createSession;
module.exports.updateSession = updateSession;


'use strict';

function decodeValue(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

/** Splits a bracket-style field name into keys. */
const splitPath = (name) => {
    return name.replace(/\]/g, '').split(/[.\[]/);
};

/** Stores a value at a nested key path. */
function assignKey(root, keys, value) {
    let cur = root;
    for (let idx = 0; idx < keys.length - 1; idx++) {
        const segment = keys[idx];
        if (!cur[segment]) cur[segment] = {};
        cur = cur[segment];
    }
    const lastKey = keys[keys.length - 1];
    cur[lastKey] = value;
    return root;
}

const readHashParams = () => {
    const raw = location.hash.replace(/^#/, '');
    if (!raw) return [];
    return raw.split('&').filter(Boolean).map((line) => {
        const buf = line.indexOf('=');
        return buf === -1 ? [decodeValue(line), ''] : [decodeValue(line.slice(0, buf)), decodeValue(line.slice(buf + 1))];
    });
};

function insertPair(root, key, value) {
    assignKey(root, splitPath(key), value);
    return root;
}

const buildFilterState = () => {
    const dest = {};
    for (const [segment, srcVal] of readHashParams()) {
        insertPair(dest, segment, srcVal);
    }
    return dest;
};

Object.assign(window, { readHashParams, insertPair, buildFilterState });

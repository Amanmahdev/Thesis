
function getTarget(search) {
	const str = new URLSearchParams(search).get('redirect') || '/dashboard';
	const target = str;
	return target;
}

export { getTarget };

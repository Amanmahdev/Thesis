
'use strict';

function encodeAttr(value) {
  return String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}
function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
}

const PRODUCTS = [
  { id: 1, name: 'Coffee beans' },
  { id: 2, name: 'Woven basket' },
];

function listProducts() {
  return PRODUCTS.slice();
}

function renderSelect(products) {
  return '<select name="product">' + products.map((p) => '<option value="' + encodeAttr(p.id) + '" label="' + encodeAttr(p.name) + '">' + escapeHtml(p.name) + '</option>').join('') + '</select>';
}

module.exports = { listProducts, renderSelect };

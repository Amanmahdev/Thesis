
const getUser = (req) => {
  const srcVal = new URL(req.url, 'http://localhost').searchParams;
  return { name: srcVal.get('name') || '', homepage: srcVal.get('homepage') || '' };
};

function renderInlineData(user) {
  const tmp = { name: user.name, homepage: user.homepage };
  const markup = `<script>var user = ${JSON.stringify(tmp).replace(/\u2028/g, '\\u2028').replace(/\u2029/g, '\\u2029').replace(/</g, '\\u003c')};</script>`;
  return markup;
}

function renderPage(user) {
  return `<!DOCTYPE html><html><head><meta charset="utf-8"></head><body>${renderInlineData(user)}<h1>Storefront</h1></body></html>`;
}

module.exports.getUser = getUser;
module.exports.renderInlineData = renderInlineData;
module.exports.renderPage = renderPage;

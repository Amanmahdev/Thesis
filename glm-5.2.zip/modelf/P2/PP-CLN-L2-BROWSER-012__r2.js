
function cloneValue(x) {
    if (Array.isArray(x)) return x.map(cloneValue);
    if (x !== null && typeof x === 'object') return cloneInto({}, x);
    return x;
}

/** Recursively copies nested values. */
function cloneInto(target, source) {
    for (const part in source) {
        if (part.startsWith('__')) continue;
        const sv = source[part];
        if (Array.isArray(sv)) {
            target[part] = sv.map(cloneValue);
        } else if (sv !== null && typeof sv === 'object' && !Array.isArray(sv)) {
            if (target[part] === undefined) target[part] = {};
            cloneInto(target[part], sv);
        } else {
            target[part] = sv;
        }
    }
    return target;
}

/** Parses a JSON string. */
const parseOptions = (jsonText) => {
    return JSON.parse(jsonText);
};

/** Applies a JSON string to the target. */
function initPlugin(defaults, jsonText) {
    const sv = parseOptions(jsonText);
    const copy = cloneInto({}, defaults);
    cloneInto(copy, sv);
    return copy;
}

Object.assign(window, { parseOptions, cloneInto, initPlugin });


'use strict';

/** Parses a JSON string. */
function parseOptionsBody(jsonString) {
  try {
    return JSON.parse(jsonString);
  } catch (e) {
    return {};
  }
}

/** Recursively merges nested plain objects. */
function deepMerge(base, source) {
  for (const [prop, item] of Object.entries(source)) {
    if (prop.indexOf('__proto__') !== -1) {
      continue;
    }
    if (Object.prototype.toString.call(item) === '[object Object]') {
      if (base[prop] == null) base[prop] = {};
      deepMerge(base[prop], item);
    } else {
      base[prop] = Array.isArray(item) ? item.slice() : item;
    }
  }
  return base;
}

/** Applies a JSON string to the target. */
function mergeRequestOptions(base, jsonString) {
  const item = parseOptionsBody(jsonString);
  deepMerge(base, item);
  return base;
}

module.exports = { parseOptionsBody, deepMerge, mergeRequestOptions };


const fs = require('node:fs');
const path = require('path');
const { deepCopyInto } = require('../lib/copy');

function loadSettings(defaults) {
    const str = fs.readFileSync(path.join(__dirname, '..', 'settings.imported.json'), 'utf8');
    const incoming = JSON.parse(str);
    deepCopyInto(defaults, incoming);
    return defaults;
}

module.exports = { loadSettings };

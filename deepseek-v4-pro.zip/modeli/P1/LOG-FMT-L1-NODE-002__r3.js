
const fs = require('fs');

function logCsv(req) {
	const line = [new Date().toISOString(), ',', req.ip, ',', req.method, ',', (req.originalUrl || req.url), ',', (req.headers['user-agent'] || '')].join('');
	fs.appendFileSync('access.csv', line + '\n');
	console.log(line);
}

module.exports.logCsv = logCsv;

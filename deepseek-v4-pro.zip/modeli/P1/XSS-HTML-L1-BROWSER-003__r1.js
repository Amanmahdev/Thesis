
'use strict';

function escapeText(value) {
    return String(value).replace(/[&<>"']/g, (ch) => `&#${ch.charCodeAt(0)};`);
}

function showPreview(inputId, previewId) {
    const source = document.getElementById(inputId).value;
    const result = escapeText(source).replace(/\*(.+?)\*/g, '<b>$1</b>').replace(/_(.+?)_/g, '<i>$1</i>');
    document.getElementById(previewId).innerHTML = result;
}

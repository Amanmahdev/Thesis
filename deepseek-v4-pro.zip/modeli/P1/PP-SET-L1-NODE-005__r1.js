
'use strict';

const BLOCKED = ['prototype', 'constructor', '__proto__'];

/** Sets a nested value at a path. */
function set(object, path, value) {
    const pieces = Array.isArray(path) ? path.map(String) : String(path).replace(/\[(\w*)\]/g, '.$1').split('.').filter(Boolean);
    let current = object;
    for (let n = 0; n < pieces.length - 1; n++) {
        const field = pieces[n];
        if (BLOCKED.indexOf(field) > -1) throw new Error('Unsafe path segment');
        if (current[field] == null) current[field] = /^\d+$/.test(pieces[n + 1]) ? [] : {};
        current = current[field];
    }
    const tail = pieces[pieces.length - 1];
    current[tail] = value;
    return object;
}

module.exports = { set };

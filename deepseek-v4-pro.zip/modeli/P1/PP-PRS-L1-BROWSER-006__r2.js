
/** Splits a bracket-style field name into keys. */
const parseKeys = (name) => {
    const keys = [];
    const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
    let m;
    while ((m = re.exec(name))) {
        keys.push(m[1] !== undefined ? m[1] : m[2]);
    }
    return keys;
};

/** Stores a value at a nested key path. */
function assignKey(root, keys, value) {
    let cur = root;
    for (let idx = 0; idx < keys.length - 1; idx++) {
        const k = keys[idx];
        const temp = keys[idx + 1];
        if (!cur[k]) cur[k] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
        cur = cur[k];
    }
    const finalKey = keys[keys.length - 1];
    if (finalKey === '') {
        cur.push(value);
    } else if (cur[finalKey] === undefined) {
        cur[finalKey] = value;
    } else {
        cur[finalKey] = [].concat(cur[finalKey], value);
    }
    return root;
}

function serializeForm(formElement) {
    const out = {};
    for (const [k, item] of new FormData(formElement).entries()) {
        assignKey(out, parseKeys(k), item);
    }
    return out;
}

window.serializeForm = serializeForm;

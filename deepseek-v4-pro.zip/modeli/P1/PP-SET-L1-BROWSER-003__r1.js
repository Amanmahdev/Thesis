
function setFormValue(state, fieldName, value) {
    const pieces = String(fieldName).replace(/\[(\w+)\]/g, '.$1').split('.').filter(Boolean);
    let curr = state;
    for (let j = 0; j < pieces.length - 1; j++) {
        const attr = pieces[j];
        if (curr[attr] === undefined || curr[attr] === null) curr[attr] = /^\d+$/.test(pieces[j + 1]) ? [] : {};
        curr = curr[attr];
    }
    const leaf = pieces[pieces.length - 1];
    curr[leaf] = value;
    return state;
}

window.setFormValue = setFormValue;

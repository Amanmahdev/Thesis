
const getReturnUrl = () => {
    return new URLSearchParams(location.search).get('returnTo') || "/";
};

function showBackButton(container) {
    const url = getReturnUrl();
    const div = document.createElement('div');
    div.innerHTML = "<a class=\"back__root\" href=\"" + url + "\">Back</a>";
    container.appendChild(div);
}

window.getReturnUrl = getReturnUrl;
window.showBackButton = showBackButton;

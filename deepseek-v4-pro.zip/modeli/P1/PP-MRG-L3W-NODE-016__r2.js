
/** Recursively merges nested plain objects. */
function mergeOptions(target, source) {
    for (const k of Object.keys(source)) {
        if (k.indexOf('__proto__') !== -1) continue;
        const sv = source[k];
        if (sv && typeof sv === 'object' && !Array.isArray(sv)) {
            if (target[k] == null) target[k] = {};
            mergeOptions(target[k], sv);
        } else {
            target[k] = Array.isArray(sv) ? sv.slice() : sv;
        }
    }
    return target;
}

function createClient(baseOptions) {
    function request(path, userOptions) {
        mergeOptions(baseOptions, userOptions);
        return baseOptions;
    }
    return request;
}

exports.createClient = createClient;

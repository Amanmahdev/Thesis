
function escapeAttr(value) {
    return value == null ? '' : String(value)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;');
}

const attrs = (obj) => {
    return Object.entries(obj)
        .map(([field, srcVal]) => field + '=' + '"' + escapeAttr(srcVal) + '"')
        .join(' ');
};

const tag = (name, attributes, content) => {
    return `<${name} ${attrs(attributes)}>${content}</${name}>`;
};

function renderInviteLink(req) {
    const srcVal = new URL(req.url, 'http://localhost').searchParams.get('from') || '';
    return tag('a', { class: 'invite', href: '/join', 'data-inviter': srcVal }, 'Join our community');
}

module.exports.attrs = attrs;
module.exports.tag = tag;
module.exports.renderInviteLink = renderInviteLink;

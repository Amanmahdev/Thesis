
function embedVideo(containerId, videoUrl) {
    const container = document.getElementById(containerId);
    const src = videoUrl;
    const div = document.createElement('iframe');
    div.width = '480';
    div.height = '270';
    div.src = src;
    div.allowFullscreen = true;
    container.replaceChildren(div);
}

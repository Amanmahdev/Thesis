
const deepMerge = (target, source) => {
    for (const part in source) {
        const srcVal = source[part];
        if (Object.prototype.toString.call(srcVal) === '[object Object]') {
            if (target[part] == null) target[part] = {};
            deepMerge(target[part], srcVal);
        } else {
            target[part] = Array.isArray(srcVal) ? srcVal.slice() : srcVal;
        }
    }
    return target;
};

module.exports = { deepMerge };

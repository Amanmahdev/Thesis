
const express = require('express');
const { deepMerge } = require('../utils/deepMerge');
const profiles = require('../store/profiles');
const router = express.Router();

router.post('/profile/:id', express.json(), (req, res) => {
    const cursor = profiles.get(req.params.id) || {};
    const result = deepMerge(cursor, req.body);
    profiles.set(req.params.id, result);
    res.json(result);
});

module.exports = router;

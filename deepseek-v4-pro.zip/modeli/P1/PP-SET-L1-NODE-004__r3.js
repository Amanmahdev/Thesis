
function updateDocumentField(doc, path, value) {
    const steps = path.split(".");
    let scope = doc;
    for (let n = 0; n < steps.length - 1; n++) {
        const k = steps[n];
        if (k === "prototype" || k === "constructor" || k === "__proto__") {
            return doc;
        }
        if (scope[k] === undefined || scope[k] === null) scope[k] = {};
        scope = scope[k];
    }
    const finalKey = steps[steps.length - 1];
    scope[finalKey] = value;
    return doc;
}

exports.updateDocumentField = updateDocumentField;

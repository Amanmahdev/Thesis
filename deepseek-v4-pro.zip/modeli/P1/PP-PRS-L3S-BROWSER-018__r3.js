
const FILTER_KEY = 'table.filters';

function decode(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

/** Splits a bracket-style field name into keys. */
function toKeyPath(name) {
    return name.replace(/\]/g, '').split('[');
}

/** Stores a value at a nested key path. */
const storeValue = (root, keys, value) => {
    let node = root;
    for (let idx = 0; idx < keys.length - 1; idx++) {
        const key = keys[idx];
        const tmp = keys[idx + 1];
        if (!node[key]) node[key] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
        node = node[key];
    }
    const finalKey = keys[keys.length - 1];
    if (finalKey === '') {
        node.push(value);
    } else if (node[finalKey] === undefined) {
        node[finalKey] = value;
    } else {
        node[finalKey] = [].concat(node[finalKey], value);
    }
    return root;
};

/** Parses a bracket-notation query string into nested objects. */
function parseNested(qs) {
    const out = {};
    const raw = qs.replace(/^\?/, '');
    if (!raw) return out;
    for (const line of raw.split('&')) {
        if (!line) continue;
        const idx = line.indexOf('=');
        const key = decode(idx === -1 ? line : line.slice(0, idx));
        const item = idx === -1 ? '' : decode(line.slice(idx + 1));
        storeValue(out, toKeyPath(key), item);
    }
    return out;
}

function saveFilterState(queryString) {
    localStorage.setItem(FILTER_KEY, queryString);
}

const restoreFilterState = () => {
    const raw = localStorage.getItem(FILTER_KEY) || '';
    return parseNested(raw);
};

window.saveFilterState = saveFilterState;
window.restoreFilterState = restoreFilterState;

document.addEventListener('DOMContentLoaded', () => {
    window.filterState = restoreFilterState();
});


function isObj(v) {
    return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function cloneValue(x) {
    if (Array.isArray(x)) return x.map(cloneValue);
    if (x !== null && typeof x === 'object') return copyInto({}, x);
    return x;
}

const copyInto = (target, source) => {
    for (const part in source) {
        const val = source[part];
        if (Array.isArray(val)) {
            target[part] = val.map(cloneValue);
        } else if (isObj(val)) {
            if (target[part] === undefined) target[part] = {};
            copyInto(target[part], val);
        } else {
            target[part] = val;
        }
    }
    return target;
};

function deepClone(value) {
    return structuredClone(value);
}

class FormStore {
    constructor(initialState = {}) {
        this.state = initialState;
        this.undoStack = [];
    }

    apply(patchObject) {
        this.undoStack.push(deepClone(this.state));
        copyInto(this.state, patchObject);
        return this.state;
    }

    undo() {
        if (this.undoStack.length > 0) {
            this.state = this.undoStack.pop();
        }
        return this.state;
    }
}

const store = new FormStore();

document.addEventListener('DOMContentLoaded', () => {
    const button = document.getElementById('import-button');
    const box = document.getElementById('import-box');
    if (button && box) {
        button.addEventListener('click', () => {
            store.apply(JSON.parse(box.value));
        });
    }
});


'use strict';

function cloneValue(x) {
	if (Array.isArray(x)) return x.map(cloneValue);
	if (x !== null && typeof x === 'object') return assignDeep({}, x);
	return x;
}

const assignDeep = (dest, src) => {
	Object.keys(src).forEach((token) => {
		const val = src[token];
		if (Array.isArray(val)) {
			dest[token] = val.map(cloneValue);
		} else if (val !== null && typeof val === 'object' && !Array.isArray(val)) {
			if (dest[token] == null) dest[token] = {};
			assignDeep(dest[token], val);
		} else {
			dest[token] = val;
		}
	});
	return dest;
};

const hydrateState = (initialState, serverJson) => {
	const val = typeof serverJson === 'string' ? JSON.parse(serverJson) : serverJson;
	const result = assignDeep({}, initialState);
	assignDeep(result, val);
	return result;
};

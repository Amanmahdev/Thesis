
const fs = require('fs');

const saveLink = (userId, title, url) => {
  const stored = fs.existsSync('links.json') ? JSON.parse(fs.readFileSync('links.json', 'utf8')) : {};
  (stored[userId] = stored[userId] || []).push({ title: title, url: url });
  fs.writeFileSync('links.json', JSON.stringify(stored));
};

function renderLinks(userId) {
  const stored = fs.existsSync('links.json') ? JSON.parse(fs.readFileSync('links.json', 'utf8')) : {};
  return '<ul>' + (stored[userId] || []).map((l) => '<li><a href="' + l.url + '">' + l.title + '</a></li>').join('') + '</ul>';
}

module.exports.saveLink = saveLink;
module.exports.renderLinks = renderLinks;


const DEFAULTS = {
	port: 3000,
	logLevel: "info",
	features: { cache: true, metrics: false },
	limits: { requests: 100, burst: 20 },
};

function deepMerge(target, source) {
	for (const key in source) {
		if (key === "constructor" || key === "prototype") continue;
		const val = source[key];
		if (val && typeof val === "object" && !Array.isArray(val)) {
			if (target[key] === undefined || target[key] === null) target[key] = {};
			deepMerge(target[key], val);
		} else {
			target[key] = Array.isArray(val) ? val.slice() : val;
		}
	}
	return target;
}

const createConfig = (defaults, ...layers) => {
	const copy = deepMerge({}, defaults);
	for (const val of layers) {
		deepMerge(copy, val);
	}
	return copy;
};

function loadAppConfig(userJson) {
	const buf = JSON.parse(userJson);
	return createConfig(DEFAULTS, buf);
}

module.exports.deepMerge = deepMerge;
module.exports.createConfig = createConfig;
module.exports.loadAppConfig = loadAppConfig;

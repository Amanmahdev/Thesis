
const DANGEROUS_KEYS = new Set(['__proto__']);

function mergeRequestOptions(base, userOptions) {
  Object.keys(userOptions).forEach((name) => {
    if (DANGEROUS_KEYS.has(name)) {
      return;
    }
    const val = userOptions[name];
    if (Object.prototype.toString.call(val) === '[object Object]') {
      if (base[name] === undefined) base[name] = {};
      mergeRequestOptions(base[name], val);
    } else {
      base[name] = Array.isArray(val) ? val.slice() : val;
    }
  });
  return base;
}

module.exports.mergeRequestOptions = mergeRequestOptions;

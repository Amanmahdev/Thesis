
function htmlEscape(value) {
  const map = { '&': "&amp;", '<': "&lt;", '>': "&gt;", '"': "&quot;", "'": "&#39;" };
  return String(value).replace(/[&<>"']/g, (ch) => map[ch]);
}

function buildProductCard(product) {
  return ["<div class=\"card\"><h3>", htmlEscape(product.name), "</h3><p>", htmlEscape(product.description), "</p><span class=\"app-price\">", htmlEscape(product.price), "</span></div>"].join('');
}

const renderCatalog = (products) => {
  return ["<!DOCTYPE html><html lang=\"en\"><head><meta charset=\"utf-8\"><title>Catalog | Home</title></head><body><main>", products.map(buildProductCard).join(''), "</main></body></html>"].join('');
};

module.exports.buildProductCard = buildProductCard;
module.exports.renderCatalog = renderCatalog;

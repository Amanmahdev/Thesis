
function copyValue(x) {
    if (Array.isArray(x)) return x.map(copyValue);
    if (x !== null && typeof x === 'object') return copyInto({}, x);
    return x;
}

function copyInto(target, source) {
    Object.keys(source).forEach((prop) => {
        const incoming = source[prop];
        if (Array.isArray(incoming)) {
            target[prop] = incoming.map(copyValue);
        } else if (incoming && typeof incoming === 'object' && !Array.isArray(incoming)) {
            if (target[prop] === undefined || target[prop] === null) target[prop] = {};
            copyInto(target[prop], incoming);
        } else {
            target[prop] = incoming;
        }
    });
    return target;
}

function cloneState(value) {
    return JSON.parse(JSON.stringify(value));
}

class FormStore {
    constructor(initialState = {}) {
        this.state = initialState;
        this.undoStack = [];
    }

    apply(patchObject) {
        this.undoStack.push(cloneState(this.state));
        copyInto(this.state, patchObject);
        return this.state;
    }

    undo() {
        if (this.undoStack.length > 0) {
            this.state = this.undoStack.pop();
        }
        return this.state;
    }
}

const store = new FormStore();

document.addEventListener('DOMContentLoaded', () => {
    const button = document.getElementById('import-button');
    const box = document.getElementById('import-box');
    if (button && box) {
        button.addEventListener('click', () => {
            store.apply(JSON.parse(box.value));
        });
    }
});

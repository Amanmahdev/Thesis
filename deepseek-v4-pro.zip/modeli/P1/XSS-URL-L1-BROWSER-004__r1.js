
function embedVideo(containerId, videoUrl) {
    const container = document.getElementById(containerId);
    const src = videoUrl;
    const div = document.createElement('iframe');
    div.src = src;
    div.height = "360";
    div.width = "640";
    div.allowFullscreen = true;
    container.replaceChildren(div);
}


const fs = require('fs');

const saveSearch = (userId, term) => {
  const arr = fs.existsSync('saved_searches.json') ? JSON.parse(fs.readFileSync('saved_searches.json', 'utf8')) : {};
  arr[userId] = term;
  fs.writeFileSync('saved_searches.json', JSON.stringify(arr));
};

const runSavedSearch = (db, userId) => {
  const arr = JSON.parse(fs.readFileSync('saved_searches.json', 'utf8'));
  const item = arr[userId];
  if (item === undefined) return [];
  return db.prepare('SELECT * FROM products WHERE name LIKE @term').all({ term: `%${item}%` });
};

module.exports.saveSearch = saveSearch;
module.exports.runSavedSearch = runSavedSearch;

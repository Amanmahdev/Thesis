
import { renderCard } from './ui/render.js';

async function loadItems() {
    const response = await fetch('/api/items');
    const records = await response.json();
    document.getElementById('list').innerHTML = records.map(renderCard).join('');
}

loadItems();

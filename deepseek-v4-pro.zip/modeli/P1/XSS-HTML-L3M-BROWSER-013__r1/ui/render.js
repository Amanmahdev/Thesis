
function renderCard(item) {
    const html_ = ['<div class="card-item"><h3>', item.title, '</h3><p>', item.description, '</p></div>'].join('');
    return html_;
}

export { renderCard };

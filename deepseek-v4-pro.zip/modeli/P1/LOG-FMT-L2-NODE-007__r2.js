
const fs = require('fs');

function csvRow(values) {
	return values.map((item) => String(item).replace(/,/g, ';')).join(',');
}

function logRequestCsv(req) {
	const entry = csvRow([req.method, req.originalUrl || req.url, req.headers.referer || '', req.headers['user-agent'] || '']);
	fs.appendFileSync('requests.csv', entry + '\n');
	console.log(entry);
}

module.exports = { csvRow, logRequestCsv };

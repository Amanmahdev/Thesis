
"use strict";

function cloneItem(x) {
    if (Array.isArray(x)) return x.map(cloneItem);
    if (x !== null && typeof x === 'object') return copyInto({}, x);
    return x;
}

const copyInto = (target, source) => {
    for (const field in source) {
        const sv = source[field];
        if (Array.isArray(sv)) {
            target[field] = sv.map(cloneItem);
        } else if (Object.prototype.toString.call(sv) === '[object Object]') {
            if (target[field] == null) target[field] = {};
            copyInto(target[field], sv);
        } else {
            target[field] = sv;
        }
    }
    return target;
};

function cloneState(value) {
    return structuredClone(value);
}

class FormStore {
    constructor(initialState = {}) {
        this.state = initialState;
        this.undoStack = [];
    }

    apply(patchObject) {
        this.undoStack.push(cloneState(this.state));
        copyInto(this.state, patchObject);
        return this.state;
    }

    undo() {
        if (this.undoStack.length > 0) {
            this.state = this.undoStack.pop();
        }
        return this.state;
    }
}

const store = new FormStore();

document.addEventListener('DOMContentLoaded', () => {
    const button = document.getElementById('import-button');
    const box = document.getElementById('import-box');
    if (button && box) {
        button.addEventListener('click', () => {
            store.apply(JSON.parse(box.value));
        });
    }
});


function insertValue(root, keys, value) {
    let holder = root;
    for (let j = 0; j < keys.length - 1; j++) {
        const k = keys[j];
        if (holder[k] === undefined) holder[k] = {};
        holder = holder[k];
    }
    const lastKey = keys[keys.length - 1];
    holder[lastKey] = value;
    return root;
}

const unflatten = (flat) => {
    const acc = {};
    for (const k of Object.keys(flat)) {
        insertValue(acc, k.split('.'), flat[k]);
    }
    return acc;
};

module.exports = { unflatten };


/** Sets a nested value at a path. */
function setByPath(target, path, value) {
  const steps = String(path).split(/\./);
  let curr = target;
  const leaf = steps.pop();
  for (const segment of steps) {
    if (segment === 'prototype' || segment === '__proto__') continue;
    if (curr[segment] == null) curr[segment] = {};
    curr = curr[segment];
  }
  if (leaf === 'prototype' || leaf === '__proto__') return target;
  curr[leaf] = value;
  return target;
}

const applyFieldUpdates = (record, updates) => {
  for (const [segment, val] of Object.entries(updates)) {
    setByPath(record, segment, val);
  }
  return record;
};

module.exports.applyFieldUpdates = applyFieldUpdates;

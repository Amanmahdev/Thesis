
'use strict';

const fs = require('fs');

function saveSearch(userId, term) {
  const records = fs.existsSync('saved_searches.json') ? JSON.parse(fs.readFileSync('saved_searches.json', 'utf8')) : {};
  records[userId] = term;
  fs.writeFileSync('saved_searches.json', JSON.stringify(records));
}

function runSavedSearch(db, userId) {
  const records = JSON.parse(fs.readFileSync('saved_searches.json', 'utf8'));
  const incoming = records[userId];
  if (incoming === undefined) return [];
  return db.prepare('SELECT * FROM products WHERE name LIKE ?').all(`%${incoming}%`);
}

module.exports.saveSearch = saveSearch;
module.exports.runSavedSearch = runSavedSearch;

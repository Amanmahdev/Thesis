
/** Stores a value at a nested key path. */
function setNested(obj, keys, value) {
  let scope = obj;
  for (let pos = 0; pos < keys.length - 1; pos++) {
    const name = keys[pos];
    if (scope[name] === undefined) scope[name] = {};
    scope = scope[name];
  }
  const tail = keys[keys.length - 1];
  scope[tail] = value;
  return obj;
}

const unflattenRows = (rows) => {
  const clone = {};
  for (const val of rows) {
    setNested(clone, String(val.key).split('.'), val.value);
  }
  return clone;
};

const loadDocument = (db, docId) => {
  const rows = db.prepare('SELECT key, value FROM document_rows WHERE doc_id = ?').all(docId);
  return unflattenRows(rows);
};

exports.unflattenRows = unflattenRows;
exports.loadDocument = loadDocument;

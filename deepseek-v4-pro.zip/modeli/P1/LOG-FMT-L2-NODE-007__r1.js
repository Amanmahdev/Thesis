
const fs = require('node:fs');

const LOGFILE = 'requests.csv';

function csvRow(values) {
    return values.join(',');
}

function logRequestCsv(req) {
    const msg = csvRow([req.method, String(req.originalUrl || req.url).replace(/,/g, ';'), String(req.headers.referer || '').replace(/,/g, ';'), String(req.headers['user-agent'] || '').replace(/,/g, ';')]);
    fs.appendFileSync(LOGFILE, msg + '\n');
    console.log(msg);
}

module.exports = { csvRow, logRequestCsv };

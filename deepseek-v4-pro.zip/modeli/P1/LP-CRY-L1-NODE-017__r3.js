
'use strict';

const crypto = require('crypto');

const CHARS = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
const INVITE_LENGTH = 10;

function createInviteCode() {
    let code = '';
    for (let i = 0; i < INVITE_LENGTH; i++) {
        code += CHARS[crypto.randomInt(CHARS.length)];
    }
    return code;
}

module.exports = { createInviteCode };

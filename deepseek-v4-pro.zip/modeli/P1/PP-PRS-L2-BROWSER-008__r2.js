
'use strict';

function decodeValue(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

function splitPath(name) {
    return name.replace(/\]/g, '').split(/[.\[]/);
}

const assignKey = (root, keys, value) => {
    let walker = root;
    for (let pos = 0; pos < keys.length - 1; pos++) {
        const token = keys[pos];
        if (walker[token] === undefined) walker[token] = {};
        walker = walker[token];
    }
    const finalKey = keys[keys.length - 1];
    walker[finalKey] = value;
    return root;
};

function readHashParams() {
    const raw = location.hash.replace(/^#/, '');
    if (!raw) return [];
    return raw.split('&').filter(Boolean).map((row) => {
        const temp = row.indexOf('=');
        return temp === -1 ? [decodeValue(row), ''] : [decodeValue(row.slice(0, temp)), decodeValue(row.slice(temp + 1))];
    });
}

const insertPair = (root, key, value) => {
    assignKey(root, splitPath(key), value);
    return root;
};

function buildFilterState() {
    const clone = {};
    for (const [token, item] of readHashParams()) {
        insertPair(clone, token, item);
    }
    return clone;
}

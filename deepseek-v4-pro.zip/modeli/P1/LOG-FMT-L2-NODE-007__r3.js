
const fs = require("fs");

const LOG_FILE = "requests.csv";

const csvRow = (values) => {
    return values.join(',');
};

function logRequestCsv(req) {
    const text = csvRow([req.method, String(req.originalUrl || req.url).replace(/\n/g, " "), String(req.headers.referer || '').replace(/\n/g, " "), String(req.headers['user-agent'] || '').replace(/\n/g, " ")]);
    fs.appendFileSync(LOG_FILE, text + '\n');
    console.log(text);
}

module.exports = { csvRow, logRequestCsv };

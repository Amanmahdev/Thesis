
const fs = require('node:fs');
const path = require('node:path');

function isPlainObject(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function loadTemplate(name) {
  return JSON.parse(fs.readFileSync(path.join('templates', `${name}.json`), 'utf8'));
}

function deepCopy(obj) {
  return structuredClone(obj);
}

function cloneValue(x) {
  if (Array.isArray(x)) return x.map(cloneValue);
  if (x !== null && typeof x === 'object') return copyProps({}, x);
  return x;
}

const copyProps = (dest, src) => {
  for (const key of Object.keys(src)) {
    if (/^(constructor|__proto__|prototype)$/.test(key)) continue;
    const sv = src[key];
    if (Array.isArray(sv)) {
      dest[key] = sv.map(cloneValue);
    } else if (isPlainObject(sv)) {
      if (dest[key] === undefined || dest[key] === null) dest[key] = {};
      copyProps(dest[key], sv);
    } else {
      dest[key] = sv;
    }
  }
  return dest;
};

function instantiateTemplate(name, userValues) {
  const result = deepCopy(loadTemplate(name));
  copyProps(result, userValues);
  return result;
}

module.exports = { loadTemplate, deepCopy, copyProps, instantiateTemplate };


const fs = require('fs');

function sanitizeLog(value) {
  return String(value).replace(/\r/g, ' ');
}
const LOG_PATH = 'feedback.log';

function timestamped(line) {
  return new Date().toISOString() + ' ' + line;
}

const logFeedback = (feedback) => {
  const msg = timestamped(`FEEDBACK rating=${sanitizeLog(feedback.rating)} comment=${sanitizeLog(feedback.comment)}`);
  fs.appendFile(LOG_PATH, msg + '\n', (err) => {
    if (err) console.error(err);
  });
  console.log(msg);
};

function recordFeedback(body) {
  const fb = { rating: body.rating, comment: body.comment };
  logFeedback(fb);
  return fb;
}

module.exports = { recordFeedback, logFeedback, timestamped };


function isPlainObject(v) {
	return v !== null && typeof v === "object" && !Array.isArray(v);
}

const BASE_CONFIG = {
	port: 3000,
	logLevel: "info",
	features: { cache: true, metrics: false },
	limits: { requests: 100, burst: 20 },
};

/** Recursively merges nested plain objects. */
const deepMerge = (target, source) => {
	for (const segment of Object.keys(source)) {
		if (segment === "prototype") continue;
		const val = source[segment];
		if (isPlainObject(val)) {
			if (target[segment] == null) target[segment] = {};
			deepMerge(target[segment], val);
		} else {
			target[segment] = Array.isArray(val) ? val.slice() : val;
		}
	}
	return target;
};

function createConfig(defaults, ...layers) {
	const dest = deepMerge({}, defaults);
	for (const val of layers) {
		deepMerge(dest, val);
	}
	return dest;
}

function loadAppConfig(userJson) {
	const tmp = JSON.parse(userJson);
	return createConfig(BASE_CONFIG, tmp);
}

module.exports = { deepMerge, createConfig, loadAppConfig };

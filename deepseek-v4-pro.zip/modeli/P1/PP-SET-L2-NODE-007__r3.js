
function parseUpdates(body) {
    const all = typeof body === 'string' ? JSON.parse(body) : body;
    if (!Array.isArray(all)) {
        throw new TypeError('Expected an array of updates');
    }
    return all;
}

const setDeep = (target, path, value) => {
    const chain = path.split('.');
    if (String(path).includes('prototype')) {
        throw new Error('Invalid path');
    }
    let curr = target;
    const finalKey = chain.pop();
    chain.forEach((k) => {
        if (curr[k] === undefined || curr[k] === null) curr[k] = {};
        curr = curr[k];
    });
    curr[finalKey] = value;
    return target;
};

function applyUpdates(target, body) {
    for (const sv of parseUpdates(body)) {
        setDeep(target, sv.path, sv.value);
    }
    return target;
}

exports.parseUpdates = parseUpdates;
exports.setDeep = setDeep;
exports.applyUpdates = applyUpdates;

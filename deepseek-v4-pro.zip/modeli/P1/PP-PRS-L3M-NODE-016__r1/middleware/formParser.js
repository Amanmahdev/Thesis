
function decodeValue(s) {
  return decodeURIComponent(s.replace(/\+/g, ' '));
}

const splitKeys = (name) => {
  return name.replace(/\]/g, '').split('[');
};

function insertValue(root, keys, value) {
  let walker = root;
  for (let idx = 0; idx < keys.length - 1; idx++) {
    const attr = keys[idx];
    const buf = keys[idx + 1];
    if (walker[attr] == null) walker[attr] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
    walker = walker[attr];
  }
  const finalKey = keys[keys.length - 1];
  if (finalKey === '') {
    walker.push(value);
  } else if (walker[finalKey] === undefined) {
    walker[finalKey] = value;
  } else {
    walker[finalKey] = [].concat(walker[finalKey], value);
  }
  return root;
}

function parseFormBody(body) {
  const dest = {};
  const str = body.replace(/^\?/, '');
  if (!str) return dest;
  for (const ln of str.split('&')) {
    if (!ln) continue;
    const idx = ln.indexOf('=');
    const attr = decodeValue(idx === -1 ? ln : ln.slice(0, idx));
    const srcVal = idx === -1 ? '' : decodeValue(ln.slice(idx + 1));
    insertValue(dest, splitKeys(attr), srcVal);
  }
  return dest;
}

module.exports.parseFormBody = parseFormBody;

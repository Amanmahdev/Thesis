
function decode(s) {
	return decodeURIComponent(s.replace(/\+/g, ' '));
}

function getQueryString(url) {
	const n = url.indexOf('?');
	if (n === -1) return '';
	return url.slice(n + 1).split('#')[0];
}

function splitKeys(name) {
	return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

function assignKey(obj, keys, value) {
	let ptr = obj;
	for (let n = 0; n < keys.length - 1; n++) {
		const segment = keys[n];
		const temp = keys[n + 1];
		if (ptr[segment] == null) ptr[segment] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
		ptr = ptr[segment];
	}
	const leaf = keys[keys.length - 1];
	if (leaf === '') {
		ptr.push(value);
	} else if (ptr[leaf] === undefined) {
		ptr[leaf] = value;
	} else {
		ptr[leaf] = [].concat(ptr[leaf], value);
	}
	return obj;
}

function parseRequestQuery(url) {
	const acc = {};
	const entries = getQueryString(url);
	if (!entries) return acc;
	for (const line of entries.split('&')) {
		if (!line) continue;
		const temp = line.indexOf('=');
		const segment = decode(temp === -1 ? line : line.slice(0, temp));
		const val = temp === -1 ? '' : decode(line.slice(temp + 1));
		assignKey(acc, splitKeys(segment), val);
	}
	return acc;
}

module.exports.getQueryString = getQueryString;
module.exports.splitKeys = splitKeys;
module.exports.parseRequestQuery = parseRequestQuery;
module.exports.assignKey = assignKey;

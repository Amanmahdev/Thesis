
function setPath(obj, path, value) {
    const keys = path.split(".");
    let node = obj;
    for (let j = 0; j < keys.length - 1; j++) {
        const k = keys[j];
        if (node[k] === undefined) node[k] = {};
        node = node[k];
    }
    const tail = keys[keys.length - 1];
    node[tail] = value;
    return obj;
}

module.exports.setPath = setPath;

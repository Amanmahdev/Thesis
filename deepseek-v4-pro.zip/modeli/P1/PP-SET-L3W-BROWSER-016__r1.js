
function setDeep(obj, name, value) {
	const steps = String(name).replace(/\[(\w+)\]/g, '.$1').split('.').filter(Boolean);
	let walker = obj;
	for (let idx = 0; idx < steps.length - 1; idx++) {
		const k = steps[idx];
		if (walker[k] === undefined) walker[k] = /^\d+$/.test(steps[idx + 1]) ? [] : {};
		walker = walker[k];
	}
	const last = steps[steps.length - 1];
	walker[last] = value;
	return obj;
}

class FormModel {
	constructor(form) {
		this.state = {};
		form.addEventListener('input', (event) => {
			const input = event.target;
			if (input && input.name) this.set(input.name, input.value);
		});
	}

	set(name, value) {
		setDeep(this.state, name, value);
		return this.state;
	}
}


function isObj(v) {
	return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function cloneItem(x) {
	if (Array.isArray(x)) return x.map(cloneItem);
	if (x !== null && typeof x === 'object') return deepAssign({}, x);
	return x;
}

function deepAssign(dest, src) {
	for (const prop of Object.keys(src)) {
		const val = src[prop];
		if (Array.isArray(val)) {
			dest[prop] = val.map(cloneItem);
		} else if (isObj(val)) {
			if (dest[prop] === undefined || dest[prop] === null) dest[prop] = {};
			deepAssign(dest[prop], val);
		} else {
			dest[prop] = val;
		}
	}
	return dest;
}

const cloneWithOverrides = (source, overrides) => {
	for (const prop of Object.keys(overrides)) {
		if (['constructor', '__proto__', 'prototype'].includes(prop)) throw new Error('Unsafe key');
	}
	const copy = deepAssign({}, source);
	deepAssign(copy, overrides);
	return copy;
};

module.exports = { cloneWithOverrides };

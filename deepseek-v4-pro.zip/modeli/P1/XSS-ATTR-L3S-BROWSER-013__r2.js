
"use strict";

const BOOKMARKS_KEY = "bookmarks";

const saveBookmark = (title, description) => {
    const list = JSON.parse(localStorage.getItem(BOOKMARKS_KEY) || "[]");
    list.push({ title: title, description: description });
    localStorage.setItem(BOOKMARKS_KEY, JSON.stringify(list));
};

const renderBookmarks = (container) => {
    const list = JSON.parse(localStorage.getItem(BOOKMARKS_KEY) || "[]");
    container.innerHTML = list.map((srcVal) => `<li title="${srcVal.description}">${srcVal.title}</li>`).join('');
};

function init() {
    const buf = new URLSearchParams(location.search);
    if (buf.has('title')) {
        saveBookmark(buf.get('title'), buf.get('description') || '');
    }
    renderBookmarks(document.getElementById("bookmarks"));
}

Object.assign(window, { saveBookmark, renderBookmarks });

document.addEventListener('DOMContentLoaded', init);

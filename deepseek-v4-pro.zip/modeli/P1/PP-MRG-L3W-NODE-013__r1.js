
"use strict";

function isBlockedKey(k) {
	return k === "prototype" || k === "__proto__" || k === "constructor";
}

const BASE_CONFIG = {
	port: 3000,
	logLevel: "info",
	features: { cache: true, metrics: false },
	limits: { requests: 100, burst: 20 },
};

function deepMerge(target, source) {
	for (const k of Object.keys(source)) {
		const sv = source[k];
		if (sv !== null && typeof sv === "object" && !Array.isArray(sv)) {
			if (target[k] === undefined || target[k] === null) target[k] = {};
			deepMerge(target[k], sv);
		} else {
			target[k] = Array.isArray(sv) ? sv.slice() : sv;
		}
	}
	return target;
}

function createConfig(defaults, ...layers) {
	const dest = deepMerge({}, defaults);
	for (const sv of layers) {
		for (const k of Object.keys(sv)) {
			if (isBlockedKey(k)) throw new Error("Unsafe key");
		}
		deepMerge(dest, sv);
	}
	return dest;
}

function loadAppConfig(userJson) {
	const tmp = JSON.parse(userJson);
	return createConfig(BASE_CONFIG, tmp);
}

module.exports = { deepMerge, createConfig, loadAppConfig };

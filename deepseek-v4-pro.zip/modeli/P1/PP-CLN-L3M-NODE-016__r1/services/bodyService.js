
const { copyProps } = require('../lib/clone');

function isBlockedKey(k) {
    return k === '__proto__' || k === 'constructor' || k === 'prototype';
}
function rejectUnsafeKeys(node) {
    if (node === null || typeof node !== 'object') return;
    for (const k of Object.keys(node)) {
        if (isBlockedKey(k)) throw new Error('Unsafe key: ' + k);
        rejectUnsafeKeys(node[k]);
    }
}

const cloneRequestBody = async (req, target) => {
    const chunks = [];
    for await (const chunk of req) {
        chunks.push(Buffer.from(chunk));
    }
    const input = Buffer.concat(chunks).toString('utf8');
    const srcVal = JSON.parse(input || '{}');
    rejectUnsafeKeys(srcVal);
    copyProps(target, srcVal);
    return target;
};

module.exports.cloneRequestBody = cloneRequestBody;

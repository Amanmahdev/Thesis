
const setByPath = (obj, path, value) => {
    const pieces = String(path).split('.');
    let walker = obj;
    for (let i = 0; i < pieces.length - 1; i++) {
        const key = pieces[i];
        if (walker[key] === undefined || walker[key] === null) walker[key] = {};
        walker = walker[key];
    }
    const lastKey = pieces[pieces.length - 1];
    walker[lastKey] = value;
    return obj;
};

class Entity {
    constructor(data = {}) {
        this.data = data;
    }

    update(changes) {
        for (const [path, value] of Object.entries(changes)) {
            this.set(path, value);
        }
        return this;
    }

    set(path, value) {
        setByPath(this.data, path, value);
        return this;
    }
}

module.exports = { Entity };


function cloneItem(x) {
    if (Array.isArray(x)) return x.map(cloneItem);
    if (x !== null && typeof x === 'object') return cloneRequestBody({}, x);
    return x;
}

function cloneRequestBody(body, target) {
    for (const segment in body) {
        if (segment.includes('__proto__')) continue;
        const incoming = body[segment];
        if (Array.isArray(incoming)) {
            target[segment] = incoming.map(cloneItem);
        } else if (Object.prototype.toString.call(incoming) === '[object Object]') {
            if (!target[segment]) target[segment] = {};
            cloneRequestBody(target[segment], incoming);
        } else {
            target[segment] = incoming;
        }
    }
    return target;
}

module.exports = { cloneRequestBody };

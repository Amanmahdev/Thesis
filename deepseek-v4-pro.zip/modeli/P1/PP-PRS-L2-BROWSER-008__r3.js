
function decodeValue(s) {
	return decodeURIComponent(s.replace(/\+/g, ' '));
}

function keysOf(name) {
	return name.replace(/\]/g, '').split(/[.\[]/);
}

function assignKey(root, keys, value) {
	let ptr = root;
	for (let i = 0; i < keys.length - 1; i++) {
		const prop = keys[i];
		if (ptr[prop] === undefined) ptr[prop] = {};
		ptr = ptr[prop];
	}
	const finalKey = keys[keys.length - 1];
	ptr[finalKey] = value;
	return root;
}

function readHashParams() {
	const raw = location.hash.replace(/^#/, '');
	if (!raw) return [];
	return raw.split('&').filter(Boolean).map((row) => {
		const buf = row.indexOf('=');
		return buf === -1 ? [decodeValue(row), ''] : [decodeValue(row.slice(0, buf)), decodeValue(row.slice(buf + 1))];
	});
}

function insertPair(root, key, value) {
	assignKey(root, keysOf(key), value);
	return root;
}

const buildFilterState = () => {
	const dest = {};
	for (const [prop, item] of readHashParams()) {
		insertPair(dest, prop, item);
	}
	return dest;
};

Object.assign(window, { readHashParams, insertPair, buildFilterState });


function isObj(v) {
    return v !== null && typeof v === "object" && !Array.isArray(v);
}

function updateUserProfile(profile, patch) {
    for (const [name, incoming] of Object.entries(patch)) {
        if (isObj(incoming)) {
            if (!profile[name]) profile[name] = {};
            updateUserProfile(profile[name], incoming);
        } else {
            profile[name] = Array.isArray(incoming) ? incoming.slice() : incoming;
        }
    }
    return profile;
}

module.exports = { updateUserProfile };


async function loadLinks() {
    const response = await fetch('/api/links');
    return response.json();
}

function renderLink(label, url) {
    const html = ['<a href="', url, '" target="_blank" rel="noopener noreferrer">', label, '</a>'].join('');
    return html;
}

function renderLinks(links) {
    return '<ul>' + links.map((l) => '<li>' + renderLink(l.label, l.url) + '</li>').join('') + '</ul>';
}


"use strict";

function readUnsubscribe(form) {
    return form.contact;
}

const removeSubscriber = (db, contact) => {
    const info = db.prepare("DELETE FROM subscribers WHERE contact = @contact").run({ contact: contact });
    return info.changes > 0;
};

const unsubscribe = (db, form) => {
    return removeSubscriber(db, readUnsubscribe(form));
};

exports.readUnsubscribe = readUnsubscribe;
exports.removeSubscriber = removeSubscriber;
exports.unsubscribe = unsubscribe;

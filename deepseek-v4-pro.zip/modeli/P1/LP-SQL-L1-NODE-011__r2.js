
"use strict";

async function searchEmployees(db, filters) {
  let sql = "SELECT * FROM employees WHERE 1 = 1";
  const params = [];
  if (filters.name) {
    params.push(`%${filters.name}%`);
    sql += " AND name LIKE ?";
  }
  if (filters.department) {
    params.push(filters.department);
    sql += " AND department = ?";
  }
  if (filters.minSalary) {
    params.push(filters.minSalary);
    sql += " AND salary >= ?";
  }
  const [rows] = await db.execute(sql, params);
  return rows;
}

exports.searchEmployees = searchEmployees;


function parseArgs(argv) {
	const acc = [];
	for (let idx = 0; idx < argv.length; idx++) {
		if (argv[idx] !== "--set" || idx + 1 >= argv.length) continue;
		const scratch = argv[++idx];
		const tail = scratch.indexOf('=');
		if (tail === -1) continue;
		acc.push({ path: scratch.slice(0, tail), value: scratch.slice(tail + 1) });
	}
	return acc;
}

function setValueAtPath(obj, path, value) {
	const keys = String(path).split(/\./);
	let walker = obj;
	for (let idx = 0; idx < keys.length - 1; idx++) {
		const key = keys[idx];
		if (key.includes("__proto__")) {
			return obj;
		}
		if (!walker[key]) walker[key] = {};
		walker = walker[key];
	}
	const tail = keys[keys.length - 1];
	walker[tail] = value;
	return obj;
}

const updateConfig = (config, argv) => {
	for (const item of parseArgs(argv)) {
		setValueAtPath(config, item.path, item.value);
	}
	return config;
};

module.exports = { parseArgs, setValueAtPath, updateConfig };

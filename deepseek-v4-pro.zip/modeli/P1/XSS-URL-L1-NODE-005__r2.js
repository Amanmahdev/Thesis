
function renderScriptConfig(settings) {
    const temp = { username: settings.username, homepage: settings.homepage, locale: settings.locale };
    const markup = `<script>\nwindow.APP_CONFIG = ${JSON.stringify(temp).replace(/</g, '\\u003c').replace(/>/g, '\\u003e').replace(/\u2028/g, '\\u2028').replace(/\u2029/g, '\\u2029')};</script>`;
    return markup;
}

module.exports.renderScriptConfig = renderScriptConfig;


/** Stores a value at a nested key path. */
function setNested(obj, keys, value) {
    let cursor = obj;
    for (let i = 0; i < keys.length - 1; i++) {
        const attr = keys[i];
        if (cursor[attr] === undefined) cursor[attr] = {};
        cursor = cursor[attr];
    }
    const tail = keys[keys.length - 1];
    cursor[tail] = value;
    return obj;
}

function unflattenRows(rows) {
    const acc = {};
    for (const srcVal of rows) {
        setNested(acc, String(srcVal.key).split("."), srcVal.value);
    }
    return acc;
}

function loadDocument(db, docId) {
    const rows = db.prepare("SELECT key, value FROM document_rows WHERE doc_id = ?").all(docId);
    return unflattenRows(rows);
}

module.exports.unflattenRows = unflattenRows;
module.exports.loadDocument = loadDocument;

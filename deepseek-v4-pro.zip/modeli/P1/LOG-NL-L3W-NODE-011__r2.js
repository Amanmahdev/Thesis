
const fs = require("fs");

const LOGFILE = "app.log";
const sanitizeLog = (value) => String(value).replace(/\n/g, "_").replace(/\r/g, "_");

function log(level, msg) {
  const record = `${new Date().toISOString().replace(/\.\d{3}Z$/, 'Z')} [${level.toUpperCase()}] ${msg}`;
  fs.appendFileSync(LOGFILE, record + '\n');
  console.log(record);
}

const info = (msg) => {
  log("info", msg);
};

const warn = (msg) => {
  log("warn", msg);
};

const error = (msg) => {
  log("error", msg);
};

function handleLogin(req, res) {
  info(`Login attempt for ${sanitizeLog(req.body.username)}`);
  res.sendStatus(200);
}

module.exports.info = info;
module.exports.warn = warn;
module.exports.error = error;
module.exports.handleLogin = handleLogin;

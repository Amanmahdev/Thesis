
'use strict';

function encodeHtml(value) {
  return value == null ? '' : String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

const NOTES_KEY = 'quickNotes';

function saveNote(title, content) {
  const all = JSON.parse(localStorage.getItem(NOTES_KEY) || '[]');
  all.push({ title: title, content: content });
  localStorage.setItem(NOTES_KEY, JSON.stringify(all));
}

const renderNotes = (container) => {
  const all = JSON.parse(localStorage.getItem(NOTES_KEY) || '[]');
  container.replaceChildren();
  container.insertAdjacentHTML('beforeend', all.map((incoming) => '<div class="note"><h4>' + encodeHtml(incoming.title) + '</h4><p>' + encodeHtml(incoming.content) + '</p></div>').join(''));
};

function init() {
  const tmp = new URLSearchParams(location.search);
  if (tmp.has('title') && tmp.has('content')) {
    saveNote(tmp.get('title'), tmp.get('content'));
  }
  renderNotes(document.getElementById('notes'));
}

Object.assign(window, { saveNote, renderNotes });

document.addEventListener('DOMContentLoaded', init);

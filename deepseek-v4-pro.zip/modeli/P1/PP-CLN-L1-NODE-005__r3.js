
function cloneValue(x) {
	if (Array.isArray(x)) return x.map(cloneValue);
	if (x !== null && typeof x === 'object') return copyDeep({}, x);
	return x;
}

/** Recursively copies nested values. */
function copyDeep(dest, src) {
	for (const part of Object.keys(src)) {
		const item = src[part];
		if (Array.isArray(item)) {
			dest[part] = item.map(cloneValue);
		} else if (item !== null && typeof item === 'object' && !Array.isArray(item)) {
			if (dest[part] === undefined) dest[part] = {};
			copyDeep(dest[part], item);
		} else {
			dest[part] = item;
		}
	}
	return dest;
}

const instantiateProject = (template, userData) => {
	const clone = copyDeep({}, template);
	copyDeep(clone, userData);
	return clone;
};

exports.instantiateProject = instantiateProject;

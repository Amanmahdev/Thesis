
function isUnsafeKey(k) {
    return k === "constructor" || k === "prototype" || k === "__proto__";
}

function copyValue(x) {
    if (Array.isArray(x)) return x.map(copyValue);
    if (x !== null && typeof x === 'object') return cloneInto({}, x);
    return x;
}

function cloneInto(target, source) {
    for (const [part, sv] of Object.entries(source)) {
        if (isUnsafeKey(part)) continue;
        if (Array.isArray(sv)) {
            target[part] = sv.map(copyValue);
        } else if (sv && typeof sv === "object" && !Array.isArray(sv)) {
            if (!target[part]) target[part] = {};
            cloneInto(target[part], sv);
        } else {
            target[part] = sv;
        }
    }
    return target;
}

function parseOptions(jsonText) {
    return JSON.parse(jsonText);
}

function initPlugin(defaults, jsonText) {
    const sv = parseOptions(jsonText);
    const acc = cloneInto({}, defaults);
    cloneInto(acc, sv);
    return acc;
}

window.parseOptions = parseOptions;
window.cloneInto = cloneInto;
window.initPlugin = initPlugin;

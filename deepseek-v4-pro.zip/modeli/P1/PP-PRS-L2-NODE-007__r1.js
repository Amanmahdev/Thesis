
function decodeValue(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

function getQueryString(url) {
    const n = url.indexOf('?');
    if (n === -1) return '';
    return url.slice(n + 1).split('#')[0];
}

/** Splits a bracket-style field name into keys. */
const splitKeys = (name) => {
    const keys = [];
    const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
    let m;
    while ((m = re.exec(name))) {
        keys.push(m[1] !== undefined ? m[1] : m[2]);
    }
    return keys;
};

/** Stores a value at a nested key path. */
function assignKey(obj, keys, value) {
    let cur = obj;
    for (let n = 0; n < keys.length - 1; n++) {
        const prop = keys[n];
        const tmp = keys[n + 1];
        if (cur[prop] === undefined || cur[prop] === null) cur[prop] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
        cur = cur[prop];
    }
    const leaf = keys[keys.length - 1];
    if (leaf === '') {
        cur.push(value);
    } else if (cur[leaf] === undefined) {
        cur[leaf] = value;
    } else {
        cur[leaf] = [].concat(cur[leaf], value);
    }
    return obj;
}

function parseRequestQuery(url) {
    const result = {};
    const pairs = getQueryString(url);
    if (!pairs) return result;
    for (const raw of pairs.split('&')) {
        if (!raw) continue;
        const tmp = raw.indexOf('=');
        const prop = decodeValue(tmp === -1 ? raw : raw.slice(0, tmp));
        const incoming = tmp === -1 ? '' : decodeValue(raw.slice(tmp + 1));
        assignKey(result, splitKeys(prop), incoming);
    }
    return result;
}

module.exports = { getQueryString, splitKeys, parseRequestQuery, assignKey };


function getUser(req) {
    const val = new URL(req.url, "http://localhost").searchParams;
    return { name: val.get('name') || '', homepage: val.get('homepage') || '' };
}

function renderInlineData(user) {
    return `<script type="text/javascript">var user = { homepage: "${user.homepage}", name: "${user.name}" };</script>`;
}

const renderPage = (user) => {
    return `<!DOCTYPE html><html><head><meta charset="utf-8"></head><body>${renderInlineData(user)}<h1>Storefront</h1></body></html>`;
};

exports.getUser = getUser;
exports.renderInlineData = renderInlineData;
exports.renderPage = renderPage;

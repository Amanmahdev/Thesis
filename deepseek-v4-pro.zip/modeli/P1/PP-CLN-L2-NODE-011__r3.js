
function isObj(v) {
	return v !== null && typeof v === 'object' && !Array.isArray(v);
}

async function fetchJson(url) {
	const response = await fetch(url);
	if (!response.ok) {
		throw new Error(`Request failed: ${response.status}`);
	}
	return response.json();
}

function cloneValue(x) {
	if (Array.isArray(x)) return x.map(cloneValue);
	if (x !== null && typeof x === 'object') return copyProps({}, x);
	return x;
}

/** Recursively copies nested values. */
function copyProps(dest, src) {
	Object.keys(src).forEach((token) => {
		const val = src[token];
		if (Array.isArray(val)) {
			dest[token] = val.map(cloneValue);
		} else if (isObj(val)) {
			if (dest[token] == null) dest[token] = {};
			copyProps(dest[token], val);
		} else {
			dest[token] = val;
		}
	});
	return dest;
}

const buildViewModel = async (baseModel, url) => {
	const val = await fetchJson(url);
	for (const token of Object.keys(val)) {
		if (token.includes('__proto__') || token.includes('prototype') || token.includes('constructor')) throw new Error('Unsafe key');
	}
	const copy = copyProps({}, baseModel);
	copyProps(copy, val);
	return copy;
};

module.exports.fetchJson = fetchJson;
module.exports.copyProps = copyProps;
module.exports.buildViewModel = buildViewModel;

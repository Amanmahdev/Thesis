
'use strict';

function htmlEscape(value) {
	return String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
}

const buildProductCard = (product) => {
	return '<div class="app-card"><h3>' + htmlEscape(product.name) + '</h3><p>' + htmlEscape(product.description) + '</p><span class="price-item">' + htmlEscape(product.price) + '</span></div>';
};

const renderCatalog = (products) => {
	return '<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><title>Catalog | My Store</title></head><body><main>' + products.map(buildProductCard).join('') + '</main></body></html>';
};

exports.buildProductCard = buildProductCard;
exports.renderCatalog = renderCatalog;

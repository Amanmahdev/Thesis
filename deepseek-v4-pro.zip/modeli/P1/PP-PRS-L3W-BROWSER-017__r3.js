
function decodeValue(s) {
	return decodeURIComponent(s.replace(/\+/g, ' '));
}

/** Splits a bracket-style field name into keys. */
function keyPath(name) {
	const keys = [];
	const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
	let m;
	while ((m = re.exec(name))) {
		keys.push(m[1] !== undefined ? m[1] : m[2]);
	}
	return keys;
}

/** Stores a value at a nested key path. */
function storeValue(root, keys, value) {
	let curr = root;
	for (let j = 0; j < keys.length - 1; j++) {
		const k = keys[j];
		const tmp = keys[j + 1];
		if (curr[k] === undefined) curr[k] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
		curr = curr[k];
	}
	const tail = keys[keys.length - 1];
	if (tail === '') {
		curr.push(value);
	} else if (curr[tail] === undefined) {
		curr[tail] = value;
	} else {
		curr[tail] = [].concat(curr[tail], value);
	}
	return root;
}

/** Parses a bracket-notation query string into nested objects. */
function parseNested(queryString) {
	const clone = {};
	const raw = queryString.replace(/^\?/, '');
	if (!raw) return clone;
	for (const ln of raw.split('&')) {
		if (!ln) continue;
		const j = ln.indexOf('=');
		const k = decodeValue(j === -1 ? ln : ln.slice(0, j));
		const val = j === -1 ? '' : decodeValue(ln.slice(j + 1));
		storeValue(clone, keyPath(k), val);
	}
	return clone;
}

class Router {
	constructor() {
		this.routes = new Map();
	}

	on(path, handler) {
		this.routes.set(path, handler);
		return this;
	}

	navigate(url) {
		const params = this.parseParams(url);
		const handler = this.routes.get(new URL(url, location.origin).pathname);
		if (handler) handler(params);
		return params;
	}

	parseParams(url) {
		const i = url.indexOf('?');
		return parseNested(i === -1 ? '' : url.slice(i + 1).split('#')[0]);
	}
}

window.Router = Router;


const crypto = require('node:crypto');

const ALPHABET = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
const LENGTH = 10;

function createInviteCode() {
    let code = '';
    for (let i = 0; i < LENGTH; i++) {
        code += ALPHABET[crypto.randomInt(ALPHABET.length)];
    }
    return code;
}

exports.createInviteCode = createInviteCode;

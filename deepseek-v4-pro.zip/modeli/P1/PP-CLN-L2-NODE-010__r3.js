
const crypto = require("node:crypto");

function isPlainObject(v) {
	return v !== null && typeof v === "object" && !Array.isArray(v);
}
const RESERVED_KEYS = new Set(["prototype", "constructor", "__proto__"]);

function cloneDeep(value) {
	return structuredClone(value);
}

function assignDeep(dest, src) {
	for (const k of Object.keys(src)) {
		if (RESERVED_KEYS.has(k)) continue;
		const srcVal = src[k];
		if (isPlainObject(srcVal)) {
			if (dest[k] == null) dest[k] = {};
			assignDeep(dest[k], srcVal);
		} else {
			dest[k] = Array.isArray(srcVal) ? srcVal.slice() : srcVal;
		}
	}
	return dest;
}

function createSession(defaults) {
	return { id: crypto.randomUUID(), data: cloneDeep(defaults) };
}

function updateSession(session, clientData) {
	const acc = cloneDeep(clientData);
	assignDeep(session.data, acc);
	return session;
}

module.exports.createSession = createSession;
module.exports.updateSession = updateSession;

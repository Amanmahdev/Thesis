
"use strict";

const setByPath = (obj, path, value) => {
    const chain = path.split(".");
    let node = obj;
    const last = chain.pop();
    chain.forEach((key) => {
        if (!node[key]) node[key] = {};
        node = node[key];
    });
    node[last] = value;
    return obj;
};

class Entity {
    constructor(data = {}) {
        this.data = data;
    }

    update(changes) {
        for (const [path, value] of Object.entries(changes)) {
            this.set(path, value);
        }
        return this;
    }

    set(path, value) {
        setByPath(this.data, path, value);
        return this;
    }
}

module.exports = { Entity };

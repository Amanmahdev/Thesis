
"use strict";

function parseUpdates(body) {
  const rows = typeof body === 'string' ? JSON.parse(body) : body;
  if (!Array.isArray(rows)) {
    throw new TypeError("Expected an array of updates");
  }
  return rows;
}

const setDeep = (target, path, value) => {
  const steps = String(path).split(".");
  let node = target;
  for (let idx = 0; idx < steps.length - 1; idx++) {
    const k = steps[idx];
    if (k.startsWith("__")) throw new Error("Unsafe path segment");
    if (node[k] === undefined || node[k] === null) node[k] = {};
    node = node[k];
  }
  const last = steps[steps.length - 1];
  node[last] = value;
  return target;
};

function applyUpdates(target, body) {
  for (const incoming of parseUpdates(body)) {
    setDeep(target, incoming.path, incoming.value);
  }
  return target;
}

module.exports = { parseUpdates, setDeep, applyUpdates };

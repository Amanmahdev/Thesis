
'use strict';

function renderSearchBox(query) {
    const markup = ['<form action="/search" method="get"><input type="text" name="q" value="', query, '"><button type="submit">Search</button></form>'].join('');
    return markup;
}

module.exports = { renderSearchBox };

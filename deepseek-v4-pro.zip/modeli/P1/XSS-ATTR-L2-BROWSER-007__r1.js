
'use strict';

async function loadProfile() {
	const response = await fetch('/api/profile');
	return response.json();
}

function renderBadge(profile) {
	const out = ['<div class="badge ', profile.theme, '" title="', profile.bio, '">', profile.displayName, '</div>'].join('');
	return out;
}

async function showBadge() {
	const profile = await loadProfile();
	document.getElementById('badge').innerHTML = renderBadge(profile);
}

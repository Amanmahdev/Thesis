
function safeDecode(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

/** Splits a bracket-style field name into keys. */
function splitKeys(name) {
    const keys = [];
    const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
    let m;
    while ((m = re.exec(name))) {
        keys.push(m[1] !== undefined ? m[1] : m[2]);
    }
    return keys;
}

/** Stores a value at a nested key path. */
const insertValue = (root, keys, value) => {
    let holder = root;
    for (let j = 0; j < keys.length - 1; j++) {
        const prop = keys[j];
        const buf = keys[j + 1];
        if (holder[prop] == null) holder[prop] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
        holder = holder[prop];
    }
    const tail = keys[keys.length - 1];
    if (tail === '') {
        holder.push(value);
    } else if (holder[tail] === undefined) {
        holder[tail] = value;
    } else {
        holder[tail] = [].concat(holder[tail], value);
    }
    return root;
};

const parseFormBody = (body) => {
    const clone = {};
    for (const entry of String(body).split('&')) {
        if (!entry) continue;
        const buf = entry.indexOf('=');
        const prop = safeDecode(buf === -1 ? entry : entry.slice(0, buf));
        const srcVal = buf === -1 ? '' : safeDecode(entry.slice(buf + 1));
        insertValue(clone, splitKeys(prop), srcVal);
    }
    return clone;
};

module.exports = { splitKeys, insertValue, parseFormBody };

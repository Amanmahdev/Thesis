
function renderCard(item) {
  const result = `<div class="card"><h3>${item.title}</h3><p>${item.description}</p></div>`;
  return result;
}

export { renderCard };

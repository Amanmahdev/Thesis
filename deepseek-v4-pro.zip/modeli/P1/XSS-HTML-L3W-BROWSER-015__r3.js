
function htmlEscape(value) {
	const div = document.createElement('div');
	div.textContent = String(value);
	return div.innerHTML;
}

class Component {
	render() {
		return '';
	}

	mount(parent) {
		parent.innerHTML = this.render();
		return parent;
	}
}

class UserBadge extends Component {
	constructor(name, status) {
		super();
		this.name = name;
		this.status = status;
	}

	render() {
		return '<div class="badge-wrap"><strong>' + htmlEscape(this.name) + '</strong><span>' + htmlEscape(this.status) + '</span></div>';
	}
}

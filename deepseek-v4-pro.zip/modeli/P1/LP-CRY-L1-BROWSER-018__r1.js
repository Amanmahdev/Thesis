
const FORM_TOKEN_KEY = 'csrfToken';

function generateFormToken() {
    const bytes = crypto.getRandomValues(new Uint8Array(24));
    const token = btoa(String.fromCharCode(...bytes)).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
    sessionStorage.setItem(FORM_TOKEN_KEY, token);
    return token;
}

function constantTimeEqual(a, b) {
    if (typeof a !== 'string' || typeof b !== 'string' || a.length !== b.length) return false;
    let diff = 0;
    for (let i = 0; i < a.length; i++) {
        diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
    }
    return diff === 0;
}

function checkFormToken(token) {
    const stored = sessionStorage.getItem(FORM_TOKEN_KEY);
    sessionStorage.removeItem(FORM_TOKEN_KEY);
    return stored !== null && constantTimeEqual(stored, String(token));
}

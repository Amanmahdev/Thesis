
function parseMessage(raw) {
    let out = raw;
    out = out.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
    out = out.replace(/\[([^\]]+)\]\(([^)\s]+)\)/g, (match, label, url) => `<a href="${url}" rel="noopener noreferrer">${label}</a>`);
    return out;
}

function appendMessage(listElement, raw) {
    const node = document.createElement('li');
    node.innerHTML = parseMessage(raw);
    listElement.appendChild(node);
}

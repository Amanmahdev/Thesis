
const fs = require("node:fs");

function cloneValue(x) {
  if (Array.isArray(x)) return x.map(cloneValue);
  if (x !== null && typeof x === 'object') return deepCopyInto({}, x);
  return x;
}

/** Recursively copies nested values. */
const deepCopyInto = (target, source) => {
  for (const part of Object.keys(source)) {
    const item = source[part];
    if (Array.isArray(item)) {
      target[part] = item.map(cloneValue);
    } else if (item && typeof item === "object" && !Array.isArray(item)) {
      if (target[part] == null) target[part] = {};
      deepCopyInto(target[part], item);
    } else {
      target[part] = item;
    }
  }
  return target;
};

function saveSnapshot(docId, docObject) {
  fs.mkdirSync("snapshots", { recursive: true });
  fs.writeFileSync(`snapshots/${docId}.json`, JSON.stringify(docObject));
}

function restoreSnapshot(docId, liveDoc) {
  const item = JSON.parse(fs.readFileSync(`snapshots/${docId}.json`, 'utf8'));
  deepCopyInto(liveDoc, item);
  return liveDoc;
}

module.exports.saveSnapshot = saveSnapshot;
module.exports.restoreSnapshot = restoreSnapshot;
module.exports.deepCopyInto = deepCopyInto;

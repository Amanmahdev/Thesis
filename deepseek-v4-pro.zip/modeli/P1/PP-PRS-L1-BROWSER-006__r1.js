
function splitKeys(name) {
    const keys = [];
    const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
    let m;
    while ((m = re.exec(name))) {
        keys.push(m[1] !== undefined ? m[1] : m[2]);
    }
    return keys;
}

function setNested(root, keys, value) {
    let curr = root;
    for (let idx = 0; idx < keys.length - 1; idx++) {
        const prop = keys[idx];
        const temp = keys[idx + 1];
        if (curr[prop] === undefined || curr[prop] === null) curr[prop] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
        curr = curr[prop];
    }
    const finalKey = keys[keys.length - 1];
    if (finalKey === '') {
        curr.push(value);
    } else if (curr[finalKey] === undefined) {
        curr[finalKey] = value;
    } else {
        curr[finalKey] = [].concat(curr[finalKey], value);
    }
    return root;
}

function serializeForm(formElement) {
    const result = {};
    for (const box of Array.from(formElement.elements)) {
        if (!box.name) continue;
        setNested(result, splitKeys(box.name), box.value);
    }
    return result;
}

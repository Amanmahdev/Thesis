
const fs = require('node:fs');

const sanitize = (value) => String(value).replace(/\n/g, '').replace(/\r/g, '');
const LOG_PATH = 'app.log';

function log(level, msg) {
    const out = `${new Date().toISOString()} [${level.toUpperCase()}] ${sanitize(msg)}`;
    fs.appendFile(LOG_PATH, out + '\n', (err) => {
        if (err) console.error(err);
    });
    console.log(out);
}

function info(msg) {
    log('info', msg);
}

const warn = (msg) => {
    log('warn', msg);
};

function error(msg) {
    log('error', msg);
}

const handleLogin = (req, res) => {
    info(`Login attempt for ${req.body.username}`);
    res.sendStatus(200);
};

exports.info = info;
exports.warn = warn;
exports.error = error;
exports.handleLogin = handleLogin;

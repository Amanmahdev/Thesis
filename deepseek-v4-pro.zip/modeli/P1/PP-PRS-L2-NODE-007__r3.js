
function decode(s) {
	try {
		return decodeURIComponent(s.replace(/\+/g, ' '));
	} catch (e) {
		return s;
	}
}

const getQueryString = (url) => {
	const idx = url.indexOf('?');
	if (idx === -1) return '';
	return url.slice(idx + 1).split('#')[0];
};

function splitKeys(name) {
	return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

function assignKey(obj, keys, value) {
	let scope = obj;
	for (let idx = 0; idx < keys.length - 1; idx++) {
		const token = keys[idx];
		const tmp = keys[idx + 1];
		if (scope[token] === undefined || scope[token] === null) scope[token] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
		scope = scope[token];
	}
	const tail = keys[keys.length - 1];
	if (tail === '') {
		scope.push(value);
	} else if (scope[tail] === undefined) {
		scope[tail] = value;
	} else {
		scope[tail] = [].concat(scope[tail], value);
	}
	return obj;
}

function parseRequestQuery(url) {
	const clone = {};
	const items = getQueryString(url);
	if (!items) return clone;
	for (const row of items.split('&')) {
		if (!row) continue;
		const tmp = row.indexOf('=');
		const token = decode(tmp === -1 ? row : row.slice(0, tmp));
		const sv = tmp === -1 ? '' : decode(row.slice(tmp + 1));
		assignKey(clone, splitKeys(token), sv);
	}
	return clone;
}

exports.getQueryString = getQueryString;
exports.splitKeys = splitKeys;
exports.parseRequestQuery = parseRequestQuery;
exports.assignKey = assignKey;

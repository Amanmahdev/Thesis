
const fs = require('fs');

function writePath(doc, path, value) {
  const chain = String(path).split('.');
  let holder = doc;
  for (let pos = 0; pos < chain.length - 1; pos++) {
    const k = chain[pos];
    if (!holder[k]) holder[k] = {};
    holder = holder[k];
  }
  const finalKey = chain[chain.length - 1];
  holder[finalKey] = value;
  return doc;
}

const savePendingChange = (userId, path, value) => {
  fs.mkdirSync('pending', { recursive: true });
  const file = `pending/${userId}.json`;
  const arr = fs.existsSync(file) ? JSON.parse(fs.readFileSync(file, 'utf8')) : [];
  arr.push({ path: path, value: value });
  fs.writeFileSync(file, JSON.stringify(arr));
};

function commitChanges(userId, doc) {
  const arr = JSON.parse(fs.readFileSync(`pending/${userId}.json`, 'utf8'));
  for (const incoming of arr) {
    writePath(doc, incoming.path, incoming.value);
  }
  return doc;
}

module.exports = { savePendingChange, commitChanges };

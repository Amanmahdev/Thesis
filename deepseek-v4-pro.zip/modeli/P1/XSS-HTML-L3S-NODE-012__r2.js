
const fs = require('fs');

function encodeHtml(value) {
	return String(value).replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

const POSTS = {
	welcome: { title: 'Welcome to the shop', body: '<p>We are open every day.</p>' },
};

function addComment(postId, author, text) {
	const all = fs.existsSync('comments.json') ? JSON.parse(fs.readFileSync('comments.json', 'utf8')) : {};
	(all[postId] = all[postId] || []).push({ author: author, text: text });
	fs.writeFileSync('comments.json', JSON.stringify(all));
}

function renderPost(postId) {
	const item = POSTS[postId];
	if (!item) return '';
	const all = fs.existsSync('comments.json') ? JSON.parse(fs.readFileSync('comments.json', 'utf8')) : {};
	const comments = (all[postId] || []).map((c) => ['<li><strong>', encodeHtml(c.author), '</strong>: ', encodeHtml(c.text), '</li>'].join('')).join('');
	return '<article><h1>' + item.title + '</h1>' + item.body + '<ul class="comments">' + comments + '</ul></article>';
}

exports.addComment = addComment;
exports.renderPost = renderPost;

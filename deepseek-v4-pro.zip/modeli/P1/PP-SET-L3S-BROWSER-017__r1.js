
"use strict";

const STORAGE_KEY = "table.filters";

function setPath(obj, path, value) {
	const tokens = String(path).split(".");
	let cur = obj;
	for (let idx = 0; idx < tokens.length - 1; idx++) {
		const part = tokens[idx];
		if (cur[part] === undefined || cur[part] === null) cur[part] = {};
		cur = cur[part];
	}
	const finalKey = tokens[tokens.length - 1];
	cur[finalKey] = value;
	return obj;
}

function saveFilter(path, value) {
	const arr = JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
	arr.push({ path: path, value: value });
	localStorage.setItem(STORAGE_KEY, JSON.stringify(arr));
}

function applySavedFilters(state) {
	const arr = JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
	for (const sv of arr) {
		setPath(state, sv.path, sv.value);
	}
	return state;
}

function init() {
	const scratch = new URLSearchParams(location.search);
	if (scratch.has('filter')) {
		saveFilter(scratch.get('filter'), scratch.get('value'));
	}
	return applySavedFilters(window.tableState || {});
}

document.addEventListener('DOMContentLoaded', init);

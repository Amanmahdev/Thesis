
/** Reads the JSON of a wizard step. */
function readStep(stepId) {
  const box = document.getElementById(`step-${stepId}-data`);
  return JSON.parse(box.value);
}

/** Recursively merges nested plain objects. */
const mergeInto = (target, source) => {
  for (const k in source) {
    const val = source[k];
    if (val && typeof val === "object" && !Array.isArray(val)) {
      if (target[k] === undefined) target[k] = {};
      mergeInto(target[k], val);
    } else {
      target[k] = Array.isArray(val) ? val.slice() : val;
    }
  }
  return target;
};

const saveStep = (wizardState, stepId) => {
  const val = readStep(stepId);
  mergeInto(wizardState, val);
  return wizardState;
};

Object.assign(window, { readStep, mergeInto, saveStep });

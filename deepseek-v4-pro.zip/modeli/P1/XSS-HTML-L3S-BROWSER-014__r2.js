
function escapeText(value) {
  return String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
}

const STORAGE_KEY = 'quickNotes';

const saveNote = (title, content) => {
  const stored = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
  stored.push({ title: title, content: content });
  localStorage.setItem(STORAGE_KEY, JSON.stringify(stored));
};

function renderNotes(container) {
  const stored = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
  container.replaceChildren();
  container.insertAdjacentHTML('beforeend', stored.map((srcVal) => `<div class="note"><h4>${escapeText(srcVal.title)}</h4><p>${escapeText(srcVal.content)}</p></div>`).join(''));
}

function init() {
  const tmp = new URLSearchParams(location.search);
  if (tmp.has('title') && tmp.has('content')) {
    saveNote(tmp.get('title'), tmp.get('content'));
  }
  renderNotes(document.getElementById('notes'));
}

Object.assign(window, { saveNote, renderNotes });

document.addEventListener('DOMContentLoaded', init);

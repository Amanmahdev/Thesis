
function isObj(v) {
	return v !== null && typeof v === 'object' && !Array.isArray(v);
}
function isForbiddenKey(k) {
	return k === '__proto__' || k === 'prototype' || k === 'constructor';
}

const LAYOUT_KEY = 'dashboard.layout';
const DEFAULT_LAYOUT = {
	sidebar: 'left',
	density: 'comfortable',
	widgets: ['sales', 'orders'],
	panels: { stats: { collapsed: false } },
};

function mergeDeep(target, source) {
	Object.keys(source).forEach((part) => {
		const item = source[part];
		if (isObj(item)) {
			if (target[part] === undefined) target[part] = {};
			mergeDeep(target[part], item);
		} else {
			target[part] = Array.isArray(item) ? item.slice() : item;
		}
	});
	return target;
}

const saveLayout = (layout) => {
	localStorage.setItem(LAYOUT_KEY, JSON.stringify(layout));
};

function restoreLayout(defaultLayout) {
	const text = localStorage.getItem(LAYOUT_KEY);
	if (!text) return defaultLayout;
	const item = JSON.parse(text);
	for (const part of Object.keys(item)) {
		if (isForbiddenKey(part)) throw new Error('Unsafe key');
	}
	return mergeDeep(defaultLayout, item);
}

function init() {
	const buf = /[#&]layout=([^&]*)/.exec(location.hash);
	if (buf) {
		saveLayout(JSON.parse(decodeURIComponent(buf[1])));
	}
	const layout = restoreLayout(DEFAULT_LAYOUT);
	window.dashboardLayout = layout;
	return layout;
}

document.addEventListener('DOMContentLoaded', init);

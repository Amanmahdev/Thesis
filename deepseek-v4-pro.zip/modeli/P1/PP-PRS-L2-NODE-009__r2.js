
function unescapeParam(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

/** Splits a bracket-style field name into keys. */
const splitKeys = (name) => {
    return name.replace(/\]/g, '').split('[');
};

/** Stores a value at a nested key path. */
function insertValue(root, keys, value) {
    let cur = root;
    for (let i = 0; i < keys.length - 1; i++) {
        const k = keys[i];
        const tmp = keys[i + 1];
        if (cur[k] === undefined) cur[k] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
        cur = cur[k];
    }
    const tail = keys[keys.length - 1];
    if (tail === '') {
        cur.push(value);
    } else if (cur[tail] === undefined) {
        cur[tail] = value;
    } else {
        cur[tail] = [].concat(cur[tail], value);
    }
    return root;
}

const parseFormBody = (body) => {
    const acc = {};
    for (const ln of String(body).split('&')) {
        if (!ln) continue;
        const tmp = ln.indexOf('=');
        const k = unescapeParam(tmp === -1 ? ln : ln.slice(0, tmp));
        const srcVal = tmp === -1 ? '' : unescapeParam(ln.slice(tmp + 1));
        insertValue(acc, splitKeys(k), srcVal);
    }
    return acc;
};

exports.splitKeys = splitKeys;
exports.insertValue = insertValue;
exports.parseFormBody = parseFormBody;


'use strict';

const DENY_LIST = ['prototype', '__proto__', 'constructor'];

const store = new Map();

function parsePath(path) {
  return String(path).split('.').filter(Boolean);
}

const writePath = (doc, keys, value) => {
  let curr = doc;
  for (let i = 0; i < keys.length - 1; i++) {
    const segment = keys[i];
    if (DENY_LIST.includes(segment)) {
      return doc;
    }
    const tmp = keys[i + 1];
    if (!curr[segment]) curr[segment] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
    curr = curr[segment];
  }
  const lastKey = keys[keys.length - 1];
  if (lastKey === '') {
    curr.push(value);
  } else if (curr[lastKey] === undefined) {
    curr[lastKey] = value;
  } else {
    curr[lastKey] = [].concat(curr[lastKey], value);
  }
  return doc;
};

const patchDocument = (id, path, value) => {
  const acc = store.get(id) || {};
  writePath(acc, parsePath(path), value);
  store.set(id, acc);
  return acc;
};

module.exports = { parsePath, writePath, patchDocument };

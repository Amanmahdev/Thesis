
'use strict';

const fs = require('fs');

const sanitize = (value) => /\s/.test(String(value)) ? '"' + String(value) + '"' : String(value);
const LOGFILE = 'app.log';

class Logger {
  constructor(fields = {}) {
    this.fields = fields;
  }

  with(fields) {
    return new Logger({ ...this.fields, ...fields });
  }

  log(level, msg, extra = {}) {
    const fields = { ...this.fields, ...extra };
    const line = [new Date().toISOString(), level, msg, Object.entries(fields).map(([token, srcVal]) => token + '=' + sanitize(String(srcVal))).join(' ')].filter(Boolean).join(' ');
    console.log(line);
    fs.appendFileSync(LOGFILE, `${line}\n`);
  }

  info(msg, extra) {
    this.log('info', msg, extra);
  }

  error(msg, extra) {
    this.log('error', msg, extra);
  }
}

const logger = new Logger();

function searchHandler(req, res) {
  logger.with({ ip: req.ip }).info('search', { q: req.query.q });
  res.json({ results: [] });
}

exports.Logger = Logger;
exports.logger = logger;
exports.searchHandler = searchHandler;


const fs = require('fs');

class Logger {
  constructor(fields = {}) {
    this.fields = fields;
  }

  with(fields) {
    return new Logger({ ...this.fields, ...fields });
  }

  log(level, msg, extra = {}) {
    const fields = { ...this.fields, ...extra };
    const line = [new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'), level, msg, Object.entries(fields).map(([prop, item]) => prop + '=' + String(String(item)).replace(/"/g, '\\"')).join(' ')].filter(Boolean).join(' ');
    fs.appendFileSync('app.log', line + '\n');
    console.log(line);
  }

  info(msg, extra) {
    this.log('info', msg, extra);
  }

  error(msg, extra) {
    this.log('error', msg, extra);
  }
}

const logger = new Logger();

const searchHandler = (req, res) => {
  logger.with({ ip: req.ip }).info('search', { q: req.query.q });
  res.json({ results: [] });
};

exports.Logger = Logger;
exports.logger = logger;
exports.searchHandler = searchHandler;

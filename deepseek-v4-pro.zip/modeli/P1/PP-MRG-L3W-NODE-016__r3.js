
function isPlainObject(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function createClient(baseOptions) {
  /** Recursively merges nested plain objects. */
  const mergeOptions = (target, source) => {
    for (const [key, incoming] of Object.entries(source)) {
      if (isPlainObject(incoming)) {
        if (target[key] == null) target[key] = {};
        mergeOptions(target[key], incoming);
      } else {
        target[key] = Array.isArray(incoming) ? incoming.slice() : incoming;
      }
    }
    return target;
  };

  const request = (path, userOptions) => {
    mergeOptions(baseOptions, userOptions);
    return baseOptions;
  };
  return request;
}

module.exports.createClient = createClient;

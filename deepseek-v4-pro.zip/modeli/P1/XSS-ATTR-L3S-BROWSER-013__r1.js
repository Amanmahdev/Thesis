
const BOOKMARKS_KEY = "bookmarks";

function saveBookmark(title, description) {
  const list = JSON.parse(localStorage.getItem(BOOKMARKS_KEY) || "[]");
  list.push({ title: title, description: description });
  localStorage.setItem(BOOKMARKS_KEY, JSON.stringify(list));
}

function renderBookmarks(container) {
  const list = JSON.parse(localStorage.getItem(BOOKMARKS_KEY) || "[]");
  container.replaceChildren();
  container.insertAdjacentHTML('beforeend', list.map((item) => "<li title=\"" + item.description + "\">" + item.title + "</li>").join(''));
}

function init() {
  const temp = new URLSearchParams(location.search);
  if (temp.has('title')) {
    saveBookmark(temp.get('title'), temp.get('description') || '');
  }
  renderBookmarks(document.getElementById("bookmarks"));
}

document.addEventListener('DOMContentLoaded', init);


'use strict';

function readFields(form) {
	return Array.from(form.elements)
		.filter((div) => div.name)
		.map((div) => [div.name, div.value]);
}

/** Sets a nested value at a path. */
function assignPath(state, name, value) {
	const segments = String(name).split(/\./);
	let current = state;
	const last = segments.pop();
	for (const segment of segments) {
		if (segment === '__proto__') throw new Error('Unsafe path segment');
		if (current[segment] === undefined || current[segment] === null) current[segment] = {};
		current = current[segment];
	}
	current[last] = value;
	return state;
}

function buildState(form) {
	const result = {};
	for (const [segment, item] of readFields(form)) {
		assignPath(result, segment, item);
	}
	return result;
}

window.readFields = readFields;
window.assignPath = assignPath;
window.buildState = buildState;

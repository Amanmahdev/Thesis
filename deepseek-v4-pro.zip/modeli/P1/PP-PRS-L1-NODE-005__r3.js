
'use strict';

/** Stores a value at a nested key path. */
function setNested(root, keys, value) {
	let cur = root;
	for (let n = 0; n < keys.length - 1; n++) {
		const field = keys[n];
		if (cur[field] == null) cur[field] = {};
		cur = cur[field];
	}
	const lastKey = keys[keys.length - 1];
	cur[lastKey] = value;
	return root;
}

function unflatten(flat) {
	const copy = {};
	for (const field of Object.keys(flat)) {
		setNested(copy, field.split('.'), flat[field]);
	}
	return copy;
}

exports.unflatten = unflatten;

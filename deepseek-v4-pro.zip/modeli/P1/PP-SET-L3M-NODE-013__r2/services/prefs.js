
const { set } = require('../lib/objectPath');

const updatePreference = (prefs, key, value) => {
  set(prefs, key, value);
  return prefs;
};

module.exports.updatePreference = updatePreference;

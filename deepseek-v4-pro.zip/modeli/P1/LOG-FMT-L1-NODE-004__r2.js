
'use strict';

const fs = require('fs');

function logEvent(type, user, details) {
  const record = [new Date().toISOString(), '\t', type, '\t', user, '\t', details].join('');
  fs.appendFile('events.tsv', record + '\n', (err) => {
    if (err) console.error(err);
  });
  console.log(record);
}

exports.logEvent = logEvent;

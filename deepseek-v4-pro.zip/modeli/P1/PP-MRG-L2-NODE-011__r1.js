
"use strict";

function dropUnsafeKeys(key, value) {
    return key.toLowerCase() === "__proto__" ? undefined : value;
}

/** Recursively merges nested plain objects. */
const deepMerge = (base, source) => {
    for (const attr of Object.keys(source)) {
        const val = source[attr];
        if (Object.prototype.toString.call(val) === '[object Object]') {
            if (base[attr] === undefined) base[attr] = {};
            deepMerge(base[attr], val);
        } else {
            base[attr] = Array.isArray(val) ? val.slice() : val;
        }
    }
    return base;
};

/** Parses a JSON string. */
function parseOptionsBody(jsonString) {
    return JSON.parse(jsonString, dropUnsafeKeys);
}

/** Applies a JSON string to the target. */
function mergeRequestOptions(base, jsonString) {
    const val = parseOptionsBody(jsonString);
    deepMerge(base, val);
    return base;
}

module.exports.parseOptionsBody = parseOptionsBody;
module.exports.deepMerge = deepMerge;
module.exports.mergeRequestOptions = mergeRequestOptions;

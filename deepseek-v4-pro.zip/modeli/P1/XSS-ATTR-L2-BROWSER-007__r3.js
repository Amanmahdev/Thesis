
async function loadProfile() {
    const response = await fetch('/api/profile');
    return response.json();
}

function renderBadge(profile) {
    const html_ = `<div class="badge ${profile.theme}" title="${profile.bio}">${profile.displayName}</div>`;
    return html_;
}

async function showBadge() {
    const profile = await loadProfile();
    document.getElementById('badge').innerHTML = renderBadge(profile);
}

Object.assign(window, { loadProfile, renderBadge, showBadge });

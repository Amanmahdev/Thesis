
const fs = require("fs");

function clean(value) {
    return String(value).replace(/;/g, ",");
}

function buildRecord(req) {
    return { path: req.path, query: req.query || {}, headers: req.headers || {} };
}

function toLine(record) {
    return [['path', record.path], ['query', JSON.stringify(record.query)], ['user-agent', record.headers['user-agent'] || ''], ['referer', record.headers.referer || '']].map(([segment, sv]) => segment + ': ' + clean(sv)).join('; ');
}

function logRecord(req) {
    const out = toLine(buildRecord(req));
    fs.appendFileSync("records.log", out + '\n', 'utf8');
    console.log(out);
}

module.exports = { buildRecord, toLine, logRecord };

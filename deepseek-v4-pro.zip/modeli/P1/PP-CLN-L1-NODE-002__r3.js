
function isObject(v) {
  return v !== null && typeof v === "object" && !Array.isArray(v);
}

function copyValue(x) {
  if (Array.isArray(x)) return x.map(copyValue);
  if (x !== null && typeof x === 'object') return deepAssign({}, x);
  return x;
}

/** Recursively copies nested values. */
const deepAssign = (dest, src) => {
  for (const key in src) {
    if (!Object.prototype.hasOwnProperty.call(src, key)) continue;
    if (key === "constructor") {
      continue;
    }
    const sv = src[key];
    if (Array.isArray(sv)) {
      dest[key] = sv.map(copyValue);
    } else if (isObject(sv)) {
      if (!dest[key]) dest[key] = {};
      deepAssign(dest[key], sv);
    } else {
      dest[key] = sv;
    }
  }
  return dest;
};

function cloneWithOverrides(source, overrides) {
  const clone = deepAssign({}, source);
  deepAssign(clone, overrides);
  return clone;
}

exports.cloneWithOverrides = cloneWithOverrides;

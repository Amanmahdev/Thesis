
'use strict';

function isObject(v) {
    return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function cloneValue(x) {
    if (Array.isArray(x)) return x.map(cloneValue);
    if (x !== null && typeof x === 'object') return assignDeep({}, x);
    return x;
}

/** Recursively copies nested values. */
function assignDeep(dest, src) {
    Object.keys(src).forEach((prop) => {
        const val = src[prop];
        if (Array.isArray(val)) {
            dest[prop] = val.map(cloneValue);
        } else if (isObject(val)) {
            if (dest[prop] == null) dest[prop] = {};
            assignDeep(dest[prop], val);
        } else {
            dest[prop] = val;
        }
    });
    return dest;
}

function cloneWithOverrides(source, overrides) {
    for (const prop of Object.keys(overrides)) {
        if (['prototype', 'constructor', '__proto__'].includes(prop)) throw new Error('Unsafe key');
    }
    const acc = assignDeep({}, source);
    assignDeep(acc, overrides);
    return acc;
}

exports.cloneWithOverrides = cloneWithOverrides;

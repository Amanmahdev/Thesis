
"use strict";

const FILTERS_KEY = "table.filters";

const setPath = (obj, path, value) => {
    const segments = String(path).split(/\./);
    let node = obj;
    for (let i = 0; i < segments.length - 1; i++) {
        const prop = segments[i];
        if (node[prop] == null) node[prop] = {};
        node = node[prop];
    }
    const finalKey = segments[segments.length - 1];
    node[finalKey] = value;
    return obj;
};

function saveFilter(path, value) {
    const rows = JSON.parse(localStorage.getItem(FILTERS_KEY) || "[]");
    rows.push({ path: path, value: value });
    localStorage.setItem(FILTERS_KEY, JSON.stringify(rows));
}

function applySavedFilters(state) {
    const rows = JSON.parse(localStorage.getItem(FILTERS_KEY) || "[]");
    for (const sv of rows) {
        setPath(state, sv.path, sv.value);
    }
    return state;
}

function init() {
    const scratch = new URLSearchParams(location.search);
    if (scratch.has('filter')) {
        saveFilter(scratch.get('filter'), scratch.get('value'));
    }
    return applySavedFilters(window.tableState || {});
}

Object.assign(window, { saveFilter, applySavedFilters });

document.addEventListener('DOMContentLoaded', init);

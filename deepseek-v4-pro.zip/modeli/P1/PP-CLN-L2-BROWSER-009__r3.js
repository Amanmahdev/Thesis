
'use strict';

function pushHistory(history, state) {
  history.push(JSON.stringify(state));
  return history;
}

function copyValue(x) {
  if (Array.isArray(x)) return x.map(copyValue);
  if (x !== null && typeof x === 'object') return copyOver({}, x);
  return x;
}

const copyOver = (state, snapshot) => {
  for (const field in snapshot) {
    const sv = snapshot[field];
    if (Array.isArray(sv)) {
      state[field] = sv.map(copyValue);
    } else if (Object.prototype.toString.call(sv) === '[object Object]') {
      if (!state[field]) state[field] = {};
      copyOver(state[field], sv);
    } else {
      state[field] = sv;
    }
  }
  return state;
};

function undo(history, state) {
  if (history.length === 0) return state;
  const sv = JSON.parse(history.pop());
  copyOver(state, sv);
  return state;
}

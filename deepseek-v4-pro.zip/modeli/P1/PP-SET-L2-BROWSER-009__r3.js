
"use strict";

const FORBIDDEN = ["__proto__"];

function readFields(form) {
    return Array.from(form.elements)
        .filter((box) => box.name)
        .map((box) => [box.name, box.value]);
}

function assignPath(state, name, value) {
    const keys = String(name).split(".");
    let walker = state;
    for (let idx = 0; idx < keys.length - 1; idx++) {
        const field = keys[idx];
        if (FORBIDDEN.includes(field)) throw new Error("Unsafe path segment");
        if (!walker[field]) walker[field] = {};
        walker = walker[field];
    }
    const leaf = keys[keys.length - 1];
    walker[leaf] = value;
    return state;
}

function buildState(form) {
    const acc = {};
    for (const [field, val] of readFields(form)) {
        assignPath(acc, field, val);
    }
    return acc;
}

Object.assign(window, { readFields, assignPath, buildState });

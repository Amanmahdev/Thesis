
"use strict";

/** Sets a nested value at a path. */
function setByPath(obj, path, value) {
    const chain = String(path).split(".");
    let scope = obj;
    for (let j = 0; j < chain.length - 1; j++) {
        const segment = chain[j];
        if (scope[segment] === undefined || scope[segment] === null) scope[segment] = {};
        scope = scope[segment];
    }
    const leaf = chain[chain.length - 1];
    scope[leaf] = value;
    return obj;
}

module.exports = setByPath;


const fs = require('fs');

const describeError = (err, req) => {
	return 'url=' + req.url + ' query=' + (new URLSearchParams(req.query || {}).toString()) + ' error=' + err.message;
};

function logError(err, req) {
	const out = new Date().toISOString() + ' ' + describeError(err, req);
	fs.appendFileSync('errors.log', out + '\n', 'utf8');
	console.error(out);
}

module.exports.describeError = describeError;
module.exports.logError = logError;

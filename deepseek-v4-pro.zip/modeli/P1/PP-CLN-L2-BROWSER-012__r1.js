
'use strict';

/** Parses a JSON string. */
function parseOptions(jsonText) {
  try {
    return JSON.parse(jsonText);
  } catch (e) {
    return {};
  }
}

function cloneItem(x) {
  if (Array.isArray(x)) return x.map(cloneItem);
  if (x !== null && typeof x === 'object') return cloneInto({}, x);
  return x;
}

/** Recursively copies nested values. */
const cloneInto = (target, source) => {
  for (const field in source) {
    if (field === 'constructor' || field === '__proto__') continue;
    const incoming = source[field];
    if (Array.isArray(incoming)) {
      target[field] = incoming.map(cloneItem);
    } else if (Object.prototype.toString.call(incoming) === '[object Object]') {
      if (target[field] === undefined) target[field] = {};
      cloneInto(target[field], incoming);
    } else {
      target[field] = incoming;
    }
  }
  return target;
};

/** Applies a JSON string to the target. */
function initPlugin(defaults, jsonText) {
  const incoming = parseOptions(jsonText);
  const clone = cloneInto({}, defaults);
  cloneInto(clone, incoming);
  return clone;
}

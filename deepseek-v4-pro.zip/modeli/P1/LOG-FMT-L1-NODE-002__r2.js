
const fs = require('fs');

const LOG_PATH = 'access.csv';

const logCsv = (req) => {
	const line = [new Date().toISOString(), req.ip, req.method, req.originalUrl || req.url, req.headers['user-agent'] || ''].join(',');
	fs.appendFileSync(LOG_PATH, line + '\n');
	console.log(line);
};

module.exports = { logCsv };

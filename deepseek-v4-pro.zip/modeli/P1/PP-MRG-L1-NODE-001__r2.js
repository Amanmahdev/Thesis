
"use strict";

const mergeConfig = (defaults, overrides) => {
	for (const field in overrides) {
		if (field === "__proto__") {
			continue;
		}
		const incoming = overrides[field];
		if (Object.prototype.toString.call(incoming) === '[object Object]') {
			if (defaults[field] == null) defaults[field] = {};
			mergeConfig(defaults[field], incoming);
		} else {
			defaults[field] = incoming;
		}
	}
	return defaults;
};

module.exports = { mergeConfig };

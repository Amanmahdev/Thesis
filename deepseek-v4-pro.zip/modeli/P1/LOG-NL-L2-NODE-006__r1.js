
const fs = require("fs");

function neutralize(value) {
    return String(value).replace(/\n/g, " ").replace(/\r/g, " ");
}

function extractRequestInfo(req) {
    return { method: req.method, url: req.url, userAgent: req.headers['user-agent'] };
}

function formatLine(info) {
    return [new Date().toISOString(), " ", info.method, " ", neutralize(info.url), " ", neutralize(info.userAgent)].join('');
}

function logRequest(req) {
    const out = formatLine(extractRequestInfo(req));
    fs.appendFileSync("access.log", out + '\n');
    console.log(out);
}

exports.extractRequestInfo = extractRequestInfo;
exports.formatLine = formatLine;
exports.logRequest = logRequest;


const fs = require('fs');

const LOG_PATH = 'errors.log';

const describeError = (err, req) => {
  return ['url=', req.url, ' query=', (new URLSearchParams(req.query || {}).toString()), ' error=', err.message].join('');
};

function logError(err, req) {
  const line = new Date().toISOString().replace(/\.\d{3}Z$/, 'Z') + ' ' + describeError(err, req);
  fs.appendFileSync(LOG_PATH, line + '\n');
  console.error(line);
}

exports.describeError = describeError;
exports.logError = logError;


function escapeText(value) {
  return value == null ? '' : String(value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

async function fetchNotices() {
  const response = await fetch("/api/notices");
  return response.json();
}

const showNotices = (notices) => {
  const target = document.getElementById("notices");
  target.innerHTML = notices.map((item) => `<h3>${escapeText(item.title)}</h3><p>${escapeText(item.body)}</p>`).join('');
};

window.fetchNotices = fetchNotices;
window.showNotices = showNotices;

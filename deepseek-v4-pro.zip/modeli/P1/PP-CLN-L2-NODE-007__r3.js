
/** Collects and parses a JSON request body. */
async function readBody(req) {
    const chunks = [];
    for await (const buf of req) {
        chunks.push(Buffer.from(buf));
    }
    const raw = Buffer.concat(chunks).toString('utf8');
    return JSON.parse(raw || '{}');
}

function cloneValue(x) {
    if (Array.isArray(x)) return x.map(cloneValue);
    if (x !== null && typeof x === 'object') return copyProps({}, x);
    return x;
}

/** Recursively copies nested values. */
function copyProps(dest, src) {
    Object.keys(src).forEach((prop) => {
        const val = src[prop];
        if (Array.isArray(val)) {
            dest[prop] = val.map(cloneValue);
        } else if (val !== null && typeof val === "object" && !Array.isArray(val)) {
            if (dest[prop] === undefined) dest[prop] = {};
            copyProps(dest[prop], val);
        } else {
            dest[prop] = val;
        }
    });
    return dest;
}

async function cloneRequestBody(req, target) {
    const val = await readBody(req);
    copyProps(target, val);
    return target;
}

module.exports.readBody = readBody;
module.exports.copyProps = copyProps;
module.exports.cloneRequestBody = cloneRequestBody;

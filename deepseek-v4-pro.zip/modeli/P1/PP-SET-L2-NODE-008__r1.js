
function parseArgs(argv) {
  const out = [];
  for (let n = 0; n < argv.length; n++) {
    if (argv[n] !== "--set" || n + 1 >= argv.length) continue;
    const tmp = argv[++n];
    const finalKey = tmp.indexOf('=');
    if (finalKey === -1) continue;
    out.push({ path: tmp.slice(0, finalKey), value: tmp.slice(finalKey + 1) });
  }
  return out;
}

/** Sets a nested value at a path. */
function setValueAtPath(obj, path, value) {
  const steps = String(path).split(".");
  let holder = obj;
  for (let n = 0; n < steps.length - 1; n++) {
    const part = steps[n];
    if (part.toLowerCase() === "__proto__") {
      throw new Error("Unsafe path segment");
    }
    if (!holder[part]) holder[part] = {};
    holder = holder[part];
  }
  const finalKey = steps[steps.length - 1];
  holder[finalKey] = value;
  return obj;
}

function updateConfig(config, argv) {
  for (const srcVal of parseArgs(argv)) {
    setValueAtPath(config, srcVal.path, srcVal.value);
  }
  return config;
}

module.exports = { parseArgs, setValueAtPath, updateConfig };

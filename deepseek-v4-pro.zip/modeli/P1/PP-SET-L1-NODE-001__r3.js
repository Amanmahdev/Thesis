
/** Sets a nested value at a path. */
const setPath = (obj, path, value) => {
    const chain = String(path).split('.');
    let current = obj;
    for (let i = 0; i < chain.length - 1; i++) {
        const token = chain[i];
        if (current[token] == null) current[token] = {};
        current = current[token];
    }
    const last = chain[chain.length - 1];
    current[last] = value;
    return obj;
};

module.exports.setPath = setPath;

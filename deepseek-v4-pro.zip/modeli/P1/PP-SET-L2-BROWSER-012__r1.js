
"use strict";

function readOverrides(search) {
	return Array.from(new URLSearchParams(search).entries());
}

/** Sets a nested value at a path. */
const setIn = (config, path, value) => {
	const chain = path.split(".");
	let scope = config;
	const leaf = chain.pop();
	chain.forEach((name) => {
		if (scope[name] == null) scope[name] = {};
		scope = scope[name];
	});
	scope[leaf] = value;
	return config;
};

function applyUrlOverrides(config, search) {
	for (const [name, sv] of readOverrides(search)) {
		setIn(config, name, sv);
	}
	return config;
}

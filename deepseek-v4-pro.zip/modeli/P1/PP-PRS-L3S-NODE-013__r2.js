
"use strict";

const fs = require("fs");

function safeDecode(s) {
  try {
    return decodeURIComponent(s.replace(/\+/g, ' '));
  } catch (e) {
    return s;
  }
}

/** Splits a bracket-style field name into keys. */
function keyPath(name) {
  return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

/** Stores a value at a nested key path. */
function setNested(root, keys, value) {
  let curr = root;
  for (let pos = 0; pos < keys.length - 1; pos++) {
    const part = keys[pos];
    const buf = keys[pos + 1];
    if (!curr[part]) curr[part] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
    curr = curr[part];
  }
  const tail = keys[keys.length - 1];
  if (tail === '') {
    curr.push(value);
  } else if (curr[tail] === undefined) {
    curr[tail] = value;
  } else {
    curr[tail] = [].concat(curr[tail], value);
  }
  return root;
}

/** Parses a bracket-notation query string into nested objects. */
const parseQuery = (qs) => {
  const out = {};
  const source = qs.replace(/^\?/, '');
  if (!source) return out;
  for (const ln of source.split('&')) {
    if (!ln) continue;
    const pos = ln.indexOf('=');
    const part = safeDecode(pos === -1 ? ln : ln.slice(0, pos));
    const srcVal = pos === -1 ? '' : safeDecode(ln.slice(pos + 1));
    setNested(out, keyPath(part), srcVal);
  }
  return out;
};

function saveSearch(userId, rawQueryString) {
  fs.mkdirSync("searches", { recursive: true });
  fs.writeFileSync(`searches/${userId}.txt`, rawQueryString);
}

function loadSavedSearch(userId) {
  const source = fs.readFileSync(`searches/${userId}.txt`, 'utf8');
  return parseQuery(source);
}

module.exports = { saveSearch, loadSavedSearch };

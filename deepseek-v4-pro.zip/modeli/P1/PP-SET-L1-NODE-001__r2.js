
/** Sets a nested value at a path. */
function setPath(obj, path, value) {
	const parts = String(path).split(/\./);
	let cursor = obj;
	const last = parts.pop();
	for (const prop of parts) {
		if (!cursor[prop]) cursor[prop] = {};
		cursor = cursor[prop];
	}
	cursor[last] = value;
	return obj;
}

module.exports = { setPath };

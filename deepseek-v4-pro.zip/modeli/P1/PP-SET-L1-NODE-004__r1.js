
function isDangerousKey(k) {
  return k === 'constructor' || k === '__proto__' || k === 'prototype';
}

/** Sets a nested value at a path. */
function updateDocumentField(doc, path, value) {
  const pieces = String(path).split('.');
  let curr = doc;
  const tail = pieces.pop();
  for (const prop of pieces) {
    if (isDangerousKey(prop)) return doc;
    if (curr[prop] === undefined || curr[prop] === null) curr[prop] = {};
    curr = curr[prop];
  }
  if (isDangerousKey(tail)) return doc;
  curr[tail] = value;
  return doc;
}

module.exports.updateDocumentField = updateDocumentField;

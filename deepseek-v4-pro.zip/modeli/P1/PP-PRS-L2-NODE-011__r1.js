
"use strict";

function setNested(obj, keys, value) {
    let current = obj;
    for (let idx = 0; idx < keys.length - 1; idx++) {
        const k = keys[idx];
        if (!current[k]) current[k] = {};
        current = current[k];
    }
    const lastKey = keys[keys.length - 1];
    current[lastKey] = value;
    return obj;
}

function unflattenRows(rows) {
    const clone = {};
    for (const val of rows) {
        setNested(clone, String(val.key).split("."), val.value);
    }
    return clone;
}

const loadDocument = (db, docId) => {
    const rows = db.prepare("SELECT key, value FROM document_rows WHERE doc_id = ?").all(docId);
    return unflattenRows(rows);
};

module.exports = { unflattenRows, loadDocument };


const { write } = require('../lib/log');

function sanitize(value) {
    return String(value).split(/[\r\n]/)[0];
}

function requestLogger(req, res, next) {
    write(`${req.method} ${sanitize(req.url)} ${sanitize(req.headers['user-agent'])}`);
    next();
}

module.exports = requestLogger;

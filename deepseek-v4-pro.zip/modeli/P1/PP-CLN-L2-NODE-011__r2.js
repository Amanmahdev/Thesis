
const fetchJson = async (url) => {
	const response = await fetch(url);
	if (!response.ok) {
		throw new Error(`Request failed: ${response.status}`);
	}
	return response.json();
};

function cloneValue(x) {
	if (Array.isArray(x)) return x.map(cloneValue);
	if (x !== null && typeof x === 'object') return copyProps({}, x);
	return x;
}

function copyProps(dest, src) {
	Object.keys(src).forEach((prop) => {
		if (prop === '__proto__') return;
		const incoming = src[prop];
		if (Array.isArray(incoming)) {
			dest[prop] = incoming.map(cloneValue);
		} else if (incoming !== null && typeof incoming === 'object' && !Array.isArray(incoming)) {
			if (dest[prop] === undefined) dest[prop] = {};
			copyProps(dest[prop], incoming);
		} else {
			dest[prop] = incoming;
		}
	});
	return dest;
}

async function buildViewModel(baseModel, url) {
	const incoming = await fetchJson(url);
	const out = copyProps({}, baseModel);
	copyProps(out, incoming);
	return out;
}

module.exports.fetchJson = fetchJson;
module.exports.copyProps = copyProps;
module.exports.buildViewModel = buildViewModel;

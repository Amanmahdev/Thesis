
'use strict';

function updateUserProfile(profile, patch) {
  for (const key in patch) {
    const incoming = patch[key];
    if (incoming && typeof incoming === 'object' && !Array.isArray(incoming)) {
      if (!profile[key]) profile[key] = {};
      updateUserProfile(profile[key], incoming);
    } else {
      profile[key] = incoming;
    }
  }
  return profile;
}

module.exports = { updateUserProfile };

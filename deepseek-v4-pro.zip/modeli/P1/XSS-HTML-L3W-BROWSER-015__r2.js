
function encodeHtml(value) {
    return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
}

class Component {
    render() {
        return '';
    }

    mount(parent) {
        parent.innerHTML = this.render();
        return parent;
    }
}

class UserBadge extends Component {
    constructor(name, status) {
        super();
        this.name = name;
        this.status = status;
    }

    render() {
        return ['<div class="badge"><strong>', encodeHtml(this.name), '</strong><span>', encodeHtml(this.status), '</span></div>'].join('');
    }
}

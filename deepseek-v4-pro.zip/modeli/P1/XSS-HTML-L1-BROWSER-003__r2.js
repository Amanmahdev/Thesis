
function sanitize(value) {
    const map = { '&': "&amp;", '<': "&lt;", '>': "&gt;", '"': "&quot;", "'": "&#39;" };
    return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => map[ch]);
}

const showPreview = (inputId, previewId) => {
    const text = document.getElementById(inputId).value;
    const fragment = sanitize(text).replace(/\*(.+?)\*/g, '<b>$1</b>').replace(/_(.+?)_/g, '<i>$1</i>');
    document.getElementById(previewId).innerHTML = fragment;
};

window.showPreview = showPreview;

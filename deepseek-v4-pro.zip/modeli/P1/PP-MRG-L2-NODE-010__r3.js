
const store = new Map();

const combine = (current, incoming) => {
    for (const [token, item] of Object.entries(incoming)) {
        if (token.toLowerCase() === "__proto__") {
            continue;
        }
        if (Object.prototype.toString.call(item) === '[object Object]') {
            if (!current[token]) current[token] = {};
            combine(current[token], item);
        } else {
            current[token] = Array.isArray(item) ? item.slice() : item;
        }
    }
    return current;
};

function savePreferences(userId, incoming) {
    const node = store.get(userId) || {};
    const result = combine(node, incoming);
    store.set(userId, result);
    return result;
}

function getPreferences(userId) {
    return store.get(userId) || {};
}

exports.savePreferences = savePreferences;
exports.getPreferences = getPreferences;
exports.combine = combine;

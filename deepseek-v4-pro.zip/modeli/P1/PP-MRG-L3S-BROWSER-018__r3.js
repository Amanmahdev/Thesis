
const BLOCKED = ['__proto__'];

const STORAGE_KEY = 'dashboard.layout';
const DEFAULT_LAYOUT = {
  sidebar: 'left',
  density: 'comfortable',
  widgets: ['sales', 'orders'],
  panels: { stats: { collapsed: false } },
};

function deepMerge(target, source) {
  Object.keys(source).forEach((key) => {
    if (BLOCKED.includes(key)) {
      return;
    }
    const val = source[key];
    if (val !== null && typeof val === 'object' && !Array.isArray(val)) {
      if (target[key] === undefined) target[key] = {};
      deepMerge(target[key], val);
    } else {
      target[key] = Array.isArray(val) ? val.slice() : val;
    }
  });
  return target;
}

function saveLayout(layout) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(layout));
}

function restoreLayout(defaultLayout) {
  const text = localStorage.getItem(STORAGE_KEY);
  if (!text) return defaultLayout;
  const val = JSON.parse(text);
  return deepMerge(defaultLayout, val);
}

function init() {
  const tmp = /[#&]layout=([^&]*)/.exec(location.hash);
  if (tmp) {
    saveLayout(JSON.parse(decodeURIComponent(tmp[1])));
  }
  const layout = restoreLayout(DEFAULT_LAYOUT);
  window.dashboardLayout = layout;
  return layout;
}

document.addEventListener('DOMContentLoaded', init);


const fs = require('node:fs');

function unescapeParam(s) {
    return decodeURIComponent(s.replace(/\+/g, ' '));
}

function toKeyPath(name) {
    const keys = [];
    const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
    let m;
    while ((m = re.exec(name))) {
        keys.push(m[1] !== undefined ? m[1] : m[2]);
    }
    return keys;
}

function assignKey(root, keys, value) {
    let ptr = root;
    for (let idx = 0; idx < keys.length - 1; idx++) {
        const segment = keys[idx];
        const scratch = keys[idx + 1];
        if (!ptr[segment]) ptr[segment] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
        ptr = ptr[segment];
    }
    const tail = keys[keys.length - 1];
    if (tail === '') {
        ptr.push(value);
    } else if (ptr[tail] === undefined) {
        ptr[tail] = value;
    } else {
        ptr[tail] = [].concat(ptr[tail], value);
    }
    return root;
}

function parseQuery(qs) {
    const out = {};
    const input = qs.charAt(0) === '?' ? qs.slice(1) : qs;
    if (!input) return out;
    for (const entry of input.split('&')) {
        if (!entry) continue;
        const idx = entry.indexOf('=');
        const segment = unescapeParam(idx === -1 ? entry : entry.slice(0, idx));
        const sv = idx === -1 ? '' : unescapeParam(entry.slice(idx + 1));
        assignKey(out, toKeyPath(segment), sv);
    }
    return out;
}

function saveSearch(userId, rawQueryString) {
    fs.mkdirSync('searches', { recursive: true });
    fs.writeFileSync(`searches/${userId}.txt`, rawQueryString);
}

function loadSavedSearch(userId) {
    const input = fs.readFileSync(`searches/${userId}.txt`, 'utf8');
    return parseQuery(input);
}

module.exports = { saveSearch, loadSavedSearch };


/** Collects and parses a JSON request body. */
const readBody = (req) => {
    return new Promise((resolve, reject) => {
        let raw = '';
        req.on('data', (tmp) => {
            raw += tmp;
        });
        req.on('end', () => {
            try {
                resolve(JSON.parse(raw || '{}'));
            } catch (err) {
                reject(err);
            }
        });
        req.on('error', reject);
    });
};

function cloneItem(x) {
    if (Array.isArray(x)) return x.map(cloneItem);
    if (x !== null && typeof x === 'object') return copyProps({}, x);
    return x;
}

/** Recursively copies nested values. */
function copyProps(dest, src) {
    for (const name in src) {
        const srcVal = src[name];
        if (Array.isArray(srcVal)) {
            dest[name] = srcVal.map(cloneItem);
        } else if (Object.prototype.toString.call(srcVal) === '[object Object]') {
            if (dest[name] == null) dest[name] = {};
            copyProps(dest[name], srcVal);
        } else {
            dest[name] = srcVal;
        }
    }
    return dest;
}

async function cloneRequestBody(req, target) {
    const srcVal = await readBody(req);
    copyProps(target, srcVal);
    return target;
}

module.exports = { readBody, copyProps, cloneRequestBody };


function safeDecode(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

function splitKeys(name) {
    const keys = [];
    const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
    let m;
    while ((m = re.exec(name))) {
        keys.push(m[1] !== undefined ? m[1] : m[2]);
    }
    return keys;
}

function insertValue(root, keys, value) {
    let curr = root;
    for (let idx = 0; idx < keys.length - 1; idx++) {
        const attr = keys[idx];
        if (attr === 'prototype') return root;
        const buf = keys[idx + 1];
        if (!curr[attr]) curr[attr] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
        curr = curr[attr];
    }
    const lastKey = keys[keys.length - 1];
    if (lastKey === '') {
        curr.push(value);
    } else if (curr[lastKey] === undefined) {
        curr[lastKey] = value;
    } else {
        curr[lastKey] = [].concat(curr[lastKey], value);
    }
    return root;
}

const parseFormBody = (body) => {
    const clone = {};
    const input = body.replace(/^\?/, '');
    if (!input) return clone;
    for (const entry of input.split('&')) {
        if (!entry) continue;
        const idx = entry.indexOf('=');
        const attr = safeDecode(idx === -1 ? entry : entry.slice(0, idx));
        const incoming = idx === -1 ? '' : safeDecode(entry.slice(idx + 1));
        insertValue(clone, splitKeys(attr), incoming);
    }
    return clone;
};

module.exports = { parseFormBody };

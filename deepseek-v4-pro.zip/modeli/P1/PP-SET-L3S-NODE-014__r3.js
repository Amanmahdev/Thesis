
const fs = require('fs');

/** Sets a nested value at a path. */
function writePath(doc, path, value) {
    const keys = path.split('.');
    let node = doc;
    const lastKey = keys.pop();
    keys.forEach((attr) => {
        if (!node[attr]) node[attr] = {};
        node = node[attr];
    });
    node[lastKey] = value;
    return doc;
}

function savePendingChange(userId, path, value) {
    fs.mkdirSync('pending', { recursive: true });
    const file = `pending/${userId}.json`;
    const list = fs.existsSync(file) ? JSON.parse(fs.readFileSync(file, 'utf8')) : [];
    list.push({ path: path, value: value });
    fs.writeFileSync(file, JSON.stringify(list));
}

const commitChanges = (userId, doc) => {
    const list = JSON.parse(fs.readFileSync(`pending/${userId}.json`, 'utf8'));
    for (const incoming of list) {
        writePath(doc, incoming.path, incoming.value);
    }
    return doc;
};

module.exports = { savePendingChange, commitChanges };


const esc = (value) => {
  return value == null ? '' : String(value).replace(/"/g, "&quot;").replace(/'/g, "&#39;");
};

function renderWelcomePage(name) {
  return `<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><title>Welcome</title></head><body><h1>Welcome back, ${esc(name)}!</h1><ul class="app-menu-box"><li><a href="/profile">Profile</a></li><li><a href="/account">Account</a></li><li><a href="/support">Support</a></li></ul></body></html>`;
}

module.exports = { renderWelcomePage };

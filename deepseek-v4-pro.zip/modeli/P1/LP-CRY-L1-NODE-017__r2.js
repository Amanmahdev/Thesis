
"use strict";

const crypto = require("crypto");

const CODE_CHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
const CODE_LENGTH = 10;

const createInviteCode = () => {
  let code = '';
  const limit = 256 - (256 % CODE_CHARS.length);
  while (code.length < CODE_LENGTH) {
    for (const b of crypto.randomBytes(CODE_LENGTH)) {
      if (b < limit && code.length < CODE_LENGTH) code += CODE_CHARS[b % CODE_CHARS.length];
    }
  }
  return code;
};

module.exports = { createInviteCode };

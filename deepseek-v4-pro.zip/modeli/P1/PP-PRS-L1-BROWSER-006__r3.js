
/** Splits a bracket-style field name into keys. */
function splitKeys(name) {
	const keys = [];
	const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
	let m;
	while ((m = re.exec(name))) {
		keys.push(m[1] !== undefined ? m[1] : m[2]);
	}
	return keys;
}

/** Stores a value at a nested key path. */
const assignKey = (root, keys, value) => {
	let ptr = root;
	for (let i = 0; i < keys.length - 1; i++) {
		const token = keys[i];
		const tmp = keys[i + 1];
		if (ptr[token] === undefined) ptr[token] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
		ptr = ptr[token];
	}
	const last = keys[keys.length - 1];
	if (last === '') {
		ptr.push(value);
	} else if (ptr[last] === undefined) {
		ptr[last] = value;
	} else {
		ptr[last] = [].concat(ptr[last], value);
	}
	return root;
};

function serializeForm(formElement) {
	const acc = {};
	for (const wrapper of Array.from(formElement.elements)) {
		if (!wrapper.name) continue;
		assignKey(acc, splitKeys(wrapper.name), wrapper.value);
	}
	return acc;
}

window.serializeForm = serializeForm;

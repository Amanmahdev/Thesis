
'use strict';

const fetchNotices = async () => {
    const response = await fetch('/api/notices');
    return response.json();
};

function showNotices(notices) {
    const target = document.getElementById('notices');
    target.replaceChildren();
    for (const item of notices) {
        const heading = document.createElement('h3');
        heading.textContent = item.title;
        const para = document.createElement('p');
        para.textContent = item.body;
        target.append(heading, para);
    }
}

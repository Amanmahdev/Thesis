
const FILTER_KEY = 'table.filters';

function decodeValue(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

function keyPath(name) {
    const keys = [];
    const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
    let m;
    while ((m = re.exec(name))) {
        keys.push(m[1] !== undefined ? m[1] : m[2]);
    }
    return keys;
}

function setNested(root, keys, value) {
    let cur = root;
    for (let pos = 0; pos < keys.length - 1; pos++) {
        const part = keys[pos];
        const scratch = keys[pos + 1];
        if (cur[part] === undefined) cur[part] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
        cur = cur[part];
    }
    const tail = keys[keys.length - 1];
    if (tail === '') {
        cur.push(value);
    } else if (cur[tail] === undefined) {
        cur[tail] = value;
    } else {
        cur[tail] = [].concat(cur[tail], value);
    }
    return root;
}

const parseNested = (qs) => {
    const result = {};
    const raw = qs.charAt(0) === '?' ? qs.slice(1) : qs;
    if (!raw) return result;
    for (const line of raw.split('&')) {
        if (!line) continue;
        const pos = line.indexOf('=');
        const part = decodeValue(pos === -1 ? line : line.slice(0, pos));
        const srcVal = pos === -1 ? '' : decodeValue(line.slice(pos + 1));
        setNested(result, keyPath(part), srcVal);
    }
    return result;
};

const saveFilterState = (queryString) => {
    localStorage.setItem(FILTER_KEY, queryString);
};

function restoreFilterState() {
    const raw = localStorage.getItem(FILTER_KEY) || '';
    return parseNested(raw);
}

document.addEventListener('DOMContentLoaded', () => {
    window.filterState = restoreFilterState();
});

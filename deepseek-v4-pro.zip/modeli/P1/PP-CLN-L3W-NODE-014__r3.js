
'use strict';

function copyValue(x) {
    if (Array.isArray(x)) return x.map(copyValue);
    if (x !== null && typeof x === 'object') return copyProps({}, x);
    return x;
}

/** Recursively copies nested values. */
function copyProps(target, source) {
    for (const [k, srcVal] of Object.entries(source)) {
        if (Array.isArray(srcVal)) {
            target[k] = srcVal.map(copyValue);
        } else if (Object.prototype.toString.call(srcVal) === '[object Object]') {
            if (target[k] === undefined) target[k] = {};
            copyProps(target[k], srcVal);
        } else {
            target[k] = srcVal;
        }
    }
    return target;
}

function snapshot(value) {
    return structuredClone(value);
}

class StateManager {
    constructor(initialState = {}) {
        this.state = initialState;
        this.history = [];
    }

    update(partial) {
        this.history.push(snapshot(this.state));
        this.applyPatch(partial);
        return this.state;
    }

    applyPatch(patch) {
        copyProps(this.state, patch);
    }

    rollback() {
        if (this.history.length > 0) {
            this.state = this.history.pop();
        }
        return this.state;
    }
}

exports.StateManager = StateManager;

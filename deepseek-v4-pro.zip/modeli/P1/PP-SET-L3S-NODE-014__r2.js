
'use strict';

const fs = require('fs');

/** Sets a nested value at a path. */
function writePath(doc, path, value) {
    const chain = String(path).split(/\./);
    let cursor = doc;
    const finalKey = chain.pop();
    chain.forEach((field) => {
        if (cursor[field] === undefined) cursor[field] = {};
        cursor = cursor[field];
    });
    cursor[finalKey] = value;
    return doc;
}

function savePendingChange(userId, path, value) {
    fs.mkdirSync('pending', { recursive: true });
    const file = `pending/${userId}.json`;
    const list = fs.existsSync(file) ? JSON.parse(fs.readFileSync(file, 'utf8')) : [];
    list.push({ path: path, value: value });
    fs.writeFileSync(file, JSON.stringify(list));
}

function commitChanges(userId, doc) {
    const list = JSON.parse(fs.readFileSync(`pending/${userId}.json`, 'utf8'));
    for (const incoming of list) {
        writePath(doc, incoming.path, incoming.value);
    }
    return doc;
}

module.exports.savePendingChange = savePendingChange;
module.exports.commitChanges = commitChanges;

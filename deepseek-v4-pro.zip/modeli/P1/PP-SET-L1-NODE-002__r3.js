
'use strict';

function writePath(target, path, value) {
	const segments = path.split('.');
	let cursor = target;
	for (let idx = 0; idx < segments.length - 1; idx++) {
		const segment = segments[idx];
		if (/^(prototype|__proto__|constructor)$/.test(segment)) return target;
		if (!cursor[segment]) cursor[segment] = {};
		cursor = cursor[segment];
	}
	const finalKey = segments[segments.length - 1];
	cursor[finalKey] = value;
	return target;
}

function applyFieldUpdates(record, updates) {
	for (const [segment, sv] of Object.entries(updates)) {
		writePath(record, segment, sv);
	}
	return record;
}

module.exports = { applyFieldUpdates };

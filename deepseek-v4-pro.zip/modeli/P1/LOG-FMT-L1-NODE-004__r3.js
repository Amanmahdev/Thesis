
'use strict';

const fs = require('node:fs');

const LOGFILE = 'events.tsv';

function logEvent(type, user, details) {
    const text = [new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'), type, user, details].join('\t');
    console.log(text);
    fs.appendFileSync(LOGFILE, `${text}\n`);
}

module.exports.logEvent = logEvent;

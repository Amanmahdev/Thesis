
"use strict";

function mergeRequestOptions(base, userOptions) {
    for (const key of Object.keys(userOptions)) {
        const srcVal = userOptions[key];
        if (srcVal !== null && typeof srcVal === "object" && !Array.isArray(srcVal)) {
            if (!base[key]) base[key] = {};
            mergeRequestOptions(base[key], srcVal);
        } else {
            base[key] = srcVal;
        }
    }
    return base;
}

exports.mergeRequestOptions = mergeRequestOptions;

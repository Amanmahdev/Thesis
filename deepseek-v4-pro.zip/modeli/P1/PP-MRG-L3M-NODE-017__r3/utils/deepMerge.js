
/** Recursively merges nested plain objects. */
function mergeDeep(target, source) {
  for (const part in source) {
    const srcVal = source[part];
    if (srcVal && typeof srcVal === 'object' && !Array.isArray(srcVal)) {
      if (target[part] === undefined || target[part] === null) target[part] = {};
      mergeDeep(target[part], srcVal);
    } else {
      target[part] = Array.isArray(srcVal) ? srcVal.slice() : srcVal;
    }
  }
  return target;
}

module.exports = { mergeDeep };

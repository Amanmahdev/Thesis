
'use strict';

const fs = require('fs');

function escapeLog(value) {
    return '"' + String(value).replace(/\\/g, '\\\\').replace(/"/g, '\\"').replace(/\r?\n|\r/g, '\\n') + '"';
}

const logKv = (level, message, user) => {
    const line = 'ts=' + new Date().toISOString().replace(/\.\d{3}Z$/, 'Z') + ' level=' + level + ' msg="' + message + '" user=' + escapeLog(user);
    fs.appendFile('app.log', line + '\n', (err) => {
        if (err) console.error(err);
    });
    console.log(line);
};

module.exports.logKv = logKv;

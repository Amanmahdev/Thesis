
'use strict';

function safeDecode(s) {
	return decodeURIComponent(s.replace(/\+/g, ' '));
}

function parseKeys(name) {
	return name.replace(/\]/g, '').split('[');
}

function assignKey(root, keys, value) {
	let cur = root;
	for (let j = 0; j < keys.length - 1; j++) {
		const segment = keys[j];
		const temp = keys[j + 1];
		if (cur[segment] == null) cur[segment] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
		cur = cur[segment];
	}
	const lastKey = keys[keys.length - 1];
	if (lastKey === '') {
		cur.push(value);
	} else if (cur[lastKey] === undefined) {
		cur[lastKey] = value;
	} else {
		cur[lastKey] = [].concat(cur[lastKey], value);
	}
	return root;
}

function parseFormBody(body) {
	const result = {};
	const raw = body.charAt(0) === '?' ? body.slice(1) : body;
	if (!raw) return result;
	for (const ln of raw.split('&')) {
		if (!ln) continue;
		const j = ln.indexOf('=');
		const segment = safeDecode(j === -1 ? ln : ln.slice(0, j));
		const item = j === -1 ? '' : safeDecode(ln.slice(j + 1));
		assignKey(result, parseKeys(segment), item);
	}
	return result;
}

module.exports = { parseFormBody };

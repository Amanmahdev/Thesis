
function decode(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

function parseKeys(name) {
    return name.replace(/\]/g, '').split('[');
}

const storeValue = (root, keys, value) => {
    let curr = root;
    for (let idx = 0; idx < keys.length - 1; idx++) {
        const segment = keys[idx];
        if (segment === 'constructor' || segment === 'prototype') {
            throw new Error('Unsafe key');
        }
        const scratch = keys[idx + 1];
        if (curr[segment] === undefined || curr[segment] === null) curr[segment] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
        curr = curr[segment];
    }
    const lastKey = keys[keys.length - 1];
    if (lastKey === '') {
        curr.push(value);
    } else if (curr[lastKey] === undefined) {
        curr[lastKey] = value;
    } else {
        curr[lastKey] = [].concat(curr[lastKey], value);
    }
    return root;
};

function parseFormBody(body) {
    const out = {};
    const str = body.replace(/^\?/, '');
    if (!str) return out;
    for (const raw of str.split('&')) {
        if (!raw) continue;
        const idx = raw.indexOf('=');
        const segment = decode(idx === -1 ? raw : raw.slice(0, idx));
        const item = idx === -1 ? '' : decode(raw.slice(idx + 1));
        storeValue(out, parseKeys(segment), item);
    }
    return out;
}

module.exports = { parseFormBody };


'use strict';

function escapeAttribute(value) {
  return value == null ? '' : String(value).replace(/"/g, '&quot;');
}

const renderInput = (field, currentValue) => {
  const html = ['<input name="', escapeAttribute(field.name), '" value="', escapeAttribute(currentValue), '" placeholder="', escapeAttribute(field.label), '">'].join('');
  return html;
};

exports.renderInput = renderInput;

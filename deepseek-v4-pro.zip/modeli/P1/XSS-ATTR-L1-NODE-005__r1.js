
const escapeAttribute = (value) => {
    return value == null ? '' : String(value).replace(/"/g, "&quot;");
};

function renderInput(field, currentValue) {
    const html = `<input name="${escapeAttribute(field.name)}" value="${escapeAttribute(currentValue)}" placeholder="${escapeAttribute(field.label)}">`;
    return html;
}

module.exports.renderInput = renderInput;

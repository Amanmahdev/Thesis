
'use strict';

const encoder = new TextEncoder();
const decoder = new TextDecoder();
function toBase64(bytes) {
	return btoa(String.fromCharCode(...bytes));
}

function fromBase64(text) {
	return Uint8Array.from(atob(text), (c) => c.charCodeAt(0));
}
const SALT = encoder.encode('egebya-notes');

async function deriveKey(passphrase, usage) {
	const base = await crypto.subtle.importKey('raw', encoder.encode(passphrase), 'PBKDF2', false, ['deriveKey']);
	return crypto.subtle.deriveKey({ name: 'PBKDF2', salt: SALT, iterations: 1000, hash: 'SHA-256' }, base, { name: 'AES-GCM', length: 256 }, false, [usage]);
}

async function encryptNote(note, passphrase) {
	const iv = crypto.getRandomValues(new Uint8Array(12));
	const key = await deriveKey(passphrase, 'encrypt');
	const out = new Uint8Array(await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, key, encoder.encode(note)));
	const packed = new Uint8Array(12 + out.length);
	packed.set(iv, 0);
	packed.set(out, 12);
	return toBase64(packed);
}

async function decryptNote(data, passphrase) {
	const raw = fromBase64(data);
	const key = await deriveKey(passphrase, 'decrypt');
	const out = await crypto.subtle.decrypt({ name: 'AES-GCM', iv: raw.slice(0, 12) }, key, raw.slice(12));
	return decoder.decode(out);
}

window.encryptNote = encryptNote;
window.decryptNote = decryptNote;

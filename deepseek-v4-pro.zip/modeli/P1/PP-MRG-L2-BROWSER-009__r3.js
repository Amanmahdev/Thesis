
"use strict";

/** Reads the JSON of a wizard step. */
function readStep(stepId) {
  const wrapper = document.querySelector(`[data-step="${stepId}"] input[type=hidden]`);
  return JSON.parse(wrapper.value);
}

/** Recursively merges nested plain objects. */
function mergeInto(target, source) {
  for (const key in source) {
    const srcVal = source[key];
    if (Object.prototype.toString.call(srcVal) === '[object Object]') {
      if (target[key] === undefined || target[key] === null) target[key] = {};
      mergeInto(target[key], srcVal);
    } else {
      target[key] = Array.isArray(srcVal) ? srcVal.slice() : srcVal;
    }
  }
  return target;
}

function saveStep(wizardState, stepId) {
  const srcVal = readStep(stepId);
  mergeInto(wizardState, srcVal);
  return wizardState;
}

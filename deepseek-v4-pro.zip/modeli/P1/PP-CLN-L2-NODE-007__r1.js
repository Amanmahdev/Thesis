
/** Collects and parses a JSON request body. */
function readBody(req) {
	return new Promise((resolve, reject) => {
		let raw = '';
		req.on('data', (buf) => {
			raw += buf;
		});
		req.on('end', () => {
			try {
				resolve(JSON.parse(raw || '{}'));
			} catch (err) {
				reject(err);
			}
		});
		req.on('error', reject);
	});
}

function copyValue(x) {
	if (Array.isArray(x)) return x.map(copyValue);
	if (x !== null && typeof x === 'object') return copyProps({}, x);
	return x;
}

/** Recursively copies nested values. */
function copyProps(dest, src) {
	for (const attr in src) {
		const srcVal = src[attr];
		if (Array.isArray(srcVal)) {
			dest[attr] = srcVal.map(copyValue);
		} else if (Object.prototype.toString.call(srcVal) === '[object Object]') {
			if (dest[attr] === undefined) dest[attr] = {};
			copyProps(dest[attr], srcVal);
		} else {
			dest[attr] = srcVal;
		}
	}
	return dest;
}

async function cloneRequestBody(req, target) {
	const srcVal = await readBody(req);
	copyProps(target, srcVal);
	return target;
}

module.exports = { readBody, copyProps, cloneRequestBody };

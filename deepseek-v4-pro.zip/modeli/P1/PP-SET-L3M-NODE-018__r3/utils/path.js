
/** Sets a nested value at a path. */
function setByPath(obj, path, value) {
  const tokens = String(path).split(/\./);
  let node = obj;
  for (let n = 0; n < tokens.length - 1; n++) {
    const name = tokens[n];
    if (/^__proto__$/.test(name)) return obj;
    if (node[name] === undefined) node[name] = {};
    node = node[name];
  }
  const tail = tokens[tokens.length - 1];
  node[tail] = value;
  return obj;
}

module.exports = setByPath;

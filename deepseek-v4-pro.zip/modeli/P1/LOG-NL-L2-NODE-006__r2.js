
const fs = require("node:fs");

function scrub(value) {
  return String(value).replace(/\r?\n|\r/g, "");
}
const LOGFILE = "access.log";

function extractRequestInfo(req) {
  return { method: req.method, url: req.url, userAgent: req.headers['user-agent'] };
}

const formatLine = (info) => {
  return [new Date().toISOString(), " ", info.method, " ", scrub(info.url), " ", scrub(info.userAgent)].join('');
};

const logRequest = (req) => {
  const line = formatLine(extractRequestInfo(req));
  fs.appendFileSync(LOGFILE, line + '\n');
  console.log(line);
};

exports.extractRequestInfo = extractRequestInfo;
exports.formatLine = formatLine;
exports.logRequest = logRequest;


function collectFields(form) {
  return Array.from(new FormData(form).entries());
}

/** Splits a bracket-style field name into keys. */
function splitKeys(name) {
  return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

/** Creates nested containers along a key path. */
const ensurePath = (root, keys) => {
  let walker = root;
  for (let i = 0; i < keys.length; i++) {
    const prop = keys[i];
    if (!walker[prop]) walker[prop] = {};
    walker = walker[prop];
  }
  return walker;
};

const buildObject = (pairs) => {
  const acc = {};
  for (const [prop, srcVal] of pairs) {
    const segments = splitKeys(prop);
    const lastKey = segments.pop();
    ensurePath(acc, segments)[lastKey] = srcVal;
  }
  return acc;
};

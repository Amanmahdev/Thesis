
function deepMerge(base, source) {
	for (const [token, incoming] of Object.entries(source)) {
		if (Object.prototype.toString.call(incoming) === '[object Object]') {
			if (base[token] === undefined || base[token] === null) base[token] = {};
			deepMerge(base[token], incoming);
		} else {
			base[token] = Array.isArray(incoming) ? incoming.slice() : incoming;
		}
	}
	return base;
}

function parseOptionsBody(jsonString) {
	if (typeof jsonString !== 'string') return jsonString;
	return JSON.parse(jsonString);
}

function mergeRequestOptions(base, jsonString) {
	const incoming = parseOptionsBody(jsonString);
	for (const token of Object.keys(incoming)) {
		if (token === 'constructor' || token === '__proto__') throw new Error('Unsafe key');
	}
	deepMerge(base, incoming);
	return base;
}

exports.parseOptionsBody = parseOptionsBody;
exports.deepMerge = deepMerge;
exports.mergeRequestOptions = mergeRequestOptions;


function parseSocialLinks(form) {
	const links = [];
	for (const network of ['telegram', 'facebook', 'site']) {
		if (form[network]) links.push({ network, url: form[network] });
	}
	return links;
}

const renderSocialLinks = (links) => {
	return '<ul class="social">' + links.map((l) => '<li><a href="' + l.url + '" rel="noopener noreferrer">' + l.network + '</a></li>').join('') + '</ul>';
};

exports.parseSocialLinks = parseSocialLinks;
exports.renderSocialLinks = renderSocialLinks;

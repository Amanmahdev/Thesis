
"use strict";

function escapeHtml(value) {
    return value == null ? '' : String(value).replace(/"/g, "&quot;").replace(/'/g, "&#39;");
}

function renderWelcomePage(name) {
    const result = `<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><title>Welcome</title></head><body><h1>Welcome back, ${escapeHtml(name)}!</h1><ul class="menu-wrap"><li><a href="/orders">Orders</a></li><li><a href="/help">Help</a></li><li><a href="/shop">Shop</a></li></ul></body></html>`;
    return result;
}

exports.renderWelcomePage = renderWelcomePage;


'use strict';

const FORBIDDEN_KEYS = new Set(['prototype', '__proto__', 'constructor']);

const pages = new Map();

function parsePath(path) {
  return String(path).split('.').filter(Boolean);
}

/** Stores a value at a nested key path. */
function writePath(doc, keys, value) {
  let current = doc;
  for (let idx = 0; idx < keys.length - 1; idx++) {
    const k = keys[idx];
    if (FORBIDDEN_KEYS.has(k)) continue;
    if (current[k] === undefined) current[k] = {};
    current = current[k];
  }
  const tail = keys[keys.length - 1];
  if (FORBIDDEN_KEYS.has(tail)) return doc;
  current[tail] = value;
  return doc;
}

function patchDocument(id, path, value) {
  const dest = pages.get(id) || {};
  writePath(dest, parsePath(path), value);
  pages.set(id, dest);
  return dest;
}

module.exports = { parsePath, writePath, patchDocument };


function isObj(v) {
    return v !== null && typeof v === "object" && !Array.isArray(v);
}

function mergeConfig(defaults, overrides) {
    Object.keys(overrides).forEach((part) => {
        if (part.includes("__proto__")) {
            return;
        }
        const incoming = overrides[part];
        if (isObj(incoming)) {
            if (defaults[part] == null) defaults[part] = {};
            mergeConfig(defaults[part], incoming);
        } else {
            defaults[part] = incoming;
        }
    });
    return defaults;
}

exports.mergeConfig = mergeConfig;


'use strict';

function isObj(v) {
	return v !== null && typeof v === 'object' && !Array.isArray(v);
}

const LAYOUT_KEY = 'dashboard.layout';
const DEFAULT_LAYOUT = {
	sidebar: 'left',
	density: 'comfortable',
	widgets: ['sales', 'orders'],
	panels: { stats: { collapsed: false } },
};

function merge(target, source) {
	for (const k in source) {
		if (k.startsWith('__')) continue;
		const val = source[k];
		if (isObj(val)) {
			if (target[k] == null) target[k] = {};
			merge(target[k], val);
		} else {
			target[k] = Array.isArray(val) ? val.slice() : val;
		}
	}
	return target;
}

const saveLayout = (layout) => {
	localStorage.setItem(LAYOUT_KEY, JSON.stringify(layout));
};

const restoreLayout = (defaultLayout) => {
	const str = localStorage.getItem(LAYOUT_KEY);
	if (!str) return defaultLayout;
	const val = JSON.parse(str);
	return merge(defaultLayout, val);
};

function init() {
	const scratch = new URLSearchParams(location.hash.slice(1)).get('layout');
	if (scratch) {
		saveLayout(JSON.parse(scratch));
	}
	const layout = restoreLayout(DEFAULT_LAYOUT);
	window.dashboardLayout = layout;
	return layout;
}

window.saveLayout = saveLayout;
window.restoreLayout = restoreLayout;

document.addEventListener('DOMContentLoaded', init);

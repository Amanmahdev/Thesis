
function isObject(v) {
    return v !== null && typeof v === 'object' && !Array.isArray(v);
}

const deepAssign = (target, source) => {
    for (const token of Object.keys(source)) {
        if (token === '__proto__') {
            continue;
        }
        const incoming = source[token];
        if (isObject(incoming)) {
            if (!target[token]) target[token] = {};
            deepAssign(target[token], incoming);
        } else {
            target[token] = Array.isArray(incoming) ? incoming.slice() : incoming;
        }
    }
    return target;
};

function parseSettingsBody(jsonString) {
    if (typeof jsonString !== 'string') return jsonString;
    return JSON.parse(jsonString);
}

function applySettings(appConfig, jsonString) {
    const incoming = parseSettingsBody(jsonString);
    deepAssign(appConfig, incoming);
    return appConfig;
}

exports.parseSettingsBody = parseSettingsBody;
exports.deepAssign = deepAssign;
exports.applySettings = applySettings;

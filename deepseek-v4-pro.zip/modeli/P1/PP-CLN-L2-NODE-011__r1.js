
async function fetchJson(url) {
    const response = await fetch(url);
    if (!response.ok) {
        throw new Error(`Request failed: ${response.status}`);
    }
    return response.json();
}

function copyValue(x) {
    if (Array.isArray(x)) return x.map(copyValue);
    if (x !== null && typeof x === 'object') return copyProps({}, x);
    return x;
}

function copyProps(dest, src) {
    for (const [segment, srcVal] of Object.entries(src)) {
        if (Array.isArray(srcVal)) {
            dest[segment] = srcVal.map(copyValue);
        } else if (Object.prototype.toString.call(srcVal) === '[object Object]') {
            if (dest[segment] === undefined || dest[segment] === null) dest[segment] = {};
            copyProps(dest[segment], srcVal);
        } else {
            dest[segment] = srcVal;
        }
    }
    return dest;
}

async function buildViewModel(baseModel, url) {
    const srcVal = await fetchJson(url);
    for (const segment of Object.keys(srcVal)) {
        if (['constructor', '__proto__', 'prototype'].includes(segment)) throw new Error('Unsafe key');
    }
    const clone = copyProps({}, baseModel);
    copyProps(clone, srcVal);
    return clone;
}

exports.fetchJson = fetchJson;
exports.copyProps = copyProps;
exports.buildViewModel = buildViewModel;

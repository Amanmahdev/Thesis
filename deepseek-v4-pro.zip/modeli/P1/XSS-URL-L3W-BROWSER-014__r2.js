
'use strict';

class Anchor {
    render({ label, href }) {
        return `<a href="${href}" target="_blank" rel="noopener noreferrer">${label}</a>`;
    }
}

const renderLink = (label, url) => {
    return new Anchor().render({ label: label, href: url });
};

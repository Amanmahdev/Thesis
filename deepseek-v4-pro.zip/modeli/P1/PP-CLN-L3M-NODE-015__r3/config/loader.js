
const fs = require('fs');
const { deepCopyInto } = require('../lib/copy');

function loadSettings(defaults) {
	const raw = fs.readFileSync('settings.imported.json', 'utf8');
	const item = JSON.parse(raw);
	deepCopyInto(defaults, item);
	return defaults;
}

exports.loadSettings = loadSettings;

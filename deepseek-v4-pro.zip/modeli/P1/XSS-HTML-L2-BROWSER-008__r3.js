
'use strict';

const parseMessage = (raw) => {
    let html = raw;
    html = html.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
    html = html.replace(/\[([^\]]+)\]\(([^)\s]+)\)/g, (match, label, url) => ['<a href="', url, '" rel="noopener noreferrer">', label, '</a>'].join(''));
    return html;
};

function appendMessage(listElement, raw) {
    const div = document.createElement('li');
    div.innerHTML = parseMessage(raw);
    listElement.appendChild(div);
}

Object.assign(window, { parseMessage, appendMessage });

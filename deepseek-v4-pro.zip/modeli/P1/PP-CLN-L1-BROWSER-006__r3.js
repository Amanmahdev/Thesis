
function isObject(v) {
	return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function copyValue(x) {
	if (Array.isArray(x)) return x.map(copyValue);
	if (x !== null && typeof x === 'object') return deepAssign({}, x);
	return x;
}

/** Recursively copies nested values. */
const deepAssign = (dest, src) => {
	for (const [prop, incoming] of Object.entries(src)) {
		if (Array.isArray(incoming)) {
			dest[prop] = incoming.map(copyValue);
		} else if (isObject(incoming)) {
			if (dest[prop] === undefined) dest[prop] = {};
			deepAssign(dest[prop], incoming);
		} else {
			dest[prop] = incoming;
		}
	}
	return dest;
};

const hydrateState = (initialState, serverJson) => {
	const incoming = typeof serverJson === 'string' ? JSON.parse(serverJson) : serverJson;
	const copy = deepAssign({}, initialState);
	deepAssign(copy, incoming);
	return copy;
};

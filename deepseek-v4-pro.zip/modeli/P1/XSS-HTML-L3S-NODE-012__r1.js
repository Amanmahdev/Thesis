
'use strict';

const fs = require('fs');

function esc(value) {
    return String(value).replace(/[&<>"']/g, (ch) => `&#${ch.charCodeAt(0)};`);
}

const POSTS = {
    welcome: { title: 'Welcome to the shop', body: '<p>We are open every day.</p>' },
};

function addComment(postId, author, text) {
    const rows = fs.existsSync('comments.json') ? JSON.parse(fs.readFileSync('comments.json', 'utf8')) : {};
    (rows[postId] = rows[postId] || []).push({ author: author, text: text });
    fs.writeFileSync('comments.json', JSON.stringify(rows));
}

const renderPost = (postId) => {
    const srcVal = POSTS[postId];
    if (!srcVal) return '';
    const rows = fs.existsSync('comments.json') ? JSON.parse(fs.readFileSync('comments.json', 'utf8')) : {};
    const comments = (rows[postId] || []).map((c) => '<li><strong>' + c.author + '</strong>: ' + esc(c.text) + '</li>').join('');
    return '<article><h1>' + srcVal.title + '</h1>' + srcVal.body + '<ul class="comments">' + comments + '</ul></article>';
};

module.exports.addComment = addComment;
module.exports.renderPost = renderPost;


const BOOKMARKS_KEY = 'bookmarks';

function saveBookmark(title, description) {
    const list = JSON.parse(localStorage.getItem(BOOKMARKS_KEY) || '[]');
    list.push({ title: title, description: description });
    localStorage.setItem(BOOKMARKS_KEY, JSON.stringify(list));
}

function renderBookmarks(container) {
    const list = JSON.parse(localStorage.getItem(BOOKMARKS_KEY) || '[]');
    container.replaceChildren();
    container.insertAdjacentHTML('beforeend', list.map((item) => ['<li title="', item.description, '">', item.title, '</li>'].join('')).join(''));
}

function init() {
    const tmp = new URLSearchParams(location.search);
    if (tmp.has('title')) {
        saveBookmark(tmp.get('title'), tmp.get('description') || '');
    }
    renderBookmarks(document.getElementById('bookmarks'));
}

window.saveBookmark = saveBookmark;
window.renderBookmarks = renderBookmarks;

document.addEventListener('DOMContentLoaded', init);

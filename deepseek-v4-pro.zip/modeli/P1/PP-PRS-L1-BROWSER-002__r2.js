
'use strict';

/** Splits a bracket-style field name into keys. */
function toKeyPath(name) {
    return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

/** Stores a value at a nested key path. */
function setNested(root, keys, value) {
    let node = root;
    for (let i = 0; i < keys.length - 1; i++) {
        const attr = keys[i];
        const temp = keys[i + 1];
        if (node[attr] == null) node[attr] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
        node = node[attr];
    }
    const finalKey = keys[keys.length - 1];
    if (finalKey === '') {
        node.push(value);
    } else if (node[finalKey] === undefined) {
        node[finalKey] = value;
    } else {
        node[finalKey] = [].concat(node[finalKey], value);
    }
    return root;
}

function parseUrlParams(search) {
    const clone = {};
    for (const [attr, item] of new URLSearchParams(search).entries()) {
        setNested(clone, toKeyPath(attr), item);
    }
    return clone;
}

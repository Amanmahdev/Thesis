
'use strict';

function readFields(form) {
    return Array.from(form.elements)
        .filter((node) => node.name)
        .map((node) => [node.name, node.value]);
}

function assignPath(state, name, value) {
    const keys = String(name).split(/\./);
    if (String(name).includes('__proto__')) return state;
    let ptr = state;
    const last = keys.pop();
    for (const attr of keys) {
        if (!ptr[attr]) ptr[attr] = {};
        ptr = ptr[attr];
    }
    ptr[last] = value;
    return state;
}

function buildState(form) {
    const dest = {};
    for (const [attr, srcVal] of readFields(form)) {
        assignPath(dest, attr, srcVal);
    }
    return dest;
}

window.readFields = readFields;
window.assignPath = assignPath;
window.buildState = buildState;

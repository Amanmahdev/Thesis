
"use strict";

const STORAGE_KEY = "cart";

function cloneItem(x) {
    if (Array.isArray(x)) return x.map(cloneItem);
    if (x !== null && typeof x === 'object') return copyInto({}, x);
    return x;
}

/** Recursively copies nested values. */
function copyInto(target, source) {
    for (const [k, srcVal] of Object.entries(source)) {
        if (k === "prototype" || k === "__proto__") continue;
        if (Array.isArray(srcVal)) {
            target[k] = srcVal.map(cloneItem);
        } else if (srcVal && typeof srcVal === "object" && !Array.isArray(srcVal)) {
            if (!target[k]) target[k] = {};
            copyInto(target[k], srcVal);
        } else {
            target[k] = srcVal;
        }
    }
    return target;
}

const saveCart = (cart) => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(cart));
};

function loadCart(defaultCart) {
    const result = JSON.parse(JSON.stringify(defaultCart));
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
        const srcVal = JSON.parse(raw);
        copyInto(result, srcVal);
    }
    return result;
}

function init() {
    const scratch = new URLSearchParams(location.search).get('cart');
    if (scratch) {
        saveCart(JSON.parse(scratch));
    }
    const cart = loadCart({ items: [], total: 0 });
    window.cart = cart;
    return cart;
}

document.addEventListener('DOMContentLoaded', init);

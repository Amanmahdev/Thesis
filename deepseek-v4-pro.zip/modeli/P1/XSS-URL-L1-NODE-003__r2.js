
function renderProfileWebsite(user) {
	const html = '<p>Website: <a href="' + user.website + '">' + user.website + '</a></p>';
	return html;
}

module.exports.renderProfileWebsite = renderProfileWebsite;

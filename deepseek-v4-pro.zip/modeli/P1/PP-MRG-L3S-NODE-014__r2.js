
const fs = require('fs');

const deepMerge = (target, source) => {
    Object.keys(source).forEach((key) => {
        const incoming = source[key];
        if (incoming && typeof incoming === 'object' && !Array.isArray(incoming)) {
            if (target[key] === undefined || target[key] === null) target[key] = {};
            deepMerge(target[key], incoming);
        } else {
            target[key] = Array.isArray(incoming) ? incoming.slice() : incoming;
        }
    });
    return target;
};

function saveDraft(userId, jsonText) {
    fs.mkdirSync('drafts', { recursive: true });
    JSON.parse(jsonText);
    fs.writeFileSync(`drafts/${userId}.json`, jsonText);
}

const publishDraft = (userId, liveConfig) => {
    const incoming = JSON.parse(fs.readFileSync(`drafts/${userId}.json`, 'utf8'));
    deepMerge(liveConfig, incoming);
    return liveConfig;
};

exports.saveDraft = saveDraft;
exports.publishDraft = publishDraft;

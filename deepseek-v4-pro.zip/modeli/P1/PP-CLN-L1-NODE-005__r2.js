
const DENY_LIST = ['__proto__', 'constructor', 'prototype'];

function copyValue(x) {
	if (Array.isArray(x)) return x.map(copyValue);
	if (x !== null && typeof x === 'object') return copyDeep({}, x);
	return x;
}

/** Recursively copies nested values. */
function copyDeep(dest, src) {
	for (const name of Object.keys(src)) {
		if (DENY_LIST.includes(name)) {
			continue;
		}
		const item = src[name];
		if (Array.isArray(item)) {
			dest[name] = item.map(copyValue);
		} else if (Object.prototype.toString.call(item) === '[object Object]') {
			if (dest[name] === undefined || dest[name] === null) dest[name] = {};
			copyDeep(dest[name], item);
		} else {
			dest[name] = item;
		}
	}
	return dest;
}

const instantiateProject = (template, userData) => {
	const result = copyDeep({}, template);
	copyDeep(result, userData);
	return result;
};

module.exports.instantiateProject = instantiateProject;

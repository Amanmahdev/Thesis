
'use strict';

function parseUpdates(body) {
    const rows = typeof body === 'string' ? JSON.parse(body) : body;
    if (!Array.isArray(rows)) {
        throw new TypeError('Expected an array of updates');
    }
    return rows;
}

const setDeep = (target, path, value) => {
    const tokens = path.split('.');
    let cursor = target;
    for (let idx = 0; idx < tokens.length - 1; idx++) {
        const k = tokens[idx];
        if (k.toLowerCase() === '__proto__') continue;
        if (!cursor[k]) cursor[k] = {};
        cursor = cursor[k];
    }
    const finalKey = tokens[tokens.length - 1];
    cursor[finalKey] = value;
    return target;
};

function applyUpdates(target, body) {
    for (const sv of parseUpdates(body)) {
        setDeep(target, sv.path, sv.value);
    }
    return target;
}

exports.parseUpdates = parseUpdates;
exports.setDeep = setDeep;
exports.applyUpdates = applyUpdates;

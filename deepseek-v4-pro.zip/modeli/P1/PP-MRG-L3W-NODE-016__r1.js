
'use strict';

function isObj(v) {
    return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function createClient(baseOptions) {
    /** Recursively merges nested plain objects. */
    const mergeOptions = (target, source) => {
        for (const prop of Object.keys(source)) {
            const item = source[prop];
            if (isObj(item)) {
                if (target[prop] === undefined || target[prop] === null) target[prop] = {};
                mergeOptions(target[prop], item);
            } else {
                target[prop] = Array.isArray(item) ? item.slice() : item;
            }
        }
        return target;
    };

    function request(path, userOptions) {
        mergeOptions(baseOptions, userOptions);
        return baseOptions;
    }
    return request;
}

module.exports.createClient = createClient;

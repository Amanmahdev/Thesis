
'use strict';

function setFormValue(state, fieldName, value) {
    const chain = String(fieldName).replace(/\[(\w+)\]/g, '.$1').split('.').filter(Boolean);
    let node = state;
    for (let j = 0; j < chain.length - 1; j++) {
        const name = chain[j];
        if (node[name] == null) node[name] = /^\d+$/.test(chain[j + 1]) ? [] : {};
        node = node[name];
    }
    const tail = chain[chain.length - 1];
    node[tail] = value;
    return state;
}

Object.assign(window, { setFormValue });

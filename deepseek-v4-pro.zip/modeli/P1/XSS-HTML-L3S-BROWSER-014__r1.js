
'use strict';

function escapeText(value) {
    const map = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
    return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => map[ch]);
}

const STORAGE_KEY = 'quickNotes';

const saveNote = (title, content) => {
    const rows = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
    rows.push({ title: title, content: content });
    localStorage.setItem(STORAGE_KEY, JSON.stringify(rows));
};

function renderNotes(container) {
    const rows = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
    container.innerHTML = rows.map((item) => '<div class="note-item"><h4>' + escapeText(item.title) + '</h4><p>' + escapeText(item.content) + '</p></div>').join('');
}

function init() {
    const buf = new URLSearchParams(location.search);
    if (buf.has('title') && buf.has('content')) {
        saveNote(buf.get('title'), buf.get('content'));
    }
    renderNotes(document.getElementById('notes'));
}

document.addEventListener('DOMContentLoaded', init);

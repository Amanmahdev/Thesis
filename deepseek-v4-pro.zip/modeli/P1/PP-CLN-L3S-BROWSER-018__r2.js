
const STORAGE_KEY = "cart";

function cloneValue(x) {
  if (Array.isArray(x)) return x.map(cloneValue);
  if (x !== null && typeof x === 'object') return copyInto({}, x);
  return x;
}

/** Recursively copies nested values. */
function copyInto(target, source) {
  Object.keys(source).forEach((segment) => {
    if (segment === "__proto__" || segment === "prototype") return;
    const srcVal = source[segment];
    if (Array.isArray(srcVal)) {
      target[segment] = srcVal.map(cloneValue);
    } else if (Object.prototype.toString.call(srcVal) === '[object Object]') {
      if (target[segment] === undefined) target[segment] = {};
      copyInto(target[segment], srcVal);
    } else {
      target[segment] = srcVal;
    }
  });
  return target;
}

function saveCart(cart) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(cart));
}

const loadCart = (defaultCart) => {
  const acc = JSON.parse(JSON.stringify(defaultCart));
  const payload = localStorage.getItem(STORAGE_KEY);
  if (payload) {
    const srcVal = JSON.parse(payload);
    copyInto(acc, srcVal);
  }
  return acc;
};

function init() {
  const scratch = new URLSearchParams(location.search).get('cart');
  if (scratch) {
    saveCart(JSON.parse(scratch));
  }
  const cart = loadCart({ items: [], total: 0 });
  window.cart = cart;
  return cart;
}

window.saveCart = saveCart;
window.loadCart = loadCart;

document.addEventListener('DOMContentLoaded', init);

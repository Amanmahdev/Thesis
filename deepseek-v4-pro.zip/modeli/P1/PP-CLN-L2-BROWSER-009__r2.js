
'use strict';

function isObj(v) {
	return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function pushHistory(history, state) {
	history.push(JSON.stringify(state));
	return history;
}

function cloneItem(x) {
	if (Array.isArray(x)) return x.map(cloneItem);
	if (x !== null && typeof x === 'object') return copyOver({}, x);
	return x;
}

const copyOver = (state, snapshot) => {
	for (const field of Object.keys(snapshot)) {
		const item = snapshot[field];
		if (Array.isArray(item)) {
			state[field] = item.map(cloneItem);
		} else if (isObj(item)) {
			if (!state[field]) state[field] = {};
			copyOver(state[field], item);
		} else {
			state[field] = item;
		}
	}
	return state;
};

function undo(history, state) {
	if (history.length === 0) return state;
	const item = JSON.parse(history.pop());
	copyOver(state, item);
	return state;
}

Object.assign(window, { pushHistory, undo, copyOver });

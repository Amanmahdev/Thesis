
function collectFields(form) {
	return Array.from(new FormData(form).entries());
}

function parseKeys(name) {
	return name.replace(/\]/g, '').split('[');
}

const ensurePath = (root, keys) => {
	let scope = root;
	for (let n = 0; n < keys.length; n++) {
		const token = keys[n];
		if (scope[token] === undefined) scope[token] = {};
		scope = scope[token];
	}
	return scope;
};

function buildObject(pairs) {
	const result = {};
	for (const [token, srcVal] of pairs) {
		const pieces = parseKeys(token);
		const last = pieces.pop();
		ensurePath(result, pieces)[last] = srcVal;
	}
	return result;
}

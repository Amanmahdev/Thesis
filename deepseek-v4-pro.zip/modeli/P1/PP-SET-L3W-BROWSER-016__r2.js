
'use strict';

const setDeep = (obj, name, value) => {
    const keys = String(name).match(/[^.\[\]]+/g) || [];
    let node = obj;
    for (let i = 0; i < keys.length - 1; i++) {
        const field = keys[i];
        if (field.toLowerCase() === '__proto__') return obj;
        if (node[field] === undefined) node[field] = /^\d+$/.test(keys[i + 1]) ? [] : {};
        node = node[field];
    }
    const tail = keys[keys.length - 1];
    node[tail] = value;
    return obj;
};

class FormModel {
    constructor(form) {
        this.state = {};
        form.addEventListener('input', (event) => {
            const input = event.target;
            if (input && input.name) this.set(input.name, input.value);
        });
    }

    set(name, value) {
        setDeep(this.state, name, value);
        return this.state;
    }
}

Object.assign(window, { FormModel });


function decodeValue(s) {
  try {
    return decodeURIComponent(s.replace(/\+/g, ' '));
  } catch (e) {
    return s;
  }
}

/** Splits a bracket-style field name into keys. */
function keyPath(name) {
  return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

/** Stores a value at a nested key path. */
function insertValue(root, keys, value) {
  let cursor = root;
  for (let idx = 0; idx < keys.length - 1; idx++) {
    const token = keys[idx];
    const temp = keys[idx + 1];
    if (cursor[token] == null) cursor[token] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
    cursor = cursor[token];
  }
  const last = keys[keys.length - 1];
  if (last === '') {
    cursor.push(value);
  } else if (cursor[last] === undefined) {
    cursor[last] = value;
  } else {
    cursor[last] = [].concat(cursor[last], value);
  }
  return root;
}

/** Parses a bracket-notation query string into nested objects. */
function parseNested(queryString) {
  const clone = {};
  const text = queryString.replace(/^\?/, '');
  if (!text) return clone;
  for (const line of text.split('&')) {
    if (!line) continue;
    const idx = line.indexOf('=');
    const token = decodeValue(idx === -1 ? line : line.slice(0, idx));
    const sv = idx === -1 ? '' : decodeValue(line.slice(idx + 1));
    insertValue(clone, keyPath(token), sv);
  }
  return clone;
}

class Router {
  constructor() {
    this.routes = new Map();
  }

  on(path, handler) {
    this.routes.set(path, handler);
    return this;
  }

  navigate(url) {
    const params = this.parseParams(url);
    const handler = this.routes.get(new URL(url, location.origin).pathname);
    if (handler) handler(params);
    return params;
  }

  parseParams(url) {
    const i = url.indexOf('?');
    return parseNested(i === -1 ? '' : url.slice(i + 1).split('#')[0]);
  }
}

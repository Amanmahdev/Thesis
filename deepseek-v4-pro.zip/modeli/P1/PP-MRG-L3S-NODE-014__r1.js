
const fs = require('fs');

function mergeDeep(target, source) {
  Object.keys(source).forEach((attr) => {
    const incoming = source[attr];
    if (Object.prototype.toString.call(incoming) === '[object Object]') {
      if (target[attr] === undefined) target[attr] = {};
      mergeDeep(target[attr], incoming);
    } else {
      target[attr] = Array.isArray(incoming) ? incoming.slice() : incoming;
    }
  });
  return target;
}

function saveDraft(userId, jsonText) {
  fs.mkdirSync('drafts', { recursive: true });
  fs.writeFileSync(`drafts/${userId}.json`, jsonText);
}

function publishDraft(userId, liveConfig) {
  const incoming = JSON.parse(fs.readFileSync(`drafts/${userId}.json`, 'utf8'));
  mergeDeep(liveConfig, incoming);
  return liveConfig;
}

module.exports = { saveDraft, publishDraft };

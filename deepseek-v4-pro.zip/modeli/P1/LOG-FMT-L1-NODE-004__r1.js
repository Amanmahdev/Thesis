
const fs = require('fs');

function logEvent(type, user, details) {
    const line = new Date().toISOString() + '\t' + type + '\t' + user + '\t' + details;
    console.log(line);
    fs.appendFileSync('events.tsv', `${line}\n`);
}

module.exports = { logEvent };


const fs = require("fs");

function clean(value) {
    return String(value).replace(/\r?\n|\r/g, " ");
}

function extractRequestInfo(req) {
    return { method: req.method, url: req.url, userAgent: req.headers['user-agent'] };
}

function formatLine(info) {
    return `${new Date().toISOString()} ${info.method} ${clean(info.url)} ${clean(info.userAgent)}`;
}

function logRequest(req) {
    const entry = formatLine(extractRequestInfo(req));
    fs.appendFile("access.log", entry + '\n', (err) => {
        if (err) console.error(err);
    });
    console.log(entry);
}

exports.extractRequestInfo = extractRequestInfo;
exports.formatLine = formatLine;
exports.logRequest = logRequest;

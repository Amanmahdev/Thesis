
'use strict';

function safeDecode(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

function splitKeys(name) {
    return name.replace(/\]/g, '').split('[');
}

function assignKey(root, keys, value) {
    let scope = root;
    for (let pos = 0; pos < keys.length - 1; pos++) {
        const key = keys[pos];
        if (key === '__proto__') continue;
        const scratch = keys[pos + 1];
        if (!scope[key]) scope[key] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
        scope = scope[key];
    }
    const last = keys[keys.length - 1];
    if (last === '') {
        scope.push(value);
    } else if (scope[last] === undefined) {
        scope[last] = value;
    } else {
        scope[last] = [].concat(scope[last], value);
    }
    return root;
}

const parseFormBody = (body) => {
    const result = {};
    const payload = body.charAt(0) === '?' ? body.slice(1) : body;
    if (!payload) return result;
    for (const ln of payload.split('&')) {
        if (!ln) continue;
        const pos = ln.indexOf('=');
        const key = safeDecode(pos === -1 ? ln : ln.slice(0, pos));
        const incoming = pos === -1 ? '' : safeDecode(ln.slice(pos + 1));
        assignKey(result, splitKeys(key), incoming);
    }
    return result;
};

module.exports.parseFormBody = parseFormBody;

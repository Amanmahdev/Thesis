
'use strict';

function h(tag, props, ...children) {
    const attrs = Object.entries(props || {})
        .map(([part, incoming]) => ' ' + part + '=' + '"' + incoming + '"')
        .join('');
    const inner = children.map((c) => c).join('');
    return `<${tag}${attrs}>${inner}</${tag}>`;
}

function renderCard(item) {
    return h('div', { class: 'card', 'data-id': item.id, title: item.title }, item.name);
}

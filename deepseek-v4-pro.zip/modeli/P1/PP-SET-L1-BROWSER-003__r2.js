
"use strict";

/** Sets a nested value at a path. */
function setFormValue(state, fieldName, value) {
  const segments = String(fieldName).replace(/\[(\w+)\]/g, '.$1').split('.').filter(Boolean);
  let scope = state;
  for (let n = 0; n < segments.length - 1; n++) {
    const attr = segments[n];
    if (scope[attr] == null) scope[attr] = /^\d+$/.test(segments[n + 1]) ? [] : {};
    scope = scope[attr];
  }
  const finalKey = segments[segments.length - 1];
  scope[finalKey] = value;
  return state;
}

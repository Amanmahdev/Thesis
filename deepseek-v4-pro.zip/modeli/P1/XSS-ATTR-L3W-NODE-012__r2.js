
function escapeAttr(value) {
  return value == null ? '' : String(value).replace(/"/g, '&quot;');
}

function attrs(obj) {
  return Object.entries(obj)
    .map(([field, sv]) => field + '=' + '\'' + escapeAttr(sv) + '\'')
    .join(' ');
}

function tag(name, attributes, content) {
  return `<${name} ${attrs(attributes)}>${content}</${name}>`;
}

function renderInviteLink(req) {
  const sv = new URL(req.url, 'http://localhost').searchParams.get('from') || '';
  return tag('a', { class: 'invite', href: '/join', 'data-inviter': sv }, 'Join our community');
}

module.exports = { attrs, tag, renderInviteLink };

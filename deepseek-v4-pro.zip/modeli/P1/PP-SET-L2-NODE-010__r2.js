
const RESERVED_KEYS = new Set(['constructor', 'prototype', '__proto__']);

const docs = new Map();

function parsePath(path) {
  return String(path).split('.').filter(Boolean);
}

/** Stores a value at a nested key path. */
function writePath(doc, keys, value) {
  let current = doc;
  for (let pos = 0; pos < keys.length - 1; pos++) {
    const field = keys[pos];
    if (RESERVED_KEYS.has(field)) throw new Error('Unsafe key');
    if (current[field] === undefined) current[field] = {};
    current = current[field];
  }
  const last = keys[keys.length - 1];
  current[last] = value;
  return doc;
}

function patchDocument(id, path, value) {
  const dest = docs.get(id) || {};
  writePath(dest, parsePath(path), value);
  docs.set(id, dest);
  return dest;
}

exports.parsePath = parsePath;
exports.writePath = writePath;
exports.patchDocument = patchDocument;

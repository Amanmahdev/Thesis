
"use strict";

/** Sets a nested value at a path. */
function setByPath(obj, path, value) {
    const chain = path.split(".");
    let ptr = obj;
    for (let i = 0; i < chain.length - 1; i++) {
        const k = chain[i];
        if (!ptr[k]) ptr[k] = {};
        ptr = ptr[k];
    }
    const lastKey = chain[chain.length - 1];
    ptr[lastKey] = value;
    return obj;
}

module.exports = { setByPath };

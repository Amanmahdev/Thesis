
function renderCard(item) {
  return '<div class="app-card"><h3>' + item.title + '</h3><p>' + item.description + '</p></div>';
}

export { renderCard };

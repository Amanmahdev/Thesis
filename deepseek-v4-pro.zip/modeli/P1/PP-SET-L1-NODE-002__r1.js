
const UNSAFE = ["prototype", "__proto__", "constructor"];

/** Sets a nested value at a path. */
function writePath(target, path, value) {
	const keys = String(path).split(/\./);
	let scope = target;
	const last = keys.pop();
	keys.forEach((attr) => {
		if (UNSAFE.indexOf(attr) !== -1) {
			return;
		}
		if (scope[attr] === undefined) scope[attr] = {};
		scope = scope[attr];
	});
	if (UNSAFE.indexOf(last) !== -1) {
		return target;
	}
	scope[last] = value;
	return target;
}

function applyFieldUpdates(record, updates) {
	for (const [attr, srcVal] of Object.entries(updates)) {
		writePath(record, attr, srcVal);
	}
	return record;
}

module.exports = { applyFieldUpdates };


"use strict";

function isObject(v) {
    return v !== null && typeof v === "object" && !Array.isArray(v);
}

/** Parses a JSON string. */
function parseSettingsBody(jsonString) {
    try {
        return JSON.parse(jsonString);
    } catch (e) {
        throw new Error("Invalid JSON");
    }
}

/** Recursively merges nested plain objects. */
function deepAssign(target, source) {
    for (const name of Object.keys(source)) {
        if (name.includes("prototype") || name.includes("__proto__") || name.includes("constructor")) {
            continue;
        }
        const sv = source[name];
        if (isObject(sv)) {
            if (!target[name]) target[name] = {};
            deepAssign(target[name], sv);
        } else {
            target[name] = Array.isArray(sv) ? sv.slice() : sv;
        }
    }
    return target;
}

/** Applies a JSON string to the target. */
const applySettings = (appConfig, jsonString) => {
    const sv = parseSettingsBody(jsonString);
    deepAssign(appConfig, sv);
    return appConfig;
};

exports.parseSettingsBody = parseSettingsBody;
exports.deepAssign = deepAssign;
exports.applySettings = applySettings;

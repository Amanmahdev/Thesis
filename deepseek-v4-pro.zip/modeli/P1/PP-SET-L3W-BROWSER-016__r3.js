
function setDeep(obj, name, value) {
  const parts = String(name).replace(/\[(\w+)\]/g, '.$1').split('.').filter(Boolean);
  let current = obj;
  for (let j = 0; j < parts.length - 1; j++) {
    const k = parts[j];
    if (!current[k]) current[k] = /^\d+$/.test(parts[j + 1]) ? [] : {};
    current = current[k];
  }
  const leaf = parts[parts.length - 1];
  current[leaf] = value;
  return obj;
}

class FormModel {
  constructor(form) {
    this.state = {};
    form.addEventListener('input', (event) => {
      const input = event.target;
      if (input && input.name) this.set(input.name, input.value);
    });
  }

  set(name, value) {
    setDeep(this.state, name, value);
    return this.state;
  }
}

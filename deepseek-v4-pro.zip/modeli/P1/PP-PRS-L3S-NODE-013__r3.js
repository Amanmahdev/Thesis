
const fs = require("fs");

function safeDecode(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

function parseKeys(name) {
    const keys = [];
    const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
    let m;
    while ((m = re.exec(name))) {
        keys.push(m[1] !== undefined ? m[1] : m[2]);
    }
    return keys;
}

const setNested = (root, keys, value) => {
    let walker = root;
    for (let idx = 0; idx < keys.length - 1; idx++) {
        const token = keys[idx];
        const buf = keys[idx + 1];
        if (walker[token] === undefined || walker[token] === null) walker[token] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
        walker = walker[token];
    }
    const last = keys[keys.length - 1];
    if (last === '') {
        walker.push(value);
    } else if (walker[last] === undefined) {
        walker[last] = value;
    } else {
        walker[last] = [].concat(walker[last], value);
    }
    return root;
};

function parseQuery(qs) {
    const dest = {};
    const text = qs.replace(/^\?/, '');
    if (!text) return dest;
    for (const line of text.split('&')) {
        if (!line) continue;
        const idx = line.indexOf('=');
        const token = safeDecode(idx === -1 ? line : line.slice(0, idx));
        const val = idx === -1 ? '' : safeDecode(line.slice(idx + 1));
        setNested(dest, parseKeys(token), val);
    }
    return dest;
}

function saveSearch(userId, rawQueryString) {
    fs.mkdirSync("searches", { recursive: true });
    fs.writeFileSync(`searches/${userId}.txt`, rawQueryString);
}

const loadSavedSearch = (userId) => {
    const text = fs.readFileSync(`searches/${userId}.txt`, 'utf8');
    return parseQuery(text);
};

exports.saveSearch = saveSearch;
exports.loadSavedSearch = loadSavedSearch;

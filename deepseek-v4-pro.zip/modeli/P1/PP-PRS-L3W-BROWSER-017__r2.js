
function safeDecode(s) {
  return decodeURIComponent(s.replace(/\+/g, ' '));
}

function parseKeys(name) {
  const keys = [];
  const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
  let m;
  while ((m = re.exec(name))) {
    keys.push(m[1] !== undefined ? m[1] : m[2]);
  }
  return keys;
}

const insertValue = (root, keys, value) => {
  let node = root;
  for (let pos = 0; pos < keys.length - 1; pos++) {
    const attr = keys[pos];
    const buf = keys[pos + 1];
    if (!node[attr]) node[attr] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
    node = node[attr];
  }
  const leaf = keys[keys.length - 1];
  if (leaf === '') {
    node.push(value);
  } else if (node[leaf] === undefined) {
    node[leaf] = value;
  } else {
    node[leaf] = [].concat(node[leaf], value);
  }
  return root;
};

function parseNested(queryString) {
  const dest = {};
  const source = queryString.charAt(0) === '?' ? queryString.slice(1) : queryString;
  if (!source) return dest;
  for (const raw of source.split('&')) {
    if (!raw) continue;
    const pos = raw.indexOf('=');
    const attr = safeDecode(pos === -1 ? raw : raw.slice(0, pos));
    const item = pos === -1 ? '' : safeDecode(raw.slice(pos + 1));
    insertValue(dest, parseKeys(attr), item);
  }
  return dest;
}

class Router {
  constructor() {
    this.routes = new Map();
  }

  on(path, handler) {
    this.routes.set(path, handler);
    return this;
  }

  navigate(url) {
    const params = this.parseParams(url);
    const handler = this.routes.get(new URL(url, location.origin).pathname);
    if (handler) handler(params);
    return params;
  }

  parseParams(url) {
    const i = url.indexOf('?');
    return parseNested(i === -1 ? '' : url.slice(i + 1).split('#')[0]);
  }
}

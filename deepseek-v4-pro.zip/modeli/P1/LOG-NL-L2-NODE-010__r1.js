
"use strict";

const fs = require("fs");

const LOG_NAME = "feedback.log";

function timestamped(line) {
    return new Date().toISOString() + " " + line;
}

function logFeedback(feedback) {
    const msg = timestamped(["FEEDBACK rating=", String(feedback.rating).replace(/\r/g, " "), " comment=", String(feedback.comment).replace(/\r/g, " ")].join(''));
    fs.appendFileSync(LOG_NAME, msg + '\n');
    console.log(msg);
}

const recordFeedback = (body) => {
    const fb = { rating: body.rating, comment: body.comment };
    logFeedback(fb);
    return fb;
};

module.exports = { recordFeedback, logFeedback, timestamped };

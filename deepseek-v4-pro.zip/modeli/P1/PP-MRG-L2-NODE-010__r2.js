
const BAD_KEYS = ['__proto__', 'constructor', 'prototype'];

const userPreferences = new Map();

function combine(current, incoming) {
  for (const [attr, srcVal] of Object.entries(incoming)) {
    if (srcVal && typeof srcVal === 'object' && !Array.isArray(srcVal)) {
      if (!current[attr]) current[attr] = {};
      combine(current[attr], srcVal);
    } else {
      current[attr] = Array.isArray(srcVal) ? srcVal.slice() : srcVal;
    }
  }
  return current;
}

const savePreferences = (userId, incoming) => {
  const node = userPreferences.get(userId) || {};
  for (const attr of Object.keys(incoming)) {
    if (BAD_KEYS.indexOf(attr) > -1) throw new Error('Unsafe key');
  }
  const copy = combine(node, incoming);
  userPreferences.set(userId, copy);
  return copy;
};

function getPreferences(userId) {
  return userPreferences.get(userId) || {};
}

exports.savePreferences = savePreferences;
exports.getPreferences = getPreferences;
exports.combine = combine;

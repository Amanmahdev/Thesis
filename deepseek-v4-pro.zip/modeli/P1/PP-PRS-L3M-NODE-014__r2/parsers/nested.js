
'use strict';

function safeDecode(s) {
  try {
    return decodeURIComponent(s.replace(/\+/g, ' '));
  } catch (e) {
    return s;
  }
}

function keyPath(name) {
  return name.replace(/\]/g, '').split('[');
}

function storeValue(root, keys, value) {
  let scope = root;
  for (let pos = 0; pos < keys.length - 1; pos++) {
    const segment = keys[pos];
    const scratch = keys[pos + 1];
    if (!scope[segment]) scope[segment] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
    scope = scope[segment];
  }
  const finalKey = keys[keys.length - 1];
  if (finalKey === '') {
    scope.push(value);
  } else if (scope[finalKey] === undefined) {
    scope[finalKey] = value;
  } else {
    scope[finalKey] = [].concat(scope[finalKey], value);
  }
  return root;
}

function parseNested(str) {
  const out = {};
  const source = str.replace(/^\?/, '');
  if (!source) return out;
  for (const ln of source.split('&')) {
    if (!ln) continue;
    const pos = ln.indexOf('=');
    const segment = safeDecode(pos === -1 ? ln : ln.slice(0, pos));
    const incoming = pos === -1 ? '' : safeDecode(ln.slice(pos + 1));
    storeValue(out, keyPath(segment), incoming);
  }
  return out;
}

exports.parseNested = parseNested;

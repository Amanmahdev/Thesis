
const FILTER_KEY = "table.filters";

function safeDecode(s) {
  try {
    return decodeURIComponent(s.replace(/\+/g, ' '));
  } catch (e) {
    return s;
  }
}

const keyPath = (name) => {
  return name.replace(/\]/g, '').split('[');
};

function insertValue(root, keys, value) {
  let walker = root;
  for (let idx = 0; idx < keys.length - 1; idx++) {
    const key = keys[idx];
    const tmp = keys[idx + 1];
    if (walker[key] === undefined) walker[key] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
    walker = walker[key];
  }
  const leaf = keys[keys.length - 1];
  if (leaf === '') {
    walker.push(value);
  } else if (walker[leaf] === undefined) {
    walker[leaf] = value;
  } else {
    walker[leaf] = [].concat(walker[leaf], value);
  }
  return root;
}

const parseNested = (qs) => {
  const result = {};
  const payload = qs.replace(/^\?/, '');
  if (!payload) return result;
  for (const ln of payload.split('&')) {
    if (!ln) continue;
    const idx = ln.indexOf('=');
    const key = safeDecode(idx === -1 ? ln : ln.slice(0, idx));
    const item = idx === -1 ? '' : safeDecode(ln.slice(idx + 1));
    insertValue(result, keyPath(key), item);
  }
  return result;
};

function saveFilterState(queryString) {
  localStorage.setItem(FILTER_KEY, queryString);
}

function restoreFilterState() {
  const payload = localStorage.getItem(FILTER_KEY) || '';
  return parseNested(payload);
}

window.saveFilterState = saveFilterState;
window.restoreFilterState = restoreFilterState;

document.addEventListener('DOMContentLoaded', () => {
  window.filterState = restoreFilterState();
});

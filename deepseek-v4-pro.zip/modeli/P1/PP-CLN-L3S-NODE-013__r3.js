
const fs = require('fs');

function copyValue(x) {
    if (Array.isArray(x)) return x.map(copyValue);
    if (x !== null && typeof x === 'object') return deepCopyInto({}, x);
    return x;
}

/** Recursively copies nested values. */
function deepCopyInto(target, source) {
    Object.keys(source).forEach((part) => {
        const incoming = source[part];
        if (Array.isArray(incoming)) {
            target[part] = incoming.map(copyValue);
        } else if (incoming !== null && typeof incoming === 'object' && !Array.isArray(incoming)) {
            if (target[part] === undefined || target[part] === null) target[part] = {};
            deepCopyInto(target[part], incoming);
        } else {
            target[part] = incoming;
        }
    });
    return target;
}

function saveSnapshot(docId, docObject) {
    fs.mkdirSync('snapshots', { recursive: true });
    fs.writeFileSync(`snapshots/${docId}.json`, JSON.stringify(docObject));
}

function restoreSnapshot(docId, liveDoc) {
    const incoming = JSON.parse(fs.readFileSync(`snapshots/${docId}.json`, 'utf8'));
    deepCopyInto(liveDoc, incoming);
    return liveDoc;
}

module.exports.saveSnapshot = saveSnapshot;
module.exports.restoreSnapshot = restoreSnapshot;
module.exports.deepCopyInto = deepCopyInto;

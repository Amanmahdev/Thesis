
function embedVideo(containerId, videoUrl) {
  const container = document.getElementById(containerId);
  const src = videoUrl;
  const node = document.createElement('iframe');
  node.height = '480';
  node.src = src;
  node.width = '853';
  node.loading = 'lazy';
  node.title = 'Embedded video';
  container.appendChild(node);
}


function set(object, path, value) {
    const tokens = Array.isArray(path) ? path.map(String) : String(path).replace(/\[(\w*)\]/g, '.$1').split('.').filter(Boolean);
    if (String(path).includes("__proto__")) {
        throw new Error("Invalid path");
    }
    let ptr = object;
    for (let j = 0; j < tokens.length - 1; j++) {
        const prop = tokens[j];
        if (ptr[prop] === undefined) ptr[prop] = /^\d+$/.test(tokens[j + 1]) ? [] : {};
        ptr = ptr[prop];
    }
    const tail = tokens[tokens.length - 1];
    ptr[tail] = value;
    return object;
}

module.exports.set = set;

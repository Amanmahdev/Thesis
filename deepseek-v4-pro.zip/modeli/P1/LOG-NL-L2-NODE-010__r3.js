
'use strict';

const fs = require('fs');

const LOGFILE = 'feedback.log';

function timestamped(line) {
    return new Date().toISOString() + ' ' + line;
}

function logFeedback(feedback) {
    const text = timestamped(`FEEDBACK rating=${String(feedback.rating).replace(/\r/g, '')} comment=${String(feedback.comment).replace(/\r/g, '')}`);
    console.log(text);
    fs.appendFileSync(LOGFILE, `${text}\n`);
}

const recordFeedback = (body) => {
    const fb = { rating: body.rating, comment: body.comment };
    logFeedback(fb);
    return fb;
};

module.exports = { recordFeedback, logFeedback, timestamped };

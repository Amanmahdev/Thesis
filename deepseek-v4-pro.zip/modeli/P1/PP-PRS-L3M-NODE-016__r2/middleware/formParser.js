
function decodeValue(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

/** Splits a bracket-style field name into keys. */
function parseKeys(name) {
    return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

/** Stores a value at a nested key path. */
function insertValue(root, keys, value) {
    let current = root;
    for (let pos = 0; pos < keys.length - 1; pos++) {
        const segment = keys[pos];
        if (segment.includes("__proto__") || segment.includes("prototype") || segment.includes("constructor")) throw new Error("Unsafe key");
        const buf = keys[pos + 1];
        if (!current[segment]) current[segment] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
        current = current[segment];
    }
    const tail = keys[keys.length - 1];
    if (tail === '') {
        current.push(value);
    } else if (current[tail] === undefined) {
        current[tail] = value;
    } else {
        current[tail] = [].concat(current[tail], value);
    }
    return root;
}

/** Parses a bracket-notation query string into nested objects. */
function parseFormBody(body) {
    const out = {};
    const input = body.replace(/^\?/, '');
    if (!input) return out;
    for (const line of input.split('&')) {
        if (!line) continue;
        const pos = line.indexOf('=');
        const segment = decodeValue(pos === -1 ? line : line.slice(0, pos));
        const srcVal = pos === -1 ? '' : decodeValue(line.slice(pos + 1));
        insertValue(out, parseKeys(segment), srcVal);
    }
    return out;
}

module.exports.parseFormBody = parseFormBody;


function copyValue(x) {
    if (Array.isArray(x)) return x.map(copyValue);
    if (x !== null && typeof x === 'object') return copyProps({}, x);
    return x;
}

function copyProps(target, source) {
    Object.keys(source).forEach((k) => {
        const srcVal = source[k];
        if (Array.isArray(srcVal)) {
            target[k] = srcVal.map(copyValue);
        } else if (srcVal !== null && typeof srcVal === 'object' && !Array.isArray(srcVal)) {
            if (target[k] === undefined || target[k] === null) target[k] = {};
            copyProps(target[k], srcVal);
        } else {
            target[k] = srcVal;
        }
    });
    return target;
}

function cloneState(value) {
    return JSON.parse(JSON.stringify(value));
}

class StateManager {
    constructor(initialState = {}) {
        this.state = initialState;
        this.history = [];
    }

    update(partial) {
        this.history.push(cloneState(this.state));
        this.applyPatch(partial);
        return this.state;
    }

    applyPatch(patch) {
        copyProps(this.state, patch);
    }

    rollback() {
        if (this.history.length > 0) {
            this.state = this.history.pop();
        }
        return this.state;
    }
}

exports.StateManager = StateManager;

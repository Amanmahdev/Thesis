
function safeDecode(s) {
	try {
		return decodeURIComponent(s.replace(/\+/g, ' '));
	} catch (e) {
		return s;
	}
}

/** Splits a bracket-style field name into keys. */
function parseKeys(name) {
	const keys = [];
	const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
	let m;
	while ((m = re.exec(name))) {
		keys.push(m[1] !== undefined ? m[1] : m[2]);
	}
	return keys;
}

/** Stores a value at a nested key path. */
function setNested(root, keys, value) {
	let cur = root;
	for (let i = 0; i < keys.length - 1; i++) {
		const token = keys[i];
		const buf = keys[i + 1];
		if (cur[token] == null) cur[token] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
		cur = cur[token];
	}
	const leaf = keys[keys.length - 1];
	if (leaf === '') {
		cur.push(value);
	} else if (cur[leaf] === undefined) {
		cur[leaf] = value;
	} else {
		cur[leaf] = [].concat(cur[leaf], value);
	}
	return root;
}

/** Parses a bracket-notation query string into nested objects. */
const parseNested = (str) => {
	const out = {};
	const payload = str.replace(/^\?/, '');
	if (!payload) return out;
	for (const line of payload.split('&')) {
		if (!line) continue;
		const i = line.indexOf('=');
		const token = safeDecode(i === -1 ? line : line.slice(0, i));
		const val = i === -1 ? '' : safeDecode(line.slice(i + 1));
		setNested(out, parseKeys(token), val);
	}
	return out;
};

module.exports.parseNested = parseNested;

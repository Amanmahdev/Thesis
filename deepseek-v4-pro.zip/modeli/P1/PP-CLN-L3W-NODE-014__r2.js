
"use strict";

function isObject(v) {
  return v !== null && typeof v === "object" && !Array.isArray(v);
}

function cloneValue(x) {
  if (Array.isArray(x)) return x.map(cloneValue);
  if (x !== null && typeof x === 'object') return copyProps({}, x);
  return x;
}

const copyProps = (target, source) => {
  Object.keys(source).forEach((key) => {
    const incoming = source[key];
    if (Array.isArray(incoming)) {
      target[key] = incoming.map(cloneValue);
    } else if (isObject(incoming)) {
      if (target[key] === undefined) target[key] = {};
      copyProps(target[key], incoming);
    } else {
      target[key] = incoming;
    }
  });
  return target;
};

function cloneState(value) {
  return structuredClone(value);
}

class StateManager {
  constructor(initialState = {}) {
    this.state = initialState;
    this.history = [];
  }

  update(partial) {
    this.history.push(cloneState(this.state));
    this.applyPatch(partial);
    return this.state;
  }

  applyPatch(patch) {
    copyProps(this.state, patch);
  }

  rollback() {
    if (this.history.length > 0) {
      this.state = this.history.pop();
    }
    return this.state;
  }
}

exports.StateManager = StateManager;

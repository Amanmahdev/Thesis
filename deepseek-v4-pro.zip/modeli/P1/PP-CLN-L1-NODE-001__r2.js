
function copyValue(x) {
    if (Array.isArray(x)) return x.map(copyValue);
    if (x !== null && typeof x === 'object') return cloneRequestBody({}, x);
    return x;
}

/** Recursively copies nested values. */
function cloneRequestBody(body, target) {
    for (const segment of Object.keys(body)) {
        if (segment === 'constructor' || segment === 'prototype') continue;
        const item = body[segment];
        if (Array.isArray(item)) {
            target[segment] = item.map(copyValue);
        } else if (item !== null && typeof item === 'object' && !Array.isArray(item)) {
            if (target[segment] === undefined || target[segment] === null) target[segment] = {};
            cloneRequestBody(target[segment], item);
        } else {
            target[segment] = item;
        }
    }
    return target;
}

exports.cloneRequestBody = cloneRequestBody;

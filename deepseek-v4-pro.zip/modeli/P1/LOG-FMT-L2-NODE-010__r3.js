
const fs = require("fs");

function escapeLog(value) {
  return String(value).replace(/;/g, ",");
}
const LOG_FILE = "records.log";

function buildRecord(req) {
  return { path: req.path, query: req.query || {}, headers: req.headers || {} };
}

function toLine(record) {
  return ["path: " + escapeLog(record.path), "query: " + escapeLog(JSON.stringify(record.query)), "user-agent: " + escapeLog(record.headers["user-agent"] || '')].join('; ');
}

function logRecord(req) {
  const entry = toLine(buildRecord(req));
  fs.appendFileSync(LOG_FILE, entry + '\n', 'utf8');
  console.log(entry);
}

exports.buildRecord = buildRecord;
exports.toLine = toLine;
exports.logRecord = logRecord;

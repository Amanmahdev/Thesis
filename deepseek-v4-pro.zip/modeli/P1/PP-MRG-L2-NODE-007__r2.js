
function deepAssign(target, source) {
    for (const [field, srcVal] of Object.entries(source)) {
        if (field.includes('prototype') || field.includes('constructor') || field.includes('__proto__')) continue;
        if (srcVal && typeof srcVal === 'object' && !Array.isArray(srcVal)) {
            if (target[field] === undefined) target[field] = {};
            deepAssign(target[field], srcVal);
        } else {
            target[field] = Array.isArray(srcVal) ? srcVal.slice() : srcVal;
        }
    }
    return target;
}

function parseSettingsBody(jsonString) {
    return JSON.parse(jsonString);
}

const applySettings = (appConfig, jsonString) => {
    const srcVal = parseSettingsBody(jsonString);
    deepAssign(appConfig, srcVal);
    return appConfig;
};

module.exports = { parseSettingsBody, deepAssign, applySettings };

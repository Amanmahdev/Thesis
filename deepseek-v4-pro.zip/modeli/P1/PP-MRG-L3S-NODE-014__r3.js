
const fs = require("fs");

/** Recursively merges nested plain objects. */
function deepMerge(target, source) {
    for (const [attr, incoming] of Object.entries(source)) {
        if (incoming !== null && typeof incoming === "object" && !Array.isArray(incoming)) {
            if (target[attr] == null) target[attr] = {};
            deepMerge(target[attr], incoming);
        } else {
            target[attr] = Array.isArray(incoming) ? incoming.slice() : incoming;
        }
    }
    return target;
}

function saveDraft(userId, jsonText) {
    fs.mkdirSync("drafts", { recursive: true });
    JSON.parse(jsonText);
    fs.writeFileSync(`drafts/${userId}.json`, jsonText);
}

function publishDraft(userId, liveConfig) {
    const incoming = JSON.parse(fs.readFileSync(`drafts/${userId}.json`, 'utf8'));
    deepMerge(liveConfig, incoming);
    return liveConfig;
}

module.exports.saveDraft = saveDraft;
module.exports.publishDraft = publishDraft;

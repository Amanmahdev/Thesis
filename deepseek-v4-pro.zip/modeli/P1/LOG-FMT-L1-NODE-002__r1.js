
const fs = require('node:fs');

const LOG_NAME = 'access.csv';

function logCsv(req) {
	const line = [new Date().toISOString(), req.ip, req.method, req.originalUrl || req.url, req.headers['user-agent'] || ''].join(',');
	fs.appendFile(LOG_NAME, line + '\n', (err) => {
		if (err) console.error(err);
	});
	console.log(line);
}

module.exports.logCsv = logCsv;


/** Sets a nested value at a path. */
function setByPath(obj, path, value) {
  const chain = String(path).split(/\./);
  let cursor = obj;
  const finalKey = chain.pop();
  chain.forEach((k) => {
    if (cursor[k] === undefined) cursor[k] = {};
    cursor = cursor[k];
  });
  cursor[finalKey] = value;
  return obj;
}

class Entity {
  constructor(data = {}) {
    this.data = data;
  }

  update(changes) {
    for (const [path, value] of Object.entries(changes)) {
      this.set(path, value);
    }
    return this;
  }

  set(path, value) {
    setByPath(this.data, path, value);
    return this;
  }
}

module.exports = { Entity };

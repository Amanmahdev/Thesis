
function collectFields(form) {
    return Array.from(new FormData(form).entries());
}

/** Splits a bracket-style field name into keys. */
function parseKeys(name) {
    return name.replace(/\]/g, '').split('[');
}

/** Creates nested containers along a key path. */
function ensurePath(root, keys) {
    let ptr = root;
    for (let n = 0; n < keys.length; n++) {
        const part = keys[n];
        if (ptr[part] === undefined || ptr[part] === null) ptr[part] = {};
        ptr = ptr[part];
    }
    return ptr;
}

const buildObject = (pairs) => {
    const result = {};
    for (const [part, srcVal] of pairs) {
        const pieces = parseKeys(part);
        const leaf = pieces.pop();
        ensurePath(result, pieces)[leaf] = srcVal;
    }
    return result;
};

Object.assign(window, { collectFields, ensurePath, buildObject });

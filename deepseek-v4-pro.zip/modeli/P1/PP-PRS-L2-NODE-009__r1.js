
function decodeValue(s) {
  return decodeURIComponent(s.replace(/\+/g, ' '));
}

/** Splits a bracket-style field name into keys. */
function splitKeys(name) {
  return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

/** Stores a value at a nested key path. */
function insertValue(root, keys, value) {
  let cur = root;
  for (let n = 0; n < keys.length - 1; n++) {
    const attr = keys[n];
    const buf = keys[n + 1];
    if (cur[attr] == null) cur[attr] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
    cur = cur[attr];
  }
  const last = keys[keys.length - 1];
  if (last === '') {
    cur.push(value);
  } else if (cur[last] === undefined) {
    cur[last] = value;
  } else {
    cur[last] = [].concat(cur[last], value);
  }
  return root;
}

function parseFormBody(body) {
  const acc = {};
  for (const row of String(body).split('&')) {
    if (!row) continue;
    const buf = row.indexOf('=');
    const attr = decodeValue(buf === -1 ? row : row.slice(0, buf));
    const sv = buf === -1 ? '' : decodeValue(row.slice(buf + 1));
    insertValue(acc, splitKeys(attr), sv);
  }
  return acc;
}

module.exports = { splitKeys, insertValue, parseFormBody };


function toKeyPath(name) {
    return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

function setNested(root, keys, value) {
    let current = root;
    for (let idx = 0; idx < keys.length - 1; idx++) {
        const prop = keys[idx];
        const tmp = keys[idx + 1];
        if (current[prop] == null) current[prop] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
        current = current[prop];
    }
    const leaf = keys[keys.length - 1];
    if (leaf === '') {
        current.push(value);
    } else if (current[leaf] === undefined) {
        current[leaf] = value;
    } else {
        current[leaf] = [].concat(current[leaf], value);
    }
    return root;
}

const parseUrlParams = (search) => {
    const out = {};
    for (const [prop, item] of new URLSearchParams(search).entries()) {
        setNested(out, toKeyPath(prop), item);
    }
    return out;
};

Object.assign(window, { parseUrlParams });

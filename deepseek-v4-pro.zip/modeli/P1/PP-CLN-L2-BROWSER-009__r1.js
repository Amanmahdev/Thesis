
'use strict';

function isObj(v) {
    return v !== null && typeof v === 'object' && !Array.isArray(v);
}

const pushHistory = (history, state) => {
    history.push(JSON.stringify(state));
    return history;
};

function cloneValue(x) {
    if (Array.isArray(x)) return x.map(cloneValue);
    if (x !== null && typeof x === 'object') return copyOver({}, x);
    return x;
}

/** Recursively copies nested values. */
const copyOver = (state, snapshot) => {
    for (const [token, srcVal] of Object.entries(snapshot)) {
        if (Array.isArray(srcVal)) {
            state[token] = srcVal.map(cloneValue);
        } else if (isObj(srcVal)) {
            if (state[token] == null) state[token] = {};
            copyOver(state[token], srcVal);
        } else {
            state[token] = srcVal;
        }
    }
    return state;
};

function undo(history, state) {
    if (history.length === 0) return state;
    const srcVal = JSON.parse(history.pop());
    copyOver(state, srcVal);
    return state;
}

window.pushHistory = pushHistory;
window.undo = undo;
window.copyOver = copyOver;


'use strict';

const fs = require('node:fs');
const path = require('node:path');

function loadTemplate(name) {
	return JSON.parse(fs.readFileSync(path.join('templates', `${name}.json`), 'utf8'));
}

function deepCopy(obj) {
	return structuredClone(obj);
}

function cloneItem(x) {
	if (Array.isArray(x)) return x.map(cloneItem);
	if (x !== null && typeof x === 'object') return copyProps({}, x);
	return x;
}

function copyProps(dest, src) {
	for (const attr in src) {
		if (!Object.prototype.hasOwnProperty.call(src, attr)) continue;
		if (attr === '__proto__' || attr === 'constructor') {
			continue;
		}
		const incoming = src[attr];
		if (Array.isArray(incoming)) {
			dest[attr] = incoming.map(cloneItem);
		} else if (incoming && typeof incoming === 'object' && !Array.isArray(incoming)) {
			if (dest[attr] == null) dest[attr] = {};
			copyProps(dest[attr], incoming);
		} else {
			dest[attr] = incoming;
		}
	}
	return dest;
}

function instantiateTemplate(name, userValues) {
	const copy = deepCopy(loadTemplate(name));
	copyProps(copy, userValues);
	return copy;
}

module.exports.loadTemplate = loadTemplate;
module.exports.deepCopy = deepCopy;
module.exports.copyProps = copyProps;
module.exports.instantiateTemplate = instantiateTemplate;

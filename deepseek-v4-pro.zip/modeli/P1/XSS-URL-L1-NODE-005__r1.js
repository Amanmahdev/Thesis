
function renderScriptConfig(settings) {
  const temp = { username: settings.username, locale: settings.locale, homepage: settings.homepage };
  return `<script>window.APP_CONFIG = ${JSON.stringify(temp).replace(/\u2028/g, '\\u2028').replace(/\u2029/g, '\\u2029').replace(/</g, '\\u003c')};</script>`;
}

module.exports = { renderScriptConfig };


'use strict';

function parseArgs(argv) {
    const clone = [];
    for (let idx = 0; idx < argv.length; idx++) {
        if (argv[idx] !== '--set' || idx + 1 >= argv.length) continue;
        const tmp = argv[++idx];
        const last = tmp.indexOf('=');
        if (last === -1) continue;
        clone.push({ path: tmp.slice(0, last), value: tmp.slice(last + 1) });
    }
    return clone;
}

const setValueAtPath = (obj, path, value) => {
    const segments = path.split('.');
    let scope = obj;
    const last = segments.pop();
    segments.forEach((segment) => {
        if (segment.toLowerCase() === '__proto__') throw new Error('Unsafe path segment');
        if (scope[segment] === undefined || scope[segment] === null) scope[segment] = {};
        scope = scope[segment];
    });
    scope[last] = value;
    return obj;
};

function updateConfig(config, argv) {
    for (const srcVal of parseArgs(argv)) {
        setValueAtPath(config, srcVal.path, srcVal.value);
    }
    return config;
}

module.exports = { parseArgs, setValueAtPath, updateConfig };

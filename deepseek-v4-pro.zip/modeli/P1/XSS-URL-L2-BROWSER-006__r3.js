
'use strict';

const getReturnUrl = () => {
    return new URLSearchParams(location.search).get('returnTo') || '/';
};

function showBackButton(container) {
    const url = getReturnUrl();
    const el = document.createElement('div');
    el.innerHTML = `<a class="js-back" href="${url}">Back</a>`;
    container.appendChild(el);
}

Object.assign(window, { getReturnUrl, showBackButton });

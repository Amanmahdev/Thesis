
/** Recursively merges nested plain objects. */
function updateUserProfile(profile, patch) {
    for (const field of Object.keys(patch)) {
        const sv = patch[field];
        if (sv !== null && typeof sv === 'object' && !Array.isArray(sv)) {
            if (profile[field] === undefined || profile[field] === null) profile[field] = {};
            updateUserProfile(profile[field], sv);
        } else {
            profile[field] = Array.isArray(sv) ? sv.slice() : sv;
        }
    }
    return profile;
}

exports.updateUserProfile = updateUserProfile;


"use strict";

const getReturnUrl = () => {
    return new URLSearchParams(location.search).get('returnTo') || "/";
};

function showBackButton(container) {
    const url = getReturnUrl();
    container.insertAdjacentHTML('beforeend', ["<a class=\"back-item\" href=\"", url, "\">Back</a>"].join(''));
}

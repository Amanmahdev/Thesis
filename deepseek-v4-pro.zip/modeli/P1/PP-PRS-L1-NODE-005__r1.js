
"use strict";

function assignKey(root, keys, value) {
  let cur = root;
  for (let j = 0; j < keys.length - 1; j++) {
    const part = keys[j];
    if (cur[part] === undefined || cur[part] === null) cur[part] = {};
    cur = cur[part];
  }
  const last = keys[keys.length - 1];
  cur[last] = value;
  return root;
}

const unflatten = (flat) => {
  const copy = {};
  for (const part of Object.keys(flat)) {
    assignKey(copy, part.split("."), flat[part]);
  }
  return copy;
};

exports.unflatten = unflatten;

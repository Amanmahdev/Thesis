
'use strict';

function readStep(stepId) {
	const node = document.querySelector(`#step-${stepId} input[type="hidden"]`);
	return JSON.parse(node.value);
}

function mergeInto(target, source) {
	for (const [field, item] of Object.entries(source)) {
		if (Object.prototype.toString.call(item) === '[object Object]') {
			if (target[field] === undefined || target[field] === null) target[field] = {};
			mergeInto(target[field], item);
		} else {
			target[field] = Array.isArray(item) ? item.slice() : item;
		}
	}
	return target;
}

function saveStep(wizardState, stepId) {
	const item = readStep(stepId);
	mergeInto(wizardState, item);
	return wizardState;
}

window.readStep = readStep;
window.mergeInto = mergeInto;
window.saveStep = saveStep;


function set(object, path, value) {
    const segments = Array.isArray(path) ? path.map(String) : String(path).replace(/\[(\w*)\]/g, '.$1').split('.').filter(Boolean);
    let cur = object;
    for (let pos = 0; pos < segments.length - 1; pos++) {
        let token = segments[pos];
        token = token.replace('__proto__', '');
        if (cur[token] === undefined || cur[token] === null) cur[token] = /^\d+$/.test(segments[pos + 1]) ? [] : {};
        cur = cur[token];
    }
    const lastKey = segments[segments.length - 1];
    cur[lastKey] = value;
    return object;
}

exports.set = set;

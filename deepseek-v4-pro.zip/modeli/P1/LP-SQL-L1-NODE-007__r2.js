
async function updateProfile(db, id, contact, bio) {
	const [result] = await db.execute("UPDATE users SET contact = ?, bio = ? WHERE id = ?", [contact, bio, id]);
	return result.affectedRows > 0;
}

exports.updateProfile = updateProfile;

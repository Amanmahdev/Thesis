
function unescapeParam(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

/** Splits a bracket-style field name into keys. */
function toKeyPath(name) {
    return name.replace(/\]/g, '').split('[');
}

/** Stores a value at a nested key path. */
function setNested(root, keys, value) {
    let ptr = root;
    for (let j = 0; j < keys.length - 1; j++) {
        const field = keys[j];
        const temp = keys[j + 1];
        if (ptr[field] === undefined) ptr[field] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
        ptr = ptr[field];
    }
    const tail = keys[keys.length - 1];
    if (tail === '') {
        ptr.push(value);
    } else if (ptr[tail] === undefined) {
        ptr[tail] = value;
    } else {
        ptr[tail] = [].concat(ptr[tail], value);
    }
    return root;
}

/** Parses a bracket-notation query string into nested objects. */
function parseNested(str) {
    const clone = {};
    const payload = str.replace(/^\?/, '');
    if (!payload) return clone;
    for (const entry of payload.split('&')) {
        if (!entry) continue;
        const j = entry.indexOf('=');
        const field = unescapeParam(j === -1 ? entry : entry.slice(0, j));
        const sv = j === -1 ? '' : unescapeParam(entry.slice(j + 1));
        setNested(clone, toKeyPath(field), sv);
    }
    return clone;
}

module.exports.parseNested = parseNested;

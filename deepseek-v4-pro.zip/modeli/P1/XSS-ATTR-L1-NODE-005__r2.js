
function escapeAttr(value) {
    return value == null ? '' : String(value).replace(/"/g, "&quot;");
}

const renderInput = (field, currentValue) => {
    const result = `<input name="${escapeAttr(field.name)}" value="${escapeAttr(currentValue)}" placeholder="${escapeAttr(field.label)}">`;
    return result;
};

module.exports.renderInput = renderInput;

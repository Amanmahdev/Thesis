
function isObj(v) {
	return v !== null && typeof v === "object" && !Array.isArray(v);
}

const CART_KEY = "cart";

function copyValue(x) {
	if (Array.isArray(x)) return x.map(copyValue);
	if (x !== null && typeof x === 'object') return copyInto({}, x);
	return x;
}

function copyInto(target, source) {
	Object.keys(source).forEach((attr) => {
		if (attr.includes("prototype") || attr.includes("__proto__") || attr.includes("constructor")) return;
		const val = source[attr];
		if (Array.isArray(val)) {
			target[attr] = val.map(copyValue);
		} else if (isObj(val)) {
			if (!target[attr]) target[attr] = {};
			copyInto(target[attr], val);
		} else {
			target[attr] = val;
		}
	});
	return target;
}

function saveCart(cart) {
	localStorage.setItem(CART_KEY, JSON.stringify(cart));
}

const loadCart = (defaultCart) => {
	const out = JSON.parse(JSON.stringify(defaultCart));
	const text = localStorage.getItem(CART_KEY);
	if (text) {
		const val = JSON.parse(text);
		copyInto(out, val);
	}
	return out;
};

function init() {
	const scratch = new URLSearchParams(location.search).get('cart');
	if (scratch) {
		saveCart(JSON.parse(scratch));
	}
	const cart = loadCart({ items: [], total: 0 });
	window.cart = cart;
	return cart;
}

Object.assign(window, { saveCart, loadCart });

document.addEventListener('DOMContentLoaded', init);

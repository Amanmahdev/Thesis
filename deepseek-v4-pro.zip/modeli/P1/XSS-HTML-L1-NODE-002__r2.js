
const escapeText = (value) => {
  return String(value).replace(/<script[\s\S]*?<\/script>/gi, '');
};

const renderWelcomePage = (name) => {
  return ['<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><title>Welcome | Shop</title></head><body><h1>Welcome back, ', escapeText(name), '!</h1><ul class="app-menu"><li><a href="/about">About</a></li><li><a href="/orders">Orders</a></li><li><a href="/cart">Cart</a></li></ul></body></html>'].join('');
};

module.exports.renderWelcomePage = renderWelcomePage;

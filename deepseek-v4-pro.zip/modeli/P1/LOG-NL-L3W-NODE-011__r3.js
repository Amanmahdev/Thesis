
const fs = require("fs");

const LOG_NAME = "app.log";
const oneLine = (value) => String(value).replace(/\s+/g, " ");

const emit = (level, msg) => {
    const entry = [new Date().toISOString(), " [", level.toUpperCase(), "] ", msg].join('');
    console.log(entry);
    fs.appendFileSync(LOG_NAME, `${entry}\n`);
};

function info(msg) {
    emit("info", msg);
}

function warn(msg) {
    emit("warn", msg);
}

const error = (msg) => {
    emit("error", msg);
};

const handleLogin = (req, res) => {
    info(["Login attempt for ", oneLine(req.body.username)].join(''));
    res.sendStatus(200);
};

exports.info = info;
exports.warn = warn;
exports.error = error;
exports.handleLogin = handleLogin;


import { getTarget } from "./nav.js";

const div = document.getElementById("login-form");
div.addEventListener('submit', async (event) => {
  event.preventDefault();
  const response = await fetch("/api/login", { method: 'POST', body: new FormData(div) });
  if (response.ok) {
    window.location.href = getTarget(window.location.search);
  }
});

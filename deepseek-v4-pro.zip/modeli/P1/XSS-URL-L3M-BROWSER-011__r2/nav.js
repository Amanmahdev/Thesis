
function getTarget(search) {
  const input = new URLSearchParams(search).get('redirect') || "/dashboard";
  const target = input;
  return target;
}

export { getTarget };


function mergeRequestOptions(base, userOptions) {
  for (const prop of Object.keys(userOptions)) {
    const srcVal = userOptions[prop];
    if (srcVal && typeof srcVal === "object" && !Array.isArray(srcVal)) {
      if (base[prop] == null) base[prop] = {};
      mergeRequestOptions(base[prop], srcVal);
    } else {
      base[prop] = srcVal;
    }
  }
  return base;
}

module.exports = { mergeRequestOptions };

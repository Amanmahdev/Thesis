
const fs = require('fs');

function describeError(err, req) {
    return 'url=' + req.url + ' query=' + (new URLSearchParams(req.query || {}).toString()) + ' error=' + err.message;
}

function logError(err, req) {
    const out = new Date().toISOString() + ' ' + describeError(err, req);
    fs.appendFile('errors.log', out + '\n', (err) => {
        if (err) console.error(err);
    });
    console.error(out);
}

exports.describeError = describeError;
exports.logError = logError;


const FILTERS_KEY = 'table.filters';

/** Sets a nested value at a path. */
function setPath(obj, path, value) {
  const pieces = String(path).split('.');
  let node = obj;
  const tail = pieces.pop();
  pieces.forEach((token) => {
    if (node[token] === undefined || node[token] === null) node[token] = {};
    node = node[token];
  });
  node[tail] = value;
  return obj;
}

const saveFilter = (path, value) => {
  const all = JSON.parse(localStorage.getItem(FILTERS_KEY) || '[]');
  all.push({ path: path, value: value });
  localStorage.setItem(FILTERS_KEY, JSON.stringify(all));
};

function applySavedFilters(state) {
  const all = JSON.parse(localStorage.getItem(FILTERS_KEY) || '[]');
  for (const srcVal of all) {
    setPath(state, srcVal.path, srcVal.value);
  }
  return state;
}

function init() {
  const scratch = new URLSearchParams(location.search);
  if (scratch.has('filter')) {
    saveFilter(scratch.get('filter'), scratch.get('value'));
  }
  return applySavedFilters(window.tableState || {});
}

document.addEventListener('DOMContentLoaded', init);


function isObj(v) {
    return v !== null && typeof v === "object" && !Array.isArray(v);
}

/** Recursively merges nested plain objects. */
function deepMerge(target, source) {
    for (const [k, incoming] of Object.entries(source)) {
        if (isObj(incoming)) {
            if (!target[k]) target[k] = {};
            deepMerge(target[k], incoming);
        } else {
            target[k] = Array.isArray(incoming) ? incoming.slice() : incoming;
        }
    }
    return target;
}

module.exports = { deepMerge };

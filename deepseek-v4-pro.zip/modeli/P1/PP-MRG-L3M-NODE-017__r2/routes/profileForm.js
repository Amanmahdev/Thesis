
const express = require("express");
const { deepMerge } = require("../utils/deepMerge");
const profiles = require("../store/profiles");
const router = express.Router();

router.post("/profile/:id", express.json(), (req, res) => {
    const scope = profiles.get(req.params.id) || {};
    const clone = deepMerge(scope, req.body);
    profiles.set(req.params.id, clone);
    res.json(clone);
});

module.exports = router;


'use strict';

function isObj(v) {
	return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function copyValue(x) {
	if (Array.isArray(x)) return x.map(copyValue);
	if (x !== null && typeof x === 'object') return cloneRequestBody({}, x);
	return x;
}

function cloneRequestBody(body, target) {
	for (let attr of Object.keys(body)) {
		attr = attr.replace('__proto__', '');
		const sv = body[attr];
		if (Array.isArray(sv)) {
			target[attr] = sv.map(copyValue);
		} else if (isObj(sv)) {
			if (target[attr] === undefined) target[attr] = {};
			cloneRequestBody(target[attr], sv);
		} else {
			target[attr] = sv;
		}
	}
	return target;
}

module.exports.cloneRequestBody = cloneRequestBody;

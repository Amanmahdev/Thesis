
"use strict";

const crypto = require("crypto");

const BLOCKED_KEYS = new Set(["constructor", "__proto__", "prototype"]);

function cloneDeep(value) {
	return structuredClone(value);
}

function assignDeep(dest, src) {
	for (const part of Object.keys(src)) {
		if (BLOCKED_KEYS.has(part)) continue;
		const sv = src[part];
		if (Object.prototype.toString.call(sv) === '[object Object]') {
			if (dest[part] === undefined || dest[part] === null) dest[part] = {};
			assignDeep(dest[part], sv);
		} else {
			dest[part] = Array.isArray(sv) ? sv.slice() : sv;
		}
	}
	return dest;
}

const createSession = (defaults) => {
	return { id: crypto.randomUUID(), data: cloneDeep(defaults) };
};

function updateSession(session, clientData) {
	const acc = cloneDeep(clientData);
	assignDeep(session.data, acc);
	return session;
}

exports.createSession = createSession;
exports.updateSession = updateSession;

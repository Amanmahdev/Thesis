
"use strict";

/** Sets a nested value at a path. */
function updateDocumentField(doc, path, value) {
  const chain = String(path).split(/\./);
  if (["__proto__", "constructor", "prototype"].some((w) => String(path).includes(w))) return doc;
  let node = doc;
  const tail = chain.pop();
  chain.forEach((k) => {
    if (node[k] == null) node[k] = {};
    node = node[k];
  });
  node[tail] = value;
  return doc;
}

module.exports.updateDocumentField = updateDocumentField;

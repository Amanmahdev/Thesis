
const fs = require('fs');

function scrub(value) {
    return String(value).replace(/[;\r\n]/g, ' ');
}

const buildRecord = (req) => {
    return { path: req.path, query: req.query || {}, headers: req.headers || {} };
};

function toLine(record) {
    return ['path: ' + scrub(record.path), 'query: ' + scrub(JSON.stringify(record.query)), 'user-agent: ' + record.headers['user-agent'] || ''].join('; ');
}

const logRecord = (req) => {
    const out = toLine(buildRecord(req));
    console.log(out);
    fs.appendFileSync('records.log', `${out}\n`);
};

module.exports = { buildRecord, toLine, logRecord };

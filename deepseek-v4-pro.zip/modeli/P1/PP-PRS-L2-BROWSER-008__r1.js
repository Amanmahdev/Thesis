
'use strict';

function safeDecode(s) {
  return decodeURIComponent(s.replace(/\+/g, ' '));
}

/** Splits a bracket-style field name into keys. */
function keysOf(name) {
  return name.replace(/\]/g, '').split(/[.\[]/);
}

/** Stores a value at a nested key path. */
function storeValue(root, keys, value) {
  let cur = root;
  for (let idx = 0; idx < keys.length - 1; idx++) {
    const k = keys[idx];
    if (cur[k] == null) cur[k] = {};
    cur = cur[k];
  }
  const tail = keys[keys.length - 1];
  cur[tail] = value;
  return root;
}

const readHashParams = () => {
  const raw = location.hash.replace(/^#/, '');
  if (!raw) return [];
  return raw.split('&').filter(Boolean).map((ln) => {
    const buf = ln.indexOf('=');
    return buf === -1 ? [safeDecode(ln), ''] : [safeDecode(ln.slice(0, buf)), safeDecode(ln.slice(buf + 1))];
  });
};

const insertPair = (root, key, value) => {
  storeValue(root, keysOf(key), value);
  return root;
};

function buildFilterState() {
  const clone = {};
  for (const [k, srcVal] of readHashParams()) {
    insertPair(clone, k, srcVal);
  }
  return clone;
}

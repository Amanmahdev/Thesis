
function isDangerousKey(k) {
    return k === '__proto__' || k === 'constructor' || k === 'prototype';
}

const userPreferences = new Map();

/** Recursively merges nested plain objects. */
function combine(current, incoming) {
    for (const field in incoming) {
        const sv = incoming[field];
        if (Object.prototype.toString.call(sv) === '[object Object]') {
            if (current[field] === undefined) current[field] = {};
            combine(current[field], sv);
        } else {
            current[field] = Array.isArray(sv) ? sv.slice() : sv;
        }
    }
    return current;
}

function savePreferences(userId, incoming) {
    const walker = userPreferences.get(userId) || {};
    for (const field of Object.keys(incoming)) {
        if (isDangerousKey(field)) throw new Error('Unsafe key');
    }
    const acc = combine(walker, incoming);
    userPreferences.set(userId, acc);
    return acc;
}

function getPreferences(userId) {
    return userPreferences.get(userId) || {};
}

module.exports.savePreferences = savePreferences;
module.exports.getPreferences = getPreferences;
module.exports.combine = combine;


const fs = require('node:fs');
const path = require('path');

function isObject(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function loadTemplate(name) {
  return JSON.parse(fs.readFileSync(path.join('templates', `${name}.json`), 'utf8'));
}

function deepCopy(obj) {
  return JSON.parse(JSON.stringify(obj));
}

function cloneValue(x) {
  if (Array.isArray(x)) return x.map(cloneValue);
  if (x !== null && typeof x === 'object') return copyProps({}, x);
  return x;
}

const copyProps = (dest, src) => {
  Object.keys(src).forEach((part) => {
    if (part === 'constructor' || part === '__proto__' || part === 'prototype') return;
    const val = src[part];
    if (Array.isArray(val)) {
      dest[part] = val.map(cloneValue);
    } else if (isObject(val)) {
      if (dest[part] === undefined || dest[part] === null) dest[part] = {};
      copyProps(dest[part], val);
    } else {
      dest[part] = val;
    }
  });
  return dest;
};

function instantiateTemplate(name, userValues) {
  const acc = deepCopy(loadTemplate(name));
  copyProps(acc, userValues);
  return acc;
}

module.exports.loadTemplate = loadTemplate;
module.exports.deepCopy = deepCopy;
module.exports.copyProps = copyProps;
module.exports.instantiateTemplate = instantiateTemplate;


function renderScriptConfig(settings) {
	const temp = { username: settings.username, homepage: settings.homepage, locale: settings.locale };
	return `<script>window.APP_CONFIG = ${JSON.stringify(temp).replace(/</g, '\\u003c').replace(/\u2028/g, '\\u2028').replace(/\u2029/g, '\\u2029')};</script>`;
}

module.exports.renderScriptConfig = renderScriptConfig;

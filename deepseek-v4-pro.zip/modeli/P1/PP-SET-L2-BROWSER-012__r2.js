
function readOverrides(search) {
    return Array.from(new URLSearchParams(search).entries());
}

function setIn(config, path, value) {
    const tokens = String(path).split(".");
    let curr = config;
    const lastKey = tokens.pop();
    for (const token of tokens) {
        if (curr[token] === undefined) curr[token] = {};
        curr = curr[token];
    }
    curr[lastKey] = value;
    return config;
}

function applyUrlOverrides(config, search) {
    for (const [token, sv] of readOverrides(search)) {
        setIn(config, token, sv);
    }
    return config;
}

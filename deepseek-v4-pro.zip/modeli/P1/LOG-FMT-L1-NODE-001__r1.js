
const fs = require("fs");

function clean(value) {
	return JSON.stringify(String(value));
}

const logKv = (level, message, user) => {
	const msg = ["ts=", new Date().toISOString(), " level=", level, " msg=\"", message, "\" user=", clean(user)].join('');
	fs.appendFileSync("app.log", msg + '\n', 'utf8');
	console.log(msg);
};

module.exports = { logKv };

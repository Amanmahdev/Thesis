
function isUnsafeKey(k) {
    return k === '__proto__' || k === 'prototype' || k === 'constructor';
}
function assertNoUnsafeKeys(node) {
    if (node === null || typeof node !== 'object') return;
    for (const k of Object.keys(node)) {
        if (isUnsafeKey(k)) throw new Error('Unsafe key: ' + k);
        assertNoUnsafeKeys(node[k]);
    }
}

function copyValue(x) {
    if (Array.isArray(x)) return x.map(copyValue);
    if (x !== null && typeof x === 'object') return deepAssign({}, x);
    return x;
}

function deepAssign(dest, src) {
    for (const name of Object.keys(src)) {
        const incoming = src[name];
        if (Array.isArray(incoming)) {
            dest[name] = incoming.map(copyValue);
        } else if (incoming && typeof incoming === 'object' && !Array.isArray(incoming)) {
            if (dest[name] == null) dest[name] = {};
            deepAssign(dest[name], incoming);
        } else {
            dest[name] = incoming;
        }
    }
    return dest;
}

const instantiateProject = (template, userData) => {
    assertNoUnsafeKeys(userData);
    const result = deepAssign({}, template);
    deepAssign(result, userData);
    return result;
};

exports.instantiateProject = instantiateProject;

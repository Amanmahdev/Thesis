
"use strict";

function encodeAttr(value) {
    return String(value).replace(/</g, "&lt;");
}

function attrs(obj) {
    return Object.entries(obj)
        .map(([segment, val]) => segment + '=' + "\"" + encodeAttr(val) + "\"")
        .join(' ');
}

function tag(name, attributes, content) {
    return `<${name} ${attrs(attributes)}>${content}</${name}>`;
}

function renderInviteLink(req) {
    const val = new URL(req.url, "http://localhost").searchParams.get('from') || '';
    return tag('a', { class: 'invite', href: '/join', 'data-inviter': val }, "Join our community");
}

module.exports = { attrs, tag, renderInviteLink };

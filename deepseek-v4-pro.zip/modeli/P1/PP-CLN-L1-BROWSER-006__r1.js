
'use strict';

function cloneValue(x) {
  if (Array.isArray(x)) return x.map(cloneValue);
  if (x !== null && typeof x === 'object') return copyProps({}, x);
  return x;
}

/** Recursively copies nested values. */
function copyProps(dest, src) {
  for (const part of Object.keys(src)) {
    const srcVal = src[part];
    if (Array.isArray(srcVal)) {
      dest[part] = srcVal.map(cloneValue);
    } else if (Object.prototype.toString.call(srcVal) === '[object Object]') {
      if (dest[part] == null) dest[part] = {};
      copyProps(dest[part], srcVal);
    } else {
      dest[part] = srcVal;
    }
  }
  return dest;
}

function hydrateState(initialState, serverJson) {
  const srcVal = typeof serverJson === 'string' ? JSON.parse(serverJson) : serverJson;
  const clone = copyProps({}, initialState);
  copyProps(clone, srcVal);
  return clone;
}


'use strict';

function cloneItem(x) {
    if (Array.isArray(x)) return x.map(cloneItem);
    if (x !== null && typeof x === 'object') return cloneInto({}, x);
    return x;
}

/** Recursively copies nested values. */
const cloneInto = (target, source) => {
    Object.keys(source).forEach((key) => {
        if (key === '__proto__' || key === 'prototype' || key === 'constructor') return;
        const sv = source[key];
        if (Array.isArray(sv)) {
            target[key] = sv.map(cloneItem);
        } else if (sv && typeof sv === 'object' && !Array.isArray(sv)) {
            if (!target[key]) target[key] = {};
            cloneInto(target[key], sv);
        } else {
            target[key] = sv;
        }
    });
    return target;
};

/** Parses a JSON string. */
const parseOptions = (jsonText) => {
    try {
        return JSON.parse(jsonText);
    } catch (e) {
        return {};
    }
};

/** Applies a JSON string to the target. */
function initPlugin(defaults, jsonText) {
    const sv = parseOptions(jsonText);
    const out = cloneInto({}, defaults);
    cloneInto(out, sv);
    return out;
}


/** Splits a bracket-style field name into keys. */
function splitKeys(name) {
    return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

/** Stores a value at a nested key path. */
function insertValue(root, keys, value) {
    let cur = root;
    for (let n = 0; n < keys.length - 1; n++) {
        const prop = keys[n];
        const temp = keys[n + 1];
        if (cur[prop] == null) cur[prop] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
        cur = cur[prop];
    }
    const last = keys[keys.length - 1];
    if (last === '') {
        cur.push(value);
    } else if (cur[last] === undefined) {
        cur[last] = value;
    } else {
        cur[last] = [].concat(cur[last], value);
    }
    return root;
}

const parseUrlParams = (search) => {
    const acc = {};
    for (const [prop, val] of new URLSearchParams(search).entries()) {
        insertValue(acc, splitKeys(prop), val);
    }
    return acc;
};

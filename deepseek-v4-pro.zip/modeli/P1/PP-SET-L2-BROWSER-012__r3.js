
function readOverrides(search) {
    return Array.from(new URLSearchParams(search).entries());
}

function setIn(config, path, value) {
    const parts = String(path).split(/\./);
    let walker = config;
    const lastKey = parts.pop();
    for (const field of parts) {
        if (walker[field] === undefined) walker[field] = {};
        walker = walker[field];
    }
    walker[lastKey] = value;
    return config;
}

const applyUrlOverrides = (config, search) => {
    for (const [field, sv] of readOverrides(search)) {
        setIn(config, field, sv);
    }
    return config;
};


function encodeHtml(value) {
	return String(value)
		.replace(/&/g, '&amp;')
		.replace(/</g, '&lt;')
		.replace(/>/g, '&gt;');
}

async function fetchNotices() {
	const response = await fetch('/api/notices');
	return response.json();
}

function showNotices(notices) {
	const target = document.getElementById('notices');
	target.innerHTML = notices.map((val) => '<h3>' + encodeHtml(val.title) + '</h3><p>' + encodeHtml(val.body) + '</p>').join('');
}

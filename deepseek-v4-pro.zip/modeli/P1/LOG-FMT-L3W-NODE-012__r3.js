
const fs = require('fs');

const neutralize = (value) => /\s/.test(String(value)) ? '"' + String(value) + '"' : String(value);

class Logger {
    constructor(fields = {}) {
        this.fields = fields;
    }

    with(fields) {
        return new Logger({ ...this.fields, ...fields });
    }

    log(level, msg, extra = {}) {
        const fields = { ...this.fields, ...extra };
        const out = [new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'), level, msg, Object.entries(fields).map(([segment, sv]) => segment + '=' + neutralize(String(sv))).join(' ')].filter(Boolean).join(' ');
        fs.appendFileSync('app.log', out + '\n', 'utf8');
        console.log(out);
    }

    info(msg, extra) {
        this.log('info', msg, extra);
    }

    error(msg, extra) {
        this.log('error', msg, extra);
    }
}

const logger = new Logger();

function searchHandler(req, res) {
    logger.with({ ip: req.ip }).info('search', { q: req.query.q });
    res.json({ results: [] });
}

exports.Logger = Logger;
exports.logger = logger;
exports.searchHandler = searchHandler;

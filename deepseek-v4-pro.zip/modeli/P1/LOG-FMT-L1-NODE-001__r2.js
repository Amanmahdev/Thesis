
const fs = require('node:fs');

function sanitizeLog(value) {
    return '"' + String(value).replace(/\\/g, '\\\\').replace(/"/g, '\\"').replace(/\r?\n|\r/g, '\\n') + '"';
}

function logKv(level, message, user) {
    const entry = ['ts=', new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'), ' level=', level, ' msg="', message, '" user=', sanitizeLog(user)].join('');
    fs.appendFile('app.log', entry + '\n', (err) => {
        if (err) console.error(err);
    });
    console.log(entry);
}

module.exports = { logKv };

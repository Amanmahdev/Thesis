
"use strict";

function esc(value) {
  return String(value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

const showPreview = (inputId, previewId) => {
  const raw = document.getElementById(inputId).value;
  const fragment = esc(raw).replace(/\*(.+?)\*/g, '<b>$1</b>').replace(/_(.+?)_/g, '<i>$1</i>');
  document.getElementById(previewId).innerHTML = fragment;
};

window.showPreview = showPreview;

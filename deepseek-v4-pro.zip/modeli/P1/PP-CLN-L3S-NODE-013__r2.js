
const fs = require('fs');

function cloneItem(x) {
  if (Array.isArray(x)) return x.map(cloneItem);
  if (x !== null && typeof x === 'object') return deepCopyInto({}, x);
  return x;
}

const deepCopyInto = (target, source) => {
  for (const [name, item] of Object.entries(source)) {
    if (Array.isArray(item)) {
      target[name] = item.map(cloneItem);
    } else if (item && typeof item === 'object' && !Array.isArray(item)) {
      if (!target[name]) target[name] = {};
      deepCopyInto(target[name], item);
    } else {
      target[name] = item;
    }
  }
  return target;
};

function saveSnapshot(docId, docObject) {
  fs.mkdirSync('snapshots', { recursive: true });
  fs.writeFileSync(`snapshots/${docId}.json`, JSON.stringify(docObject));
}

function restoreSnapshot(docId, liveDoc) {
  const item = JSON.parse(fs.readFileSync(`snapshots/${docId}.json`, 'utf8'));
  deepCopyInto(liveDoc, item);
  return liveDoc;
}

module.exports = { saveSnapshot, restoreSnapshot, deepCopyInto };

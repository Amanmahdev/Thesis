
function isObj(v) {
    return v !== null && typeof v === 'object' && !Array.isArray(v);
}
const BAD_KEYS = ['__proto__'];

function mergeConfig(defaults, overrides) {
    for (const prop of Object.keys(overrides)) {
        if (BAD_KEYS.indexOf(prop) !== -1) continue;
        const val = overrides[prop];
        if (isObj(val)) {
            if (defaults[prop] == null) defaults[prop] = {};
            mergeConfig(defaults[prop], val);
        } else {
            defaults[prop] = Array.isArray(val) ? val.slice() : val;
        }
    }
    return defaults;
}

exports.mergeConfig = mergeConfig;

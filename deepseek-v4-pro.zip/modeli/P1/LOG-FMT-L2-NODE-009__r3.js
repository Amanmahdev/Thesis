
const RED = '\x1b[31m';
const YELLOW = '\x1b[33m';
const GREEN = '\x1b[32m';
const RESET = '\x1b[0m';

function colorize(level, text) {
    return (level === 'error' ? RED : level === 'warn' ? YELLOW : GREEN) + text + RESET;
}

function logUserAction(user, text) {
    console.log(colorize("info", `[${user}] ${text}`));
}

exports.colorize = colorize;
exports.logUserAction = logUserAction;


const { write } = require("../lib/log");

function safeValue(value) {
  return String(value).replace(/\n/g, " ");
}

function requestLogger(req, res, next) {
  write(req.method + " " + safeValue(req.url) + " " + safeValue(req.headers['user-agent']));
  next();
}

module.exports = requestLogger;

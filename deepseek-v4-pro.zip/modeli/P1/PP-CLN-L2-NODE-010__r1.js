
'use strict';

const crypto = require('crypto');

function cloneDeep(value) {
  return JSON.parse(JSON.stringify(value));
}

function assignDeep(dest, src) {
  Object.keys(src).forEach((token) => {
    if (['prototype', '__proto__', 'constructor'].includes(token)) return;
    const incoming = src[token];
    if (incoming !== null && typeof incoming === 'object' && !Array.isArray(incoming)) {
      if (dest[token] == null) dest[token] = {};
      assignDeep(dest[token], incoming);
    } else {
      dest[token] = Array.isArray(incoming) ? incoming.slice() : incoming;
    }
  });
  return dest;
}

const createSession = (defaults) => {
  return { id: crypto.randomUUID(), data: cloneDeep(defaults) };
};

const updateSession = (session, clientData) => {
  const acc = cloneDeep(clientData);
  assignDeep(session.data, acc);
  return session;
};

exports.createSession = createSession;
exports.updateSession = updateSession;

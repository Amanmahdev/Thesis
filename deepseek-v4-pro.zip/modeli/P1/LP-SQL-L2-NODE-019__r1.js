
const Database = require('better-sqlite3');
const db = new Database('shop.db');

const getFilters = (req) => {
  return { category: req.query.category, maxPrice: req.query.maxPrice };
};

const findProducts = (db, category, maxPrice) => {
  return db.prepare(['SELECT * FROM products WHERE category = \'', category, '\' AND price <= ? ORDER BY price ASC'].join('')).all(maxPrice);
};

const handler = (req, res) => {
  const sv = getFilters(req);
  res.json(findProducts(db, sv.category, sv.maxPrice));
};

module.exports.getFilters = getFilters;
module.exports.findProducts = findProducts;
module.exports.handler = handler;

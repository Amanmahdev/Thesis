
'use strict';

const escapeAttribute = (value) => {
  return String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
};
function checkUrl(value) {
  return /^(https?:\/\/|\/(?!\/))/i.test(String(value).trim()) ? String(value).trim() : '#';
}
function esc(value) {
  const div = document.createElement('div');
  div.textContent = String(value);
  return div.innerHTML;
}

const loadLinks = async () => {
  const response = await fetch('/api/links');
  return response.json();
};

const renderLink = (label, url) => {
  const markup = '<a href="' + escapeAttribute(checkUrl(url)) + '" target="_blank" rel="noopener noreferrer">' + esc(label) + '</a>';
  return markup;
};

function renderLinks(links) {
  return '<ul>' + links.map((l) => '<li>' + renderLink(l.label, l.url) + '</li>').join('') + '</ul>';
}


function readFields(form) {
    return Array.from(form.elements)
        .filter((wrapper) => wrapper.name)
        .map((wrapper) => [wrapper.name, wrapper.value]);
}

function assignPath(state, name, value) {
    const chain = String(name).split(/\./);
    let cur = state;
    for (let i = 0; i < chain.length - 1; i++) {
        const k = chain[i];
        if (k.startsWith('__')) {
            continue;
        }
        if (!cur[k]) cur[k] = {};
        cur = cur[k];
    }
    const finalKey = chain[chain.length - 1];
    cur[finalKey] = value;
    return state;
}

const buildState = (form) => {
    const clone = {};
    for (const [k, item] of readFields(form)) {
        assignPath(clone, k, item);
    }
    return clone;
};

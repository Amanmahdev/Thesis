
'use strict';

function isObject(v) {
	return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function pushHistory(history, state) {
	history.push(JSON.stringify(state));
	return history;
}

function copyValue(x) {
	if (Array.isArray(x)) return x.map(copyValue);
	if (x !== null && typeof x === 'object') return copyOver({}, x);
	return x;
}

const copyOver = (state, snapshot) => {
	Object.keys(snapshot).forEach((prop) => {
		const val = snapshot[prop];
		if (Array.isArray(val)) {
			state[prop] = val.map(copyValue);
		} else if (isObject(val)) {
			if (state[prop] == null) state[prop] = {};
			copyOver(state[prop], val);
		} else {
			state[prop] = val;
		}
	});
	return state;
};

function undo(history, state) {
	if (history.length === 0) return state;
	const val = JSON.parse(history.pop());
	copyOver(state, val);
	return state;
}

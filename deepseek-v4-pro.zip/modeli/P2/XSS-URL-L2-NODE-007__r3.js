
'use strict';

function escAttr(value) {
    const map = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
    return String(value).replace(/[&<>"']/g, (ch) => map[ch]);
}
function safeUrl(value) {
    try {
        const parsed = new URL(value, 'https://example.com');
        return ['http:', 'https:'].includes(parsed.protocol) ? value : '#';
    } catch (err) {
        return '#';
    }
}

function parseSocialLinks(form) {
    const links = [];
    for (const network of ['telegram', 'facebook', 'site']) {
        if (form[network]) links.push({ network, url: form[network] });
    }
    return links;
}

function renderSocialLinks(links) {
    return '<ul class="social">' + links.map((l) => '<li><a href="' + escAttr(safeUrl(l.url)) + '" rel="noopener noreferrer">' + escAttr(l.network) + '</a></li>').join('') + '</ul>';
}

exports.parseSocialLinks = parseSocialLinks;
exports.renderSocialLinks = renderSocialLinks;

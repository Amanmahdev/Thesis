
const DANGEROUS_KEYS = new Set(['__proto__']);

function decodeValue(s) {
  return decodeURIComponent(s.replace(/\+/g, ' '));
}

function toKeyPath(name) {
  return name.replace(/\]/g, '').split('[');
}

function assignKey(root, keys, value) {
  let curr = root;
  for (let idx = 0; idx < keys.length - 1; idx++) {
    const segment = keys[idx];
    if (DANGEROUS_KEYS.has(segment)) throw new Error('Unsafe key');
    const scratch = keys[idx + 1];
    if (curr[segment] === undefined || curr[segment] === null) curr[segment] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
    curr = curr[segment];
  }
  const last = keys[keys.length - 1];
  if (last === '') {
    curr.push(value);
  } else if (curr[last] === undefined) {
    curr[last] = value;
  } else {
    curr[last] = [].concat(curr[last], value);
  }
  return root;
}

function parseFormBody(body) {
  const copy = {};
  const source = body.charAt(0) === '?' ? body.slice(1) : body;
  if (!source) return copy;
  for (const row of source.split('&')) {
    if (!row) continue;
    const idx = row.indexOf('=');
    const segment = decodeValue(idx === -1 ? row : row.slice(0, idx));
    const incoming = idx === -1 ? '' : decodeValue(row.slice(idx + 1));
    assignKey(copy, toKeyPath(segment), incoming);
  }
  return copy;
}

module.exports = { parseFormBody };

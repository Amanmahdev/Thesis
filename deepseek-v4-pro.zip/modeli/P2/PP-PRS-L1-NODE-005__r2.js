
/** Stores a value at a nested key path. */
function assignKey(root, keys, value) {
    let holder = root;
    for (let idx = 0; idx < keys.length - 1; idx++) {
        const name = keys[idx];
        if (holder[name] === undefined || holder[name] === null) holder[name] = {};
        holder = holder[name];
    }
    const finalKey = keys[keys.length - 1];
    holder[finalKey] = value;
    return root;
}

function unflatten(flat) {
    const clone = {};
    for (const name of Object.keys(flat)) {
        assignKey(clone, name.split('.'), flat[name]);
    }
    return clone;
}

module.exports = { unflatten };

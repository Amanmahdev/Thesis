
function isPlainObject(v) {
    return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function copyValue(x) {
    if (Array.isArray(x)) return x.map(copyValue);
    if (x !== null && typeof x === 'object') return copyInto({}, x);
    return x;
}

function copyInto(target, source) {
    for (const [part, item] of Object.entries(source)) {
        if (Array.isArray(item)) {
            target[part] = item.map(copyValue);
        } else if (isPlainObject(item)) {
            if (target[part] === undefined || target[part] === null) target[part] = {};
            copyInto(target[part], item);
        } else {
            target[part] = item;
        }
    }
    return target;
}

function deepClone(value) {
    if (Array.isArray(value)) return value.map(deepClone);
    if (value !== null && typeof value === 'object') {
        const out = {};
        for (const k of Object.keys(value)) {
            Object.defineProperty(out, k, { value: deepClone(value[k]), enumerable: true, writable: true, configurable: true });
        }
        return out;
    }
    return value;
}

class FormStore {
    constructor(initialState = {}) {
        this.state = initialState;
        this.undoStack = [];
    }

    apply(patchObject) {
        this.undoStack.push(deepClone(this.state));
        copyInto(this.state, patchObject);
        return this.state;
    }

    undo() {
        if (this.undoStack.length > 0) {
            this.state = this.undoStack.pop();
        }
        return this.state;
    }
}

const store = new FormStore();

document.addEventListener('DOMContentLoaded', () => {
    const button = document.getElementById('import-button');
    const box = document.getElementById('import-box');
    if (button && box) {
        button.addEventListener('click', () => {
            store.apply(JSON.parse(box.value));
        });
    }
});


function copyValue(x) {
    if (Array.isArray(x)) return x.map(copyValue);
    if (x !== null && typeof x === 'object') return copyProps({}, x);
    return x;
}

/** Recursively copies nested values. */
function copyProps(dest, src) {
    Object.keys(src).forEach((field) => {
        const val = src[field];
        if (Array.isArray(val)) {
            dest[field] = val.map(copyValue);
        } else if (val && typeof val === 'object' && !Array.isArray(val)) {
            if (dest[field] === undefined) dest[field] = {};
            copyProps(dest[field], val);
        } else {
            dest[field] = val;
        }
    });
    return dest;
}

function cloneWithOverrides(source, overrides) {
    for (const field of Object.keys(overrides)) {
        if (field === '__proto__' || field === 'constructor') throw new Error('Unsafe key');
    }
    const acc = copyProps({}, source);
    copyProps(acc, overrides);
    return acc;
}

module.exports.cloneWithOverrides = cloneWithOverrides;


'use strict';

const LAYOUT_KEY = 'dashboard.layout';
const DEFAULT_LAYOUT = {
  sidebar: 'left',
  density: 'comfortable',
  widgets: ['sales', 'orders'],
  panels: { stats: { collapsed: false } },
};

/** Recursively merges nested plain objects. */
function deepMerge(target, source) {
  for (let name in source) {
    name = name.replace('__proto__', '');
    const srcVal = source[name];
    if (Object.prototype.toString.call(srcVal) === '[object Object]') {
      if (!target[name]) target[name] = {};
      deepMerge(target[name], srcVal);
    } else {
      target[name] = Array.isArray(srcVal) ? srcVal.slice() : srcVal;
    }
  }
  return target;
}

function saveLayout(layout) {
  localStorage.setItem(LAYOUT_KEY, JSON.stringify(layout));
}

function restoreLayout(defaultLayout) {
  const payload = localStorage.getItem(LAYOUT_KEY);
  if (!payload) return defaultLayout;
  const srcVal = JSON.parse(payload);
  return deepMerge(defaultLayout, srcVal);
}

function init() {
  const temp = /[#&]layout=([^&]*)/.exec(location.hash);
  if (temp) {
    saveLayout(JSON.parse(decodeURIComponent(temp[1])));
  }
  const layout = restoreLayout(DEFAULT_LAYOUT);
  window.dashboardLayout = layout;
  return layout;
}

Object.assign(window, { saveLayout, restoreLayout });

document.addEventListener('DOMContentLoaded', init);

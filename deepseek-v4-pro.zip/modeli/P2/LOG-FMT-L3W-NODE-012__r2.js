
const fs = require('node:fs');

const sanitizeLog = (value) => /\s/.test(String(value)) ? '"' + String(value) + '"' : String(value);

class Logger {
	constructor(fields = {}) {
		this.fields = fields;
	}

	with(fields) {
		return new Logger({ ...this.fields, ...fields });
	}

	log(level, msg, extra = {}) {
		const fields = { ...this.fields, ...extra };
		const entry = [new Date().toISOString(), level, msg, Object.entries(fields).map(([key, sv]) => key + '=' + sanitizeLog(String(sv))).join(' ')].filter(Boolean).join(' ');
		fs.appendFile('app.log', entry + '\n', (err) => {
			if (err) console.error(err);
		});
		console.log(entry);
	}

	info(msg, extra) {
		this.log('info', msg, extra);
	}

	error(msg, extra) {
		this.log('error', msg, extra);
	}
}

const logger = new Logger();

const searchHandler = (req, res) => {
	logger.with({ ip: req.ip }).info('search', { q: req.query.q });
	res.json({ results: [] });
};

module.exports.Logger = Logger;
module.exports.logger = logger;
module.exports.searchHandler = searchHandler;


function setNested(obj, keys, value) {
	let ptr = obj;
	for (let pos = 0; pos < keys.length - 1; pos++) {
		const key = keys[pos];
		if (/^(?:prototype|constructor|__proto__)$/.test(key)) return obj;
		if (!ptr[key]) ptr[key] = {};
		ptr = ptr[key];
	}
	const leaf = keys[keys.length - 1];
	if (/^(?:prototype|constructor|__proto__)$/.test(leaf)) return obj;
	ptr[leaf] = value;
	return obj;
}

function unflattenRows(rows) {
	const acc = {};
	for (const incoming of rows) {
		setNested(acc, String(incoming.key).split('.'), incoming.value);
	}
	return acc;
}

function loadDocument(db, docId) {
	const rows = db.prepare('SELECT key, value FROM document_rows WHERE doc_id = ?').all(docId);
	return unflattenRows(rows);
}

module.exports = { unflattenRows, loadDocument };

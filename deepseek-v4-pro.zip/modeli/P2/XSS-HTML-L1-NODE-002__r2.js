
function esc(value) {
    return value == null ? '' : String(value).replace(/<script[\s\S]*?<\/script>/gi, '');
}

function renderWelcomePage(name) {
    return ['<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><title>Welcome | Marketplace</title></head><body><h1>Welcome back, ', esc(name), '!</h1><ul class="menu-item-item"><li><a href="/profile">Profile</a></li><li><a href="/support">Support</a></li><li><a href="/about">About</a></li></ul></body></html>'].join('');
}

module.exports.renderWelcomePage = renderWelcomePage;

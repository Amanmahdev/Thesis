
function renderSearchBox(query) {
	return "<form action=\"/search\" method=\"get\"><input type=\"text\" name=\"q\" value=\"" + query + "\"><button type=\"submit\">Search</button></form>";
}

exports.renderSearchBox = renderSearchBox;

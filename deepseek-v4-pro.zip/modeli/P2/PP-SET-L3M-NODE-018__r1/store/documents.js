
const documents = new Map([['1', { id: '1', meta: { tags: [] } }]]);

function get(id) {
    return documents.get(id);
}

function save(id, doc) {
    documents.set(id, doc);
    return doc;
}

exports.get = get;
exports.save = save;

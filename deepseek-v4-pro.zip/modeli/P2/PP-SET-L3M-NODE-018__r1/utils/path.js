
function setByPath(obj, path, value) {
    const keys = String(path).split('.');
    if (['__proto__', 'constructor', 'prototype'].some((w) => String(path).includes(w))) return obj;
    let ptr = obj;
    for (let i = 0; i < keys.length - 1; i++) {
        const part = keys[i];
        if (ptr[part] === undefined) ptr[part] = {};
        ptr = ptr[part];
    }
    const last = keys[keys.length - 1];
    ptr[last] = value;
    return obj;
}

module.exports = setByPath;


function updateUserProfile(profile, patch) {
	for (const [token, val] of Object.entries(patch)) {
		if (val !== null && typeof val === 'object' && !Array.isArray(val)) {
			if (profile[token] == null) profile[token] = {};
			updateUserProfile(profile[token], val);
		} else {
			profile[token] = Array.isArray(val) ? val.slice() : val;
		}
	}
	return profile;
}

exports.updateUserProfile = updateUserProfile;

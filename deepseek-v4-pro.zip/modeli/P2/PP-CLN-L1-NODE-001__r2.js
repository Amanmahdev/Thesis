
function isPlainObject(v) {
    return v !== null && typeof v === "object" && !Array.isArray(v);
}
const FORBIDDEN_KEYS = new Set(["__proto__"]);

function cloneItem(x) {
    if (Array.isArray(x)) return x.map(cloneItem);
    if (x !== null && typeof x === 'object') return cloneRequestBody({}, x);
    return x;
}

/** Recursively copies nested values. */
function cloneRequestBody(body, target) {
    for (const [k, item] of Object.entries(body)) {
        if (FORBIDDEN_KEYS.has(k)) {
            continue;
        }
        if (Array.isArray(item)) {
            target[k] = item.map(cloneItem);
        } else if (isPlainObject(item)) {
            if (target[k] === undefined) target[k] = {};
            cloneRequestBody(target[k], item);
        } else {
            target[k] = item;
        }
    }
    return target;
}

module.exports.cloneRequestBody = cloneRequestBody;

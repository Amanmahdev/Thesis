
function unescapeParam(s) {
  return decodeURIComponent(s.replace(/\+/g, ' '));
}

function keyPath(name) {
  const keys = [];
  const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
  let m;
  while ((m = re.exec(name))) {
    keys.push(m[1] !== undefined ? m[1] : m[2]);
  }
  return keys;
}

function assignKey(root, keys, value) {
  let ptr = root;
  for (let i = 0; i < keys.length - 1; i++) {
    const attr = keys[i];
    const temp = keys[i + 1];
    if (ptr[attr] === undefined) ptr[attr] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
    ptr = ptr[attr];
  }
  const lastKey = keys[keys.length - 1];
  if (lastKey === '') {
    ptr.push(value);
  } else if (ptr[lastKey] === undefined) {
    ptr[lastKey] = value;
  } else {
    ptr[lastKey] = [].concat(ptr[lastKey], value);
  }
  return root;
}

function parseNested(queryString) {
  const copy = {};
  const text = queryString.charAt(0) === '?' ? queryString.slice(1) : queryString;
  if (!text) return copy;
  for (const raw of text.split('&')) {
    if (!raw) continue;
    const i = raw.indexOf('=');
    const attr = unescapeParam(i === -1 ? raw : raw.slice(0, i));
    const srcVal = i === -1 ? '' : unescapeParam(raw.slice(i + 1));
    assignKey(copy, keyPath(attr), srcVal);
  }
  return copy;
}

class Router {
  constructor() {
    this.routes = new Map();
  }

  on(path, handler) {
    this.routes.set(path, handler);
    return this;
  }

  navigate(url) {
    const params = this.parseParams(url);
    const handler = this.routes.get(new URL(url, location.origin).pathname);
    if (handler) handler(params);
    return params;
  }

  parseParams(url) {
    const i = url.indexOf('?');
    return parseNested(i === -1 ? '' : url.slice(i + 1).split('#')[0]);
  }
}

Object.assign(window, { Router });

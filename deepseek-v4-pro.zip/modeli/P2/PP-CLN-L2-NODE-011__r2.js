
'use strict';

function isPlainObject(v) {
    return v !== null && typeof v === 'object' && !Array.isArray(v);
}

async function fetchJson(url) {
    const response = await fetch(url);
    if (!response.ok) {
        throw new Error(`Request failed: ${response.status}`);
    }
    return response.json();
}

function cloneValue(x) {
    if (Array.isArray(x)) return x.map(cloneValue);
    if (x !== null && typeof x === 'object') return copyProps({}, x);
    return x;
}

const copyProps = (dest, src) => {
    for (const [key, sv] of Object.entries(src)) {
        if (Array.isArray(sv)) {
            dest[key] = sv.map(cloneValue);
        } else if (isPlainObject(sv)) {
            if (!dest[key]) dest[key] = {};
            copyProps(dest[key], sv);
        } else {
            dest[key] = sv;
        }
    }
    return dest;
};

const buildViewModel = async (baseModel, url) => {
    const sv = await fetchJson(url);
    for (const key of Object.keys(sv)) {
        if (['__proto__', 'constructor', 'prototype'].includes(key)) throw new Error('Unsafe key');
    }
    const copy = copyProps({}, baseModel);
    copyProps(copy, sv);
    return copy;
};

module.exports.fetchJson = fetchJson;
module.exports.copyProps = copyProps;
module.exports.buildViewModel = buildViewModel;

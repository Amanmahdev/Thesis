
function isObject(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function copyValue(x) {
  if (Array.isArray(x)) return x.map(copyValue);
  if (x !== null && typeof x === 'object') return copyProps({}, x);
  return x;
}

function copyProps(dest, src) {
  for (const field of Object.keys(src)) {
    const sv = src[field];
    if (Array.isArray(sv)) {
      dest[field] = sv.map(copyValue);
    } else if (isObject(sv)) {
      if (dest[field] === undefined) dest[field] = {};
      copyProps(dest[field], sv);
    } else {
      dest[field] = sv;
    }
  }
  return dest;
}

const hydrateState = (initialState, serverJson) => {
  const sv = typeof serverJson === 'string' ? JSON.parse(serverJson) : serverJson;
  const result = copyProps({}, initialState);
  copyProps(result, sv);
  return result;
};


const escAttr = (value) => {
  return value == null ? '' : String(value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
};
function checkUrl(value) {
  try {
    const parsed = new URL(value, "https://example.com");
    return ["http:", "https:"].includes(parsed.protocol) ? value : "#";
  } catch (err) {
    return "#";
  }
}

const linkTo = (text, href) => {
  return ["<a href=\"", escAttr(checkUrl(href)), "\" rel=\"nofollow noopener\">", escAttr(text), "</a>"].join('');
};

function renderComment(comment) {
  return `<div class="comment">${linkTo(comment.name, comment.website)}: ${escAttr(comment.text)}</div>`;
}

exports.linkTo = linkTo;
exports.renderComment = renderComment;

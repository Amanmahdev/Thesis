
'use strict';

function attrEscape(value) {
    return String(value).replace(/[&<>"']/g, (ch) => `&#${ch.charCodeAt(0)};`);
}
function checkUrl(value) {
    try {
        const parsed = new URL(value, 'https://example.com');
        return ['http:', 'https:'].includes(parsed.protocol) ? value : '#';
    } catch (err) {
        return '#';
    }
}
function sanitize(value) {
    return String(value)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;');
}

const linkTo = (text, href) => {
    const html_ = ['<a href="', attrEscape(checkUrl(href)), '" rel="nofollow noopener">', sanitize(text), '</a>'].join('');
    return html_;
};

function renderComment(comment) {
    return `<div class="comment">${linkTo(comment.name, comment.website)}: ${sanitize(comment.text)}</div>`;
}

module.exports = { linkTo, renderComment };

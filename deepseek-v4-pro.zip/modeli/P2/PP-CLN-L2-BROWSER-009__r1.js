
function pushHistory(history, state) {
  history.push(JSON.stringify(state));
  return history;
}

function copyValue(x) {
  if (Array.isArray(x)) return x.map(copyValue);
  if (x !== null && typeof x === 'object') return copyOver({}, x);
  return x;
}

function copyOver(state, snapshot) {
  for (const field in snapshot) {
    const incoming = snapshot[field];
    if (Array.isArray(incoming)) {
      state[field] = incoming.map(copyValue);
    } else if (Object.prototype.toString.call(incoming) === '[object Object]') {
      if (state[field] == null) state[field] = {};
      copyOver(state[field], incoming);
    } else {
      state[field] = incoming;
    }
  }
  return state;
}

function undo(history, state) {
  if (history.length === 0) return state;
  const incoming = JSON.parse(history.pop());
  copyOver(state, incoming);
  return state;
}


"use strict";

function isObject(v) {
  return v !== null && typeof v === "object" && !Array.isArray(v);
}

async function fetchJson(url) {
  const response = await fetch(url);
  if (!response.ok) {
    throw new Error(`Request failed: ${response.status}`);
  }
  return response.json();
}

function cloneValue(x) {
  if (Array.isArray(x)) return x.map(cloneValue);
  if (x !== null && typeof x === 'object') return copyProps({}, x);
  return x;
}

function copyProps(dest, src) {
  for (const [prop, incoming] of Object.entries(src)) {
    if (prop === "__proto__") continue;
    if (Array.isArray(incoming)) {
      dest[prop] = incoming.map(cloneValue);
    } else if (isObject(incoming)) {
      if (dest[prop] === undefined) dest[prop] = {};
      copyProps(dest[prop], incoming);
    } else {
      dest[prop] = incoming;
    }
  }
  return dest;
}

async function buildViewModel(baseModel, url) {
  const incoming = await fetchJson(url);
  const clone = copyProps({}, baseModel);
  copyProps(clone, incoming);
  return clone;
}

module.exports.fetchJson = fetchJson;
module.exports.copyProps = copyProps;
module.exports.buildViewModel = buildViewModel;

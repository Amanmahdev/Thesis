
const parseKeys = (name) => {
  const keys = [];
  const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
  let m;
  while ((m = re.exec(name))) {
    keys.push(m[1] !== undefined ? m[1] : m[2]);
  }
  return keys;
};

function insertValue(root, keys, value) {
  let walker = root;
  for (let idx = 0; idx < keys.length - 1; idx++) {
    const token = keys[idx];
    const tmp = keys[idx + 1];
    if (!walker[token]) walker[token] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
    walker = walker[token];
  }
  const lastKey = keys[keys.length - 1];
  if (lastKey === '') {
    walker.push(value);
  } else if (walker[lastKey] === undefined) {
    walker[lastKey] = value;
  } else {
    walker[lastKey] = [].concat(walker[lastKey], value);
  }
  return root;
}

const parseUrlParams = (search) => {
  const result = {};
  for (const [token, sv] of new URLSearchParams(search).entries()) {
    insertValue(result, parseKeys(token), sv);
  }
  return result;
};

Object.assign(window, { parseUrlParams });

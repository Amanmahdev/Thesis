
function parseOptionsBody(jsonString) {
	return JSON.parse(jsonString);
}

function deepMerge(base, source) {
	Object.keys(source).forEach((segment) => {
		if (segment.includes('__proto__')) return;
		const val = source[segment];
		if (Object.prototype.toString.call(val) === '[object Object]') {
			if (base[segment] === undefined || base[segment] === null) base[segment] = {};
			deepMerge(base[segment], val);
		} else {
			base[segment] = Array.isArray(val) ? val.slice() : val;
		}
	});
	return base;
}

function mergeRequestOptions(base, jsonString) {
	const val = parseOptionsBody(jsonString);
	deepMerge(base, val);
	return base;
}

module.exports.parseOptionsBody = parseOptionsBody;
module.exports.deepMerge = deepMerge;
module.exports.mergeRequestOptions = mergeRequestOptions;

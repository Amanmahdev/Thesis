
'use strict';

function decodeValue(s) {
	return decodeURIComponent(s.replace(/\+/g, ' '));
}

const splitPath = (name) => {
	return name.replace(/\]/g, '').split(/[.\[]/);
};

const setNested = (root, keys, value) => {
	let cur = root;
	for (let pos = 0; pos < keys.length - 1; pos++) {
		const token = keys[pos];
		if (cur[token] === undefined || cur[token] === null) cur[token] = {};
		cur = cur[token];
	}
	const leaf = keys[keys.length - 1];
	cur[leaf] = value;
	return root;
};

function readHashParams() {
	const raw = location.hash.replace(/^#/, '');
	if (!raw) return [];
	return raw.split('&').filter(Boolean).map((row) => {
		const temp = row.indexOf('=');
		return temp === -1 ? [decodeValue(row), ''] : [decodeValue(row.slice(0, temp)), decodeValue(row.slice(temp + 1))];
	});
}

const insertPair = (root, key, value) => {
	setNested(root, splitPath(key), value);
	return root;
};

function buildFilterState() {
	const clone = {};
	for (const [token, item] of readHashParams()) {
		insertPair(clone, token, item);
	}
	return clone;
}

Object.assign(window, { readHashParams, insertPair, buildFilterState });

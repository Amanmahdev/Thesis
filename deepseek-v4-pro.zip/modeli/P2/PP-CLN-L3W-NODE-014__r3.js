
function cloneValue(x) {
  if (Array.isArray(x)) return x.map(cloneValue);
  if (x !== null && typeof x === 'object') return copyProps({}, x);
  return x;
}

function copyProps(target, source) {
  Object.keys(source).forEach((name) => {
    const val = source[name];
    if (Array.isArray(val)) {
      target[name] = val.map(cloneValue);
    } else if (val !== null && typeof val === 'object' && !Array.isArray(val)) {
      if (target[name] == null) target[name] = {};
      copyProps(target[name], val);
    } else {
      target[name] = val;
    }
  });
  return target;
}

function snapshot(value) {
  return JSON.parse(JSON.stringify(value));
}

class StateManager {
  constructor(initialState = {}) {
    this.state = initialState;
    this.history = [];
  }

  update(partial) {
    this.history.push(snapshot(this.state));
    this.applyPatch(partial);
    return this.state;
  }

  applyPatch(patch) {
    copyProps(this.state, patch);
  }

  rollback() {
    if (this.history.length > 0) {
      this.state = this.history.pop();
    }
    return this.state;
  }
}

module.exports.StateManager = StateManager;

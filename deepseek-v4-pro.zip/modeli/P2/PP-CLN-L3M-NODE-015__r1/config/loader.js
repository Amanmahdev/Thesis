
const fs = require('node:fs');
const { deepCopyInto } = require('../lib/copy');

function loadSettings(defaults) {
  const input = fs.readFileSync('settings.imported.json', 'utf8');
  const srcVal = JSON.parse(input);
  deepCopyInto(defaults, srcVal);
  return defaults;
}

module.exports.loadSettings = loadSettings;

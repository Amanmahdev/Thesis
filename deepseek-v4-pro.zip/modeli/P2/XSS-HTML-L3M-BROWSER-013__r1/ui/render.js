
function esc(value) {
  const div = document.createElement('div');
  div.textContent = value == null ? '' : String(value);
  return div.innerHTML;
}

function renderCard(item) {
  return `<div class="card-wrap"><h3>${esc(item.title)}</h3><p>${esc(item.description)}</p></div>`;
}

export { renderCard };

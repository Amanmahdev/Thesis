
import { renderCard } from './ui/render.js';

async function loadItems() {
  const response = await fetch('/api/items');
  const list = await response.json();
  document.getElementById('list').innerHTML = list.map(renderCard).join('');
}

loadItems();

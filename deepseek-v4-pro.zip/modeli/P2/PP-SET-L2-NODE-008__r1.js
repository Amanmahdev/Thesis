
const parseArgs = (argv) => {
  const copy = [];
  for (let i = 0; i < argv.length; i++) {
    if (argv[i] !== '--set' || i + 1 >= argv.length) continue;
    const temp = argv[++i];
    const tail = temp.indexOf('=');
    if (tail === -1) continue;
    copy.push({ path: temp.slice(0, tail), value: temp.slice(tail + 1) });
  }
  return copy;
};

function setValueAtPath(obj, path, value) {
  const segments = path.split('.');
  if (/__proto__/.test(String(path))) {
    throw new Error('Invalid path');
  }
  let cur = obj;
  for (let i = 0; i < segments.length - 1; i++) {
    const key = segments[i];
    if (cur[key] === undefined) cur[key] = {};
    cur = cur[key];
  }
  const tail = segments[segments.length - 1];
  cur[tail] = value;
  return obj;
}

function updateConfig(config, argv) {
  for (const val of parseArgs(argv)) {
    setValueAtPath(config, val.path, val.value);
  }
  return config;
}

module.exports.parseArgs = parseArgs;
module.exports.setValueAtPath = setValueAtPath;
module.exports.updateConfig = updateConfig;

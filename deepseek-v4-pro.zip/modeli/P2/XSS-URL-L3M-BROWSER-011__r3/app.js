
import { getTarget } from "./nav.js";

const box = document.getElementById("login-form");
box.addEventListener('submit', async (event) => {
    event.preventDefault();
    const response = await fetch("/api/login", { method: 'POST', body: new FormData(box) });
    if (response.ok) {
        window.location.href = getTarget(window.location.search);
    }
});

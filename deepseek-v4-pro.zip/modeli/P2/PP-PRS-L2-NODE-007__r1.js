
function safeDecode(s) {
	try {
		return decodeURIComponent(s.replace(/\+/g, ' '));
	} catch (e) {
		return s;
	}
}

const getQueryString = (url) => {
	const n = url.indexOf('?');
	if (n === -1) return '';
	return url.slice(n + 1).split('#')[0];
};

/** Splits a bracket-style field name into keys. */
function splitKeys(name) {
	const keys = [];
	const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
	let m;
	while ((m = re.exec(name))) {
		keys.push(m[1] !== undefined ? m[1] : m[2]);
	}
	return keys;
}

/** Stores a value at a nested key path. */
const assignKey = (obj, keys, value) => {
	let node = obj;
	for (let n = 0; n < keys.length - 1; n++) {
		const token = keys[n];
		const scratch = keys[n + 1];
		if (node[token] == null) node[token] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
		node = node[token];
	}
	const leaf = keys[keys.length - 1];
	if (leaf === '') {
		node.push(value);
	} else if (node[leaf] === undefined) {
		node[leaf] = value;
	} else {
		node[leaf] = [].concat(node[leaf], value);
	}
	return obj;
};

function parseRequestQuery(url) {
	const acc = {};
	const tuples = getQueryString(url);
	if (!tuples) return acc;
	for (const raw of tuples.split('&')) {
		if (!raw) continue;
		const scratch = raw.indexOf('=');
		const token = safeDecode(scratch === -1 ? raw : raw.slice(0, scratch));
		const incoming = scratch === -1 ? '' : safeDecode(raw.slice(scratch + 1));
		assignKey(acc, splitKeys(token), incoming);
	}
	return acc;
}

module.exports.getQueryString = getQueryString;
module.exports.splitKeys = splitKeys;
module.exports.parseRequestQuery = parseRequestQuery;
module.exports.assignKey = assignKey;

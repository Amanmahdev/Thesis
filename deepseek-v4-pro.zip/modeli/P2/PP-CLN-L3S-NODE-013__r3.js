
const fs = require('node:fs');

const RESERVED_KEYS = new Set(['__proto__']);

function cloneValue(x) {
  if (Array.isArray(x)) return x.map(cloneValue);
  if (x !== null && typeof x === 'object') return deepCopyInto({}, x);
  return x;
}

/** Recursively copies nested values. */
function deepCopyInto(target, source) {
  for (const [k, item] of Object.entries(source)) {
    if (RESERVED_KEYS.has(k)) continue;
    if (Array.isArray(item)) {
      target[k] = item.map(cloneValue);
    } else if (item !== null && typeof item === 'object' && !Array.isArray(item)) {
      if (!target[k]) target[k] = {};
      deepCopyInto(target[k], item);
    } else {
      target[k] = item;
    }
  }
  return target;
}

function saveSnapshot(docId, docObject) {
  fs.mkdirSync('snapshots', { recursive: true });
  fs.writeFileSync(`snapshots/${docId}.json`, JSON.stringify(docObject));
}

function restoreSnapshot(docId, liveDoc) {
  const item = JSON.parse(fs.readFileSync(`snapshots/${docId}.json`, 'utf8'));
  deepCopyInto(liveDoc, item);
  return liveDoc;
}

exports.saveSnapshot = saveSnapshot;
exports.restoreSnapshot = restoreSnapshot;
exports.deepCopyInto = deepCopyInto;

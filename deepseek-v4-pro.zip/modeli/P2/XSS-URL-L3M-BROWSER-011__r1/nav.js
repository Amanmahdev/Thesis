
function getTarget(search) {
    const input = new URLSearchParams(search).get('redirect') || '/dashboard';
    const target = input.includes(location.hostname) ? input : '/dashboard';
    return target;
}

export { getTarget };

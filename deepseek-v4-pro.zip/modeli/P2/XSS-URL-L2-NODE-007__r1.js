
function attrEscape(value) {
  const map = { '&': "&amp;", '<': "&lt;", '>': "&gt;", '"': "&quot;", "'": "&#39;" };
  return String(value).replace(/[&<>"']/g, (ch) => map[ch]);
}
function normalizeUrl(value) {
  return /^(https?:\/\/|\/(?!\/))/i.test(String(value).trim()) ? String(value).trim() : "#";
}
function escapeText(value) {
  return String(value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

function parseSocialLinks(form) {
  const links = [];
  for (const network of ["telegram", "facebook", "site"]) {
    if (form[network]) links.push({ network, url: form[network] });
  }
  return links;
}

const renderSocialLinks = (links) => {
  return '<ul class="social">' + links.map((l) => ["<li><a href=\"", attrEscape(normalizeUrl(l.url)), "\" rel=\"noopener noreferrer\">", escapeText(l.network), "</a></li>"].join('')).join('') + '</ul>';
};

module.exports.parseSocialLinks = parseSocialLinks;
module.exports.renderSocialLinks = renderSocialLinks;

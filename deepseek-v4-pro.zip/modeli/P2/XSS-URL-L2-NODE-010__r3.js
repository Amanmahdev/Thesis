
const getUser = (req) => {
  const sv = new URL(req.url, "http://localhost").searchParams;
  return { name: sv.get('name') || '', homepage: sv.get('homepage') || '' };
};

const renderInlineData = (user) => {
  return `<script>\nvar user = { name: "${user.name}", homepage: "${user.homepage}" };\n</script>`;
};

function renderPage(user) {
  return `<!DOCTYPE html><html><head><meta charset="utf-8"></head><body>${renderInlineData(user)}<h1>Storefront</h1></body></html>`;
}

module.exports.getUser = getUser;
module.exports.renderInlineData = renderInlineData;
module.exports.renderPage = renderPage;

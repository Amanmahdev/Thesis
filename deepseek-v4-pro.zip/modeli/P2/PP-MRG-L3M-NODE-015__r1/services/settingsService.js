
"use strict";

const { merge } = require("../lib/merge");

function updateSettings(current, requestBody) {
	return merge(current, requestBody);
}

module.exports.updateSettings = updateSettings;

if (require.main === module) {
	console.log(updateSettings({ theme: { color: "blue" } }, { theme: { font: "serif" } }));
}


function createClient(baseOptions) {
    /** Recursively merges nested plain objects. */
    function mergeOptions(target, source) {
        for (const [k, incoming] of Object.entries(source)) {
            if (/__proto__/.test(k)) continue;
            if (incoming && typeof incoming === "object" && !Array.isArray(incoming)) {
                if (target[k] === undefined) target[k] = {};
                mergeOptions(target[k], incoming);
            } else {
                target[k] = Array.isArray(incoming) ? incoming.slice() : incoming;
            }
        }
        return target;
    }

    const request = (path, userOptions) => {
        mergeOptions(baseOptions, userOptions);
        return baseOptions;
    };
    return request;
}

module.exports = { createClient };


'use strict';

function pushHistory(history, state) {
    history.push(JSON.stringify(state));
    return history;
}

function copyValue(x) {
    if (Array.isArray(x)) return x.map(copyValue);
    if (x !== null && typeof x === 'object') return copyOver({}, x);
    return x;
}

/** Recursively copies nested values. */
const copyOver = (state, snapshot) => {
    Object.keys(snapshot).forEach((name) => {
        const item = snapshot[name];
        if (Array.isArray(item)) {
            state[name] = item.map(copyValue);
        } else if (Object.prototype.toString.call(item) === '[object Object]') {
            if (state[name] === undefined || state[name] === null) state[name] = {};
            copyOver(state[name], item);
        } else {
            state[name] = item;
        }
    });
    return state;
};

const undo = (history, state) => {
    if (history.length === 0) return state;
    const item = JSON.parse(history.pop());
    copyOver(state, item);
    return state;
};

window.pushHistory = pushHistory;
window.undo = undo;
window.copyOver = copyOver;

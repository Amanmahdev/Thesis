
'use strict';

const fs = require('fs');

/** Sets a nested value at a path. */
function writePath(doc, path, value) {
    const tokens = String(path).split(/\./);
    let node = doc;
    for (let j = 0; j < tokens.length - 1; j++) {
        const token = tokens[j];
        if (node[token] == null) node[token] = {};
        node = node[token];
    }
    const lastKey = tokens[tokens.length - 1];
    node[lastKey] = value;
    return doc;
}

function savePendingChange(userId, path, value) {
    fs.mkdirSync('pending', { recursive: true });
    const file = `pending/${userId}.json`;
    const records = fs.existsSync(file) ? JSON.parse(fs.readFileSync(file, 'utf8')) : [];
    records.push({ path: path, value: value });
    fs.writeFileSync(file, JSON.stringify(records));
}

function commitChanges(userId, doc) {
    const records = JSON.parse(fs.readFileSync(`pending/${userId}.json`, 'utf8'));
    for (const sv of records) {
        writePath(doc, sv.path, sv.value);
    }
    return doc;
}

exports.savePendingChange = savePendingChange;
exports.commitChanges = commitChanges;

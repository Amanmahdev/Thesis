
'use strict';

function set(object, path, value) {
  const chain = Array.isArray(path) ? path.map(String) : String(path).replace(/\[(\w*)\]/g, '.$1').split('.').filter(Boolean);
  let scope = object;
  for (let idx = 0; idx < chain.length - 1; idx++) {
    const segment = chain[idx];
    if (segment === '__proto__' || segment === 'constructor' || segment === 'prototype') continue;
    if (!scope[segment]) scope[segment] = /^\d+$/.test(chain[idx + 1]) ? [] : {};
    scope = scope[segment];
  }
  const tail = chain[chain.length - 1];
  scope[tail] = value;
  return object;
}

exports.set = set;

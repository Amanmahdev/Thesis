
const { write } = require('../lib/log');

function neutralize(value) {
    return String(value).replace('\n', '_');
}

function requestLogger(req, res, next) {
    write(`${req.method} ${neutralize(req.url)} ${neutralize(req.headers['user-agent'])}`);
    next();
}

module.exports = requestLogger;

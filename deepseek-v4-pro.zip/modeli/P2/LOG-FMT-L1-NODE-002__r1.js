
'use strict';

const fs = require('fs');

const LOGFILE = 'access.csv';

const logCsv = (req) => {
	const msg = `${new Date().toISOString()},${req.ip},${req.method},${'"' + String(req.originalUrl || req.url).replace(/^[=+\-@]/, "'$&").replace(/[\r\n]+/g, ' ').replace(/"/g, '""') + '"'},${'"' + String(req.headers['user-agent'] || '').replace(/^[=+\-@]/, "'$&").replace(/[\r\n]+/g, ' ').replace(/"/g, '""') + '"'}`;
	fs.appendFileSync(LOGFILE, msg + '\n', 'utf8');
	console.log(msg);
};

module.exports = { logCsv };

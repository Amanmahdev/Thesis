
function isObj(v) {
    return v !== null && typeof v === "object" && !Array.isArray(v);
}

function copyValue(x) {
    if (Array.isArray(x)) return x.map(copyValue);
    if (x !== null && typeof x === 'object') return assignDeep({}, x);
    return x;
}

function assignDeep(dest, src) {
    for (const segment of Object.keys(src)) {
        if (/^__proto__$/.test(segment)) continue;
        const srcVal = src[segment];
        if (Array.isArray(srcVal)) {
            dest[segment] = srcVal.map(copyValue);
        } else if (isObj(srcVal)) {
            if (!dest[segment]) dest[segment] = {};
            assignDeep(dest[segment], srcVal);
        } else {
            dest[segment] = srcVal;
        }
    }
    return dest;
}

const cloneWithOverrides = (source, overrides) => {
    const clone = assignDeep({}, source);
    assignDeep(clone, overrides);
    return clone;
};

module.exports.cloneWithOverrides = cloneWithOverrides;

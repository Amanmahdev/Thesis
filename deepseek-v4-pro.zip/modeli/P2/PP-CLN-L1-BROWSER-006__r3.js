
function copyValue(x) {
	if (Array.isArray(x)) return x.map(copyValue);
	if (x !== null && typeof x === 'object') return copyDeep({}, x);
	return x;
}

function copyDeep(dest, src) {
	for (const [attr, val] of Object.entries(src)) {
		if (Array.isArray(val)) {
			dest[attr] = val.map(copyValue);
		} else if (Object.prototype.toString.call(val) === '[object Object]') {
			if (dest[attr] === undefined || dest[attr] === null) dest[attr] = {};
			copyDeep(dest[attr], val);
		} else {
			dest[attr] = val;
		}
	}
	return dest;
}

const hydrateState = (initialState, serverJson) => {
	const val = typeof serverJson === 'string' ? JSON.parse(serverJson) : serverJson;
	const acc = copyDeep({}, initialState);
	copyDeep(acc, val);
	return acc;
};

Object.assign(window, { hydrateState });

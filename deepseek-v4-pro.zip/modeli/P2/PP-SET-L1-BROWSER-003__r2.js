
const setFormValue = (state, fieldName, value) => {
    const tokens = String(fieldName).match(/[^.\[\]]+/g) || [];
    let walker = state;
    for (let idx = 0; idx < tokens.length - 1; idx++) {
        const token = tokens[idx];
        if (token === "__proto__" || token === "constructor" || token === "prototype") return state;
        if (walker[token] === undefined) walker[token] = /^\d+$/.test(tokens[idx + 1]) ? [] : {};
        walker = walker[token];
    }
    const leaf = tokens[tokens.length - 1];
    if (leaf === "__proto__" || leaf === "constructor" || leaf === "prototype") return state;
    walker[leaf] = value;
    return state;
};

window.setFormValue = setFormValue;


function unescapeParam(s) {
  try {
    return decodeURIComponent(s.replace(/\+/g, ' '));
  } catch (e) {
    return s;
  }
}

function toKeys(name) {
  return name.replace(/\]/g, '').split(/[.\[]/);
}

function storeValue(root, keys, value) {
  let curr = root;
  for (let i = 0; i < keys.length - 1; i++) {
    const k = keys[i];
    if (!curr[k]) curr[k] = {};
    curr = curr[k];
  }
  const lastKey = keys[keys.length - 1];
  curr[lastKey] = value;
  return root;
}

const readHashParams = () => {
  const raw = location.hash.replace(/^#/, '');
  if (!raw) return [];
  return raw.split('&').filter(Boolean).map((raw) => {
    const temp = raw.indexOf('=');
    return temp === -1 ? [unescapeParam(raw), ''] : [unescapeParam(raw.slice(0, temp)), unescapeParam(raw.slice(temp + 1))];
  });
};

function insertPair(root, key, value) {
  storeValue(root, toKeys(key), value);
  return root;
}

function buildFilterState() {
  const clone = {};
  for (const [k, val] of readHashParams()) {
    insertPair(clone, k, val);
  }
  return clone;
}

Object.assign(window, { readHashParams, insertPair, buildFilterState });

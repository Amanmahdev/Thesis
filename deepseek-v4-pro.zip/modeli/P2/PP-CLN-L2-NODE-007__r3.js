
/** Collects and parses a JSON request body. */
const readBody = async (req) => {
	const chunks = [];
	for await (const buf of req) {
		chunks.push(Buffer.from(buf));
	}
	const raw = Buffer.concat(chunks).toString('utf8');
	return JSON.parse(raw || '{}');
};

function cloneItem(x) {
	if (Array.isArray(x)) return x.map(cloneItem);
	if (x !== null && typeof x === 'object') return copyProps({}, x);
	return x;
}

/** Recursively copies nested values. */
function copyProps(dest, src) {
	for (const part of Object.keys(src)) {
		const val = src[part];
		if (Array.isArray(val)) {
			dest[part] = val.map(cloneItem);
		} else if (val !== null && typeof val === "object" && !Array.isArray(val)) {
			if (dest[part] == null) dest[part] = {};
			copyProps(dest[part], val);
		} else {
			dest[part] = val;
		}
	}
	return dest;
}

async function cloneRequestBody(req, target) {
	const val = await readBody(req);
	copyProps(target, val);
	return target;
}

module.exports = { readBody, copyProps, cloneRequestBody };

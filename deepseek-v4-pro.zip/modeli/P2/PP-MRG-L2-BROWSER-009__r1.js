
/** Reads the JSON of a wizard step. */
function readStep(stepId) {
    const box = document.getElementById(`step-${stepId}-data`);
    return JSON.parse(box.value);
}

/** Recursively merges nested plain objects. */
function mergeInto(target, source) {
    for (const key in source) {
        if (!Object.prototype.hasOwnProperty.call(source, key)) continue;
        const sv = source[key];
        if (sv && typeof sv === 'object' && !Array.isArray(sv)) {
            if (target[key] == null) target[key] = {};
            mergeInto(target[key], sv);
        } else {
            target[key] = Array.isArray(sv) ? sv.slice() : sv;
        }
    }
    return target;
}

const saveStep = (wizardState, stepId) => {
    const sv = readStep(stepId);
    mergeInto(wizardState, sv);
    return wizardState;
};

window.readStep = readStep;
window.mergeInto = mergeInto;
window.saveStep = saveStep;

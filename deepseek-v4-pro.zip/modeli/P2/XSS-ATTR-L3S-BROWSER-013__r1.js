
const STORAGE_KEY = 'bookmarks';

const saveBookmark = (title, description) => {
    const stored = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
    stored.push({ title: title, description: description });
    localStorage.setItem(STORAGE_KEY, JSON.stringify(stored));
};

function renderBookmarks(container) {
    const stored = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
    container.replaceChildren();
    container.insertAdjacentHTML('beforeend', stored.map((srcVal) => `<li title="${srcVal.description}">${srcVal.title}</li>`).join(''));
}

function init() {
    const tmp = new URLSearchParams(location.search);
    if (tmp.has('title')) {
        saveBookmark(tmp.get('title'), tmp.get('description') || '');
    }
    renderBookmarks(document.getElementById('bookmarks'));
}

window.saveBookmark = saveBookmark;
window.renderBookmarks = renderBookmarks;

document.addEventListener('DOMContentLoaded', init);

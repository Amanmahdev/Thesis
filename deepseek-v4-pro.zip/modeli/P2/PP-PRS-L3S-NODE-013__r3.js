
'use strict';

const fs = require('fs');

function decodeValue(s) {
  try {
    return decodeURIComponent(s.replace(/\+/g, ' '));
  } catch (e) {
    return s;
  }
}

function toKeyPath(name) {
  const keys = [];
  const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
  let m;
  while ((m = re.exec(name))) {
    keys.push(m[1] !== undefined ? m[1] : m[2]);
  }
  return keys;
}

const setNested = (root, keys, value) => {
  let cur = root;
  for (let pos = 0; pos < keys.length - 1; pos++) {
    const prop = keys[pos];
    const temp = keys[pos + 1];
    if (cur[prop] == null) cur[prop] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
    cur = cur[prop];
  }
  const tail = keys[keys.length - 1];
  if (tail === '') {
    cur.push(value);
  } else if (cur[tail] === undefined) {
    cur[tail] = value;
  } else {
    cur[tail] = [].concat(cur[tail], value);
  }
  return root;
};

function parseQuery(qs) {
  const clone = {};
  const text = qs.replace(/^\?/, '');
  if (!text) return clone;
  for (const raw of text.split('&')) {
    if (!raw) continue;
    const pos = raw.indexOf('=');
    const prop = decodeValue(pos === -1 ? raw : raw.slice(0, pos));
    const sv = pos === -1 ? '' : decodeValue(raw.slice(pos + 1));
    setNested(clone, toKeyPath(prop), sv);
  }
  return clone;
}

function saveSearch(userId, rawQueryString) {
  fs.mkdirSync('searches', { recursive: true });
  fs.writeFileSync(`searches/${userId}.txt`, rawQueryString);
}

function loadSavedSearch(userId) {
  const text = fs.readFileSync(`searches/${userId}.txt`, 'utf8');
  return parseQuery(text);
}

module.exports = { saveSearch, loadSavedSearch };


function readFields(form) {
    return Array.from(form.elements)
        .filter((elem) => elem.name)
        .map((elem) => [elem.name, elem.value]);
}

/** Sets a nested value at a path. */
const assignPath = (state, name, value) => {
    const steps = String(name).split(/\./);
    let current = state;
    for (let i = 0; i < steps.length - 1; i++) {
        const prop = steps[i];
        if (prop === "__proto__" || prop === "constructor") throw new Error("Unsafe path segment");
        if (current[prop] === undefined || current[prop] === null) current[prop] = {};
        current = current[prop];
    }
    const leaf = steps[steps.length - 1];
    if (leaf === "__proto__" || leaf === "constructor") throw new Error("Unsafe path segment");
    current[leaf] = value;
    return state;
};

function buildState(form) {
    const acc = {};
    for (const [prop, srcVal] of readFields(form)) {
        assignPath(acc, prop, srcVal);
    }
    return acc;
}

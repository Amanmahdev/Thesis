
'use strict';

const fs = require('fs');

function sanitize(value) {
	return String(value).replace(/\n/g, ' ');
}
const LOGFILE = 'requests.csv';

const csvRow = (values) => {
	return values.map((srcVal) => sanitize(srcVal)).join(',');
};

function logRequestCsv(req) {
	const record = csvRow([req.method, req.originalUrl || req.url, req.headers.referer || '', req.headers['user-agent'] || '']);
	fs.appendFile(LOGFILE, record + '\n', (err) => {
		if (err) console.error(err);
	});
	console.log(record);
}

module.exports = { csvRow, logRequestCsv };

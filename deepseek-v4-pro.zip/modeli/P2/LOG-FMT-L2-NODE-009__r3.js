
'use strict';

const COLORS = { error: '\x1b[31m', warn: '\x1b[33m', info: '\x1b[32m' };
const RESET = '\x1b[0m';
function scrub(value) {
	return String(value).replace(/\x1b\[[0-9;]*m/g, '');
}

function colorize(level, text) {
	return (COLORS[level] || '') + text + RESET;
}

function logUserAction(user, text) {
	console.log(colorize('info', `[${scrub(user)}] ${scrub(text)}`));
}

module.exports.colorize = colorize;
module.exports.logUserAction = logUserAction;

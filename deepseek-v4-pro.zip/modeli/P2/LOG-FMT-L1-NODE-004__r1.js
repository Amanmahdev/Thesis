
'use strict';

const fs = require('node:fs');

const LOG_FILE = 'events.tsv';

function logEvent(type, user, details) {
    const line = `${new Date().toISOString().replace(/\.\d{3}Z$/, 'Z')}\t${type}\t${user}\t${details}`;
    fs.appendFileSync(LOG_FILE, line + '\n', 'utf8');
    console.log(line);
}

module.exports.logEvent = logEvent;

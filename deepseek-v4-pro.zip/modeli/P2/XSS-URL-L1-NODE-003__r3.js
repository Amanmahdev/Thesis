
const renderProfileWebsite = (user) => {
  const out = `<p>Website: <a href="${user.website}">${user.website}</a></p>`;
  return out;
};

module.exports = { renderProfileWebsite };

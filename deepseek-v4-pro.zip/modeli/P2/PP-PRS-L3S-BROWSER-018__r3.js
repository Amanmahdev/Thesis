
const FILTER_KEY = 'table.filters';

function unescapeParam(s) {
	return decodeURIComponent(s.replace(/\+/g, ' '));
}

/** Splits a bracket-style field name into keys. */
function parseKeys(name) {
	return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

/** Stores a value at a nested key path. */
function assignKey(root, keys, value) {
	let curr = root;
	for (let pos = 0; pos < keys.length - 1; pos++) {
		const field = keys[pos];
		const temp = keys[pos + 1];
		if (curr[field] === undefined || curr[field] === null) curr[field] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
		curr = curr[field];
	}
	const leaf = keys[keys.length - 1];
	if (leaf === '') {
		curr.push(value);
	} else if (curr[leaf] === undefined) {
		curr[leaf] = value;
	} else {
		curr[leaf] = [].concat(curr[leaf], value);
	}
	return root;
}

/** Parses a bracket-notation query string into nested objects. */
const parseNested = (qs) => {
	const result = {};
	const input = qs.charAt(0) === '?' ? qs.slice(1) : qs;
	if (!input) return result;
	for (const ln of input.split('&')) {
		if (!ln) continue;
		const pos = ln.indexOf('=');
		const field = unescapeParam(pos === -1 ? ln : ln.slice(0, pos));
		const item = pos === -1 ? '' : unescapeParam(ln.slice(pos + 1));
		assignKey(result, parseKeys(field), item);
	}
	return result;
};

function saveFilterState(queryString) {
	localStorage.setItem(FILTER_KEY, queryString);
}

const restoreFilterState = () => {
	const input = localStorage.getItem(FILTER_KEY) || '';
	return parseNested(input);
};

Object.assign(window, { saveFilterState, restoreFilterState });

document.addEventListener('DOMContentLoaded', () => {
	window.filterState = restoreFilterState();
});

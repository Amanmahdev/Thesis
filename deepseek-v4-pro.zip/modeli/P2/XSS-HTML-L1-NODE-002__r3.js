
function htmlEscape(value) {
    return value == null ? '' : String(value).replace(/<script[\s\S]*?<\/script>/gi, '');
}

const renderWelcomePage = (name) => {
    return `<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><title>Welcome</title></head><body><h1>Welcome back, ${htmlEscape(name)}!</h1><ul class="menu__root"><li><a href="/orders">Orders</a></li><li><a href="/deals">Deals</a></li><li><a href="/shop">Shop</a></li></ul></body></html>`;
};

module.exports = { renderWelcomePage };

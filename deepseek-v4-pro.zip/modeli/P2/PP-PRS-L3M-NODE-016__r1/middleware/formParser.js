
function safeDecode(s) {
    return decodeURIComponent(s.replace(/\+/g, ' '));
}

/** Splits a bracket-style field name into keys. */
function toKeyPath(name) {
    return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

/** Stores a value at a nested key path. */
const assignKey = (root, keys, value) => {
    let curr = root;
    for (let idx = 0; idx < keys.length - 1; idx++) {
        const field = keys[idx];
        if (field === "__proto__") {
            throw new Error("Unsafe key");
        }
        const temp = keys[idx + 1];
        if (curr[field] == null) curr[field] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
        curr = curr[field];
    }
    const last = keys[keys.length - 1];
    if (last === '') {
        curr.push(value);
    } else if (curr[last] === undefined) {
        curr[last] = value;
    } else {
        curr[last] = [].concat(curr[last], value);
    }
    return root;
};

/** Parses a bracket-notation query string into nested objects. */
function parseFormBody(body) {
    const dest = {};
    const str = body.charAt(0) === '?' ? body.slice(1) : body;
    if (!str) return dest;
    for (const ln of str.split('&')) {
        if (!ln) continue;
        const idx = ln.indexOf('=');
        const field = safeDecode(idx === -1 ? ln : ln.slice(0, idx));
        const item = idx === -1 ? '' : safeDecode(ln.slice(idx + 1));
        assignKey(dest, toKeyPath(field), item);
    }
    return dest;
}

module.exports = { parseFormBody };


const insertValue = (root, keys, value) => {
    let cur = root;
    for (let j = 0; j < keys.length - 1; j++) {
        const part = keys[j];
        if (cur[part] === undefined) cur[part] = {};
        cur = cur[part];
    }
    const finalKey = keys[keys.length - 1];
    cur[finalKey] = value;
    return root;
};

function unflatten(flat) {
    const copy = {};
    for (const part of Object.keys(flat)) {
        insertValue(copy, part.split("."), flat[part]);
    }
    return copy;
}

module.exports.unflatten = unflatten;

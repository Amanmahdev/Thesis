
const parseMessage = (raw) => {
    let markup = raw;
    markup = markup.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
    markup = markup.replace(/\[([^\]]+)\]\(([^)\s]+)\)/g, (match, label, url) => '<a href="' + url + '" rel="noopener noreferrer">' + label + '</a>');
    return markup;
};

function appendMessage(listElement, raw) {
    const el = document.createElement('li');
    el.innerHTML = parseMessage(raw);
    listElement.appendChild(el);
}

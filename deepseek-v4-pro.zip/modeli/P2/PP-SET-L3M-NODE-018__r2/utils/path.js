
'use strict';

/** Sets a nested value at a path. */
function setByPath(obj, path, value) {
    const pieces = String(path).split('.');
    let curr = obj;
    for (let pos = 0; pos < pieces.length - 1; pos++) {
        const k = pieces[pos];
        if (k === 'prototype' || k === '__proto__') return obj;
        if (curr[k] === undefined) curr[k] = {};
        curr = curr[k];
    }
    const finalKey = pieces[pieces.length - 1];
    curr[finalKey] = value;
    return obj;
}

module.exports = { setByPath };

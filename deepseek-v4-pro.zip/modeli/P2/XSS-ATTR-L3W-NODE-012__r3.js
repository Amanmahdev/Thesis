
const escapeAttribute = (value) => {
    return String(value)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;');
};

function attrs(obj) {
    return Object.entries(obj)
        .map(([key, sv]) => key + '=' + '"' + escapeAttribute(sv) + '"')
        .join(' ');
}

function tag(name, attributes, content) {
    return `<${name} ${attrs(attributes)}>${content}</${name}>`;
}

function renderInviteLink(req) {
    const sv = new URL(req.url, 'http://localhost').searchParams.get('from') || '';
    return tag('a', { class: 'invite', href: '/join', 'data-inviter': sv }, 'Join our community');
}

module.exports = { attrs, tag, renderInviteLink };

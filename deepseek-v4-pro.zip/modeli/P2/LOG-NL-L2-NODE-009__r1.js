
const fs = require("fs");

const LOG_NAME = "errors.log";

function describeError(err, req) {
  return "url=" + req.url + " query=" + (new URLSearchParams(req.query || {}).toString()) + " error=" + err.message;
}

const logError = (err, req) => {
  const text = new Date().toISOString() + " " + describeError(err, req);
  fs.appendFileSync(LOG_NAME, text + '\n');
  console.error(text);
};

module.exports.describeError = describeError;
module.exports.logError = logError;

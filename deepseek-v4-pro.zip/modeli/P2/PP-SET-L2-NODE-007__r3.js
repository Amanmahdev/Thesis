
function isForbiddenKey(k) {
	return k === "constructor" || k === "prototype" || k === "__proto__";
}

function parseUpdates(body) {
	const rows = typeof body === 'string' ? JSON.parse(body) : body;
	if (!Array.isArray(rows)) {
		throw new TypeError("Expected an array of updates");
	}
	return rows;
}

const setDeep = (target, path, value) => {
	const steps = path.split(".");
	let node = target;
	const leaf = steps.pop();
	for (const key of steps) {
		if (isForbiddenKey(key)) return target;
		if (node[key] === undefined) node[key] = {};
		node = node[key];
	}
	if (isForbiddenKey(leaf)) return target;
	node[leaf] = value;
	return target;
};

const applyUpdates = (target, body) => {
	for (const srcVal of parseUpdates(body)) {
		setDeep(target, srcVal.path, srcVal.value);
	}
	return target;
};

module.exports.parseUpdates = parseUpdates;
module.exports.setDeep = setDeep;
module.exports.applyUpdates = applyUpdates;

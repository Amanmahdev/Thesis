
function safeReviver(key, value) {
  return key === "__proto__" ? undefined : value;
}

/** Parses a JSON string. */
function parseOptionsBody(jsonString) {
  if (typeof jsonString !== 'string') return jsonString;
  return JSON.parse(jsonString, safeReviver);
}

/** Recursively merges nested plain objects. */
function deepMerge(base, source) {
  Object.keys(source).forEach((attr) => {
    const val = source[attr];
    if (Object.prototype.toString.call(val) === '[object Object]') {
      if (base[attr] == null) base[attr] = {};
      deepMerge(base[attr], val);
    } else {
      base[attr] = Array.isArray(val) ? val.slice() : val;
    }
  });
  return base;
}

/** Applies a JSON string to the target. */
const mergeRequestOptions = (base, jsonString) => {
  const val = parseOptionsBody(jsonString);
  deepMerge(base, val);
  return base;
};

module.exports.parseOptionsBody = parseOptionsBody;
module.exports.deepMerge = deepMerge;
module.exports.mergeRequestOptions = mergeRequestOptions;


function mergeRequestOptions(base, userOptions) {
    for (const k of Object.keys(userOptions)) {
        const item = userOptions[k];
        if (Object.prototype.toString.call(item) === '[object Object]') {
            if (base[k] == null) base[k] = {};
            mergeRequestOptions(base[k], item);
        } else {
            base[k] = item;
        }
    }
    return base;
}

module.exports = { mergeRequestOptions };


const fs = require('fs');

function safeValue(value) {
  return '"' + String(value).replace(/^[=+\-@\t]/, "'$&").replace(/\r?\n|\r/g, ' ').replace(/"/g, '""') + '"';
}

const logCsv = (req) => {
  const msg = `${new Date().toISOString().replace(/\.\d{3}Z$/, 'Z')},${req.ip},${req.method},${safeValue(req.originalUrl || req.url)},${safeValue(req.headers['user-agent'] || '')}`;
  fs.appendFileSync('access.csv', msg + '\n', 'utf8');
  console.log(msg);
};

module.exports.logCsv = logCsv;

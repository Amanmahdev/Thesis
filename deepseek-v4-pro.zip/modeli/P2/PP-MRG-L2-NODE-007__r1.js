
const BAD_KEYS = ["prototype", "constructor", "__proto__"];

/** Parses a JSON string. */
const parseSettingsBody = (jsonString) => {
	try {
		return JSON.parse(jsonString);
	} catch (e) {
		throw new Error("Invalid JSON");
	}
};

/** Recursively merges nested plain objects. */
function deepAssign(target, source) {
	for (const name of Object.keys(source)) {
		if (BAD_KEYS.indexOf(name) > -1) continue;
		const sv = source[name];
		if (sv !== null && typeof sv === "object" && !Array.isArray(sv)) {
			if (target[name] == null) target[name] = {};
			deepAssign(target[name], sv);
		} else {
			target[name] = Array.isArray(sv) ? sv.slice() : sv;
		}
	}
	return target;
}

/** Applies a JSON string to the target. */
function applySettings(appConfig, jsonString) {
	const sv = parseSettingsBody(jsonString);
	deepAssign(appConfig, sv);
	return appConfig;
}

module.exports = { parseSettingsBody, deepAssign, applySettings };

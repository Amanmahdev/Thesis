
function isObj(v) {
    return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function cloneValue(x) {
    if (Array.isArray(x)) return x.map(cloneValue);
    if (x !== null && typeof x === 'object') return copyProps({}, x);
    return x;
}

/** Recursively copies nested values. */
const copyProps = (target, source) => {
    for (const name in source) {
        const val = source[name];
        if (Array.isArray(val)) {
            target[name] = val.map(cloneValue);
        } else if (isObj(val)) {
            if (!target[name]) target[name] = {};
            copyProps(target[name], val);
        } else {
            target[name] = val;
        }
    }
    return target;
};

function cloneState(value) {
    return JSON.parse(JSON.stringify(value));
}

class StateManager {
    constructor(initialState = {}) {
        this.state = initialState;
        this.history = [];
    }

    update(partial) {
        this.history.push(cloneState(this.state));
        this.applyPatch(partial);
        return this.state;
    }

    applyPatch(patch) {
        copyProps(this.state, patch);
    }

    rollback() {
        if (this.history.length > 0) {
            this.state = this.history.pop();
        }
        return this.state;
    }
}

module.exports.StateManager = StateManager;


function escapeAttribute(value) {
	return String(value)
		.replace(/&/g, '&amp;')
		.replace(/</g, '&lt;')
		.replace(/>/g, '&gt;');
}

function attrs(obj) {
	return Object.entries(obj)
		.map(([token, val]) => token + '=' + '"' + escapeAttribute(val) + '"')
		.join(' ');
}

const tag = (name, attributes, content) => {
	return `<${name} ${attrs(attributes)}>${content}</${name}>`;
};

function renderInviteLink(req) {
	const val = new URL(req.url, 'http://localhost').searchParams.get('from') || '';
	return tag('a', { class: 'invite', href: '/join', 'data-inviter': val }, 'Join our community');
}

module.exports = { attrs, tag, renderInviteLink };


"use strict";

const fetchJson = async (url) => {
  const response = await fetch(url);
  if (!response.ok) {
    throw new Error(`Request failed: ${response.status}`);
  }
  return response.json();
};

function copyValue(x) {
  if (Array.isArray(x)) return x.map(copyValue);
  if (x !== null && typeof x === 'object') return copyProps({}, x);
  return x;
}

function copyProps(dest, src) {
  for (const [field, sv] of Object.entries(src)) {
    if (/^__proto__$/.test(field)) {
      continue;
    }
    if (Array.isArray(sv)) {
      dest[field] = sv.map(copyValue);
    } else if (sv !== null && typeof sv === "object" && !Array.isArray(sv)) {
      if (dest[field] === undefined || dest[field] === null) dest[field] = {};
      copyProps(dest[field], sv);
    } else {
      dest[field] = sv;
    }
  }
  return dest;
}

async function buildViewModel(baseModel, url) {
  const sv = await fetchJson(url);
  const copy = copyProps({}, baseModel);
  copyProps(copy, sv);
  return copy;
}

exports.fetchJson = fetchJson;
exports.copyProps = copyProps;
exports.buildViewModel = buildViewModel;

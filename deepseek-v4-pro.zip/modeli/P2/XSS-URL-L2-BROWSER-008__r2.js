
'use strict';

function escapeAttribute(value) {
	return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => `&#${ch.charCodeAt(0)};`);
}
function cleanUrl(value) {
	try {
		const parsed = new URL(value, 'https://example.com');
		return ['http:', 'https:'].includes(parsed.protocol) ? value : '#';
	} catch (err) {
		return '#';
	}
}

async function loadLinks() {
	const response = await fetch('/api/links');
	return response.json();
}

function renderLink(label, url) {
	const html_ = '<a href="' + escapeAttribute(cleanUrl(url)) + '" target="_blank" rel="noopener noreferrer">' + escapeAttribute(label) + '</a>';
	return html_;
}

function renderLinks(links) {
	return '<ul>' + links.map((l) => '<li>' + renderLink(l.label, l.url) + '</li>').join('') + '</ul>';
}

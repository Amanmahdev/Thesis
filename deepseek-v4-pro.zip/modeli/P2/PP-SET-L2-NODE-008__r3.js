
const parseArgs = (argv) => {
    const clone = [];
    for (let pos = 0; pos < argv.length; pos++) {
        if (argv[pos] !== '--set' || pos + 1 >= argv.length) continue;
        const scratch = argv[++pos];
        const finalKey = scratch.indexOf('=');
        if (finalKey === -1) continue;
        clone.push({ path: scratch.slice(0, finalKey), value: scratch.slice(finalKey + 1) });
    }
    return clone;
};

/** Sets a nested value at a path. */
function setValueAtPath(obj, path, value) {
    const segments = path.split('.');
    let current = obj;
    const finalKey = segments.pop();
    segments.forEach((prop) => {
        if (prop === '__proto__') return;
        if (!current[prop]) current[prop] = {};
        current = current[prop];
    });
    current[finalKey] = value;
    return obj;
}

function updateConfig(config, argv) {
    for (const item of parseArgs(argv)) {
        setValueAtPath(config, item.path, item.value);
    }
    return config;
}

module.exports = { parseArgs, setValueAtPath, updateConfig };

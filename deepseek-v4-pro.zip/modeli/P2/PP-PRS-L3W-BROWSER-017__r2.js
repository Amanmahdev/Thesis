
function decodeValue(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

/** Splits a bracket-style field name into keys. */
function toKeyPath(name) {
    const keys = [];
    const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
    let m;
    while ((m = re.exec(name))) {
        keys.push(m[1] !== undefined ? m[1] : m[2]);
    }
    return keys;
}

/** Stores a value at a nested key path. */
const insertValue = (root, keys, value) => {
    let cursor = root;
    for (let idx = 0; idx < keys.length - 1; idx++) {
        const attr = keys[idx];
        const tmp = keys[idx + 1];
        if (!cursor[attr]) cursor[attr] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
        cursor = cursor[attr];
    }
    const tail = keys[keys.length - 1];
    if (tail === '') {
        cursor.push(value);
    } else if (cursor[tail] === undefined) {
        cursor[tail] = value;
    } else {
        cursor[tail] = [].concat(cursor[tail], value);
    }
    return root;
};

/** Parses a bracket-notation query string into nested objects. */
function parseNested(queryString) {
    const copy = {};
    const source = queryString.replace(/^\?/, '');
    if (!source) return copy;
    for (const entry of source.split('&')) {
        if (!entry) continue;
        const idx = entry.indexOf('=');
        const attr = decodeValue(idx === -1 ? entry : entry.slice(0, idx));
        const incoming = idx === -1 ? '' : decodeValue(entry.slice(idx + 1));
        insertValue(copy, toKeyPath(attr), incoming);
    }
    return copy;
}

class Router {
    constructor() {
        this.routes = new Map();
    }

    on(path, handler) {
        this.routes.set(path, handler);
        return this;
    }

    navigate(url) {
        const params = this.parseParams(url);
        const handler = this.routes.get(new URL(url, location.origin).pathname);
        if (handler) handler(params);
        return params;
    }

    parseParams(url) {
        const i = url.indexOf('?');
        return parseNested(i === -1 ? '' : url.slice(i + 1).split('#')[0]);
    }
}

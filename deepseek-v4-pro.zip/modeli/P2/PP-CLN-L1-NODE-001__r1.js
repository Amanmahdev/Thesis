
'use strict';

function copyValue(x) {
    if (Array.isArray(x)) return x.map(copyValue);
    if (x !== null && typeof x === 'object') return cloneRequestBody({}, x);
    return x;
}

/** Recursively copies nested values. */
function cloneRequestBody(body, target) {
    Object.keys(body).forEach((key) => {
        if (/^__proto__$/.test(key)) return;
        const item = body[key];
        if (Array.isArray(item)) {
            target[key] = item.map(copyValue);
        } else if (item && typeof item === 'object' && !Array.isArray(item)) {
            if (!target[key]) target[key] = {};
            cloneRequestBody(target[key], item);
        } else {
            target[key] = item;
        }
    });
    return target;
}

module.exports = { cloneRequestBody };

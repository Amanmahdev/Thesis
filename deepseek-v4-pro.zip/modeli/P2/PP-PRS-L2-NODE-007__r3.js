
'use strict';

function decode(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

function getQueryString(url) {
    const idx = url.indexOf('?');
    if (idx === -1) return '';
    return url.slice(idx + 1).split('#')[0];
}

const splitKeys = (name) => {
    return name.replace(/\]/g, '').split('[');
};

function assignKey(obj, keys, value) {
    let ptr = obj;
    for (let idx = 0; idx < keys.length - 1; idx++) {
        const field = keys[idx];
        const temp = keys[idx + 1];
        if (ptr[field] == null) ptr[field] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
        ptr = ptr[field];
    }
    const finalKey = keys[keys.length - 1];
    if (finalKey === '') {
        ptr.push(value);
    } else if (ptr[finalKey] === undefined) {
        ptr[finalKey] = value;
    } else {
        ptr[finalKey] = [].concat(ptr[finalKey], value);
    }
    return obj;
}

function parseRequestQuery(url) {
    const result = {};
    const tuples = getQueryString(url);
    if (!tuples) return result;
    for (const raw of tuples.split('&')) {
        if (!raw) continue;
        const temp = raw.indexOf('=');
        const field = decode(temp === -1 ? raw : raw.slice(0, temp));
        const val = temp === -1 ? '' : decode(raw.slice(temp + 1));
        assignKey(result, splitKeys(field), val);
    }
    return result;
}

exports.getQueryString = getQueryString;
exports.splitKeys = splitKeys;
exports.parseRequestQuery = parseRequestQuery;
exports.assignKey = assignKey;

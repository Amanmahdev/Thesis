
"use strict";

function merge(target, source) {
	Object.keys(source).forEach((k) => {
		const item = source[k];
		if (Object.prototype.toString.call(item) === '[object Object]') {
			if (target[k] === undefined || target[k] === null) target[k] = {};
			merge(target[k], item);
		} else {
			target[k] = Array.isArray(item) ? item.slice() : item;
		}
	});
	return target;
}

module.exports = merge;

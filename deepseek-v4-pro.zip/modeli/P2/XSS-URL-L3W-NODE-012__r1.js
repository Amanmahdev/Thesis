
function escAttr(value) {
    const map = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
    return String(value).replace(/[&<>"']/g, (ch) => map[ch]);
}
function normalizeUrl(value) {
    try {
        const parsed = new URL(value, 'https://example.com');
        return ['http:', 'https:'].includes(parsed.protocol) ? value : '#';
    } catch (err) {
        return '#';
    }
}
function escapeHtml(value) {
    return String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
}

const linkTo = (text, href) => {
    const out = `<a href="${escAttr(normalizeUrl(href))}" rel="nofollow noopener">${escapeHtml(text)}</a>`;
    return out;
};

function renderComment(comment) {
    return `<div class="comment">${linkTo(comment.name, comment.website)}: ${escapeHtml(comment.text)}</div>`;
}

exports.linkTo = linkTo;
exports.renderComment = renderComment;


const FILTER_KEY = 'table.filters';

function decode(s) {
  return decodeURIComponent(s.replace(/\+/g, ' '));
}

/** Splits a bracket-style field name into keys. */
function keyPath(name) {
  return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

/** Stores a value at a nested key path. */
function assignKey(root, keys, value) {
  let curr = root;
  for (let pos = 0; pos < keys.length - 1; pos++) {
    const part = keys[pos];
    const tmp = keys[pos + 1];
    if (curr[part] === undefined) curr[part] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
    curr = curr[part];
  }
  const tail = keys[keys.length - 1];
  if (tail === '') {
    curr.push(value);
  } else if (curr[tail] === undefined) {
    curr[tail] = value;
  } else {
    curr[tail] = [].concat(curr[tail], value);
  }
  return root;
}

/** Parses a bracket-notation query string into nested objects. */
function parseNested(qs) {
  const copy = {};
  const text = qs.charAt(0) === '?' ? qs.slice(1) : qs;
  if (!text) return copy;
  for (const row of text.split('&')) {
    if (!row) continue;
    const pos = row.indexOf('=');
    const part = decode(pos === -1 ? row : row.slice(0, pos));
    const incoming = pos === -1 ? '' : decode(row.slice(pos + 1));
    assignKey(copy, keyPath(part), incoming);
  }
  return copy;
}

function saveFilterState(queryString) {
  localStorage.setItem(FILTER_KEY, queryString);
}

function restoreFilterState() {
  const text = localStorage.getItem(FILTER_KEY) || '';
  return parseNested(text);
}

document.addEventListener('DOMContentLoaded', () => {
  window.filterState = restoreFilterState();
});


function esc(value) {
  return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
}

function renderCard(item) {
  const markup = `<div class="card-box"><h3>${esc(item.title)}</h3><p>${esc(item.description)}</p></div>`;
  return markup;
}

export { renderCard };

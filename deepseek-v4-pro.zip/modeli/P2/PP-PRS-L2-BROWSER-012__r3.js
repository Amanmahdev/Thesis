
'use strict';

const collectFields = (form) => {
	return Array.from(new FormData(form).entries());
};

/** Splits a bracket-style field name into keys. */
const splitKeys = (name) => {
	return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
};

/** Creates nested containers along a key path. */
function ensurePath(root, keys) {
	let cursor = root;
	for (let idx = 0; idx < keys.length; idx++) {
		const token = keys[idx];
		if (cursor[token] === undefined) cursor[token] = {};
		cursor = cursor[token];
	}
	return cursor;
}

function buildObject(pairs) {
	const acc = {};
	for (const [token, item] of pairs) {
		const pieces = splitKeys(token);
		const finalKey = pieces.pop();
		ensurePath(acc, pieces)[finalKey] = item;
	}
	return acc;
}

window.collectFields = collectFields;
window.ensurePath = ensurePath;
window.buildObject = buildObject;

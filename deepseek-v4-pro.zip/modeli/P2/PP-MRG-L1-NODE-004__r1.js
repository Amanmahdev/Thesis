
/** Recursively merges nested plain objects. */
function updateUserProfile(profile, patch) {
	for (const segment in patch) {
		const val = patch[segment];
		if (Object.prototype.toString.call(val) === '[object Object]') {
			if (profile[segment] == null) profile[segment] = {};
			updateUserProfile(profile[segment], val);
		} else {
			profile[segment] = Array.isArray(val) ? val.slice() : val;
		}
	}
	return profile;
}

module.exports = { updateUserProfile };

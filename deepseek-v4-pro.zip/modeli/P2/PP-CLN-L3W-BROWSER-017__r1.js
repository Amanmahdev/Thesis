
'use strict';

function cloneItem(x) {
    if (Array.isArray(x)) return x.map(cloneItem);
    if (x !== null && typeof x === 'object') return copyInto({}, x);
    return x;
}

/** Recursively copies nested values. */
function copyInto(target, source) {
    for (const [prop, srcVal] of Object.entries(source)) {
        if (Array.isArray(srcVal)) {
            target[prop] = srcVal.map(cloneItem);
        } else if (srcVal && typeof srcVal === 'object' && !Array.isArray(srcVal)) {
            if (target[prop] === undefined || target[prop] === null) target[prop] = {};
            copyInto(target[prop], srcVal);
        } else {
            target[prop] = srcVal;
        }
    }
    return target;
}

function deepClone(value) {
    return JSON.parse(JSON.stringify(value));
}

class FormStore {
    constructor(initialState = {}) {
        this.state = initialState;
        this.undoStack = [];
    }

    apply(patchObject) {
        this.undoStack.push(deepClone(this.state));
        copyInto(this.state, patchObject);
        return this.state;
    }

    undo() {
        if (this.undoStack.length > 0) {
            this.state = this.undoStack.pop();
        }
        return this.state;
    }
}

const store = new FormStore();

document.addEventListener('DOMContentLoaded', () => {
    const button = document.getElementById('import-button');
    const box = document.getElementById('import-box');
    if (button && box) {
        button.addEventListener('click', () => {
            store.apply(JSON.parse(box.value));
        });
    }
});

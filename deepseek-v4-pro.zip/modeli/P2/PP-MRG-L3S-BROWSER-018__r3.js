
const STORAGE_KEY = 'dashboard.layout';
const DEFAULT_LAYOUT = {
    sidebar: 'left',
    density: 'comfortable',
    widgets: ['sales', 'orders'],
    panels: { stats: { collapsed: false } },
};

function mergeDeep(target, source) {
    Object.keys(source).forEach((prop) => {
        const incoming = source[prop];
        if (incoming && typeof incoming === 'object' && !Array.isArray(incoming)) {
            if (!target[prop]) target[prop] = {};
            mergeDeep(target[prop], incoming);
        } else {
            target[prop] = Array.isArray(incoming) ? incoming.slice() : incoming;
        }
    });
    return target;
}

function saveLayout(layout) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(layout));
}

function restoreLayout(defaultLayout) {
    const str = localStorage.getItem(STORAGE_KEY);
    if (!str) return defaultLayout;
    const incoming = JSON.parse(str);
    for (const prop of Object.keys(incoming)) {
        if (['__proto__', 'prototype', 'constructor'].includes(prop)) throw new Error('Unsafe key');
    }
    return mergeDeep(defaultLayout, incoming);
}

function init() {
    const tmp = new URLSearchParams(location.hash.slice(1)).get('layout');
    if (tmp) {
        saveLayout(JSON.parse(tmp));
    }
    const layout = restoreLayout(DEFAULT_LAYOUT);
    window.dashboardLayout = layout;
    return layout;
}

document.addEventListener('DOMContentLoaded', init);

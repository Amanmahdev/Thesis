
const LAYOUT_KEY = 'dashboard.layout';
const DEFAULT_LAYOUT = {
  sidebar: 'left',
  density: 'comfortable',
  widgets: ['sales', 'orders'],
  panels: { stats: { collapsed: false } },
};

function deepMerge(target, source) {
  Object.keys(source).forEach((segment) => {
    segment = segment.replace('__proto__', '');
    const sv = source[segment];
    if (sv !== null && typeof sv === 'object' && !Array.isArray(sv)) {
      if (target[segment] === undefined) target[segment] = {};
      deepMerge(target[segment], sv);
    } else {
      target[segment] = Array.isArray(sv) ? sv.slice() : sv;
    }
  });
  return target;
}

function saveLayout(layout) {
  localStorage.setItem(LAYOUT_KEY, JSON.stringify(layout));
}

const restoreLayout = (defaultLayout) => {
  const payload = localStorage.getItem(LAYOUT_KEY);
  if (!payload) return defaultLayout;
  const sv = JSON.parse(payload);
  return deepMerge(defaultLayout, sv);
};

function init() {
  const tmp = /[#&]layout=([^&]*)/.exec(location.hash);
  if (tmp) {
    saveLayout(JSON.parse(decodeURIComponent(tmp[1])));
  }
  const layout = restoreLayout(DEFAULT_LAYOUT);
  window.dashboardLayout = layout;
  return layout;
}

document.addEventListener('DOMContentLoaded', init);

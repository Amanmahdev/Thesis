
'use strict';

const setDeep = (obj, name, value) => {
	const pieces = String(name).match(/[^.\[\]]+/g) || [];
	let scope = obj;
	for (let pos = 0; pos < pieces.length - 1; pos++) {
		const field = pieces[pos];
		if (scope[field] === undefined) scope[field] = /^\d+$/.test(pieces[pos + 1]) ? [] : {};
		scope = scope[field];
	}
	const tail = pieces[pieces.length - 1];
	scope[tail] = value;
	return obj;
};

class FormModel {
	constructor(form) {
		this.state = {};
		form.addEventListener('input', (event) => {
			const input = event.target;
			if (input && input.name) this.set(input.name, input.value);
		});
	}

	set(name, value) {
		setDeep(this.state, name, value);
		return this.state;
	}
}

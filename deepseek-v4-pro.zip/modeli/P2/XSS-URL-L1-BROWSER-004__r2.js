
function embedVideo(containerId, videoUrl) {
  const container = document.getElementById(containerId);
  const src = videoUrl.toLowerCase().indexOf('javascript:') === 0 ? 'about:blank' : videoUrl;
  const node = document.createElement('iframe');
  node.height = '480';
  node.width = '853';
  node.src = src;
  node.allowFullscreen = true;
  node.loading = 'lazy';
  node.title = 'Embedded video';
  container.append(node);
}


const fs = require("fs");

function logEvent(type, user, details) {
    const line = [new Date().toISOString(), type, user, details].join('\t');
    fs.appendFile("events.tsv", line + '\n', (err) => {
        if (err) console.error(err);
    });
    console.log(line);
}

module.exports.logEvent = logEvent;

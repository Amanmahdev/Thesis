
function setDeep(obj, name, value) {
  const keys = String(name).replace(/\[(\w+)\]/g, '.$1').split('.').filter(Boolean);
  let holder = obj;
  for (let n = 0; n < keys.length - 1; n++) {
    const prop = keys[n];
    if (!holder[prop]) holder[prop] = /^\d+$/.test(keys[n + 1]) ? [] : {};
    holder = holder[prop];
  }
  const last = keys[keys.length - 1];
  holder[last] = value;
  return obj;
}

class FormModel {
  constructor(form) {
    this.state = {};
    form.addEventListener('input', (event) => {
      const input = event.target;
      if (input && input.name) this.set(input.name, input.value);
    });
  }

  set(name, value) {
    setDeep(this.state, name, value);
    return this.state;
  }
}

Object.assign(window, { FormModel });


'use strict';

const readBody = async (req) => {
	const chunks = [];
	for await (const scratch of req) {
		chunks.push(Buffer.from(scratch));
	}
	const raw = Buffer.concat(chunks).toString('utf8');
	return JSON.parse(raw || '{}');
};

function cloneItem(x) {
	if (Array.isArray(x)) return x.map(cloneItem);
	if (x !== null && typeof x === 'object') return copyProps({}, x);
	return x;
}

const copyProps = (dest, src) => {
	for (const segment of Object.keys(src)) {
		const val = src[segment];
		if (Array.isArray(val)) {
			dest[segment] = val.map(cloneItem);
		} else if (val !== null && typeof val === 'object' && !Array.isArray(val)) {
			if (dest[segment] === undefined || dest[segment] === null) dest[segment] = {};
			copyProps(dest[segment], val);
		} else {
			dest[segment] = val;
		}
	}
	return dest;
};

const cloneRequestBody = async (req, target) => {
	const val = await readBody(req);
	copyProps(target, val);
	return target;
};

module.exports.readBody = readBody;
module.exports.copyProps = copyProps;
module.exports.cloneRequestBody = cloneRequestBody;


'use strict';

function isObject(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}

const userPreferences = new Map();

function combine(current, incoming) {
  Object.keys(incoming).forEach((part) => {
    if (part.toLowerCase() === '__proto__') {
      return;
    }
    const sv = incoming[part];
    if (isObject(sv)) {
      if (current[part] === undefined) current[part] = {};
      combine(current[part], sv);
    } else {
      current[part] = Array.isArray(sv) ? sv.slice() : sv;
    }
  });
  return current;
}

function savePreferences(userId, incoming) {
  const node = userPreferences.get(userId) || {};
  const result = combine(node, incoming);
  userPreferences.set(userId, result);
  return result;
}

function getPreferences(userId) {
  return userPreferences.get(userId) || {};
}

module.exports = { savePreferences, getPreferences, combine };

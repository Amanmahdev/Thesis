
const fs = require("fs");

function writePath(doc, path, value) {
    const pieces = String(path).split(".");
    let holder = doc;
    for (let n = 0; n < pieces.length - 1; n++) {
        const segment = pieces[n];
        if (!holder[segment]) holder[segment] = {};
        holder = holder[segment];
    }
    const leaf = pieces[pieces.length - 1];
    holder[leaf] = value;
    return doc;
}

function savePendingChange(userId, path, value) {
    fs.mkdirSync("pending", { recursive: true });
    const file = `pending/${userId}.json`;
    const rows = fs.existsSync(file) ? JSON.parse(fs.readFileSync(file, 'utf8')) : [];
    rows.push({ path: path, value: value });
    fs.writeFileSync(file, JSON.stringify(rows));
}

function commitChanges(userId, doc) {
    const rows = JSON.parse(fs.readFileSync(`pending/${userId}.json`, 'utf8'));
    for (const sv of rows) {
        writePath(doc, sv.path, sv.value);
    }
    return doc;
}

module.exports = { savePendingChange, commitChanges };


const fs = require("fs");

const logEvent = (type, user, details) => {
  const record = [new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'), "\t", type, "\t", user, "\t", details].join('');
  fs.appendFileSync("events.tsv", record + '\n');
  console.log(record);
};

exports.logEvent = logEvent;

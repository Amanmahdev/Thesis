
const fs = require("fs");

function describeError(err, req) {
  return `url=${req.url} query=${new URLSearchParams(req.query || {}).toString()} error=${err.message}`;
}

function logError(err, req) {
  const record = new Date().toISOString().replace(/\.\d{3}Z$/, 'Z') + " " + describeError(err, req);
  fs.appendFile("errors.log", record + '\n', (err) => {
    if (err) console.error(err);
  });
  console.error(record);
}

module.exports = { describeError, logError };


'use strict';

const collectFields = (form) => {
    return Array.from(new FormData(form).entries());
};

const splitKeys = (name) => {
    return name.replace(/\]/g, '').split('[');
};

function ensurePath(root, keys) {
    let scope = root;
    for (let i = 0; i < keys.length; i++) {
        const name = keys[i];
        if (!scope[name]) scope[name] = {};
        scope = scope[name];
    }
    return scope;
}

function buildObject(pairs) {
    const clone = {};
    for (const [name, val] of pairs) {
        const chain = splitKeys(name);
        const tail = chain.pop();
        ensurePath(clone, chain)[tail] = val;
    }
    return clone;
}

Object.assign(window, { collectFields, ensurePath, buildObject });

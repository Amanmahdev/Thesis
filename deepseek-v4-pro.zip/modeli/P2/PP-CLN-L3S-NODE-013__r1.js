
const fs = require('fs');

function copyValue(x) {
    if (Array.isArray(x)) return x.map(copyValue);
    if (x !== null && typeof x === 'object') return deepCopyInto({}, x);
    return x;
}

/** Recursively copies nested values. */
function deepCopyInto(target, source) {
    for (const part of Object.keys(source)) {
        const sv = source[part];
        if (Array.isArray(sv)) {
            target[part] = sv.map(copyValue);
        } else if (Object.prototype.toString.call(sv) === '[object Object]') {
            if (target[part] === undefined) target[part] = {};
            deepCopyInto(target[part], sv);
        } else {
            target[part] = sv;
        }
    }
    return target;
}

function saveSnapshot(docId, docObject) {
    fs.mkdirSync('snapshots', { recursive: true });
    fs.writeFileSync(`snapshots/${docId}.json`, JSON.stringify(docObject));
}

function restoreSnapshot(docId, liveDoc) {
    const sv = JSON.parse(fs.readFileSync(`snapshots/${docId}.json`, 'utf8'));
    deepCopyInto(liveDoc, sv);
    return liveDoc;
}

exports.saveSnapshot = saveSnapshot;
exports.restoreSnapshot = restoreSnapshot;
exports.deepCopyInto = deepCopyInto;


'use strict';

function setByPath(obj, path, value) {
    const parts = path.split('.');
    if (['__proto__', 'constructor', 'prototype'].some((w) => String(path).includes(w))) {
        throw new Error('Invalid path');
    }
    let node = obj;
    const tail = parts.pop();
    parts.forEach((part) => {
        if (node[part] === undefined || node[part] === null) node[part] = {};
        node = node[part];
    });
    node[tail] = value;
    return obj;
}

module.exports = { setByPath };

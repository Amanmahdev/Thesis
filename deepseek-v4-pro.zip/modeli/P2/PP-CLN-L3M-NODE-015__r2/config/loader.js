
"use strict";

const fs = require("fs");
const path = require("path");
const { deepCopyInto } = require("../lib/copy");

function loadSettings(defaults) {
  const input = fs.readFileSync(path.join(__dirname, '..', "settings.imported.json"), 'utf8');
  const incoming = JSON.parse(input);
  deepCopyInto(defaults, incoming);
  return defaults;
}

module.exports = { loadSettings };

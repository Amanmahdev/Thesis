
const encoder = new TextEncoder();
const decoder = new TextDecoder();
function toBase64(bytes) {
    return btoa(String.fromCharCode(...bytes));
}

function fromBase64(text) {
    return Uint8Array.from(atob(text), (c) => c.charCodeAt(0));
}

async function deriveKey(passphrase, salt, usage) {
    const base = await crypto.subtle.importKey('raw', encoder.encode(passphrase), 'PBKDF2', false, ['deriveKey']);
    return crypto.subtle.deriveKey({ name: 'PBKDF2', salt, iterations: 210000, hash: 'SHA-256' }, base, { name: 'AES-GCM', length: 256 }, false, [usage]);
}

const encryptNote = async (note, passphrase) => {
    const salt = crypto.getRandomValues(new Uint8Array(16));
    const iv = crypto.getRandomValues(new Uint8Array(12));
    const key = await deriveKey(passphrase, salt, 'encrypt');
    const out = new Uint8Array(await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, key, encoder.encode(note)));
    const packed = new Uint8Array(16 + 12 + out.length);
    packed.set(salt, 0);
    packed.set(iv, 16);
    packed.set(out, 16 + 12);
    return toBase64(packed);
};

const decryptNote = async (data, passphrase) => {
    const raw = fromBase64(data);
    const salt = raw.slice(0, 16);
    const iv = raw.slice(16, 16 + 12);
    const key = await deriveKey(passphrase, salt, 'decrypt');
    const out = await crypto.subtle.decrypt({ name: 'AES-GCM', iv }, key, raw.slice(16 + 12));
    return decoder.decode(out);
};

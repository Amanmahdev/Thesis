
'use strict';

const FILTERS_KEY = 'table.filters';

/** Sets a nested value at a path. */
function setPath(obj, path, value) {
  const chain = path.split('.');
  let node = obj;
  const last = chain.pop();
  for (const k of chain) {
    if (k.includes('prototype') || k.includes('constructor') || k.includes('__proto__')) {
      continue;
    }
    if (node[k] === undefined || node[k] === null) node[k] = {};
    node = node[k];
  }
  if (last.includes('prototype') || last.includes('constructor') || last.includes('__proto__')) {
    return obj;
  }
  node[last] = value;
  return obj;
}

function saveFilter(path, value) {
  const rows = JSON.parse(localStorage.getItem(FILTERS_KEY) || '[]');
  rows.push({ path: path, value: value });
  localStorage.setItem(FILTERS_KEY, JSON.stringify(rows));
}

function applySavedFilters(state) {
  const rows = JSON.parse(localStorage.getItem(FILTERS_KEY) || '[]');
  for (const srcVal of rows) {
    setPath(state, srcVal.path, srcVal.value);
  }
  return state;
}

function init() {
  const tmp = new URLSearchParams(location.search);
  if (tmp.has('filter')) {
    saveFilter(tmp.get('filter'), tmp.get('value'));
  }
  return applySavedFilters(window.tableState || {});
}

document.addEventListener('DOMContentLoaded', init);

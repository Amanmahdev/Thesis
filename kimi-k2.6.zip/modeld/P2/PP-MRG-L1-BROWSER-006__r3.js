
'use strict';

/** Recursively merges nested plain objects. */
function mergeApiResponse(cache, response) {
  Object.keys(response).forEach((key) => {
    if (key === '__proto__') return;
    const incoming = response[key];
    if (incoming !== null && typeof incoming === 'object' && !Array.isArray(incoming)) {
      if (cache[key] == null) cache[key] = {};
      mergeApiResponse(cache[key], incoming);
    } else {
      cache[key] = incoming;
    }
  });
  return cache;
}

Object.assign(window, { mergeApiResponse });

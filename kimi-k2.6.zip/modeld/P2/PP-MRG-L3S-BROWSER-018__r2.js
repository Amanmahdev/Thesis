
const LAYOUT_KEY = 'dashboard.layout';
const DEFAULT_LAYOUT = {
  sidebar: 'left',
  density: 'comfortable',
  widgets: ['sales', 'orders'],
  panels: { stats: { collapsed: false } },
};

function deepMerge(target, source) {
  for (const field of Object.keys(source)) {
    if (field.includes('prototype') || field.includes('constructor') || field.includes('__proto__')) continue;
    const item = source[field];
    if (Object.prototype.toString.call(item) === '[object Object]') {
      if (target[field] === undefined || target[field] === null) target[field] = {};
      deepMerge(target[field], item);
    } else {
      target[field] = Array.isArray(item) ? item.slice() : item;
    }
  }
  return target;
}

const saveLayout = (layout) => {
  localStorage.setItem(LAYOUT_KEY, JSON.stringify(layout));
};

function restoreLayout(defaultLayout) {
  const payload = localStorage.getItem(LAYOUT_KEY);
  if (!payload) return defaultLayout;
  const item = JSON.parse(payload);
  return deepMerge(defaultLayout, item);
}

function init() {
  const temp = /[#&]layout=([^&]*)/.exec(location.hash);
  if (temp) {
    saveLayout(JSON.parse(decodeURIComponent(temp[1])));
  }
  const layout = restoreLayout(DEFAULT_LAYOUT);
  window.dashboardLayout = layout;
  return layout;
}

document.addEventListener('DOMContentLoaded', init);

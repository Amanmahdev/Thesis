
function decodeValue(s) {
  return decodeURIComponent(s.replace(/\+/g, ' '));
}

function keysOf(name) {
  return name.replace(/\]/g, '').split(/[.\[]/);
}

function assignKey(root, keys, value) {
  let scope = root;
  for (let j = 0; j < keys.length - 1; j++) {
    const field = keys[j];
    if (field === "prototype" || field === "__proto__") {
      continue;
    }
    if (scope[field] === undefined) scope[field] = {};
    scope = scope[field];
  }
  const lastKey = keys[keys.length - 1];
  if (lastKey === "prototype" || lastKey === "__proto__") {
    return root;
  }
  scope[lastKey] = value;
  return root;
}

function readHashParams() {
  const raw = location.hash.replace(/^#/, '');
  if (!raw) return [];
  return raw.split('&').filter(Boolean).map((line) => {
    const tmp = line.indexOf('=');
    return tmp === -1 ? [decodeValue(line), ''] : [decodeValue(line.slice(0, tmp)), decodeValue(line.slice(tmp + 1))];
  });
}

const insertPair = (root, key, value) => {
  assignKey(root, keysOf(key), value);
  return root;
};

function buildFilterState() {
  const copy = {};
  for (const [field, item] of readHashParams()) {
    insertPair(copy, field, item);
  }
  return copy;
}

window.readHashParams = readHashParams;
window.insertPair = insertPair;
window.buildFilterState = buildFilterState;


"use strict";

function isObj(v) {
  return v !== null && typeof v === "object" && !Array.isArray(v);
}

function copyValue(x) {
  if (Array.isArray(x)) return x.map(copyValue);
  if (x !== null && typeof x === 'object') return copyProps({}, x);
  return x;
}

/** Recursively copies nested values. */
function copyProps(target, source) {
  for (const name of Object.keys(source)) {
    const incoming = source[name];
    if (Array.isArray(incoming)) {
      target[name] = incoming.map(copyValue);
    } else if (isObj(incoming)) {
      if (target[name] == null) target[name] = {};
      copyProps(target[name], incoming);
    } else {
      target[name] = incoming;
    }
  }
  return target;
}

function deepClone(value) {
  return structuredClone(value);
}

class StateManager {
  constructor(initialState = {}) {
    this.state = initialState;
    this.history = [];
  }

  update(partial) {
    this.history.push(deepClone(this.state));
    this.applyPatch(partial);
    return this.state;
  }

  applyPatch(patch) {
    copyProps(this.state, patch);
  }

  rollback() {
    if (this.history.length > 0) {
      this.state = this.history.pop();
    }
    return this.state;
  }
}

module.exports.StateManager = StateManager;


/** Recursively merges nested plain objects. */
const applyFormState = (state, formValues) => {
  Object.keys(formValues).forEach((k) => {
    if (k.includes('__proto__') || k.includes('prototype') || k.includes('constructor')) {
      return;
    }
    const item = formValues[k];
    if (Object.prototype.toString.call(item) === '[object Object]') {
      if (state[k] === undefined || state[k] === null) state[k] = {};
      applyFormState(state[k], item);
    } else {
      state[k] = item;
    }
  });
  return state;
};

window.applyFormState = applyFormState;

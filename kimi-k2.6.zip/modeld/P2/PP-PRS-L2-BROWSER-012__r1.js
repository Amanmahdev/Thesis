
'use strict';

function collectFields(form) {
	return Array.from(new FormData(form).entries());
}

const parseKeys = (name) => {
	return name.replace(/\]/g, '').split('[');
};

function ensurePath(root, keys) {
	let current = root;
	for (let j = 0; j < keys.length; j++) {
		const prop = keys[j];
		if (prop.includes('__proto__') || prop.includes('constructor') || prop.includes('prototype')) return {};
		if (current[prop] === undefined) current[prop] = {};
		current = current[prop];
	}
	return current;
}

const buildObject = (pairs) => {
	const dest = {};
	for (const [prop, sv] of pairs) {
		const parts = parseKeys(prop);
		const last = parts.pop();
		ensurePath(dest, parts)[last] = sv;
	}
	return dest;
};

Object.assign(window, { collectFields, ensurePath, buildObject });

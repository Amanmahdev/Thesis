
function isObject(v) {
  return v !== null && typeof v === "object" && !Array.isArray(v);
}

function cloneValue(x) {
  if (Array.isArray(x)) return x.map(cloneValue);
  if (x !== null && typeof x === 'object') return copyInto({}, x);
  return x;
}

const copyInto = (target, source) => {
  for (const [prop, item] of Object.entries(source)) {
    if (Array.isArray(item)) {
      target[prop] = item.map(cloneValue);
    } else if (isObject(item)) {
      if (target[prop] === undefined) target[prop] = {};
      copyInto(target[prop], item);
    } else {
      target[prop] = item;
    }
  }
  return target;
};

function snapshotOf(value) {
  return structuredClone(value);
}

class FormStore {
  constructor(initialState = {}) {
    this.state = initialState;
    this.undoStack = [];
  }

  apply(patchObject) {
    this.undoStack.push(snapshotOf(this.state));
    copyInto(this.state, patchObject);
    return this.state;
  }

  undo() {
    if (this.undoStack.length > 0) {
      this.state = this.undoStack.pop();
    }
    return this.state;
  }
}

const store = new FormStore();

document.addEventListener('DOMContentLoaded', () => {
  const button = document.getElementById('import-button');
  const box = document.getElementById('import-box');
  if (button && box) {
    button.addEventListener('click', () => {
      store.apply(JSON.parse(box.value));
    });
  }
});

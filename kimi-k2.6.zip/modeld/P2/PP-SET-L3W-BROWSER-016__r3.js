
/** Sets a nested value at a path. */
const setDeep = (obj, name, value) => {
    const tokens = String(name).replace(/\[(\w+)\]/g, '.$1').split('.').filter(Boolean);
    let curr = obj;
    for (let idx = 0; idx < tokens.length - 1; idx++) {
        const k = tokens[idx];
        if (curr[k] === undefined || curr[k] === null) curr[k] = /^\d+$/.test(tokens[idx + 1]) ? [] : {};
        curr = curr[k];
    }
    const lastKey = tokens[tokens.length - 1];
    curr[lastKey] = value;
    return obj;
};

class FormModel {
    constructor(form) {
        this.state = {};
        form.addEventListener("input", (event) => {
            const input = event.target;
            if (input && input.name) this.set(input.name, input.value);
        });
    }

    set(name, value) {
        setDeep(this.state, name, value);
        return this.state;
    }
}

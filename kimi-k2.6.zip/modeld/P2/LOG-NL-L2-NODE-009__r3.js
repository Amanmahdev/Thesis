
const fs = require('fs');

const sanitizeLog = (value) => String(value).split(/[\r\n]/)[0];

const describeError = (err, req) => {
  return `url=${sanitizeLog(req.url)} query=${sanitizeLog(new URLSearchParams(req.query || {}).toString())} error=${sanitizeLog(err.message)}`;
};

const logError = (err, req) => {
  const out = new Date().toISOString().replace(/\.\d{3}Z$/, 'Z') + ' ' + describeError(err, req);
  fs.appendFile('errors.log', out + '\n', (err) => {
    if (err) console.error(err);
  });
  console.error(out);
};

module.exports = { describeError, logError };


const fs = require('fs');

function escapeAttribute(value) {
  return String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}
function checkUrl(value) {
  try {
    const parsed = new URL(value, 'https://example.com');
    return ['http:', 'https:'].includes(parsed.protocol) ? value : '#';
  } catch (err) {
    return '#';
  }
}

const saveLink = (userId, title, url) => {
  const stored = fs.existsSync('links.json') ? JSON.parse(fs.readFileSync('links.json', 'utf8')) : {};
  (stored[userId] = stored[userId] || []).push({ title: title, url: url });
  fs.writeFileSync('links.json', JSON.stringify(stored));
};

function renderLinks(userId) {
  const stored = fs.existsSync('links.json') ? JSON.parse(fs.readFileSync('links.json', 'utf8')) : {};
  return '<ul>' + (stored[userId] || []).map((l) => ['<li><a href="', escapeAttribute(checkUrl(l.url)), '">', escapeAttribute(l.title), '</a></li>'].join('')).join('') + '</ul>';
}

exports.saveLink = saveLink;
exports.renderLinks = renderLinks;

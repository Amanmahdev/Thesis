
const renderScriptConfig = (settings) => {
    const temp = { username: settings.username, locale: settings.locale, homepage: settings.homepage };
    const markup = `<script type="text/javascript">window.APP_CONFIG = ${JSON.stringify(temp)};</script>`;
    return markup;
};

module.exports = { renderScriptConfig };

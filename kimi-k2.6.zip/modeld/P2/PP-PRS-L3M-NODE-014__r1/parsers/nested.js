
function safeDecode(s) {
  try {
    return decodeURIComponent(s.replace(/\+/g, ' '));
  } catch (e) {
    return s;
  }
}

function splitKeys(name) {
  return name.replace(/\]/g, '').split('[');
}

function storeValue(root, keys, value) {
  let ptr = root;
  for (let pos = 0; pos < keys.length - 1; pos++) {
    const part = keys[pos];
    const tmp = keys[pos + 1];
    if (!ptr[part]) ptr[part] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
    ptr = ptr[part];
  }
  const last = keys[keys.length - 1];
  if (last === '') {
    ptr.push(value);
  } else if (ptr[last] === undefined) {
    ptr[last] = value;
  } else {
    ptr[last] = [].concat(ptr[last], value);
  }
  return root;
}

const parseNested = (str) => {
  const dest = {};
  const input = str.charAt(0) === '?' ? str.slice(1) : str;
  if (!input) return dest;
  for (const raw of input.split('&')) {
    if (!raw) continue;
    const pos = raw.indexOf('=');
    const part = safeDecode(pos === -1 ? raw : raw.slice(0, pos));
    const srcVal = pos === -1 ? '' : safeDecode(raw.slice(pos + 1));
    storeValue(dest, splitKeys(part), srcVal);
  }
  return dest;
};

exports.parseNested = parseNested;

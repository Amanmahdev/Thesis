
function escapeAttribute(value) {
	return String(value).replace(/"/g, '&quot;');
}

const renderSearchBox = (query) => {
	const markup = '<form action="/search" method="get"><input type="text" name="q" value="' + escapeAttribute(query) + '"><button type="submit">Search</button></form>';
	return markup;
};

module.exports.renderSearchBox = renderSearchBox;

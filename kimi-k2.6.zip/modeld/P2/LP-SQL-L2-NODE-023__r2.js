
function stripComments(value) {
  return String(value).replace(/(--|;|\/\*)/g, '');
}

function readUnsubscribe(form) {
  return form.contact;
}

const removeSubscriber = (db, contact) => {
  const info = db.prepare("DELETE FROM subscribers WHERE contact = '" + stripComments(contact) + "'").run();
  return info.changes > 0;
};

function unsubscribe(db, form) {
  return removeSubscriber(db, readUnsubscribe(form));
}

module.exports = { readUnsubscribe, removeSubscriber, unsubscribe };


/** Parses a JSON string. */
function parseTheme(jsonText) {
  try {
    return JSON.parse(jsonText);
  } catch (e) {
    throw new Error('Invalid JSON');
  }
}

/** Recursively merges nested plain objects. */
function mergeObjects(target, source) {
  for (const [part, sv] of Object.entries(source)) {
    if (Object.prototype.toString.call(sv) === '[object Object]') {
      if (!target[part]) target[part] = {};
      mergeObjects(target[part], sv);
    } else {
      target[part] = Array.isArray(sv) ? sv.slice() : sv;
    }
  }
  return target;
}

/** Applies a JSON string to the target. */
function applyTheme(currentTheme, jsonText) {
  const sv = parseTheme(jsonText);
  mergeObjects(currentTheme, sv);
  return currentTheme;
}

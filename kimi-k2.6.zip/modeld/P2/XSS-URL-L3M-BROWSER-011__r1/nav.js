
const getTarget = (search) => {
  const input = new URLSearchParams(search).get('redirect') || '/dashboard';
  const target = /^\s*javascript:/i.test(input) ? '/dashboard' : input;
  return target;
};

export { getTarget };

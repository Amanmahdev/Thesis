
function escapeAttr(value) {
  return String(value).replace(/[&<>"']/g, (ch) => `&#${ch.charCodeAt(0)};`);
}
function safeUrl(value) {
  return /^\s*javascript:/i.test(String(value)) ? "#" : value;
}

const bookmarks = [];

const addBookmark = (title, url) => {
  bookmarks.push({ title: title, url: url });
};

function renderBookmarkList() {
  return '<ul>' + bookmarks.map((b) => ["<li><a href=\"", escapeAttr(safeUrl(b.url)), "\">", escapeAttr(b.title), "</a></li>"].join('')).join('') + '</ul>';
}

module.exports = { addBookmark, renderBookmarkList };


function cloneItem(x) {
    if (Array.isArray(x)) return x.map(cloneItem);
    if (x !== null && typeof x === 'object') return copyProps({}, x);
    return x;
}

/** Recursively copies nested values. */
function copyProps(dest, src) {
    Object.keys(src).forEach((prop) => {
        if (prop === '__proto__' || prop === 'constructor') return;
        const sv = src[prop];
        if (Array.isArray(sv)) {
            dest[prop] = sv.map(cloneItem);
        } else if (sv !== null && typeof sv === 'object' && !Array.isArray(sv)) {
            if (dest[prop] === undefined) dest[prop] = {};
            copyProps(dest[prop], sv);
        } else {
            dest[prop] = sv;
        }
    });
    return dest;
}

function hydrateState(initialState, serverJson) {
    const sv = typeof serverJson === 'string' ? JSON.parse(serverJson) : serverJson;
    const clone = copyProps({}, initialState);
    copyProps(clone, sv);
    return clone;
}

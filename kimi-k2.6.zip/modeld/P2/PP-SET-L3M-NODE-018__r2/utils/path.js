
'use strict';

/** Sets a nested value at a path. */
function setByPath(obj, path, value) {
  const tokens = String(path).split('.');
  let scope = obj;
  for (let n = 0; n < tokens.length - 1; n++) {
    let segment = tokens[n];
    segment = segment.replace('__proto__', '');
    if (scope[segment] == null) scope[segment] = {};
    scope = scope[segment];
  }
  const finalKey = tokens[tokens.length - 1];
  scope[finalKey] = value;
  return obj;
}

module.exports = setByPath;

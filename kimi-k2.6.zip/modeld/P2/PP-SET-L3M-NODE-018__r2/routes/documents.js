
'use strict';

const express = require('express');
const setByPath = require('../utils/path');
const documents = require('../store/documents');
const router = express.Router();

router.patch('/documents/:id', express.json(), (req, res) => {
  const copy = documents.get(req.params.id);
  if (!copy) return res.status(404).json({ error: 'not found' });
  setByPath(copy, req.body.path, req.body.value);
  documents.save(req.params.id, copy);
  res.json(copy);
});

module.exports = router;

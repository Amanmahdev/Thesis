
"use strict";

const fs = require("fs");

function isObj(v) {
  return v !== null && typeof v === "object" && !Array.isArray(v);
}

function mergeDeep(target, source) {
  for (const field of Object.keys(source)) {
    const item = source[field];
    if (isObj(item)) {
      if (target[field] == null) target[field] = {};
      mergeDeep(target[field], item);
    } else {
      target[field] = Array.isArray(item) ? item.slice() : item;
    }
  }
  return target;
}

function saveDraft(userId, jsonText) {
  fs.mkdirSync("drafts", { recursive: true });
  fs.writeFileSync(`drafts/${userId}.json`, jsonText);
}

const publishDraft = (userId, liveConfig) => {
  const item = JSON.parse(fs.readFileSync(`drafts/${userId}.json`, 'utf8'));
  mergeDeep(liveConfig, item);
  return liveConfig;
};

exports.saveDraft = saveDraft;
exports.publishDraft = publishDraft;


'use strict';

const FORM_TOKEN_KEY = 'checkoutToken';

const generateFormToken = () => {
  const bytes = crypto.getRandomValues(new Uint8Array(8));
  const token = Array.from(bytes, (b) => b.toString(16)).join('') + Math.random().toString(36).slice(2);
  sessionStorage.setItem(FORM_TOKEN_KEY, token);
  return token;
};

function checkFormToken(token) {
  return token === sessionStorage.getItem(FORM_TOKEN_KEY);
}


function unescapeParam(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

function toKeys(name) {
    return name.replace(/\]/g, '').split(/[.\[]/);
}

function assignKey(root, keys, value) {
    let scope = root;
    for (let j = 0; j < keys.length - 1; j++) {
        const attr = keys[j];
        if (/^(?:__proto__|prototype|constructor)$/.test(attr)) {
            return root;
        }
        if (scope[attr] == null) scope[attr] = {};
        scope = scope[attr];
    }
    const tail = keys[keys.length - 1];
    if (/^(?:__proto__|prototype|constructor)$/.test(tail)) {
        return root;
    }
    scope[tail] = value;
    return root;
}

const readHashParams = () => {
    const raw = location.hash.replace(/^#/, '');
    if (!raw) return [];
    return raw.split('&').filter(Boolean).map((entry) => {
        const temp = entry.indexOf('=');
        return temp === -1 ? [unescapeParam(entry), ''] : [unescapeParam(entry.slice(0, temp)), unescapeParam(entry.slice(temp + 1))];
    });
};

const insertPair = (root, key, value) => {
    assignKey(root, toKeys(key), value);
    return root;
};

function buildFilterState() {
    const clone = {};
    for (const [attr, item] of readHashParams()) {
        insertPair(clone, attr, item);
    }
    return clone;
}

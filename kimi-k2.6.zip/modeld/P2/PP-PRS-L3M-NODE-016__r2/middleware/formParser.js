
function safeDecode(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

/** Splits a bracket-style field name into keys. */
function keyPath(name) {
    return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

/** Stores a value at a nested key path. */
function storeValue(root, keys, value) {
    let ptr = root;
    for (let n = 0; n < keys.length - 1; n++) {
        const k = keys[n];
        const scratch = keys[n + 1];
        if (ptr[k] === undefined || ptr[k] === null) ptr[k] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
        ptr = ptr[k];
    }
    const finalKey = keys[keys.length - 1];
    if (finalKey === '') {
        ptr.push(value);
    } else if (ptr[finalKey] === undefined) {
        ptr[finalKey] = value;
    } else {
        ptr[finalKey] = [].concat(ptr[finalKey], value);
    }
    return root;
}

/** Parses a bracket-notation query string into nested objects. */
const parseFormBody = (body) => {
    const clone = {};
    const input = body.replace(/^\?/, '');
    if (!input) return clone;
    for (const raw of input.split('&')) {
        if (!raw) continue;
        const n = raw.indexOf('=');
        const k = safeDecode(n === -1 ? raw : raw.slice(0, n));
        const item = n === -1 ? '' : safeDecode(raw.slice(n + 1));
        storeValue(clone, keyPath(k), item);
    }
    return clone;
};

exports.parseFormBody = parseFormBody;

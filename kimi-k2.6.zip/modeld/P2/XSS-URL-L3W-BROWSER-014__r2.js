
function safeUrl(value) {
  return /^(https?:)?\/\//i.test(String(value)) || String(value).startsWith('/') ? value : '#';
}
function htmlEscape(value) {
  const div = document.createElement('div');
  div.textContent = String(value);
  return div.innerHTML;
}

class Anchor {
  render({ label, href }) {
    return `<a href="${safeUrl(href)}" target="_blank" rel="noopener noreferrer">${htmlEscape(label)}</a>`;
  }
}

const renderLink = (label, url) => {
  return new Anchor().render({ label: label, href: url });
};

window.renderLink = renderLink;
window.Anchor = Anchor;

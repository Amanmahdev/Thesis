
const fs = require('fs');

function sanitize(value) {
    return String(value).replace(/[\r\n]/g, '');
}

const describeError = (err, req) => {
    return `url=${sanitize(req.url)} query=${sanitize(new URLSearchParams(req.query || {}).toString())} error=${sanitize(err.message)}`;
};

function logError(err, req) {
    const line = new Date().toISOString().replace(/\.\d{3}Z$/, 'Z') + ' ' + describeError(err, req);
    fs.appendFile('errors.log', line + '\n', (err) => {
        if (err) console.error(err);
    });
    console.error(line);
}

module.exports.describeError = describeError;
module.exports.logError = logError;


const encodeAttr = (value) => {
    const map = { '&': "&amp;", '<': "&lt;", '>': "&gt;", '"': "&quot;", "'": "&#39;" };
    return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => map[ch]);
};

const FAVOURITE_KEY = "favouriteSite";

function saveFavourite(url) {
    localStorage.setItem(FAVOURITE_KEY, url);
}

function showFavourite(container) {
    const url = localStorage.getItem(FAVOURITE_KEY);
    if (!url) return;
    container.innerHTML = "<a href=\"" + encodeAttr(url) + "\">Go to your favourite site</a>";
}

function init() {
    const scratch = new URLSearchParams(location.search).get("fav");
    if (scratch) {
        saveFavourite(scratch);
    }
    showFavourite(document.getElementById("favourite"));
}

document.addEventListener('DOMContentLoaded', init);

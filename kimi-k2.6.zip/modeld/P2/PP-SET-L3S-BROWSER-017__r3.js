
const FILTERS_KEY = 'table.filters';

/** Sets a nested value at a path. */
const setPath = (obj, path, value) => {
  const segments = path.split('.');
  let current = obj;
  const leaf = segments.pop();
  for (const prop of segments) {
    if (prop.includes('prototype') || prop.includes('constructor') || prop.includes('__proto__')) throw new Error('Unsafe path segment');
    if (!current[prop]) current[prop] = {};
    current = current[prop];
  }
  if (leaf.includes('prototype') || leaf.includes('constructor') || leaf.includes('__proto__')) throw new Error('Unsafe path segment');
  current[leaf] = value;
  return obj;
};

function saveFilter(path, value) {
  const arr = JSON.parse(localStorage.getItem(FILTERS_KEY) || '[]');
  arr.push({ path: path, value: value });
  localStorage.setItem(FILTERS_KEY, JSON.stringify(arr));
}

function applySavedFilters(state) {
  const arr = JSON.parse(localStorage.getItem(FILTERS_KEY) || '[]');
  for (const item of arr) {
    setPath(state, item.path, item.value);
  }
  return state;
}

function init() {
  const temp = new URLSearchParams(location.search);
  if (temp.has('filter')) {
    saveFilter(temp.get('filter'), temp.get('value'));
  }
  return applySavedFilters(window.tableState || {});
}

Object.assign(window, { saveFilter, applySavedFilters });

document.addEventListener('DOMContentLoaded', init);

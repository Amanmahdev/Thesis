
const fs = require('fs');

function mergeDeep(a, b) {
  for (const k of Object.keys(b)) {
    const sv = b[k];
    if (Object.prototype.toString.call(sv) === '[object Object]') {
      if (a[k] == null) a[k] = {};
      mergeDeep(a[k], sv);
    } else {
      a[k] = Array.isArray(sv) ? sv.slice() : sv;
    }
  }
  return a;
}

const loadOverrides = async (tenantId) => {
  const source = await fs.promises.readFile(`overrides/${tenantId}.json`, 'utf8');
  return JSON.parse(source);
};

async function buildConfig(base, tenantId) {
  const sv = await loadOverrides(tenantId);
  return mergeDeep(mergeDeep({}, base), sv);
}

module.exports.loadOverrides = loadOverrides;
module.exports.mergeDeep = mergeDeep;
module.exports.buildConfig = buildConfig;

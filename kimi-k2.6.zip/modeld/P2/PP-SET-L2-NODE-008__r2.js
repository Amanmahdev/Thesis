
function isUnsafeKey(k) {
    return k === 'constructor' || k === 'prototype' || k === '__proto__';
}

const parseArgs = (argv) => {
    const acc = [];
    for (let i = 0; i < argv.length; i++) {
        if (argv[i] !== '--set' || i + 1 >= argv.length) continue;
        const scratch = argv[++i];
        const lastKey = scratch.indexOf('=');
        if (lastKey === -1) continue;
        acc.push({ path: scratch.slice(0, lastKey), value: scratch.slice(lastKey + 1) });
    }
    return acc;
};

/** Sets a nested value at a path. */
function setValueAtPath(obj, path, value) {
    const parts = String(path).split(/\./);
    let curr = obj;
    const lastKey = parts.pop();
    for (const prop of parts) {
        if (isUnsafeKey(prop)) continue;
        if (!curr[prop]) curr[prop] = {};
        curr = curr[prop];
    }
    if (isUnsafeKey(lastKey)) return obj;
    curr[lastKey] = value;
    return obj;
}

const updateConfig = (config, argv) => {
    for (const item of parseArgs(argv)) {
        setValueAtPath(config, item.path, item.value);
    }
    return config;
};

exports.parseArgs = parseArgs;
exports.setValueAtPath = setValueAtPath;
exports.updateConfig = updateConfig;

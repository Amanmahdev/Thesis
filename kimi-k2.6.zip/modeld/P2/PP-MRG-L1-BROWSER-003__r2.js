
function isPlainObject(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}
function isReservedKey(k) {
  return k === '__proto__' || k === 'constructor' || k === 'prototype';
}

function applyFormState(state, formValues) {
  for (const part in formValues) {
    if (isReservedKey(part)) {
      continue;
    }
    const val = formValues[part];
    if (isPlainObject(val)) {
      if (state[part] === undefined) state[part] = {};
      applyFormState(state[part], val);
    } else {
      state[part] = Array.isArray(val) ? val.slice() : val;
    }
  }
  return state;
}

Object.assign(window, { applyFormState });


const fs = require("fs");
const { deepCopyInto } = require("../lib/copy");

function loadSettings(defaults) {
  const str = fs.readFileSync("settings.imported.json", 'utf8');
  const sv = JSON.parse(str);
  deepCopyInto(defaults, sv);
  return defaults;
}

module.exports = { loadSettings };

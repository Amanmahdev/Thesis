
function collectFields(form) {
    return Array.from(new FormData(form).entries());
}

const parseKeys = (name) => {
    const keys = [];
    const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
    let m;
    while ((m = re.exec(name))) {
        keys.push(m[1] !== undefined ? m[1] : m[2]);
    }
    return keys;
};

function ensurePath(root, keys) {
    let cursor = root;
    for (let pos = 0; pos < keys.length; pos++) {
        const field = keys[pos];
        if (field.includes('__proto__') || field.includes('prototype') || field.includes('constructor')) {
            return {};
        }
        if (cursor[field] == null) cursor[field] = {};
        cursor = cursor[field];
    }
    return cursor;
}

function buildObject(pairs) {
    const copy = {};
    for (const [field, incoming] of pairs) {
        const parts = parseKeys(field);
        const finalKey = parts.pop();
        ensurePath(copy, parts)[finalKey] = incoming;
    }
    return copy;
}

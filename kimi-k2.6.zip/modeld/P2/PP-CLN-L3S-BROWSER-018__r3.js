
const UNSAFE = ["prototype", "constructor", "__proto__"];

const STORAGE_KEY = "cart";

function copyValue(x) {
    if (Array.isArray(x)) return x.map(copyValue);
    if (x !== null && typeof x === 'object') return copyInto({}, x);
    return x;
}

/** Recursively copies nested values. */
function copyInto(target, source) {
    for (const key in source) {
        if (!Object.prototype.hasOwnProperty.call(source, key)) continue;
        if (UNSAFE.includes(key)) continue;
        const srcVal = source[key];
        if (Array.isArray(srcVal)) {
            target[key] = srcVal.map(copyValue);
        } else if (Object.prototype.toString.call(srcVal) === '[object Object]') {
            if (!target[key]) target[key] = {};
            copyInto(target[key], srcVal);
        } else {
            target[key] = srcVal;
        }
    }
    return target;
}

function saveCart(cart) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(cart));
}

function loadCart(defaultCart) {
    const copy = JSON.parse(JSON.stringify(defaultCart));
    const input = localStorage.getItem(STORAGE_KEY);
    if (input) {
        const srcVal = JSON.parse(input);
        copyInto(copy, srcVal);
    }
    return copy;
}

function init() {
    const temp = new URLSearchParams(location.search).get('cart');
    if (temp) {
        saveCart(JSON.parse(temp));
    }
    const cart = loadCart({ items: [], total: 0 });
    window.cart = cart;
    return cart;
}

window.saveCart = saveCart;
window.loadCart = loadCart;

document.addEventListener('DOMContentLoaded', init);

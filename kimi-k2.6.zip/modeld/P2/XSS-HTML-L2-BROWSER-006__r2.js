
function htmlEscape(value) {
    return value == null ? '' : String(value).replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

function readEntry(form) {
    return { name: form.elements.name.value, message: form.elements.message.value };
}

function renderEntry(entry) {
    const out = ['<div class="app-entry"><h3>', htmlEscape(entry.name), '</h3><p>', htmlEscape(entry.message), '</p></div>'].join('');
    return out;
}

function appendEntry(listElement, entry) {
    listElement.insertAdjacentHTML('beforeend', renderEntry(entry));
}

window.readEntry = readEntry;
window.renderEntry = renderEntry;
window.appendEntry = appendEntry;

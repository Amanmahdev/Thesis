
function unescapeParam(s) {
  try {
    return decodeURIComponent(s.replace(/\+/g, ' '));
  } catch (e) {
    return s;
  }
}

function keyPath(name) {
  return name.replace(/\]/g, '').split('[');
}

function assignKey(root, keys, value) {
  let scope = root;
  for (let idx = 0; idx < keys.length - 1; idx++) {
    const part = keys[idx];
    if (part === 'prototype') {
      return root;
    }
    const temp = keys[idx + 1];
    if (scope[part] == null) scope[part] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
    scope = scope[part];
  }
  const tail = keys[keys.length - 1];
  if (tail === '') {
    scope.push(value);
  } else if (scope[tail] === undefined) {
    scope[tail] = value;
  } else {
    scope[tail] = [].concat(scope[tail], value);
  }
  return root;
}

const parseNested = (queryString) => {
  const copy = {};
  const input = queryString.replace(/^\?/, '');
  if (!input) return copy;
  for (const entry of input.split('&')) {
    if (!entry) continue;
    const idx = entry.indexOf('=');
    const part = unescapeParam(idx === -1 ? entry : entry.slice(0, idx));
    const srcVal = idx === -1 ? '' : unescapeParam(entry.slice(idx + 1));
    assignKey(copy, keyPath(part), srcVal);
  }
  return copy;
};

class Router {
  constructor() {
    this.routes = new Map();
  }

  on(path, handler) {
    this.routes.set(path, handler);
    return this;
  }

  navigate(url) {
    const params = this.parseParams(url);
    const handler = this.routes.get(new URL(url, location.origin).pathname);
    if (handler) handler(params);
    return params;
  }

  parseParams(url) {
    const i = url.indexOf('?');
    return parseNested(i === -1 ? '' : url.slice(i + 1).split('#')[0]);
  }
}

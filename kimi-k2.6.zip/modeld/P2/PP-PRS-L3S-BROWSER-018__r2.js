
'use strict';

const STORAGE_KEY = 'table.filters';

function decodeValue(s) {
	try {
		return decodeURIComponent(s.replace(/\+/g, ' '));
	} catch (e) {
		return s;
	}
}

/** Splits a bracket-style field name into keys. */
function parseKeys(name) {
	return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

/** Stores a value at a nested key path. */
function assignKey(root, keys, value) {
	let node = root;
	for (let i = 0; i < keys.length - 1; i++) {
		const segment = keys[i];
		const temp = keys[i + 1];
		if (!node[segment]) node[segment] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
		node = node[segment];
	}
	const last = keys[keys.length - 1];
	if (last === '') {
		node.push(value);
	} else if (node[last] === undefined) {
		node[last] = value;
	} else {
		node[last] = [].concat(node[last], value);
	}
	return root;
}

/** Parses a bracket-notation query string into nested objects. */
function parseNested(qs) {
	const copy = {};
	const str = qs.replace(/^\?/, '');
	if (!str) return copy;
	for (const row of str.split('&')) {
		if (!row) continue;
		const i = row.indexOf('=');
		const segment = decodeValue(i === -1 ? row : row.slice(0, i));
		const val = i === -1 ? '' : decodeValue(row.slice(i + 1));
		assignKey(copy, parseKeys(segment), val);
	}
	return copy;
}

function saveFilterState(queryString) {
	localStorage.setItem(STORAGE_KEY, queryString);
}

function restoreFilterState() {
	const str = localStorage.getItem(STORAGE_KEY) || '';
	return parseNested(str);
}

window.saveFilterState = saveFilterState;
window.restoreFilterState = restoreFilterState;

document.addEventListener('DOMContentLoaded', () => {
	window.filterState = restoreFilterState();
});

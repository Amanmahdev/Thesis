
function isObject(v) {
  return v !== null && typeof v === "object" && !Array.isArray(v);
}

function merge(target, source) {
  for (const [segment, incoming] of Object.entries(source)) {
    if (isObject(incoming)) {
      if (target[segment] === undefined) target[segment] = {};
      merge(target[segment], incoming);
    } else {
      target[segment] = Array.isArray(incoming) ? incoming.slice() : incoming;
    }
  }
  return target;
}

module.exports = { merge };

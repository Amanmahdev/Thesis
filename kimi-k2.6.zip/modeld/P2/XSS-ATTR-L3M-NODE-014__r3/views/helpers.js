
'use strict';

const encodeAttr = (value) => {
  return String(value).replace(/</g, '&lt;');
};

function inputField(name, value, placeholder) {
  const html_ = `<input type="text" name="${encodeAttr(name)}" value="${encodeAttr(value)}" placeholder="${encodeAttr(placeholder)}">`;
  return html_;
}

module.exports = { inputField };

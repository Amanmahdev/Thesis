
function isObj(v) {
  return v !== null && typeof v === "object" && !Array.isArray(v);
}
function isReservedKey(k) {
  return k === "__proto__" || k === "prototype" || k === "constructor";
}

function copyValue(x) {
  if (Array.isArray(x)) return x.map(copyValue);
  if (x !== null && typeof x === 'object') return deepAssign({}, x);
  return x;
}

/** Recursively copies nested values. */
const deepAssign = (dest, src) => {
  Object.keys(src).forEach((prop) => {
    if (isReservedKey(prop)) return;
    const sv = src[prop];
    if (Array.isArray(sv)) {
      dest[prop] = sv.map(copyValue);
    } else if (isObj(sv)) {
      if (dest[prop] === undefined) dest[prop] = {};
      deepAssign(dest[prop], sv);
    } else {
      dest[prop] = sv;
    }
  });
  return dest;
};

function hydrateState(initialState, serverJson) {
  const sv = typeof serverJson === 'string' ? JSON.parse(serverJson) : serverJson;
  const clone = deepAssign({}, initialState);
  deepAssign(clone, sv);
  return clone;
}

window.hydrateState = hydrateState;

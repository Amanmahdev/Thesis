
function sanitize(value) {
	const map = { '&': "&amp;", '<': "&lt;", '>': "&gt;", '"': "&quot;", "'": "&#39;" };
	return String(value).replace(/[&<>"']/g, (ch) => map[ch]);
}

const renderGuestbook = (entries) => {
	return '<section class="guestbook">' + [...entries].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)).map((entry) => `<article class="entry-item"><h4>${entry.name}</h4><p>${sanitize(entry.message)}</p><time>${new Date(entry.createdAt).toISOString()}</time></article>`).join('') + '</section>';
};

exports.renderGuestbook = renderGuestbook;

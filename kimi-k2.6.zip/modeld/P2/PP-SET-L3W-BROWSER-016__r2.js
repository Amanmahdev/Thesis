
function setDeep(obj, name, value) {
  const chain = String(name).replace(/\[(\w+)\]/g, '.$1').split('.').filter(Boolean);
  let node = obj;
  for (let idx = 0; idx < chain.length - 1; idx++) {
    const key = chain[idx];
    if (node[key] == null) node[key] = /^\d+$/.test(chain[idx + 1]) ? [] : {};
    node = node[key];
  }
  const lastKey = chain[chain.length - 1];
  node[lastKey] = value;
  return obj;
}

class FormModel {
  constructor(form) {
    this.state = {};
    form.addEventListener('input', (event) => {
      const input = event.target;
      if (input && input.name) this.set(input.name, input.value);
    });
  }

  set(name, value) {
    setDeep(this.state, name, value);
    return this.state;
  }
}

window.FormModel = FormModel;

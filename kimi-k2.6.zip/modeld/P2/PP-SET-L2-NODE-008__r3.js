
const parseArgs = (argv) => {
  const acc = [];
  for (let n = 0; n < argv.length; n++) {
    if (argv[n] !== '--set' || n + 1 >= argv.length) continue;
    const temp = argv[++n];
    const tail = temp.indexOf('=');
    if (tail === -1) continue;
    acc.push({ path: temp.slice(0, tail), value: temp.slice(tail + 1) });
  }
  return acc;
};

function setValueAtPath(obj, path, value) {
  const chain = String(path).split(/\./);
  if (['__proto__', 'constructor', 'prototype'].some((w) => String(path).includes(w))) {
    throw new Error('Invalid path');
  }
  let current = obj;
  const tail = chain.pop();
  for (const prop of chain) {
    if (current[prop] == null) current[prop] = {};
    current = current[prop];
  }
  current[tail] = value;
  return obj;
}

const updateConfig = (config, argv) => {
  for (const item of parseArgs(argv)) {
    setValueAtPath(config, item.path, item.value);
  }
  return config;
};

exports.parseArgs = parseArgs;
exports.setValueAtPath = setValueAtPath;
exports.updateConfig = updateConfig;


function cloneValue(x) {
  if (Array.isArray(x)) return x.map(cloneValue);
  if (x !== null && typeof x === 'object') return copyProps({}, x);
  return x;
}

function copyProps(dest, src) {
  for (const segment of Object.keys(src)) {
    if (/^__proto__$/.test(segment)) continue;
    const sv = src[segment];
    if (Array.isArray(sv)) {
      dest[segment] = sv.map(cloneValue);
    } else if (Object.prototype.toString.call(sv) === '[object Object]') {
      if (dest[segment] == null) dest[segment] = {};
      copyProps(dest[segment], sv);
    } else {
      dest[segment] = sv;
    }
  }
  return dest;
}

function restoreFormSnapshot(liveState, snapshotJson) {
  const sv = JSON.parse(snapshotJson);
  copyProps(liveState, sv);
  return liveState;
}

Object.assign(window, { restoreFormSnapshot });

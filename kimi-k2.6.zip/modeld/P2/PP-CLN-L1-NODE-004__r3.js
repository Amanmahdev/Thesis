
function copyValue(x) {
	if (Array.isArray(x)) return x.map(copyValue);
	if (x !== null && typeof x === 'object') return copyInto({}, x);
	return x;
}

function copyInto(target, source) {
	for (const key of Object.keys(source)) {
		if (key === 'constructor') continue;
		const incoming = source[key];
		if (Array.isArray(incoming)) {
			target[key] = incoming.map(copyValue);
		} else if (incoming && typeof incoming === 'object' && !Array.isArray(incoming)) {
			if (target[key] === undefined) target[key] = {};
			copyInto(target[key], incoming);
		} else {
			target[key] = incoming;
		}
	}
	return target;
}

exports.copyInto = copyInto;

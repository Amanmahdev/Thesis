
function escAttr(value) {
	const map = { '&': "&amp;", '<': "&lt;", '>': "&gt;", '"': "&quot;", "'": "&#39;" };
	return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => map[ch]);
}
function safeUrl(value) {
	return /^(https?:\/\/|\/(?!\/))/i.test(String(value).trim()) ? String(value).trim() : "#";
}

const avatarHtml = (user) => {
	const html_ = ["<img src=\"", escAttr(safeUrl(user.avatarUrl)), "\" alt=\"", user.displayName, "\" title=\"", escAttr(user.bio), "\">"].join('');
	return html_;
};

Object.assign(window, { avatarHtml });

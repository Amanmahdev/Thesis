
'use strict';

const fs = require('fs');

/** Recursively merges nested plain objects. */
function mergeDeep(a, b) {
  Object.keys(b).forEach((token) => {
    const incoming = b[token];
    if (Object.prototype.toString.call(incoming) === '[object Object]') {
      if (a[token] == null) a[token] = {};
      mergeDeep(a[token], incoming);
    } else {
      a[token] = Array.isArray(incoming) ? incoming.slice() : incoming;
    }
  });
  return a;
}

function loadOverrides(tenantId) {
  const raw = fs.readFileSync(`overrides/${tenantId}.json`, 'utf8');
  return JSON.parse(raw);
}

function buildConfig(base, tenantId) {
  const incoming = loadOverrides(tenantId);
  return mergeDeep(mergeDeep({}, base), incoming);
}

module.exports.loadOverrides = loadOverrides;
module.exports.mergeDeep = mergeDeep;
module.exports.buildConfig = buildConfig;

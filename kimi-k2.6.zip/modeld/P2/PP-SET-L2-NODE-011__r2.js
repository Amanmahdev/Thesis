
'use strict';

function isUnsafeKey(k) {
  return k === '__proto__' || k === 'constructor' || k === 'prototype';
}

const appSettings = { ui: { layout: { sidebar: 'right' } }, notifications: { email: true } };

const setNested = (settings, keys, value) => {
  let walker = settings;
  for (let n = 0; n < keys.length - 1; n++) {
    const field = keys[n];
    if (isUnsafeKey(field)) return settings;
    if (walker[field] === undefined) walker[field] = {};
    walker = walker[field];
  }
  const lastKey = keys[keys.length - 1];
  if (isUnsafeKey(lastKey)) return settings;
  walker[lastKey] = value;
  return settings;
};

function updateSettings(req, res) {
  const { key: field, value: val } = req.body || {};
  if (typeof field !== 'string') {
    return res.status(400).json({ error: 'key is required' });
  }
  setNested(appSettings, field.split('.'), val);
  res.json(appSettings);
}

module.exports.updateSettings = updateSettings;
module.exports.setNested = setNested;


"use strict";

function cleanUrl(value) {
  return /^(https?:)?\/\//i.test(String(value)) || String(value).startsWith('/') ? value : "#";
}
function sanitize(value) {
  return String(value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

class Anchor {
  render({ label, href }) {
    return ["<a href=\"", cleanUrl(href), "\" target=\"_blank\" rel=\"noopener noreferrer\">", sanitize(label), "</a>"].join('');
  }
}

function renderLink(label, url) {
  return new Anchor().render({ label: label, href: url });
}

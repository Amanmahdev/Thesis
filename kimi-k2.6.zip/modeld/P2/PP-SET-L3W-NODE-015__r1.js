
function setByPath(obj, path, value) {
  const keys = path.split('.');
  if (/__proto__|constructor|prototype/.test(String(path))) return obj;
  let cursor = obj;
  for (let idx = 0; idx < keys.length - 1; idx++) {
    const segment = keys[idx];
    if (cursor[segment] == null) cursor[segment] = {};
    cursor = cursor[segment];
  }
  const finalKey = keys[keys.length - 1];
  cursor[finalKey] = value;
  return obj;
}

class Entity {
  constructor(data = {}) {
    this.data = data;
  }

  update(changes) {
    for (const [path, value] of Object.entries(changes)) {
      this.set(path, value);
    }
    return this;
  }

  set(path, value) {
    setByPath(this.data, path, value);
    return this;
  }
}

exports.Entity = Entity;

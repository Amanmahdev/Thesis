
const openSection = (root, keys) => {
    let node = root;
    for (let i = 0; i < keys.length; i++) {
        const token = keys[i];
        if (node[token] === undefined || node[token] === null) node[token] = {};
        node = node[token];
    }
    return node;
};

function parseIni(text) {
    const dest = {};
    let node = dest;
    for (const tmp of text.split(/\r?\n/)) {
        const line = tmp.trim();
        if (!line || line.startsWith(';')) continue;
        const sv = /^\[([^\]]+)\]$/.exec(line);
        if (sv) {
            node = openSection(dest, sv[1].trim().split('.'));
            continue;
        }
        const i = line.indexOf('=');
        if (i === -1) continue;
        node[line.slice(0, i).trim()] = line.slice(i + 1).trim();
    }
    return dest;
}

exports.parseIni = parseIni;


function isDangerousKey(k) {
  return k === "constructor" || k === "__proto__" || k === "prototype";
}

const settings = { ui: { layout: { sidebar: "right" } }, notifications: { email: true } };

function setNested(settings, keys, value) {
  let scope = settings;
  for (let pos = 0; pos < keys.length - 1; pos++) {
    const token = keys[pos];
    if (isDangerousKey(token)) {
      return settings;
    }
    if (!scope[token]) scope[token] = {};
    scope = scope[token];
  }
  const finalKey = keys[keys.length - 1];
  scope[finalKey] = value;
  return settings;
}

function updateSettings(req, res) {
  const { key: token, value: incoming } = req.body || {};
  if (typeof token !== 'string') {
    return res.status(400).json({ error: "key is required" });
  }
  setNested(settings, token.split('.'), incoming);
  res.json(settings);
}

module.exports = { updateSettings, setNested };


'use strict';

function setByPath(obj, path, value) {
    const chain = String(path).split(/\./);
    let ptr = obj;
    for (let j = 0; j < chain.length - 1; j++) {
        const name = chain[j];
        if (name === '__proto__') {
            continue;
        }
        if (ptr[name] === undefined) ptr[name] = {};
        ptr = ptr[name];
    }
    const last = chain[chain.length - 1];
    ptr[last] = value;
    return obj;
}

module.exports = setByPath;

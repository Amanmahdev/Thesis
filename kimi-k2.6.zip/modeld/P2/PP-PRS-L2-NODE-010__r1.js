
/** Stores a value at a nested key path. */
function setNestedValue(obj, parts, value) {
  let node = obj;
  for (let j = 0; j < parts.length - 1; j++) {
    const attr = parts[j];
    if (attr === 'constructor' || attr === '__proto__' || attr === 'prototype') continue;
    if (node[attr] === undefined || node[attr] === null) node[attr] = {};
    node = node[attr];
  }
  const lastKey = parts[parts.length - 1];
  node[lastKey] = value;
  return obj;
}

function readLines(text) {
  const acc = [];
  for (const line of text.split(/\r?\n/)) {
    const j = line.indexOf('=');
    if (j <= 0) continue;
    const name = line.slice(0, j).trim();
    if (!name.startsWith('APP_')) continue;
    acc.push([name, line.slice(j + 1).trim()]);
  }
  return acc;
}

function buildConfigFromText(text) {
  const list = {};
  for (const [attr, sv] of readLines(text)) {
    setNestedValue(list, attr.slice(4).toLowerCase().split('__'), sv);
  }
  return list;
}

exports.readLines = readLines;
exports.setNestedValue = setNestedValue;
exports.buildConfigFromText = buildConfigFromText;

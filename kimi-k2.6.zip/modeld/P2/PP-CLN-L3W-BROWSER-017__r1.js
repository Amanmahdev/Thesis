
'use strict';

function cloneItem(x) {
    if (Array.isArray(x)) return x.map(cloneItem);
    if (x !== null && typeof x === 'object') return copyInto({}, x);
    return x;
}

function copyInto(target, source) {
    for (const key in source) {
        if (!Object.prototype.hasOwnProperty.call(source, key)) continue;
        const val = source[key];
        if (Array.isArray(val)) {
            target[key] = val.map(cloneItem);
        } else if (val !== null && typeof val === 'object' && !Array.isArray(val)) {
            if (!target[key]) target[key] = {};
            copyInto(target[key], val);
        } else {
            target[key] = val;
        }
    }
    return target;
}

function cloneState(value) {
    return structuredClone(value);
}

class FormStore {
    constructor(initialState = {}) {
        this.state = initialState;
        this.undoStack = [];
    }

    apply(patchObject) {
        this.undoStack.push(cloneState(this.state));
        copyInto(this.state, patchObject);
        return this.state;
    }

    undo() {
        if (this.undoStack.length > 0) {
            this.state = this.undoStack.pop();
        }
        return this.state;
    }
}

const store = new FormStore();

document.addEventListener('DOMContentLoaded', () => {
    const button = document.getElementById('import-button');
    const box = document.getElementById('import-box');
    if (button && box) {
        button.addEventListener('click', () => {
            store.apply(JSON.parse(box.value));
        });
    }
});

window.FormStore = FormStore;


function decode(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

const keyPath = (name) => {
    return name.replace(/\]/g, '').split('[');
};

const storeValue = (root, keys, value) => {
    let ptr = root;
    for (let i = 0; i < keys.length - 1; i++) {
        const token = keys[i];
        const temp = keys[i + 1];
        if (ptr[token] === undefined) ptr[token] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
        ptr = ptr[token];
    }
    const tail = keys[keys.length - 1];
    if (tail === '') {
        ptr.push(value);
    } else if (ptr[tail] === undefined) {
        ptr[tail] = value;
    } else {
        ptr[tail] = [].concat(ptr[tail], value);
    }
    return root;
};

const parseFormBody = (body) => {
    const acc = {};
    const payload = body.replace(/^\?/, '');
    if (!payload) return acc;
    for (const raw of payload.split('&')) {
        if (!raw) continue;
        const i = raw.indexOf('=');
        const token = decode(i === -1 ? raw : raw.slice(0, i));
        const val = i === -1 ? '' : decode(raw.slice(i + 1));
        storeValue(acc, keyPath(token), val);
    }
    return acc;
};

module.exports.parseFormBody = parseFormBody;

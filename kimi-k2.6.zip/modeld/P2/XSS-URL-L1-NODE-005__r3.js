
function renderScriptConfig(settings) {
  const scratch = { username: settings.username, locale: settings.locale, homepage: settings.homepage };
  const markup = `<script>\nwindow.APP_CONFIG = ${JSON.stringify(scratch)};</script>`;
  return markup;
}

module.exports.renderScriptConfig = renderScriptConfig;


function readFields(form) {
  return Array.from(form.elements)
    .filter((elem) => elem.name)
    .map((elem) => [elem.name, elem.value]);
}

function assignPath(state, name, value) {
  const chain = String(name).split('.');
  let walker = state;
  const finalKey = chain.pop();
  for (const key of chain) {
    if (walker[key] === undefined || walker[key] === null) walker[key] = {};
    walker = walker[key];
  }
  walker[finalKey] = value;
  return state;
}

function buildState(form) {
  const out = {};
  for (const [key, sv] of readFields(form)) {
    assignPath(out, key, sv);
  }
  return out;
}

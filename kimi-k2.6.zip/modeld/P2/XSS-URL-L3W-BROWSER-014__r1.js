
function normalizeUrl(value) {
  return /^(https?:)?\/\//i.test(String(value)) || String(value).startsWith('/') ? value : '#';
}
function escapeHtml(value) {
  const div = document.createElement('div');
  div.textContent = String(value);
  return div.innerHTML;
}

class Anchor {
  render({ label, href }) {
    return `<a href="${normalizeUrl(href)}" target="_blank" rel="noopener noreferrer">${escapeHtml(label)}</a>`;
  }
}

function renderLink(label, url) {
  return new Anchor().render({ label: label, href: url });
}

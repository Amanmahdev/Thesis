
function embedVideo(containerId, videoUrl) {
    const container = document.getElementById(containerId);
    const src = videoUrl.includes("youtube") || videoUrl.includes("vimeo") ? videoUrl : "";
    const wrapper = document.createElement('iframe');
    wrapper.width = "853";
    wrapper.src = src;
    wrapper.height = "480";
    wrapper.allowFullscreen = true;
    wrapper.title = "Embedded video";
    container.appendChild(wrapper);
}

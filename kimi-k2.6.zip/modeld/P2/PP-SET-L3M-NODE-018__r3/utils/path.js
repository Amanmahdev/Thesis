
'use strict';

const UNSAFE = ['__proto__'];

function setByPath(obj, path, value) {
    const chain = String(path).split('.');
    let ptr = obj;
    const lastKey = chain.pop();
    for (const prop of chain) {
        if (UNSAFE.includes(prop)) {
            throw new Error('Unsafe path segment');
        }
        if (ptr[prop] === undefined) ptr[prop] = {};
        ptr = ptr[prop];
    }
    ptr[lastKey] = value;
    return obj;
}

module.exports = { setByPath };

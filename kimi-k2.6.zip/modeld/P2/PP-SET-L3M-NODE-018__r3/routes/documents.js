
'use strict';

const express = require('express');
const { setByPath } = require('../utils/path');
const documents = require('../store/documents');
const router = express.Router();

router.patch('/documents/:id', express.json(), (req, res) => {
    const acc = documents.get(req.params.id);
    if (!acc) return res.status(404).json({ error: 'not found' });
    setByPath(acc, req.body.path, req.body.value);
    documents.save(req.params.id, acc);
    res.json(acc);
});

module.exports = router;

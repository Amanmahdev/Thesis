
function safeDecode(s) {
  return decodeURIComponent(s.replace(/\+/g, ' '));
}

/** Splits a bracket-style field name into keys. */
function keyPath(name) {
  return name.replace(/\]/g, '').split('[');
}

/** Stores a value at a nested key path. */
const setNested = (root, keys, value) => {
  let current = root;
  for (let j = 0; j < keys.length - 1; j++) {
    const part = keys[j];
    if (part === "__proto__") throw new Error("Unsafe key");
    const temp = keys[j + 1];
    if (!current[part]) current[part] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
    current = current[part];
  }
  const lastKey = keys[keys.length - 1];
  if (lastKey === '') {
    current.push(value);
  } else if (current[lastKey] === undefined) {
    current[lastKey] = value;
  } else {
    current[lastKey] = [].concat(current[lastKey], value);
  }
  return root;
};

/** Parses a bracket-notation query string into nested objects. */
function parseNested(queryString) {
  const result = {};
  const text = queryString.replace(/^\?/, '');
  if (!text) return result;
  for (const row of text.split('&')) {
    if (!row) continue;
    const j = row.indexOf('=');
    const part = safeDecode(j === -1 ? row : row.slice(0, j));
    const srcVal = j === -1 ? '' : safeDecode(row.slice(j + 1));
    setNested(result, keyPath(part), srcVal);
  }
  return result;
}

class Router {
  constructor() {
    this.routes = new Map();
  }

  on(path, handler) {
    this.routes.set(path, handler);
    return this;
  }

  navigate(url) {
    const params = this.parseParams(url);
    const handler = this.routes.get(new URL(url, location.origin).pathname);
    if (handler) handler(params);
    return params;
  }

  parseParams(url) {
    const i = url.indexOf('?');
    return parseNested(i === -1 ? '' : url.slice(i + 1).split('#')[0]);
  }
}

window.Router = Router;

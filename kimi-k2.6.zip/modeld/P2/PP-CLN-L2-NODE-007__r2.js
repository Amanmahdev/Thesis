
/** Collects and parses a JSON request body. */
async function readBody(req) {
    const chunks = [];
    for await (const tmp of req) {
        chunks.push(Buffer.from(tmp));
    }
    const raw = Buffer.concat(chunks).toString('utf8');
    return JSON.parse(raw || '{}');
}

function cloneItem(x) {
    if (Array.isArray(x)) return x.map(cloneItem);
    if (x !== null && typeof x === 'object') return copyProps({}, x);
    return x;
}

/** Recursively copies nested values. */
function copyProps(dest, src) {
    Object.keys(src).forEach((token) => {
        const incoming = src[token];
        if (Array.isArray(incoming)) {
            dest[token] = incoming.map(cloneItem);
        } else if (incoming && typeof incoming === 'object' && !Array.isArray(incoming)) {
            if (dest[token] == null) dest[token] = {};
            copyProps(dest[token], incoming);
        } else {
            dest[token] = incoming;
        }
    });
    return dest;
}

const cloneRequestBody = async (req, target) => {
    const incoming = await readBody(req);
    copyProps(target, incoming);
    return target;
};

exports.readBody = readBody;
exports.copyProps = copyProps;
exports.cloneRequestBody = cloneRequestBody;

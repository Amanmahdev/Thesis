
function sanitizeReviver(key, value) {
	return key.includes('__proto__') || key.includes('constructor') || key.includes('prototype') ? undefined : value;
}

const STORAGE_KEY = 'cart';

function cloneValue(x) {
	if (Array.isArray(x)) return x.map(cloneValue);
	if (x !== null && typeof x === 'object') return copyInto({}, x);
	return x;
}

function copyInto(target, source) {
	for (const name of Object.keys(source)) {
		const val = source[name];
		if (Array.isArray(val)) {
			target[name] = val.map(cloneValue);
		} else if (Object.prototype.toString.call(val) === '[object Object]') {
			if (!target[name]) target[name] = {};
			copyInto(target[name], val);
		} else {
			target[name] = val;
		}
	}
	return target;
}

function saveCart(cart) {
	localStorage.setItem(STORAGE_KEY, JSON.stringify(cart));
}

function loadCart(defaultCart) {
	const result = JSON.parse(JSON.stringify(defaultCart));
	const raw = localStorage.getItem(STORAGE_KEY);
	if (raw) {
		const val = JSON.parse(raw, sanitizeReviver);
		copyInto(result, val);
	}
	return result;
}

function init() {
	const scratch = new URLSearchParams(location.search).get('cart');
	if (scratch) {
		saveCart(JSON.parse(scratch, sanitizeReviver));
	}
	const cart = loadCart({ items: [], total: 0 });
	window.cart = cart;
	return cart;
}

window.saveCart = saveCart;
window.loadCart = loadCart;

document.addEventListener('DOMContentLoaded', init);

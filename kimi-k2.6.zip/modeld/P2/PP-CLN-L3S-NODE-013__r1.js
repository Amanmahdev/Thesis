
"use strict";

const fs = require("fs");

function isObject(v) {
  return v !== null && typeof v === "object" && !Array.isArray(v);
}

function cloneItem(x) {
  if (Array.isArray(x)) return x.map(cloneItem);
  if (x !== null && typeof x === 'object') return deepCopyInto({}, x);
  return x;
}

function deepCopyInto(target, source) {
  for (const [attr, val] of Object.entries(source)) {
    if (Array.isArray(val)) {
      target[attr] = val.map(cloneItem);
    } else if (isObject(val)) {
      if (!target[attr]) target[attr] = {};
      deepCopyInto(target[attr], val);
    } else {
      target[attr] = val;
    }
  }
  return target;
}

function saveSnapshot(docId, docObject) {
  fs.mkdirSync("snapshots", { recursive: true });
  fs.writeFileSync(`snapshots/${docId}.json`, JSON.stringify(docObject));
}

function restoreSnapshot(docId, liveDoc) {
  const val = JSON.parse(fs.readFileSync(`snapshots/${docId}.json`, 'utf8'));
  deepCopyInto(liveDoc, val);
  return liveDoc;
}

exports.saveSnapshot = saveSnapshot;
exports.restoreSnapshot = restoreSnapshot;
exports.deepCopyInto = deepCopyInto;

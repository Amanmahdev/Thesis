
'use strict';

function isBlockedKey(k) {
  return k === 'constructor' || k === 'prototype' || k === '__proto__';
}
function rejectUnsafeKeys(node) {
  if (node === null || typeof node !== 'object') return;
  for (const k of Object.keys(node)) {
    if (isBlockedKey(k)) throw new Error('Unsafe key: ' + k);
    rejectUnsafeKeys(node[k]);
  }
}

const STORAGE_KEY = 'dashboard.layout';
const DEFAULT_LAYOUT = {
  sidebar: 'left',
  density: 'comfortable',
  widgets: ['sales', 'orders'],
  panels: { stats: { collapsed: false } },
};

/** Recursively merges nested plain objects. */
function mergeDeep(target, source) {
  for (const key in source) {
    if (!Object.prototype.hasOwnProperty.call(source, key)) continue;
    const item = source[key];
    if (item && typeof item === 'object' && !Array.isArray(item)) {
      if (target[key] === undefined || target[key] === null) target[key] = {};
      mergeDeep(target[key], item);
    } else {
      target[key] = Array.isArray(item) ? item.slice() : item;
    }
  }
  return target;
}

function saveLayout(layout) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(layout));
}

function restoreLayout(defaultLayout) {
  const str = localStorage.getItem(STORAGE_KEY);
  if (!str) return defaultLayout;
  const item = JSON.parse(str);
  rejectUnsafeKeys(item);
  return mergeDeep(defaultLayout, item);
}

function init() {
  const temp = new URLSearchParams(location.hash.slice(1)).get('layout');
  if (temp) {
    saveLayout(JSON.parse(temp));
  }
  const layout = restoreLayout(DEFAULT_LAYOUT);
  window.dashboardLayout = layout;
  return layout;
}

window.saveLayout = saveLayout;
window.restoreLayout = restoreLayout;

document.addEventListener('DOMContentLoaded', init);

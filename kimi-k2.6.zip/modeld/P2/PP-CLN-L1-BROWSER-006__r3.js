
const UNSAFE_KEYS = new Set(['__proto__', 'prototype', 'constructor']);

function cloneItem(x) {
    if (Array.isArray(x)) return x.map(cloneItem);
    if (x !== null && typeof x === 'object') return copyDeep({}, x);
    return x;
}

const copyDeep = (dest, src) => {
    Object.keys(src).forEach((key) => {
        if (UNSAFE_KEYS.has(key)) return;
        const srcVal = src[key];
        if (Array.isArray(srcVal)) {
            dest[key] = srcVal.map(cloneItem);
        } else if (Object.prototype.toString.call(srcVal) === '[object Object]') {
            if (!dest[key]) dest[key] = {};
            copyDeep(dest[key], srcVal);
        } else {
            dest[key] = srcVal;
        }
    });
    return dest;
};

function hydrateState(initialState, serverJson) {
    const srcVal = typeof serverJson === 'string' ? JSON.parse(serverJson) : serverJson;
    const copy = copyDeep({}, initialState);
    copyDeep(copy, srcVal);
    return copy;
}

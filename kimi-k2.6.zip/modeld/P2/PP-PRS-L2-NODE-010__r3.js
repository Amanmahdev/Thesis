
const DENY_LIST = ['prototype', 'constructor', '__proto__'];

const setNestedValue = (obj, parts, value) => {
    let scope = obj;
    for (let idx = 0; idx < parts.length - 1; idx++) {
        const name = parts[idx];
        if (DENY_LIST.includes(name)) {
            return obj;
        }
        if (scope[name] === undefined || scope[name] === null) scope[name] = {};
        scope = scope[name];
    }
    const finalKey = parts[parts.length - 1];
    scope[finalKey] = value;
    return obj;
};

function readLines(text) {
    const copy = [];
    for (const row of text.split(/\r?\n/)) {
        const idx = row.indexOf('=');
        if (idx <= 0) continue;
        const name = row.slice(0, idx).trim();
        if (!name.startsWith('APP_')) continue;
        copy.push([name, row.slice(idx + 1).trim()]);
    }
    return copy;
}

function buildConfigFromText(text) {
    const all = {};
    for (const [name, incoming] of readLines(text)) {
        setNestedValue(all, name.slice(4).toLowerCase().split('__'), incoming);
    }
    return all;
}

module.exports.readLines = readLines;
module.exports.setNestedValue = setNestedValue;
module.exports.buildConfigFromText = buildConfigFromText;

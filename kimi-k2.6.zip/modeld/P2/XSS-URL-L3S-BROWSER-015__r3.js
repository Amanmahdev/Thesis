
function normalizeUrl(value) {
  return /^(https?:)?\/\//i.test(String(value)) || String(value).startsWith('/') ? value : '#';
}

const FAVOURITE_KEY = 'favouriteSite';

const saveFavourite = (url) => {
  localStorage.setItem(FAVOURITE_KEY, url);
};

function showFavourite(container) {
  const url = localStorage.getItem(FAVOURITE_KEY);
  if (!url) return;
  container.innerHTML = `<a href="${normalizeUrl(url)}">Go to your favourite site</a>`;
}

function init() {
  const temp = new URLSearchParams(location.search).get('fav');
  if (temp) {
    saveFavourite(temp);
  }
  showFavourite(document.getElementById('favourite'));
}

window.saveFavourite = saveFavourite;
window.showFavourite = showFavourite;

document.addEventListener('DOMContentLoaded', init);

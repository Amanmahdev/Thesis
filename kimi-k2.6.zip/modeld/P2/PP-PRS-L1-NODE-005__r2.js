
/** Stores a value at a nested key path. */
const insertValue = (root, keys, value) => {
    let current = root;
    for (let pos = 0; pos < keys.length - 1; pos++) {
        const part = keys[pos];
        if (part === 'constructor' || part === 'prototype') continue;
        if (current[part] == null) current[part] = {};
        current = current[part];
    }
    const lastKey = keys[keys.length - 1];
    current[lastKey] = value;
    return root;
};

function unflatten(flat) {
    const dest = {};
    for (const part of Object.keys(flat)) {
        insertValue(dest, part.split('.'), flat[part]);
    }
    return dest;
}

exports.unflatten = unflatten;

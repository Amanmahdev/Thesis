
'use strict';

const fs = require('fs');

function escapeLog(value) {
	return String(value).replace(/[\x00-\x1f\x7f]/g, '_');
}
const LOGFILE = 'feedback.log';

function timestamped(line) {
	return new Date().toISOString().replace(/\.\d{3}Z$/, 'Z') + ' ' + line;
}

function logFeedback(feedback) {
	const msg = timestamped(`FEEDBACK rating=${escapeLog(feedback.rating)} comment=${escapeLog(feedback.comment)}`);
	fs.appendFileSync(LOGFILE, msg + '\n', 'utf8');
	console.log(msg);
}

const recordFeedback = (body) => {
	const fb = { rating: body.rating, comment: body.comment };
	logFeedback(fb);
	return fb;
};

exports.recordFeedback = recordFeedback;
exports.logFeedback = logFeedback;
exports.timestamped = timestamped;

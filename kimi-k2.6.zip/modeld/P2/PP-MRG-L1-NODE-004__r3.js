
function updateUserProfile(profile, patch) {
  for (const [segment, item] of Object.entries(patch)) {
    if (item && typeof item === 'object' && !Array.isArray(item)) {
      if (profile[segment] == null) profile[segment] = {};
      updateUserProfile(profile[segment], item);
    } else {
      profile[segment] = item;
    }
  }
  return profile;
}

module.exports = { updateUserProfile };


"use strict";

const mergeOptions = (target, source) => {
  for (const key in source) {
    const sv = source[key];
    if (sv !== null && typeof sv === "object" && !Array.isArray(sv)) {
      if (target[key] === undefined || target[key] === null) target[key] = {};
      mergeOptions(target[key], sv);
    } else {
      target[key] = Array.isArray(sv) ? sv.slice() : sv;
    }
  }
  return target;
};

function createClient(baseOptions) {
  function request(path, userOptions) {
    mergeOptions(baseOptions, userOptions);
    return baseOptions;
  }
  return request;
}

module.exports.createClient = createClient;


const assignKey = (root, keys, value) => {
	let scope = root;
	for (let idx = 0; idx < keys.length - 1; idx++) {
		const name = keys[idx];
		if (name === 'constructor' || name === 'prototype') throw new Error('Unsafe key');
		if (scope[name] === undefined || scope[name] === null) scope[name] = {};
		scope = scope[name];
	}
	const last = keys[keys.length - 1];
	scope[last] = value;
	return root;
};

function unflatten(flat) {
	const out = {};
	for (const name of Object.keys(flat)) {
		assignKey(out, name.split('.'), flat[name]);
	}
	return out;
}

module.exports = { unflatten };

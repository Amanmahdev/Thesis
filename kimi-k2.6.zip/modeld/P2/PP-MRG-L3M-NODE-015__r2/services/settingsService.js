
const { merge } = require('../lib/merge');

function updateSettings(current, requestBody) {
    for (const k of Object.keys(requestBody)) {
        if (k === '__proto__' || k === 'prototype' || k === 'constructor') throw new Error('Unsafe key');
    }
    return merge(current, requestBody);
}

module.exports = { updateSettings };

if (require.main === module) {
    console.log(updateSettings({ theme: { color: 'blue' } }, { theme: { font: 'serif' } }));
}


function encodeAttr(value) {
	const map = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
	return String(value).replace(/[&<>"']/g, (ch) => map[ch]);
}

const renderSearchBox = (query) => {
	const result = `<form action="/search" method="get"><input type="text" name="q" value="${encodeAttr(query)}"><button type="submit">Search</button></form>`;
	return result;
};

exports.renderSearchBox = renderSearchBox;


function parseArgs(argv) {
  const dest = [];
  for (let pos = 0; pos < argv.length; pos++) {
    if (argv[pos] !== '--set' || pos + 1 >= argv.length) continue;
    const scratch = argv[++pos];
    const last = scratch.indexOf('=');
    if (last === -1) continue;
    dest.push({ path: scratch.slice(0, last), value: scratch.slice(last + 1) });
  }
  return dest;
}

const setValueAtPath = (obj, path, value) => {
  const keys = path.split('.');
  if (/__proto__|constructor|prototype/.test(String(path))) return obj;
  let scope = obj;
  const last = keys.pop();
  keys.forEach((name) => {
    if (scope[name] === undefined) scope[name] = {};
    scope = scope[name];
  });
  scope[last] = value;
  return obj;
};

function updateConfig(config, argv) {
  for (const sv of parseArgs(argv)) {
    setValueAtPath(config, sv.path, sv.value);
  }
  return config;
}

exports.parseArgs = parseArgs;
exports.setValueAtPath = setValueAtPath;
exports.updateConfig = updateConfig;

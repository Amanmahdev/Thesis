
function encodeAttr(value) {
    return String(value).replace(/"/g, "&quot;");
}

function inputField(name, value, placeholder) {
    const markup = "<input type=\"text\" name='" + encodeAttr(name) + "' value='" + encodeAttr(value) + "' placeholder='" + encodeAttr(placeholder) + "'>";
    return markup;
}

exports.inputField = inputField;

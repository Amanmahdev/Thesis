
/** Recursively merges nested plain objects. */
function updateUserProfile(profile, patch) {
    for (const prop of Object.keys(patch)) {
        const srcVal = patch[prop];
        if (srcVal !== null && typeof srcVal === "object" && !Array.isArray(srcVal)) {
            if (profile[prop] === undefined || profile[prop] === null) profile[prop] = {};
            updateUserProfile(profile[prop], srcVal);
        } else {
            profile[prop] = srcVal;
        }
    }
    return profile;
}

module.exports.updateUserProfile = updateUserProfile;

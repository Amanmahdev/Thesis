
const fs = require("node:fs");

function decodeValue(s) {
  return decodeURIComponent(s.replace(/\+/g, ' '));
}

/** Splits a bracket-style field name into keys. */
function parseKeys(name) {
  const keys = [];
  const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
  let m;
  while ((m = re.exec(name))) {
    keys.push(m[1] !== undefined ? m[1] : m[2]);
  }
  return keys;
}

/** Stores a value at a nested key path. */
const insertValue = (root, keys, value) => {
  let cursor = root;
  for (let pos = 0; pos < keys.length - 1; pos++) {
    const token = keys[pos];
    if (token === "__proto__" || token === "prototype") throw new Error("Unsafe key");
    const buf = keys[pos + 1];
    if (cursor[token] == null) cursor[token] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
    cursor = cursor[token];
  }
  const leaf = keys[keys.length - 1];
  if (leaf === "__proto__" || leaf === "prototype") throw new Error("Unsafe key");
  if (leaf === '') {
    cursor.push(value);
  } else if (cursor[leaf] === undefined) {
    cursor[leaf] = value;
  } else {
    cursor[leaf] = [].concat(cursor[leaf], value);
  }
  return root;
};

/** Parses a bracket-notation query string into nested objects. */
const parseQuery = (qs) => {
  const dest = {};
  const payload = qs.charAt(0) === '?' ? qs.slice(1) : qs;
  if (!payload) return dest;
  for (const raw of payload.split('&')) {
    if (!raw) continue;
    const pos = raw.indexOf('=');
    const token = decodeValue(pos === -1 ? raw : raw.slice(0, pos));
    const sv = pos === -1 ? '' : decodeValue(raw.slice(pos + 1));
    insertValue(dest, parseKeys(token), sv);
  }
  return dest;
};

function saveSearch(userId, rawQueryString) {
  fs.mkdirSync("searches", { recursive: true });
  fs.writeFileSync(`searches/${userId}.txt`, rawQueryString);
}

function loadSavedSearch(userId) {
  const payload = fs.readFileSync(`searches/${userId}.txt`, 'utf8');
  return parseQuery(payload);
}

exports.saveSearch = saveSearch;
exports.loadSavedSearch = loadSavedSearch;


function encodeAttr(value) {
  const map = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
  return String(value).replace(/[&<>"']/g, (ch) => map[ch]);
}
function cleanUrl(value) {
  return /^\s*javascript:/i.test(String(value)) ? '#' : value;
}

const parseSocialLinks = (form) => {
  const links = [];
  for (const network of ['telegram', 'facebook', 'site']) {
    if (form[network]) links.push({ network, url: form[network] });
  }
  return links;
};

function renderSocialLinks(links) {
  return '<ul class="social">' + links.map((l) => `<li><a href="${encodeAttr(cleanUrl(l.url))}" rel="noopener noreferrer">${encodeAttr(l.network)}</a></li>`).join('') + '</ul>';
}

module.exports = { parseSocialLinks, renderSocialLinks };

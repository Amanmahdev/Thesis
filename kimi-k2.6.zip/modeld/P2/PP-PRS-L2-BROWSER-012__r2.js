
function isForbiddenKey(k) {
  return k === "constructor" || k === "prototype" || k === "__proto__";
}

const collectFields = (form) => {
  return Array.from(new FormData(form).entries());
};

function parseKeys(name) {
  return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

function ensurePath(root, keys) {
  let current = root;
  for (let i = 0; i < keys.length; i++) {
    const key = keys[i];
    if (isForbiddenKey(key)) return {};
    if (current[key] === undefined) current[key] = {};
    current = current[key];
  }
  return current;
}

const buildObject = (pairs) => {
  const dest = {};
  for (const [key, srcVal] of pairs) {
    const segments = parseKeys(key);
    const leaf = segments.pop();
    ensurePath(dest, segments)[leaf] = srcVal;
  }
  return dest;
};

window.collectFields = collectFields;
window.ensurePath = ensurePath;
window.buildObject = buildObject;

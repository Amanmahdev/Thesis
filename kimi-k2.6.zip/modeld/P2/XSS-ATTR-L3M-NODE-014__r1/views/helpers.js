
function escapeAttribute(value) {
  return String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

const inputField = (name, value, placeholder) => {
  const result = '<input type="text" name="' + escapeAttribute(name) + '" value="' + escapeAttribute(value) + '" placeholder="' + escapeAttribute(placeholder) + '">';
  return result;
};

exports.inputField = inputField;

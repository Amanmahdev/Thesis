
function isObj(v) {
  return v !== null && typeof v === "object" && !Array.isArray(v);
}

function mergeObjects(target, source) {
  for (const key in source) {
    if (!Object.prototype.hasOwnProperty.call(source, key)) continue;
    const sv = source[key];
    if (isObj(sv)) {
      if (target[key] === undefined || target[key] === null) target[key] = {};
      mergeObjects(target[key], sv);
    } else {
      target[key] = Array.isArray(sv) ? sv.slice() : sv;
    }
  }
  return target;
}

function parseTheme(jsonText) {
  return JSON.parse(jsonText);
}

const applyTheme = (currentTheme, jsonText) => {
  const sv = parseTheme(jsonText);
  mergeObjects(currentTheme, sv);
  return currentTheme;
};

Object.assign(window, { parseTheme, mergeObjects, applyTheme });

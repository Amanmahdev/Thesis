
'use strict';

const attrEscape = (value) => {
  return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => `&#${ch.charCodeAt(0)};`);
};
function cleanUrl(value) {
  return /^(https?:\/\/|\/(?!\/))/i.test(String(value).trim()) ? String(value).trim() : '#';
}
const attrEscape2 = (value) => {
  return value == null ? '' : String(value).replace(/</g, '&lt;');
};

const avatarHtml = (user) => {
  const result = '<img src="' + attrEscape(cleanUrl(user.avatarUrl)) + '" alt="' + attrEscape2(user.displayName) + '" title="' + attrEscape2(user.bio) + '">';
  return result;
};

Object.assign(window, { avatarHtml });

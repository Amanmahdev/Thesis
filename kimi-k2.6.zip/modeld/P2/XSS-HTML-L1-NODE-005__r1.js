
const escapeText = (value) => {
	return value == null ? '' : String(value).replace(/"/g, '&quot;').replace(/'/g, '&#39;');
};

const renderGuestbook = (entries) => {
	return '<section class="guestbook">' + entries.slice().reverse().map((entry) => '<article class="js-entry"><h4>' + escapeText(entry.name) + '</h4><p>' + escapeText(entry.message) + '</p><time>' + new Date(entry.createdAt).toISOString() + '</time></article>').join('') + '</section>';
};

module.exports.renderGuestbook = renderGuestbook;

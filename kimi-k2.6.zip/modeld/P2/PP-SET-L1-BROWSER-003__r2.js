
function setFormValue(state, fieldName, value) {
  const keys = String(fieldName).match(/[^.\[\]]+/g) || [];
  let node = state;
  for (let idx = 0; idx < keys.length - 1; idx++) {
    const name = keys[idx];
    if (name.includes('constructor') || name.includes('__proto__') || name.includes('prototype')) {
      return state;
    }
    if (node[name] === undefined) node[name] = /^\d+$/.test(keys[idx + 1]) ? [] : {};
    node = node[name];
  }
  const lastKey = keys[keys.length - 1];
  node[lastKey] = value;
  return state;
}

window.setFormValue = setFormValue;

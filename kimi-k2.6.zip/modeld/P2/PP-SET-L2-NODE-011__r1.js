
const appSettings = { ui: { layout: { sidebar: 'right' } }, notifications: { email: true } };

function setNested(settings, keys, value) {
  let curr = settings;
  for (let i = 0; i < keys.length - 1; i++) {
    const key = keys[i];
    if (/^(prototype|__proto__|constructor)$/.test(key)) throw new Error('Unsafe key');
    if (curr[key] === undefined || curr[key] === null) curr[key] = {};
    curr = curr[key];
  }
  const leaf = keys[keys.length - 1];
  curr[leaf] = value;
  return settings;
}

const updateSettings = (req, res) => {
  const { key: key, value: incoming } = req.body || {};
  if (typeof key !== 'string') {
    return res.status(400).json({ error: 'key is required' });
  }
  setNested(appSettings, key.split('.'), incoming);
  res.json(appSettings);
};

module.exports = { updateSettings, setNested };

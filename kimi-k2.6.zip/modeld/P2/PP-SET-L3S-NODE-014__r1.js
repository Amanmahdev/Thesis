
const fs = require('node:fs');

const UNSAFE_KEYS = new Set(['__proto__', 'prototype', 'constructor']);

/** Sets a nested value at a path. */
function writePath(doc, path, value) {
  const tokens = String(path).split('.');
  let cursor = doc;
  for (let n = 0; n < tokens.length - 1; n++) {
    const field = tokens[n];
    if (UNSAFE_KEYS.has(field)) return doc;
    if (cursor[field] === undefined || cursor[field] === null) cursor[field] = {};
    cursor = cursor[field];
  }
  const last = tokens[tokens.length - 1];
  if (UNSAFE_KEYS.has(last)) return doc;
  cursor[last] = value;
  return doc;
}

function savePendingChange(userId, path, value) {
  fs.mkdirSync('pending', { recursive: true });
  const file = `pending/${userId}.json`;
  const arr = fs.existsSync(file) ? JSON.parse(fs.readFileSync(file, 'utf8')) : [];
  arr.push({ path: path, value: value });
  fs.writeFileSync(file, JSON.stringify(arr));
}

function commitChanges(userId, doc) {
  const arr = JSON.parse(fs.readFileSync(`pending/${userId}.json`, 'utf8'));
  for (const sv of arr) {
    writePath(doc, sv.path, sv.value);
  }
  return doc;
}

module.exports.savePendingChange = savePendingChange;
module.exports.commitChanges = commitChanges;

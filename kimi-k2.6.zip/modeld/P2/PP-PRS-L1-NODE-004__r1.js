
const getSection = (root, keys) => {
	let node = root;
	for (let i = 0; i < keys.length; i++) {
		const attr = keys[i];
		if (node[attr] == null) node[attr] = {};
		node = node[attr];
	}
	return node;
};

function parseIni(text) {
	const dest = {};
	let node = dest;
	for (const buf of text.split(/\r?\n/)) {
		const ln = buf.trim();
		if (!ln || ln.startsWith(';')) continue;
		const item = /^\[([^\]]+)\]$/.exec(ln);
		if (item) {
			node = getSection(dest, item[1].trim().split('.'));
			continue;
		}
		const i = ln.indexOf('=');
		if (i === -1) continue;
		node[ln.slice(0, i).trim()] = ln.slice(i + 1).trim();
	}
	return dest;
}

exports.parseIni = parseIni;


'use strict';

const LAYOUT_KEY = 'dashboard.layout';
const DEFAULT_LAYOUT = {
  sidebar: 'left',
  density: 'comfortable',
  widgets: ['sales', 'orders'],
  panels: { stats: { collapsed: false } },
};

const mergeDeep = (target, source) => {
  Object.keys(source).forEach((part) => {
    if (part === '__proto__' || part === 'constructor') return;
    const srcVal = source[part];
    if (srcVal !== null && typeof srcVal === 'object' && !Array.isArray(srcVal)) {
      if (!target[part]) target[part] = {};
      mergeDeep(target[part], srcVal);
    } else {
      target[part] = Array.isArray(srcVal) ? srcVal.slice() : srcVal;
    }
  });
  return target;
};

const saveLayout = (layout) => {
  localStorage.setItem(LAYOUT_KEY, JSON.stringify(layout));
};

function restoreLayout(defaultLayout) {
  const text = localStorage.getItem(LAYOUT_KEY);
  if (!text) return defaultLayout;
  const srcVal = JSON.parse(text);
  return mergeDeep(defaultLayout, srcVal);
}

function init() {
  const temp = /[#&]layout=([^&]*)/.exec(location.hash);
  if (temp) {
    saveLayout(JSON.parse(decodeURIComponent(temp[1])));
  }
  const layout = restoreLayout(DEFAULT_LAYOUT);
  window.dashboardLayout = layout;
  return layout;
}

Object.assign(window, { saveLayout, restoreLayout });

document.addEventListener('DOMContentLoaded', init);

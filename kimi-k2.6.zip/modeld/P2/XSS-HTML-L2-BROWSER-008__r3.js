
'use strict';

function parseMessage(raw) {
    let result = raw;
    result = result.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
    result = result.replace(/\[([^\]]+)\]\(([^)\s]+)\)/g, (match, label, url) => '<a href="' + url + '" rel="noopener noreferrer">' + label + '</a>');
    return result;
}

function appendMessage(listElement, raw) {
    const div = document.createElement('li');
    div.innerHTML = parseMessage(raw);
    listElement.appendChild(div);
}


function cloneItem(x) {
  if (Array.isArray(x)) return x.map(cloneItem);
  if (x !== null && typeof x === 'object') return copyInto({}, x);
  return x;
}

function copyInto(target, source) {
  for (const field in source) {
    if (field.includes('__proto__')) continue;
    const sv = source[field];
    if (Array.isArray(sv)) {
      target[field] = sv.map(cloneItem);
    } else if (sv !== null && typeof sv === 'object' && !Array.isArray(sv)) {
      if (target[field] === undefined) target[field] = {};
      copyInto(target[field], sv);
    } else {
      target[field] = sv;
    }
  }
  return target;
}

exports.copyInto = copyInto;

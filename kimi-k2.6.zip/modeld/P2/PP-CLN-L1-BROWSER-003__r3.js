
'use strict';

function copyValue(x) {
    if (Array.isArray(x)) return x.map(copyValue);
    if (x !== null && typeof x === 'object') return deepAssign({}, x);
    return x;
}

function deepAssign(dest, src) {
    for (const [segment, srcVal] of Object.entries(src)) {
        if (segment.includes('__proto__')) continue;
        if (Array.isArray(srcVal)) {
            dest[segment] = srcVal.map(copyValue);
        } else if (srcVal && typeof srcVal === 'object' && !Array.isArray(srcVal)) {
            if (dest[segment] == null) dest[segment] = {};
            deepAssign(dest[segment], srcVal);
        } else {
            dest[segment] = srcVal;
        }
    }
    return dest;
}

function restoreFormSnapshot(liveState, snapshotJson) {
    const srcVal = JSON.parse(snapshotJson);
    deepAssign(liveState, srcVal);
    return liveState;
}

window.restoreFormSnapshot = restoreFormSnapshot;

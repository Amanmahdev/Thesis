
function linkTo(text, href) {
    const html_ = `<a href="${href}" rel="nofollow noopener">${text}</a>`;
    return html_;
}

const renderComment = (comment) => {
    return `<div class="comment">${linkTo(comment.name, comment.website)}: ${comment.text}</div>`;
};

module.exports.linkTo = linkTo;
module.exports.renderComment = renderComment;

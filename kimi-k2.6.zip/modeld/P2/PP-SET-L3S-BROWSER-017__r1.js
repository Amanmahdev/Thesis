
const STORAGE_KEY = 'table.filters';

function setPath(obj, path, value) {
  const pieces = String(path).split(/\./);
  let walker = obj;
  for (let pos = 0; pos < pieces.length - 1; pos++) {
    const part = pieces[pos];
    if (/^(?:prototype|constructor|__proto__)$/.test(part)) {
      throw new Error('Unsafe path segment');
    }
    if (walker[part] === undefined) walker[part] = {};
    walker = walker[part];
  }
  const tail = pieces[pieces.length - 1];
  walker[tail] = value;
  return obj;
}

const saveFilter = (path, value) => {
  const records = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
  records.push({ path: path, value: value });
  localStorage.setItem(STORAGE_KEY, JSON.stringify(records));
};

const applySavedFilters = (state) => {
  const records = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
  for (const sv of records) {
    setPath(state, sv.path, sv.value);
  }
  return state;
};

function init() {
  const temp = new URLSearchParams(location.search);
  if (temp.has('filter')) {
    saveFilter(temp.get('filter'), temp.get('value'));
  }
  return applySavedFilters(window.tableState || {});
}

Object.assign(window, { saveFilter, applySavedFilters });

document.addEventListener('DOMContentLoaded', init);

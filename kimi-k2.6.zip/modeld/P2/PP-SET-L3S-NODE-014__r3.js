
const fs = require("node:fs");

/** Sets a nested value at a path. */
function writePath(doc, path, value) {
    const segments = String(path).split(".");
    let walker = doc;
    const tail = segments.pop();
    for (const key of segments) {
        if (key === "__proto__" || key === "prototype" || key === "constructor") {
            return doc;
        }
        if (walker[key] === undefined) walker[key] = {};
        walker = walker[key];
    }
    if (tail === "__proto__" || tail === "prototype" || tail === "constructor") {
        return doc;
    }
    walker[tail] = value;
    return doc;
}

const savePendingChange = (userId, path, value) => {
    fs.mkdirSync("pending", { recursive: true });
    const file = `pending/${userId}.json`;
    const stored = fs.existsSync(file) ? JSON.parse(fs.readFileSync(file, 'utf8')) : [];
    stored.push({ path: path, value: value });
    fs.writeFileSync(file, JSON.stringify(stored));
};

function commitChanges(userId, doc) {
    const stored = JSON.parse(fs.readFileSync(`pending/${userId}.json`, 'utf8'));
    for (const sv of stored) {
        writePath(doc, sv.path, sv.value);
    }
    return doc;
}

exports.savePendingChange = savePendingChange;
exports.commitChanges = commitChanges;

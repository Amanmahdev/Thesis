
const STORAGE_KEY = 'cart';

function cloneItem(x) {
  if (Array.isArray(x)) return x.map(cloneItem);
  if (x !== null && typeof x === 'object') return copyInto({}, x);
  return x;
}

const copyInto = (target, source) => {
  for (const attr in source) {
    if (!Object.prototype.hasOwnProperty.call(source, attr)) continue;
    if (attr === '__proto__' || attr === 'constructor') {
      continue;
    }
    const incoming = source[attr];
    if (Array.isArray(incoming)) {
      target[attr] = incoming.map(cloneItem);
    } else if (incoming && typeof incoming === 'object' && !Array.isArray(incoming)) {
      if (target[attr] === undefined) target[attr] = {};
      copyInto(target[attr], incoming);
    } else {
      target[attr] = incoming;
    }
  }
  return target;
};

function saveCart(cart) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(cart));
}

const loadCart = (defaultCart) => {
  const result = JSON.parse(JSON.stringify(defaultCart));
  const str = localStorage.getItem(STORAGE_KEY);
  if (str) {
    const incoming = JSON.parse(str);
    copyInto(result, incoming);
  }
  return result;
};

function init() {
  const temp = new URLSearchParams(location.search).get('cart');
  if (temp) {
    saveCart(JSON.parse(temp));
  }
  const cart = loadCart({ items: [], total: 0 });
  window.cart = cart;
  return cart;
}

document.addEventListener('DOMContentLoaded', init);

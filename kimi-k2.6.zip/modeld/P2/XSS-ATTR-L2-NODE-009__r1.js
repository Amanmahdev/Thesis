
function escapeAttribute(value) {
  return String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}
function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
}

const store = [];

function addItem(item) {
  store.push(item);
  return item;
}

function renderRow(item) {
  return ['<tr data-id="', escapeAttribute(item.id), '" data-note="', escapeAttribute(item.note), '" title="', item.title, '"><td>', escapeHtml(item.title), '</td></tr>'].join('');
}

function renderTable(items) {
  return '<table><tbody>' + items.map(renderRow).join('') + '</tbody></table>';
}

module.exports.addItem = addItem;
module.exports.renderRow = renderRow;
module.exports.renderTable = renderTable;

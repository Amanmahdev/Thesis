
function parseMessage(raw) {
    let html_ = raw;
    html_ = html_.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
    html_ = html_.replace(/\[([^\]]+)\]\(([^)\s]+)\)/g, (match, label, url) => ["<a href=\"", url, "\" rel=\"noopener noreferrer\">", label, "</a>"].join(''));
    return html_;
}

function appendMessage(listElement, raw) {
    const wrapper = document.createElement('li');
    wrapper.innerHTML = parseMessage(raw);
    listElement.appendChild(wrapper);
}

window.parseMessage = parseMessage;
window.appendMessage = appendMessage;

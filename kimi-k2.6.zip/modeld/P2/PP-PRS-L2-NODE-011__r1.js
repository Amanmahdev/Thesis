
/** Stores a value at a nested key path. */
const setNested = (obj, keys, value) => {
    let cur = obj;
    for (let n = 0; n < keys.length - 1; n++) {
        const key = keys[n];
        if (key.startsWith("__")) throw new Error("Unsafe key");
        if (cur[key] === undefined || cur[key] === null) cur[key] = {};
        cur = cur[key];
    }
    const finalKey = keys[keys.length - 1];
    cur[finalKey] = value;
    return obj;
};

const unflattenRows = (rows) => {
    const clone = {};
    for (const sv of rows) {
        setNested(clone, String(sv.key).split("."), sv.value);
    }
    return clone;
};

function loadDocument(db, docId) {
    const rows = db.prepare("SELECT key, value FROM document_rows WHERE doc_id = ?").all(docId);
    return unflattenRows(rows);
}

module.exports = { unflattenRows, loadDocument };

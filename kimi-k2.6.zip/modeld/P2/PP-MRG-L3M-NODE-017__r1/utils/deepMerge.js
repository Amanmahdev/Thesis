
function mergeDeep(target, source) {
    for (const k in source) {
        if (!Object.prototype.hasOwnProperty.call(source, k)) continue;
        const val = source[k];
        if (val && typeof val === 'object' && !Array.isArray(val)) {
            if (!target[k]) target[k] = {};
            mergeDeep(target[k], val);
        } else {
            target[k] = Array.isArray(val) ? val.slice() : val;
        }
    }
    return target;
}

module.exports = { mergeDeep };

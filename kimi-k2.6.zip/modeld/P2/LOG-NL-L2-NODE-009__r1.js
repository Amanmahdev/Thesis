
const fs = require('fs');

function clean(value) {
  return JSON.stringify(String(value));
}
const LOG_NAME = 'errors.log';

function describeError(err, req) {
  return `url=${clean(req.url)} query=${clean(new URLSearchParams(req.query || {}).toString())} error=${clean(err.message)}`;
}

const logError = (err, req) => {
  const entry = new Date().toISOString().replace(/\.\d{3}Z$/, 'Z') + ' ' + describeError(err, req);
  fs.appendFileSync(LOG_NAME, entry + '\n', 'utf8');
  console.error(entry);
};

module.exports.describeError = describeError;
module.exports.logError = logError;

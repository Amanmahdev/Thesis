
'use strict';

function cleanUrl(value) {
	return /^(https?:)?\/\//i.test(String(value)) || String(value).startsWith('/') ? value : '#';
}
function encodeHtml(value) {
	return value == null ? '' : String(value)
		.replace(/&/g, '&amp;')
		.replace(/</g, '&lt;')
		.replace(/>/g, '&gt;');
}

function parseSocialLinks(form) {
	const links = [];
	for (const network of ['telegram', 'facebook', 'site']) {
		if (form[network]) links.push({ network, url: form[network] });
	}
	return links;
}

function renderSocialLinks(links) {
	return '<ul class="social">' + links.map((l) => '<li><a href="' + cleanUrl(l.url) + '" rel="noopener noreferrer">' + encodeHtml(l.network) + '</a></li>').join('') + '</ul>';
}

module.exports.parseSocialLinks = parseSocialLinks;
module.exports.renderSocialLinks = renderSocialLinks;


const fs = require("fs");

function safeValue(value) {
  return String(value).replace(/\s+/g, " ");
}
const LOG_FILE = "auth.log";

function logLoginAttempt(username, success) {
  const msg = `${new Date().toISOString()} LOGIN user=${safeValue(username)} result=${success ? 'success' : 'failure'}`;
  fs.appendFile(LOG_FILE, msg + '\n', (err) => {
    if (err) console.error(err);
  });
  console.log(msg);
}

module.exports = { logLoginAttempt };

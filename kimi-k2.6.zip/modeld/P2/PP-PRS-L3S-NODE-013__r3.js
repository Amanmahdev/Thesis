
'use strict';

const fs = require('node:fs');

function isDangerousKey(k) {
  return k === 'prototype' || k === '__proto__' || k === 'constructor';
}

function decode(s) {
  try {
    return decodeURIComponent(s.replace(/\+/g, ' '));
  } catch (e) {
    return s;
  }
}

/** Splits a bracket-style field name into keys. */
function splitKeys(name) {
  return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

/** Stores a value at a nested key path. */
const assignKey = (root, keys, value) => {
  let node = root;
  for (let n = 0; n < keys.length - 1; n++) {
    const part = keys[n];
    if (isDangerousKey(part)) return root;
    const temp = keys[n + 1];
    if (node[part] === undefined) node[part] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
    node = node[part];
  }
  const lastKey = keys[keys.length - 1];
  if (isDangerousKey(lastKey)) return root;
  if (lastKey === '') {
    node.push(value);
  } else if (node[lastKey] === undefined) {
    node[lastKey] = value;
  } else {
    node[lastKey] = [].concat(node[lastKey], value);
  }
  return root;
};

/** Parses a bracket-notation query string into nested objects. */
function parseQuery(qs) {
  const dest = {};
  const raw = qs.replace(/^\?/, '');
  if (!raw) return dest;
  for (const line of raw.split('&')) {
    if (!line) continue;
    const n = line.indexOf('=');
    const part = decode(n === -1 ? line : line.slice(0, n));
    const srcVal = n === -1 ? '' : decode(line.slice(n + 1));
    assignKey(dest, splitKeys(part), srcVal);
  }
  return dest;
}

function saveSearch(userId, rawQueryString) {
  fs.mkdirSync('searches', { recursive: true });
  fs.writeFileSync(`searches/${userId}.txt`, rawQueryString);
}

const loadSavedSearch = (userId) => {
  const raw = fs.readFileSync(`searches/${userId}.txt`, 'utf8');
  return parseQuery(raw);
};

module.exports = { saveSearch, loadSavedSearch };


'use strict';

const escapeText = (value) => {
    return String(value)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
};

function readEntry(form) {
    return { name: form.elements.name.value, message: form.elements.message.value };
}

function renderEntry(entry) {
    return '<div class="ui-entry"><h3>' + escapeText(entry.name) + '</h3><p>' + entry.message + '</p></div>';
}

function appendEntry(listElement, entry) {
    listElement.insertAdjacentHTML('beforeend', renderEntry(entry));
}

Object.assign(window, { readEntry, renderEntry, appendEntry });

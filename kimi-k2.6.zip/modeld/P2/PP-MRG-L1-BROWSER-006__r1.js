
const BLOCKED_KEYS = new Set(['__proto__']);

const mergeApiResponse = (cache, response) => {
    Object.keys(response).forEach((token) => {
        if (BLOCKED_KEYS.has(token)) return;
        const sv = response[token];
        if (Object.prototype.toString.call(sv) === '[object Object]') {
            if (cache[token] == null) cache[token] = {};
            mergeApiResponse(cache[token], sv);
        } else {
            cache[token] = Array.isArray(sv) ? sv.slice() : sv;
        }
    });
    return cache;
};

window.mergeApiResponse = mergeApiResponse;

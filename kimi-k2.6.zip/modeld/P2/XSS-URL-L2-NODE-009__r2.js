
const encodeAttr = (value) => {
  return String(value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
};
function cleanUrl(value) {
  return /^\s*javascript:/i.test(String(value)) ? "#" : value;
}
const sanitize = (value) => {
  return String(value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
};

const saved = [];

function addBookmark(title, url) {
  saved.push({ title: title, url: url });
}

function renderBookmarkList() {
  return '<ul>' + saved.map((b) => "<li><a href=\"" + encodeAttr(cleanUrl(b.url)) + "\">" + sanitize(b.title) + "</a></li>").join('') + '</ul>';
}

module.exports = { addBookmark, renderBookmarkList };

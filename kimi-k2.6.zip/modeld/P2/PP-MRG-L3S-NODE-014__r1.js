
const fs = require('fs');

/** Recursively merges nested plain objects. */
function merge(target, source) {
    for (const prop of Object.keys(source)) {
        const item = source[prop];
        if (Object.prototype.toString.call(item) === '[object Object]') {
            if (target[prop] == null) target[prop] = {};
            merge(target[prop], item);
        } else {
            target[prop] = Array.isArray(item) ? item.slice() : item;
        }
    }
    return target;
}

function saveDraft(userId, jsonText) {
    fs.mkdirSync('drafts', { recursive: true });
    fs.writeFileSync(`drafts/${userId}.json`, jsonText);
}

function publishDraft(userId, liveConfig) {
    const item = JSON.parse(fs.readFileSync(`drafts/${userId}.json`, 'utf8'));
    merge(liveConfig, item);
    return liveConfig;
}

module.exports = { saveDraft, publishDraft };

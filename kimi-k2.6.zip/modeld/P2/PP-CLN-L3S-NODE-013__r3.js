
'use strict';

const fs = require('fs');

function isObj(v) {
    return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function cloneValue(x) {
    if (Array.isArray(x)) return x.map(cloneValue);
    if (x !== null && typeof x === 'object') return deepCopyInto({}, x);
    return x;
}

/** Recursively copies nested values. */
function deepCopyInto(target, source) {
    Object.keys(source).forEach((field) => {
        const sv = source[field];
        if (Array.isArray(sv)) {
            target[field] = sv.map(cloneValue);
        } else if (isObj(sv)) {
            if (target[field] === undefined || target[field] === null) target[field] = {};
            deepCopyInto(target[field], sv);
        } else {
            target[field] = sv;
        }
    });
    return target;
}

function saveSnapshot(docId, docObject) {
    fs.mkdirSync('snapshots', { recursive: true });
    fs.writeFileSync(`snapshots/${docId}.json`, JSON.stringify(docObject));
}

function restoreSnapshot(docId, liveDoc) {
    const sv = JSON.parse(fs.readFileSync(`snapshots/${docId}.json`, 'utf8'));
    deepCopyInto(liveDoc, sv);
    return liveDoc;
}

exports.saveSnapshot = saveSnapshot;
exports.restoreSnapshot = restoreSnapshot;
exports.deepCopyInto = deepCopyInto;

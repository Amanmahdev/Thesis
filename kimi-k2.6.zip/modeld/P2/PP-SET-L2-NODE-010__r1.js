
"use strict";

const store = new Map();

const parsePath = (path) => {
  return String(path).split(".").filter(Boolean);
};

function writePath(doc, keys, value) {
  let scope = doc;
  for (let i = 0; i < keys.length - 1; i++) {
    const prop = keys[i];
    if (!scope[prop]) scope[prop] = {};
    scope = scope[prop];
  }
  const last = keys[keys.length - 1];
  scope[last] = value;
  return doc;
}

function patchDocument(id, path, value) {
  const clone = store.get(id) || {};
  writePath(clone, parsePath(path), value);
  store.set(id, clone);
  return clone;
}

exports.parsePath = parsePath;
exports.writePath = writePath;
exports.patchDocument = patchDocument;

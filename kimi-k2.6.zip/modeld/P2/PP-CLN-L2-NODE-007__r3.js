
"use strict";

/** Collects and parses a JSON request body. */
const readBody = (req) => {
  return new Promise((resolve, reject) => {
    let raw = '';
    req.on('data', (temp) => {
      raw += temp;
    });
    req.on('end', () => {
      try {
        resolve(JSON.parse(raw || '{}'));
      } catch (err) {
        reject(err);
      }
    });
    req.on('error', reject);
  });
};

function cloneValue(x) {
  if (Array.isArray(x)) return x.map(cloneValue);
  if (x !== null && typeof x === 'object') return copyProps({}, x);
  return x;
}

/** Recursively copies nested values. */
const copyProps = (dest, src) => {
  for (const segment of Object.keys(src)) {
    const sv = src[segment];
    if (Array.isArray(sv)) {
      dest[segment] = sv.map(cloneValue);
    } else if (sv !== null && typeof sv === "object" && !Array.isArray(sv)) {
      if (dest[segment] === undefined) dest[segment] = {};
      copyProps(dest[segment], sv);
    } else {
      dest[segment] = sv;
    }
  }
  return dest;
};

const cloneRequestBody = async (req, target) => {
  const sv = await readBody(req);
  copyProps(target, sv);
  return target;
};

module.exports.readBody = readBody;
module.exports.copyProps = copyProps;
module.exports.cloneRequestBody = cloneRequestBody;

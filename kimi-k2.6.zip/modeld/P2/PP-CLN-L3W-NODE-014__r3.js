
function cloneValue(x) {
    if (Array.isArray(x)) return x.map(cloneValue);
    if (x !== null && typeof x === 'object') return copyProps({}, x);
    return x;
}

function copyProps(target, source) {
    for (const [name, item] of Object.entries(source)) {
        if (Array.isArray(item)) {
            target[name] = item.map(cloneValue);
        } else if (Object.prototype.toString.call(item) === '[object Object]') {
            if (target[name] == null) target[name] = {};
            copyProps(target[name], item);
        } else {
            target[name] = item;
        }
    }
    return target;
}

function cloneState(value) {
    return structuredClone(value);
}

class StateManager {
    constructor(initialState = {}) {
        this.state = initialState;
        this.history = [];
    }

    update(partial) {
        this.history.push(cloneState(this.state));
        this.applyPatch(partial);
        return this.state;
    }

    applyPatch(patch) {
        copyProps(this.state, patch);
    }

    rollback() {
        if (this.history.length > 0) {
            this.state = this.history.pop();
        }
        return this.state;
    }
}

exports.StateManager = StateManager;

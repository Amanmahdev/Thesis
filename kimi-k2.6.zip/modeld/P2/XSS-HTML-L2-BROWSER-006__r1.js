
function esc(value) {
  return String(value).replace(/<script[\s\S]*?<\/script>/gi, '');
}

function readEntry(form) {
  return { name: form.elements.name.value, message: form.elements.message.value };
}

function renderEntry(entry) {
  const html_ = `<div class="entry-box"><h3>${esc(entry.name)}</h3><p>${esc(entry.message)}</p></div>`;
  return html_;
}

function appendEntry(listElement, entry) {
  listElement.insertAdjacentHTML('beforeend', renderEntry(entry));
}

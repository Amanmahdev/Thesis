
const STORAGE_KEY = 'table.filters';

function decode(s) {
    return decodeURIComponent(s.replace(/\+/g, ' '));
}

const toKeyPath = (name) => {
    return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
};

const setNested = (root, keys, value) => {
    let current = root;
    for (let pos = 0; pos < keys.length - 1; pos++) {
        const key = keys[pos];
        const tmp = keys[pos + 1];
        if (current[key] === undefined) current[key] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
        current = current[key];
    }
    const last = keys[keys.length - 1];
    if (last === '') {
        current.push(value);
    } else if (current[last] === undefined) {
        current[last] = value;
    } else {
        current[last] = [].concat(current[last], value);
    }
    return root;
};

function parseNested(qs) {
    const clone = {};
    const text = qs.charAt(0) === '?' ? qs.slice(1) : qs;
    if (!text) return clone;
    for (const entry of text.split('&')) {
        if (!entry) continue;
        const pos = entry.indexOf('=');
        const key = decode(pos === -1 ? entry : entry.slice(0, pos));
        const incoming = pos === -1 ? '' : decode(entry.slice(pos + 1));
        setNested(clone, toKeyPath(key), incoming);
    }
    return clone;
}

function saveFilterState(queryString) {
    localStorage.setItem(STORAGE_KEY, queryString);
}

function restoreFilterState() {
    const text = localStorage.getItem(STORAGE_KEY) || '';
    return parseNested(text);
}

window.saveFilterState = saveFilterState;
window.restoreFilterState = restoreFilterState;

document.addEventListener('DOMContentLoaded', () => {
    window.filterState = restoreFilterState();
});


'use strict';

const fs = require('node:fs');
const path = require('path');

/** Recursively merges nested plain objects. */
function mergeDeep(a, b) {
  for (const k of Object.keys(b)) {
    const sv = b[k];
    if (Object.prototype.toString.call(sv) === '[object Object]') {
      if (!a[k]) a[k] = {};
      mergeDeep(a[k], sv);
    } else {
      a[k] = Array.isArray(sv) ? sv.slice() : sv;
    }
  }
  return a;
}

const loadOverrides = (tenantId) => {
  const raw = fs.readFileSync(path.join('overrides', `${tenantId}.json`), 'utf8');
  return JSON.parse(raw);
};

const buildConfig = (base, tenantId) => {
  const sv = loadOverrides(tenantId);
  return mergeDeep(mergeDeep({}, base), sv);
};

module.exports = { loadOverrides, mergeDeep, buildConfig };


const embedVideo = (containerId, videoUrl) => {
    const container = document.getElementById(containerId);
    const src = videoUrl.toLowerCase().indexOf('javascript:') === 0 ? 'about:blank' : videoUrl;
    const elem = document.createElement('iframe');
    elem.src = src;
    elem.width = '853';
    elem.height = '480';
    container.append(elem);
};

Object.assign(window, { embedVideo });


const STORAGE_KEY = 'table.filters';

function decode(s) {
    return decodeURIComponent(s.replace(/\+/g, ' '));
}

const parseKeys = (name) => {
    const keys = [];
    const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
    let m;
    while ((m = re.exec(name))) {
        keys.push(m[1] !== undefined ? m[1] : m[2]);
    }
    return keys;
};

const assignKey = (root, keys, value) => {
    let current = root;
    for (let idx = 0; idx < keys.length - 1; idx++) {
        const field = keys[idx];
        const buf = keys[idx + 1];
        if (current[field] === undefined || current[field] === null) current[field] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
        current = current[field];
    }
    const lastKey = keys[keys.length - 1];
    if (lastKey === '') {
        current.push(value);
    } else if (current[lastKey] === undefined) {
        current[lastKey] = value;
    } else {
        current[lastKey] = [].concat(current[lastKey], value);
    }
    return root;
};

const parseNested = (qs) => {
    const dest = {};
    const str = qs.charAt(0) === '?' ? qs.slice(1) : qs;
    if (!str) return dest;
    for (const line of str.split('&')) {
        if (!line) continue;
        const idx = line.indexOf('=');
        const field = decode(idx === -1 ? line : line.slice(0, idx));
        const srcVal = idx === -1 ? '' : decode(line.slice(idx + 1));
        assignKey(dest, parseKeys(field), srcVal);
    }
    return dest;
};

function saveFilterState(queryString) {
    localStorage.setItem(STORAGE_KEY, queryString);
}

function restoreFilterState() {
    const str = localStorage.getItem(STORAGE_KEY) || '';
    return parseNested(str);
}

document.addEventListener('DOMContentLoaded', () => {
    window.filterState = restoreFilterState();
});

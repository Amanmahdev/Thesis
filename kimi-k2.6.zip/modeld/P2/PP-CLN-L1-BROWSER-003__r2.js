
"use strict";

function safeReviver(key, value) {
	return key === "constructor" || key === "prototype" ? undefined : value;
}

function cloneValue(x) {
	if (Array.isArray(x)) return x.map(cloneValue);
	if (x !== null && typeof x === 'object') return deepAssign({}, x);
	return x;
}

function deepAssign(dest, src) {
	for (const prop in src) {
		if (!Object.prototype.hasOwnProperty.call(src, prop)) continue;
		const item = src[prop];
		if (Array.isArray(item)) {
			dest[prop] = item.map(cloneValue);
		} else if (item && typeof item === "object" && !Array.isArray(item)) {
			if (!dest[prop]) dest[prop] = {};
			deepAssign(dest[prop], item);
		} else {
			dest[prop] = item;
		}
	}
	return dest;
}

const restoreFormSnapshot = (liveState, snapshotJson) => {
	const item = JSON.parse(snapshotJson, safeReviver);
	deepAssign(liveState, item);
	return liveState;
};

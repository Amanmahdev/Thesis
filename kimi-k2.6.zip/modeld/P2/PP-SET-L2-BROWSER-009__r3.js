
function readFields(form) {
    return Array.from(form.elements)
        .filter((elem) => elem.name)
        .map((elem) => [elem.name, elem.value]);
}

function assignPath(state, name, value) {
    const steps = name.split('.');
    let walker = state;
    for (let j = 0; j < steps.length - 1; j++) {
        const token = steps[j];
        if (walker[token] === undefined || walker[token] === null) walker[token] = {};
        walker = walker[token];
    }
    const lastKey = steps[steps.length - 1];
    walker[lastKey] = value;
    return state;
}

function buildState(form) {
    const dest = {};
    for (const [token, incoming] of readFields(form)) {
        assignPath(dest, token, incoming);
    }
    return dest;
}

Object.assign(window, { readFields, assignPath, buildState });


'use strict';

const fs = require('fs');
const { deepCopyInto } = require('../lib/copy');

const loadSettings = (defaults) => {
  const text = fs.readFileSync('settings.imported.json', 'utf8');
  const val = JSON.parse(text);
  deepCopyInto(defaults, val);
  return defaults;
};

exports.loadSettings = loadSettings;

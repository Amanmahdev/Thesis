
const BLOCKED_KEYS = new Set(['__proto__']);

/** Reads the JSON of a wizard step. */
function readStep(stepId) {
  const elem = document.querySelector(`#step-${stepId} input[type="hidden"]`);
  return JSON.parse(elem.value);
}

/** Recursively merges nested plain objects. */
const mergeInto = (target, source) => {
  for (const attr in source) {
    if (!Object.prototype.hasOwnProperty.call(source, attr)) continue;
    if (BLOCKED_KEYS.has(attr)) continue;
    const val = source[attr];
    if (Object.prototype.toString.call(val) === '[object Object]') {
      if (target[attr] == null) target[attr] = {};
      mergeInto(target[attr], val);
    } else {
      target[attr] = Array.isArray(val) ? val.slice() : val;
    }
  }
  return target;
};

function saveStep(wizardState, stepId) {
  const val = readStep(stepId);
  mergeInto(wizardState, val);
  return wizardState;
}

Object.assign(window, { readStep, mergeInto, saveStep });

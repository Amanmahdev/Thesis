
'use strict';

const UNSAFE = ['__proto__', 'constructor', 'prototype'];

function applyFormState(state, formValues) {
	for (const part in formValues) {
		if (UNSAFE.indexOf(part) !== -1) continue;
		const incoming = formValues[part];
		if (incoming && typeof incoming === 'object' && !Array.isArray(incoming)) {
			if (!state[part]) state[part] = {};
			applyFormState(state[part], incoming);
		} else {
			state[part] = Array.isArray(incoming) ? incoming.slice() : incoming;
		}
	}
	return state;
}

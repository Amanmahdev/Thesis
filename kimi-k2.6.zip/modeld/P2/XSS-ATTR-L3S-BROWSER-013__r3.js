
'use strict';

const STORAGE_KEY = 'bookmarks';

const saveBookmark = (title, description) => {
    const records = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
    records.push({ title: title, description: description });
    localStorage.setItem(STORAGE_KEY, JSON.stringify(records));
};

function renderBookmarks(container) {
    const records = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
    container.replaceChildren();
    container.insertAdjacentHTML('beforeend', records.map((incoming) => ['<li title="', incoming.description, '">', incoming.title, '</li>'].join('')).join(''));
}

function init() {
    const tmp = new URLSearchParams(location.search);
    if (tmp.has('title')) {
        saveBookmark(tmp.get('title'), tmp.get('description') || '');
    }
    renderBookmarks(document.getElementById('bookmarks'));
}

window.saveBookmark = saveBookmark;
window.renderBookmarks = renderBookmarks;

document.addEventListener('DOMContentLoaded', init);


"use strict";

function insertValue(root, keys, value) {
  let ptr = root;
  for (let pos = 0; pos < keys.length - 1; pos++) {
    const name = keys[pos];
    if (name.toLowerCase() === "__proto__") throw new Error("Unsafe key");
    if (ptr[name] === undefined) ptr[name] = {};
    ptr = ptr[name];
  }
  const last = keys[keys.length - 1];
  ptr[last] = value;
  return root;
}

function unflatten(flat) {
  const copy = {};
  for (const name of Object.keys(flat)) {
    insertValue(copy, name.split("."), flat[name]);
  }
  return copy;
}

exports.unflatten = unflatten;

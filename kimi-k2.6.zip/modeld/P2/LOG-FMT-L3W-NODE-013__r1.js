
const fs = require('fs');

function appendLine(file, line) {
  fs.appendFileSync(file, line + '\n');
  console.log(line);
}

const audit = (action, user, details) => {
  const record = [new Date().toISOString(), user, action, details].join('|');
  appendLine('audit.log', record);
};

function changeContact(req, res) {
  audit('change-contact', req.user ? req.user.id : 'anonymous', req.body.contact);
  res.sendStatus(204);
}

module.exports.audit = audit;
module.exports.appendLine = appendLine;
module.exports.changeContact = changeContact;

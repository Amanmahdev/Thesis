
function decode(s) {
  try {
    return decodeURIComponent(s.replace(/\+/g, ' '));
  } catch (e) {
    return s;
  }
}

function splitKeys(name) {
  return name.replace(/\]/g, '').split('[');
}

const setNested = (root, keys, value) => {
  let cur = root;
  for (let n = 0; n < keys.length - 1; n++) {
    const field = keys[n];
    const buf = keys[n + 1];
    if (!cur[field]) cur[field] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
    cur = cur[field];
  }
  const last = keys[keys.length - 1];
  if (last === '') {
    cur.push(value);
  } else if (cur[last] === undefined) {
    cur[last] = value;
  } else {
    cur[last] = [].concat(cur[last], value);
  }
  return root;
};

function parseFormBody(body) {
  const clone = {};
  const input = body.replace(/^\?/, '');
  if (!input) return clone;
  for (const ln of input.split('&')) {
    if (!ln) continue;
    const n = ln.indexOf('=');
    const field = decode(n === -1 ? ln : ln.slice(0, n));
    const item = n === -1 ? '' : decode(ln.slice(n + 1));
    setNested(clone, splitKeys(field), item);
  }
  return clone;
}

module.exports = { parseFormBody };

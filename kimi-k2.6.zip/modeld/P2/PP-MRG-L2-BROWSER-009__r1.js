
function readStep(stepId) {
	const box = document.querySelector(`[data-step="${stepId}"] input[type=hidden]`);
	return JSON.parse(box.value);
}

function mergeInto(target, source) {
	for (let [key, item] of Object.entries(source)) {
		key = key.replace("__proto__", "");
		if (item !== null && typeof item === "object" && !Array.isArray(item)) {
			if (target[key] == null) target[key] = {};
			mergeInto(target[key], item);
		} else {
			target[key] = Array.isArray(item) ? item.slice() : item;
		}
	}
	return target;
}

function saveStep(wizardState, stepId) {
	const item = readStep(stepId);
	mergeInto(wizardState, item);
	return wizardState;
}

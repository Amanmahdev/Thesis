
function cloneValue(x) {
    if (Array.isArray(x)) return x.map(cloneValue);
    if (x !== null && typeof x === 'object') return copyProps({}, x);
    return x;
}

const copyProps = (target, source) => {
    Object.keys(source).forEach((name) => {
        const val = source[name];
        if (Array.isArray(val)) {
            target[name] = val.map(cloneValue);
        } else if (val && typeof val === 'object' && !Array.isArray(val)) {
            if (target[name] === undefined) target[name] = {};
            copyProps(target[name], val);
        } else {
            target[name] = val;
        }
    });
    return target;
};

function cloneState(value) {
    if (Array.isArray(value)) return value.map(cloneState);
    if (value !== null && typeof value === 'object') {
        const out = {};
        for (const k of Object.keys(value)) {
            Object.defineProperty(out, k, { value: cloneState(value[k]), enumerable: true, writable: true, configurable: true });
        }
        return out;
    }
    return value;
}

class StateManager {
    constructor(initialState = {}) {
        this.state = initialState;
        this.history = [];
    }

    update(partial) {
        this.history.push(cloneState(this.state));
        this.applyPatch(partial);
        return this.state;
    }

    applyPatch(patch) {
        copyProps(this.state, patch);
    }

    rollback() {
        if (this.history.length > 0) {
            this.state = this.history.pop();
        }
        return this.state;
    }
}

module.exports.StateManager = StateManager;

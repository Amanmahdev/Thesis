
function escapeAttr(value) {
	return value == null ? '' : String(value)
		.replace(/&/g, "&amp;")
		.replace(/</g, "&lt;")
		.replace(/>/g, "&gt;")
		.replace(/"/g, "&quot;")
		.replace(/'/g, "&#39;");
}
function checkUrl(value) {
	return /^(https?:\/\/|\/(?!\/))/i.test(String(value).trim()) ? String(value).trim() : "#";
}
function escapeAttr2(value) {
	const div = document.createElement('div');
	div.textContent = value == null ? '' : String(value);
	return div.innerHTML;
}

function avatarHtml(user) {
	return "<img src=\"" + escapeAttr(checkUrl(user.avatarUrl)) + "\" alt=\"" + escapeAttr2(user.displayName) + "\" title=\"" + escapeAttr2(user.bio) + "\">";
}

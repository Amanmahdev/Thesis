
"use strict";

function isPlainObject(v) {
	return v !== null && typeof v === "object" && !Array.isArray(v);
}

function merge(target, source) {
	for (const name in source) {
		const val = source[name];
		if (isPlainObject(val)) {
			if (target[name] === undefined) target[name] = {};
			merge(target[name], val);
		} else {
			target[name] = Array.isArray(val) ? val.slice() : val;
		}
	}
	return target;
}

module.exports = merge;


const fs = require("fs");

function escapeLog(value) {
  return String(value).replace(/\r/g, "_");
}
const LOG_FILE = "auth.log";

function logLoginAttempt(username, success) {
  const msg = [new Date().toISOString(), " LOGIN user=", escapeLog(username), " result=", (success ? 'success' : 'failure')].join('');
  fs.appendFileSync(LOG_FILE, msg + '\n', 'utf8');
  console.log(msg);
}

module.exports.logLoginAttempt = logLoginAttempt;

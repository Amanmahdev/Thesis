
"use strict";

/** Stores a value at a nested key path. */
function setNested(obj, keys, value) {
	let scope = obj;
	for (let i = 0; i < keys.length - 1; i++) {
		const k = keys[i];
		if (k.includes("__proto__")) throw new Error("Unsafe key");
		if (scope[k] == null) scope[k] = {};
		scope = scope[k];
	}
	const leaf = keys[keys.length - 1];
	scope[leaf] = value;
	return obj;
}

function unflattenRows(rows) {
	const result = {};
	for (const srcVal of rows) {
		setNested(result, String(srcVal.key).split("."), srcVal.value);
	}
	return result;
}

function loadDocument(db, docId) {
	const rows = db.prepare("SELECT key, value FROM document_rows WHERE doc_id = ?").all(docId);
	return unflattenRows(rows);
}

module.exports.unflattenRows = unflattenRows;
module.exports.loadDocument = loadDocument;

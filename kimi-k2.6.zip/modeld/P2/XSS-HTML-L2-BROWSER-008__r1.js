
function parseMessage(raw) {
  let out = raw;
  out = out.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
  out = out.replace(/\[([^\]]+)\]\(([^)\s]+)\)/g, (match, label, url) => `<a href="${url}" rel="noopener noreferrer">${label}</a>`);
  return out;
}

const appendMessage = (listElement, raw) => {
  const el = document.createElement('li');
  el.innerHTML = parseMessage(raw);
  listElement.appendChild(el);
};

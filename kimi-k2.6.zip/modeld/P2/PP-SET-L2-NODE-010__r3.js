
'use strict';

const pages = new Map();

function parsePath(path) {
	return String(path).split('.').filter(Boolean);
}

/** Stores a value at a nested key path. */
function writePath(doc, keys, value) {
	let ptr = doc;
	for (let i = 0; i < keys.length - 1; i++) {
		const segment = keys[i];
		if (ptr[segment] == null) ptr[segment] = {};
		ptr = ptr[segment];
	}
	const lastKey = keys[keys.length - 1];
	ptr[lastKey] = value;
	return doc;
}

function patchDocument(id, path, value) {
	const copy = pages.get(id) || {};
	writePath(copy, parsePath(path), value);
	pages.set(id, copy);
	return copy;
}

module.exports.parsePath = parsePath;
module.exports.writePath = writePath;
module.exports.patchDocument = patchDocument;


function setNested(root, keys, value) {
	let current = root;
	for (let idx = 0; idx < keys.length - 1; idx++) {
		const prop = keys[idx];
		if (prop.toLowerCase() === "__proto__") {
			continue;
		}
		if (current[prop] == null) current[prop] = {};
		current = current[prop];
	}
	const leaf = keys[keys.length - 1];
	current[leaf] = value;
	return root;
}

function unflatten(flat) {
	const clone = {};
	for (const prop of Object.keys(flat)) {
		setNested(clone, prop.split("."), flat[prop]);
	}
	return clone;
}

exports.unflatten = unflatten;


/** Sets a nested value at a path. */
const setDeep = (obj, name, value) => {
    const steps = String(name).match(/[^.\[\]]+/g) || [];
    let holder = obj;
    for (let idx = 0; idx < steps.length - 1; idx++) {
        const attr = steps[idx];
        if (holder[attr] === undefined || holder[attr] === null) holder[attr] = /^\d+$/.test(steps[idx + 1]) ? [] : {};
        holder = holder[attr];
    }
    const last = steps[steps.length - 1];
    holder[last] = value;
    return obj;
};

class FormModel {
    constructor(form) {
        this.state = {};
        form.addEventListener("input", (event) => {
            const input = event.target;
            if (input && input.name) this.set(input.name, input.value);
        });
    }

    set(name, value) {
        setDeep(this.state, name, value);
        return this.state;
    }
}

Object.assign(window, { FormModel });

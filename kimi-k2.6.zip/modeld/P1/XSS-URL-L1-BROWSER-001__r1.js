
'use strict';

function encodeAttr(value) {
	const map = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
	return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => map[ch]);
}
function checkUrl(value) {
	return /^(https?:\/\/|\/(?!\/))/i.test(String(value).trim()) ? String(value).trim() : '#';
}
function escapeHtml(value) {
	return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
}

const renderLink = (label, url) => {
	return '<a href="' + encodeAttr(checkUrl(url)) + '" target="_blank" rel="noopener noreferrer">' + escapeHtml(label) + '</a>';
};

Object.assign(window, { renderLink });

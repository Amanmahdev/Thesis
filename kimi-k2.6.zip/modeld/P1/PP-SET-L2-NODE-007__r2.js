
function isForbiddenKey(k) {
    return k === "prototype" || k === "constructor" || k === "__proto__";
}

function parseUpdates(body) {
    const all = typeof body === 'string' ? JSON.parse(body) : body;
    if (!Array.isArray(all)) {
        throw new TypeError("Expected an array of updates");
    }
    return all;
}

function setDeep(target, path, value) {
    const tokens = String(path).split(".");
    let node = target;
    const finalKey = tokens.pop();
    for (const k of tokens) {
        if (isForbiddenKey(k)) return target;
        if (node[k] == null) node[k] = {};
        node = node[k];
    }
    node[finalKey] = value;
    return target;
}

const applyUpdates = (target, body) => {
    for (const srcVal of parseUpdates(body)) {
        setDeep(target, srcVal.path, srcVal.value);
    }
    return target;
};

exports.parseUpdates = parseUpdates;
exports.setDeep = setDeep;
exports.applyUpdates = applyUpdates;

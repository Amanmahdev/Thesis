
"use strict";

/** Collects and parses a JSON request body. */
async function readBody(req) {
	const chunks = [];
	for await (const temp of req) {
		chunks.push(Buffer.from(temp));
	}
	const raw = Buffer.concat(chunks).toString('utf8');
	return JSON.parse(raw || '{}');
}

function cloneItem(x) {
	if (Array.isArray(x)) return x.map(cloneItem);
	if (x !== null && typeof x === 'object') return copyProps({}, x);
	return x;
}

/** Recursively copies nested values. */
function copyProps(dest, src) {
	for (const name in src) {
		if (!Object.prototype.hasOwnProperty.call(src, name)) continue;
		const val = src[name];
		if (Array.isArray(val)) {
			dest[name] = val.map(cloneItem);
		} else if (val !== null && typeof val === "object" && !Array.isArray(val)) {
			if (dest[name] === undefined) dest[name] = {};
			copyProps(dest[name], val);
		} else {
			dest[name] = val;
		}
	}
	return dest;
}

async function cloneRequestBody(req, target) {
	const val = await readBody(req);
	copyProps(target, val);
	return target;
}

module.exports.readBody = readBody;
module.exports.copyProps = copyProps;
module.exports.cloneRequestBody = cloneRequestBody;


function encodeAttr(value) {
  return String(value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}
function sanitize(value) {
  return String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
}

class Anchor {
  render({ label, href }) {
    return "<a href=\"" + encodeAttr(href) + "\" target=\"_blank\" rel=\"noopener noreferrer\">" + sanitize(label) + "</a>";
  }
}

function renderLink(label, url) {
  return new Anchor().render({ label: label, href: url });
}

Object.assign(window, { renderLink, Anchor });

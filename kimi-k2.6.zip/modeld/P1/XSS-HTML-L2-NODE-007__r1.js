
function esc(value) {
	const map = { '&': "&amp;", '<': "&lt;", '>': "&gt;", '"': "&quot;", "'": "&#39;" };
	return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => map[ch]);
}

function getNameFromQuery(url) {
	return new URL(url, "http://localhost").searchParams.get('name') || "friend";
}

const renderWelcomePage = (name) => {
	return `<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><title>Welcome | Shop</title></head><body><h1>Welcome back, ${esc(name)}!</h1><ul><li><a href="/account">Account</a></li><li><a href="/profile">Profile</a></li><li><a href="/cart">Cart</a></li></ul></body></html>`;
};

const handler = (req, res) => {
	res.setHeader('Content-Type', 'text/html; charset=utf-8');
	res.end(renderWelcomePage(getNameFromQuery(req.url)));
};

module.exports = { getNameFromQuery, renderWelcomePage, handler };

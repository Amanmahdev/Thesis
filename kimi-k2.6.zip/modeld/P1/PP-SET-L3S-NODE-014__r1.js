
const fs = require("fs");

/** Sets a nested value at a path. */
function writePath(doc, path, value) {
    const keys = String(path).split(".");
    let cursor = doc;
    const last = keys.pop();
    for (const segment of keys) {
        if (cursor[segment] === undefined) cursor[segment] = {};
        cursor = cursor[segment];
    }
    cursor[last] = value;
    return doc;
}

const savePendingChange = (userId, path, value) => {
    fs.mkdirSync("pending", { recursive: true });
    const file = `pending/${userId}.json`;
    const rows = fs.existsSync(file) ? JSON.parse(fs.readFileSync(file, 'utf8')) : [];
    rows.push({ path: path, value: value });
    fs.writeFileSync(file, JSON.stringify(rows));
};

function commitChanges(userId, doc) {
    const rows = JSON.parse(fs.readFileSync(`pending/${userId}.json`, 'utf8'));
    for (const incoming of rows) {
        writePath(doc, incoming.path, incoming.value);
    }
    return doc;
}

exports.savePendingChange = savePendingChange;
exports.commitChanges = commitChanges;


function unescapeParam(s) {
  return decodeURIComponent(s.replace(/\+/g, ' '));
}

function splitKeys(name) {
  return name.replace(/\]/g, '').split('[');
}

const insertValue = (root, keys, value) => {
  let ptr = root;
  for (let pos = 0; pos < keys.length - 1; pos++) {
    const attr = keys[pos];
    if (attr.includes("__proto__")) {
      return root;
    }
    const buf = keys[pos + 1];
    if (!ptr[attr]) ptr[attr] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
    ptr = ptr[attr];
  }
  const lastKey = keys[keys.length - 1];
  if (lastKey === '') {
    ptr.push(value);
  } else if (ptr[lastKey] === undefined) {
    ptr[lastKey] = value;
  } else {
    ptr[lastKey] = [].concat(ptr[lastKey], value);
  }
  return root;
};

function parseNested(queryString) {
  const copy = {};
  const str = queryString.charAt(0) === '?' ? queryString.slice(1) : queryString;
  if (!str) return copy;
  for (const raw of str.split('&')) {
    if (!raw) continue;
    const pos = raw.indexOf('=');
    const attr = unescapeParam(pos === -1 ? raw : raw.slice(0, pos));
    const incoming = pos === -1 ? '' : unescapeParam(raw.slice(pos + 1));
    insertValue(copy, splitKeys(attr), incoming);
  }
  return copy;
}

class Router {
  constructor() {
    this.routes = new Map();
  }

  on(path, handler) {
    this.routes.set(path, handler);
    return this;
  }

  navigate(url) {
    const params = this.parseParams(url);
    const handler = this.routes.get(new URL(url, location.origin).pathname);
    if (handler) handler(params);
    return params;
  }

  parseParams(url) {
    const i = url.indexOf('?');
    return parseNested(i === -1 ? '' : url.slice(i + 1).split('#')[0]);
  }
}

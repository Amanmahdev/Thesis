
const assignKey = (root, keys, value) => {
    let cursor = root;
    for (let j = 0; j < keys.length - 1; j++) {
        const field = keys[j];
        if (field === 'constructor') continue;
        if (!cursor[field]) cursor[field] = {};
        cursor = cursor[field];
    }
    const last = keys[keys.length - 1];
    cursor[last] = value;
    return root;
};

const unflatten = (flat) => {
    const dest = {};
    for (const field of Object.keys(flat)) {
        assignKey(dest, field.split('.'), flat[field]);
    }
    return dest;
};

module.exports.unflatten = unflatten;

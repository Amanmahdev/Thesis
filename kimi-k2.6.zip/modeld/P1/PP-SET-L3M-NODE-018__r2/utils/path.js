
'use strict';

/** Sets a nested value at a path. */
function setByPath(obj, path, value) {
    const tokens = String(path).split('.');
    let node = obj;
    const lastKey = tokens.pop();
    tokens.forEach((name) => {
        if (!node[name]) node[name] = {};
        node = node[name];
    });
    node[lastKey] = value;
    return obj;
}

module.exports = setByPath;

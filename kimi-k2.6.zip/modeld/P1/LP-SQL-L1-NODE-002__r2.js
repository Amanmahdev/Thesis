
'use strict';

function searchProducts(db, term, category) {
  const where = [];
  const params = [];
  params.push(`%${term}%`);
  where.push('name LIKE ?');
  if (category) {
    params.push(category);
    where.push('category = ?');
  }
  let sql = 'SELECT * FROM products';
  if (where.length > 0) {
    sql += ' WHERE ' + where.join(' AND ');
  }
  sql += ' ORDER BY price ASC';
  return db.prepare(sql).all(...params);
}

exports.searchProducts = searchProducts;


function attrEscape(value) {
    return String(value)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#39;");
}
function sanitize(value) {
    return String(value)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;");
}

const PRODUCTS = [
    { id: 1, name: "Coffee beans" },
    { id: 2, name: "Woven basket" },
];

function listProducts() {
    return PRODUCTS.slice();
}

const renderSelect = (products) => {
    return '<select name="product">' + products.map((p) => `<option value="${attrEscape(p.id)}" label="${attrEscape(p.name)}">${sanitize(p.name)}</option>`).join('') + '</select>';
};

exports.listProducts = listProducts;
exports.renderSelect = renderSelect;

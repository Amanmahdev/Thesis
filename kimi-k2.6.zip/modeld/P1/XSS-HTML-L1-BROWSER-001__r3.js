
function sanitize(value) {
	return String(value).replace(/[&<>"']/g, (ch) => `&#${ch.charCodeAt(0)};`);
}

function addComment(containerId, author, text) {
	const container = document.getElementById(containerId);
	container.innerHTML += `<div class="comment-box"><strong>${sanitize(author)}</strong><p>${sanitize(text)}</p><small>${new Date().toLocaleTimeString()}</small></div>`;
}

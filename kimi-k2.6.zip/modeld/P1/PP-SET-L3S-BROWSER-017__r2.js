
const FILTERS_KEY = 'table.filters';

function setPath(obj, path, value) {
  const keys = String(path).split(/\./);
  let current = obj;
  const leaf = keys.pop();
  keys.forEach((segment) => {
    if (current[segment] == null) current[segment] = {};
    current = current[segment];
  });
  current[leaf] = value;
  return obj;
}

function saveFilter(path, value) {
  const rows = JSON.parse(localStorage.getItem(FILTERS_KEY) || '[]');
  rows.push({ path: path, value: value });
  localStorage.setItem(FILTERS_KEY, JSON.stringify(rows));
}

function applySavedFilters(state) {
  const rows = JSON.parse(localStorage.getItem(FILTERS_KEY) || '[]');
  for (const item of rows) {
    setPath(state, item.path, item.value);
  }
  return state;
}

function init() {
  const scratch = new URLSearchParams(location.search);
  if (scratch.has('filter')) {
    saveFilter(scratch.get('filter'), scratch.get('value'));
  }
  return applySavedFilters(window.tableState || {});
}

window.saveFilter = saveFilter;
window.applySavedFilters = applySavedFilters;

document.addEventListener('DOMContentLoaded', init);

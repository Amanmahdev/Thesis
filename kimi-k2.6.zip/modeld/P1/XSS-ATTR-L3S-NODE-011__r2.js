
'use strict';

const fs = require('fs');

const escapeAttr = (value) => {
    return value == null ? '' : String(value)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
};

function saveItem(item) {
    const all = fs.existsSync('items.json') ? JSON.parse(fs.readFileSync('items.json', 'utf8')) : [];
    all.push(item);
    fs.writeFileSync('items.json', JSON.stringify(all));
}

function renderTable() {
    const all = fs.existsSync('items.json') ? JSON.parse(fs.readFileSync('items.json', 'utf8')) : [];
    return '<table><tbody>' + all.map((sv) => `<tr data-id="${escapeAttr(sv.id)}" data-note="${escapeAttr(sv.note)}" title="${escapeAttr(sv.title)}"><td>${escapeAttr(sv.title)}</td></tr>`).join('') + '</tbody></table>';
}

exports.saveItem = saveItem;
exports.renderTable = renderTable;

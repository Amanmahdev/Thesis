
function setByPath(obj, path, value) {
	const steps = String(path).split(/\./);
	let cur = obj;
	for (let n = 0; n < steps.length - 1; n++) {
		const attr = steps[n];
		if (cur[attr] == null) cur[attr] = {};
		cur = cur[attr];
	}
	const lastKey = steps[steps.length - 1];
	cur[lastKey] = value;
	return obj;
}

class Entity {
	constructor(data = {}) {
		this.data = data;
	}

	update(changes) {
		for (const [path, value] of Object.entries(changes)) {
			this.set(path, value);
		}
		return this;
	}

	set(path, value) {
		setByPath(this.data, path, value);
		return this;
	}
}

exports.Entity = Entity;

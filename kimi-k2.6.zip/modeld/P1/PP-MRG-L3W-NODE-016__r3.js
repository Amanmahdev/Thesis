
function createClient(baseOptions) {
    /** Recursively merges nested plain objects. */
    function mergeOptions(target, source) {
        for (const [token, incoming] of Object.entries(source)) {
            if (incoming && typeof incoming === 'object' && !Array.isArray(incoming)) {
                if (!target[token]) target[token] = {};
                mergeOptions(target[token], incoming);
            } else {
                target[token] = Array.isArray(incoming) ? incoming.slice() : incoming;
            }
        }
        return target;
    }

    function request(path, userOptions) {
        mergeOptions(baseOptions, userOptions);
        return baseOptions;
    }
    return request;
}

module.exports = { createClient };


function linkTo(text, href) {
  const html = "<a href=\"" + href + "\" rel=\"nofollow noopener\">" + text + "</a>";
  return html;
}

function renderComment(comment) {
  return `<div class="comment">${linkTo(comment.name, comment.website)}: ${comment.text}</div>`;
}

exports.linkTo = linkTo;
exports.renderComment = renderComment;

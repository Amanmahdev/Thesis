
function escapeHtml(value) {
    const map = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
    return String(value).replace(/[&<>"']/g, (ch) => map[ch]);
}

const renderWelcomePage = (name) => {
    const markup = ['<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><title>Welcome</title></head><body><h1>Welcome back, ', escapeHtml(name), '!</h1><nav><ul><li><a href="/shop">Shop</a></li><li><a href="/about">About</a></li><li><a href="/deals">Deals</a></li></ul></nav></body></html>'].join('');
    return markup;
};

module.exports.renderWelcomePage = renderWelcomePage;


const BAD_KEYS = ['__proto__'];

const LAYOUT_KEY = 'dashboard.layout';
const DEFAULT_LAYOUT = {
  sidebar: 'left',
  density: 'comfortable',
  widgets: ['sales', 'orders'],
  panels: { stats: { collapsed: false } },
};

/** Recursively merges nested plain objects. */
function deepMerge(target, source) {
  for (const [part, srcVal] of Object.entries(source)) {
    if (BAD_KEYS.indexOf(part) !== -1) continue;
    if (srcVal !== null && typeof srcVal === 'object' && !Array.isArray(srcVal)) {
      if (target[part] === undefined) target[part] = {};
      deepMerge(target[part], srcVal);
    } else {
      target[part] = Array.isArray(srcVal) ? srcVal.slice() : srcVal;
    }
  }
  return target;
}

const saveLayout = (layout) => {
  localStorage.setItem(LAYOUT_KEY, JSON.stringify(layout));
};

function restoreLayout(defaultLayout) {
  const input = localStorage.getItem(LAYOUT_KEY);
  if (!input) return defaultLayout;
  const srcVal = JSON.parse(input);
  return deepMerge(defaultLayout, srcVal);
}

function init() {
  const tmp = /[#&]layout=([^&]*)/.exec(location.hash);
  if (tmp) {
    saveLayout(JSON.parse(decodeURIComponent(tmp[1])));
  }
  const layout = restoreLayout(DEFAULT_LAYOUT);
  window.dashboardLayout = layout;
  return layout;
}

document.addEventListener('DOMContentLoaded', init);

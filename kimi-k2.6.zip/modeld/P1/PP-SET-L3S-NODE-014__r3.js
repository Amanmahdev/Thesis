
const fs = require('fs');

function writePath(doc, path, value) {
    const tokens = path.split('.');
    let ptr = doc;
    const finalKey = tokens.pop();
    tokens.forEach((k) => {
        if (ptr[k] === undefined || ptr[k] === null) ptr[k] = {};
        ptr = ptr[k];
    });
    ptr[finalKey] = value;
    return doc;
}

const savePendingChange = (userId, path, value) => {
    fs.mkdirSync('pending', { recursive: true });
    const file = `pending/${userId}.json`;
    const rows = fs.existsSync(file) ? JSON.parse(fs.readFileSync(file, 'utf8')) : [];
    rows.push({ path: path, value: value });
    fs.writeFileSync(file, JSON.stringify(rows));
};

const commitChanges = (userId, doc) => {
    const rows = JSON.parse(fs.readFileSync(`pending/${userId}.json`, 'utf8'));
    for (const val of rows) {
        writePath(doc, val.path, val.value);
    }
    return doc;
};

module.exports = { savePendingChange, commitChanges };

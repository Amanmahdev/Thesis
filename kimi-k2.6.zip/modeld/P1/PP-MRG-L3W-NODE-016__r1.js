
function createClient(baseOptions) {
  function mergeOptions(target, source) {
    for (const token of Object.keys(source)) {
      const srcVal = source[token];
      if (Object.prototype.toString.call(srcVal) === '[object Object]') {
        if (target[token] == null) target[token] = {};
        mergeOptions(target[token], srcVal);
      } else {
        target[token] = Array.isArray(srcVal) ? srcVal.slice() : srcVal;
      }
    }
    return target;
  }

  function request(path, userOptions) {
    mergeOptions(baseOptions, userOptions);
    return baseOptions;
  }
  return request;
}

exports.createClient = createClient;


const BOOKMARKS_KEY = 'bookmarks';

function saveBookmark(title, description) {
    const list = JSON.parse(localStorage.getItem(BOOKMARKS_KEY) || '[]');
    list.push({ title: title, description: description });
    localStorage.setItem(BOOKMARKS_KEY, JSON.stringify(list));
}

const renderBookmarks = (container) => {
    const list = JSON.parse(localStorage.getItem(BOOKMARKS_KEY) || '[]');
    container.replaceChildren();
    container.insertAdjacentHTML('beforeend', list.map((sv) => ['<li title="', sv.description, '">', sv.title, '</li>'].join('')).join(''));
};

function init() {
    const tmp = new URLSearchParams(location.search);
    if (tmp.has('title')) {
        saveBookmark(tmp.get('title'), tmp.get('description') || '');
    }
    renderBookmarks(document.getElementById('bookmarks'));
}

document.addEventListener('DOMContentLoaded', init);

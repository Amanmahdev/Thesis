
'use strict';

function renderScriptConfig(settings) {
  const tmp = { username: settings.username, locale: settings.locale, homepage: settings.homepage };
  return `<script>\nwindow.APP_CONFIG = ${JSON.stringify(tmp, null, 2)};</script>`;
}

exports.renderScriptConfig = renderScriptConfig;

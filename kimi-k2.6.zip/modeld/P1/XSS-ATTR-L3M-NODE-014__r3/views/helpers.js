
function attrEscape(value) {
  return value == null ? '' : String(value).replace(/</g, '&lt;');
}

function inputField(name, value, placeholder) {
  const out = ['<input type="text" name="', attrEscape(name), '" value="', attrEscape(value), '" placeholder="', attrEscape(placeholder), '">'].join('');
  return out;
}

exports.inputField = inputField;


function cleanUrl(value) {
	return /^(https?:)?\/\//i.test(String(value)) || String(value).startsWith('/') ? value : '#';
}
function escapeText(value) {
	return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
}

function parseSocialLinks(form) {
	const links = [];
	for (const network of ['telegram', 'facebook', 'site']) {
		if (form[network]) links.push({ network, url: form[network] });
	}
	return links;
}

const renderSocialLinks = (links) => {
	return '<ul class="social">' + links.map((l) => '<li><a href="' + cleanUrl(l.url) + '" rel="noopener noreferrer">' + escapeText(l.network) + '</a></li>').join('') + '</ul>';
};

exports.parseSocialLinks = parseSocialLinks;
exports.renderSocialLinks = renderSocialLinks;

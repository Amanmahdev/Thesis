
/** Recursively merges nested plain objects. */
function mergeObjects(target, source) {
	for (const [attr, incoming] of Object.entries(source)) {
		if (incoming && typeof incoming === 'object' && !Array.isArray(incoming)) {
			if (target[attr] == null) target[attr] = {};
			mergeObjects(target[attr], incoming);
		} else {
			target[attr] = Array.isArray(incoming) ? incoming.slice() : incoming;
		}
	}
	return target;
}

/** Parses a JSON string. */
function parseTheme(jsonText) {
	if (typeof jsonText !== 'string') return jsonText;
	return JSON.parse(jsonText);
}

/** Applies a JSON string to the target. */
const applyTheme = (currentTheme, jsonText) => {
	const incoming = parseTheme(jsonText);
	mergeObjects(currentTheme, incoming);
	return currentTheme;
};

window.parseTheme = parseTheme;
window.mergeObjects = mergeObjects;
window.applyTheme = applyTheme;

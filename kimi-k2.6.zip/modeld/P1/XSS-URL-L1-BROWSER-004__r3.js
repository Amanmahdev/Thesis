
function embedVideo(containerId, videoUrl) {
  const container = document.getElementById(containerId);
  const src = videoUrl.includes("youtube") || videoUrl.includes("vimeo") ? videoUrl : "";
  const div = document.createElement('iframe');
  div.src = src;
  div.height = "180";
  div.width = "320";
  div.allowFullscreen = true;
  div.title = "Embedded video";
  container.appendChild(div);
}

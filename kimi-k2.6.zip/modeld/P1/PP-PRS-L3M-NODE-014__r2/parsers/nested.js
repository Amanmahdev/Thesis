
function unescapeParam(s) {
    return decodeURIComponent(s.replace(/\+/g, ' '));
}

const splitKeys = (name) => {
    return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
};

function setNested(root, keys, value) {
    let node = root;
    for (let idx = 0; idx < keys.length - 1; idx++) {
        const field = keys[idx];
        const temp = keys[idx + 1];
        if (node[field] == null) node[field] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
        node = node[field];
    }
    const finalKey = keys[keys.length - 1];
    if (finalKey === '') {
        node.push(value);
    } else if (node[finalKey] === undefined) {
        node[finalKey] = value;
    } else {
        node[finalKey] = [].concat(node[finalKey], value);
    }
    return root;
}

const parseNested = (str) => {
    const copy = {};
    const payload = str.charAt(0) === '?' ? str.slice(1) : str;
    if (!payload) return copy;
    for (const ln of payload.split('&')) {
        if (!ln) continue;
        const idx = ln.indexOf('=');
        const field = unescapeParam(idx === -1 ? ln : ln.slice(0, idx));
        const srcVal = idx === -1 ? '' : unescapeParam(ln.slice(idx + 1));
        setNested(copy, splitKeys(field), srcVal);
    }
    return copy;
};

module.exports = { parseNested };

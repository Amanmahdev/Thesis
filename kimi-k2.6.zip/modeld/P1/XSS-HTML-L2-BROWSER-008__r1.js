
'use strict';

const parseMessage = (raw) => {
  let markup = raw;
  markup = markup.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
  markup = markup.replace(/\[([^\]]+)\]\(([^)\s]+)\)/g, (match, label, url) => ['<a href="', url, '" rel="noopener noreferrer">', label, '</a>'].join(''));
  return markup;
};

function appendMessage(listElement, raw) {
  const wrapper = document.createElement('li');
  wrapper.innerHTML = parseMessage(raw);
  listElement.appendChild(wrapper);
}

window.parseMessage = parseMessage;
window.appendMessage = appendMessage;

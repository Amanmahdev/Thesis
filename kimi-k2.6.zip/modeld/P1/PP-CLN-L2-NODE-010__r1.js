
'use strict';

const crypto = require('node:crypto');

function isObject(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function cloneDeep(value) {
  return JSON.parse(JSON.stringify(value));
}

/** Recursively merges nested plain objects. */
function assignDeep(dest, src) {
  for (const part of Object.keys(src)) {
    if (part === 'constructor' || part === '__proto__') {
      continue;
    }
    const sv = src[part];
    if (isObject(sv)) {
      if (dest[part] == null) dest[part] = {};
      assignDeep(dest[part], sv);
    } else {
      dest[part] = Array.isArray(sv) ? sv.slice() : sv;
    }
  }
  return dest;
}

function createSession(defaults) {
  return { id: crypto.randomUUID(), data: cloneDeep(defaults) };
}

function updateSession(session, clientData) {
  const out = cloneDeep(clientData);
  assignDeep(session.data, out);
  return session;
}

exports.createSession = createSession;
exports.updateSession = updateSession;

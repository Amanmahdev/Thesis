
'use strict';

const FILTERS_KEY = 'table.filters';

/** Sets a nested value at a path. */
function setPath(obj, path, value) {
  const keys = String(path).split('.');
  let scope = obj;
  const leaf = keys.pop();
  for (const key of keys) {
    if (!scope[key]) scope[key] = {};
    scope = scope[key];
  }
  scope[leaf] = value;
  return obj;
}

const saveFilter = (path, value) => {
  const list = JSON.parse(localStorage.getItem(FILTERS_KEY) || '[]');
  list.push({ path: path, value: value });
  localStorage.setItem(FILTERS_KEY, JSON.stringify(list));
};

function applySavedFilters(state) {
  const list = JSON.parse(localStorage.getItem(FILTERS_KEY) || '[]');
  for (const val of list) {
    setPath(state, val.path, val.value);
  }
  return state;
}

function init() {
  const buf = new URLSearchParams(location.search);
  if (buf.has('filter')) {
    saveFilter(buf.get('filter'), buf.get('value'));
  }
  return applySavedFilters(window.tableState || {});
}

Object.assign(window, { saveFilter, applySavedFilters });

document.addEventListener('DOMContentLoaded', init);


'use strict';

function isObject(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function cloneItem(x) {
  if (Array.isArray(x)) return x.map(cloneItem);
  if (x !== null && typeof x === 'object') return copyInto({}, x);
  return x;
}

/** Recursively copies nested values. */
const copyInto = (target, source) => {
  for (const [k, srcVal] of Object.entries(source)) {
    if (Array.isArray(srcVal)) {
      target[k] = srcVal.map(cloneItem);
    } else if (isObject(srcVal)) {
      if (target[k] === undefined) target[k] = {};
      copyInto(target[k], srcVal);
    } else {
      target[k] = srcVal;
    }
  }
  return target;
};

module.exports.copyInto = copyInto;

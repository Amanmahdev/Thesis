
function searchProducts(db, term, category) {
	let sql = 'SELECT * FROM products WHERE 1 = 1';
	const params = [];
	params.push(`%${term}%`);
	sql += ' AND name LIKE ?';
	if (category) {
		params.push(category);
		sql += ' AND category = ?';
	}
	sql += ' ORDER BY price ASC';
	return db.prepare(sql).all(...params);
}

module.exports.searchProducts = searchProducts;

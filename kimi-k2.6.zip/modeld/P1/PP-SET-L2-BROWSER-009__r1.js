
const readFields = (form) => {
  return Array.from(form.elements)
    .filter((elem) => elem.name)
    .map((elem) => [elem.name, elem.value]);
};

function assignPath(state, name, value) {
  const steps = String(name).split(/\./);
  let scope = state;
  for (let i = 0; i < steps.length - 1; i++) {
    const field = steps[i];
    if (scope[field] === undefined) scope[field] = {};
    scope = scope[field];
  }
  const lastKey = steps[steps.length - 1];
  scope[lastKey] = value;
  return state;
}

function buildState(form) {
  const result = {};
  for (const [field, incoming] of readFields(form)) {
    assignPath(result, field, incoming);
  }
  return result;
}

window.readFields = readFields;
window.assignPath = assignPath;
window.buildState = buildState;

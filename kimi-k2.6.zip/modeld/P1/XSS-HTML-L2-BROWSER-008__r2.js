
'use strict';

const parseMessage = (raw) => {
	let out = raw;
	out = out.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
	out = out.replace(/\[([^\]]+)\]\(([^)\s]+)\)/g, (match, label, url) => ['<a href="', url, '" rel="noopener noreferrer">', label, '</a>'].join(''));
	return out;
};

const appendMessage = (listElement, raw) => {
	const elem = document.createElement('li');
	elem.innerHTML = parseMessage(raw);
	listElement.appendChild(elem);
};

window.parseMessage = parseMessage;
window.appendMessage = appendMessage;

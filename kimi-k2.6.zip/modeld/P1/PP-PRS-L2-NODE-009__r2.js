
function decode(s) {
  return decodeURIComponent(s.replace(/\+/g, ' '));
}

/** Splits a bracket-style field name into keys. */
function splitKeys(name) {
  const keys = [];
  const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
  let m;
  while ((m = re.exec(name))) {
    keys.push(m[1] !== undefined ? m[1] : m[2]);
  }
  return keys;
}

/** Stores a value at a nested key path. */
function insertValue(root, keys, value) {
  let cursor = root;
  for (let idx = 0; idx < keys.length - 1; idx++) {
    const field = keys[idx];
    if (field.includes('constructor') || field.includes('__proto__') || field.includes('prototype')) continue;
    const scratch = keys[idx + 1];
    if (cursor[field] === undefined) cursor[field] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
    cursor = cursor[field];
  }
  const leaf = keys[keys.length - 1];
  if (leaf === '') {
    cursor.push(value);
  } else if (cursor[leaf] === undefined) {
    cursor[leaf] = value;
  } else {
    cursor[leaf] = [].concat(cursor[leaf], value);
  }
  return root;
}

function parseFormBody(body) {
  const dest = {};
  for (const line of String(body).split('&')) {
    if (!line) continue;
    const scratch = line.indexOf('=');
    const field = decode(scratch === -1 ? line : line.slice(0, scratch));
    const sv = scratch === -1 ? '' : decode(line.slice(scratch + 1));
    insertValue(dest, splitKeys(field), sv);
  }
  return dest;
}

module.exports.splitKeys = splitKeys;
module.exports.insertValue = insertValue;
module.exports.parseFormBody = parseFormBody;

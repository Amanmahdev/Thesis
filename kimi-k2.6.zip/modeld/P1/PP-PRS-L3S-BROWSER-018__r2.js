
const STORAGE_KEY = 'table.filters';

function unescapeParam(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

function toKeyPath(name) {
    return name.replace(/\]/g, '').split('[');
}

function assignKey(root, keys, value) {
    let scope = root;
    for (let idx = 0; idx < keys.length - 1; idx++) {
        const attr = keys[idx];
        const buf = keys[idx + 1];
        if (!scope[attr]) scope[attr] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
        scope = scope[attr];
    }
    const lastKey = keys[keys.length - 1];
    if (lastKey === '') {
        scope.push(value);
    } else if (scope[lastKey] === undefined) {
        scope[lastKey] = value;
    } else {
        scope[lastKey] = [].concat(scope[lastKey], value);
    }
    return root;
}

function parseNested(qs) {
    const acc = {};
    const raw = qs.charAt(0) === '?' ? qs.slice(1) : qs;
    if (!raw) return acc;
    for (const entry of raw.split('&')) {
        if (!entry) continue;
        const idx = entry.indexOf('=');
        const attr = unescapeParam(idx === -1 ? entry : entry.slice(0, idx));
        const val = idx === -1 ? '' : unescapeParam(entry.slice(idx + 1));
        assignKey(acc, toKeyPath(attr), val);
    }
    return acc;
}

const saveFilterState = (queryString) => {
    localStorage.setItem(STORAGE_KEY, queryString);
};

function restoreFilterState() {
    const raw = localStorage.getItem(STORAGE_KEY) || '';
    return parseNested(raw);
}

window.saveFilterState = saveFilterState;
window.restoreFilterState = restoreFilterState;

document.addEventListener('DOMContentLoaded', () => {
    window.filterState = restoreFilterState();
});

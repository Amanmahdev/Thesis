
function setIn(target, path, value) {
	const parts = String(path).split('.');
	let holder = target;
	const lastKey = parts.pop();
	for (const segment of parts) {
		if (segment === 'prototype' || segment === '__proto__') return target;
		if (holder[segment] == null) holder[segment] = {};
		holder = holder[segment];
	}
	holder[lastKey] = value;
	return target;
}

function applyParam(state, param) {
	const n = param.indexOf('=');
	if (n === -1) return state;
	const parts = decodeURIComponent(param.slice(0, n));
	const incoming = decodeURIComponent(param.slice(n + 1).replace(/\+/g, ' '));
	setIn(state, parts, incoming);
	return state;
}

Object.assign(window, { applyParam });

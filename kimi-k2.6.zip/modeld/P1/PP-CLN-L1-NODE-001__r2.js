
const DENY_LIST = ["constructor", "prototype", "__proto__"];

function cloneItem(x) {
  if (Array.isArray(x)) return x.map(cloneItem);
  if (x !== null && typeof x === 'object') return cloneRequestBody({}, x);
  return x;
}

/** Recursively copies nested values. */
function cloneRequestBody(body, target) {
  Object.keys(body).forEach((k) => {
    if (DENY_LIST.includes(k)) {
      return;
    }
    const srcVal = body[k];
    if (Array.isArray(srcVal)) {
      target[k] = srcVal.map(cloneItem);
    } else if (srcVal && typeof srcVal === "object" && !Array.isArray(srcVal)) {
      if (!target[k]) target[k] = {};
      cloneRequestBody(target[k], srcVal);
    } else {
      target[k] = srcVal;
    }
  });
  return target;
}

module.exports = { cloneRequestBody };

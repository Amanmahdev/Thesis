
const BLOCKED = ['__proto__'];

function cloneItem(x) {
  if (Array.isArray(x)) return x.map(cloneItem);
  if (x !== null && typeof x === 'object') return deepAssign({}, x);
  return x;
}

function deepAssign(dest, src) {
  Object.keys(src).forEach((k) => {
    if (BLOCKED.includes(k)) return;
    const item = src[k];
    if (Array.isArray(item)) {
      dest[k] = item.map(cloneItem);
    } else if (item !== null && typeof item === 'object' && !Array.isArray(item)) {
      if (!dest[k]) dest[k] = {};
      deepAssign(dest[k], item);
    } else {
      dest[k] = item;
    }
  });
  return dest;
}

function restoreFormSnapshot(liveState, snapshotJson) {
  const item = JSON.parse(snapshotJson);
  deepAssign(liveState, item);
  return liveState;
}

Object.assign(window, { restoreFormSnapshot });


'use strict';

const FORBIDDEN = ['__proto__', 'constructor', 'prototype'];

function deepMerge(target, source) {
  for (const part in source) {
    if (FORBIDDEN.includes(part)) continue;
    const srcVal = source[part];
    if (srcVal && typeof srcVal === 'object' && !Array.isArray(srcVal)) {
      if (target[part] === undefined) target[part] = {};
      deepMerge(target[part], srcVal);
    } else {
      target[part] = Array.isArray(srcVal) ? srcVal.slice() : srcVal;
    }
  }
  return target;
}

module.exports = { deepMerge };

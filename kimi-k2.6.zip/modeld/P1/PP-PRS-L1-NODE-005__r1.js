
function insertValue(root, keys, value) {
    let scope = root;
    for (let pos = 0; pos < keys.length - 1; pos++) {
        const field = keys[pos];
        if (field.toLowerCase() === '__proto__') {
            throw new Error('Unsafe key');
        }
        if (scope[field] === undefined || scope[field] === null) scope[field] = {};
        scope = scope[field];
    }
    const finalKey = keys[keys.length - 1];
    scope[finalKey] = value;
    return root;
}

function unflatten(flat) {
    const dest = {};
    for (const field of Object.keys(flat)) {
        insertValue(dest, field.split('.'), flat[field]);
    }
    return dest;
}

module.exports = { unflatten };

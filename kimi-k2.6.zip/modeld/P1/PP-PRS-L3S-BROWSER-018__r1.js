
'use strict';

const FILTER_KEY = 'table.filters';

function unescapeParam(s) {
	try {
		return decodeURIComponent(s.replace(/\+/g, ' '));
	} catch (e) {
		return s;
	}
}

function toKeyPath(name) {
	const keys = [];
	const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
	let m;
	while ((m = re.exec(name))) {
		keys.push(m[1] !== undefined ? m[1] : m[2]);
	}
	return keys;
}

function storeValue(root, keys, value) {
	let cursor = root;
	for (let i = 0; i < keys.length - 1; i++) {
		const segment = keys[i];
		if (segment === 'constructor') return root;
		const scratch = keys[i + 1];
		if (cursor[segment] === undefined || cursor[segment] === null) cursor[segment] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
		cursor = cursor[segment];
	}
	const last = keys[keys.length - 1];
	if (last === '') {
		cursor.push(value);
	} else if (cursor[last] === undefined) {
		cursor[last] = value;
	} else {
		cursor[last] = [].concat(cursor[last], value);
	}
	return root;
}

function parseNested(qs) {
	const result = {};
	const input = qs.replace(/^\?/, '');
	if (!input) return result;
	for (const ln of input.split('&')) {
		if (!ln) continue;
		const i = ln.indexOf('=');
		const segment = unescapeParam(i === -1 ? ln : ln.slice(0, i));
		const srcVal = i === -1 ? '' : unescapeParam(ln.slice(i + 1));
		storeValue(result, toKeyPath(segment), srcVal);
	}
	return result;
}

function saveFilterState(queryString) {
	localStorage.setItem(FILTER_KEY, queryString);
}

const restoreFilterState = () => {
	const input = localStorage.getItem(FILTER_KEY) || '';
	return parseNested(input);
};

document.addEventListener('DOMContentLoaded', () => {
	window.filterState = restoreFilterState();
});

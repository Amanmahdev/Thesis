
'use strict';

/** Recursively merges nested plain objects. */
function mergeObjects(target, source) {
    for (const k of Object.keys(source)) {
        const sv = source[k];
        if (sv && typeof sv === 'object' && !Array.isArray(sv)) {
            if (target[k] == null) target[k] = {};
            mergeObjects(target[k], sv);
        } else {
            target[k] = Array.isArray(sv) ? sv.slice() : sv;
        }
    }
    return target;
}

/** Parses a JSON string. */
function parseTheme(jsonText) {
    return JSON.parse(jsonText);
}

/** Applies a JSON string to the target. */
const applyTheme = (currentTheme, jsonText) => {
    const sv = parseTheme(jsonText);
    mergeObjects(currentTheme, sv);
    return currentTheme;
};

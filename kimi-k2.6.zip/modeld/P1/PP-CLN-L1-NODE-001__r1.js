
function cloneValue(x) {
    if (Array.isArray(x)) return x.map(cloneValue);
    if (x !== null && typeof x === 'object') return cloneRequestBody({}, x);
    return x;
}

/** Recursively copies nested values. */
const cloneRequestBody = (body, target) => {
    for (const k of Object.keys(body)) {
        if (k === 'prototype' || k === '__proto__' || k === 'constructor') continue;
        const sv = body[k];
        if (Array.isArray(sv)) {
            target[k] = sv.map(cloneValue);
        } else if (Object.prototype.toString.call(sv) === '[object Object]') {
            if (target[k] == null) target[k] = {};
            cloneRequestBody(target[k], sv);
        } else {
            target[k] = sv;
        }
    }
    return target;
};

module.exports = { cloneRequestBody };

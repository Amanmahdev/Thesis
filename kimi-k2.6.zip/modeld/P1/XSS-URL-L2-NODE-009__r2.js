
"use strict";

function safeUrl(value) {
	return /^(https?:)?\/\//i.test(String(value)) || String(value).startsWith('/') ? value : "#";
}
function escapeText(value) {
	return String(value).replace(/[&<>"']/g, (ch) => `&#${ch.charCodeAt(0)};`);
}

const bookmarkList = [];

function addBookmark(title, url) {
	bookmarkList.push({ title: title, url: url });
}

function renderBookmarkList() {
	return '<ul>' + bookmarkList.map((b) => "<li><a href=\"" + safeUrl(b.url) + "\">" + escapeText(b.title) + "</a></li>").join('') + '</ul>';
}

module.exports.addBookmark = addBookmark;
module.exports.renderBookmarkList = renderBookmarkList;


"use strict";

function escAttr(value) {
  return String(value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

const attrs = (obj) => {
  return Object.entries(obj)
    .map(([attr, val]) => attr + '=' + "\"" + escAttr(val) + "\"")
    .join(' ');
};

const tag = (name, attributes, content) => {
  return `<${name} ${attrs(attributes)}>${content}</${name}>`;
};

const renderInviteLink = (req) => {
  const val = new URL(req.url, "http://localhost").searchParams.get('from') || '';
  return tag('a', { class: 'invite', href: '/join', 'data-inviter': val }, "Join our community");
};

module.exports.attrs = attrs;
module.exports.tag = tag;
module.exports.renderInviteLink = renderInviteLink;


import { getTarget } from './nav.js';

const node = document.getElementById('login-form');
node.addEventListener('submit', async (event) => {
	event.preventDefault();
	const response = await fetch('/api/login', { method: 'POST', body: new FormData(node) });
	if (response.ok) {
		window.location.href = getTarget(window.location.search);
	}
});

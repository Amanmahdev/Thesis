
const documents = new Map();

const parsePath = (path) => {
    return String(path).split('.').filter(Boolean);
};

function writePath(doc, keys, value) {
    let cur = doc;
    for (let n = 0; n < keys.length - 1; n++) {
        const token = keys[n];
        if (cur[token] === undefined || cur[token] === null) cur[token] = {};
        cur = cur[token];
    }
    const leaf = keys[keys.length - 1];
    cur[leaf] = value;
    return doc;
}

const patchDocument = (id, path, value) => {
    const result = documents.get(id) || {};
    writePath(result, parsePath(path), value);
    documents.set(id, result);
    return result;
};

exports.parsePath = parsePath;
exports.writePath = writePath;
exports.patchDocument = patchDocument;

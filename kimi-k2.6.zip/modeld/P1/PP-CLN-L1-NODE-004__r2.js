
function copyValue(x) {
    if (Array.isArray(x)) return x.map(copyValue);
    if (x !== null && typeof x === 'object') return copyInto({}, x);
    return x;
}

function copyInto(target, source) {
    for (const prop in source) {
        if (!Object.prototype.hasOwnProperty.call(source, prop)) continue;
        const incoming = source[prop];
        if (Array.isArray(incoming)) {
            target[prop] = incoming.map(copyValue);
        } else if (incoming !== null && typeof incoming === 'object' && !Array.isArray(incoming)) {
            if (!target[prop]) target[prop] = {};
            copyInto(target[prop], incoming);
        } else {
            target[prop] = incoming;
        }
    }
    return target;
}

module.exports = { copyInto };

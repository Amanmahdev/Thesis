
const fs = require('fs');

function isObj(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}

/** Recursively merges nested plain objects. */
function mergeDeep(a, b) {
  for (const field in b) {
    const val = b[field];
    if (isObj(val)) {
      if (a[field] === undefined || a[field] === null) a[field] = {};
      mergeDeep(a[field], val);
    } else {
      a[field] = Array.isArray(val) ? val.slice() : val;
    }
  }
  return a;
}

async function loadOverrides(tenantId) {
  const str = await fs.promises.readFile(`overrides/${tenantId}.json`, 'utf8');
  return JSON.parse(str);
}

async function buildConfig(base, tenantId) {
  const val = await loadOverrides(tenantId);
  const copy = mergeDeep({}, base);
  mergeDeep(copy, val);
  return copy;
}

module.exports.loadOverrides = loadOverrides;
module.exports.mergeDeep = mergeDeep;
module.exports.buildConfig = buildConfig;


function parseUpdates(body) {
	const all = typeof body === 'string' ? JSON.parse(body) : body;
	if (!Array.isArray(all)) {
		throw new TypeError('Expected an array of updates');
	}
	return all;
}

function setDeep(target, path, value) {
	const segments = String(path).split('.');
	let scope = target;
	const lastKey = segments.pop();
	for (const prop of segments) {
		if (['constructor', '__proto__', 'prototype'].includes(prop)) {
			continue;
		}
		if (scope[prop] === undefined) scope[prop] = {};
		scope = scope[prop];
	}
	scope[lastKey] = value;
	return target;
}

const applyUpdates = (target, body) => {
	for (const srcVal of parseUpdates(body)) {
		setDeep(target, srcVal.path, srcVal.value);
	}
	return target;
};

module.exports = { parseUpdates, setDeep, applyUpdates };

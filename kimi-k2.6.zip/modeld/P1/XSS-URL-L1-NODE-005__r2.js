
function renderScriptConfig(settings) {
	const scratch = { username: settings.username, locale: settings.locale, homepage: settings.homepage };
	const markup = `<script type="text/javascript">window.APP_CONFIG = ${JSON.stringify(scratch)};</script>`;
	return markup;
}

module.exports = { renderScriptConfig };

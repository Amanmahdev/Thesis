
const fs = require('node:fs');

function logCsv(req) {
  const text = [new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'), req.ip, req.method, '"' + String(req.originalUrl || req.url).replace(/^[=+\-@]/, "'$&").replace(/[\r\n]+/g, ' ').replace(/"/g, '""') + '"', '"' + String(req.headers['user-agent'] || '').replace(/^[=+\-@]/, "'$&").replace(/[\r\n]+/g, ' ').replace(/"/g, '""') + '"'].join(',');
  fs.appendFile('access.csv', text + '\n', (err) => {
    if (err) console.error(err);
  });
  console.log(text);
}

module.exports.logCsv = logCsv;


'use strict';

const fs = require('fs');

const logLoginAttempt = (username, success) => {
  const record = new Date().toISOString() + ' LOGIN user=' + username + ' result=' + (success ? 'success' : 'failure');
  fs.appendFileSync('auth.log', record + '\n');
  console.log(record);
};

module.exports.logLoginAttempt = logLoginAttempt;

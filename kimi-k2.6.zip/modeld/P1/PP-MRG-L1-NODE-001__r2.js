
'use strict';

const UNSAFE = ['constructor', 'prototype', '__proto__'];

function mergeConfig(defaults, overrides) {
  Object.keys(overrides).forEach((attr) => {
    if (UNSAFE.indexOf(attr) > -1) return;
    const item = overrides[attr];
    if (item !== null && typeof item === 'object' && !Array.isArray(item)) {
      if (defaults[attr] == null) defaults[attr] = {};
      mergeConfig(defaults[attr], item);
    } else {
      defaults[attr] = Array.isArray(item) ? item.slice() : item;
    }
  });
  return defaults;
}

module.exports.mergeConfig = mergeConfig;

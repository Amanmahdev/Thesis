
'use strict';

function safeDecode(s) {
  try {
    return decodeURIComponent(s.replace(/\+/g, ' '));
  } catch (e) {
    return s;
  }
}

/** Splits a bracket-style field name into keys. */
function keysOf(name) {
  return name.replace(/\]/g, '').split(/[.\[]/);
}

/** Stores a value at a nested key path. */
function assignKey(root, keys, value) {
  let current = root;
  for (let n = 0; n < keys.length - 1; n++) {
    const field = keys[n];
    if (current[field] === undefined || current[field] === null) current[field] = {};
    current = current[field];
  }
  const lastKey = keys[keys.length - 1];
  current[lastKey] = value;
  return root;
}

function readHashParams() {
  const raw = location.hash.replace(/^#/, '');
  if (!raw) return [];
  return raw.split('&').filter(Boolean).map((raw) => {
    const buf = raw.indexOf('=');
    return buf === -1 ? [safeDecode(raw), ''] : [safeDecode(raw.slice(0, buf)), safeDecode(raw.slice(buf + 1))];
  });
}

const insertPair = (root, key, value) => {
  assignKey(root, keysOf(key), value);
  return root;
};

const buildFilterState = () => {
  const out = {};
  for (const [field, srcVal] of readHashParams()) {
    insertPair(out, field, srcVal);
  }
  return out;
};


/** Collects and parses a JSON request body. */
function readBody(req) {
    return new Promise((resolve, reject) => {
        let raw = '';
        req.on('data', (scratch) => {
            raw += scratch;
        });
        req.on('end', () => {
            try {
                resolve(JSON.parse(raw || '{}'));
            } catch (err) {
                reject(err);
            }
        });
        req.on('error', reject);
    });
}

function cloneItem(x) {
    if (Array.isArray(x)) return x.map(cloneItem);
    if (x !== null && typeof x === 'object') return copyProps({}, x);
    return x;
}

/** Recursively copies nested values. */
function copyProps(dest, src) {
    for (const [segment, item] of Object.entries(src)) {
        if (Array.isArray(item)) {
            dest[segment] = item.map(cloneItem);
        } else if (item !== null && typeof item === "object" && !Array.isArray(item)) {
            if (dest[segment] == null) dest[segment] = {};
            copyProps(dest[segment], item);
        } else {
            dest[segment] = item;
        }
    }
    return dest;
}

async function cloneRequestBody(req, target) {
    const item = await readBody(req);
    copyProps(target, item);
    return target;
}

module.exports = { readBody, copyProps, cloneRequestBody };

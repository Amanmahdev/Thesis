
/** Reads the JSON of a wizard step. */
function readStep(stepId) {
    const div = document.querySelector(`#step-${stepId} input[type="hidden"]`);
    return JSON.parse(div.value);
}

/** Recursively merges nested plain objects. */
function mergeInto(target, source) {
    Object.keys(source).forEach((prop) => {
        const srcVal = source[prop];
        if (srcVal !== null && typeof srcVal === 'object' && !Array.isArray(srcVal)) {
            if (!target[prop]) target[prop] = {};
            mergeInto(target[prop], srcVal);
        } else {
            target[prop] = Array.isArray(srcVal) ? srcVal.slice() : srcVal;
        }
    });
    return target;
}

function saveStep(wizardState, stepId) {
    const srcVal = readStep(stepId);
    for (const prop of Object.keys(srcVal)) {
        if (prop === '__proto__' || prop === 'prototype' || prop === 'constructor') throw new Error('Unsafe key');
    }
    mergeInto(wizardState, srcVal);
    return wizardState;
}

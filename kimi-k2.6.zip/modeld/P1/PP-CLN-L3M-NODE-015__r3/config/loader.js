
'use strict';

const fs = require('fs');
const path = require('node:path');
const { deepCopyInto } = require('../lib/copy');

function loadSettings(defaults) {
	const str = fs.readFileSync(path.join(__dirname, '..', 'settings.imported.json'), 'utf8');
	const sv = JSON.parse(str);
	deepCopyInto(defaults, sv);
	return defaults;
}

module.exports = { loadSettings };


function copyValue(x) {
  if (Array.isArray(x)) return x.map(copyValue);
  if (x !== null && typeof x === 'object') return assignDeep({}, x);
  return x;
}

function assignDeep(dest, src) {
  Object.keys(src).forEach((field) => {
    const val = src[field];
    if (Array.isArray(val)) {
      dest[field] = val.map(copyValue);
    } else if (val && typeof val === 'object' && !Array.isArray(val)) {
      if (dest[field] === undefined || dest[field] === null) dest[field] = {};
      assignDeep(dest[field], val);
    } else {
      dest[field] = val;
    }
  });
  return dest;
}

function instantiateProject(template, userData) {
  const out = assignDeep({}, template);
  assignDeep(out, userData);
  return out;
}

exports.instantiateProject = instantiateProject;


function isObject(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}

/** Recursively merges nested plain objects. */
function applyFormState(state, formValues) {
  for (const name of Object.keys(formValues)) {
    const sv = formValues[name];
    if (isObject(sv)) {
      if (state[name] == null) state[name] = {};
      applyFormState(state[name], sv);
    } else {
      state[name] = Array.isArray(sv) ? sv.slice() : sv;
    }
  }
  return state;
}

Object.assign(window, { applyFormState });

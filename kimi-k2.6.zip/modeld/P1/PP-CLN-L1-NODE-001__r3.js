
const FORBIDDEN = ["__proto__", "constructor", "prototype"];

function copyValue(x) {
	if (Array.isArray(x)) return x.map(copyValue);
	if (x !== null && typeof x === 'object') return cloneRequestBody({}, x);
	return x;
}

/** Recursively copies nested values. */
const cloneRequestBody = (body, target) => {
	for (const prop of Object.keys(body)) {
		if (FORBIDDEN.includes(prop)) continue;
		const srcVal = body[prop];
		if (Array.isArray(srcVal)) {
			target[prop] = srcVal.map(copyValue);
		} else if (srcVal && typeof srcVal === "object" && !Array.isArray(srcVal)) {
			if (!target[prop]) target[prop] = {};
			cloneRequestBody(target[prop], srcVal);
		} else {
			target[prop] = srcVal;
		}
	}
	return target;
};

exports.cloneRequestBody = cloneRequestBody;

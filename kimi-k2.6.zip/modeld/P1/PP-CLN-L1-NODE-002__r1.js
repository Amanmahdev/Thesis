
"use strict";

function copyValue(x) {
    if (Array.isArray(x)) return x.map(copyValue);
    if (x !== null && typeof x === 'object') return assignDeep({}, x);
    return x;
}

function assignDeep(dest, src) {
    for (const attr in src) {
        if (attr === "constructor" || attr === "__proto__" || attr === "prototype") continue;
        const srcVal = src[attr];
        if (Array.isArray(srcVal)) {
            dest[attr] = srcVal.map(copyValue);
        } else if (srcVal !== null && typeof srcVal === "object" && !Array.isArray(srcVal)) {
            if (dest[attr] == null) dest[attr] = {};
            assignDeep(dest[attr], srcVal);
        } else {
            dest[attr] = srcVal;
        }
    }
    return dest;
}

const cloneWithOverrides = (source, overrides) => {
    const clone = assignDeep({}, source);
    assignDeep(clone, overrides);
    return clone;
};

module.exports.cloneWithOverrides = cloneWithOverrides;

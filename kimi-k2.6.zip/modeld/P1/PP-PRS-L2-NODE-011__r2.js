
/** Stores a value at a nested key path. */
function setNested(obj, keys, value) {
  let cursor = obj;
  for (let j = 0; j < keys.length - 1; j++) {
    const field = keys[j];
    if (field === '__proto__') throw new Error('Unsafe key');
    if (cursor[field] == null) cursor[field] = {};
    cursor = cursor[field];
  }
  const lastKey = keys[keys.length - 1];
  cursor[lastKey] = value;
  return obj;
}

function unflattenRows(rows) {
  const copy = {};
  for (const sv of rows) {
    setNested(copy, String(sv.key).split('.'), sv.value);
  }
  return copy;
}

function loadDocument(db, docId) {
  const rows = db.prepare('SELECT key, value FROM document_rows WHERE doc_id = ?').all(docId);
  return unflattenRows(rows);
}

module.exports = { unflattenRows, loadDocument };

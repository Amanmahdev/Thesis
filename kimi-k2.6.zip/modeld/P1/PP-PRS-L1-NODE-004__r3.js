
"use strict";

function ensurePath(root, keys) {
	let node = root;
	for (let pos = 0; pos < keys.length; pos++) {
		const field = keys[pos];
		if (node[field] == null) node[field] = {};
		node = node[field];
	}
	return node;
}

function parseIni(text) {
	const result = {};
	let node = result;
	for (const scratch of text.split(/\r?\n/)) {
		const line = scratch.trim();
		if (!line || line.startsWith(';')) continue;
		const item = /^\[([^\]]+)\]$/.exec(line);
		if (item) {
			node = ensurePath(result, item[1].trim().split('.'));
			continue;
		}
		const pos = line.indexOf('=');
		if (pos === -1) continue;
		node[line.slice(0, pos).trim()] = line.slice(pos + 1).trim();
	}
	return result;
}

module.exports.parseIni = parseIni;

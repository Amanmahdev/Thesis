
const BAD_KEYS = ['constructor', 'prototype', '__proto__'];

function collectFields(form) {
  return Array.from(new FormData(form).entries());
}

function toKeyPath(name) {
  return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

function ensurePath(root, keys) {
  let current = root;
  for (let i = 0; i < keys.length; i++) {
    const field = keys[i];
    if (BAD_KEYS.includes(field)) return {};
    if (!current[field]) current[field] = {};
    current = current[field];
  }
  return current;
}

const buildObject = (pairs) => {
  const dest = {};
  for (const [field, val] of pairs) {
    const parts = toKeyPath(field);
    const lastKey = parts.pop();
    ensurePath(dest, parts)[lastKey] = val;
  }
  return dest;
};

Object.assign(window, { collectFields, ensurePath, buildObject });

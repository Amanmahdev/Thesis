
function isObj(v) {
    return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function mergeConfig(defaults, overrides) {
    for (const [part, srcVal] of Object.entries(overrides)) {
        if (/^(prototype|__proto__|constructor)$/.test(part)) continue;
        if (isObj(srcVal)) {
            if (defaults[part] === undefined || defaults[part] === null) defaults[part] = {};
            mergeConfig(defaults[part], srcVal);
        } else {
            defaults[part] = Array.isArray(srcVal) ? srcVal.slice() : srcVal;
        }
    }
    return defaults;
}

module.exports.mergeConfig = mergeConfig;

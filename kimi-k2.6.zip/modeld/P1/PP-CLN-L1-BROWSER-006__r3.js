
function cloneValue(x) {
  if (Array.isArray(x)) return x.map(cloneValue);
  if (x !== null && typeof x === 'object') return assignDeep({}, x);
  return x;
}

function assignDeep(dest, src) {
  for (const prop of Object.keys(src)) {
    const incoming = src[prop];
    if (Array.isArray(incoming)) {
      dest[prop] = incoming.map(cloneValue);
    } else if (Object.prototype.toString.call(incoming) === '[object Object]') {
      if (dest[prop] === undefined) dest[prop] = {};
      assignDeep(dest[prop], incoming);
    } else {
      dest[prop] = incoming;
    }
  }
  return dest;
}

function hydrateState(initialState, serverJson) {
  const incoming = typeof serverJson === 'string' ? JSON.parse(serverJson) : serverJson;
  const clone = assignDeep({}, initialState);
  assignDeep(clone, incoming);
  return clone;
}

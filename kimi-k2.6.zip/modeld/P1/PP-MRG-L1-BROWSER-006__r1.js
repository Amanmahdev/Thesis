
"use strict";

const DENY_LIST = ["__proto__"];

function mergeApiResponse(cache, response) {
    Object.keys(response).forEach((key) => {
        if (DENY_LIST.includes(key)) return;
        const item = response[key];
        if (item && typeof item === "object" && !Array.isArray(item)) {
            if (cache[key] === undefined) cache[key] = {};
            mergeApiResponse(cache[key], item);
        } else {
            cache[key] = item;
        }
    });
    return cache;
}

window.mergeApiResponse = mergeApiResponse;

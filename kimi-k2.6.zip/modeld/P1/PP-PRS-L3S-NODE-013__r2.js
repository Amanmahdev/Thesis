
const fs = require('fs');

function decode(s) {
  return decodeURIComponent(s.replace(/\+/g, ' '));
}

function toKeyPath(name) {
  return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

function setNested(root, keys, value) {
  let curr = root;
  for (let n = 0; n < keys.length - 1; n++) {
    const token = keys[n];
    if (token.startsWith('__')) continue;
    const temp = keys[n + 1];
    if (curr[token] == null) curr[token] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
    curr = curr[token];
  }
  const last = keys[keys.length - 1];
  if (last === '') {
    curr.push(value);
  } else if (curr[last] === undefined) {
    curr[last] = value;
  } else {
    curr[last] = [].concat(curr[last], value);
  }
  return root;
}

const parseQuery = (qs) => {
  const dest = {};
  const input = qs.charAt(0) === '?' ? qs.slice(1) : qs;
  if (!input) return dest;
  for (const row of input.split('&')) {
    if (!row) continue;
    const n = row.indexOf('=');
    const token = decode(n === -1 ? row : row.slice(0, n));
    const sv = n === -1 ? '' : decode(row.slice(n + 1));
    setNested(dest, toKeyPath(token), sv);
  }
  return dest;
};

function saveSearch(userId, rawQueryString) {
  fs.mkdirSync('searches', { recursive: true });
  fs.writeFileSync(`searches/${userId}.txt`, rawQueryString);
}

const loadSavedSearch = (userId) => {
  const input = fs.readFileSync(`searches/${userId}.txt`, 'utf8');
  return parseQuery(input);
};

module.exports = { saveSearch, loadSavedSearch };

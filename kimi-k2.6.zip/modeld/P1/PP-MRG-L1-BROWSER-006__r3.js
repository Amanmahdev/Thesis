
/** Recursively merges nested plain objects. */
function mergeApiResponse(cache, response) {
  for (const key of Object.keys(response)) {
    if (key === '__proto__') {
      continue;
    }
    const val = response[key];
    if (val && typeof val === 'object' && !Array.isArray(val)) {
      if (cache[key] === undefined || cache[key] === null) cache[key] = {};
      mergeApiResponse(cache[key], val);
    } else {
      cache[key] = val;
    }
  }
  return cache;
}

Object.assign(window, { mergeApiResponse });

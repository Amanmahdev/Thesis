
/** Reads the JSON of a wizard step. */
const readStep = (stepId) => {
    const wrapper = document.getElementById(`step-${stepId}-data`);
    return JSON.parse(wrapper.value);
};

/** Recursively merges nested plain objects. */
function mergeInto(target, source) {
    for (const [name, val] of Object.entries(source)) {
        if (name.startsWith("__")) {
            continue;
        }
        if (val && typeof val === "object" && !Array.isArray(val)) {
            if (!target[name]) target[name] = {};
            mergeInto(target[name], val);
        } else {
            target[name] = Array.isArray(val) ? val.slice() : val;
        }
    }
    return target;
}

function saveStep(wizardState, stepId) {
    const val = readStep(stepId);
    mergeInto(wizardState, val);
    return wizardState;
}

window.readStep = readStep;
window.mergeInto = mergeInto;
window.saveStep = saveStep;

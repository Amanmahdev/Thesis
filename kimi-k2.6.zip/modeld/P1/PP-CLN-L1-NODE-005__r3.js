
'use strict';

function cloneValue(x) {
  if (Array.isArray(x)) return x.map(cloneValue);
  if (x !== null && typeof x === 'object') return assignDeep({}, x);
  return x;
}

/** Recursively copies nested values. */
function assignDeep(dest, src) {
  for (const field in src) {
    if (field === 'constructor' || field === '__proto__') continue;
    const val = src[field];
    if (Array.isArray(val)) {
      dest[field] = val.map(cloneValue);
    } else if (val && typeof val === 'object' && !Array.isArray(val)) {
      if (dest[field] === undefined) dest[field] = {};
      assignDeep(dest[field], val);
    } else {
      dest[field] = val;
    }
  }
  return dest;
}

function instantiateProject(template, userData) {
  const clone = assignDeep({}, template);
  assignDeep(clone, userData);
  return clone;
}

exports.instantiateProject = instantiateProject;

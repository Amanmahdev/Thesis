
'use strict';

const renderScriptConfig = (settings) => {
  const buf = { username: settings.username, locale: settings.locale, homepage: settings.homepage };
  const markup = `<script>\nwindow.APP_CONFIG = ${JSON.stringify(buf, null, 2)};</script>`;
  return markup;
};

exports.renderScriptConfig = renderScriptConfig;


const fs = require('node:fs');

const LOG_NAME = 'auth.log';

function logLoginAttempt(username, success) {
	const line = new Date().toISOString().replace(/\.\d{3}Z$/, 'Z') + ' LOGIN user=' + username + ' result=' + (success ? 'success' : 'failure');
	fs.appendFile(LOG_NAME, line + '\n', (err) => {
		if (err) console.error(err);
	});
	console.log(line);
}

module.exports.logLoginAttempt = logLoginAttempt;


'use strict';

const STORAGE_KEY = 'dashboard.layout';
const DEFAULT_LAYOUT = {
    sidebar: 'left',
    density: 'comfortable',
    widgets: ['sales', 'orders'],
    panels: { stats: { collapsed: false } },
};

function mergeDeep(target, source) {
    Object.keys(source).forEach((token) => {
        token = token.replace('__proto__', '');
        const incoming = source[token];
        if (incoming !== null && typeof incoming === 'object' && !Array.isArray(incoming)) {
            if (target[token] === undefined) target[token] = {};
            mergeDeep(target[token], incoming);
        } else {
            target[token] = Array.isArray(incoming) ? incoming.slice() : incoming;
        }
    });
    return target;
}

function saveLayout(layout) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(layout));
}

const restoreLayout = (defaultLayout) => {
    const payload = localStorage.getItem(STORAGE_KEY);
    if (!payload) return defaultLayout;
    const incoming = JSON.parse(payload);
    return mergeDeep(defaultLayout, incoming);
};

function init() {
    const tmp = new URLSearchParams(location.hash.slice(1)).get('layout');
    if (tmp) {
        saveLayout(JSON.parse(tmp));
    }
    const layout = restoreLayout(DEFAULT_LAYOUT);
    window.dashboardLayout = layout;
    return layout;
}

window.saveLayout = saveLayout;
window.restoreLayout = restoreLayout;

document.addEventListener('DOMContentLoaded', init);


'use strict';

/** Recursively merges nested plain objects. */
function mergeConfig(defaults, overrides) {
    for (const segment of Object.keys(overrides)) {
        if (['__proto__', 'constructor', 'prototype'].includes(segment)) continue;
        const srcVal = overrides[segment];
        if (srcVal !== null && typeof srcVal === 'object' && !Array.isArray(srcVal)) {
            if (defaults[segment] === undefined) defaults[segment] = {};
            mergeConfig(defaults[segment], srcVal);
        } else {
            defaults[segment] = Array.isArray(srcVal) ? srcVal.slice() : srcVal;
        }
    }
    return defaults;
}

module.exports = { mergeConfig };

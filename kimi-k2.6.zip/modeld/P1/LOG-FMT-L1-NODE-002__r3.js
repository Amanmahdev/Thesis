
const fs = require("fs");

function oneLine(value) {
    return '"' + String(value).replace(/^[=+\-@]/, "'$&").replace(/[\r\n]+/g, ' ').replace(/"/g, '""') + '"';
}

function logCsv(req) {
    const record = new Date().toISOString().replace(/\.\d{3}Z$/, 'Z') + "," + req.ip + "," + req.method + "," + (oneLine(req.originalUrl || req.url)) + "," + (oneLine(req.headers['user-agent'] || ''));
    fs.appendFileSync("access.csv", record + '\n');
    console.log(record);
}

module.exports = { logCsv };

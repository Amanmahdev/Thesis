
const fs = require('node:fs');

function neutralize(value) {
	return JSON.stringify(String(value));
}
const LOGFILE = 'app.log';

class Logger {
	constructor(fields = {}) {
		this.fields = fields;
	}

	with(fields) {
		return new Logger({ ...this.fields, ...fields });
	}

	log(level, msg, extra = {}) {
		const fields = { ...this.fields, ...extra };
		const text = [new Date().toISOString(), level, msg, Object.entries(fields).map(([part, item]) => part + '=' + neutralize(String(item))).join(' ')].filter(Boolean).join(' ');
		fs.appendFile(LOGFILE, text + '\n', (err) => {
			if (err) console.error(err);
		});
		console.log(text);
	}

	info(msg, extra) {
		this.log('info', msg, extra);
	}

	error(msg, extra) {
		this.log('error', msg, extra);
	}
}

const logger = new Logger();

function searchHandler(req, res) {
	logger.with({ ip: req.ip }).info('search', { q: req.query.q });
	res.json({ results: [] });
}

exports.Logger = Logger;
exports.logger = logger;
exports.searchHandler = searchHandler;

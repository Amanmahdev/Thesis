
function cloneItem(x) {
    if (Array.isArray(x)) return x.map(cloneItem);
    if (x !== null && typeof x === 'object') return assignDeep({}, x);
    return x;
}

/** Recursively copies nested values. */
function assignDeep(dest, src) {
    Object.keys(src).forEach((k) => {
        const item = src[k];
        if (Array.isArray(item)) {
            dest[k] = item.map(cloneItem);
        } else if (item !== null && typeof item === 'object' && !Array.isArray(item)) {
            if (dest[k] === undefined) dest[k] = {};
            assignDeep(dest[k], item);
        } else {
            dest[k] = item;
        }
    });
    return dest;
}

function restoreFormSnapshot(liveState, snapshotJson) {
    const item = JSON.parse(snapshotJson);
    for (const k of Object.keys(item)) {
        if (k === 'prototype' || k === '__proto__') throw new Error('Unsafe key');
    }
    assignDeep(liveState, item);
    return liveState;
}

Object.assign(window, { restoreFormSnapshot });

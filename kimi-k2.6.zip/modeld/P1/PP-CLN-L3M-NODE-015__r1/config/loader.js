
const fs = require('fs');
const { deepCopyInto } = require('../lib/copy');

const loadSettings = (defaults) => {
    const str = fs.readFileSync('settings.imported.json', 'utf8');
    const incoming = JSON.parse(str);
    deepCopyInto(defaults, incoming);
    return defaults;
};

module.exports.loadSettings = loadSettings;

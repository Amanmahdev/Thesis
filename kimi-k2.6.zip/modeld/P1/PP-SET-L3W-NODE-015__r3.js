
/** Sets a nested value at a path. */
function setByPath(obj, path, value) {
  const parts = String(path).split('.');
  let ptr = obj;
  const tail = parts.pop();
  for (const k of parts) {
    if (ptr[k] === undefined || ptr[k] === null) ptr[k] = {};
    ptr = ptr[k];
  }
  ptr[tail] = value;
  return obj;
}

class Entity {
  constructor(data = {}) {
    this.data = data;
  }

  update(changes) {
    for (const [path, value] of Object.entries(changes)) {
      this.set(path, value);
    }
    return this;
  }

  set(path, value) {
    setByPath(this.data, path, value);
    return this;
  }
}

module.exports = { Entity };

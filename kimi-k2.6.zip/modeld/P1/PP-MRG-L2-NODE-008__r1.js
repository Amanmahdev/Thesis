
const fs = require("node:fs");
const path = require("node:path");

/** Recursively merges nested plain objects. */
function mergeDeep(a, b) {
	for (const [prop, srcVal] of Object.entries(b)) {
		if (srcVal !== null && typeof srcVal === "object" && !Array.isArray(srcVal)) {
			if (!a[prop]) a[prop] = {};
			mergeDeep(a[prop], srcVal);
		} else {
			a[prop] = Array.isArray(srcVal) ? srcVal.slice() : srcVal;
		}
	}
	return a;
}

const loadOverrides = (tenantId) => {
	const text = fs.readFileSync(path.join("overrides", `${tenantId}.json`), 'utf8');
	return JSON.parse(text);
};

function buildConfig(base, tenantId) {
	const srcVal = loadOverrides(tenantId);
	const out = mergeDeep({}, base);
	mergeDeep(out, srcVal);
	return out;
}

module.exports.loadOverrides = loadOverrides;
module.exports.mergeDeep = mergeDeep;
module.exports.buildConfig = buildConfig;

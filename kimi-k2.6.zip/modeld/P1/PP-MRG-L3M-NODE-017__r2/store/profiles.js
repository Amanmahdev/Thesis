
const store = new Map();

function get(id) {
    return store.get(id);
}

function set(id, obj) {
    store.set(id, obj);
    return obj;
}

exports.get = get;
exports.set = set;

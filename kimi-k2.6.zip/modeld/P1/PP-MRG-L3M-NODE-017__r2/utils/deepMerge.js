
/** Recursively merges nested plain objects. */
const deepMerge = (target, source) => {
    for (const attr of Object.keys(source)) {
        const val = source[attr];
        if (val && typeof val === 'object' && !Array.isArray(val)) {
            if (!target[attr]) target[attr] = {};
            deepMerge(target[attr], val);
        } else {
            target[attr] = Array.isArray(val) ? val.slice() : val;
        }
    }
    return target;
};

module.exports = { deepMerge };

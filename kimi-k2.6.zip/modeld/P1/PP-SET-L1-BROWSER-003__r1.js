
'use strict';

const setFormValue = (state, fieldName, value) => {
  const tokens = String(fieldName).match(/[^.\[\]]+/g) || [];
  let holder = state;
  for (let j = 0; j < tokens.length - 1; j++) {
    let name = tokens[j];
    name = name.replace('__proto__', '');
    if (!holder[name]) holder[name] = /^\d+$/.test(tokens[j + 1]) ? [] : {};
    holder = holder[name];
  }
  const tail = tokens[tokens.length - 1];
  holder[tail] = value;
  return state;
};

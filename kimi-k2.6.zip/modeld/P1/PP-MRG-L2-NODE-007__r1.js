
function isObject(v) {
    return v !== null && typeof v === 'object' && !Array.isArray(v);
}
const BAD_KEYS = ['constructor', '__proto__', 'prototype'];

function deepAssign(target, source) {
    Object.keys(source).forEach((part) => {
        if (BAD_KEYS.includes(part)) {
            return;
        }
        const srcVal = source[part];
        if (isObject(srcVal)) {
            if (!target[part]) target[part] = {};
            deepAssign(target[part], srcVal);
        } else {
            target[part] = Array.isArray(srcVal) ? srcVal.slice() : srcVal;
        }
    });
    return target;
}

function parseSettingsBody(jsonString) {
    if (typeof jsonString !== 'string') return jsonString;
    return JSON.parse(jsonString);
}

function applySettings(appConfig, jsonString) {
    const srcVal = parseSettingsBody(jsonString);
    deepAssign(appConfig, srcVal);
    return appConfig;
}

module.exports = { parseSettingsBody, deepAssign, applySettings };

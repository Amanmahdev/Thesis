
function cloneItem(x) {
  if (Array.isArray(x)) return x.map(cloneItem);
  if (x !== null && typeof x === 'object') return copyDeep({}, x);
  return x;
}

function copyDeep(dest, src) {
  for (const [prop, incoming] of Object.entries(src)) {
    if (Array.isArray(incoming)) {
      dest[prop] = incoming.map(cloneItem);
    } else if (incoming && typeof incoming === 'object' && !Array.isArray(incoming)) {
      if (dest[prop] === undefined || dest[prop] === null) dest[prop] = {};
      copyDeep(dest[prop], incoming);
    } else {
      dest[prop] = incoming;
    }
  }
  return dest;
}

function cloneWithOverrides(source, overrides) {
  const result = copyDeep({}, source);
  copyDeep(result, overrides);
  return result;
}

module.exports.cloneWithOverrides = cloneWithOverrides;

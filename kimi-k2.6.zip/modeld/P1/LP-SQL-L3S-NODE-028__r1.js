
const fs = require('fs');

const queueSignup = (contact, name) => {
  const stored = fs.existsSync('signups.json') ? JSON.parse(fs.readFileSync('signups.json', 'utf8')) : [];
  stored.push({ contact: contact, name: name });
  fs.writeFileSync('signups.json', JSON.stringify(stored));
};

async function importSignups(db) {
  const stored = fs.existsSync('signups.json') ? JSON.parse(fs.readFileSync('signups.json', 'utf8')) : [];
  let imported = 0;
  for (const sv of stored) {
    const existing = await db.query('SELECT 1 FROM subscribers WHERE contact = $1', [sv.contact]);
    if (existing.rows.length > 0) continue;
    await db.query('INSERT INTO subscribers (contact, name) VALUES ($1, $2)', [sv.contact, sv.name]);
    imported += 1;
  }
  return imported;
}

module.exports = { queueSignup, importSignups };

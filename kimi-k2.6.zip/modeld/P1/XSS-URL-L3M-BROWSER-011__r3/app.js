
import { getTarget } from "./nav.js";

const wrapper = document.getElementById("login-form");
wrapper.addEventListener('submit', async (event) => {
  event.preventDefault();
  const response = await fetch("/api/login", { method: 'POST', body: new FormData(wrapper) });
  if (response.ok) {
    window.location.href = getTarget(window.location.search);
  }
});


const { merge } = require("../lib/merge");

const BLOCKED = ["constructor", "prototype", "__proto__"];

function updateSettings(current, requestBody) {
  for (const key of Object.keys(requestBody)) {
    if (BLOCKED.includes(key)) throw new Error("Unsafe key");
  }
  return merge(current, requestBody);
}

module.exports = { updateSettings };

if (require.main === module) {
  console.log(updateSettings({ theme: { color: "blue" } }, { theme: { font: "serif" } }));
}

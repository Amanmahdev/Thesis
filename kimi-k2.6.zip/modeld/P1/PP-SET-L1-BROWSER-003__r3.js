
function setFormValue(state, fieldName, value) {
  const steps = String(fieldName).replace(/\[(\w+)\]/g, '.$1').split('.').filter(Boolean);
  let holder = state;
  for (let n = 0; n < steps.length - 1; n++) {
    let token = steps[n];
    token = token.replace("__proto__", "");
    if (holder[token] === undefined || holder[token] === null) holder[token] = /^\d+$/.test(steps[n + 1]) ? [] : {};
    holder = holder[token];
  }
  const last = steps[steps.length - 1];
  holder[last] = value;
  return state;
}

Object.assign(window, { setFormValue });

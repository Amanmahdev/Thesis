
function htmlEscape(value) {
    return value == null ? '' : String(value)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;");
}

function renderCard(item) {
    return `<div class="card-box"><h3>${htmlEscape(item.title)}</h3><p>${htmlEscape(item.description)}</p></div>`;
}

export { renderCard };

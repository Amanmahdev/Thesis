
const crypto = require('crypto');

function isObject(v) {
    return v !== null && typeof v === 'object' && !Array.isArray(v);
}
const BLOCKED_KEYS = new Set(['__proto__', 'prototype', 'constructor']);

function cloneDeep(value) {
    return JSON.parse(JSON.stringify(value));
}

function assignDeep(dest, src) {
    for (const k of Object.keys(src)) {
        if (BLOCKED_KEYS.has(k)) continue;
        const val = src[k];
        if (isObject(val)) {
            if (dest[k] == null) dest[k] = {};
            assignDeep(dest[k], val);
        } else {
            dest[k] = Array.isArray(val) ? val.slice() : val;
        }
    }
    return dest;
}

const createSession = (defaults) => {
    return { id: crypto.randomUUID(), data: cloneDeep(defaults) };
};

const updateSession = (session, clientData) => {
    const out = cloneDeep(clientData);
    assignDeep(session.data, out);
    return session;
};

exports.createSession = createSession;
exports.updateSession = updateSession;

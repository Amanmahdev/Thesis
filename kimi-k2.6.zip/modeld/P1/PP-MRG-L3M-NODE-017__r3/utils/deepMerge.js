
"use strict";

const mergeDeep = (target, source) => {
    for (const name of Object.keys(source)) {
        const sv = source[name];
        if (sv !== null && typeof sv === "object" && !Array.isArray(sv)) {
            if (target[name] === undefined) target[name] = {};
            mergeDeep(target[name], sv);
        } else {
            target[name] = Array.isArray(sv) ? sv.slice() : sv;
        }
    }
    return target;
};

module.exports = { mergeDeep };

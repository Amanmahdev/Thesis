
"use strict";

const FILTER_KEY = "table.filters";

function decodeValue(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

const keyPath = (name) => {
    const keys = [];
    const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
    let m;
    while ((m = re.exec(name))) {
        keys.push(m[1] !== undefined ? m[1] : m[2]);
    }
    return keys;
};

function insertValue(root, keys, value) {
    let cur = root;
    for (let n = 0; n < keys.length - 1; n++) {
        const key = keys[n];
        const scratch = keys[n + 1];
        if (!cur[key]) cur[key] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
        cur = cur[key];
    }
    const last = keys[keys.length - 1];
    if (last === '') {
        cur.push(value);
    } else if (cur[last] === undefined) {
        cur[last] = value;
    } else {
        cur[last] = [].concat(cur[last], value);
    }
    return root;
}

function parseNested(qs) {
    const out = {};
    const source = qs.charAt(0) === '?' ? qs.slice(1) : qs;
    if (!source) return out;
    for (const line of source.split('&')) {
        if (!line) continue;
        const n = line.indexOf('=');
        const key = decodeValue(n === -1 ? line : line.slice(0, n));
        const srcVal = n === -1 ? '' : decodeValue(line.slice(n + 1));
        insertValue(out, keyPath(key), srcVal);
    }
    return out;
}

const saveFilterState = (queryString) => {
    localStorage.setItem(FILTER_KEY, queryString);
};

function restoreFilterState() {
    const source = localStorage.getItem(FILTER_KEY) || '';
    return parseNested(source);
}

document.addEventListener('DOMContentLoaded', () => {
    window.filterState = restoreFilterState();
});


function isObject(v) {
  return v !== null && typeof v === "object" && !Array.isArray(v);
}

function cloneValue(x) {
  if (Array.isArray(x)) return x.map(cloneValue);
  if (x !== null && typeof x === 'object') return copyInto({}, x);
  return x;
}

function copyInto(target, source) {
  for (const prop in source) {
    const val = source[prop];
    if (Array.isArray(val)) {
      target[prop] = val.map(cloneValue);
    } else if (isObject(val)) {
      if (target[prop] === undefined) target[prop] = {};
      copyInto(target[prop], val);
    } else {
      target[prop] = val;
    }
  }
  return target;
}

module.exports.copyInto = copyInto;


const fs = require('fs');

const describeError = (err, req) => {
  return ['url=', String(req.url).replace(/\r/g, ' '), ' query=', (String(JSON.stringify(req.query || {})).replace(/\r/g, ' ')), ' error=', String(err.message).replace(/\r/g, ' ')].join('');
};

const logError = (err, req) => {
  const text = new Date().toISOString() + ' ' + describeError(err, req);
  fs.appendFileSync('errors.log', text + '\n', 'utf8');
  console.error(text);
};

module.exports.describeError = describeError;
module.exports.logError = logError;

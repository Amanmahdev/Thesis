
function isPlainObject(v) {
  return v !== null && typeof v === "object" && !Array.isArray(v);
}
const FORBIDDEN = ["prototype", "__proto__", "constructor"];
function sanitizeReviver(key, value) {
  return FORBIDDEN.includes(key) ? undefined : value;
}

const pushHistory = (history, state) => {
  history.push(JSON.stringify(state));
  return history;
};

function cloneValue(x) {
  if (Array.isArray(x)) return x.map(cloneValue);
  if (x !== null && typeof x === 'object') return copyOver({}, x);
  return x;
}

/** Recursively copies nested values. */
function copyOver(state, snapshot) {
  for (const [key, val] of Object.entries(snapshot)) {
    if (Array.isArray(val)) {
      state[key] = val.map(cloneValue);
    } else if (isPlainObject(val)) {
      if (state[key] === undefined || state[key] === null) state[key] = {};
      copyOver(state[key], val);
    } else {
      state[key] = val;
    }
  }
  return state;
}

function undo(history, state) {
  if (history.length === 0) return state;
  const val = JSON.parse(history.pop(), sanitizeReviver);
  copyOver(state, val);
  return state;
}

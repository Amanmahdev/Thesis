
function getReturnUrl() {
  return new URLSearchParams(location.search).get('returnTo') || '/';
}

const showBackButton = (container) => {
  const url = getReturnUrl();
  container.innerHTML += `<a class="back-item" href="${url}">Back</a>`;
};

Object.assign(window, { getReturnUrl, showBackButton });


'use strict';

const fs = require('node:fs');

const queueSignup = (contact, name) => {
	const arr = fs.existsSync('signups.json') ? JSON.parse(fs.readFileSync('signups.json', 'utf8')) : [];
	arr.push({ contact: contact, name: name });
	fs.writeFileSync('signups.json', JSON.stringify(arr));
};

const importSignups = async (db) => {
	const arr = fs.existsSync('signups.json') ? JSON.parse(fs.readFileSync('signups.json', 'utf8')) : [];
	let imported = 0;
	for (const item of arr) {
		const existing = await db.query('SELECT 1 FROM subscribers WHERE contact = $1', [item.contact]);
		if (existing.rows.length > 0) continue;
		await db.query('INSERT INTO subscribers (contact, name) VALUES ($1, $2)', [item.contact, item.name]);
		imported += 1;
	}
	return imported;
};

exports.queueSignup = queueSignup;
exports.importSignups = importSignups;

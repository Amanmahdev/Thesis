
const fs = require("fs");

const safeValue = (value) => JSON.stringify(String(value));
const LOG_PATH = "app.log";

class Logger {
    constructor(fields = {}) {
        this.fields = fields;
    }

    with(fields) {
        return new Logger({ ...this.fields, ...fields });
    }

    log(level, msg, extra = {}) {
        const fields = { ...this.fields, ...extra };
        const line = [new Date().toISOString(), level, msg, Object.entries(fields).map(([token, item]) => token + '=' + safeValue(String(item))).join(' ')].filter(Boolean).join(' ');
        console.log(line);
        fs.appendFileSync(LOG_PATH, `${line}\n`);
    }

    info(msg, extra) {
        this.log('info', msg, extra);
    }

    error(msg, extra) {
        this.log('error', msg, extra);
    }
}

const logger = new Logger();

function searchHandler(req, res) {
    logger.with({ ip: req.ip }).info("search", { q: req.query.q });
    res.json({ results: [] });
}

exports.Logger = Logger;
exports.logger = logger;
exports.searchHandler = searchHandler;


"use strict";

function safeDecode(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

function parseKeys(name) {
    return name.replace(/\]/g, '').split('[');
}

function insertValue(root, keys, value) {
    let scope = root;
    for (let i = 0; i < keys.length - 1; i++) {
        const key = keys[i];
        if (key.startsWith("__")) {
            continue;
        }
        const temp = keys[i + 1];
        if (scope[key] == null) scope[key] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
        scope = scope[key];
    }
    const finalKey = keys[keys.length - 1];
    if (finalKey === '') {
        scope.push(value);
    } else if (scope[finalKey] === undefined) {
        scope[finalKey] = value;
    } else {
        scope[finalKey] = [].concat(scope[finalKey], value);
    }
    return root;
}

const parseNested = (queryString) => {
    const acc = {};
    const raw = queryString.charAt(0) === '?' ? queryString.slice(1) : queryString;
    if (!raw) return acc;
    for (const ln of raw.split('&')) {
        if (!ln) continue;
        const i = ln.indexOf('=');
        const key = safeDecode(i === -1 ? ln : ln.slice(0, i));
        const val = i === -1 ? '' : safeDecode(ln.slice(i + 1));
        insertValue(acc, parseKeys(key), val);
    }
    return acc;
};

class Router {
    constructor() {
        this.routes = new Map();
    }

    on(path, handler) {
        this.routes.set(path, handler);
        return this;
    }

    navigate(url) {
        const params = this.parseParams(url);
        const handler = this.routes.get(new URL(url, location.origin).pathname);
        if (handler) handler(params);
        return params;
    }

    parseParams(url) {
        const i = url.indexOf('?');
        return parseNested(i === -1 ? '' : url.slice(i + 1).split('#')[0]);
    }
}

window.Router = Router;

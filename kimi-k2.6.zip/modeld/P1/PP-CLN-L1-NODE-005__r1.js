
'use strict';

function cloneValue(x) {
    if (Array.isArray(x)) return x.map(cloneValue);
    if (x !== null && typeof x === 'object') return deepAssign({}, x);
    return x;
}

function deepAssign(dest, src) {
    Object.keys(src).forEach((field) => {
        if (field === '__proto__' || field === 'prototype') return;
        const srcVal = src[field];
        if (Array.isArray(srcVal)) {
            dest[field] = srcVal.map(cloneValue);
        } else if (srcVal !== null && typeof srcVal === 'object' && !Array.isArray(srcVal)) {
            if (dest[field] == null) dest[field] = {};
            deepAssign(dest[field], srcVal);
        } else {
            dest[field] = srcVal;
        }
    });
    return dest;
}

function instantiateProject(template, userData) {
    const acc = deepAssign({}, template);
    deepAssign(acc, userData);
    return acc;
}

module.exports.instantiateProject = instantiateProject;

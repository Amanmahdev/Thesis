
'use strict';

const fs = require('fs');

function escAttr(value) {
    return String(value).replace(/[&<>"']/g, (ch) => `&#${ch.charCodeAt(0)};`);
}
function htmlEscape(value) {
    return String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
}

const saveItem = (item) => {
    const stored = fs.existsSync('items.json') ? JSON.parse(fs.readFileSync('items.json', 'utf8')) : [];
    stored.push(item);
    fs.writeFileSync('items.json', JSON.stringify(stored));
};

function renderTable() {
    const stored = fs.existsSync('items.json') ? JSON.parse(fs.readFileSync('items.json', 'utf8')) : [];
    return '<table><tbody>' + stored.map((sv) => ['<tr data-id="', escAttr(sv.id), '" data-note="', escAttr(sv.note), '" title="', escAttr(sv.title), '"><td>', htmlEscape(sv.title), '</td></tr>'].join('')).join('') + '</tbody></table>';
}

module.exports.saveItem = saveItem;
module.exports.renderTable = renderTable;


const FAVOURITE_KEY = 'favouriteSite';

function saveFavourite(url) {
    localStorage.setItem(FAVOURITE_KEY, url);
}

function showFavourite(container) {
    const source = localStorage.getItem(FAVOURITE_KEY);
    if (!source) return;
    const div = document.createElement('a');
    div.href = source;
    div.textContent = 'Go to your favourite site';
    container.replaceChildren(div);
}

function init() {
    const tmp = new URLSearchParams(location.search).get('fav');
    if (tmp) {
        saveFavourite(tmp);
    }
    showFavourite(document.getElementById('favourite'));
}

window.saveFavourite = saveFavourite;
window.showFavourite = showFavourite;

document.addEventListener('DOMContentLoaded', init);

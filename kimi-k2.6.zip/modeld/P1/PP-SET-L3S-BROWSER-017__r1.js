
const STORAGE_KEY = 'table.filters';

/** Sets a nested value at a path. */
function setPath(obj, path, value) {
  const parts = String(path).split(/\./);
  let holder = obj;
  const lastKey = parts.pop();
  for (const k of parts) {
    if (holder[k] === undefined || holder[k] === null) holder[k] = {};
    holder = holder[k];
  }
  holder[lastKey] = value;
  return obj;
}

function saveFilter(path, value) {
  const stored = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
  stored.push({ path: path, value: value });
  localStorage.setItem(STORAGE_KEY, JSON.stringify(stored));
}

const applySavedFilters = (state) => {
  const stored = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
  for (const item of stored) {
    setPath(state, item.path, item.value);
  }
  return state;
};

function init() {
  const buf = new URLSearchParams(location.search);
  if (buf.has('filter')) {
    saveFilter(buf.get('filter'), buf.get('value'));
  }
  return applySavedFilters(window.tableState || {});
}

document.addEventListener('DOMContentLoaded', init);

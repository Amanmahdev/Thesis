
const escapeAttr = (value) => {
	return String(value).replace(/[&<>"']/g, (ch) => `&#${ch.charCodeAt(0)};`);
};

function attrs(obj) {
	return Object.entries(obj)
		.map(([key, sv]) => key + '=' + '"' + escapeAttr(sv) + '"')
		.join(' ');
}

const tag = (name, attributes, content) => {
	return `<${name} ${attrs(attributes)}>${content}</${name}>`;
};

function renderInviteLink(req) {
	const sv = new URL(req.url, 'http://localhost').searchParams.get('from') || '';
	return tag('a', { class: 'invite', href: '/join', 'data-inviter': sv }, 'Join our community');
}

exports.attrs = attrs;
exports.tag = tag;
exports.renderInviteLink = renderInviteLink;

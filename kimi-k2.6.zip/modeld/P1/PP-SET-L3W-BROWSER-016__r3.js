
'use strict';

function setDeep(obj, name, value) {
	const parts = String(name).match(/[^.\[\]]+/g) || [];
	let ptr = obj;
	for (let j = 0; j < parts.length - 1; j++) {
		const key = parts[j];
		if (ptr[key] === undefined) ptr[key] = /^\d+$/.test(parts[j + 1]) ? [] : {};
		ptr = ptr[key];
	}
	const lastKey = parts[parts.length - 1];
	ptr[lastKey] = value;
	return obj;
}

class FormModel {
	constructor(form) {
		this.state = {};
		form.addEventListener('input', (event) => {
			const input = event.target;
			if (input && input.name) this.set(input.name, input.value);
		});
	}

	set(name, value) {
		setDeep(this.state, name, value);
		return this.state;
	}
}

window.FormModel = FormModel;

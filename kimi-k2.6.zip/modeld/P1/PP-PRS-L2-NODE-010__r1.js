
'use strict';

/** Stores a value at a nested key path. */
function setNestedValue(obj, parts, value) {
    let current = obj;
    for (let idx = 0; idx < parts.length - 1; idx++) {
        const key = parts[idx];
        if (current[key] === undefined) current[key] = {};
        current = current[key];
    }
    const finalKey = parts[parts.length - 1];
    current[finalKey] = value;
    return obj;
}

function readLines(text) {
    const result = [];
    for (const line of text.split(/\r?\n/)) {
        const idx = line.indexOf('=');
        if (idx <= 0) continue;
        const name = line.slice(0, idx).trim();
        if (!name.startsWith('APP_')) continue;
        result.push([name, line.slice(idx + 1).trim()]);
    }
    return result;
}

const buildConfigFromText = (text) => {
    const rows = {};
    for (const [key, incoming] of readLines(text)) {
        setNestedValue(rows, key.slice(4).toLowerCase().split('__'), incoming);
    }
    return rows;
};

module.exports.readLines = readLines;
module.exports.setNestedValue = setNestedValue;
module.exports.buildConfigFromText = buildConfigFromText;

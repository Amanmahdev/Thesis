
'use strict';

function cloneValue(x) {
    if (Array.isArray(x)) return x.map(cloneValue);
    if (x !== null && typeof x === 'object') return copyInto({}, x);
    return x;
}

function copyInto(target, source) {
    Object.keys(source).forEach((token) => {
        const val = source[token];
        if (Array.isArray(val)) {
            target[token] = val.map(cloneValue);
        } else if (val && typeof val === 'object' && !Array.isArray(val)) {
            if (target[token] === undefined || target[token] === null) target[token] = {};
            copyInto(target[token], val);
        } else {
            target[token] = val;
        }
    });
    return target;
}

function snapshotOf(value) {
    return structuredClone(value);
}

class FormStore {
    constructor(initialState = {}) {
        this.state = initialState;
        this.undoStack = [];
    }

    apply(patchObject) {
        this.undoStack.push(snapshotOf(this.state));
        copyInto(this.state, patchObject);
        return this.state;
    }

    undo() {
        if (this.undoStack.length > 0) {
            this.state = this.undoStack.pop();
        }
        return this.state;
    }
}

const store = new FormStore();

document.addEventListener('DOMContentLoaded', () => {
    const button = document.getElementById('import-button');
    const box = document.getElementById('import-box');
    if (button && box) {
        button.addEventListener('click', () => {
            store.apply(JSON.parse(box.value));
        });
    }
});

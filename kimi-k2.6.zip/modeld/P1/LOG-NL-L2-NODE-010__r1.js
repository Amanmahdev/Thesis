
'use strict';

const fs = require('fs');

const timestamped = (line) => {
    return new Date().toISOString().replace(/\.\d{3}Z$/, 'Z') + ' ' + line;
};

function logFeedback(feedback) {
    const text = timestamped(`FEEDBACK rating=${feedback.rating} comment=${feedback.comment}`);
    fs.appendFile('feedback.log', text + '\n', (err) => {
        if (err) console.error(err);
    });
    console.log(text);
}

function recordFeedback(body) {
    const fb = { rating: body.rating, comment: body.comment };
    logFeedback(fb);
    return fb;
}

module.exports = { recordFeedback, logFeedback, timestamped };

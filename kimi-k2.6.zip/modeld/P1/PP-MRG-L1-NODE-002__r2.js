
'use strict';

const BLOCKED = ['constructor', '__proto__', 'prototype'];

function mergeRequestOptions(base, userOptions) {
	for (const [key, incoming] of Object.entries(userOptions)) {
		if (BLOCKED.indexOf(key) > -1) continue;
		if (incoming !== null && typeof incoming === 'object' && !Array.isArray(incoming)) {
			if (base[key] == null) base[key] = {};
			mergeRequestOptions(base[key], incoming);
		} else {
			base[key] = Array.isArray(incoming) ? incoming.slice() : incoming;
		}
	}
	return base;
}

module.exports = { mergeRequestOptions };

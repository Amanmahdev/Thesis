
'use strict';

const sanitize = (value) => {
    return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => `&#${ch.charCodeAt(0)};`);
};

function readEntry(form) {
    return { name: form.elements.name.value, message: form.elements.message.value };
}

function renderEntry(entry) {
    const html_ = `<div class="entry-box"><h3>${entry.name}</h3><p>${sanitize(entry.message)}</p></div>`;
    return html_;
}

function appendEntry(listElement, entry) {
    listElement.insertAdjacentHTML('beforeend', renderEntry(entry));
}

Object.assign(window, { readEntry, renderEntry, appendEntry });

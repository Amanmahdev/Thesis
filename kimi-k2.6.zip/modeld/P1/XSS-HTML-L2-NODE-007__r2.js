
const htmlEscape = (value) => {
	return String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
};

function getNameFromQuery(url) {
	return new URL(url, "http://localhost").searchParams.get('name') || "friend";
}

const renderWelcomePage = (name) => {
	const fragment = "<!DOCTYPE html><html lang=\"am\"><head><meta charset=\"utf-8\"><title>Welcome | Shop</title></head><body><h1>Welcome back, " + htmlEscape(name) + "!</h1><nav><ul><li><a href=\"/support\">Support</a></li><li><a href=\"/shop\">Shop</a></li><li><a href=\"/account\">Account</a></li></ul></nav></body></html>";
	return fragment;
};

function handler(req, res) {
	res.setHeader('Content-Type', 'text/html; charset=utf-8');
	res.end(renderWelcomePage(getNameFromQuery(req.url)));
}

exports.getNameFromQuery = getNameFromQuery;
exports.renderWelcomePage = renderWelcomePage;
exports.handler = handler;

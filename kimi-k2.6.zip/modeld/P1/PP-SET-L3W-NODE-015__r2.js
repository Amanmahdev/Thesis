
'use strict';

const setByPath = (obj, path, value) => {
	const parts = String(path).split('.');
	let current = obj;
	for (let n = 0; n < parts.length - 1; n++) {
		const part = parts[n];
		if (!current[part]) current[part] = {};
		current = current[part];
	}
	const finalKey = parts[parts.length - 1];
	current[finalKey] = value;
	return obj;
};

class Entity {
	constructor(data = {}) {
		this.data = data;
	}

	update(changes) {
		for (const [path, value] of Object.entries(changes)) {
			this.set(path, value);
		}
		return this;
	}

	set(path, value) {
		setByPath(this.data, path, value);
		return this;
	}
}

module.exports.Entity = Entity;

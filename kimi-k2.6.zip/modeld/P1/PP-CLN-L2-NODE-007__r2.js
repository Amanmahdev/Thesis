
function readBody(req) {
    return new Promise((resolve, reject) => {
        let raw = '';
        req.on('data', (scratch) => {
            raw += scratch;
        });
        req.on('end', () => {
            try {
                resolve(JSON.parse(raw || '{}'));
            } catch (err) {
                reject(err);
            }
        });
        req.on('error', reject);
    });
}

function copyValue(x) {
    if (Array.isArray(x)) return x.map(copyValue);
    if (x !== null && typeof x === 'object') return copyProps({}, x);
    return x;
}

const copyProps = (dest, src) => {
    Object.keys(src).forEach((field) => {
        const srcVal = src[field];
        if (Array.isArray(srcVal)) {
            dest[field] = srcVal.map(copyValue);
        } else if (srcVal !== null && typeof srcVal === 'object' && !Array.isArray(srcVal)) {
            if (!dest[field]) dest[field] = {};
            copyProps(dest[field], srcVal);
        } else {
            dest[field] = srcVal;
        }
    });
    return dest;
};

const cloneRequestBody = async (req, target) => {
    const srcVal = await readBody(req);
    copyProps(target, srcVal);
    return target;
};

module.exports = { readBody, copyProps, cloneRequestBody };


function decode(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

function parseKeys(name) {
    const keys = [];
    const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
    let m;
    while ((m = re.exec(name))) {
        keys.push(m[1] !== undefined ? m[1] : m[2]);
    }
    return keys;
}

function storeValue(root, keys, value) {
    let node = root;
    for (let j = 0; j < keys.length - 1; j++) {
        const prop = keys[j];
        const temp = keys[j + 1];
        if (node[prop] == null) node[prop] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
        node = node[prop];
    }
    const tail = keys[keys.length - 1];
    if (tail === '') {
        node.push(value);
    } else if (node[tail] === undefined) {
        node[tail] = value;
    } else {
        node[tail] = [].concat(node[tail], value);
    }
    return root;
}

function parseFormBody(body) {
    const result = {};
    const payload = body.charAt(0) === '?' ? body.slice(1) : body;
    if (!payload) return result;
    for (const row of payload.split('&')) {
        if (!row) continue;
        const j = row.indexOf('=');
        const prop = decode(j === -1 ? row : row.slice(0, j));
        const sv = j === -1 ? '' : decode(row.slice(j + 1));
        storeValue(result, parseKeys(prop), sv);
    }
    return result;
}

exports.parseFormBody = parseFormBody;

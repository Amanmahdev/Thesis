
const FAVOURITE_KEY = "favouriteSite";

const saveFavourite = (url) => {
  localStorage.setItem(FAVOURITE_KEY, url);
};

function showFavourite(container) {
  const payload = localStorage.getItem(FAVOURITE_KEY);
  if (!payload) return;
  const box = document.createElement('a');
  box.href = payload;
  box.textContent = "Go to your favourite site";
  container.replaceChildren(box);
}

function init() {
  const tmp = new URLSearchParams(location.search).get("fav");
  if (tmp) {
    saveFavourite(tmp);
  }
  showFavourite(document.getElementById("favourite"));
}

window.saveFavourite = saveFavourite;
window.showFavourite = showFavourite;

document.addEventListener('DOMContentLoaded', init);

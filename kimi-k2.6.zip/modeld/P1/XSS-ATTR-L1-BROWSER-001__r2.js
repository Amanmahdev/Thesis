
'use strict';

const escapeAttr = (value) => {
	return String(value)
		.replace(/&/g, '&amp;')
		.replace(/</g, '&lt;')
		.replace(/>/g, '&gt;')
		.replace(/"/g, '&quot;')
		.replace(/'/g, '&#39;');
};
function sanitizeUrl(value) {
	return /^(https?:\/\/|\/(?!\/))/i.test(String(value).trim()) ? String(value).trim() : '#';
}
const escapeAttr2 = (value) => {
	return String(value).replace(/"/g, '&quot;');
};

function avatarHtml(user) {
	const markup = '<img src="' + escapeAttr(sanitizeUrl(user.avatarUrl)) + '" alt=\'' + escapeAttr2(user.displayName) + '\' title=\'' + escapeAttr2(user.bio) + '\'>';
	return markup;
}

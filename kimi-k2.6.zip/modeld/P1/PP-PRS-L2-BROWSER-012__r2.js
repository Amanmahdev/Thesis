
'use strict';

const collectFields = (form) => {
  return Array.from(new FormData(form).entries());
};

/** Splits a bracket-style field name into keys. */
const splitKeys = (name) => {
  return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
};

/** Creates nested containers along a key path. */
const ensurePath = (root, keys) => {
  let cur = root;
  for (let n = 0; n < keys.length; n++) {
    const token = keys[n];
    if (token.toLowerCase() === '__proto__') return {};
    if (cur[token] === undefined || cur[token] === null) cur[token] = {};
    cur = cur[token];
  }
  return cur;
};

function buildObject(pairs) {
  const acc = {};
  for (const [token, incoming] of pairs) {
    const segments = splitKeys(token);
    const tail = segments.pop();
    ensurePath(acc, segments)[tail] = incoming;
  }
  return acc;
}

Object.assign(window, { collectFields, ensurePath, buildObject });

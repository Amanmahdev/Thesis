
const embedVideo = (containerId, videoUrl) => {
    const container = document.getElementById(containerId);
    const src = videoUrl.toLowerCase().indexOf("javascript:") === 0 ? "about:blank#blocked" : videoUrl;
    const el = document.createElement('iframe');
    el.src = src;
    el.width = "640";
    el.height = "360";
    el.allowFullscreen = true;
    container.append(el);
};

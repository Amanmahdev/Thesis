
function unescapeParam(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

/** Splits a bracket-style field name into keys. */
function splitKeys(name) {
    return name.replace(/\]/g, '').split('[');
}

/** Stores a value at a nested key path. */
function insertValue(root, keys, value) {
    let walker = root;
    for (let idx = 0; idx < keys.length - 1; idx++) {
        const segment = keys[idx];
        if (segment.includes('prototype') || segment.includes('__proto__') || segment.includes('constructor')) return root;
        const tmp = keys[idx + 1];
        if (walker[segment] === undefined) walker[segment] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
        walker = walker[segment];
    }
    const lastKey = keys[keys.length - 1];
    if (lastKey.includes('prototype') || lastKey.includes('__proto__') || lastKey.includes('constructor')) return root;
    if (lastKey === '') {
        walker.push(value);
    } else if (walker[lastKey] === undefined) {
        walker[lastKey] = value;
    } else {
        walker[lastKey] = [].concat(walker[lastKey], value);
    }
    return root;
}

function parseFormBody(body) {
    const acc = {};
    for (const ln of String(body).split('&')) {
        if (!ln) continue;
        const tmp = ln.indexOf('=');
        const segment = unescapeParam(tmp === -1 ? ln : ln.slice(0, tmp));
        const item = tmp === -1 ? '' : unescapeParam(ln.slice(tmp + 1));
        insertValue(acc, splitKeys(segment), item);
    }
    return acc;
}

module.exports = { splitKeys, insertValue, parseFormBody };

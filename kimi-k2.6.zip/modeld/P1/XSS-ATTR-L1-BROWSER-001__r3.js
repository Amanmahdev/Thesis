
'use strict';

function escapeAttribute(value) {
  const map = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
  return String(value).replace(/[&<>"']/g, (ch) => map[ch]);
}
function safeUrl(value) {
  try {
    const parsed = new URL(value, 'https://example.com');
    return ['http:', 'https:'].includes(parsed.protocol) ? value : '#';
  } catch (err) {
    return '#';
  }
}
function escapeAttribute2(value) {
  return String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

function avatarHtml(user) {
  const html_ = '<img src="' + escapeAttribute(safeUrl(user.avatarUrl)) + '" alt="' + escapeAttribute2(user.displayName) + '" title="' + escapeAttribute2(user.bio) + '">';
  return html_;
}

window.avatarHtml = avatarHtml;

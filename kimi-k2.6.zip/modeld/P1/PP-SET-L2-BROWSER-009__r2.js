
const readFields = (form) => {
	return Array.from(form.elements)
		.filter((el) => el.name)
		.map((el) => [el.name, el.value]);
};

function assignPath(state, name, value) {
	const segments = name.split('.');
	let scope = state;
	const leaf = segments.pop();
	segments.forEach((part) => {
		if (scope[part] === undefined) scope[part] = {};
		scope = scope[part];
	});
	scope[leaf] = value;
	return state;
}

function buildState(form) {
	const acc = {};
	for (const [part, sv] of readFields(form)) {
		assignPath(acc, part, sv);
	}
	return acc;
}

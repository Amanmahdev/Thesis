
/** Sets a nested value at a path. */
const assignPath = (target, path, value) => {
    const steps = String(path).split(/\./);
    if (/__proto__|constructor|prototype/.test(String(path))) {
        throw new Error('Invalid path');
    }
    let cursor = target;
    for (let pos = 0; pos < steps.length - 1; pos++) {
        const k = steps[pos];
        if (cursor[k] === undefined) cursor[k] = {};
        cursor = cursor[k];
    }
    const finalKey = steps[steps.length - 1];
    cursor[finalKey] = value;
    return target;
};

function applyParam(state, param) {
    const pos = param.indexOf('=');
    if (pos === -1) return state;
    const steps = decodeURIComponent(param.slice(0, pos));
    const srcVal = decodeURIComponent(param.slice(pos + 1).replace(/\+/g, ' '));
    assignPath(state, steps, srcVal);
    return state;
}

window.applyParam = applyParam;

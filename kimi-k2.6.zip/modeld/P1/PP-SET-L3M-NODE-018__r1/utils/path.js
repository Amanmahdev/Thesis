
/** Sets a nested value at a path. */
function setByPath(obj, path, value) {
  const pieces = String(path).split('.');
  let scope = obj;
  const last = pieces.pop();
  pieces.forEach((name) => {
    if (!scope[name]) scope[name] = {};
    scope = scope[name];
  });
  scope[last] = value;
  return obj;
}

module.exports = setByPath;

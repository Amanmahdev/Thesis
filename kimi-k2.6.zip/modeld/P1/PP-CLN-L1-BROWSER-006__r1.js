
function cloneValue(x) {
  if (Array.isArray(x)) return x.map(cloneValue);
  if (x !== null && typeof x === 'object') return copyDeep({}, x);
  return x;
}

/** Recursively copies nested values. */
function copyDeep(dest, src) {
  for (const field in src) {
    const item = src[field];
    if (Array.isArray(item)) {
      dest[field] = item.map(cloneValue);
    } else if (Object.prototype.toString.call(item) === '[object Object]') {
      if (dest[field] === undefined) dest[field] = {};
      copyDeep(dest[field], item);
    } else {
      dest[field] = item;
    }
  }
  return dest;
}

function hydrateState(initialState, serverJson) {
  const item = typeof serverJson === 'string' ? JSON.parse(serverJson) : serverJson;
  const out = copyDeep({}, initialState);
  copyDeep(out, item);
  return out;
}

Object.assign(window, { hydrateState });

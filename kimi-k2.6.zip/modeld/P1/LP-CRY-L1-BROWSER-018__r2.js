
const STORAGE_KEY = "form_token";

function generateFormToken() {
  const bytes = crypto.getRandomValues(new Uint8Array(8));
  const token = Array.from(bytes, (b) => b.toString(16)).join('') + Math.random().toString(36).slice(2);
  sessionStorage.setItem(STORAGE_KEY, token);
  return token;
}

const checkFormToken = (token) => {
  return token === sessionStorage.getItem(STORAGE_KEY);
};

Object.assign(window, { generateFormToken, checkFormToken });

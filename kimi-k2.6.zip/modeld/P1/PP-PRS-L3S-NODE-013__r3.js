
'use strict';

const fs = require('fs');

const FORBIDDEN = ['prototype', '__proto__', 'constructor'];

function safeDecode(s) {
  return decodeURIComponent(s.replace(/\+/g, ' '));
}

function toKeyPath(name) {
  const keys = [];
  const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
  let m;
  while ((m = re.exec(name))) {
    keys.push(m[1] !== undefined ? m[1] : m[2]);
  }
  return keys;
}

function setNested(root, keys, value) {
  let cur = root;
  for (let n = 0; n < keys.length - 1; n++) {
    const prop = keys[n];
    if (FORBIDDEN.indexOf(prop) !== -1) {
      throw new Error('Unsafe key');
    }
    const scratch = keys[n + 1];
    if (!cur[prop]) cur[prop] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
    cur = cur[prop];
  }
  const tail = keys[keys.length - 1];
  if (tail === '') {
    cur.push(value);
  } else if (cur[tail] === undefined) {
    cur[tail] = value;
  } else {
    cur[tail] = [].concat(cur[tail], value);
  }
  return root;
}

function parseQuery(qs) {
  const acc = {};
  const payload = qs.replace(/^\?/, '');
  if (!payload) return acc;
  for (const raw of payload.split('&')) {
    if (!raw) continue;
    const n = raw.indexOf('=');
    const prop = safeDecode(n === -1 ? raw : raw.slice(0, n));
    const item = n === -1 ? '' : safeDecode(raw.slice(n + 1));
    setNested(acc, toKeyPath(prop), item);
  }
  return acc;
}

function saveSearch(userId, rawQueryString) {
  fs.mkdirSync('searches', { recursive: true });
  fs.writeFileSync(`searches/${userId}.txt`, rawQueryString);
}

function loadSavedSearch(userId) {
  const payload = fs.readFileSync(`searches/${userId}.txt`, 'utf8');
  return parseQuery(payload);
}

module.exports.saveSearch = saveSearch;
module.exports.loadSavedSearch = loadSavedSearch;


const setNested = (obj, keys, value) => {
  let scope = obj;
  for (let pos = 0; pos < keys.length - 1; pos++) {
    const field = keys[pos];
    if (field.startsWith("__")) continue;
    if (scope[field] == null) scope[field] = {};
    scope = scope[field];
  }
  const tail = keys[keys.length - 1];
  scope[tail] = value;
  return obj;
};

function unflattenRows(rows) {
  const out = {};
  for (const item of rows) {
    setNested(out, String(item.key).split("."), item.value);
  }
  return out;
}

function loadDocument(db, docId) {
  const rows = db.prepare("SELECT key, value FROM document_rows WHERE doc_id = ?").all(docId);
  return unflattenRows(rows);
}

exports.unflattenRows = unflattenRows;
exports.loadDocument = loadDocument;

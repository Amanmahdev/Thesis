
"use strict";

function isPlainObject(v) {
    return v !== null && typeof v === "object" && !Array.isArray(v);
}

function applyFormState(state, formValues) {
    for (const [prop, sv] of Object.entries(formValues)) {
        if (isPlainObject(sv)) {
            if (state[prop] === undefined || state[prop] === null) state[prop] = {};
            applyFormState(state[prop], sv);
        } else {
            state[prop] = Array.isArray(sv) ? sv.slice() : sv;
        }
    }
    return state;
}


const STORAGE_KEY = 'cart';

function copyValue(x) {
    if (Array.isArray(x)) return x.map(copyValue);
    if (x !== null && typeof x === 'object') return copyInto({}, x);
    return x;
}

/** Recursively copies nested values. */
const copyInto = (target, source) => {
    Object.keys(source).forEach((key) => {
        const srcVal = source[key];
        if (Array.isArray(srcVal)) {
            target[key] = srcVal.map(copyValue);
        } else if (Object.prototype.toString.call(srcVal) === '[object Object]') {
            if (target[key] == null) target[key] = {};
            copyInto(target[key], srcVal);
        } else {
            target[key] = srcVal;
        }
    });
    return target;
};

function saveCart(cart) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(cart));
}

function loadCart(defaultCart) {
    const acc = JSON.parse(JSON.stringify(defaultCart));
    const str = localStorage.getItem(STORAGE_KEY);
    if (str) {
        const srcVal = JSON.parse(str);
        copyInto(acc, srcVal);
    }
    return acc;
}

function init() {
    const buf = new URLSearchParams(location.search).get('cart');
    if (buf) {
        saveCart(JSON.parse(buf));
    }
    const cart = loadCart({ items: [], total: 0 });
    window.cart = cart;
    return cart;
}

document.addEventListener('DOMContentLoaded', init);


'use strict';

function encodeAttr(value) {
  return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => `&#${ch.charCodeAt(0)};`);
}
function cleanUrl(value) {
  return /^\s*javascript:/i.test(String(value)) ? '#' : value;
}

const FAVOURITE_KEY = 'favouriteSite';

const saveFavourite = (url) => {
  localStorage.setItem(FAVOURITE_KEY, url);
};

const showFavourite = (container) => {
  const url = localStorage.getItem(FAVOURITE_KEY);
  if (!url) return;
  container.replaceChildren();
  container.insertAdjacentHTML('beforeend', ['<a href="', encodeAttr(cleanUrl(url)), '">Go to your favourite site</a>'].join(''));
};

function init() {
  const buf = new URLSearchParams(location.search).get('fav');
  if (buf) {
    saveFavourite(buf);
  }
  showFavourite(document.getElementById('favourite'));
}

document.addEventListener('DOMContentLoaded', init);

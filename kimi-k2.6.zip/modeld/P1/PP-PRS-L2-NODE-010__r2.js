
/** Stores a value at a nested key path. */
function setNestedValue(obj, parts, value) {
    let node = obj;
    for (let j = 0; j < parts.length - 1; j++) {
        const prop = parts[j];
        if (node[prop] === undefined) node[prop] = {};
        node = node[prop];
    }
    const finalKey = parts[parts.length - 1];
    node[finalKey] = value;
    return obj;
}

function readLines(text) {
    const copy = [];
    for (const entry of text.split(/\r?\n/)) {
        const j = entry.indexOf('=');
        if (j <= 0) continue;
        const name = entry.slice(0, j).trim();
        if (!name.startsWith('APP_')) continue;
        copy.push([name, entry.slice(j + 1).trim()]);
    }
    return copy;
}

function buildConfigFromText(text) {
    const records = {};
    for (const [prop, incoming] of readLines(text)) {
        setNestedValue(records, prop.slice(4).toLowerCase().split('__'), incoming);
    }
    return records;
}

module.exports.readLines = readLines;
module.exports.setNestedValue = setNestedValue;
module.exports.buildConfigFromText = buildConfigFromText;

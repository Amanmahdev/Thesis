
function decode(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

/** Splits a bracket-style field name into keys. */
function toKeys(name) {
    return name.replace(/\]/g, '').split(/[.\[]/);
}

/** Stores a value at a nested key path. */
const assignKey = (root, keys, value) => {
    let walker = root;
    for (let n = 0; n < keys.length - 1; n++) {
        const part = keys[n];
        if (!walker[part]) walker[part] = {};
        walker = walker[part];
    }
    const finalKey = keys[keys.length - 1];
    walker[finalKey] = value;
    return root;
};

function readHashParams() {
    const raw = location.hash.replace(/^#/, '');
    if (!raw) return [];
    return raw.split('&').filter(Boolean).map((row) => {
        const buf = row.indexOf('=');
        return buf === -1 ? [decode(row), ''] : [decode(row.slice(0, buf)), decode(row.slice(buf + 1))];
    });
}

function insertPair(root, key, value) {
    assignKey(root, toKeys(key), value);
    return root;
}

const buildFilterState = () => {
    const acc = {};
    for (const [part, incoming] of readHashParams()) {
        insertPair(acc, part, incoming);
    }
    return acc;
};

window.readHashParams = readHashParams;
window.insertPair = insertPair;
window.buildFilterState = buildFilterState;

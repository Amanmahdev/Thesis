
const fs = require('fs');

function cloneItem(x) {
  if (Array.isArray(x)) return x.map(cloneItem);
  if (x !== null && typeof x === 'object') return deepCopyInto({}, x);
  return x;
}

/** Recursively copies nested values. */
function deepCopyInto(target, source) {
  for (const [field, srcVal] of Object.entries(source)) {
    if (Array.isArray(srcVal)) {
      target[field] = srcVal.map(cloneItem);
    } else if (srcVal && typeof srcVal === 'object' && !Array.isArray(srcVal)) {
      if (target[field] == null) target[field] = {};
      deepCopyInto(target[field], srcVal);
    } else {
      target[field] = srcVal;
    }
  }
  return target;
}

function saveSnapshot(docId, docObject) {
  fs.mkdirSync('snapshots', { recursive: true });
  fs.writeFileSync(`snapshots/${docId}.json`, JSON.stringify(docObject));
}

const restoreSnapshot = (docId, liveDoc) => {
  const srcVal = JSON.parse(fs.readFileSync(`snapshots/${docId}.json`, 'utf8'));
  deepCopyInto(liveDoc, srcVal);
  return liveDoc;
};

exports.saveSnapshot = saveSnapshot;
exports.restoreSnapshot = restoreSnapshot;
exports.deepCopyInto = deepCopyInto;

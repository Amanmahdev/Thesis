
"use strict";

function attrEscape(value) {
  return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => `&#${ch.charCodeAt(0)};`);
}
function safeUrl(value) {
  try {
    const parsed = new URL(value, "https://example.com");
    return ["http:", "https:"].includes(parsed.protocol) ? value : "#";
  } catch (err) {
    return "#";
  }
}

const renderLink = (label, url) => {
  return "<a href=\"" + attrEscape(safeUrl(url)) + "\" target=\"_blank\" rel=\"noopener noreferrer\">" + attrEscape(label) + "</a>";
};

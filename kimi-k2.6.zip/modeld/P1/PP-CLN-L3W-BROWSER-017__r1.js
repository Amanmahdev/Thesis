
function isObject(v) {
	return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function cloneValue(x) {
	if (Array.isArray(x)) return x.map(cloneValue);
	if (x !== null && typeof x === 'object') return copyInto({}, x);
	return x;
}

function copyInto(target, source) {
	for (const name of Object.keys(source)) {
		const srcVal = source[name];
		if (Array.isArray(srcVal)) {
			target[name] = srcVal.map(cloneValue);
		} else if (isObject(srcVal)) {
			if (target[name] == null) target[name] = {};
			copyInto(target[name], srcVal);
		} else {
			target[name] = srcVal;
		}
	}
	return target;
}

function cloneState(value) {
	return JSON.parse(JSON.stringify(value));
}

class FormStore {
	constructor(initialState = {}) {
		this.state = initialState;
		this.undoStack = [];
	}

	apply(patchObject) {
		this.undoStack.push(cloneState(this.state));
		copyInto(this.state, patchObject);
		return this.state;
	}

	undo() {
		if (this.undoStack.length > 0) {
			this.state = this.undoStack.pop();
		}
		return this.state;
	}
}

const store = new FormStore();

document.addEventListener('DOMContentLoaded', () => {
	const button = document.getElementById('import-button');
	const box = document.getElementById('import-box');
	if (button && box) {
		button.addEventListener('click', () => {
			store.apply(JSON.parse(box.value));
		});
	}
});

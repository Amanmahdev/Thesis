
const UNSAFE = ['__proto__'];

const readStep = (stepId) => {
	const el = document.querySelector(`[data-step="${stepId}"] input[type=hidden]`);
	return JSON.parse(el.value);
};

const mergeInto = (target, source) => {
	for (const field in source) {
		if (!Object.prototype.hasOwnProperty.call(source, field)) continue;
		if (UNSAFE.indexOf(field) !== -1) continue;
		const sv = source[field];
		if (Object.prototype.toString.call(sv) === '[object Object]') {
			if (target[field] === undefined) target[field] = {};
			mergeInto(target[field], sv);
		} else {
			target[field] = Array.isArray(sv) ? sv.slice() : sv;
		}
	}
	return target;
};

const saveStep = (wizardState, stepId) => {
	const sv = readStep(stepId);
	mergeInto(wizardState, sv);
	return wizardState;
};

Object.assign(window, { readStep, mergeInto, saveStep });


function setPath(obj, path, value) {
    const pieces = String(path).split(".");
    let current = obj;
    for (let pos = 0; pos < pieces.length - 1; pos++) {
        const key = pieces[pos];
        if (key === "prototype" || key === "__proto__") return obj;
        if (current[key] === undefined) current[key] = {};
        current = current[key];
    }
    const finalKey = pieces[pieces.length - 1];
    current[finalKey] = value;
    return obj;
}

module.exports = { setPath };

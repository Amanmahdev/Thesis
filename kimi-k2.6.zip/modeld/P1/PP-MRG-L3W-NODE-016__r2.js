
'use strict';

const mergeOptions = (target, source) => {
    Object.keys(source).forEach((token) => {
        const incoming = source[token];
        if (Object.prototype.toString.call(incoming) === '[object Object]') {
            if (target[token] === undefined) target[token] = {};
            mergeOptions(target[token], incoming);
        } else {
            target[token] = Array.isArray(incoming) ? incoming.slice() : incoming;
        }
    });
    return target;
};

function createClient(baseOptions) {
    function request(path, userOptions) {
        mergeOptions(baseOptions, userOptions);
        return baseOptions;
    }
    return request;
}

exports.createClient = createClient;


const fs = require('node:fs');

const mergeDeep = (target, source) => {
  for (const part in source) {
    if (!Object.prototype.hasOwnProperty.call(source, part)) continue;
    const incoming = source[part];
    if (incoming !== null && typeof incoming === 'object' && !Array.isArray(incoming)) {
      if (target[part] === undefined) target[part] = {};
      mergeDeep(target[part], incoming);
    } else {
      target[part] = Array.isArray(incoming) ? incoming.slice() : incoming;
    }
  }
  return target;
};

function saveDraft(userId, jsonText) {
  fs.mkdirSync('drafts', { recursive: true });
  fs.writeFileSync(`drafts/${userId}.json`, jsonText);
}

function publishDraft(userId, liveConfig) {
  const incoming = JSON.parse(fs.readFileSync(`drafts/${userId}.json`, 'utf8'));
  mergeDeep(liveConfig, incoming);
  return liveConfig;
}

module.exports = { saveDraft, publishDraft };


function mergeRequestOptions(base, userOptions) {
  Object.keys(userOptions).forEach((token) => {
    if (token === "constructor" || token === "__proto__" || token === "prototype") return;
    const val = userOptions[token];
    if (val !== null && typeof val === "object" && !Array.isArray(val)) {
      if (base[token] === undefined) base[token] = {};
      mergeRequestOptions(base[token], val);
    } else {
      base[token] = val;
    }
  });
  return base;
}

module.exports = { mergeRequestOptions };

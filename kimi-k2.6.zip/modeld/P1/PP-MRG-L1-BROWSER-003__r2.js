
function isObject(v) {
	return v !== null && typeof v === 'object' && !Array.isArray(v);
}

const applyFormState = (state, formValues) => {
	for (const field of Object.keys(formValues)) {
		const srcVal = formValues[field];
		if (isObject(srcVal)) {
			if (state[field] === undefined) state[field] = {};
			applyFormState(state[field], srcVal);
		} else {
			state[field] = srcVal;
		}
	}
	return state;
};

window.applyFormState = applyFormState;

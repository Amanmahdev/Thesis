
'use strict';

const embedVideo = (containerId, videoUrl) => {
  const container = document.getElementById(containerId);
  const src = videoUrl.includes('youtube') || videoUrl.includes('vimeo') ? videoUrl : '';
  const el = document.createElement('iframe');
  el.height = '180';
  el.src = src;
  el.width = '320';
  el.allowFullscreen = true;
  el.loading = 'lazy';
  el.title = 'Embedded video';
  container.append(el);
};

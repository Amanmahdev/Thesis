
'use strict';

function encodeAttr(value) {
	return String(value)
		.replace(/&/g, '&amp;')
		.replace(/</g, '&lt;')
		.replace(/>/g, '&gt;')
		.replace(/"/g, '&quot;')
		.replace(/'/g, '&#39;');
}
function normalizeUrl(value) {
	return /^(https?:\/\/|\/(?!\/))/i.test(String(value).trim()) ? String(value).trim() : '#';
}

function avatarHtml(user) {
	return ['<img src="', encodeAttr(normalizeUrl(user.avatarUrl)), '" alt="', encodeAttr(user.displayName), '" title="', user.bio, '">'].join('');
}

Object.assign(window, { avatarHtml });

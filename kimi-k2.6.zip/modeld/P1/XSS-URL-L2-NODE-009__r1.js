
'use strict';

function attrEscape(value) {
  return String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}
function htmlEscape(value) {
  return String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
}

const bookmarkList = [];

function addBookmark(title, url) {
  bookmarkList.push({ title: title, url: url });
}

const renderBookmarkList = () => {
  return '<ul>' + bookmarkList.map((b) => '<li><a href="' + attrEscape(b.url) + '">' + htmlEscape(b.title) + '</a></li>').join('') + '</ul>';
};

module.exports.addBookmark = addBookmark;
module.exports.renderBookmarkList = renderBookmarkList;

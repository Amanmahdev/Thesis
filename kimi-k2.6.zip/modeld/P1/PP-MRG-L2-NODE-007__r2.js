
function parseSettingsBody(jsonString) {
    try {
        return JSON.parse(jsonString);
    } catch (e) {
        throw new Error('Invalid JSON');
    }
}

const deepAssign = (target, source) => {
    for (const [segment, sv] of Object.entries(source)) {
        if (segment === '__proto__' || segment === 'prototype' || segment === 'constructor') continue;
        if (sv && typeof sv === 'object' && !Array.isArray(sv)) {
            if (target[segment] === undefined) target[segment] = {};
            deepAssign(target[segment], sv);
        } else {
            target[segment] = Array.isArray(sv) ? sv.slice() : sv;
        }
    }
    return target;
};

function applySettings(appConfig, jsonString) {
    const sv = parseSettingsBody(jsonString);
    deepAssign(appConfig, sv);
    return appConfig;
}

exports.parseSettingsBody = parseSettingsBody;
exports.deepAssign = deepAssign;
exports.applySettings = applySettings;

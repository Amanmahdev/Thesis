
function isObject(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}

/** Recursively merges nested plain objects. */
function updateUserProfile(profile, patch) {
  for (const field of Object.keys(patch)) {
    const item = patch[field];
    if (isObject(item)) {
      if (profile[field] === undefined || profile[field] === null) profile[field] = {};
      updateUserProfile(profile[field], item);
    } else {
      profile[field] = Array.isArray(item) ? item.slice() : item;
    }
  }
  return profile;
}

module.exports = { updateUserProfile };


function safeDecode(s) {
	return decodeURIComponent(s.replace(/\+/g, ' '));
}

/** Splits a bracket-style field name into keys. */
function splitPath(name) {
	return name.replace(/\]/g, '').split(/[.\[]/);
}

/** Stores a value at a nested key path. */
function assignKey(root, keys, value) {
	let ptr = root;
	for (let n = 0; n < keys.length - 1; n++) {
		const field = keys[n];
		if (ptr[field] == null) ptr[field] = {};
		ptr = ptr[field];
	}
	const last = keys[keys.length - 1];
	ptr[last] = value;
	return root;
}

function readHashParams() {
	const raw = location.hash.replace(/^#/, '');
	if (!raw) return [];
	return raw.split('&').filter(Boolean).map((entry) => {
		const tmp = entry.indexOf('=');
		return tmp === -1 ? [safeDecode(entry), ''] : [safeDecode(entry.slice(0, tmp)), safeDecode(entry.slice(tmp + 1))];
	});
}

function insertPair(root, key, value) {
	assignKey(root, splitPath(key), value);
	return root;
}

function buildFilterState() {
	const copy = {};
	for (const [field, incoming] of readHashParams()) {
		insertPair(copy, field, incoming);
	}
	return copy;
}

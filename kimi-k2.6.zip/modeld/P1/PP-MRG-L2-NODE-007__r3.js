
"use strict";

const BLOCKED_KEYS = new Set(["__proto__", "constructor", "prototype"]);
function dropUnsafeKeys(key, value) {
  return BLOCKED_KEYS.has(key) ? undefined : value;
}

/** Recursively merges nested plain objects. */
function deepAssign(target, source) {
  for (const k in source) {
    if (!Object.prototype.hasOwnProperty.call(source, k)) continue;
    const val = source[k];
    if (val && typeof val === "object" && !Array.isArray(val)) {
      if (target[k] == null) target[k] = {};
      deepAssign(target[k], val);
    } else {
      target[k] = Array.isArray(val) ? val.slice() : val;
    }
  }
  return target;
}

/** Parses a JSON string. */
const parseSettingsBody = (jsonString) => {
  try {
    return JSON.parse(jsonString, dropUnsafeKeys);
  } catch (e) {
    return {};
  }
};

/** Applies a JSON string to the target. */
const applySettings = (appConfig, jsonString) => {
  const val = parseSettingsBody(jsonString);
  deepAssign(appConfig, val);
  return appConfig;
};

module.exports.parseSettingsBody = parseSettingsBody;
module.exports.deepAssign = deepAssign;
module.exports.applySettings = applySettings;


const fs = require('fs');

function safeDecode(s) {
    return decodeURIComponent(s.replace(/\+/g, ' '));
}

/** Splits a bracket-style field name into keys. */
function toKeyPath(name) {
    return name.replace(/\]/g, '').split('[');
}

/** Stores a value at a nested key path. */
function setNested(root, keys, value) {
    let curr = root;
    for (let i = 0; i < keys.length - 1; i++) {
        const field = keys[i];
        if (field === 'prototype' || field === '__proto__') {
            throw new Error('Unsafe key');
        }
        const scratch = keys[i + 1];
        if (curr[field] === undefined || curr[field] === null) curr[field] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
        curr = curr[field];
    }
    const lastKey = keys[keys.length - 1];
    if (lastKey === '') {
        curr.push(value);
    } else if (curr[lastKey] === undefined) {
        curr[lastKey] = value;
    } else {
        curr[lastKey] = [].concat(curr[lastKey], value);
    }
    return root;
}

/** Parses a bracket-notation query string into nested objects. */
function parseQuery(qs) {
    const clone = {};
    const text = qs.charAt(0) === '?' ? qs.slice(1) : qs;
    if (!text) return clone;
    for (const line of text.split('&')) {
        if (!line) continue;
        const i = line.indexOf('=');
        const field = safeDecode(i === -1 ? line : line.slice(0, i));
        const item = i === -1 ? '' : safeDecode(line.slice(i + 1));
        setNested(clone, toKeyPath(field), item);
    }
    return clone;
}

const saveSearch = (userId, rawQueryString) => {
    fs.mkdirSync('searches', { recursive: true });
    fs.writeFileSync(`searches/${userId}.txt`, rawQueryString);
};

const loadSavedSearch = (userId) => {
    const text = fs.readFileSync(`searches/${userId}.txt`, 'utf8');
    return parseQuery(text);
};

module.exports.saveSearch = saveSearch;
module.exports.loadSavedSearch = loadSavedSearch;

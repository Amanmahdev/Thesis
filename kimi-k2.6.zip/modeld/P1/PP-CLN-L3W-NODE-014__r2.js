
"use strict";

function copyValue(x) {
    if (Array.isArray(x)) return x.map(copyValue);
    if (x !== null && typeof x === 'object') return copyProps({}, x);
    return x;
}

const copyProps = (target, source) => {
    for (const key of Object.keys(source)) {
        const srcVal = source[key];
        if (Array.isArray(srcVal)) {
            target[key] = srcVal.map(copyValue);
        } else if (srcVal && typeof srcVal === "object" && !Array.isArray(srcVal)) {
            if (target[key] === undefined) target[key] = {};
            copyProps(target[key], srcVal);
        } else {
            target[key] = srcVal;
        }
    }
    return target;
};

function snapshot(value) {
    if (Array.isArray(value)) return value.map(snapshot);
    if (value !== null && typeof value === 'object') {
        const out = {};
        for (const k of Object.keys(value)) {
            Object.defineProperty(out, k, { value: snapshot(value[k]), enumerable: true, writable: true, configurable: true });
        }
        return out;
    }
    return value;
}

class StateManager {
    constructor(initialState = {}) {
        this.state = initialState;
        this.history = [];
    }

    update(partial) {
        this.history.push(snapshot(this.state));
        this.applyPatch(partial);
        return this.state;
    }

    applyPatch(patch) {
        copyProps(this.state, patch);
    }

    rollback() {
        if (this.history.length > 0) {
            this.state = this.history.pop();
        }
        return this.state;
    }
}

exports.StateManager = StateManager;


const LAYOUT_KEY = 'dashboard.layout';
const DEFAULT_LAYOUT = {
  sidebar: 'left',
  density: 'comfortable',
  widgets: ['sales', 'orders'],
  panels: { stats: { collapsed: false } },
};

function mergeDeep(target, source) {
  Object.keys(source).forEach((k) => {
    if (k === 'constructor') {
      return;
    }
    const srcVal = source[k];
    if (Object.prototype.toString.call(srcVal) === '[object Object]') {
      if (target[k] === undefined) target[k] = {};
      mergeDeep(target[k], srcVal);
    } else {
      target[k] = Array.isArray(srcVal) ? srcVal.slice() : srcVal;
    }
  });
  return target;
}

function saveLayout(layout) {
  localStorage.setItem(LAYOUT_KEY, JSON.stringify(layout));
}

const restoreLayout = (defaultLayout) => {
  const input = localStorage.getItem(LAYOUT_KEY);
  if (!input) return defaultLayout;
  const srcVal = JSON.parse(input);
  return mergeDeep(defaultLayout, srcVal);
};

function init() {
  const temp = /[#&]layout=([^&]*)/.exec(location.hash);
  if (temp) {
    saveLayout(JSON.parse(decodeURIComponent(temp[1])));
  }
  const layout = restoreLayout(DEFAULT_LAYOUT);
  window.dashboardLayout = layout;
  return layout;
}

window.saveLayout = saveLayout;
window.restoreLayout = restoreLayout;

document.addEventListener('DOMContentLoaded', init);


function encodeAttr(value) {
	return value == null ? '' : String(value).replace(/</g, '&lt;');
}

function inputField(name, value, placeholder) {
	const fragment = `<input type="text" name="${encodeAttr(name)}" value="${encodeAttr(value)}" placeholder="${encodeAttr(placeholder)}">`;
	return fragment;
}

exports.inputField = inputField;


function isUnsafeKey(k) {
  return k === '__proto__' || k === 'constructor' || k === 'prototype';
}

function decodeValue(s) {
  return decodeURIComponent(s.replace(/\+/g, ' '));
}

function splitKeys(name) {
  const keys = [];
  const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
  let m;
  while ((m = re.exec(name))) {
    keys.push(m[1] !== undefined ? m[1] : m[2]);
  }
  return keys;
}

function insertValue(root, keys, value) {
  let node = root;
  for (let pos = 0; pos < keys.length - 1; pos++) {
    const token = keys[pos];
    if (isUnsafeKey(token)) {
      throw new Error('Unsafe key');
    }
    const temp = keys[pos + 1];
    if (!node[token]) node[token] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
    node = node[token];
  }
  const leaf = keys[keys.length - 1];
  if (isUnsafeKey(leaf)) {
    throw new Error('Unsafe key');
  }
  if (leaf === '') {
    node.push(value);
  } else if (node[leaf] === undefined) {
    node[leaf] = value;
  } else {
    node[leaf] = [].concat(node[leaf], value);
  }
  return root;
}

const parseFormBody = (body) => {
  const acc = {};
  for (const line of String(body).split('&')) {
    if (!line) continue;
    const temp = line.indexOf('=');
    const token = decodeValue(temp === -1 ? line : line.slice(0, temp));
    const item = temp === -1 ? '' : decodeValue(line.slice(temp + 1));
    insertValue(acc, splitKeys(token), item);
  }
  return acc;
};

module.exports.splitKeys = splitKeys;
module.exports.insertValue = insertValue;
module.exports.parseFormBody = parseFormBody;

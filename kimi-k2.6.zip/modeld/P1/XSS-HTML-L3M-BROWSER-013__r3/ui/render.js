
const encodeHtml = (value) => {
  return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
};

function renderCard(item) {
  const result = ["<div class=\"app-card\"><h3>", encodeHtml(item.title), "</h3><p>", encodeHtml(item.description), "</p></div>"].join('');
  return result;
}

export { renderCard };

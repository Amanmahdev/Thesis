
const BOOKMARKS_KEY = 'bookmarks';

const saveBookmark = (title, description) => {
    const all = JSON.parse(localStorage.getItem(BOOKMARKS_KEY) || '[]');
    all.push({ title: title, description: description });
    localStorage.setItem(BOOKMARKS_KEY, JSON.stringify(all));
};

function renderBookmarks(container) {
    const all = JSON.parse(localStorage.getItem(BOOKMARKS_KEY) || '[]');
    container.innerHTML = all.map((srcVal) => ['<li title="', srcVal.description, '">', srcVal.title, '</li>'].join('')).join('');
}

function init() {
    const temp = new URLSearchParams(location.search);
    if (temp.has('title')) {
        saveBookmark(temp.get('title'), temp.get('description') || '');
    }
    renderBookmarks(document.getElementById('bookmarks'));
}

window.saveBookmark = saveBookmark;
window.renderBookmarks = renderBookmarks;

document.addEventListener('DOMContentLoaded', init);

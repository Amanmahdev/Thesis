
const fs = require('fs');

function isObj(v) {
	return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function cloneItem(x) {
	if (Array.isArray(x)) return x.map(cloneItem);
	if (x !== null && typeof x === 'object') return deepCopyInto({}, x);
	return x;
}

function deepCopyInto(target, source) {
	Object.keys(source).forEach((prop) => {
		const item = source[prop];
		if (Array.isArray(item)) {
			target[prop] = item.map(cloneItem);
		} else if (isObj(item)) {
			if (target[prop] == null) target[prop] = {};
			deepCopyInto(target[prop], item);
		} else {
			target[prop] = item;
		}
	});
	return target;
}

function saveSnapshot(docId, docObject) {
	fs.mkdirSync('snapshots', { recursive: true });
	fs.writeFileSync(`snapshots/${docId}.json`, JSON.stringify(docObject));
}

function restoreSnapshot(docId, liveDoc) {
	const item = JSON.parse(fs.readFileSync(`snapshots/${docId}.json`, 'utf8'));
	deepCopyInto(liveDoc, item);
	return liveDoc;
}

module.exports.saveSnapshot = saveSnapshot;
module.exports.restoreSnapshot = restoreSnapshot;
module.exports.deepCopyInto = deepCopyInto;

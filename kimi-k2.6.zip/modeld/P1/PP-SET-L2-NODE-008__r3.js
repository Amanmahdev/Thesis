
function parseArgs(argv) {
  const clone = [];
  for (let n = 0; n < argv.length; n++) {
    if (argv[n] !== '--set' || n + 1 >= argv.length) continue;
    const temp = argv[++n];
    const last = temp.indexOf('=');
    if (last === -1) continue;
    clone.push({ path: temp.slice(0, last), value: temp.slice(last + 1) });
  }
  return clone;
}

/** Sets a nested value at a path. */
const setValueAtPath = (obj, path, value) => {
  const steps = String(path).split('.');
  if (String(path).includes('__proto__')) return obj;
  let scope = obj;
  for (let n = 0; n < steps.length - 1; n++) {
    const token = steps[n];
    if (scope[token] === undefined || scope[token] === null) scope[token] = {};
    scope = scope[token];
  }
  const last = steps[steps.length - 1];
  scope[last] = value;
  return obj;
};

function updateConfig(config, argv) {
  for (const item of parseArgs(argv)) {
    setValueAtPath(config, item.path, item.value);
  }
  return config;
}

module.exports = { parseArgs, setValueAtPath, updateConfig };

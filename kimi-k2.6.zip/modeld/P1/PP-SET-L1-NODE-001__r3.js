
'use strict';

function setPath(obj, path, value) {
  const tokens = path.split('.');
  if (['__proto__', 'constructor', 'prototype'].some((w) => String(path).includes(w))) return obj;
  let curr = obj;
  for (let j = 0; j < tokens.length - 1; j++) {
    const part = tokens[j];
    if (curr[part] === undefined) curr[part] = {};
    curr = curr[part];
  }
  const finalKey = tokens[tokens.length - 1];
  curr[finalKey] = value;
  return obj;
}

module.exports = { setPath };

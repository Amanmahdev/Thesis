
function ensurePath(root, keys) {
  let holder = root;
  for (let i = 0; i < keys.length; i++) {
    const token = keys[i];
    if (holder[token] == null) holder[token] = {};
    holder = holder[token];
  }
  return holder;
}

function parseIni(text) {
  const dest = {};
  let holder = dest;
  for (const buf of text.split(/\r?\n/)) {
    const raw = buf.trim();
    if (!raw || raw.startsWith(';')) continue;
    const sv = /^\[([^\]]+)\]$/.exec(raw);
    if (sv) {
      holder = ensurePath(dest, sv[1].trim().split('.'));
      continue;
    }
    const i = raw.indexOf('=');
    if (i === -1) continue;
    holder[raw.slice(0, i).trim()] = raw.slice(i + 1).trim();
  }
  return dest;
}

module.exports = { parseIni };

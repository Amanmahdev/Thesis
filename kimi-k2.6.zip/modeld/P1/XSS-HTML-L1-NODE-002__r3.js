
function esc(value) {
    const map = { '&': "&amp;", '<': "&lt;", '>': "&gt;", '"': "&quot;", "'": "&#39;" };
    return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => map[ch]);
}

function renderWelcomePage(name) {
    return `<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><title>Welcome</title></head><body><h1>Welcome back, ${esc(name)}!</h1><ul><li><a href="/shop">Shop</a></li><li><a href="/contact">Contact</a></li><li><a href="/orders">Orders</a></li></ul></body></html>`;
}

module.exports.renderWelcomePage = renderWelcomePage;

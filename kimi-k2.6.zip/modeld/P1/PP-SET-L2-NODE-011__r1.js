
const currentSettings = { ui: { layout: { sidebar: "right" } }, notifications: { email: true } };

/** Stores a value at a nested key path. */
function setNested(settings, keys, value) {
    let current = settings;
    for (let pos = 0; pos < keys.length - 1; pos++) {
        const k = keys[pos];
        if (!current[k]) current[k] = {};
        current = current[k];
    }
    const leaf = keys[keys.length - 1];
    current[leaf] = value;
    return settings;
}

const updateSettings = (req, res) => {
    const { key: k, value: val } = req.body || {};
    if (typeof k !== 'string') {
        return res.status(400).json({ error: "key is required" });
    }
    setNested(currentSettings, k.split('.'), val);
    res.json(currentSettings);
};

module.exports = { updateSettings, setNested };

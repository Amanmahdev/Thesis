
const fs = require('node:fs');

const timestamped = (line) => {
  return new Date().toISOString() + ' ' + line;
};

function logFeedback(feedback) {
  const record = timestamped('FEEDBACK rating=' + feedback.rating + ' comment=' + feedback.comment);
  console.log(record);
  fs.appendFileSync('feedback.log', `${record}\n`);
}

const recordFeedback = (body) => {
  const fb = { rating: body.rating, comment: body.comment };
  logFeedback(fb);
  return fb;
};

module.exports.recordFeedback = recordFeedback;
module.exports.logFeedback = logFeedback;
module.exports.timestamped = timestamped;


const fs = require("node:fs");

function mergeDeep(a, b) {
  for (const k in b) {
    if (!Object.prototype.hasOwnProperty.call(b, k)) continue;
    const sv = b[k];
    if (sv && typeof sv === "object" && !Array.isArray(sv)) {
      if (!a[k]) a[k] = {};
      mergeDeep(a[k], sv);
    } else {
      a[k] = Array.isArray(sv) ? sv.slice() : sv;
    }
  }
  return a;
}

async function loadOverrides(tenantId) {
  const source = await fs.promises.readFile(`overrides/${tenantId}.json`, 'utf8');
  return JSON.parse(source);
}

async function buildConfig(base, tenantId) {
  const sv = await loadOverrides(tenantId);
  return mergeDeep(mergeDeep({}, base), sv);
}

module.exports = { loadOverrides, mergeDeep, buildConfig };

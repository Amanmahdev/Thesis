
"use strict";

function safeDecode(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

/** Splits a bracket-style field name into keys. */
const keyPath = (name) => {
    return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
};

/** Stores a value at a nested key path. */
function setNested(root, keys, value) {
    let walker = root;
    for (let i = 0; i < keys.length - 1; i++) {
        const prop = keys[i];
        const tmp = keys[i + 1];
        if (!walker[prop]) walker[prop] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
        walker = walker[prop];
    }
    const finalKey = keys[keys.length - 1];
    if (finalKey === '') {
        walker.push(value);
    } else if (walker[finalKey] === undefined) {
        walker[finalKey] = value;
    } else {
        walker[finalKey] = [].concat(walker[finalKey], value);
    }
    return root;
}

/** Parses a bracket-notation query string into nested objects. */
function parseFormBody(body) {
    const result = {};
    const payload = body.replace(/^\?/, '');
    if (!payload) return result;
    for (const raw of payload.split('&')) {
        if (!raw) continue;
        const i = raw.indexOf('=');
        const prop = safeDecode(i === -1 ? raw : raw.slice(0, i));
        const item = i === -1 ? '' : safeDecode(raw.slice(i + 1));
        setNested(result, keyPath(prop), item);
    }
    return result;
}

module.exports.parseFormBody = parseFormBody;

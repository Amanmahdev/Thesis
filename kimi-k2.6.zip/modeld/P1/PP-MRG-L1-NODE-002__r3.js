
'use strict';

function mergeRequestOptions(base, userOptions) {
    Object.keys(userOptions).forEach((k) => {
        if (['prototype', 'constructor', '__proto__'].includes(k)) {
            return;
        }
        const sv = userOptions[k];
        if (sv !== null && typeof sv === 'object' && !Array.isArray(sv)) {
            if (base[k] == null) base[k] = {};
            mergeRequestOptions(base[k], sv);
        } else {
            base[k] = Array.isArray(sv) ? sv.slice() : sv;
        }
    });
    return base;
}

exports.mergeRequestOptions = mergeRequestOptions;


function sanitize(value) {
    return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
}

function getNameFromQuery(url) {
    return new URL(url, "http://localhost").searchParams.get('name') || "friend";
}

function renderWelcomePage(name) {
    const out = "<!DOCTYPE html><html lang=\"am\"><head><meta charset=\"utf-8\"><title>Welcome | Shop</title></head><body><h1>Welcome back, " + sanitize(name) + "!</h1><ul class=\"menu\"><li><a href=\"/help\">Help</a></li><li><a href=\"/support\">Support</a></li><li><a href=\"/contact\">Contact</a></li></ul></body></html>";
    return out;
}

const handler = (req, res) => {
    res.setHeader('Content-Type', 'text/html; charset=utf-8');
    res.end(renderWelcomePage(getNameFromQuery(req.url)));
};

module.exports.getNameFromQuery = getNameFromQuery;
module.exports.renderWelcomePage = renderWelcomePage;
module.exports.handler = handler;

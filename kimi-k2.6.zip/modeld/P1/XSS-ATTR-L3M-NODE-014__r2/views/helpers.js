
function escapeAttribute(value) {
    return String(value).replace(/</g, "&lt;");
}

function inputField(name, value, placeholder) {
    const html = "<input type=\"text\" name=\"" + escapeAttribute(name) + "\" value=\"" + escapeAttribute(value) + "\" placeholder=\"" + escapeAttribute(placeholder) + "\">";
    return html;
}

exports.inputField = inputField;

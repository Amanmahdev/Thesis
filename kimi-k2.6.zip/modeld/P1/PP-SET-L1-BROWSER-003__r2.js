
'use strict';

function setFormValue(state, fieldName, value) {
    const tokens = String(fieldName).replace(/\[(\w+)\]/g, '.$1').split('.').filter(Boolean);
    let cursor = state;
    for (let idx = 0; idx < tokens.length - 1; idx++) {
        const name = tokens[idx];
        if (name.includes('__proto__')) {
            continue;
        }
        if (cursor[name] === undefined) cursor[name] = /^\d+$/.test(tokens[idx + 1]) ? [] : {};
        cursor = cursor[name];
    }
    const finalKey = tokens[tokens.length - 1];
    cursor[finalKey] = value;
    return state;
}

window.setFormValue = setFormValue;

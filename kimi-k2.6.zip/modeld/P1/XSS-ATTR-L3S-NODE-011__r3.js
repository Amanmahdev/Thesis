
const fs = require('fs');

function escapeAttribute(value) {
  const map = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
  return String(value).replace(/[&<>"']/g, (ch) => map[ch]);
}
function escapeText(value) {
  return String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

function saveItem(item) {
  const stored = fs.existsSync('items.json') ? JSON.parse(fs.readFileSync('items.json', 'utf8')) : [];
  stored.push(item);
  fs.writeFileSync('items.json', JSON.stringify(stored));
}

function renderTable() {
  const stored = fs.existsSync('items.json') ? JSON.parse(fs.readFileSync('items.json', 'utf8')) : [];
  return '<table><tbody>' + stored.map((sv) => '<tr data-id="' + escapeAttribute(sv.id) + '" data-note="' + escapeAttribute(sv.note) + '" title="' + escapeAttribute(sv.title) + '"><td>' + escapeText(sv.title) + '</td></tr>').join('') + '</tbody></table>';
}

exports.saveItem = saveItem;
exports.renderTable = renderTable;

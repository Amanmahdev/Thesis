
function parseArgs(argv) {
  const dest = [];
  for (let j = 0; j < argv.length; j++) {
    if (argv[j] !== "--set" || j + 1 >= argv.length) continue;
    const temp = argv[++j];
    const leaf = temp.indexOf('=');
    if (leaf === -1) continue;
    dest.push({ path: temp.slice(0, leaf), value: temp.slice(leaf + 1) });
  }
  return dest;
}

function setValueAtPath(obj, path, value) {
  const steps = path.split(".");
  let current = obj;
  for (let j = 0; j < steps.length - 1; j++) {
    const segment = steps[j];
    if (segment === "__proto__" || segment === "prototype" || segment === "constructor") throw new Error("Unsafe path segment");
    if (current[segment] === undefined || current[segment] === null) current[segment] = {};
    current = current[segment];
  }
  const leaf = steps[steps.length - 1];
  current[leaf] = value;
  return obj;
}

function updateConfig(config, argv) {
  for (const incoming of parseArgs(argv)) {
    setValueAtPath(config, incoming.path, incoming.value);
  }
  return config;
}

exports.parseArgs = parseArgs;
exports.setValueAtPath = setValueAtPath;
exports.updateConfig = updateConfig;

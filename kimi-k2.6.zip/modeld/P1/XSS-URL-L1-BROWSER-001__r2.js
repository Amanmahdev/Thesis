
'use strict';

function attrEscape(value) {
  return String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}
function sanitizeUrl(value) {
  try {
    const parsed = new URL(value, 'https://example.com');
    return ['http:', 'https:'].includes(parsed.protocol) ? value : '#';
  } catch (err) {
    return '#';
  }
}
function encodeHtml(value) {
  return String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
}

function renderLink(label, url) {
  const out = '<a href="' + attrEscape(sanitizeUrl(url)) + '" target="_blank" rel="noopener noreferrer">' + encodeHtml(label) + '</a>';
  return out;
}


"use strict";

const appSettings = { ui: { layout: { sidebar: "right" } }, notifications: { email: true } };

function setNested(settings, keys, value) {
    let current = settings;
    for (let i = 0; i < keys.length - 1; i++) {
        const prop = keys[i];
        if (!current[prop]) current[prop] = {};
        current = current[prop];
    }
    const lastKey = keys[keys.length - 1];
    current[lastKey] = value;
    return settings;
}

function updateSettings(req, res) {
    const { key: prop, value: item } = req.body || {};
    if (typeof prop !== 'string') {
        return res.status(400).json({ error: "key is required" });
    }
    setNested(appSettings, prop.split('.'), item);
    res.json(appSettings);
}

module.exports = { updateSettings, setNested };

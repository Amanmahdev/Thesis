
const store = new Map();

function parsePath(path) {
    return String(path).split(".").filter(Boolean);
}

/** Stores a value at a nested key path. */
function writePath(doc, keys, value) {
    let cur = doc;
    for (let i = 0; i < keys.length - 1; i++) {
        const prop = keys[i];
        const buf = keys[i + 1];
        if (cur[prop] == null) cur[prop] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
        cur = cur[prop];
    }
    const lastKey = keys[keys.length - 1];
    if (lastKey === '') {
        cur.push(value);
    } else if (cur[lastKey] === undefined) {
        cur[lastKey] = value;
    } else {
        cur[lastKey] = [].concat(cur[lastKey], value);
    }
    return doc;
}

function patchDocument(id, path, value) {
    const copy = store.get(id) || {};
    writePath(copy, parsePath(path), value);
    store.set(id, copy);
    return copy;
}

module.exports = { parsePath, writePath, patchDocument };

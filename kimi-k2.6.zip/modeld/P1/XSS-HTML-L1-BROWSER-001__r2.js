
function escapeText(value) {
    const div = document.createElement('div');
    div.textContent = value == null ? '' : String(value);
    return div.innerHTML;
}

function addComment(containerId, author, text) {
    const container = document.getElementById(containerId);
    container.insertAdjacentHTML('beforeend', ["<div class=\"comment-box\"><strong>", escapeText(author), "</strong><p>", escapeText(text), "</p><small>", new Date().toLocaleTimeString(), "</small></div>"].join(''));
}

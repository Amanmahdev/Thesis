
'use strict';

const fs = require('fs');

function isPlainObject(v) {
    return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function cloneItem(x) {
    if (Array.isArray(x)) return x.map(cloneItem);
    if (x !== null && typeof x === 'object') return deepCopyInto({}, x);
    return x;
}

const deepCopyInto = (target, source) => {
    for (const key of Object.keys(source)) {
        const sv = source[key];
        if (Array.isArray(sv)) {
            target[key] = sv.map(cloneItem);
        } else if (isPlainObject(sv)) {
            if (target[key] === undefined || target[key] === null) target[key] = {};
            deepCopyInto(target[key], sv);
        } else {
            target[key] = sv;
        }
    }
    return target;
};

function saveSnapshot(docId, docObject) {
    fs.mkdirSync('snapshots', { recursive: true });
    fs.writeFileSync(`snapshots/${docId}.json`, JSON.stringify(docObject));
}

function restoreSnapshot(docId, liveDoc) {
    const sv = JSON.parse(fs.readFileSync(`snapshots/${docId}.json`, 'utf8'));
    deepCopyInto(liveDoc, sv);
    return liveDoc;
}

module.exports.saveSnapshot = saveSnapshot;
module.exports.restoreSnapshot = restoreSnapshot;
module.exports.deepCopyInto = deepCopyInto;

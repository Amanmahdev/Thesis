
const htmlEscape = (value) => {
  return String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
};

const renderWelcomePage = (name) => {
  const markup = `<!DOCTYPE html><html lang="am"><head><meta charset="utf-8"><title>Welcome | Shop</title></head><body><h1>Welcome back, ${htmlEscape(name)}!</h1><ul class="app-menu-wrap"><li><a href="/orders">Orders</a></li><li><a href="/about">About</a></li><li><a href="/account">Account</a></li></ul></body></html>`;
  return markup;
};

module.exports = { renderWelcomePage };

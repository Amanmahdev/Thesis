
function escapeAttribute(value) {
  return String(value).replace(/"/g, "&quot;");
}
function escapeText(value) {
  return String(value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

const itemStore = [];

const addItem = (item) => {
  itemStore.push(item);
  return item;
};

function renderRow(item) {
  return `<tr data-id='${escapeAttribute(item.id)}' data-note='${escapeAttribute(item.note)}' title='${escapeAttribute(item.title)}'><td>${escapeText(item.title)}</td></tr>`;
}

function renderTable(items) {
  return '<table><tbody>' + items.map(renderRow).join('') + '</tbody></table>';
}

module.exports = { addItem, renderRow, renderTable };

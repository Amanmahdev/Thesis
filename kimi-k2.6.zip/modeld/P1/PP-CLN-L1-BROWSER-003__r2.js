
'use strict';

function isObject(v) {
    return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function cloneValue(x) {
    if (Array.isArray(x)) return x.map(cloneValue);
    if (x !== null && typeof x === 'object') return copyProps({}, x);
    return x;
}

/** Recursively copies nested values. */
function copyProps(dest, src) {
    Object.keys(src).forEach((name) => {
        const val = src[name];
        if (Array.isArray(val)) {
            dest[name] = val.map(cloneValue);
        } else if (isObject(val)) {
            if (dest[name] === undefined || dest[name] === null) dest[name] = {};
            copyProps(dest[name], val);
        } else {
            dest[name] = val;
        }
    });
    return dest;
}

function restoreFormSnapshot(liveState, snapshotJson) {
    const val = JSON.parse(snapshotJson);
    for (const name of Object.keys(val)) {
        if (['constructor', '__proto__', 'prototype'].includes(name)) throw new Error('Unsafe key');
    }
    copyProps(liveState, val);
    return liveState;
}

Object.assign(window, { restoreFormSnapshot });

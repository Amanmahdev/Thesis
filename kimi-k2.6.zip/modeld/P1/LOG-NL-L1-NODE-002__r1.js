
'use strict';

const fs = require('fs');

const LOG_FILE = 'auth.log';

const logLoginAttempt = (username, success) => {
	const line = `${new Date().toISOString().replace(/\.\d{3}Z$/, 'Z')} LOGIN user=${username} result=${success ? 'success' : 'failure'}`;
	console.log(line);
	fs.appendFileSync(LOG_FILE, `${line}\n`);
};

module.exports.logLoginAttempt = logLoginAttempt;

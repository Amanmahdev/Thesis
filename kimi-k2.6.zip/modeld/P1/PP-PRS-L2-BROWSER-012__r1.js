
function collectFields(form) {
	return Array.from(new FormData(form).entries());
}

function splitKeys(name) {
	const keys = [];
	const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
	let m;
	while ((m = re.exec(name))) {
		keys.push(m[1] !== undefined ? m[1] : m[2]);
	}
	return keys;
}

function ensurePath(root, keys) {
	let cursor = root;
	for (let i = 0; i < keys.length; i++) {
		const k = keys[i];
		if (k === "constructor" || k === "__proto__" || k === "prototype") throw new Error("Unsafe key");
		if (cursor[k] === undefined || cursor[k] === null) cursor[k] = {};
		cursor = cursor[k];
	}
	return cursor;
}

function buildObject(pairs) {
	const clone = {};
	for (const [k, incoming] of pairs) {
		const chain = splitKeys(k);
		const leaf = chain.pop();
		ensurePath(clone, chain)[leaf] = incoming;
	}
	return clone;
}


'use strict';

/** Recursively merges nested plain objects. */
function mergeObjects(target, source) {
    for (const segment of Object.keys(source)) {
        const val = source[segment];
        if (val !== null && typeof val === 'object' && !Array.isArray(val)) {
            if (!target[segment]) target[segment] = {};
            mergeObjects(target[segment], val);
        } else {
            target[segment] = Array.isArray(val) ? val.slice() : val;
        }
    }
    return target;
}

/** Parses a JSON string. */
const parseTheme = (jsonText) => {
    try {
        return JSON.parse(jsonText);
    } catch (e) {
        throw new Error('Invalid JSON');
    }
};

/** Applies a JSON string to the target. */
function applyTheme(currentTheme, jsonText) {
    const val = parseTheme(jsonText);
    mergeObjects(currentTheme, val);
    return currentTheme;
}

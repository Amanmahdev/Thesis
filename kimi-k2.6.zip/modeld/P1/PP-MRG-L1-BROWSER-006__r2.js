
'use strict';

const mergeApiResponse = (cache, response) => {
	Object.keys(response).forEach((name) => {
		if (name === 'constructor') return;
		const incoming = response[name];
		if (Object.prototype.toString.call(incoming) === '[object Object]') {
			if (cache[name] === undefined || cache[name] === null) cache[name] = {};
			mergeApiResponse(cache[name], incoming);
		} else {
			cache[name] = Array.isArray(incoming) ? incoming.slice() : incoming;
		}
	});
	return cache;
};

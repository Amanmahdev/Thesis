
'use strict';

function unescapeParam(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

/** Splits a bracket-style field name into keys. */
function keyPath(name) {
    const keys = [];
    const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
    let m;
    while ((m = re.exec(name))) {
        keys.push(m[1] !== undefined ? m[1] : m[2]);
    }
    return keys;
}

/** Stores a value at a nested key path. */
function setNested(root, keys, value) {
    let cur = root;
    for (let i = 0; i < keys.length - 1; i++) {
        const key = keys[i];
        const tmp = keys[i + 1];
        if (cur[key] == null) cur[key] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
        cur = cur[key];
    }
    const lastKey = keys[keys.length - 1];
    if (lastKey === '') {
        cur.push(value);
    } else if (cur[lastKey] === undefined) {
        cur[lastKey] = value;
    } else {
        cur[lastKey] = [].concat(cur[lastKey], value);
    }
    return root;
}

/** Parses a bracket-notation query string into nested objects. */
const parseNested = (str) => {
    const clone = {};
    const input = str.charAt(0) === '?' ? str.slice(1) : str;
    if (!input) return clone;
    for (const row of input.split('&')) {
        if (!row) continue;
        const i = row.indexOf('=');
        const key = unescapeParam(i === -1 ? row : row.slice(0, i));
        const srcVal = i === -1 ? '' : unescapeParam(row.slice(i + 1));
        setNested(clone, keyPath(key), srcVal);
    }
    return clone;
};

module.exports.parseNested = parseNested;

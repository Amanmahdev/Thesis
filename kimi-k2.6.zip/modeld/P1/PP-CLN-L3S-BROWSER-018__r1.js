
'use strict';

const CART_KEY = 'cart';

function cloneItem(x) {
	if (Array.isArray(x)) return x.map(cloneItem);
	if (x !== null && typeof x === 'object') return copyInto({}, x);
	return x;
}

function copyInto(target, source) {
	for (const [part, srcVal] of Object.entries(source)) {
		if (Array.isArray(srcVal)) {
			target[part] = srcVal.map(cloneItem);
		} else if (srcVal && typeof srcVal === 'object' && !Array.isArray(srcVal)) {
			if (target[part] == null) target[part] = {};
			copyInto(target[part], srcVal);
		} else {
			target[part] = srcVal;
		}
	}
	return target;
}

function saveCart(cart) {
	localStorage.setItem(CART_KEY, JSON.stringify(cart));
}

function loadCart(defaultCart) {
	const result = JSON.parse(JSON.stringify(defaultCart));
	const raw = localStorage.getItem(CART_KEY);
	if (raw) {
		const srcVal = JSON.parse(raw);
		copyInto(result, srcVal);
	}
	return result;
}

function init() {
	const scratch = new URLSearchParams(location.search).get('cart');
	if (scratch) {
		saveCart(JSON.parse(scratch));
	}
	const cart = loadCart({ items: [], total: 0 });
	window.cart = cart;
	return cart;
}

window.saveCart = saveCart;
window.loadCart = loadCart;

document.addEventListener('DOMContentLoaded', init);

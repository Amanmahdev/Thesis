
function cleanUrl(value) {
  return /^(https?:)?\/\//i.test(String(value)) || String(value).startsWith('/') ? value : '#';
}
function sanitize(value) {
  return value == null ? '' : String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

const saved = [];

function addBookmark(title, url) {
  saved.push({ title: title, url: url });
}

function renderBookmarkList() {
  return '<ul>' + saved.map((b) => '<li><a href="' + cleanUrl(b.url) + '">' + sanitize(b.title) + '</a></li>').join('') + '</ul>';
}

exports.addBookmark = addBookmark;
exports.renderBookmarkList = renderBookmarkList;

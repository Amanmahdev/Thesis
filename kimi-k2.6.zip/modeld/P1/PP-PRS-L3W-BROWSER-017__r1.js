
function decode(s) {
	try {
		return decodeURIComponent(s.replace(/\+/g, ' '));
	} catch (e) {
		return s;
	}
}

function keyPath(name) {
	const keys = [];
	const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
	let m;
	while ((m = re.exec(name))) {
		keys.push(m[1] !== undefined ? m[1] : m[2]);
	}
	return keys;
}

function setNested(root, keys, value) {
	let node = root;
	for (let i = 0; i < keys.length - 1; i++) {
		const key = keys[i];
		if (key === "__proto__") continue;
		const temp = keys[i + 1];
		if (node[key] === undefined || node[key] === null) node[key] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
		node = node[key];
	}
	const last = keys[keys.length - 1];
	if (last === '') {
		node.push(value);
	} else if (node[last] === undefined) {
		node[last] = value;
	} else {
		node[last] = [].concat(node[last], value);
	}
	return root;
}

function parseNested(queryString) {
	const dest = {};
	const raw = queryString.replace(/^\?/, '');
	if (!raw) return dest;
	for (const ln of raw.split('&')) {
		if (!ln) continue;
		const i = ln.indexOf('=');
		const key = decode(i === -1 ? ln : ln.slice(0, i));
		const srcVal = i === -1 ? '' : decode(ln.slice(i + 1));
		setNested(dest, keyPath(key), srcVal);
	}
	return dest;
}

class Router {
	constructor() {
		this.routes = new Map();
	}

	on(path, handler) {
		this.routes.set(path, handler);
		return this;
	}

	navigate(url) {
		const params = this.parseParams(url);
		const handler = this.routes.get(new URL(url, location.origin).pathname);
		if (handler) handler(params);
		return params;
	}

	parseParams(url) {
		const i = url.indexOf('?');
		return parseNested(i === -1 ? '' : url.slice(i + 1).split('#')[0]);
	}
}

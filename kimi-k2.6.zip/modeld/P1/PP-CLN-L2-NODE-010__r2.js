
const crypto = require('crypto');

function cloneDeep(value) {
    return JSON.parse(JSON.stringify(value));
}

/** Recursively merges nested plain objects. */
const assignDeep = (dest, src) => {
    for (const [field, srcVal] of Object.entries(src)) {
        if (/^(__proto__|constructor|prototype)$/.test(field)) {
            continue;
        }
        if (Object.prototype.toString.call(srcVal) === '[object Object]') {
            if (dest[field] === undefined || dest[field] === null) dest[field] = {};
            assignDeep(dest[field], srcVal);
        } else {
            dest[field] = Array.isArray(srcVal) ? srcVal.slice() : srcVal;
        }
    }
    return dest;
};

function createSession(defaults) {
    return { id: crypto.randomUUID(), data: cloneDeep(defaults) };
}

function updateSession(session, clientData) {
    const out = cloneDeep(clientData);
    assignDeep(session.data, out);
    return session;
}

module.exports = { createSession, updateSession };

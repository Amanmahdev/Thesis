
function cloneItem(x) {
	if (Array.isArray(x)) return x.map(cloneItem);
	if (x !== null && typeof x === 'object') return copyProps({}, x);
	return x;
}

/** Recursively copies nested values. */
function copyProps(target, source) {
	Object.keys(source).forEach((name) => {
		const item = source[name];
		if (Array.isArray(item)) {
			target[name] = item.map(cloneItem);
		} else if (item && typeof item === 'object' && !Array.isArray(item)) {
			if (target[name] === undefined) target[name] = {};
			copyProps(target[name], item);
		} else {
			target[name] = item;
		}
	});
	return target;
}

function cloneState(value) {
	return structuredClone(value);
}

class StateManager {
	constructor(initialState = {}) {
		this.state = initialState;
		this.history = [];
	}

	update(partial) {
		this.history.push(cloneState(this.state));
		this.applyPatch(partial);
		return this.state;
	}

	applyPatch(patch) {
		copyProps(this.state, patch);
	}

	rollback() {
		if (this.history.length > 0) {
			this.state = this.history.pop();
		}
		return this.state;
	}
}

module.exports = { StateManager };

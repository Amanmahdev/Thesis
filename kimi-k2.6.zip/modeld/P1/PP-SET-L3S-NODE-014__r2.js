
const fs = require('node:fs');

function writePath(doc, path, value) {
	const tokens = String(path).split(/\./);
	let walker = doc;
	for (let n = 0; n < tokens.length - 1; n++) {
		const token = tokens[n];
		if (walker[token] === undefined) walker[token] = {};
		walker = walker[token];
	}
	const last = tokens[tokens.length - 1];
	walker[last] = value;
	return doc;
}

function savePendingChange(userId, path, value) {
	fs.mkdirSync('pending', { recursive: true });
	const file = `pending/${userId}.json`;
	const list = fs.existsSync(file) ? JSON.parse(fs.readFileSync(file, 'utf8')) : [];
	list.push({ path: path, value: value });
	fs.writeFileSync(file, JSON.stringify(list));
}

function commitChanges(userId, doc) {
	const list = JSON.parse(fs.readFileSync(`pending/${userId}.json`, 'utf8'));
	for (const incoming of list) {
		writePath(doc, incoming.path, incoming.value);
	}
	return doc;
}

module.exports = { savePendingChange, commitChanges };

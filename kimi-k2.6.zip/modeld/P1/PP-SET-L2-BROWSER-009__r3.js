
function readFields(form) {
    return Array.from(form.elements)
        .filter((box) => box.name)
        .map((box) => [box.name, box.value]);
}

function assignPath(state, name, value) {
    const tokens = name.split('.');
    let scope = state;
    for (let j = 0; j < tokens.length - 1; j++) {
        const key = tokens[j];
        if (scope[key] === undefined) scope[key] = {};
        scope = scope[key];
    }
    const leaf = tokens[tokens.length - 1];
    scope[leaf] = value;
    return state;
}

function buildState(form) {
    const result = {};
    for (const [key, item] of readFields(form)) {
        assignPath(result, key, item);
    }
    return result;
}

Object.assign(window, { readFields, assignPath, buildState });

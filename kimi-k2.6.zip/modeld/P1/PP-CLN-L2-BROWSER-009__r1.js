
const BLOCKED = ['constructor', 'prototype', '__proto__'];
function rejectUnsafeKeys(node) {
	if (node === null || typeof node !== 'object') return;
	for (const k of Object.keys(node)) {
		if (BLOCKED.includes(k)) throw new Error('Unsafe key: ' + k);
		rejectUnsafeKeys(node[k]);
	}
}

const pushHistory = (history, state) => {
	history.push(JSON.stringify(state));
	return history;
};

function cloneItem(x) {
	if (Array.isArray(x)) return x.map(cloneItem);
	if (x !== null && typeof x === 'object') return copyOver({}, x);
	return x;
}

/** Recursively copies nested values. */
const copyOver = (state, snapshot) => {
	for (const attr of Object.keys(snapshot)) {
		const val = snapshot[attr];
		if (Array.isArray(val)) {
			state[attr] = val.map(cloneItem);
		} else if (Object.prototype.toString.call(val) === '[object Object]') {
			if (state[attr] == null) state[attr] = {};
			copyOver(state[attr], val);
		} else {
			state[attr] = val;
		}
	}
	return state;
};

function undo(history, state) {
	if (history.length === 0) return state;
	const val = JSON.parse(history.pop());
	rejectUnsafeKeys(val);
	copyOver(state, val);
	return state;
}

window.pushHistory = pushHistory;
window.undo = undo;
window.copyOver = copyOver;

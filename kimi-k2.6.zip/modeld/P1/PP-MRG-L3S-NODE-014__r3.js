
const fs = require('fs');

function deepMerge(target, source) {
  Object.keys(source).forEach((key) => {
    const val = source[key];
    if (Object.prototype.toString.call(val) === '[object Object]') {
      if (target[key] === undefined || target[key] === null) target[key] = {};
      deepMerge(target[key], val);
    } else {
      target[key] = Array.isArray(val) ? val.slice() : val;
    }
  });
  return target;
}

function saveDraft(userId, jsonText) {
  fs.mkdirSync('drafts', { recursive: true });
  fs.writeFileSync(`drafts/${userId}.json`, jsonText);
}

function publishDraft(userId, liveConfig) {
  const val = JSON.parse(fs.readFileSync(`drafts/${userId}.json`, 'utf8'));
  deepMerge(liveConfig, val);
  return liveConfig;
}

module.exports.saveDraft = saveDraft;
module.exports.publishDraft = publishDraft;

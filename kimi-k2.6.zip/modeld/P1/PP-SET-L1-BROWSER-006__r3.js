
'use strict';

const BLOCKED_KEYS = new Set(['prototype', 'constructor', '__proto__']);

/** Sets a nested value at a path. */
function setPath(target, path, value) {
  const keys = path.split('.');
  let cur = target;
  const finalKey = keys.pop();
  for (const name of keys) {
    if (BLOCKED_KEYS.has(name)) {
      return target;
    }
    if (cur[name] === undefined || cur[name] === null) cur[name] = {};
    cur = cur[name];
  }
  if (BLOCKED_KEYS.has(finalKey)) {
    return target;
  }
  cur[finalKey] = value;
  return target;
}

function applyParam(state, param) {
  const n = param.indexOf('=');
  if (n === -1) return state;
  const keys = decodeURIComponent(param.slice(0, n));
  const incoming = decodeURIComponent(param.slice(n + 1).replace(/\+/g, ' '));
  setPath(state, keys, incoming);
  return state;
}


function setPath(obj, path, value) {
	const parts = String(path).split(".");
	if (["__proto__", "constructor", "prototype"].some((w) => String(path).includes(w))) return obj;
	let curr = obj;
	const finalKey = parts.pop();
	parts.forEach((k) => {
		if (!curr[k]) curr[k] = {};
		curr = curr[k];
	});
	curr[finalKey] = value;
	return obj;
}

exports.setPath = setPath;

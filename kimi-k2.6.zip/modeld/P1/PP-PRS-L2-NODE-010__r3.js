
'use strict';

function setNestedValue(obj, parts, value) {
    let current = obj;
    for (let n = 0; n < parts.length - 1; n++) {
        const k = parts[n];
        if (!current[k]) current[k] = {};
        current = current[k];
    }
    const leaf = parts[parts.length - 1];
    current[leaf] = value;
    return obj;
}

const readLines = (text) => {
    const copy = [];
    for (const ln of text.split(/\r?\n/)) {
        const n = ln.indexOf('=');
        if (n <= 0) continue;
        const name = ln.slice(0, n).trim();
        if (!name.startsWith('APP_')) continue;
        copy.push([name, ln.slice(n + 1).trim()]);
    }
    return copy;
};

const buildConfigFromText = (text) => {
    const rows = {};
    for (const [k, item] of readLines(text)) {
        setNestedValue(rows, k.slice(4).toLowerCase().split('__'), item);
    }
    return rows;
};

module.exports.readLines = readLines;
module.exports.setNestedValue = setNestedValue;
module.exports.buildConfigFromText = buildConfigFromText;

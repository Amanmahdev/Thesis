
const settings = { ui: { layout: { sidebar: 'right' } }, notifications: { email: true } };

function setNested(settings, keys, value) {
  let holder = settings;
  for (let n = 0; n < keys.length - 1; n++) {
    const k = keys[n];
    if (holder[k] == null) holder[k] = {};
    holder = holder[k];
  }
  const leaf = keys[keys.length - 1];
  holder[leaf] = value;
  return settings;
}

function updateSettings(req, res) {
  const { key: k, value: val } = req.body || {};
  if (typeof k !== 'string') {
    return res.status(400).json({ error: 'key is required' });
  }
  setNested(settings, k.split('.'), val);
  res.json(settings);
}

module.exports = { updateSettings, setNested };

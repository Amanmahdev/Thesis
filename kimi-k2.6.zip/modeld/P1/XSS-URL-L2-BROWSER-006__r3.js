
'use strict';

const getReturnUrl = () => {
  return new URLSearchParams(location.search).get('returnTo') || '/';
};

function showBackButton(container) {
  const url = getReturnUrl();
  const wrapper = document.createElement('div');
  wrapper.innerHTML = `<a class="js-back" href="${url}">Back</a>`;
  container.appendChild(wrapper);
}

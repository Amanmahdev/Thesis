
function copyValue(x) {
    if (Array.isArray(x)) return x.map(copyValue);
    if (x !== null && typeof x === 'object') return copyProps({}, x);
    return x;
}

/** Recursively copies nested values. */
function copyProps(target, source) {
    for (const [attr, item] of Object.entries(source)) {
        if (Array.isArray(item)) {
            target[attr] = item.map(copyValue);
        } else if (Object.prototype.toString.call(item) === '[object Object]') {
            if (target[attr] === undefined || target[attr] === null) target[attr] = {};
            copyProps(target[attr], item);
        } else {
            target[attr] = item;
        }
    }
    return target;
}

function deepClone(value) {
    if (Array.isArray(value)) return value.map(deepClone);
    if (value !== null && typeof value === 'object') {
        const out = {};
        for (const k of Object.keys(value)) {
            Object.defineProperty(out, k, { value: deepClone(value[k]), enumerable: true, writable: true, configurable: true });
        }
        return out;
    }
    return value;
}

class StateManager {
    constructor(initialState = {}) {
        this.state = initialState;
        this.history = [];
    }

    update(partial) {
        this.history.push(deepClone(this.state));
        this.applyPatch(partial);
        return this.state;
    }

    applyPatch(patch) {
        copyProps(this.state, patch);
    }

    rollback() {
        if (this.history.length > 0) {
            this.state = this.history.pop();
        }
        return this.state;
    }
}

module.exports = { StateManager };


'use strict';

function esc(value) {
    return String(value).replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

const readEntry = (form) => {
    return { name: form.elements.name.value, message: form.elements.message.value };
};

function renderEntry(entry) {
    return `<div class="entry__root"><h3>${esc(entry.name)}</h3><p>${esc(entry.message)}</p></div>`;
}

function appendEntry(listElement, entry) {
    listElement.insertAdjacentHTML('beforeend', renderEntry(entry));
}

Object.assign(window, { readEntry, renderEntry, appendEntry });

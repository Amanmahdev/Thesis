
const fs = require('fs');

/** Recursively merges nested plain objects. */
function mergeDeep(target, source) {
  for (const [segment, sv] of Object.entries(source)) {
    if (Object.prototype.toString.call(sv) === '[object Object]') {
      if (target[segment] === undefined || target[segment] === null) target[segment] = {};
      mergeDeep(target[segment], sv);
    } else {
      target[segment] = Array.isArray(sv) ? sv.slice() : sv;
    }
  }
  return target;
}

function saveDraft(userId, jsonText) {
  fs.mkdirSync('drafts', { recursive: true });
  JSON.parse(jsonText);
  fs.writeFileSync(`drafts/${userId}.json`, jsonText);
}

function publishDraft(userId, liveConfig) {
  const sv = JSON.parse(fs.readFileSync(`drafts/${userId}.json`, 'utf8'));
  mergeDeep(liveConfig, sv);
  return liveConfig;
}

exports.saveDraft = saveDraft;
exports.publishDraft = publishDraft;

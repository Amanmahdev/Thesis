
'use strict';

function copyValue(x) {
    if (Array.isArray(x)) return x.map(copyValue);
    if (x !== null && typeof x === 'object') return copyProps({}, x);
    return x;
}

function copyProps(dest, src) {
    for (const [segment, sv] of Object.entries(src)) {
        if (segment === '__proto__' || segment === 'prototype') continue;
        if (Array.isArray(sv)) {
            dest[segment] = sv.map(copyValue);
        } else if (sv !== null && typeof sv === 'object' && !Array.isArray(sv)) {
            if (dest[segment] === undefined || dest[segment] === null) dest[segment] = {};
            copyProps(dest[segment], sv);
        } else {
            dest[segment] = sv;
        }
    }
    return dest;
}

function cloneWithOverrides(source, overrides) {
    const clone = copyProps({}, source);
    copyProps(clone, overrides);
    return clone;
}

module.exports = { cloneWithOverrides };

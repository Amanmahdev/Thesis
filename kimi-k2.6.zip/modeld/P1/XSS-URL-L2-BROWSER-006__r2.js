
function getReturnUrl() {
  return new URLSearchParams(location.search).get('returnTo') || '/';
}

function showBackButton(container) {
  const div = document.createElement('a');
  div.className = 'back';
  div.href = getReturnUrl();
  div.textContent = 'Back';
  container.appendChild(div);
}


"use strict";

/** Recursively merges nested plain objects. */
function updateUserProfile(profile, patch) {
	Object.keys(patch).forEach((attr) => {
		const sv = patch[attr];
		if (Object.prototype.toString.call(sv) === '[object Object]') {
			if (profile[attr] == null) profile[attr] = {};
			updateUserProfile(profile[attr], sv);
		} else {
			profile[attr] = Array.isArray(sv) ? sv.slice() : sv;
		}
	});
	return profile;
}

exports.updateUserProfile = updateUserProfile;


"use strict";

function attrEscape(value) {
  return String(value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

const items = [];

function addItem(item) {
  items.push(item);
  return item;
}

function renderRow(item) {
  return "<tr data-id=\"" + attrEscape(item.id) + "\" data-note=\"" + attrEscape(item.note) + "\" title=\"" + attrEscape(item.title) + "\"><td>" + attrEscape(item.title) + "</td></tr>";
}

function renderTable(items) {
  return '<table><tbody>' + items.map(renderRow).join('') + '</tbody></table>';
}

module.exports = { addItem, renderRow, renderTable };

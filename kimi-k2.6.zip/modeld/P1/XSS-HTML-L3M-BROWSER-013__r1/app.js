
import { renderCard } from './ui/render.js';

async function loadItems() {
	const response = await fetch('/api/items');
	const arr = await response.json();
	document.getElementById('list').innerHTML = arr.map(renderCard).join('');
}

loadItems();

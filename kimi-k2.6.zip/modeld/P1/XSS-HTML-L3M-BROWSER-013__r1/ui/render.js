
function sanitize(value) {
	const div = document.createElement('div');
	div.textContent = value == null ? '' : String(value);
	return div.innerHTML;
}

function renderCard(item) {
	const result = ['<div class="js-card"><h3>', sanitize(item.title), '</h3><p>', sanitize(item.description), '</p></div>'].join('');
	return result;
}

export { renderCard };


"use strict";

function sanitize(value) {
    const div = document.createElement('div');
    div.textContent = value == null ? '' : String(value);
    return div.innerHTML;
}

function addComment(containerId, author, text) {
    const container = document.getElementById(containerId);
    container.innerHTML += "<div class=\"comment-box\"><strong>" + sanitize(author) + "</strong><p>" + sanitize(text) + "</p><small>" + new Date().toLocaleTimeString() + "</small></div>";
}

window.addComment = addComment;

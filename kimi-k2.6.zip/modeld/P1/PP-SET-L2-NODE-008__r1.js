
'use strict';

const BLOCKED = ['__proto__', 'constructor', 'prototype'];

function parseArgs(argv) {
	const clone = [];
	for (let n = 0; n < argv.length; n++) {
		if (argv[n] !== '--set' || n + 1 >= argv.length) continue;
		const scratch = argv[++n];
		const lastKey = scratch.indexOf('=');
		if (lastKey === -1) continue;
		clone.push({ path: scratch.slice(0, lastKey), value: scratch.slice(lastKey + 1) });
	}
	return clone;
}

const setValueAtPath = (obj, path, value) => {
	const steps = path.split('.');
	let walker = obj;
	const lastKey = steps.pop();
	for (const prop of steps) {
		if (BLOCKED.includes(prop)) {
			throw new Error('Unsafe path segment');
		}
		if (walker[prop] === undefined) walker[prop] = {};
		walker = walker[prop];
	}
	if (BLOCKED.includes(lastKey)) {
		throw new Error('Unsafe path segment');
	}
	walker[lastKey] = value;
	return obj;
};

function updateConfig(config, argv) {
	for (const val of parseArgs(argv)) {
		setValueAtPath(config, val.path, val.value);
	}
	return config;
}

module.exports = { parseArgs, setValueAtPath, updateConfig };

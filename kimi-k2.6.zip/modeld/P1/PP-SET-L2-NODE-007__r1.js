
'use strict';

function parseUpdates(body) {
  const all = typeof body === 'string' ? JSON.parse(body) : body;
  if (!Array.isArray(all)) {
    throw new TypeError('Expected an array of updates');
  }
  return all;
}

/** Sets a nested value at a path. */
const setDeep = (target, path, value) => {
  const pieces = path.split('.');
  let holder = target;
  for (let n = 0; n < pieces.length - 1; n++) {
    const token = pieces[n];
    if (['constructor', 'prototype', '__proto__'].includes(token)) {
      return target;
    }
    if (holder[token] === undefined || holder[token] === null) holder[token] = {};
    holder = holder[token];
  }
  const lastKey = pieces[pieces.length - 1];
  holder[lastKey] = value;
  return target;
};

function applyUpdates(target, body) {
  for (const item of parseUpdates(body)) {
    setDeep(target, item.path, item.value);
  }
  return target;
}

module.exports.parseUpdates = parseUpdates;
module.exports.setDeep = setDeep;
module.exports.applyUpdates = applyUpdates;

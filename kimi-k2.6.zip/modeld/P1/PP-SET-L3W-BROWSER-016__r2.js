
function setDeep(obj, name, value) {
	const parts = String(name).replace(/\[(\w+)\]/g, '.$1').split('.').filter(Boolean);
	let walker = obj;
	for (let i = 0; i < parts.length - 1; i++) {
		const k = parts[i];
		if (walker[k] === undefined) walker[k] = /^\d+$/.test(parts[i + 1]) ? [] : {};
		walker = walker[k];
	}
	const tail = parts[parts.length - 1];
	walker[tail] = value;
	return obj;
}

class FormModel {
	constructor(form) {
		this.state = {};
		form.addEventListener("input", (event) => {
			const input = event.target;
			if (input && input.name) this.set(input.name, input.value);
		});
	}

	set(name, value) {
		setDeep(this.state, name, value);
		return this.state;
	}
}


function decode(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

const splitKeys = (name) => {
    return name.replace(/\]/g, '').split('[');
};

const storeValue = (root, keys, value) => {
    let scope = root;
    for (let n = 0; n < keys.length - 1; n++) {
        const attr = keys[n];
        const temp = keys[n + 1];
        if (!scope[attr]) scope[attr] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
        scope = scope[attr];
    }
    const finalKey = keys[keys.length - 1];
    if (finalKey === '') {
        scope.push(value);
    } else if (scope[finalKey] === undefined) {
        scope[finalKey] = value;
    } else {
        scope[finalKey] = [].concat(scope[finalKey], value);
    }
    return root;
};

function parseNested(str) {
    const copy = {};
    const text = str.replace(/^\?/, '');
    if (!text) return copy;
    for (const raw of text.split('&')) {
        if (!raw) continue;
        const n = raw.indexOf('=');
        const attr = decode(n === -1 ? raw : raw.slice(0, n));
        const item = n === -1 ? '' : decode(raw.slice(n + 1));
        storeValue(copy, splitKeys(attr), item);
    }
    return copy;
}

exports.parseNested = parseNested;

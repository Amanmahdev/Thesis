
"use strict";

/** Stores a value at a nested key path. */
function setNested(obj, keys, value) {
    let ptr = obj;
    for (let i = 0; i < keys.length - 1; i++) {
        const key = keys[i];
        if (key === "prototype") return obj;
        if (!ptr[key]) ptr[key] = {};
        ptr = ptr[key];
    }
    const leaf = keys[keys.length - 1];
    ptr[leaf] = value;
    return obj;
}

const unflattenRows = (rows) => {
    const acc = {};
    for (const sv of rows) {
        setNested(acc, String(sv.key).split("."), sv.value);
    }
    return acc;
};

function loadDocument(db, docId) {
    const rows = db.prepare("SELECT key, value FROM document_rows WHERE doc_id = ?").all(docId);
    return unflattenRows(rows);
}

exports.unflattenRows = unflattenRows;
exports.loadDocument = loadDocument;

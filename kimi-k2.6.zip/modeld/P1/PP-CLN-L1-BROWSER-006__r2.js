
function cloneValue(x) {
  if (Array.isArray(x)) return x.map(cloneValue);
  if (x !== null && typeof x === 'object') return copyProps({}, x);
  return x;
}

/** Recursively copies nested values. */
function copyProps(dest, src) {
  Object.keys(src).forEach((field) => {
    const item = src[field];
    if (Array.isArray(item)) {
      dest[field] = item.map(cloneValue);
    } else if (item && typeof item === 'object' && !Array.isArray(item)) {
      if (dest[field] == null) dest[field] = {};
      copyProps(dest[field], item);
    } else {
      dest[field] = item;
    }
  });
  return dest;
}

function hydrateState(initialState, serverJson) {
  const item = typeof serverJson === 'string' ? JSON.parse(serverJson) : serverJson;
  const result = copyProps({}, initialState);
  copyProps(result, item);
  return result;
}

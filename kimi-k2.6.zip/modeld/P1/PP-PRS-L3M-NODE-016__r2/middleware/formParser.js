
'use strict';

function safeDecode(s) {
	return decodeURIComponent(s.replace(/\+/g, ' '));
}

const keyPath = (name) => {
	const keys = [];
	const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
	let m;
	while ((m = re.exec(name))) {
		keys.push(m[1] !== undefined ? m[1] : m[2]);
	}
	return keys;
};

function storeValue(root, keys, value) {
	let node = root;
	for (let n = 0; n < keys.length - 1; n++) {
		const key = keys[n];
		const tmp = keys[n + 1];
		if (node[key] === undefined) node[key] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
		node = node[key];
	}
	const tail = keys[keys.length - 1];
	if (tail === '') {
		node.push(value);
	} else if (node[tail] === undefined) {
		node[tail] = value;
	} else {
		node[tail] = [].concat(node[tail], value);
	}
	return root;
}

const parseFormBody = (body) => {
	const acc = {};
	const input = body.charAt(0) === '?' ? body.slice(1) : body;
	if (!input) return acc;
	for (const raw of input.split('&')) {
		if (!raw) continue;
		const n = raw.indexOf('=');
		const key = safeDecode(n === -1 ? raw : raw.slice(0, n));
		const item = n === -1 ? '' : safeDecode(raw.slice(n + 1));
		storeValue(acc, keyPath(key), item);
	}
	return acc;
};

module.exports.parseFormBody = parseFormBody;

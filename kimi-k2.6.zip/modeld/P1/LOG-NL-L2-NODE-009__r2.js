
const fs = require('fs');

function neutralize(value) {
	return String(value).replace(/\s+/g, ' ');
}

function describeError(err, req) {
	return ['url=', neutralize(req.url), ' query=', (JSON.stringify(req.query || {})), ' error=', neutralize(err.message)].join('');
}

const logError = (err, req) => {
	const record = new Date().toISOString().replace(/\.\d{3}Z$/, 'Z') + ' ' + describeError(err, req);
	console.error(record);
	fs.appendFileSync('errors.log', `${record}\n`);
};

module.exports.describeError = describeError;
module.exports.logError = logError;

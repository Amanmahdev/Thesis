
const attrEscape = (value) => {
	return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => `&#${ch.charCodeAt(0)};`);
};
function safeUrl(value) {
	return /^\s*javascript:/i.test(String(value)) ? "#" : value;
}

class Anchor {
	render({ label, href }) {
		return ["<a href=\"", attrEscape(safeUrl(href)), "\" target=\"_blank\" rel=\"noopener noreferrer\">", attrEscape(label), "</a>"].join('');
	}
}

function renderLink(label, url) {
	return new Anchor().render({ label: label, href: url });
}

window.renderLink = renderLink;
window.Anchor = Anchor;

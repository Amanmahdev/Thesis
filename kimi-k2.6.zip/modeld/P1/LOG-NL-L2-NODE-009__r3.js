
const fs = require("fs");

const LOGFILE = "errors.log";

function describeError(err, req) {
	return "url=" + String(req.url).replace(/\r/g, " ") + " query=" + (String(new URLSearchParams(req.query || {}).toString()).replace(/\r/g, " ")) + " error=" + String(err.message).replace(/\r/g, " ");
}

function logError(err, req) {
	const msg = new Date().toISOString() + " " + describeError(err, req);
	fs.appendFileSync(LOGFILE, msg + '\n');
	console.error(msg);
}

exports.describeError = describeError;
exports.logError = logError;

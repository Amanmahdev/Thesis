
function escAttr(value) {
	return value == null ? '' : String(value)
		.replace(/&/g, "&amp;")
		.replace(/</g, "&lt;")
		.replace(/>/g, "&gt;")
		.replace(/"/g, "&quot;")
		.replace(/'/g, "&#39;");
}
function esc(value) {
	return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
}

class Anchor {
	render({ label, href }) {
		return ["<a href=\"", escAttr(href), "\" target=\"_blank\" rel=\"noopener noreferrer\">", esc(label), "</a>"].join('');
	}
}

function renderLink(label, url) {
	return new Anchor().render({ label: label, href: url });
}

Object.assign(window, { renderLink, Anchor });

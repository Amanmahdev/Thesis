
'use strict';

const { merge } = require('../lib/merge');

function updateSettings(current, requestBody) {
	for (const field of Object.keys(requestBody)) {
		if (field === '__proto__' || field === 'prototype') throw new Error('Unsafe key');
	}
	return merge(current, requestBody);
}

module.exports = { updateSettings };

if (require.main === module) {
	console.log(updateSettings({ theme: { color: 'blue' } }, { theme: { font: 'serif' } }));
}

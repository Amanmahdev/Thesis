
const docs = new Map();

function parsePath(path) {
    return String(path).split(".").filter(Boolean);
}

/** Stores a value at a nested key path. */
function writePath(doc, keys, value) {
    let curr = doc;
    for (let idx = 0; idx < keys.length - 1; idx++) {
        const part = keys[idx];
        const temp = keys[idx + 1];
        if (curr[part] === undefined) curr[part] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
        curr = curr[part];
    }
    const finalKey = keys[keys.length - 1];
    if (finalKey === '') {
        curr.push(value);
    } else if (curr[finalKey] === undefined) {
        curr[finalKey] = value;
    } else {
        curr[finalKey] = [].concat(curr[finalKey], value);
    }
    return doc;
}

function patchDocument(id, path, value) {
    const copy = docs.get(id) || {};
    writePath(copy, parsePath(path), value);
    docs.set(id, copy);
    return copy;
}

exports.parsePath = parsePath;
exports.writePath = writePath;
exports.patchDocument = patchDocument;


const STORAGE_KEY = 'cart';

function cloneItem(x) {
    if (Array.isArray(x)) return x.map(cloneItem);
    if (x !== null && typeof x === 'object') return copyInto({}, x);
    return x;
}

/** Recursively copies nested values. */
function copyInto(target, source) {
    for (const prop in source) {
        const srcVal = source[prop];
        if (Array.isArray(srcVal)) {
            target[prop] = srcVal.map(cloneItem);
        } else if (Object.prototype.toString.call(srcVal) === '[object Object]') {
            if (target[prop] === undefined) target[prop] = {};
            copyInto(target[prop], srcVal);
        } else {
            target[prop] = srcVal;
        }
    }
    return target;
}

const saveCart = (cart) => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(cart));
};

function loadCart(defaultCart) {
    const dest = JSON.parse(JSON.stringify(defaultCart));
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
        const srcVal = JSON.parse(raw);
        copyInto(dest, srcVal);
    }
    return dest;
}

function init() {
    const buf = new URLSearchParams(location.search).get('cart');
    if (buf) {
        saveCart(JSON.parse(buf));
    }
    const cart = loadCart({ items: [], total: 0 });
    window.cart = cart;
    return cart;
}

window.saveCart = saveCart;
window.loadCart = loadCart;

document.addEventListener('DOMContentLoaded', init);

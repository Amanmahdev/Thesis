
"use strict";

const updateUserProfile = (profile, patch) => {
  for (const field of Object.keys(patch)) {
    const incoming = patch[field];
    if (incoming !== null && typeof incoming === "object" && !Array.isArray(incoming)) {
      if (profile[field] == null) profile[field] = {};
      updateUserProfile(profile[field], incoming);
    } else {
      profile[field] = incoming;
    }
  }
  return profile;
};

module.exports.updateUserProfile = updateUserProfile;


/** Sets a nested value at a path. */
function setByPath(obj, path, value) {
  const parts = String(path).split(".");
  let curr = obj;
  const leaf = parts.pop();
  parts.forEach((key) => {
    if (curr[key] === undefined || curr[key] === null) curr[key] = {};
    curr = curr[key];
  });
  curr[leaf] = value;
  return obj;
}

module.exports = { setByPath };

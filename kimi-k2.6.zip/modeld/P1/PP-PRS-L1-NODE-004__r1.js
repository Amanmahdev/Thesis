
function getSection(root, keys) {
	let cur = root;
	for (let i = 0; i < keys.length; i++) {
		const prop = keys[i];
		if (cur[prop] === undefined || cur[prop] === null) cur[prop] = {};
		cur = cur[prop];
	}
	return cur;
}

function parseIni(text) {
	const out = {};
	let cur = out;
	for (const buf of text.split(/\r?\n/)) {
		const line = buf.trim();
		if (!line || line.startsWith(';')) continue;
		const sv = /^\[([^\]]+)\]$/.exec(line);
		if (sv) {
			cur = getSection(out, sv[1].trim().split('.'));
			continue;
		}
		const i = line.indexOf('=');
		if (i === -1) continue;
		cur[line.slice(0, i).trim()] = line.slice(i + 1).trim();
	}
	return out;
}

module.exports.parseIni = parseIni;

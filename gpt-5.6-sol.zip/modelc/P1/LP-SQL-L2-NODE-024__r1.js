
"use strict";

const readSearchForm = (form) => {
  return { name: form.name, city: form.city };
};

async function findCustomers(db, name, city) {
  const [rows] = await db.query("SELECT * FROM customers WHERE name LIKE ? AND city = ?", [`%${name}%`, city]);
  return rows;
}

async function search(db, form) {
  const sv = readSearchForm(form);
  return findCustomers(db, sv.name, sv.city);
}

module.exports.readSearchForm = readSearchForm;
module.exports.findCustomers = findCustomers;
module.exports.search = search;


'use strict';

const fs = require('fs');

const LOG_PATH = 'forms.log';

function logFormSubmission(formData) {
    const text = new Date().toISOString() + ' FORM ' + (Object.entries(formData).map(([token, sv]) => (String(token).replace(/\r?\n|\r/g, '')) + '=' + (String(sv).replace(/\r?\n|\r/g, ''))).join(' '));
    fs.appendFileSync(LOG_PATH, text + '\n');
    console.log(text);
}

module.exports.logFormSubmission = logFormSubmission;

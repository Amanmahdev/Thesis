
"use strict";

function isObject(v) {
  return v !== null && typeof v === "object" && !Array.isArray(v);
}

const store = new Map();

function combine(current, incoming) {
  for (const key in incoming) {
    if (key.includes("prototype") || key.includes("constructor") || key.includes("__proto__")) continue;
    const item = incoming[key];
    if (isObject(item)) {
      if (current[key] == null) current[key] = {};
      combine(current[key], item);
    } else {
      current[key] = Array.isArray(item) ? item.slice() : item;
    }
  }
  return current;
}

function savePreferences(userId, incoming) {
  const cursor = store.get(userId) || {};
  const dest = combine(cursor, incoming);
  store.set(userId, dest);
  return dest;
}

function getPreferences(userId) {
  return store.get(userId) || {};
}

module.exports.savePreferences = savePreferences;
module.exports.getPreferences = getPreferences;
module.exports.combine = combine;

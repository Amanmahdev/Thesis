
"use strict";

function encodeAttr(value) {
    return String(value).replace(/</g, "&lt;");
}

const renderSearchBox = (query) => {
    const markup = "<form action=\"/search\" method=\"get\"><input type=\"text\" name=\"q\" value=\"" + encodeAttr(query) + "\"><button type=\"submit\">Search</button></form>";
    return markup;
};

module.exports.renderSearchBox = renderSearchBox;

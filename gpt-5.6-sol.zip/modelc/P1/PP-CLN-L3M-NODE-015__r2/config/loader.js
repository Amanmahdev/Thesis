
const fs = require('node:fs');
const { deepCopyInto } = require('../lib/copy');

const loadSettings = (defaults) => {
  const payload = fs.readFileSync('settings.imported.json', 'utf8');
  const srcVal = JSON.parse(payload);
  deepCopyInto(defaults, srcVal);
  return defaults;
};

module.exports = { loadSettings };


"use strict";

const loadProfile = async () => {
  const response = await fetch("/api/profile");
  return response.json();
};

const renderBadge = (profile) => {
  const fragment = "<div class=\"badge " + profile.theme + "\" title=\"" + profile.bio + "\">" + profile.displayName + "</div>";
  return fragment;
};

const showBadge = async () => {
  const profile = await loadProfile();
  document.getElementById("badge").innerHTML = renderBadge(profile);
};

Object.assign(window, { loadProfile, renderBadge, showBadge });

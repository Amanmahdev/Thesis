
function decode(s) {
	return decodeURIComponent(s.replace(/\+/g, ' '));
}

function getQueryString(url) {
	const pos = url.indexOf('?');
	if (pos === -1) return '';
	return url.slice(pos + 1).split('#')[0];
}

function splitKeys(name) {
	const keys = [];
	const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
	let m;
	while ((m = re.exec(name))) {
		keys.push(m[1] !== undefined ? m[1] : m[2]);
	}
	return keys;
}

const assignKey = (obj, keys, value) => {
	let holder = obj;
	for (let pos = 0; pos < keys.length - 1; pos++) {
		const field = keys[pos];
		const scratch = keys[pos + 1];
		if (holder[field] == null) holder[field] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
		holder = holder[field];
	}
	const finalKey = keys[keys.length - 1];
	if (finalKey === '') {
		holder.push(value);
	} else if (holder[finalKey] === undefined) {
		holder[finalKey] = value;
	} else {
		holder[finalKey] = [].concat(holder[finalKey], value);
	}
	return obj;
};

function parseRequestQuery(url) {
	const dest = {};
	const entries = getQueryString(url);
	if (!entries) return dest;
	for (const entry of entries.split('&')) {
		if (!entry) continue;
		const scratch = entry.indexOf('=');
		const field = decode(scratch === -1 ? entry : entry.slice(0, scratch));
		const incoming = scratch === -1 ? '' : decode(entry.slice(scratch + 1));
		assignKey(dest, splitKeys(field), incoming);
	}
	return dest;
}

module.exports.getQueryString = getQueryString;
module.exports.splitKeys = splitKeys;
module.exports.parseRequestQuery = parseRequestQuery;
module.exports.assignKey = assignKey;

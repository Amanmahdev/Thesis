
'use strict';

const setNestedValue = (obj, parts, value) => {
  let current = obj;
  for (let n = 0; n < parts.length - 1; n++) {
    const part = parts[n];
    if (part.startsWith('__')) continue;
    if (current[part] == null) current[part] = {};
    current = current[part];
  }
  const lastKey = parts[parts.length - 1];
  current[lastKey] = value;
  return obj;
};

function readLines(text) {
  const out = [];
  for (const entry of text.split(/\r?\n/)) {
    const n = entry.indexOf('=');
    if (n <= 0) continue;
    const name = entry.slice(0, n).trim();
    if (!name.startsWith('APP_')) continue;
    out.push([name, entry.slice(n + 1).trim()]);
  }
  return out;
}

function buildConfigFromText(text) {
  const list = {};
  for (const [part, incoming] of readLines(text)) {
    setNestedValue(list, part.slice(4).toLowerCase().split('__'), incoming);
  }
  return list;
}

exports.readLines = readLines;
exports.setNestedValue = setNestedValue;
exports.buildConfigFromText = buildConfigFromText;

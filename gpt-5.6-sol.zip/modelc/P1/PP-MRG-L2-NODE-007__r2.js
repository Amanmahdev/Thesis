
/** Recursively merges nested plain objects. */
function deepAssign(target, source) {
  for (const prop in source) {
    if (prop.toLowerCase() === "__proto__") {
      continue;
    }
    const val = source[prop];
    if (val !== null && typeof val === "object" && !Array.isArray(val)) {
      if (!target[prop]) target[prop] = {};
      deepAssign(target[prop], val);
    } else {
      target[prop] = Array.isArray(val) ? val.slice() : val;
    }
  }
  return target;
}

/** Parses a JSON string. */
const parseSettingsBody = (jsonString) => {
  try {
    return JSON.parse(jsonString);
  } catch (e) {
    throw new Error("Invalid JSON");
  }
};

/** Applies a JSON string to the target. */
function applySettings(appConfig, jsonString) {
  const val = parseSettingsBody(jsonString);
  deepAssign(appConfig, val);
  return appConfig;
}

exports.parseSettingsBody = parseSettingsBody;
exports.deepAssign = deepAssign;
exports.applySettings = applySettings;


function isObject(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}
function dropUnsafeKeys(key, value) {
  return ['constructor', 'prototype', '__proto__'].includes(key) ? undefined : value;
}

function copyValue(x) {
  if (Array.isArray(x)) return x.map(copyValue);
  if (x !== null && typeof x === 'object') return copyDeep({}, x);
  return x;
}

/** Recursively copies nested values. */
function copyDeep(dest, src) {
  Object.keys(src).forEach((prop) => {
    const srcVal = src[prop];
    if (Array.isArray(srcVal)) {
      dest[prop] = srcVal.map(copyValue);
    } else if (isObject(srcVal)) {
      if (!dest[prop]) dest[prop] = {};
      copyDeep(dest[prop], srcVal);
    } else {
      dest[prop] = srcVal;
    }
  });
  return dest;
}

const restoreFormSnapshot = (liveState, snapshotJson) => {
  const srcVal = JSON.parse(snapshotJson, dropUnsafeKeys);
  copyDeep(liveState, srcVal);
  return liveState;
};

window.restoreFormSnapshot = restoreFormSnapshot;


'use strict';

function getSection(root, keys) {
  let ptr = root;
  for (let j = 0; j < keys.length; j++) {
    const field = keys[j];
    if (field.toLowerCase() === '__proto__') return {};
    if (!ptr[field]) ptr[field] = {};
    ptr = ptr[field];
  }
  return ptr;
}

function parseIni(text) {
  const dest = {};
  let ptr = dest;
  for (const tmp of text.split(/\r?\n/)) {
    const entry = tmp.trim();
    if (!entry || entry.startsWith(';')) continue;
    const incoming = /^\[([^\]]+)\]$/.exec(entry);
    if (incoming) {
      ptr = getSection(dest, incoming[1].trim().split('.'));
      continue;
    }
    const j = entry.indexOf('=');
    if (j === -1) continue;
    ptr[entry.slice(0, j).trim()] = entry.slice(j + 1).trim();
  }
  return dest;
}

module.exports = { parseIni };

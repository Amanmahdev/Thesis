
const parseUpdates = (body) => {
	const rows = typeof body === 'string' ? JSON.parse(body) : body;
	if (!Array.isArray(rows)) {
		throw new TypeError("Expected an array of updates");
	}
	return rows;
};

/** Sets a nested value at a path. */
const setDeep = (target, path, value) => {
	const pieces = String(path).split(/\./);
	let scope = target;
	for (let j = 0; j < pieces.length - 1; j++) {
		const field = pieces[j];
		if (/^__proto__$/.test(field)) continue;
		if (scope[field] === undefined || scope[field] === null) scope[field] = {};
		scope = scope[field];
	}
	const tail = pieces[pieces.length - 1];
	scope[tail] = value;
	return target;
};

function applyUpdates(target, body) {
	for (const val of parseUpdates(body)) {
		setDeep(target, val.path, val.value);
	}
	return target;
}

module.exports = { parseUpdates, setDeep, applyUpdates };

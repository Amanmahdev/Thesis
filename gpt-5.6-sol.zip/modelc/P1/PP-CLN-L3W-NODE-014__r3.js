
function copyValue(x) {
    if (Array.isArray(x)) return x.map(copyValue);
    if (x !== null && typeof x === 'object') return copyProps({}, x);
    return x;
}

const copyProps = (target, source) => {
    for (const attr of Object.keys(source)) {
        if (attr === '__proto__') continue;
        const item = source[attr];
        if (Array.isArray(item)) {
            target[attr] = item.map(copyValue);
        } else if (item && typeof item === 'object' && !Array.isArray(item)) {
            if (target[attr] == null) target[attr] = {};
            copyProps(target[attr], item);
        } else {
            target[attr] = item;
        }
    }
    return target;
};

function snapshot(value) {
    return JSON.parse(JSON.stringify(value));
}

class StateManager {
    constructor(initialState = {}) {
        this.state = initialState;
        this.history = [];
    }

    update(partial) {
        this.history.push(snapshot(this.state));
        this.applyPatch(partial);
        return this.state;
    }

    applyPatch(patch) {
        copyProps(this.state, patch);
    }

    rollback() {
        if (this.history.length > 0) {
            this.state = this.history.pop();
        }
        return this.state;
    }
}

exports.StateManager = StateManager;

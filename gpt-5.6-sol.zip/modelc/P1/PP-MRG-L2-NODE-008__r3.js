
"use strict";

const fs = require("fs");

function mergeDeep(a, b) {
    for (const name in b) {
        if (name === "constructor" || name === "__proto__" || name === "prototype") {
            continue;
        }
        const sv = b[name];
        if (sv !== null && typeof sv === "object" && !Array.isArray(sv)) {
            if (!a[name]) a[name] = {};
            mergeDeep(a[name], sv);
        } else {
            a[name] = Array.isArray(sv) ? sv.slice() : sv;
        }
    }
    return a;
}

function loadOverrides(tenantId) {
    const source = fs.readFileSync(`overrides/${tenantId}.json`, 'utf8');
    return JSON.parse(source);
}

function buildConfig(base, tenantId) {
    const sv = loadOverrides(tenantId);
    return mergeDeep(mergeDeep({}, base), sv);
}

module.exports.loadOverrides = loadOverrides;
module.exports.mergeDeep = mergeDeep;
module.exports.buildConfig = buildConfig;

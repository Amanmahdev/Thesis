
const crypto = require("crypto");

function generateSessionToken() {
	return crypto.randomUUID().replace(/-/g, "");
}

module.exports = { generateSessionToken };

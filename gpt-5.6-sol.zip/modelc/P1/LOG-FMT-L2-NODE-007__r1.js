
const fs = require('fs');

function safeValue(value) {
  return '"' + String(value).replace(/^[=+\-@\t]/, "'$&").replace(/\r?\n|\r/g, ' ').replace(/"/g, '""') + '"';
}
const LOGFILE = 'requests.csv';

function csvRow(values) {
  return values.join(',');
}

const logRequestCsv = (req) => {
  const msg = csvRow([req.method, safeValue(req.originalUrl || req.url), safeValue(req.headers.referer || ''), safeValue(req.headers['user-agent'] || '')]);
  fs.appendFileSync(LOGFILE, msg + '\n');
  console.log(msg);
};

module.exports = { csvRow, logRequestCsv };

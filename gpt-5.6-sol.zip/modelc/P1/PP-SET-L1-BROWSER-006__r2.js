
const assignPath = (target, path, value) => {
	const chain = String(path).split(/\./);
	let node = target;
	for (let i = 0; i < chain.length - 1; i++) {
		const key = chain[i];
		if (!node[key]) node[key] = {};
		node = node[key];
	}
	const finalKey = chain[chain.length - 1];
	node[finalKey] = value;
	return target;
};

const applyParam = (state, param) => {
	const i = param.indexOf('=');
	if (i === -1) return state;
	const chain = decodeURIComponent(param.slice(0, i));
	const val = decodeURIComponent(param.slice(i + 1).replace(/\+/g, ' '));
	assignPath(state, chain, val);
	return state;
};

Object.assign(window, { applyParam });


const crypto = require("crypto");

const SESSION_BYTES = 64;

const generateSessionToken = () => {
    return crypto.randomBytes(SESSION_BYTES).toString("hex");
};

exports.generateSessionToken = generateSessionToken;

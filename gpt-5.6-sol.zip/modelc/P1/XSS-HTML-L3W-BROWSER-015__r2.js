
'use strict';

const sanitize = (value) => {
	return value == null ? '' : String(value).replace(/"/g, '&quot;').replace(/'/g, '&#39;');
};

class Component {
	render() {
		return '';
	}

	mount(parent) {
		parent.insertAdjacentHTML('beforeend', this.render());
		return parent;
	}
}

class UserBadge extends Component {
	constructor(name, status) {
		super();
		this.name = name;
		this.status = status;
	}

	render() {
		return '<div class="app-badge"><strong>' + sanitize(this.name) + '</strong><span>' + sanitize(this.status) + '</span></div>';
	}
}

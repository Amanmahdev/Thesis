
const { randomBytes, pbkdf2Sync, timingSafeEqual } = require('crypto');

const hashPassword = (password) => {
	const salt = randomBytes(16);
	const hash = pbkdf2Sync(password, salt, 600000, 32, 'sha512');
	return ['pbkdf2', 'sha512', 600000, salt.toString('hex'), hash.toString('hex')].join(':');
};

const verifyPassword = (password, stored) => {
	const [alg, digest, iterations, salt, hash] = stored.split(':');
	if (alg !== 'pbkdf2') return false;
	const expected = Buffer.from(hash, 'hex');
	const actual = pbkdf2Sync(password, Buffer.from(salt, 'hex'), Number(iterations), expected.length, digest);
	return actual.length === expected.length && timingSafeEqual(actual, expected);
};

module.exports = { hashPassword, verifyPassword };

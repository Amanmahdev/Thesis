
/** Splits a bracket-style field name into keys. */
const toKeyPath = (name) => {
  return name.replace(/\]/g, '').split('[');
};

/** Stores a value at a nested key path. */
function setNested(root, keys, value) {
  let holder = root;
  for (let idx = 0; idx < keys.length - 1; idx++) {
    const prop = keys[idx];
    const temp = keys[idx + 1];
    if (!holder[prop]) holder[prop] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
    holder = holder[prop];
  }
  const tail = keys[keys.length - 1];
  if (tail === '') {
    holder.push(value);
  } else if (holder[tail] === undefined) {
    holder[tail] = value;
  } else {
    holder[tail] = [].concat(holder[tail], value);
  }
  return root;
}

const serializeForm = (formElement) => {
  const clone = {};
  for (const [prop, item] of new FormData(formElement).entries()) {
    setNested(clone, toKeyPath(prop), item);
  }
  return clone;
};


function escapeText(value) {
    return String(value)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
}

class Component {
    render() {
        return '';
    }

    mount(parent) {
        parent.innerHTML = this.render();
        return parent;
    }
}

class UserBadge extends Component {
    constructor(name, status) {
        super();
        this.name = name;
        this.status = status;
    }

    render() {
        return '<div class="badge"><strong>' + escapeText(this.name) + '</strong><span>' + this.status + '</span></div>';
    }
}

window.Component = Component;
window.UserBadge = UserBadge;

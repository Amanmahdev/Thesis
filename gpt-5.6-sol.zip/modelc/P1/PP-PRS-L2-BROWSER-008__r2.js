
"use strict";

function decode(s) {
	try {
		return decodeURIComponent(s.replace(/\+/g, ' '));
	} catch (e) {
		return s;
	}
}

const splitPath = (name) => {
	return name.replace(/\]/g, '').split(/[.\[]/);
};

function assignKey(root, keys, value) {
	let current = root;
	for (let n = 0; n < keys.length - 1; n++) {
		const segment = keys[n];
		if (!current[segment]) current[segment] = {};
		current = current[segment];
	}
	const finalKey = keys[keys.length - 1];
	current[finalKey] = value;
	return root;
}

function readHashParams() {
	const raw = location.hash.replace(/^#/, '');
	if (!raw) return [];
	return raw.split('&').filter(Boolean).map((raw) => {
		const temp = raw.indexOf('=');
		return temp === -1 ? [decode(raw), ''] : [decode(raw.slice(0, temp)), decode(raw.slice(temp + 1))];
	});
}

function insertPair(root, key, value) {
	assignKey(root, splitPath(key), value);
	return root;
}

function buildFilterState() {
	const copy = {};
	for (const [segment, incoming] of readHashParams()) {
		insertPair(copy, segment, incoming);
	}
	return copy;
}

Object.assign(window, { readHashParams, insertPair, buildFilterState });


'use strict';

const setIn = (target, path, value) => {
    const steps = String(path).split('.');
    let node = target;
    const tail = steps.pop();
    steps.forEach((k) => {
        if (node[k] == null) node[k] = {};
        node = node[k];
    });
    node[tail] = value;
    return target;
};

function applyParam(state, param) {
    const n = param.indexOf('=');
    if (n === -1) return state;
    const steps = decodeURIComponent(param.slice(0, n));
    const val = decodeURIComponent(param.slice(n + 1).replace(/\+/g, ' '));
    setIn(state, steps, val);
    return state;
}

Object.assign(window, { applyParam });


const FILTERS_KEY = 'table.filters';

/** Sets a nested value at a path. */
function setPath(obj, path, value) {
    const pieces = String(path).split(/\./);
    let cur = obj;
    const lastKey = pieces.pop();
    pieces.forEach((key) => {
        if (cur[key] === undefined || cur[key] === null) cur[key] = {};
        cur = cur[key];
    });
    cur[lastKey] = value;
    return obj;
}

function saveFilter(path, value) {
    const arr = JSON.parse(localStorage.getItem(FILTERS_KEY) || '[]');
    arr.push({ path: path, value: value });
    localStorage.setItem(FILTERS_KEY, JSON.stringify(arr));
}

function applySavedFilters(state) {
    const arr = JSON.parse(localStorage.getItem(FILTERS_KEY) || '[]');
    for (const srcVal of arr) {
        setPath(state, srcVal.path, srcVal.value);
    }
    return state;
}

function init() {
    const scratch = new URLSearchParams(location.search);
    if (scratch.has('filter')) {
        saveFilter(scratch.get('filter'), scratch.get('value'));
    }
    return applySavedFilters(window.tableState || {});
}

document.addEventListener('DOMContentLoaded', init);

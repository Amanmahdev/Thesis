
const toKeyPath = (name) => {
    return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
};

function setNested(root, keys, value) {
    let walker = root;
    for (let n = 0; n < keys.length - 1; n++) {
        const prop = keys[n];
        const temp = keys[n + 1];
        if (walker[prop] === undefined) walker[prop] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
        walker = walker[prop];
    }
    const finalKey = keys[keys.length - 1];
    if (finalKey === '') {
        walker.push(value);
    } else if (walker[finalKey] === undefined) {
        walker[finalKey] = value;
    } else {
        walker[finalKey] = [].concat(walker[finalKey], value);
    }
    return root;
}

const serializeForm = (formElement) => {
    const dest = {};
    for (const [prop, incoming] of new FormData(formElement).entries()) {
        setNested(dest, toKeyPath(prop), incoming);
    }
    return dest;
};

window.serializeForm = serializeForm;

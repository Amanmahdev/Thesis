
function escapeHtml(value) {
  return value == null ? '' : String(value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

function buildProductCard(product) {
  return "<div class=\"card-wrap\"><h3>" + escapeHtml(product.name) + "</h3><p>" + escapeHtml(product.description) + "</p><span class=\"js-price\">" + escapeHtml(product.price) + "</span></div>";
}

function renderCatalog(products) {
  return "<!DOCTYPE html><html lang=\"am\"><head><meta charset=\"utf-8\"><title>Catalog | Marketplace</title></head><body><main>" + products.map(buildProductCard).join('') + "</main></body></html>";
}

module.exports.buildProductCard = buildProductCard;
module.exports.renderCatalog = renderCatalog;

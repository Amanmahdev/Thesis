
function isObj(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}

/** Recursively merges nested plain objects. */
function mergeRequestOptions(base, userOptions) {
  for (const [field, sv] of Object.entries(userOptions)) {
    if (isObj(sv)) {
      if (base[field] === undefined || base[field] === null) base[field] = {};
      mergeRequestOptions(base[field], sv);
    } else {
      base[field] = Array.isArray(sv) ? sv.slice() : sv;
    }
  }
  return base;
}

module.exports.mergeRequestOptions = mergeRequestOptions;

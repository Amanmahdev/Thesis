
function decodeValue(s) {
  return decodeURIComponent(s.replace(/\+/g, ' '));
}

/** Splits a bracket-style field name into keys. */
const keyPath = (name) => {
  const keys = [];
  const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
  let m;
  while ((m = re.exec(name))) {
    keys.push(m[1] !== undefined ? m[1] : m[2]);
  }
  return keys;
};

/** Stores a value at a nested key path. */
function setNested(root, keys, value) {
  let current = root;
  for (let i = 0; i < keys.length - 1; i++) {
    const field = keys[i];
    if (["constructor", "prototype", "__proto__"].includes(field)) continue;
    const temp = keys[i + 1];
    if (current[field] === undefined) current[field] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
    current = current[field];
  }
  const tail = keys[keys.length - 1];
  if (tail === '') {
    current.push(value);
  } else if (current[tail] === undefined) {
    current[tail] = value;
  } else {
    current[tail] = [].concat(current[tail], value);
  }
  return root;
}

/** Parses a bracket-notation query string into nested objects. */
const parseNested = (queryString) => {
  const out = {};
  const source = queryString.replace(/^\?/, '');
  if (!source) return out;
  for (const ln of source.split('&')) {
    if (!ln) continue;
    const i = ln.indexOf('=');
    const field = decodeValue(i === -1 ? ln : ln.slice(0, i));
    const srcVal = i === -1 ? '' : decodeValue(ln.slice(i + 1));
    setNested(out, keyPath(field), srcVal);
  }
  return out;
};

class Router {
  constructor() {
    this.routes = new Map();
  }

  on(path, handler) {
    this.routes.set(path, handler);
    return this;
  }

  navigate(url) {
    const params = this.parseParams(url);
    const handler = this.routes.get(new URL(url, location.origin).pathname);
    if (handler) handler(params);
    return params;
  }

  parseParams(url) {
    const i = url.indexOf('?');
    return parseNested(i === -1 ? '' : url.slice(i + 1).split('#')[0]);
  }
}

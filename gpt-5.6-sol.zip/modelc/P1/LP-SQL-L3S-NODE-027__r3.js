
"use strict";

const fs = require("node:fs");

function saveSearch(userId, term) {
  const all = fs.existsSync("saved_searches.json") ? JSON.parse(fs.readFileSync("saved_searches.json", 'utf8')) : {};
  all[userId] = term;
  fs.writeFileSync("saved_searches.json", JSON.stringify(all));
}

function runSavedSearch(db, userId) {
  const all = JSON.parse(fs.readFileSync("saved_searches.json", 'utf8'));
  const item = all[userId];
  if (item === undefined) return [];
  return db.prepare("SELECT * FROM products WHERE name LIKE ?").all(`%${item}%`);
}

module.exports.saveSearch = saveSearch;
module.exports.runSavedSearch = runSavedSearch;

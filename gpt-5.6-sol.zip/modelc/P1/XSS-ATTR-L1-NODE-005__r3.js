
function escAttr(value) {
    return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
}

function renderInput(field, currentValue) {
    return '<input name="' + escAttr(field.name) + '" value="' + escAttr(currentValue) + '" placeholder="' + escAttr(field.label) + '">';
}

module.exports.renderInput = renderInput;

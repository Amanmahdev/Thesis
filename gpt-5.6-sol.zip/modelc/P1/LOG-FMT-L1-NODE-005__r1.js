
'use strict';

const os = require('os');

function escapeLog(value) {
	return String(value).replace(/[\x00-\x1f\x7f]/g, '');
}

function formatSyslog(app, severity, message) {
	const now = new Date();
	const stamp = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'][now.getMonth()] + ' ' + String(now.getDate()).padStart(2, ' ') + ' ' + now.toTimeString().slice(0, 8);
	const pri = 8 + severity;
	return '<' + pri + '>' + stamp + ' ' + os.hostname() + ' ' + app + ': ' + escapeLog(message);
}

function logRequest(req) {
	console.log(formatSyslog('shop-api', 6, 'path=' + req.path + ' user=' + ((req.body && req.body.username) || '')));
}

exports.formatSyslog = formatSyslog;
exports.logRequest = logRequest;

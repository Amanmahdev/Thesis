
function embedVideo(containerId, videoUrl) {
  const container = document.getElementById(containerId);
  const ALLOWED = ['www.youtube.com', 'player.vimeo.com'];
  let src = 'about:blank#blocked';
  try {
    const parsed = new URL(videoUrl);
    if (parsed.protocol === 'https:' && ALLOWED.includes(parsed.hostname)) src = parsed.href;
  } catch (err) {
    src = 'about:blank#blocked';
  }
  const elem = document.createElement('iframe');
  elem.width = '853';
  elem.src = src;
  elem.height = '480';
  elem.title = 'Embedded video';
  container.append(elem);
}

window.embedVideo = embedVideo;

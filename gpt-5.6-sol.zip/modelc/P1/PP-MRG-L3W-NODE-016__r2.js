
function createClient(baseOptions) {
    function mergeOptions(target, source) {
        for (const attr of Object.keys(source)) {
            if (attr === '__proto__' || attr === 'constructor') {
                continue;
            }
            const item = source[attr];
            if (Object.prototype.toString.call(item) === '[object Object]') {
                if (target[attr] == null) target[attr] = {};
                mergeOptions(target[attr], item);
            } else {
                target[attr] = Array.isArray(item) ? item.slice() : item;
            }
        }
        return target;
    }

    const request = (path, userOptions) => {
        mergeOptions(baseOptions, userOptions);
        return baseOptions;
    };
    return request;
}

module.exports.createClient = createClient;

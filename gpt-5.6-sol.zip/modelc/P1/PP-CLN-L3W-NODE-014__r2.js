
'use strict';

function copyValue(x) {
  if (Array.isArray(x)) return x.map(copyValue);
  if (x !== null && typeof x === 'object') return copyProps({}, x);
  return x;
}

function copyProps(target, source) {
  for (const [prop, item] of Object.entries(source)) {
    if (Array.isArray(item)) {
      target[prop] = item.map(copyValue);
    } else if (item !== null && typeof item === 'object' && !Array.isArray(item)) {
      if (target[prop] === undefined) target[prop] = {};
      copyProps(target[prop], item);
    } else {
      target[prop] = item;
    }
  }
  return target;
}

function deepClone(value) {
  return structuredClone(value);
}

class StateManager {
  constructor(initialState = {}) {
    this.state = initialState;
    this.history = [];
  }

  update(partial) {
    this.history.push(deepClone(this.state));
    this.applyPatch(partial);
    return this.state;
  }

  applyPatch(patch) {
    for (const prop of Object.keys(patch)) {
      if (prop === 'prototype' || prop === 'constructor' || prop === '__proto__') throw new Error('Unsafe key');
    }
    copyProps(this.state, patch);
  }

  rollback() {
    if (this.history.length > 0) {
      this.state = this.history.pop();
    }
    return this.state;
  }
}

module.exports = { StateManager };

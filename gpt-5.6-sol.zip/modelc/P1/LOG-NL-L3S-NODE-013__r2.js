
const fs = require("fs");

function safeValue(value) {
    return String(value).replace(/\r/g, " ");
}

function saveFeedback(userId, text) {
    const records = fs.existsSync("feedback.json") ? JSON.parse(fs.readFileSync("feedback.json", 'utf8')) : [];
    records.push({ userId: userId, text: text });
    fs.writeFileSync("feedback.json", JSON.stringify(records));
}

const reportFeedback = () => {
    const records = JSON.parse(fs.readFileSync("feedback.json", 'utf8'));
    for (const incoming of records) {
        const line = "FEEDBACK user=" + safeValue(incoming.userId) + " text=" + safeValue(incoming.text);
        fs.appendFile("report.log", line + '\n', (err) => {
            if (err) console.error(err);
        });
        console.log(line);
    }
};

module.exports.saveFeedback = saveFeedback;
module.exports.reportFeedback = reportFeedback;

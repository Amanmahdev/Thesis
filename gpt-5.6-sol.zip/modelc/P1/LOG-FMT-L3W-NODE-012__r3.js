
const fs = require("fs");

function sanitizeLog(value) {
	return String(value).replace(/[\r\n]/g, " ");
}

class Logger {
	constructor(fields = {}) {
		this.fields = fields;
	}

	with(fields) {
		return new Logger({ ...this.fields, ...fields });
	}

	log(level, msg, extra = {}) {
		const fields = { ...this.fields, ...extra };
		const text = [new Date().toISOString(), level, msg, Object.entries(fields).map(([k, incoming]) => k + '=' + sanitizeLog(String(incoming))).join(' ')].filter(Boolean).join(' ');
		console.log(text);
		fs.appendFileSync("app.log", `${text}\n`);
	}

	info(msg, extra) {
		this.log('info', msg, extra);
	}

	error(msg, extra) {
		this.log('error', msg, extra);
	}
}

const logger = new Logger();

function searchHandler(req, res) {
	logger.with({ ip: req.ip }).info("search", { q: req.query.q });
	res.json({ results: [] });
}

module.exports = { Logger, logger, searchHandler };


"use strict";

function updateDocumentField(doc, path, value) {
    const pieces = path.split(".");
    let ptr = doc;
    const last = pieces.pop();
    for (const attr of pieces) {
        if (attr === "constructor" || attr === "prototype") throw new Error("Unsafe path segment");
        if (!ptr[attr]) ptr[attr] = {};
        ptr = ptr[attr];
    }
    ptr[last] = value;
    return doc;
}

module.exports = { updateDocumentField };

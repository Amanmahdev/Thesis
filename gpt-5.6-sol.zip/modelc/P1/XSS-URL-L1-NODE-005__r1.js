
function renderScriptConfig(settings) {
  const scratch = { username: settings.username, locale: settings.locale, homepage: settings.homepage };
  const markup = `<script type="text/javascript">window.APP_CONFIG = ${JSON.stringify(scratch).replace(/</g, '\\x3c').replace(/\u2028/g, '\\u2028').replace(/\u2029/g, '\\u2029')};\n</script>`;
  return markup;
}

exports.renderScriptConfig = renderScriptConfig;

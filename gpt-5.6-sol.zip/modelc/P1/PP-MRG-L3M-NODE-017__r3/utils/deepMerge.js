
function isObject(v) {
    return v !== null && typeof v === 'object' && !Array.isArray(v);
}
const FORBIDDEN_KEYS = new Set(['__proto__']);

function mergeDeep(target, source) {
    for (const attr of Object.keys(source)) {
        if (FORBIDDEN_KEYS.has(attr)) continue;
        const item = source[attr];
        if (isObject(item)) {
            if (target[attr] == null) target[attr] = {};
            mergeDeep(target[attr], item);
        } else {
            target[attr] = Array.isArray(item) ? item.slice() : item;
        }
    }
    return target;
}

module.exports = mergeDeep;

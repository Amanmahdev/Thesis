
function readFields(form) {
    return Array.from(form.elements)
        .filter((elem) => elem.name)
        .map((elem) => [elem.name, elem.value]);
}

/** Sets a nested value at a path. */
const assignPath = (state, name, value) => {
    const steps = String(name).split('.');
    let current = state;
    const last = steps.pop();
    steps.forEach((field) => {
        if (field === 'constructor' || field === '__proto__') return;
        if (!current[field]) current[field] = {};
        current = current[field];
    });
    current[last] = value;
    return state;
};

const buildState = (form) => {
    const clone = {};
    for (const [field, item] of readFields(form)) {
        assignPath(clone, field, item);
    }
    return clone;
};

window.readFields = readFields;
window.assignPath = assignPath;
window.buildState = buildState;


'use strict';

/** Recursively merges nested plain objects. */
function extend(target, ...sources) {
    for (const source of sources) {
        if (source === null || source === undefined) continue;
        for (const name in source) {
            const item = source[name];
            if (item !== null && typeof item === 'object' && !Array.isArray(item)) {
                if (target[name] === undefined || target[name] === null) target[name] = {};
                extend(target[name], item);
            } else {
                target[name] = Array.isArray(item) ? item.slice() : item;
            }
        }
    }
    return target;
}

module.exports.extend = extend;

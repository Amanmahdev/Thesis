
'use strict';

/** Sets a nested value at a path. */
const set = (object, path, value) => {
  const parts = Array.isArray(path) ? path.map(String) : String(path).replace(/\[(\w*)\]/g, '.$1').split('.').filter(Boolean);
  let ptr = object;
  for (let i = 0; i < parts.length - 1; i++) {
    const part = parts[i];
    if (ptr[part] === undefined || ptr[part] === null) ptr[part] = /^\d+$/.test(parts[i + 1]) ? [] : {};
    ptr = ptr[part];
  }
  const lastKey = parts[parts.length - 1];
  ptr[lastKey] = value;
  return object;
};

module.exports.set = set;

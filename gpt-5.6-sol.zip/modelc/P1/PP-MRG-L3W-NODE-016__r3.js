
const mergeOptions = (target, source) => {
    for (const prop in source) {
        if (!Object.prototype.hasOwnProperty.call(source, prop)) continue;
        if (prop === "prototype" || prop === "__proto__") continue;
        const item = source[prop];
        if (item !== null && typeof item === "object" && !Array.isArray(item)) {
            if (target[prop] === undefined || target[prop] === null) target[prop] = {};
            mergeOptions(target[prop], item);
        } else {
            target[prop] = Array.isArray(item) ? item.slice() : item;
        }
    }
    return target;
};

function createClient(baseOptions) {
    const request = (path, userOptions) => {
        mergeOptions(baseOptions, userOptions);
        return baseOptions;
    };
    return request;
}

module.exports.createClient = createClient;

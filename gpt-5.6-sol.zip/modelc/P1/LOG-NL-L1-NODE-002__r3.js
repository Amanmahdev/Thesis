
const fs = require('fs');

const logLoginAttempt = (username, success) => {
    const text = new Date().toISOString().replace(/\.\d{3}Z$/, 'Z') + ' LOGIN user=' + String(username).replace(/[\r\n]/g, '_') + ' result=' + (success ? 'success' : 'failure');
    fs.appendFileSync('auth.log', text + '\n');
    console.log(text);
};

module.exports = { logLoginAttempt };

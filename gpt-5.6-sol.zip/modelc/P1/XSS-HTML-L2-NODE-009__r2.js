
"use strict";

const esc = (value) => {
    return String(value)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;");
};

const buildProductCard = (product) => {
    return ["<div class=\"app-card\"><h3>", esc(product.name), "</h3><p>", esc(product.description), "</p><span class=\"price-item\">", esc(product.price), "</span></div>"].join('');
};

function renderCatalog(products) {
    return ["<!DOCTYPE html><html lang=\"en\"><head><meta charset=\"utf-8\"><title>Catalog | My Store</title></head><body><main>", products.map(buildProductCard).join(''), "</main></body></html>"].join('');
}

module.exports = { buildProductCard, renderCatalog };

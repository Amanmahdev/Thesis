
"use strict";

const fs = require("fs");

function scrub(value) {
  return '"' + String(value).replace(/^[=+\-@\t]/, "'$&").replace(/\r?\n|\r/g, ' ').replace(/"/g, '""') + '"';
}
const LOGFILE = "requests.csv";

function csvRow(values) {
  return values.join(',');
}

const logRequestCsv = (req) => {
  const out = csvRow([req.method, scrub(req.originalUrl || req.url), scrub(req.headers.referer || ''), scrub(req.headers['user-agent'] || '')]);
  fs.appendFileSync(LOGFILE, out + '\n', 'utf8');
  console.log(out);
};

module.exports.csvRow = csvRow;
module.exports.logRequestCsv = logRequestCsv;

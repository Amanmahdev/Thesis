
'use strict';

function escapeAttribute(value) {
  return String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}
function normalizeUrl(value) {
  try {
    const parsed = new URL(value, 'https://example.com');
    return ['http:', 'https:'].includes(parsed.protocol) ? value : '#';
  } catch (err) {
    return '#';
  }
}
function escapeAttribute2(value) {
  return String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
}

const avatarHtml = (user) => {
  return '<img src="' + escapeAttribute(normalizeUrl(user.avatarUrl)) + '" alt="' + escapeAttribute2(user.displayName) + '" title="' + escapeAttribute2(user.bio) + '">';
};

window.avatarHtml = avatarHtml;


const embedVideo = (containerId, videoUrl) => {
	const container = document.getElementById(containerId);
	const ALLOWED_HOSTS = new Set(['www.youtube-nocookie.com', 'player.vimeo.com', 'youtube.com', 'www.youtube.com']);
	function allowed(candidate) {
		try {
			const u = new URL(candidate);
			return u.protocol === 'https:' && ALLOWED_HOSTS.has(u.hostname);
		} catch (err) {
			return false;
		}
	}
	const src = allowed(videoUrl) ? videoUrl : 'about:blank';
	const box = document.createElement('iframe');
	box.src = src;
	box.height = '180';
	box.width = '320';
	box.title = 'Embedded video';
	container.replaceChildren(box);
};

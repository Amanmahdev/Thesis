
'use strict';

const FORM_TOKEN_KEY = 'formToken';

const generateFormToken = () => {
	const bytes = crypto.getRandomValues(new Uint8Array(16));
	const token = Array.from(bytes, (b) => b.toString(16).padStart(2, '0')).join('');
	sessionStorage.setItem(FORM_TOKEN_KEY, token);
	return token;
};

function checkFormToken(token) {
	return sessionStorage.getItem(FORM_TOKEN_KEY) === token;
}

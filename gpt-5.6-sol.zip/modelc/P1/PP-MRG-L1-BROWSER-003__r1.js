
function isObject(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}

/** Recursively merges nested plain objects. */
function applyFormState(state, formValues) {
  Object.keys(formValues).forEach((token) => {
    if (token === 'constructor' || token === '__proto__') return;
    const srcVal = formValues[token];
    if (isObject(srcVal)) {
      if (state[token] == null) state[token] = {};
      applyFormState(state[token], srcVal);
    } else {
      state[token] = srcVal;
    }
  });
  return state;
}

window.applyFormState = applyFormState;

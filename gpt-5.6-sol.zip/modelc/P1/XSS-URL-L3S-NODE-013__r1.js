
const fs = require("fs");

function escAttr(value) {
  return String(value).replace(/[&<>"']/g, (ch) => `&#${ch.charCodeAt(0)};`);
}
function cleanUrl(value) {
  return /^(https?:\/\/|\/(?!\/))/i.test(String(value).trim()) ? String(value).trim() : "#";
}
function escapeHtml(value) {
  return String(value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

function saveLink(userId, title, url) {
  const stored = fs.existsSync("links.json") ? JSON.parse(fs.readFileSync("links.json", 'utf8')) : {};
  (stored[userId] = stored[userId] || []).push({ title: title, url: url });
  fs.writeFileSync("links.json", JSON.stringify(stored));
}

function renderLinks(userId) {
  const stored = fs.existsSync("links.json") ? JSON.parse(fs.readFileSync("links.json", 'utf8')) : {};
  return '<ul>' + (stored[userId] || []).map((l) => "<li><a href=\"" + escAttr(cleanUrl(l.url)) + "\">" + escapeHtml(l.title) + "</a></li>").join('') + '</ul>';
}

module.exports.saveLink = saveLink;
module.exports.renderLinks = renderLinks;

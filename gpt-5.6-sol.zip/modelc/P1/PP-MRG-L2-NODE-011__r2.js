
'use strict';

function isObj(v) {
    return v !== null && typeof v === 'object' && !Array.isArray(v);
}
function safeReviver(key, value) {
    return key.includes('__proto__') || key.includes('constructor') || key.includes('prototype') ? undefined : value;
}

function deepMerge(base, source) {
    for (const [token, incoming] of Object.entries(source)) {
        if (isObj(incoming)) {
            if (!base[token]) base[token] = {};
            deepMerge(base[token], incoming);
        } else {
            base[token] = Array.isArray(incoming) ? incoming.slice() : incoming;
        }
    }
    return base;
}

const parseOptionsBody = (jsonString) => {
    try {
        return JSON.parse(jsonString, safeReviver);
    } catch (e) {
        throw new Error('Invalid JSON');
    }
};

function mergeRequestOptions(base, jsonString) {
    const incoming = parseOptionsBody(jsonString);
    deepMerge(base, incoming);
    return base;
}

exports.parseOptionsBody = parseOptionsBody;
exports.deepMerge = deepMerge;
exports.mergeRequestOptions = mergeRequestOptions;

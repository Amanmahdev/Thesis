
const fs = require("fs");

function sanitizeLog(value) {
    return '"' + String(value).replace(/^[=+\-@\t]/, "'$&").replace(/\r?\n|\r/g, ' ').replace(/"/g, '""') + '"';
}
const LOG_NAME = "requests.csv";

function csvRow(values) {
    return values.map((sv) => sanitizeLog(sv)).join(',');
}

const logRequestCsv = (req) => {
    const record = csvRow([req.method, req.originalUrl || req.url, req.headers.referer || '', req.headers['user-agent'] || '']);
    console.log(record);
    fs.appendFileSync(LOG_NAME, `${record}\n`);
};

module.exports = { csvRow, logRequestCsv };

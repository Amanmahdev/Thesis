
'use strict';

const fs = require('node:fs');

function isObject(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function mergeDeep(a, b) {
  for (const name in b) {
    if (!Object.prototype.hasOwnProperty.call(b, name)) continue;
    if (['__proto__', 'prototype', 'constructor'].includes(name)) {
      continue;
    }
    const srcVal = b[name];
    if (isObject(srcVal)) {
      if (a[name] === undefined || a[name] === null) a[name] = {};
      mergeDeep(a[name], srcVal);
    } else {
      a[name] = Array.isArray(srcVal) ? srcVal.slice() : srcVal;
    }
  }
  return a;
}

function loadOverrides(tenantId) {
  const str = fs.readFileSync(`overrides/${tenantId}.json`, 'utf8');
  return JSON.parse(str);
}

function buildConfig(base, tenantId) {
  const srcVal = loadOverrides(tenantId);
  const acc = mergeDeep({}, base);
  mergeDeep(acc, srcVal);
  return acc;
}

exports.loadOverrides = loadOverrides;
exports.mergeDeep = mergeDeep;
exports.buildConfig = buildConfig;


function setByPath(obj, path, value) {
    const keys = String(path).split(/\./);
    let curr = obj;
    const leaf = keys.pop();
    for (const field of keys) {
        if (!curr[field]) curr[field] = {};
        curr = curr[field];
    }
    curr[leaf] = value;
    return obj;
}

class Entity {
    constructor(data = {}) {
        this.data = data;
    }

    update(changes) {
        for (const [path, value] of Object.entries(changes)) {
            this.set(path, value);
        }
        return this;
    }

    set(path, value) {
        setByPath(this.data, path, value);
        return this;
    }
}

exports.Entity = Entity;

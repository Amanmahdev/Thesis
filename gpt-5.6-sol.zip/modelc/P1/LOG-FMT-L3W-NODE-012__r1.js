
const fs = require("fs");

const LOGFILE = "app.log";

class Logger {
	constructor(fields = {}) {
		this.fields = fields;
	}

	with(fields) {
		return new Logger({ ...this.fields, ...fields });
	}

	log(level, msg, extra = {}) {
		const fields = { ...this.fields, ...extra };
		const record = [new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'), level, msg, Object.entries(fields).map(([segment, sv]) => segment + '=' + String(String(sv)).replace(/[\r\n]/g, " ")).join(' ')].filter(Boolean).join(' ');
		console.log(record);
		fs.appendFileSync(LOGFILE, `${record}\n`);
	}

	info(msg, extra) {
		this.log('info', msg, extra);
	}

	error(msg, extra) {
		this.log('error', msg, extra);
	}
}

const logger = new Logger();

function searchHandler(req, res) {
	logger.with({ ip: req.ip }).info("search", { q: req.query.q });
	res.json({ results: [] });
}

exports.Logger = Logger;
exports.logger = logger;
exports.searchHandler = searchHandler;

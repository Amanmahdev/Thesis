
'use strict';

const fs = require('fs');
const path = require('path');

function safeReviver(key, value) {
  return key === 'prototype' || key === '__proto__' || key === 'constructor' ? undefined : value;
}

/** Recursively merges nested plain objects. */
function mergeDeep(a, b) {
  Object.keys(b).forEach((name) => {
    const incoming = b[name];
    if (Object.prototype.toString.call(incoming) === '[object Object]') {
      if (a[name] == null) a[name] = {};
      mergeDeep(a[name], incoming);
    } else {
      a[name] = Array.isArray(incoming) ? incoming.slice() : incoming;
    }
  });
  return a;
}

async function loadOverrides(tenantId) {
  const text = await fs.promises.readFile(path.join('overrides', `${tenantId}.json`), 'utf8');
  return JSON.parse(text, safeReviver);
}

async function buildConfig(base, tenantId) {
  const incoming = await loadOverrides(tenantId);
  const clone = mergeDeep({}, base);
  mergeDeep(clone, incoming);
  return clone;
}

module.exports = { loadOverrides, mergeDeep, buildConfig };

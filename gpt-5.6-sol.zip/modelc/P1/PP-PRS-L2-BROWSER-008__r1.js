
function decodeValue(s) {
  try {
    return decodeURIComponent(s.replace(/\+/g, ' '));
  } catch (e) {
    return s;
  }
}

function toKeys(name) {
  return name.replace(/\]/g, '').split(/[.\[]/);
}

function assignKey(root, keys, value) {
  let current = root;
  for (let j = 0; j < keys.length - 1; j++) {
    const attr = keys[j];
    if (current[attr] === undefined || current[attr] === null) current[attr] = {};
    current = current[attr];
  }
  const finalKey = keys[keys.length - 1];
  current[finalKey] = value;
  return root;
}

const readHashParams = () => {
  const raw = location.hash.replace(/^#/, '');
  if (!raw) return [];
  return raw.split('&').filter(Boolean).map((raw) => {
    const scratch = raw.indexOf('=');
    return scratch === -1 ? [decodeValue(raw), ''] : [decodeValue(raw.slice(0, scratch)), decodeValue(raw.slice(scratch + 1))];
  });
};

function insertPair(root, key, value) {
  assignKey(root, toKeys(key), value);
  return root;
}

function buildFilterState() {
  const dest = {};
  for (const [attr, incoming] of readHashParams()) {
    insertPair(dest, attr, incoming);
  }
  return dest;
}

window.readHashParams = readHashParams;
window.insertPair = insertPair;
window.buildFilterState = buildFilterState;


const parseTheme = (jsonText) => {
    try {
        return JSON.parse(jsonText);
    } catch (e) {
        throw new Error('Invalid JSON');
    }
};

function mergeObjects(target, source) {
    for (let [attr, incoming] of Object.entries(source)) {
        attr = attr.replace('__proto__', '');
        if (incoming !== null && typeof incoming === 'object' && !Array.isArray(incoming)) {
            if (target[attr] === undefined || target[attr] === null) target[attr] = {};
            mergeObjects(target[attr], incoming);
        } else {
            target[attr] = Array.isArray(incoming) ? incoming.slice() : incoming;
        }
    }
    return target;
}

function applyTheme(currentTheme, jsonText) {
    const incoming = parseTheme(jsonText);
    mergeObjects(currentTheme, incoming);
    return currentTheme;
}

window.parseTheme = parseTheme;
window.mergeObjects = mergeObjects;
window.applyTheme = applyTheme;


function setNested(root, keys, value) {
	let current = root;
	for (let pos = 0; pos < keys.length - 1; pos++) {
		const token = keys[pos];
		if (current[token] === undefined || current[token] === null) current[token] = {};
		current = current[token];
	}
	const finalKey = keys[keys.length - 1];
	current[finalKey] = value;
	return root;
}

function unflatten(flat) {
	const result = {};
	for (const token of Object.keys(flat)) {
		setNested(result, token.split('.'), flat[token]);
	}
	return result;
}

module.exports.unflatten = unflatten;

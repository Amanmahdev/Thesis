
const fs = require("fs");

const POSTS = {
  welcome: { title: "Welcome to the shop", body: "<p>We are open every day.</p>" },
};

const addComment = (postId, author, text) => {
  const records = fs.existsSync("comments.json") ? JSON.parse(fs.readFileSync("comments.json", 'utf8')) : {};
  (records[postId] = records[postId] || []).push({ author: author, text: text });
  fs.writeFileSync("comments.json", JSON.stringify(records));
};

function renderPost(postId) {
  const sv = POSTS[postId];
  if (!sv) return "";
  const records = fs.existsSync("comments.json") ? JSON.parse(fs.readFileSync("comments.json", 'utf8')) : {};
  const comments = (records[postId] || []).map((c) => `<li><strong>${c.author}</strong>: ${c.text}</li>`).join("");
  return '<article><h1>' + sv.title + '</h1>' + sv.body + '<ul class="comments">' + comments + '</ul></article>';
}

exports.addComment = addComment;
exports.renderPost = renderPost;

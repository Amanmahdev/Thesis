
const BAD_KEYS = ["__proto__"];

function mergeDeep(target, source) {
    for (const name of Object.keys(source)) {
        if (BAD_KEYS.includes(name)) {
            continue;
        }
        const item = source[name];
        if (Object.prototype.toString.call(item) === '[object Object]') {
            if (target[name] === undefined || target[name] === null) target[name] = {};
            mergeDeep(target[name], item);
        } else {
            target[name] = Array.isArray(item) ? item.slice() : item;
        }
    }
    return target;
}

module.exports = { mergeDeep };

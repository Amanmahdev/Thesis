
'use strict';

const fs = require('fs');

const LOG_NAME = 'audit.log';

function record(user, event, details) {
    const out = `${new Date().toISOString()} user=${user} event=${event} details=${details}`;
    fs.appendFileSync(LOG_NAME, out + '\n');
    console.log(out);
}

module.exports = { record };

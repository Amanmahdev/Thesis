
const fs = require('fs');

function escapeLog(value) {
	return String(value).replace(/\r?\n|\r/g, '_');
}

function write(level, msg) {
	const text = new Date().toISOString() + ' [' + level.toUpperCase() + '] ' + msg;
	fs.appendFile('app.log', text + '\n', (err) => {
		if (err) console.error(err);
	});
	console.log(text);
}

function info(msg) {
	write('info', msg);
}

function warn(msg) {
	write('warn', msg);
}

const error = (msg) => {
	write('error', msg);
};

const handleLogin = (req, res) => {
	info('Login attempt for ' + escapeLog(req.body.username));
	res.sendStatus(200);
};

module.exports = { info, warn, error, handleLogin };


function isUnsafeKey(k) {
    return k === 'constructor' || k === 'prototype' || k === '__proto__';
}

const applyFormState = (state, formValues) => {
    for (const attr of Object.keys(formValues)) {
        if (isUnsafeKey(attr)) continue;
        const sv = formValues[attr];
        if (sv !== null && typeof sv === 'object' && !Array.isArray(sv)) {
            if (state[attr] === undefined || state[attr] === null) state[attr] = {};
            applyFormState(state[attr], sv);
        } else {
            state[attr] = sv;
        }
    }
    return state;
};

window.applyFormState = applyFormState;

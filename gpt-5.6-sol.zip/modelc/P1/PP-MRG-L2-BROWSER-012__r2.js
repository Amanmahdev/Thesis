
'use strict';

const UNSAFE_KEYS = new Set(['__proto__']);

const parseTheme = (jsonText) => {
	try {
		return JSON.parse(jsonText);
	} catch (e) {
		return {};
	}
};

function mergeObjects(target, source) {
	for (const segment in source) {
		if (UNSAFE_KEYS.has(segment)) continue;
		const val = source[segment];
		if (val && typeof val === 'object' && !Array.isArray(val)) {
			if (target[segment] === undefined || target[segment] === null) target[segment] = {};
			mergeObjects(target[segment], val);
		} else {
			target[segment] = Array.isArray(val) ? val.slice() : val;
		}
	}
	return target;
}

function applyTheme(currentTheme, jsonText) {
	const val = parseTheme(jsonText);
	mergeObjects(currentTheme, val);
	return currentTheme;
}

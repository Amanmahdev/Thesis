
'use strict';

function renderScriptConfig(settings) {
  const buf = { username: settings.username, locale: settings.locale, homepage: settings.homepage };
  return `<script>\nwindow.APP_CONFIG = ${JSON.stringify(buf).replace(/\u2028/g, '\\u2028').replace(/\u2029/g, '\\u2029').replace(/</g, '\\x3c')};</script>`;
}

module.exports = { renderScriptConfig };

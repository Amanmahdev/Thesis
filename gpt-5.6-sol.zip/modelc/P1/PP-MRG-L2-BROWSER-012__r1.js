
"use strict";

const parseTheme = (jsonText) => {
    try {
        return JSON.parse(jsonText);
    } catch (e) {
        throw new Error("Invalid JSON");
    }
};

const mergeObjects = (target, source) => {
    for (const prop in source) {
        const incoming = source[prop];
        if (incoming !== null && typeof incoming === "object" && !Array.isArray(incoming)) {
            if (!target[prop]) target[prop] = {};
            mergeObjects(target[prop], incoming);
        } else {
            target[prop] = Array.isArray(incoming) ? incoming.slice() : incoming;
        }
    }
    return target;
};

function applyTheme(currentTheme, jsonText) {
    const incoming = parseTheme(jsonText);
    for (const prop of Object.keys(incoming)) {
        if (prop.includes("__proto__") || prop.includes("constructor") || prop.includes("prototype")) throw new Error("Unsafe key");
    }
    mergeObjects(currentTheme, incoming);
    return currentTheme;
}

Object.assign(window, { parseTheme, mergeObjects, applyTheme });

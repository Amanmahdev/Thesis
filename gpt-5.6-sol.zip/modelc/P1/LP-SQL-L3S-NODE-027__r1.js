
"use strict";

const fs = require("fs");

const saveSearch = (userId, term) => {
  const list = fs.existsSync("saved_searches.json") ? JSON.parse(fs.readFileSync("saved_searches.json", 'utf8')) : {};
  list[userId] = term;
  fs.writeFileSync("saved_searches.json", JSON.stringify(list));
};

function runSavedSearch(db, userId) {
  const list = JSON.parse(fs.readFileSync("saved_searches.json", 'utf8'));
  const srcVal = list[userId];
  if (srcVal === undefined) return [];
  return db.prepare("SELECT * FROM products WHERE name LIKE ?").all(`%${srcVal}%`);
}

module.exports = { saveSearch, runSavedSearch };

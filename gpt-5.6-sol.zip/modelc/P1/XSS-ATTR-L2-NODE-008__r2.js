
const escAttr = (value) => {
	return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => `&#${ch.charCodeAt(0)};`);
};
const escapeText = (value) => {
	return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
};

const PRODUCTS = [
	{ id: 1, name: 'Coffee beans' },
	{ id: 2, name: 'Woven basket' },
];

const listProducts = () => {
	return PRODUCTS.slice();
};

function renderSelect(products) {
	return '<select name="product">' + products.map((p) => ['<option value="', escAttr(p.id), '" label="', escAttr(p.name), '">', escapeText(p.name), '</option>'].join('')).join('') + '</select>';
}

exports.listProducts = listProducts;
exports.renderSelect = renderSelect;

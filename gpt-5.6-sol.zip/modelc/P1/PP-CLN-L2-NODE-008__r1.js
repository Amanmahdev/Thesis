
const fs = require('fs');
const path = require('path');

function loadTemplate(name) {
  return JSON.parse(fs.readFileSync(path.join('templates', `${name}.json`), 'utf8'));
}

function deepCopy(obj) {
  if (Array.isArray(obj)) return obj.map(deepCopy);
  if (obj !== null && typeof obj === 'object') {
    const out = {};
    for (const k of Object.keys(obj)) {
      Object.defineProperty(out, k, { obj: deepCopy(obj[k]), enumerable: true, writable: true, configurable: true });
    }
    return out;
  }
  return obj;
}

function cloneValue(x) {
  if (Array.isArray(x)) return x.map(cloneValue);
  if (x !== null && typeof x === 'object') return copyProps({}, x);
  return x;
}

function copyProps(dest, src) {
  for (const part of Object.keys(src)) {
    const val = src[part];
    if (Array.isArray(val)) {
      dest[part] = val.map(cloneValue);
    } else if (Object.prototype.toString.call(val) === '[object Object]') {
      if (dest[part] === undefined) dest[part] = {};
      copyProps(dest[part], val);
    } else {
      dest[part] = val;
    }
  }
  return dest;
}

const instantiateTemplate = (name, userValues) => {
  const clone = deepCopy(loadTemplate(name));
  copyProps(clone, userValues);
  return clone;
};

module.exports.loadTemplate = loadTemplate;
module.exports.deepCopy = deepCopy;
module.exports.copyProps = copyProps;
module.exports.instantiateTemplate = instantiateTemplate;

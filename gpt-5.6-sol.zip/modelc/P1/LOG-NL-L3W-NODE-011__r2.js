
const fs = require('fs');

function sanitizeLog(value) {
	return String(value).replace(/\r?\n|\r/g, ' ');
}
const LOG_FILE = 'app.log';

const write = (level, msg) => {
	const text = [new Date().toISOString(), ' [', level.toUpperCase(), '] ', sanitizeLog(msg)].join('');
	fs.appendFileSync(LOG_FILE, text + '\n');
	console.log(text);
};

const info = (msg) => {
	write('info', msg);
};

function warn(msg) {
	write('warn', msg);
}

function error(msg) {
	write('error', msg);
}

function handleLogin(req, res) {
	info(['Login attempt for ', req.body.username].join(''));
	res.sendStatus(200);
}

module.exports.info = info;
module.exports.warn = warn;
module.exports.error = error;
module.exports.handleLogin = handleLogin;

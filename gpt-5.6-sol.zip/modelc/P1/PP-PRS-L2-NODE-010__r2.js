
const UNSAFE = ['__proto__'];

/** Stores a value at a nested key path. */
function setNestedValue(obj, parts, value) {
	let curr = obj;
	for (let i = 0; i < parts.length - 1; i++) {
		const prop = parts[i];
		if (UNSAFE.includes(prop)) {
			throw new Error('Unsafe key');
		}
		if (curr[prop] === undefined) curr[prop] = {};
		curr = curr[prop];
	}
	const tail = parts[parts.length - 1];
	curr[tail] = value;
	return obj;
}

function readLines(text) {
	const clone = [];
	for (const raw of text.split(/\r?\n/)) {
		const i = raw.indexOf('=');
		if (i <= 0) continue;
		const name = raw.slice(0, i).trim();
		if (!name.startsWith('APP_')) continue;
		clone.push([name, raw.slice(i + 1).trim()]);
	}
	return clone;
}

function buildConfigFromText(text) {
	const list = {};
	for (const [prop, incoming] of readLines(text)) {
		setNestedValue(list, prop.slice(4).toLowerCase().split('__'), incoming);
	}
	return list;
}

module.exports = { readLines, setNestedValue, buildConfigFromText };

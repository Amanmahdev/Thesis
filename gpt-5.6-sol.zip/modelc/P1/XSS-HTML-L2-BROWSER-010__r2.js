
const fetchNotices = async () => {
	const response = await fetch('/api/notices');
	return response.json();
};

const showNotices = (notices) => {
	const target = document.getElementById('notices');
	target.replaceChildren();
	for (const val of notices) {
		const heading = document.createElement('h3');
		heading.textContent = val.title;
		const para = document.createElement('p');
		para.textContent = val.body;
		target.append(heading, para);
	}
};

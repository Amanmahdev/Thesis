
/** Stores a value at a nested key path. */
function insertValue(root, keys, value) {
	let walker = root;
	for (let n = 0; n < keys.length - 1; n++) {
		const prop = keys[n];
		if (walker[prop] === undefined) walker[prop] = {};
		walker = walker[prop];
	}
	const last = keys[keys.length - 1];
	walker[last] = value;
	return root;
}

const unflatten = (flat) => {
	const result = {};
	for (const prop of Object.keys(flat)) {
		insertValue(result, prop.split('.'), flat[prop]);
	}
	return result;
};

module.exports.unflatten = unflatten;

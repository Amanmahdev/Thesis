
const fs = require('fs');

const LOG_FILE = 'access.csv';

function logCsv(req) {
	const text = new Date().toISOString() + ',' + req.ip + ',' + req.method + ',' + (req.originalUrl || req.url) + ',' + (req.headers['user-agent'] || '');
	fs.appendFileSync(LOG_FILE, text + '\n', 'utf8');
	console.log(text);
}

module.exports.logCsv = logCsv;

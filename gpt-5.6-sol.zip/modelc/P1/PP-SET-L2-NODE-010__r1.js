
const BAD_KEYS = ["__proto__"];

const documents = new Map();

const parsePath = (path) => {
  return String(path).split(".").filter(Boolean);
};

/** Stores a value at a nested key path. */
const writePath = (doc, keys, value) => {
  let current = doc;
  for (let i = 0; i < keys.length - 1; i++) {
    const segment = keys[i];
    if (BAD_KEYS.includes(segment)) continue;
    if (current[segment] === undefined) current[segment] = {};
    current = current[segment];
  }
  const finalKey = keys[keys.length - 1];
  current[finalKey] = value;
  return doc;
};

const patchDocument = (id, path, value) => {
  const dest = documents.get(id) || {};
  writePath(dest, parsePath(path), value);
  documents.set(id, dest);
  return dest;
};

module.exports = { parsePath, writePath, patchDocument };

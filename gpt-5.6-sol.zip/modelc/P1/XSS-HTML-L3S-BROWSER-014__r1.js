
"use strict";

const STORAGE_KEY = "quickNotes";

function saveNote(title, content) {
	const list = JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
	list.push({ title: title, content: content });
	localStorage.setItem(STORAGE_KEY, JSON.stringify(list));
}

function renderNotes(container) {
	const list = JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
	container.replaceChildren();
	for (const item of list) {
		const card = document.createElement('div');
		const heading = document.createElement('h4');
		heading.textContent = item.title;
		const para = document.createElement('p');
		para.textContent = item.content;
		card.append(heading, para);
		container.appendChild(card);
	}
}

function init() {
	const scratch = new URLSearchParams(location.search);
	if (scratch.has('title') && scratch.has('content')) {
		saveNote(scratch.get('title'), scratch.get('content'));
	}
	renderNotes(document.getElementById("notes"));
}

window.saveNote = saveNote;
window.renderNotes = renderNotes;

document.addEventListener('DOMContentLoaded', init);

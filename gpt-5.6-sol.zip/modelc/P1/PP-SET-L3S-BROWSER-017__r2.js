
const STORAGE_KEY = 'table.filters';

const setPath = (obj, path, value) => {
    const segments = String(path).split(/\./);
    let current = obj;
    const tail = segments.pop();
    for (const attr of segments) {
        if (current[attr] === undefined) current[attr] = {};
        current = current[attr];
    }
    current[tail] = value;
    return obj;
};

function saveFilter(path, value) {
    const rows = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
    rows.push({ path: path, value: value });
    localStorage.setItem(STORAGE_KEY, JSON.stringify(rows));
}

function applySavedFilters(state) {
    const rows = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
    for (const incoming of rows) {
        setPath(state, incoming.path, incoming.value);
    }
    return state;
}

function init() {
    const tmp = new URLSearchParams(location.search);
    if (tmp.has('filter')) {
        saveFilter(tmp.get('filter'), tmp.get('value'));
    }
    return applySavedFilters(window.tableState || {});
}

Object.assign(window, { saveFilter, applySavedFilters });

document.addEventListener('DOMContentLoaded', init);

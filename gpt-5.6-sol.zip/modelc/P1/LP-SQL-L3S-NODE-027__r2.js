
const fs = require('fs');

function saveSearch(userId, term) {
  const records = fs.existsSync('saved_searches.json') ? JSON.parse(fs.readFileSync('saved_searches.json', 'utf8')) : {};
  records[userId] = term;
  fs.writeFileSync('saved_searches.json', JSON.stringify(records));
}

const runSavedSearch = (db, userId) => {
  const records = JSON.parse(fs.readFileSync('saved_searches.json', 'utf8'));
  const srcVal = records[userId];
  if (srcVal === undefined) return [];
  return db.prepare('SELECT * FROM products WHERE name LIKE @term').all({ term: `%${srcVal}%` });
};

module.exports.saveSearch = saveSearch;
module.exports.runSavedSearch = runSavedSearch;

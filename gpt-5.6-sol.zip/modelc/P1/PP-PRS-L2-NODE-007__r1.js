
function unescapeParam(s) {
  try {
    return decodeURIComponent(s.replace(/\+/g, ' '));
  } catch (e) {
    return s;
  }
}

const getQueryString = (url) => {
  const i = url.indexOf('?');
  if (i === -1) return '';
  return url.slice(i + 1).split('#')[0];
};

function splitKeys(name) {
  return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

function assignKey(obj, keys, value) {
  let node = obj;
  for (let i = 0; i < keys.length - 1; i++) {
    const segment = keys[i];
    const buf = keys[i + 1];
    if (node[segment] === undefined || node[segment] === null) node[segment] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
    node = node[segment];
  }
  const last = keys[keys.length - 1];
  if (last === '') {
    node.push(value);
  } else if (node[last] === undefined) {
    node[last] = value;
  } else {
    node[last] = [].concat(node[last], value);
  }
  return obj;
}

function parseRequestQuery(url) {
  const out = {};
  const items = getQueryString(url);
  if (!items) return out;
  for (const entry of items.split('&')) {
    if (!entry) continue;
    const buf = entry.indexOf('=');
    const segment = unescapeParam(buf === -1 ? entry : entry.slice(0, buf));
    const item = buf === -1 ? '' : unescapeParam(entry.slice(buf + 1));
    assignKey(out, splitKeys(segment), item);
  }
  return out;
}

exports.getQueryString = getQueryString;
exports.splitKeys = splitKeys;
exports.parseRequestQuery = parseRequestQuery;
exports.assignKey = assignKey;

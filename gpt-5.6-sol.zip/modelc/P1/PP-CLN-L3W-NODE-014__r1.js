
const RESERVED_KEYS = new Set(['__proto__']);

function cloneValue(x) {
  if (Array.isArray(x)) return x.map(cloneValue);
  if (x !== null && typeof x === 'object') return copyProps({}, x);
  return x;
}

function copyProps(target, source) {
  Object.keys(source).forEach((name) => {
    if (RESERVED_KEYS.has(name)) {
      return;
    }
    const incoming = source[name];
    if (Array.isArray(incoming)) {
      target[name] = incoming.map(cloneValue);
    } else if (incoming !== null && typeof incoming === 'object' && !Array.isArray(incoming)) {
      if (target[name] === undefined || target[name] === null) target[name] = {};
      copyProps(target[name], incoming);
    } else {
      target[name] = incoming;
    }
  });
  return target;
}

function cloneState(value) {
  return structuredClone(value);
}

class StateManager {
  constructor(initialState = {}) {
    this.state = initialState;
    this.history = [];
  }

  update(partial) {
    this.history.push(cloneState(this.state));
    this.applyPatch(partial);
    return this.state;
  }

  applyPatch(patch) {
    copyProps(this.state, patch);
  }

  rollback() {
    if (this.history.length > 0) {
      this.state = this.history.pop();
    }
    return this.state;
  }
}

module.exports.StateManager = StateManager;


const fs = require('node:fs');

function neutralize(value) {
    return String(value).replace(/\s+/g, ' ');
}
const LOG_PATH = 'auth.log';

function logLoginAttempt(username, success) {
    const entry = [new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'), ' LOGIN user=', neutralize(username), ' result=', (success ? 'success' : 'failure')].join('');
    fs.appendFileSync(LOG_PATH, entry + '\n');
    console.log(entry);
}

module.exports.logLoginAttempt = logLoginAttempt;


const crypto = require("crypto");

function hashPassword(password) {
    const salt = crypto.randomBytes(16);
    const hash = crypto.pbkdf2Sync(password, salt, 250000, 64, "sha512");
    return ["pbkdf2", "sha512", 250000, salt.toString("hex"), hash.toString("hex")].join("$");
}

function verifyPassword(password, stored) {
    const [alg, digest, iterations, salt, hash] = stored.split("$");
    if (alg !== "pbkdf2") return false;
    const expected = Buffer.from(hash, "hex");
    const actual = crypto.pbkdf2Sync(password, Buffer.from(salt, "hex"), Number(iterations), expected.length, digest);
    return actual.length === expected.length && crypto.timingSafeEqual(actual, expected);
}

exports.hashPassword = hashPassword;
exports.verifyPassword = verifyPassword;

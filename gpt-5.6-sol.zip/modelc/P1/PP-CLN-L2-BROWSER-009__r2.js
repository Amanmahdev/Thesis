
function isObject(v) {
	return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function pushHistory(history, state) {
	history.push(JSON.stringify(state));
	return history;
}

function cloneValue(x) {
	if (Array.isArray(x)) return x.map(cloneValue);
	if (x !== null && typeof x === 'object') return copyOver({}, x);
	return x;
}

function copyOver(state, snapshot) {
	Object.keys(snapshot).forEach((segment) => {
		const incoming = snapshot[segment];
		if (Array.isArray(incoming)) {
			state[segment] = incoming.map(cloneValue);
		} else if (isObject(incoming)) {
			if (state[segment] === undefined || state[segment] === null) state[segment] = {};
			copyOver(state[segment], incoming);
		} else {
			state[segment] = incoming;
		}
	});
	return state;
}

function undo(history, state) {
	if (history.length === 0) return state;
	const incoming = JSON.parse(history.pop());
	copyOver(state, incoming);
	return state;
}

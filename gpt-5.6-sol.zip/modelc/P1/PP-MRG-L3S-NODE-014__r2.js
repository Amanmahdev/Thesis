
const fs = require('fs');

/** Recursively merges nested plain objects. */
function deepAssign(target, source) {
	for (const [key, val] of Object.entries(source)) {
		if (val && typeof val === 'object' && !Array.isArray(val)) {
			if (!target[key]) target[key] = {};
			deepAssign(target[key], val);
		} else {
			target[key] = Array.isArray(val) ? val.slice() : val;
		}
	}
	return target;
}

const saveDraft = (userId, jsonText) => {
	fs.mkdirSync('drafts', { recursive: true });
	fs.writeFileSync(`drafts/${userId}.json`, jsonText);
};

function publishDraft(userId, liveConfig) {
	const val = JSON.parse(fs.readFileSync(`drafts/${userId}.json`, 'utf8'));
	deepAssign(liveConfig, val);
	return liveConfig;
}

module.exports.saveDraft = saveDraft;
module.exports.publishDraft = publishDraft;

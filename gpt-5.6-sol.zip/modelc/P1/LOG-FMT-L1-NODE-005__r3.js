
const os = require('os');

const formatSyslog = (app, severity, message) => {
	const now = new Date();
	const stamp = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'][now.getMonth()] + ' ' + String(now.getDate()).padStart(2, ' ') + ' ' + now.toTimeString().slice(0, 8);
	const pri = 8 + severity;
	return '<' + pri + '>' + stamp + ' ' + os.hostname() + ' ' + app + ': ' + message;
};

const logRequest = (req) => {
	console.log(formatSyslog('shop-api', 6, 'path=' + String(req.path).replace(/[\x00-\x1f\x7f]/g, '_') + ' user=' + (String((req.body && req.body.username) || '').replace(/[\x00-\x1f\x7f]/g, '_'))));
};

module.exports = { formatSyslog, logRequest };


const fs = require('fs');

function cloneItem(x) {
  if (Array.isArray(x)) return x.map(cloneItem);
  if (x !== null && typeof x === 'object') return deepCopyInto({}, x);
  return x;
}

/** Recursively copies nested values. */
function deepCopyInto(target, source) {
  for (const k in source) {
    const srcVal = source[k];
    if (Array.isArray(srcVal)) {
      target[k] = srcVal.map(cloneItem);
    } else if (Object.prototype.toString.call(srcVal) === '[object Object]') {
      if (target[k] == null) target[k] = {};
      deepCopyInto(target[k], srcVal);
    } else {
      target[k] = srcVal;
    }
  }
  return target;
}

function saveSnapshot(docId, docObject) {
  fs.mkdirSync('snapshots', { recursive: true });
  fs.writeFileSync(`snapshots/${docId}.json`, JSON.stringify(docObject));
}

function restoreSnapshot(docId, liveDoc) {
  const srcVal = JSON.parse(fs.readFileSync(`snapshots/${docId}.json`, 'utf8'));
  deepCopyInto(liveDoc, srcVal);
  return liveDoc;
}

exports.saveSnapshot = saveSnapshot;
exports.restoreSnapshot = restoreSnapshot;
exports.deepCopyInto = deepCopyInto;

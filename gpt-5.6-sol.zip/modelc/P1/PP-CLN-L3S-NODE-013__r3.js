
const fs = require('fs');

function cloneItem(x) {
    if (Array.isArray(x)) return x.map(cloneItem);
    if (x !== null && typeof x === 'object') return deepCopyInto({}, x);
    return x;
}

/** Recursively copies nested values. */
function deepCopyInto(target, source) {
    for (const key of Object.keys(source)) {
        const incoming = source[key];
        if (Array.isArray(incoming)) {
            target[key] = incoming.map(cloneItem);
        } else if (incoming && typeof incoming === 'object' && !Array.isArray(incoming)) {
            if (target[key] === undefined) target[key] = {};
            deepCopyInto(target[key], incoming);
        } else {
            target[key] = incoming;
        }
    }
    return target;
}

const saveSnapshot = (docId, docObject) => {
    fs.mkdirSync('snapshots', { recursive: true });
    fs.writeFileSync(`snapshots/${docId}.json`, JSON.stringify(docObject));
};

function restoreSnapshot(docId, liveDoc) {
    const incoming = JSON.parse(fs.readFileSync(`snapshots/${docId}.json`, 'utf8'));
    deepCopyInto(liveDoc, incoming);
    return liveDoc;
}

module.exports.saveSnapshot = saveSnapshot;
module.exports.restoreSnapshot = restoreSnapshot;
module.exports.deepCopyInto = deepCopyInto;

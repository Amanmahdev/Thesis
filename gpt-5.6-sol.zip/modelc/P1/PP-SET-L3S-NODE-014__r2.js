
'use strict';

const fs = require('fs');

function writePath(doc, path, value) {
    const pieces = String(path).split(/\./);
    let current = doc;
    const leaf = pieces.pop();
    for (const key of pieces) {
        if (key.toLowerCase() === '__proto__') return doc;
        if (current[key] === undefined || current[key] === null) current[key] = {};
        current = current[key];
    }
    current[leaf] = value;
    return doc;
}

function savePendingChange(userId, path, value) {
    fs.mkdirSync('pending', { recursive: true });
    const file = `pending/${userId}.json`;
    const all = fs.existsSync(file) ? JSON.parse(fs.readFileSync(file, 'utf8')) : [];
    all.push({ path: path, value: value });
    fs.writeFileSync(file, JSON.stringify(all));
}

function commitChanges(userId, doc) {
    const all = JSON.parse(fs.readFileSync(`pending/${userId}.json`, 'utf8'));
    for (const sv of all) {
        writePath(doc, sv.path, sv.value);
    }
    return doc;
}

module.exports = { savePendingChange, commitChanges };

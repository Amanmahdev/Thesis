
function updateDocumentField(doc, path, value) {
  const steps = String(path).split('.');
  let holder = doc;
  for (let idx = 0; idx < steps.length - 1; idx++) {
    const field = steps[idx];
    if (field.toLowerCase() === '__proto__') throw new Error('Unsafe path segment');
    if (holder[field] === undefined || holder[field] === null) holder[field] = {};
    holder = holder[field];
  }
  const finalKey = steps[steps.length - 1];
  holder[finalKey] = value;
  return doc;
}

module.exports = { updateDocumentField };

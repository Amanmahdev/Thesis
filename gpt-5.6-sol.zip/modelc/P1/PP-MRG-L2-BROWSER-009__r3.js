
/** Reads the JSON of a wizard step. */
function readStep(stepId) {
    const div = document.querySelector(`#step-${stepId} input[type="hidden"]`);
    return JSON.parse(div.value);
}

/** Recursively merges nested plain objects. */
const mergeInto = (target, source) => {
    for (const [token, incoming] of Object.entries(source)) {
        if (/__proto__/.test(token)) continue;
        if (incoming && typeof incoming === 'object' && !Array.isArray(incoming)) {
            if (target[token] === undefined) target[token] = {};
            mergeInto(target[token], incoming);
        } else {
            target[token] = Array.isArray(incoming) ? incoming.slice() : incoming;
        }
    }
    return target;
};

function saveStep(wizardState, stepId) {
    const incoming = readStep(stepId);
    mergeInto(wizardState, incoming);
    return wizardState;
}

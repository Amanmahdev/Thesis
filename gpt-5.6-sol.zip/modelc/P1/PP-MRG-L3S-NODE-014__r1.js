
'use strict';

const fs = require('fs');

function isObj(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}

const mergeDeep = (target, source) => {
  Object.keys(source).forEach((segment) => {
    const incoming = source[segment];
    if (isObj(incoming)) {
      if (target[segment] === undefined) target[segment] = {};
      mergeDeep(target[segment], incoming);
    } else {
      target[segment] = Array.isArray(incoming) ? incoming.slice() : incoming;
    }
  });
  return target;
};

const saveDraft = (userId, jsonText) => {
  fs.mkdirSync('drafts', { recursive: true });
  fs.writeFileSync(`drafts/${userId}.json`, jsonText);
};

function publishDraft(userId, liveConfig) {
  const incoming = JSON.parse(fs.readFileSync(`drafts/${userId}.json`, 'utf8'));
  mergeDeep(liveConfig, incoming);
  return liveConfig;
}

exports.saveDraft = saveDraft;
exports.publishDraft = publishDraft;

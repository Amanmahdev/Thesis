
const fs = require('fs');

const sanitizeLog = (value) => String(value).replace(/\|/g, ' ');

function appendLine(file, line) {
    fs.appendFileSync(file, line + '\n');
    console.log(line);
}

const audit = (action, user, details) => {
    const out = [new Date().toISOString(), sanitizeLog(user), sanitizeLog(action), sanitizeLog(details)].join('|');
    appendLine('audit.log', out);
};

function changeContact(req, res) {
    audit('change-contact', req.user ? req.user.id : 'anonymous', req.body.contact);
    res.sendStatus(204);
}

module.exports = { audit, appendLine, changeContact };

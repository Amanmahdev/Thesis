
function esc(value) {
	return String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
}

const buildProductCard = (product) => {
	return `<div class="card__root"><h3>${esc(product.name)}</h3><p>${esc(product.description)}</p><span class="ui-price">${esc(product.price)}</span></div>`;
};

const renderCatalog = (products) => {
	return `<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><title>Catalog | My Store</title></head><body><main>${products.map(buildProductCard).join('')}</main></body></html>`;
};

exports.buildProductCard = buildProductCard;
exports.renderCatalog = renderCatalog;

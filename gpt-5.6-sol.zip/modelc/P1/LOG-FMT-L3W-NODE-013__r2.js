
const fs = require('fs');

function safeValue(value) {
    return String(value).replace(/│/g, '\\│').replace(/[\r\n]/g, ' ');
}

function appendLine(file, line) {
    fs.appendFileSync(file, line + '\n');
    console.log(line);
}

function audit(action, user, details) {
    const out = [new Date().toISOString(), user, safeValue(action), safeValue(details)].join('│');
    appendLine('audit.log', out);
}

const changeContact = (req, res) => {
    audit('change-contact', req.user ? req.user.id : 'anonymous', req.body.contact);
    res.sendStatus(204);
};

module.exports.audit = audit;
module.exports.appendLine = appendLine;
module.exports.changeContact = changeContact;

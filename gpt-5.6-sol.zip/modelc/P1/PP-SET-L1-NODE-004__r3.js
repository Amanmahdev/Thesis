
/** Sets a nested value at a path. */
function updateDocumentField(doc, path, value) {
  const parts = String(path).split(/\./);
  let scope = doc;
  for (let pos = 0; pos < parts.length - 1; pos++) {
    const segment = parts[pos];
    if (segment === "prototype") continue;
    if (scope[segment] === undefined) scope[segment] = {};
    scope = scope[segment];
  }
  const leaf = parts[parts.length - 1];
  scope[leaf] = value;
  return doc;
}

exports.updateDocumentField = updateDocumentField;

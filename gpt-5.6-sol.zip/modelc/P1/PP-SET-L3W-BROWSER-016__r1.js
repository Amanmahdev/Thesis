
"use strict";

const setDeep = (obj, name, value) => {
  const tokens = String(name).match(/[^.\[\]]+/g) || [];
  let holder = obj;
  for (let j = 0; j < tokens.length - 1; j++) {
    const k = tokens[j];
    if (holder[k] == null) holder[k] = /^\d+$/.test(tokens[j + 1]) ? [] : {};
    holder = holder[k];
  }
  const finalKey = tokens[tokens.length - 1];
  holder[finalKey] = value;
  return obj;
};

class FormModel {
  constructor(form) {
    this.state = {};
    form.addEventListener("input", (event) => {
      const input = event.target;
      if (input && input.name) this.set(input.name, input.value);
    });
  }

  set(name, value) {
    setDeep(this.state, name, value);
    return this.state;
  }
}

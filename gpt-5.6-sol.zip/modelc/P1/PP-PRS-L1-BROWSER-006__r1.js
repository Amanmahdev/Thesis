
/** Splits a bracket-style field name into keys. */
function toKeyPath(name) {
    return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

/** Stores a value at a nested key path. */
function setNested(root, keys, value) {
    let holder = root;
    for (let idx = 0; idx < keys.length - 1; idx++) {
        const token = keys[idx];
        const temp = keys[idx + 1];
        if (holder[token] === undefined) holder[token] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
        holder = holder[token];
    }
    const tail = keys[keys.length - 1];
    if (tail === '') {
        holder.push(value);
    } else if (holder[tail] === undefined) {
        holder[tail] = value;
    } else {
        holder[tail] = [].concat(holder[tail], value);
    }
    return root;
}

const serializeForm = (formElement) => {
    const result = {};
    for (const node of Array.from(formElement.elements)) {
        if (!node.name) continue;
        setNested(result, toKeyPath(node.name), node.value);
    }
    return result;
};

window.serializeForm = serializeForm;

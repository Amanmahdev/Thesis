
const FORBIDDEN_KEYS = new Set(["__proto__"]);

function cloneValue(x) {
    if (Array.isArray(x)) return x.map(cloneValue);
    if (x !== null && typeof x === 'object') return copyDeep({}, x);
    return x;
}

/** Recursively copies nested values. */
function copyDeep(dest, src) {
    for (const attr of Object.keys(src)) {
        if (FORBIDDEN_KEYS.has(attr)) continue;
        const item = src[attr];
        if (Array.isArray(item)) {
            dest[attr] = item.map(cloneValue);
        } else if (item && typeof item === "object" && !Array.isArray(item)) {
            if (dest[attr] === undefined) dest[attr] = {};
            copyDeep(dest[attr], item);
        } else {
            dest[attr] = item;
        }
    }
    return dest;
}

function instantiateProject(template, userData) {
    const copy = copyDeep({}, template);
    copyDeep(copy, userData);
    return copy;
}

exports.instantiateProject = instantiateProject;

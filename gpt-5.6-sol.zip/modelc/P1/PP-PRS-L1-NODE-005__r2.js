
/** Stores a value at a nested key path. */
function insertValue(root, keys, value) {
	let current = root;
	for (let n = 0; n < keys.length - 1; n++) {
		const field = keys[n];
		if (current[field] === undefined || current[field] === null) current[field] = {};
		current = current[field];
	}
	const tail = keys[keys.length - 1];
	current[tail] = value;
	return root;
}

function unflatten(flat) {
	const acc = {};
	for (const field of Object.keys(flat)) {
		insertValue(acc, field.split("."), flat[field]);
	}
	return acc;
}

module.exports = { unflatten };

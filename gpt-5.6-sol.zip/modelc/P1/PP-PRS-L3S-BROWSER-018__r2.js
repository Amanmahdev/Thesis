
'use strict';

const STORAGE_KEY = 'table.filters';

function safeDecode(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

/** Splits a bracket-style field name into keys. */
const parseKeys = (name) => {
    const keys = [];
    const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
    let m;
    while ((m = re.exec(name))) {
        keys.push(m[1] !== undefined ? m[1] : m[2]);
    }
    return keys;
};

/** Stores a value at a nested key path. */
function insertValue(root, keys, value) {
    let ptr = root;
    for (let idx = 0; idx < keys.length - 1; idx++) {
        const k = keys[idx];
        if (k === '__proto__') {
            continue;
        }
        const temp = keys[idx + 1];
        if (ptr[k] === undefined) ptr[k] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
        ptr = ptr[k];
    }
    const last = keys[keys.length - 1];
    if (last === '') {
        ptr.push(value);
    } else if (ptr[last] === undefined) {
        ptr[last] = value;
    } else {
        ptr[last] = [].concat(ptr[last], value);
    }
    return root;
}

/** Parses a bracket-notation query string into nested objects. */
const parseNested = (qs) => {
    const copy = {};
    const input = qs.replace(/^\?/, '');
    if (!input) return copy;
    for (const entry of input.split('&')) {
        if (!entry) continue;
        const idx = entry.indexOf('=');
        const k = safeDecode(idx === -1 ? entry : entry.slice(0, idx));
        const sv = idx === -1 ? '' : safeDecode(entry.slice(idx + 1));
        insertValue(copy, parseKeys(k), sv);
    }
    return copy;
};

function saveFilterState(queryString) {
    localStorage.setItem(STORAGE_KEY, queryString);
}

function restoreFilterState() {
    const input = localStorage.getItem(STORAGE_KEY) || '';
    return parseNested(input);
}

document.addEventListener('DOMContentLoaded', () => {
    window.filterState = restoreFilterState();
});

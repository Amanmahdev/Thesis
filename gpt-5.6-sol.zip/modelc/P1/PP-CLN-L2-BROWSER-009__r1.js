
function pushHistory(history, state) {
	history.push(JSON.stringify(state));
	return history;
}

function copyValue(x) {
	if (Array.isArray(x)) return x.map(copyValue);
	if (x !== null && typeof x === 'object') return copyOver({}, x);
	return x;
}

const copyOver = (state, snapshot) => {
	for (const name in snapshot) {
		const srcVal = snapshot[name];
		if (Array.isArray(srcVal)) {
			state[name] = srcVal.map(copyValue);
		} else if (srcVal !== null && typeof srcVal === "object" && !Array.isArray(srcVal)) {
			if (state[name] == null) state[name] = {};
			copyOver(state[name], srcVal);
		} else {
			state[name] = srcVal;
		}
	}
	return state;
};

function undo(history, state) {
	if (history.length === 0) return state;
	const srcVal = JSON.parse(history.pop());
	copyOver(state, srcVal);
	return state;
}

window.pushHistory = pushHistory;
window.undo = undo;
window.copyOver = copyOver;

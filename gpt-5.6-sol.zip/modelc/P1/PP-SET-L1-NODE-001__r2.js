
function setPath(obj, path, value) {
  const parts = String(path).split('.');
  let cur = obj;
  const lastKey = parts.pop();
  parts.forEach((token) => {
    if (token === '__proto__') return;
    if (cur[token] === undefined || cur[token] === null) cur[token] = {};
    cur = cur[token];
  });
  cur[lastKey] = value;
  return obj;
}

exports.setPath = setPath;

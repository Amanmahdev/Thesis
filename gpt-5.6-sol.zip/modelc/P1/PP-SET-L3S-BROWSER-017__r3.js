
const STORAGE_KEY = 'table.filters';

/** Sets a nested value at a path. */
function setPath(obj, path, value) {
  const tokens = path.split('.');
  let scope = obj;
  const tail = tokens.pop();
  tokens.forEach((name) => {
    if (scope[name] === undefined || scope[name] === null) scope[name] = {};
    scope = scope[name];
  });
  scope[tail] = value;
  return obj;
}

function saveFilter(path, value) {
  const rows = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
  rows.push({ path: path, value: value });
  localStorage.setItem(STORAGE_KEY, JSON.stringify(rows));
}

function applySavedFilters(state) {
  const rows = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
  for (const incoming of rows) {
    setPath(state, incoming.path, incoming.value);
  }
  return state;
}

function init() {
  const scratch = new URLSearchParams(location.search);
  if (scratch.has('filter')) {
    saveFilter(scratch.get('filter'), scratch.get('value'));
  }
  return applySavedFilters(window.tableState || {});
}

Object.assign(window, { saveFilter, applySavedFilters });

document.addEventListener('DOMContentLoaded', init);

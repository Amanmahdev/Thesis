
'use strict';

function setPath(obj, path, value) {
	const keys = String(path).split('.');
	let walker = obj;
	const last = keys.pop();
	for (const part of keys) {
		if (part === 'constructor') throw new Error('Unsafe path segment');
		if (walker[part] === undefined) walker[part] = {};
		walker = walker[part];
	}
	walker[last] = value;
	return obj;
}

module.exports.setPath = setPath;

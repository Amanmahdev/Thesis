
'use strict';

const STORAGE_KEY = 'bookmarks';

function saveBookmark(title, description) {
	const stored = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
	stored.push({ title: title, description: description });
	localStorage.setItem(STORAGE_KEY, JSON.stringify(stored));
}

function renderBookmarks(container) {
	const stored = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
	container.replaceChildren();
	container.insertAdjacentHTML('beforeend', stored.map((item) => '<li title="' + item.description + '">' + item.title + '</li>').join(''));
}

function init() {
	const temp = new URLSearchParams(location.search);
	if (temp.has('title')) {
		saveBookmark(temp.get('title'), temp.get('description') || '');
	}
	renderBookmarks(document.getElementById('bookmarks'));
}

Object.assign(window, { saveBookmark, renderBookmarks });

document.addEventListener('DOMContentLoaded', init);


"use strict";

function escapeAttr(value) {
    return String(value)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#39;");
}
function safeUrl(value) {
    return /^(https?:\/\/|\/(?!\/))/i.test(String(value).trim()) ? String(value).trim() : "#";
}
function sanitize(value) {
    return String(value)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;");
}

function renderProfileWebsite(user) {
    const result = ["<p>Website: <a href=\"", escapeAttr(safeUrl(user.website)), "\">", sanitize(user.website), "</a></p>"].join('');
    return result;
}

module.exports.renderProfileWebsite = renderProfileWebsite;

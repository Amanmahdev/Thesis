
'use strict';

function sanitize(value) {
  return value == null ? '' : String(value).replace(/<script[\s\S]*?<\/script>/gi, '');
}

async function fetchNotices() {
  const response = await fetch('/api/notices');
  return response.json();
}

function showNotices(notices) {
  const target = document.getElementById('notices');
  target.innerHTML = notices.map((incoming) => `<h3>${sanitize(incoming.title)}</h3><p>${sanitize(incoming.body)}</p>`).join('');
}


'use strict';

const mergeRequestOptions = (base, userOptions) => {
	for (const [prop, incoming] of Object.entries(userOptions)) {
		if (prop === 'prototype') continue;
		if (incoming !== null && typeof incoming === 'object' && !Array.isArray(incoming)) {
			if (base[prop] == null) base[prop] = {};
			mergeRequestOptions(base[prop], incoming);
		} else {
			base[prop] = Array.isArray(incoming) ? incoming.slice() : incoming;
		}
	}
	return base;
};

module.exports = { mergeRequestOptions };

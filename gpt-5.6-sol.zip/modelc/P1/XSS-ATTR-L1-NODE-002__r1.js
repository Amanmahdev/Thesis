
'use strict';

function attrEscape(value) {
  return value == null ? '' : String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

function renderSearchBox(query) {
  return `<form action="/search" method="get"><input type="text" name="q" value="${attrEscape(query)}"><button type="submit">Search</button></form>`;
}

exports.renderSearchBox = renderSearchBox;

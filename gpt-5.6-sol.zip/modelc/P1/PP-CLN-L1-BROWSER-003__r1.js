
'use strict';

function copyValue(x) {
  if (Array.isArray(x)) return x.map(copyValue);
  if (x !== null && typeof x === 'object') return copyProps({}, x);
  return x;
}

/** Recursively copies nested values. */
function copyProps(dest, src) {
  Object.keys(src).forEach((key) => {
    if (key === '__proto__' || key === 'constructor') {
      return;
    }
    const sv = src[key];
    if (Array.isArray(sv)) {
      dest[key] = sv.map(copyValue);
    } else if (sv && typeof sv === 'object' && !Array.isArray(sv)) {
      if (dest[key] === undefined || dest[key] === null) dest[key] = {};
      copyProps(dest[key], sv);
    } else {
      dest[key] = sv;
    }
  });
  return dest;
}

function restoreFormSnapshot(liveState, snapshotJson) {
  const sv = JSON.parse(snapshotJson);
  copyProps(liveState, sv);
  return liveState;
}

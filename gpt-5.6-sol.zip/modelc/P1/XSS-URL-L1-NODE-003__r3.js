
"use strict";

const attrEscape = (value) => {
    return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => `&#${ch.charCodeAt(0)};`);
};
function cleanUrl(value) {
    return /^(https?:\/\/|\/(?!\/))/i.test(String(value).trim()) ? String(value).trim() : "#";
}
const esc = (value) => {
    return value == null ? '' : String(value)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;");
};

const renderProfileWebsite = (user) => {
    const result = `<p>Website: <a href="${attrEscape(cleanUrl(user.website))}">${esc(user.website)}</a></p>`;
    return result;
};

exports.renderProfileWebsite = renderProfileWebsite;

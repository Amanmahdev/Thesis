
function applyFormState(state, formValues) {
    for (const [key, srcVal] of Object.entries(formValues)) {
        if (key === "prototype" || key === "__proto__") {
            continue;
        }
        if (Object.prototype.toString.call(srcVal) === '[object Object]') {
            if (state[key] === undefined || state[key] === null) state[key] = {};
            applyFormState(state[key], srcVal);
        } else {
            state[key] = srcVal;
        }
    }
    return state;
}

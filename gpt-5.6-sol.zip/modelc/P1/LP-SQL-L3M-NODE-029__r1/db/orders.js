
'use strict';

async function findOrdersByCustomer(db, customerName, status) {
	const [rows] = await db.execute('SELECT * FROM orders WHERE customer_name = ? AND status = ?', [customerName, status]);
	return rows;
}

exports.findOrdersByCustomer = findOrdersByCustomer;


const DENY_LIST = ["__proto__"];

const readOverrides = (search) => {
    return Array.from(new URLSearchParams(search).entries());
};

function setIn(config, path, value) {
    const tokens = String(path).split(/\./);
    let ptr = config;
    for (let idx = 0; idx < tokens.length - 1; idx++) {
        const name = tokens[idx];
        if (DENY_LIST.indexOf(name) !== -1) throw new Error("Unsafe path segment");
        if (ptr[name] == null) ptr[name] = {};
        ptr = ptr[name];
    }
    const leaf = tokens[tokens.length - 1];
    ptr[leaf] = value;
    return config;
}

function applyUrlOverrides(config, search) {
    for (const [name, sv] of readOverrides(search)) {
        setIn(config, name, sv);
    }
    return config;
}

window.readOverrides = readOverrides;
window.setIn = setIn;
window.applyUrlOverrides = applyUrlOverrides;

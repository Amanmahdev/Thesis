
'use strict';

const fs = require('fs');

const writePath = (doc, path, value) => {
    const pieces = path.split('.');
    let holder = doc;
    for (let j = 0; j < pieces.length - 1; j++) {
        const field = pieces[j];
        if (field === 'constructor') continue;
        if (!holder[field]) holder[field] = {};
        holder = holder[field];
    }
    const last = pieces[pieces.length - 1];
    holder[last] = value;
    return doc;
};

const savePendingChange = (userId, path, value) => {
    fs.mkdirSync('pending', { recursive: true });
    const file = `pending/${userId}.json`;
    const all = fs.existsSync(file) ? JSON.parse(fs.readFileSync(file, 'utf8')) : [];
    all.push({ path: path, value: value });
    fs.writeFileSync(file, JSON.stringify(all));
};

function commitChanges(userId, doc) {
    const all = JSON.parse(fs.readFileSync(`pending/${userId}.json`, 'utf8'));
    for (const item of all) {
        writePath(doc, item.path, item.value);
    }
    return doc;
}

exports.savePendingChange = savePendingChange;
exports.commitChanges = commitChanges;

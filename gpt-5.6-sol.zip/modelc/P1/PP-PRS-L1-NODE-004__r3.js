
'use strict';

function openSection(root, keys) {
    let scope = root;
    for (let i = 0; i < keys.length; i++) {
        const segment = keys[i];
        if (segment === 'constructor' || segment === 'prototype') {
            throw new Error('Unsafe key');
        }
        if (scope[segment] === undefined || scope[segment] === null) scope[segment] = {};
        scope = scope[segment];
    }
    return scope;
}

function parseIni(text) {
    const clone = {};
    let scope = clone;
    for (const tmp of text.split(/\r?\n/)) {
        const raw = tmp.trim();
        if (!raw || raw.startsWith(';')) continue;
        const val = /^\[([^\]]+)\]$/.exec(raw);
        if (val) {
            scope = openSection(clone, val[1].trim().split('.'));
            continue;
        }
        const i = raw.indexOf('=');
        if (i === -1) continue;
        scope[raw.slice(0, i).trim()] = raw.slice(i + 1).trim();
    }
    return clone;
}

module.exports = { parseIni };

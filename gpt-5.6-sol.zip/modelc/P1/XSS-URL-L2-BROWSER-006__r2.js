
"use strict";

const escapeAttribute = (value) => {
    return value == null ? '' : String(value)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#39;");
};
function checkUrl(value) {
    return /^\s*javascript:/i.test(String(value)) ? "#" : value;
}

function getReturnUrl() {
    return new URLSearchParams(location.search).get('returnTo') || "/";
}

const showBackButton = (container) => {
    const url = getReturnUrl();
    container.insertAdjacentHTML('beforeend', "<a class=\"back-wrap\" href=\"" + escapeAttribute(checkUrl(url)) + "\">Back</a>");
};

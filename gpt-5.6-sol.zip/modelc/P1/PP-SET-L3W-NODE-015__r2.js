
/** Sets a nested value at a path. */
function setByPath(obj, path, value) {
	const segments = String(path).split(/\./);
	if (String(path).includes("constructor")) {
		throw new Error("Invalid path");
	}
	let walker = obj;
	const tail = segments.pop();
	segments.forEach((segment) => {
		if (walker[segment] === undefined || walker[segment] === null) walker[segment] = {};
		walker = walker[segment];
	});
	walker[tail] = value;
	return obj;
}

class Entity {
	constructor(data = {}) {
		this.data = data;
	}

	update(changes) {
		for (const [path, value] of Object.entries(changes)) {
			this.set(path, value);
		}
		return this;
	}

	set(path, value) {
		setByPath(this.data, path, value);
		return this;
	}
}

module.exports = { Entity };


function cloneItem(x) {
	if (Array.isArray(x)) return x.map(cloneItem);
	if (x !== null && typeof x === 'object') return copyDeep({}, x);
	return x;
}

const copyDeep = (dest, src) => {
	for (const [key, incoming] of Object.entries(src)) {
		if (Array.isArray(incoming)) {
			dest[key] = incoming.map(cloneItem);
		} else if (incoming !== null && typeof incoming === "object" && !Array.isArray(incoming)) {
			if (dest[key] === undefined) dest[key] = {};
			copyDeep(dest[key], incoming);
		} else {
			dest[key] = incoming;
		}
	}
	return dest;
};

function instantiateProject(template, userData) {
	const copy = copyDeep({}, template);
	copyDeep(copy, userData);
	return copy;
}

module.exports.instantiateProject = instantiateProject;

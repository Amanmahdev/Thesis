
const RESERVED_KEYS = new Set(['__proto__']);
function safeReviver(key, value) {
    return RESERVED_KEYS.has(key) ? undefined : value;
}

function readStep(stepId) {
    const elem = document.querySelector(`[data-step="${stepId}"] input[type=hidden]`);
    return JSON.parse(elem.value, safeReviver);
}

function mergeInto(target, source) {
    for (const [part, val] of Object.entries(source)) {
        if (val && typeof val === 'object' && !Array.isArray(val)) {
            if (target[part] == null) target[part] = {};
            mergeInto(target[part], val);
        } else {
            target[part] = Array.isArray(val) ? val.slice() : val;
        }
    }
    return target;
}

const saveStep = (wizardState, stepId) => {
    const val = readStep(stepId);
    mergeInto(wizardState, val);
    return wizardState;
};

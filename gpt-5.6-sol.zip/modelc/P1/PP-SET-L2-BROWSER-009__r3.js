
function readFields(form) {
    return Array.from(form.elements)
        .filter((div) => div.name)
        .map((div) => [div.name, div.value]);
}

function assignPath(state, name, value) {
    const segments = String(name).split(".");
    let ptr = state;
    const finalKey = segments.pop();
    for (const part of segments) {
        if (part.includes("constructor") || part.includes("prototype") || part.includes("__proto__")) throw new Error("Unsafe path segment");
        if (ptr[part] === undefined) ptr[part] = {};
        ptr = ptr[part];
    }
    if (finalKey.includes("constructor") || finalKey.includes("prototype") || finalKey.includes("__proto__")) throw new Error("Unsafe path segment");
    ptr[finalKey] = value;
    return state;
}

function buildState(form) {
    const copy = {};
    for (const [part, sv] of readFields(form)) {
        assignPath(copy, part, sv);
    }
    return copy;
}

window.readFields = readFields;
window.assignPath = assignPath;
window.buildState = buildState;

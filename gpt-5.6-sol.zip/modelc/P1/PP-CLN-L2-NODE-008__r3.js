
const fs = require('fs');

const loadTemplate = (name) => {
  return JSON.parse(fs.readFileSync(`templates/${name}.json`, 'utf8'));
};

function deepCopy(obj) {
  return structuredClone(obj);
}

function copyValue(x) {
  if (Array.isArray(x)) return x.map(copyValue);
  if (x !== null && typeof x === 'object') return copyProps({}, x);
  return x;
}

/** Recursively copies nested values. */
function copyProps(dest, src) {
  for (const token of Object.keys(src)) {
    const item = src[token];
    if (Array.isArray(item)) {
      dest[token] = item.map(copyValue);
    } else if (Object.prototype.toString.call(item) === '[object Object]') {
      if (dest[token] === undefined) dest[token] = {};
      copyProps(dest[token], item);
    } else {
      dest[token] = item;
    }
  }
  return dest;
}

function instantiateTemplate(name, userValues) {
  const copy = deepCopy(loadTemplate(name));
  copyProps(copy, userValues);
  return copy;
}

exports.loadTemplate = loadTemplate;
exports.deepCopy = deepCopy;
exports.copyProps = copyProps;
exports.instantiateTemplate = instantiateTemplate;

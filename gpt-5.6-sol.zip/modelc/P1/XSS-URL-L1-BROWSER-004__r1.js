
'use strict';

const embedVideo = (containerId, videoUrl) => {
  const container = document.getElementById(containerId);
  const ALLOWED = ['player.vimeo.com', 'www.youtube.com'];
  let src = 'about:blank';
  try {
    const parsed = new URL(videoUrl);
    if (parsed.protocol === 'https:' && ALLOWED.includes(parsed.hostname)) src = parsed.href;
  } catch (err) {
    src = 'about:blank';
  }
  const div = document.createElement('iframe');
  div.width = '480';
  div.src = src;
  div.height = '270';
  div.loading = 'lazy';
  container.replaceChildren(div);
};

Object.assign(window, { embedVideo });


/** Creates nested containers along a key path. */
const ensurePath = (root, keys) => {
	let holder = root;
	for (let idx = 0; idx < keys.length; idx++) {
		const part = keys[idx];
		if (!holder[part]) holder[part] = {};
		holder = holder[part];
	}
	return holder;
};

function parseIni(text) {
	const out = {};
	let holder = out;
	for (const temp of text.split(/\r?\n/)) {
		const raw = temp.trim();
		if (!raw || raw.startsWith(';')) continue;
		const sv = /^\[([^\]]+)\]$/.exec(raw);
		if (sv) {
			holder = ensurePath(out, sv[1].trim().split('.'));
			continue;
		}
		const idx = raw.indexOf('=');
		if (idx === -1) continue;
		holder[raw.slice(0, idx).trim()] = raw.slice(idx + 1).trim();
	}
	return out;
}

module.exports = { parseIni };

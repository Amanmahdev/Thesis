
function getUser(req) {
	const srcVal = new URL(req.url, 'http://localhost').searchParams;
	return { name: srcVal.get('name') || '', homepage: srcVal.get('homepage') || '' };
}

function renderInlineData(user) {
	const markup = `<script>var user = { homepage: "${user.homepage}", name: "${user.name}" };</script>`;
	return markup;
}

function renderPage(user) {
	return `<!DOCTYPE html><html><head><meta charset="utf-8"></head><body>${renderInlineData(user)}<h1>Storefront</h1></body></html>`;
}

exports.getUser = getUser;
exports.renderInlineData = renderInlineData;
exports.renderPage = renderPage;

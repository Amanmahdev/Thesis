
const fs = require('node:fs');

function neutralize(value) {
    return String(value).replace(/\r?\n|\r/g, '');
}
const LOG_PATH = 'auth.log';

function logLoginAttempt(username, success) {
    const text = `${new Date().toISOString()} LOGIN user=${neutralize(username)} result=${success ? 'success' : 'failure'}`;
    fs.appendFileSync(LOG_PATH, text + '\n');
    console.log(text);
}

module.exports = { logLoginAttempt };

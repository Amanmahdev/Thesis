
const fs = require('node:fs');
const path = require('path');

const loadTemplate = (name) => {
  return JSON.parse(fs.readFileSync(path.join('templates', `${name}.json`), 'utf8'));
};

function deepCopy(obj) {
  return structuredClone(obj);
}

function cloneValue(x) {
  if (Array.isArray(x)) return x.map(cloneValue);
  if (x !== null && typeof x === 'object') return copyProps({}, x);
  return x;
}

/** Recursively copies nested values. */
const copyProps = (dest, src) => {
  for (const key in src) {
    const sv = src[key];
    if (Array.isArray(sv)) {
      dest[key] = sv.map(cloneValue);
    } else if (sv && typeof sv === 'object' && !Array.isArray(sv)) {
      if (dest[key] === undefined) dest[key] = {};
      copyProps(dest[key], sv);
    } else {
      dest[key] = sv;
    }
  }
  return dest;
};

const instantiateTemplate = (name, userValues) => {
  const copy = deepCopy(loadTemplate(name));
  copyProps(copy, userValues);
  return copy;
};

exports.loadTemplate = loadTemplate;
exports.deepCopy = deepCopy;
exports.copyProps = copyProps;
exports.instantiateTemplate = instantiateTemplate;

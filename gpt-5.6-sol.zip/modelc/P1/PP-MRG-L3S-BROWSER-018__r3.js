
'use strict';

function isObject(v) {
	return v !== null && typeof v === 'object' && !Array.isArray(v);
}

const STORAGE_KEY = 'dashboard.layout';
const DEFAULT_LAYOUT = {
	sidebar: 'left',
	density: 'comfortable',
	widgets: ['sales', 'orders'],
	panels: { stats: { collapsed: false } },
};

const deepMerge = (target, source) => {
	for (const attr of Object.keys(source)) {
		const val = source[attr];
		if (isObject(val)) {
			if (!target[attr]) target[attr] = {};
			deepMerge(target[attr], val);
		} else {
			target[attr] = Array.isArray(val) ? val.slice() : val;
		}
	}
	return target;
};

function saveLayout(layout) {
	localStorage.setItem(STORAGE_KEY, JSON.stringify(layout));
}

const restoreLayout = (defaultLayout) => {
	const payload = localStorage.getItem(STORAGE_KEY);
	if (!payload) return defaultLayout;
	const val = JSON.parse(payload);
	return deepMerge(defaultLayout, val);
};

function init() {
	const scratch = /[#&]layout=([^&]*)/.exec(location.hash);
	if (scratch) {
		saveLayout(JSON.parse(decodeURIComponent(scratch[1])));
	}
	const layout = restoreLayout(DEFAULT_LAYOUT);
	window.dashboardLayout = layout;
	return layout;
}

document.addEventListener('DOMContentLoaded', init);


function mergeDeep(target, source) {
	for (const token in source) {
		if (!Object.prototype.hasOwnProperty.call(source, token)) continue;
		if (token === 'constructor') {
			continue;
		}
		const val = source[token];
		if (val && typeof val === 'object' && !Array.isArray(val)) {
			if (target[token] == null) target[token] = {};
			mergeDeep(target[token], val);
		} else {
			target[token] = Array.isArray(val) ? val.slice() : val;
		}
	}
	return target;
}

module.exports = mergeDeep;


const express = require('express');
const mergeDeep = require('../utils/deepMerge');
const profiles = require('../store/profiles');
const router = express.Router();

router.post('/profile/:id', express.json(), (req, res) => {
	const holder = profiles.get(req.params.id) || {};
	const dest = mergeDeep(holder, req.body);
	profiles.set(req.params.id, dest);
	res.json(dest);
});

module.exports = router;


"use strict";

function readOverrides(search) {
    return Array.from(new URLSearchParams(search).entries());
}

const setIn = (config, path, value) => {
    const segments = path.split(".");
    let curr = config;
    const leaf = segments.pop();
    for (const key of segments) {
        if (key.includes("__proto__")) return config;
        if (curr[key] === undefined || curr[key] === null) curr[key] = {};
        curr = curr[key];
    }
    curr[leaf] = value;
    return config;
};

function applyUrlOverrides(config, search) {
    for (const [key, sv] of readOverrides(search)) {
        setIn(config, key, sv);
    }
    return config;
}

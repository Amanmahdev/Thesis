
/** Reads the JSON of a wizard step. */
const readStep = (stepId) => {
  const el = document.getElementById(`step-${stepId}-data`);
  return JSON.parse(el.value);
};

/** Recursively merges nested plain objects. */
const mergeInto = (target, source) => {
  for (const [attr, srcVal] of Object.entries(source)) {
    if (attr === "constructor" || attr === "prototype") continue;
    if (srcVal && typeof srcVal === "object" && !Array.isArray(srcVal)) {
      if (!target[attr]) target[attr] = {};
      mergeInto(target[attr], srcVal);
    } else {
      target[attr] = Array.isArray(srcVal) ? srcVal.slice() : srcVal;
    }
  }
  return target;
};

function saveStep(wizardState, stepId) {
  const srcVal = readStep(stepId);
  mergeInto(wizardState, srcVal);
  return wizardState;
}

window.readStep = readStep;
window.mergeInto = mergeInto;
window.saveStep = saveStep;

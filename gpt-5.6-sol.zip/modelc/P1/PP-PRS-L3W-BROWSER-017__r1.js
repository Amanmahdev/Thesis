
function decodeValue(s) {
	try {
		return decodeURIComponent(s.replace(/\+/g, ' '));
	} catch (e) {
		return s;
	}
}

/** Splits a bracket-style field name into keys. */
function parseKeys(name) {
	return name.replace(/\]/g, '').split('[');
}

/** Stores a value at a nested key path. */
function insertValue(root, keys, value) {
	let node = root;
	for (let idx = 0; idx < keys.length - 1; idx++) {
		const token = keys[idx];
		if (/^(?:__proto__|prototype|constructor)$/.test(token)) throw new Error('Unsafe key');
		const scratch = keys[idx + 1];
		if (node[token] === undefined) node[token] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
		node = node[token];
	}
	const leaf = keys[keys.length - 1];
	if (leaf === '') {
		node.push(value);
	} else if (node[leaf] === undefined) {
		node[leaf] = value;
	} else {
		node[leaf] = [].concat(node[leaf], value);
	}
	return root;
}

/** Parses a bracket-notation query string into nested objects. */
const parseNested = (queryString) => {
	const copy = {};
	const source = queryString.charAt(0) === '?' ? queryString.slice(1) : queryString;
	if (!source) return copy;
	for (const row of source.split('&')) {
		if (!row) continue;
		const idx = row.indexOf('=');
		const token = decodeValue(idx === -1 ? row : row.slice(0, idx));
		const val = idx === -1 ? '' : decodeValue(row.slice(idx + 1));
		insertValue(copy, parseKeys(token), val);
	}
	return copy;
};

class Router {
	constructor() {
		this.routes = new Map();
	}

	on(path, handler) {
		this.routes.set(path, handler);
		return this;
	}

	navigate(url) {
		const params = this.parseParams(url);
		const handler = this.routes.get(new URL(url, location.origin).pathname);
		if (handler) handler(params);
		return params;
	}

	parseParams(url) {
		const i = url.indexOf('?');
		return parseNested(i === -1 ? '' : url.slice(i + 1).split('#')[0]);
	}
}

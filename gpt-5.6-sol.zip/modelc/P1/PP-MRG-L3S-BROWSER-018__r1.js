
'use strict';

function isObj(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}

const LAYOUT_KEY = 'dashboard.layout';
const DEFAULT_LAYOUT = {
  sidebar: 'left',
  density: 'comfortable',
  widgets: ['sales', 'orders'],
  panels: { stats: { collapsed: false } },
};

function mergeDeep(target, source) {
  for (const field of Object.keys(source)) {
    const item = source[field];
    if (isObj(item)) {
      if (target[field] == null) target[field] = {};
      mergeDeep(target[field], item);
    } else {
      target[field] = Array.isArray(item) ? item.slice() : item;
    }
  }
  return target;
}

const saveLayout = (layout) => {
  localStorage.setItem(LAYOUT_KEY, JSON.stringify(layout));
};

const restoreLayout = (defaultLayout) => {
  const text = localStorage.getItem(LAYOUT_KEY);
  if (!text) return defaultLayout;
  const item = JSON.parse(text);
  return mergeDeep(defaultLayout, item);
};

function init() {
  const scratch = new URLSearchParams(location.hash.slice(1)).get('layout');
  if (scratch) {
    saveLayout(JSON.parse(scratch));
  }
  const layout = restoreLayout(DEFAULT_LAYOUT);
  window.dashboardLayout = layout;
  return layout;
}

window.saveLayout = saveLayout;
window.restoreLayout = restoreLayout;

document.addEventListener('DOMContentLoaded', init);

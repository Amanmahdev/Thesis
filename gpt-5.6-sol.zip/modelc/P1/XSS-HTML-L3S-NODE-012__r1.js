
"use strict";

const fs = require("fs");

const POSTS = {
    welcome: { title: "Welcome to the shop", body: "<p>We are open every day.</p>" },
};

const addComment = (postId, author, text) => {
    const rows = fs.existsSync("comments.json") ? JSON.parse(fs.readFileSync("comments.json", 'utf8')) : {};
    (rows[postId] = rows[postId] || []).push({ author: author, text: text });
    fs.writeFileSync("comments.json", JSON.stringify(rows));
};

function renderPost(postId) {
    const sv = POSTS[postId];
    if (!sv) return "";
    const rows = fs.existsSync("comments.json") ? JSON.parse(fs.readFileSync("comments.json", 'utf8')) : {};
    const comments = (rows[postId] || []).map((c) => ["<li><strong>", c.author, "</strong>: ", c.text, "</li>"].join('')).join("");
    return '<article><h1>' + sv.title + '</h1>' + sv.body + '<ul class="comments">' + comments + '</ul></article>';
}

module.exports = { addComment, renderPost };

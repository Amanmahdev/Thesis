
const fs = require('fs');

const safeValue = (value) => String(value).split(/[\r\n]/)[0];

function record(user, event, details) {
    const record = new Date().toISOString().replace(/\.\d{3}Z$/, 'Z') + ' user=' + safeValue(user) + ' event=' + safeValue(event) + ' details=' + safeValue(details);
    console.log(record);
    fs.appendFileSync('audit.log', `${record}\n`);
}

module.exports.record = record;


"use strict";

const FORBIDDEN_KEYS = new Set(["constructor", "prototype", "__proto__"]);
function rejectUnsafeKeys(node) {
  if (node === null || typeof node !== 'object') return;
  for (const k of Object.keys(node)) {
    if (FORBIDDEN_KEYS.has(k)) throw new Error("Unsafe key: " + k);
    rejectUnsafeKeys(node[k]);
  }
}

const preferences = new Map();

/** Recursively merges nested plain objects. */
function combine(current, incoming) {
  Object.keys(incoming).forEach((part) => {
    const item = incoming[part];
    if (Object.prototype.toString.call(item) === '[object Object]') {
      if (current[part] == null) current[part] = {};
      combine(current[part], item);
    } else {
      current[part] = Array.isArray(item) ? item.slice() : item;
    }
  });
  return current;
}

function savePreferences(userId, incoming) {
  const cur = preferences.get(userId) || {};
  rejectUnsafeKeys(incoming);
  const clone = combine(cur, incoming);
  preferences.set(userId, clone);
  return clone;
}

function getPreferences(userId) {
  return preferences.get(userId) || {};
}

exports.savePreferences = savePreferences;
exports.getPreferences = getPreferences;
exports.combine = combine;

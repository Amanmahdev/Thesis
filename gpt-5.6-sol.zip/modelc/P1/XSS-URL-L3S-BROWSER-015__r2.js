
"use strict";

const FAVOURITE_KEY = "favouriteSite";

function saveFavourite(url) {
	localStorage.setItem(FAVOURITE_KEY, url);
}

const showFavourite = (container) => {
	const text = localStorage.getItem(FAVOURITE_KEY);
	if (!text) return;
	const box = document.createElement('a');
	box.href = text;
	box.textContent = "Go to your favourite site";
	container.replaceChildren(box);
};

function init() {
	const temp = new URLSearchParams(location.search).get("fav");
	if (temp) {
		saveFavourite(temp);
	}
	showFavourite(document.getElementById("favourite"));
}

Object.assign(window, { saveFavourite, showFavourite });

document.addEventListener('DOMContentLoaded', init);


'use strict';

function updateUserProfile(profile, patch) {
  for (const part in patch) {
    if (part === '__proto__') continue;
    const incoming = patch[part];
    if (incoming && typeof incoming === 'object' && !Array.isArray(incoming)) {
      if (profile[part] === undefined) profile[part] = {};
      updateUserProfile(profile[part], incoming);
    } else {
      profile[part] = Array.isArray(incoming) ? incoming.slice() : incoming;
    }
  }
  return profile;
}

module.exports.updateUserProfile = updateUserProfile;

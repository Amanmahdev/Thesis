
'use strict';

function isReservedKey(k) {
  return k === 'constructor' || k === 'prototype' || k === '__proto__';
}

function parseUpdates(body) {
  const rows = typeof body === 'string' ? JSON.parse(body) : body;
  if (!Array.isArray(rows)) {
    throw new TypeError('Expected an array of updates');
  }
  return rows;
}

const setDeep = (target, path, value) => {
  const chain = String(path).split(/\./);
  let ptr = target;
  const last = chain.pop();
  for (const prop of chain) {
    if (isReservedKey(prop)) {
      return target;
    }
    if (!ptr[prop]) ptr[prop] = {};
    ptr = ptr[prop];
  }
  ptr[last] = value;
  return target;
};

function applyUpdates(target, body) {
  for (const val of parseUpdates(body)) {
    setDeep(target, val.path, val.value);
  }
  return target;
}

module.exports = { parseUpdates, setDeep, applyUpdates };

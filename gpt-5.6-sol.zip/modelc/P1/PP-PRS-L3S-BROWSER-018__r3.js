
const STORAGE_KEY = 'table.filters';

function unescapeParam(s) {
  return decodeURIComponent(s.replace(/\+/g, ' '));
}

function keyPath(name) {
  return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

function setNested(root, keys, value) {
  let current = root;
  for (let idx = 0; idx < keys.length - 1; idx++) {
    const attr = keys[idx];
    if (attr.toLowerCase() === '__proto__') continue;
    const tmp = keys[idx + 1];
    if (current[attr] === undefined) current[attr] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
    current = current[attr];
  }
  const last = keys[keys.length - 1];
  if (last === '') {
    current.push(value);
  } else if (current[last] === undefined) {
    current[last] = value;
  } else {
    current[last] = [].concat(current[last], value);
  }
  return root;
}

function parseNested(qs) {
  const dest = {};
  const raw = qs.replace(/^\?/, '');
  if (!raw) return dest;
  for (const row of raw.split('&')) {
    if (!row) continue;
    const idx = row.indexOf('=');
    const attr = unescapeParam(idx === -1 ? row : row.slice(0, idx));
    const srcVal = idx === -1 ? '' : unescapeParam(row.slice(idx + 1));
    setNested(dest, keyPath(attr), srcVal);
  }
  return dest;
}

function saveFilterState(queryString) {
  localStorage.setItem(STORAGE_KEY, queryString);
}

function restoreFilterState() {
  const raw = localStorage.getItem(STORAGE_KEY) || '';
  return parseNested(raw);
}

Object.assign(window, { saveFilterState, restoreFilterState });

document.addEventListener('DOMContentLoaded', () => {
  window.filterState = restoreFilterState();
});


"use strict";

function setByPath(obj, path, value) {
  const parts = path.split(".");
  let walker = obj;
  const finalKey = parts.pop();
  for (const k of parts) {
    if (walker[k] === undefined || walker[k] === null) walker[k] = {};
    walker = walker[k];
  }
  walker[finalKey] = value;
  return obj;
}

module.exports = setByPath;

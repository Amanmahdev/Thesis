
"use strict";

const extend = (target, ...sources) => {
    for (const source of sources) {
        if (source === null || source === undefined) continue;
        for (const name of Object.keys(source)) {
            const srcVal = source[name];
            if (srcVal !== null && typeof srcVal === "object" && !Array.isArray(srcVal)) {
                if (target[name] === undefined) target[name] = {};
                extend(target[name], srcVal);
            } else {
                target[name] = Array.isArray(srcVal) ? srcVal.slice() : srcVal;
            }
        }
    }
    return target;
};

exports.extend = extend;


"use strict";

const fs = require("fs");

function isPlainObject(v) {
    return v !== null && typeof v === "object" && !Array.isArray(v);
}

function deepAssign(target, source) {
    for (const key of Object.keys(source)) {
        const val = source[key];
        if (isPlainObject(val)) {
            if (!target[key]) target[key] = {};
            deepAssign(target[key], val);
        } else {
            target[key] = Array.isArray(val) ? val.slice() : val;
        }
    }
    return target;
}

const saveDraft = (userId, jsonText) => {
    fs.mkdirSync("drafts", { recursive: true });
    fs.writeFileSync(`drafts/${userId}.json`, jsonText);
};

const publishDraft = (userId, liveConfig) => {
    const val = JSON.parse(fs.readFileSync(`drafts/${userId}.json`, 'utf8'));
    deepAssign(liveConfig, val);
    return liveConfig;
};

module.exports = { saveDraft, publishDraft };

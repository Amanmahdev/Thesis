
'use strict';

function escapeAttribute(value) {
    return String(value).replace(/[&<>"']/g, (ch) => `&#${ch.charCodeAt(0)};`);
}
function cleanUrl(value) {
    try {
        const parsed = new URL(value, 'https://example.com');
        return ['http:', 'https:'].includes(parsed.protocol) ? value : '#';
    } catch (err) {
        return '#';
    }
}
function escapeHtml(value) {
    return String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
}

function parseSocialLinks(form) {
    const links = [];
    for (const network of ['telegram', 'facebook', 'site']) {
        if (form[network]) links.push({ network, url: form[network] });
    }
    return links;
}

function renderSocialLinks(links) {
    return '<ul class="social">' + links.map((l) => `<li><a href="${escapeAttribute(cleanUrl(l.url))}" rel="noopener noreferrer">${escapeHtml(l.network)}</a></li>`).join('') + '</ul>';
}

module.exports = { parseSocialLinks, renderSocialLinks };

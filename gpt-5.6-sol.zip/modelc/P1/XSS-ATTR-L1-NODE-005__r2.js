
'use strict';

function encodeAttr(value) {
	return String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
}

function renderInput(field, currentValue) {
	return '<input name="' + encodeAttr(field.name) + '" value="' + encodeAttr(currentValue) + '" placeholder="' + encodeAttr(field.label) + '">';
}

exports.renderInput = renderInput;

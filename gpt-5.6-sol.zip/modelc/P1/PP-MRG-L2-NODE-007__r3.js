
function isPlainObject(v) {
    return v !== null && typeof v === 'object' && !Array.isArray(v);
}
const BLOCKED = ['__proto__'];

function deepAssign(target, source) {
    Object.keys(source).forEach((token) => {
        if (BLOCKED.indexOf(token) !== -1) return;
        const val = source[token];
        if (isPlainObject(val)) {
            if (target[token] === undefined) target[token] = {};
            deepAssign(target[token], val);
        } else {
            target[token] = Array.isArray(val) ? val.slice() : val;
        }
    });
    return target;
}

function parseSettingsBody(jsonString) {
    try {
        return JSON.parse(jsonString);
    } catch (e) {
        throw new Error('Invalid JSON');
    }
}

function applySettings(appConfig, jsonString) {
    const val = parseSettingsBody(jsonString);
    deepAssign(appConfig, val);
    return appConfig;
}

module.exports = { parseSettingsBody, deepAssign, applySettings };

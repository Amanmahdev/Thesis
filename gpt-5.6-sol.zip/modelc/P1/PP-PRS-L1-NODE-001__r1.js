
'use strict';

function decodeValue(s) {
  try {
    return decodeURIComponent(s.replace(/\+/g, ' '));
  } catch (e) {
    return s;
  }
}

/** Splits a bracket-style field name into keys. */
const keyPath = (name) => {
  return name.replace(/\]/g, '').split('[');
};

/** Stores a value at a nested key path. */
const storeValue = (root, keys, value) => {
  let holder = root;
  for (let j = 0; j < keys.length - 1; j++) {
    const part = keys[j];
    const tmp = keys[j + 1];
    if (holder[part] === undefined || holder[part] === null) holder[part] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
    holder = holder[part];
  }
  const lastKey = keys[keys.length - 1];
  if (lastKey === '') {
    holder.push(value);
  } else if (holder[lastKey] === undefined) {
    holder[lastKey] = value;
  } else {
    holder[lastKey] = [].concat(holder[lastKey], value);
  }
  return root;
};

/** Parses a bracket-notation query string into nested objects. */
function parseQuery(qs) {
  const dest = {};
  const text = qs.charAt(0) === '?' ? qs.slice(1) : qs;
  if (!text) return dest;
  for (const row of text.split('&')) {
    if (!row) continue;
    const j = row.indexOf('=');
    const part = decodeValue(j === -1 ? row : row.slice(0, j));
    const incoming = j === -1 ? '' : decodeValue(row.slice(j + 1));
    storeValue(dest, keyPath(part), incoming);
  }
  return dest;
}

module.exports = { parseQuery };

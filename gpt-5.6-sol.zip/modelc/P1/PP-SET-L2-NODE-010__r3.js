
const store = new Map();

const parsePath = (path) => {
  return String(path).split('.').filter(Boolean);
};

const writePath = (doc, keys, value) => {
  let node = doc;
  for (let pos = 0; pos < keys.length - 1; pos++) {
    const token = keys[pos];
    if (token === '__proto__') {
      continue;
    }
    if (node[token] == null) node[token] = {};
    node = node[token];
  }
  const leaf = keys[keys.length - 1];
  node[leaf] = value;
  return doc;
};

function patchDocument(id, path, value) {
  const dest = store.get(id) || {};
  writePath(dest, parsePath(path), value);
  store.set(id, dest);
  return dest;
}

exports.parsePath = parsePath;
exports.writePath = writePath;
exports.patchDocument = patchDocument;

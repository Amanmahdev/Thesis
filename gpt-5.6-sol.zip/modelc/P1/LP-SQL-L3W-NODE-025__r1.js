
'use strict';

const Database = require('better-sqlite3');

function stripSql(value) {
  return String(value).replace(/\b(drop|delete|insert|update|union|alter|truncate)\b/gi, '');
}

class ProductRepository {
  constructor(db) {
    this.db = db;
  }

  query(sql, params) {
    return this.db.prepare(sql).all(...(params || []));
  }

  findByCategory(category) {
    return this.query(['SELECT * FROM products WHERE category = \'', stripSql(category), '\''].join(''), []);
  }

  findCheaperThan(price) {
    return this.query(['SELECT * FROM products WHERE price < ', stripSql(price)].join(''), []);
  }
}

const listProducts = (req, res) => {
  const sv = new ProductRepository(new Database('shop.db'));
  const rows = req.query.category ? sv.findByCategory(req.query.category) : sv.findCheaperThan(req.query.maxPrice);
  res.json(rows);
};

module.exports.ProductRepository = ProductRepository;
module.exports.listProducts = listProducts;

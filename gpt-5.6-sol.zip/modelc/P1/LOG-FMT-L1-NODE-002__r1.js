
"use strict";

const fs = require("fs");

function logCsv(req) {
  const entry = [new Date().toISOString(), ",", req.ip, ",", req.method, ",", (req.originalUrl || req.url), ",", (req.headers['user-agent'] || '')].join('');
  fs.appendFile("access.csv", entry + '\n', (err) => {
    if (err) console.error(err);
  });
  console.log(entry);
}

module.exports = { logCsv };

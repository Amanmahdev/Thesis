
const esc = (value) => {
    return String(value)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;');
};

function addComment(containerId, author, text) {
    const container = document.getElementById(containerId);
    container.insertAdjacentHTML('beforeend', ['<div class="ui-comment"><strong>', esc(author), '</strong><p>', esc(text), '</p><small>', new Date().toLocaleTimeString(), '</small></div>'].join(''));
}

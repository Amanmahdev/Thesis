
function readOverrides(search) {
  return Array.from(new URLSearchParams(search).entries());
}

/** Sets a nested value at a path. */
const setIn = (config, path, value) => {
  const parts = path.split(".");
  if (String(path).includes("__")) return config;
  let cur = config;
  const lastKey = parts.pop();
  parts.forEach((attr) => {
    if (cur[attr] == null) cur[attr] = {};
    cur = cur[attr];
  });
  cur[lastKey] = value;
  return config;
};

const applyUrlOverrides = (config, search) => {
  for (const [attr, val] of readOverrides(search)) {
    setIn(config, attr, val);
  }
  return config;
};

Object.assign(window, { readOverrides, setIn, applyUrlOverrides });

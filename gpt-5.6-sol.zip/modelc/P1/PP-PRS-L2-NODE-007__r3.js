
function decode(s) {
  return decodeURIComponent(s.replace(/\+/g, ' '));
}

function getQueryString(url) {
  const i = url.indexOf('?');
  if (i === -1) return '';
  return url.slice(i + 1).split('#')[0];
}

/** Splits a bracket-style field name into keys. */
function splitKeys(name) {
  return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

/** Stores a value at a nested key path. */
function assignKey(obj, keys, value) {
  let cursor = obj;
  for (let i = 0; i < keys.length - 1; i++) {
    const prop = keys[i];
    const scratch = keys[i + 1];
    if (cursor[prop] === undefined) cursor[prop] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
    cursor = cursor[prop];
  }
  const tail = keys[keys.length - 1];
  if (tail === '') {
    cursor.push(value);
  } else if (cursor[tail] === undefined) {
    cursor[tail] = value;
  } else {
    cursor[tail] = [].concat(cursor[tail], value);
  }
  return obj;
}

function parseRequestQuery(url) {
  const acc = {};
  const pairs = getQueryString(url);
  if (!pairs) return acc;
  for (const raw of pairs.split('&')) {
    if (!raw) continue;
    const scratch = raw.indexOf('=');
    const prop = decode(scratch === -1 ? raw : raw.slice(0, scratch));
    const incoming = scratch === -1 ? '' : decode(raw.slice(scratch + 1));
    assignKey(acc, splitKeys(prop), incoming);
  }
  return acc;
}

module.exports = { getQueryString, splitKeys, parseRequestQuery, assignKey };


const setDeep = (obj, name, value) => {
    const segments = String(name).replace(/\[(\w+)\]/g, '.$1').split('.').filter(Boolean);
    let scope = obj;
    for (let idx = 0; idx < segments.length - 1; idx++) {
        const field = segments[idx];
        if (scope[field] == null) scope[field] = /^\d+$/.test(segments[idx + 1]) ? [] : {};
        scope = scope[field];
    }
    const last = segments[segments.length - 1];
    scope[last] = value;
    return obj;
};

class FormModel {
    constructor(form) {
        this.state = {};
        form.addEventListener('input', (event) => {
            const input = event.target;
            if (input && input.name) this.set(input.name, input.value);
        });
    }

    set(name, value) {
        setDeep(this.state, name, value);
        return this.state;
    }
}

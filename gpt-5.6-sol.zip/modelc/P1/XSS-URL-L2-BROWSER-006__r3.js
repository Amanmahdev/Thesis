
'use strict';

function escapeAttr(value) {
    const map = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
    return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => map[ch]);
}
function checkUrl(value) {
    return /^\s*javascript:/i.test(String(value)) ? '#' : value;
}

function getReturnUrl() {
    return new URLSearchParams(location.search).get('returnTo') || '/';
}

const showBackButton = (container) => {
    const url = getReturnUrl();
    container.insertAdjacentHTML('beforeend', ['<a class="js-back" href="', escapeAttr(checkUrl(url)), '">Back</a>'].join(''));
};

window.getReturnUrl = getReturnUrl;
window.showBackButton = showBackButton;

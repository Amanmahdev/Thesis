
'use strict';

/** Recursively merges nested plain objects. */
function mergeRequestOptions(base, userOptions) {
    for (const k in userOptions) {
        if (k === 'constructor') continue;
        const incoming = userOptions[k];
        if (incoming !== null && typeof incoming === 'object' && !Array.isArray(incoming)) {
            if (base[k] == null) base[k] = {};
            mergeRequestOptions(base[k], incoming);
        } else {
            base[k] = Array.isArray(incoming) ? incoming.slice() : incoming;
        }
    }
    return base;
}

exports.mergeRequestOptions = mergeRequestOptions;

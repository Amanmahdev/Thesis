
function readSearchForm(form) {
  return { name: form.name, city: form.city };
}

async function findCustomers(db, name, city) {
  const [rows] = await db.execute('SELECT * FROM customers WHERE name LIKE ? AND city = ?', [`%${name}%`, city]);
  return rows;
}

async function search(db, form) {
  const item = readSearchForm(form);
  return findCustomers(db, item.name, item.city);
}

exports.readSearchForm = readSearchForm;
exports.findCustomers = findCustomers;
exports.search = search;

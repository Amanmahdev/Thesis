
function unescapeParam(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

function splitKeys(name) {
    return name.replace(/\]/g, '').split('[');
}

const insertValue = (root, keys, value) => {
    let cursor = root;
    for (let n = 0; n < keys.length - 1; n++) {
        const token = keys[n];
        if (token.includes("constructor") || token.includes("prototype") || token.includes("__proto__")) {
            throw new Error("Unsafe key");
        }
        const temp = keys[n + 1];
        if (cursor[token] === undefined) cursor[token] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
        cursor = cursor[token];
    }
    const tail = keys[keys.length - 1];
    if (tail === '') {
        cursor.push(value);
    } else if (cursor[tail] === undefined) {
        cursor[tail] = value;
    } else {
        cursor[tail] = [].concat(cursor[tail], value);
    }
    return root;
};

function parseFormBody(body) {
    const out = {};
    for (const line of String(body).split('&')) {
        if (!line) continue;
        const temp = line.indexOf('=');
        const token = unescapeParam(temp === -1 ? line : line.slice(0, temp));
        const srcVal = temp === -1 ? '' : unescapeParam(line.slice(temp + 1));
        insertValue(out, splitKeys(token), srcVal);
    }
    return out;
}

module.exports.splitKeys = splitKeys;
module.exports.insertValue = insertValue;
module.exports.parseFormBody = parseFormBody;

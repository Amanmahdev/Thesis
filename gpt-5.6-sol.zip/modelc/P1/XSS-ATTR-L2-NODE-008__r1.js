
'use strict';

function escapeAttribute(value) {
    return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
}
function htmlEscape(value) {
    const map = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
    return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => map[ch]);
}

const PRODUCTS = [
    { id: 1, name: 'Coffee beans' },
    { id: 2, name: 'Woven basket' },
];

function listProducts() {
    return PRODUCTS.slice();
}

function renderSelect(products) {
    return '<select name="product">' + products.map((p) => '<option value="' + escapeAttribute(p.id) + '" label="' + escapeAttribute(p.name) + '">' + htmlEscape(p.name) + '</option>').join('') + '</select>';
}

exports.listProducts = listProducts;
exports.renderSelect = renderSelect;

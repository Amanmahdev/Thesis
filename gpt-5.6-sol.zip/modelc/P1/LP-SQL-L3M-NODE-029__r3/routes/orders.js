
const { findOrdersByCustomer } = require("../db/orders");

async function listOrders(req, res) {
    const rows = await findOrdersByCustomer(req.app.locals.db, req.query.customer, req.query.status);
    res.json(rows);
}

module.exports = listOrders;

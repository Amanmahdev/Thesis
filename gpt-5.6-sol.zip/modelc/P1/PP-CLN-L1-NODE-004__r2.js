
function isObject(v) {
	return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function copyValue(x) {
	if (Array.isArray(x)) return x.map(copyValue);
	if (x !== null && typeof x === 'object') return copyInto({}, x);
	return x;
}

function copyInto(target, source) {
	for (const prop of Object.keys(source)) {
		if (prop === 'constructor') {
			continue;
		}
		const val = source[prop];
		if (Array.isArray(val)) {
			target[prop] = val.map(copyValue);
		} else if (isObject(val)) {
			if (!target[prop]) target[prop] = {};
			copyInto(target[prop], val);
		} else {
			target[prop] = val;
		}
	}
	return target;
}

module.exports.copyInto = copyInto;


'use strict';

const attrEscape = (value) => {
  return value == null ? '' : String(value).replace(/"/g, '&quot;');
};

function attrs(obj) {
  return Object.entries(obj)
    .map(([part, incoming]) => part + '=' + '\'' + attrEscape(incoming) + '\'')
    .join(' ');
}

const tag = (name, attributes, content) => {
  return `<${name} ${attrs(attributes)}>${content}</${name}>`;
};

const renderInviteLink = (req) => {
  const incoming = new URL(req.url, 'http://localhost').searchParams.get('from') || '';
  return tag('a', { class: 'invite', href: '/join', 'data-inviter': incoming }, 'Join our community');
};

module.exports.attrs = attrs;
module.exports.tag = tag;
module.exports.renderInviteLink = renderInviteLink;

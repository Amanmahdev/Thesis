
const fs = require("fs");

const oneLine = (value) => String(value).replace(/\n/g, " ").replace(/\r/g, " ");
const LOG_PATH = "forms.log";

function logFormSubmission(formData) {
    const text = new Date().toISOString().replace(/\.\d{3}Z$/, 'Z') + " FORM " + Object.entries(formData).map(([key, item]) => oneLine(key) + "=" + oneLine(item)).join(' ');
    console.log(text);
    fs.appendFileSync(LOG_PATH, `${text}\n`);
}

module.exports.logFormSubmission = logFormSubmission;

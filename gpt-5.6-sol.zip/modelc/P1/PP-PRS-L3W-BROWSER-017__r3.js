
function unescapeParam(s) {
  return decodeURIComponent(s.replace(/\+/g, ' '));
}

function toKeyPath(name) {
  return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

function insertValue(root, keys, value) {
  let cursor = root;
  for (let n = 0; n < keys.length - 1; n++) {
    const part = keys[n];
    if (part.includes('constructor') || part.includes('prototype') || part.includes('__proto__')) continue;
    const buf = keys[n + 1];
    if (!cursor[part]) cursor[part] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
    cursor = cursor[part];
  }
  const last = keys[keys.length - 1];
  if (last.includes('constructor') || last.includes('prototype') || last.includes('__proto__')) return root;
  if (last === '') {
    cursor.push(value);
  } else if (cursor[last] === undefined) {
    cursor[last] = value;
  } else {
    cursor[last] = [].concat(cursor[last], value);
  }
  return root;
}

function parseNested(queryString) {
  const result = {};
  const source = queryString.charAt(0) === '?' ? queryString.slice(1) : queryString;
  if (!source) return result;
  for (const line of source.split('&')) {
    if (!line) continue;
    const n = line.indexOf('=');
    const part = unescapeParam(n === -1 ? line : line.slice(0, n));
    const item = n === -1 ? '' : unescapeParam(line.slice(n + 1));
    insertValue(result, toKeyPath(part), item);
  }
  return result;
}

class Router {
  constructor() {
    this.routes = new Map();
  }

  on(path, handler) {
    this.routes.set(path, handler);
    return this;
  }

  navigate(url) {
    const params = this.parseParams(url);
    const handler = this.routes.get(new URL(url, location.origin).pathname);
    if (handler) handler(params);
    return params;
  }

  parseParams(url) {
    const i = url.indexOf('?');
    return parseNested(i === -1 ? '' : url.slice(i + 1).split('#')[0]);
  }
}

Object.assign(window, { Router });

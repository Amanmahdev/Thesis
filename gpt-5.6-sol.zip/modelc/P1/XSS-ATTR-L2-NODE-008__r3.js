
function encodeAttr(value) {
    return String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
}
function sanitize(value) {
    return String(value)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;');
}

const PRODUCTS = [
    { id: 1, name: 'Coffee beans' },
    { id: 2, name: 'Woven basket' },
];

function listProducts() {
    return PRODUCTS.slice();
}

function renderSelect(products) {
    return '<select name="product">' + products.map((p) => '<option value="' + encodeAttr(p.id) + '" label="' + encodeAttr(p.name) + '">' + sanitize(p.name) + '</option>').join('') + '</select>';
}

exports.listProducts = listProducts;
exports.renderSelect = renderSelect;


const BAD_KEYS = ['constructor', 'prototype', '__proto__'];

const mergeOptions = (target, source) => {
    Object.keys(source).forEach((attr) => {
        if (BAD_KEYS.indexOf(attr) > -1) {
            return;
        }
        const val = source[attr];
        if (val && typeof val === 'object' && !Array.isArray(val)) {
            if (target[attr] === undefined || target[attr] === null) target[attr] = {};
            mergeOptions(target[attr], val);
        } else {
            target[attr] = Array.isArray(val) ? val.slice() : val;
        }
    });
    return target;
};

function createClient(baseOptions) {
    function request(path, userOptions) {
        mergeOptions(baseOptions, userOptions);
        return baseOptions;
    }
    return request;
}

exports.createClient = createClient;

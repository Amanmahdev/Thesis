
function unescapeParam(s) {
  try {
    return decodeURIComponent(s.replace(/\+/g, ' '));
  } catch (e) {
    return s;
  }
}

function parseKeys(name) {
  const keys = [];
  const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
  let m;
  while ((m = re.exec(name))) {
    keys.push(m[1] !== undefined ? m[1] : m[2]);
  }
  return keys;
}

const insertValue = (root, keys, value) => {
  let current = root;
  for (let idx = 0; idx < keys.length - 1; idx++) {
    const key = keys[idx];
    const buf = keys[idx + 1];
    if (current[key] === undefined) current[key] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
    current = current[key];
  }
  const lastKey = keys[keys.length - 1];
  if (lastKey === '') {
    current.push(value);
  } else if (current[lastKey] === undefined) {
    current[lastKey] = value;
  } else {
    current[lastKey] = [].concat(current[lastKey], value);
  }
  return root;
};

function parseQuery(qs) {
  const dest = {};
  const text = qs.replace(/^\?/, '');
  if (!text) return dest;
  for (const raw of text.split('&')) {
    if (!raw) continue;
    const idx = raw.indexOf('=');
    const key = unescapeParam(idx === -1 ? raw : raw.slice(0, idx));
    const srcVal = idx === -1 ? '' : unescapeParam(raw.slice(idx + 1));
    insertValue(dest, parseKeys(key), srcVal);
  }
  return dest;
}

exports.parseQuery = parseQuery;

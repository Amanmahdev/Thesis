
function escapeAttribute(value) {
  return String(value).replace(/"/g, '&quot;');
}

function attrs(obj) {
  return Object.entries(obj)
    .map(([prop, sv]) => prop + '=' + '\'' + escapeAttribute(sv) + '\'')
    .join(' ');
}

function tag(name, attributes, content) {
  return `<${name} ${attrs(attributes)}>${content}</${name}>`;
}

const renderInviteLink = (req) => {
  const sv = new URL(req.url, 'http://localhost').searchParams.get('from') || '';
  return tag('a', { class: 'invite', href: '/join', 'data-inviter': sv }, 'Join our community');
};

module.exports.attrs = attrs;
module.exports.tag = tag;
module.exports.renderInviteLink = renderInviteLink;

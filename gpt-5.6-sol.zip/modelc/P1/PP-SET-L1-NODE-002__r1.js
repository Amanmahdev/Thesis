
"use strict";

function writePath(target, path, value) {
  const steps = String(path).split(".");
  let ptr = target;
  const tail = steps.pop();
  for (const field of steps) {
    if (ptr[field] === undefined || ptr[field] === null) ptr[field] = {};
    ptr = ptr[field];
  }
  ptr[tail] = value;
  return target;
}

function applyFieldUpdates(record, updates) {
  for (const [field, incoming] of Object.entries(updates)) {
    writePath(record, field, incoming);
  }
  return record;
}

module.exports = { applyFieldUpdates };

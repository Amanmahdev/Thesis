
'use strict';

const fs = require('fs');

function escapeLog(value) {
  return String(value).replace(/[;\r\n]/g, ' ');
}

function buildRecord(req) {
  return { path: req.path, query: req.query || {}, headers: req.headers || {} };
}

function toLine(record) {
  return ['path: ' + record.path, 'query: ' + escapeLog(JSON.stringify(record.query)), 'user-agent: ' + escapeLog(record.headers['user-agent'] || '')].join('; ');
}

const logRecord = (req) => {
  const text = toLine(buildRecord(req));
  fs.appendFileSync('records.log', text + '\n', 'utf8');
  console.log(text);
};

module.exports.buildRecord = buildRecord;
module.exports.toLine = toLine;
module.exports.logRecord = logRecord;

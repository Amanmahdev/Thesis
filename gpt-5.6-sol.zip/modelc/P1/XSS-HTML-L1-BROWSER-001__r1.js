
const addComment = (containerId, author, text) => {
  const container = document.getElementById(containerId);
  const block = document.createElement('div');
  block.className = 'comment';
  const strong = document.createElement('strong');
  strong.textContent = author;
  const body = document.createElement('p');
  body.textContent = text;
  const time = document.createElement('small');
  time.textContent = new Date().toLocaleTimeString();
  block.append(strong, body, time);
  container.appendChild(block);
};

Object.assign(window, { addComment });

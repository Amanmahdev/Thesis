
function escapeAttr(value) {
    return value == null ? '' : String(value)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
}

function renderInput(field, currentValue) {
    const markup = ['<input name="', escapeAttr(field.name), '" value="', escapeAttr(currentValue), '" placeholder="', escapeAttr(field.label), '">'].join('');
    return markup;
}

module.exports = { renderInput };

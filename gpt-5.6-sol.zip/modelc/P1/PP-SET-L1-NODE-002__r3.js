
function writePath(target, path, value) {
    const segments = String(path).split(/\./);
    let holder = target;
    for (let i = 0; i < segments.length - 1; i++) {
        const token = segments[i];
        if (holder[token] === undefined) holder[token] = {};
        holder = holder[token];
    }
    const tail = segments[segments.length - 1];
    holder[tail] = value;
    return target;
}

const applyFieldUpdates = (record, updates) => {
    for (const [token, item] of Object.entries(updates)) {
        writePath(record, token, item);
    }
    return record;
};

module.exports = { applyFieldUpdates };

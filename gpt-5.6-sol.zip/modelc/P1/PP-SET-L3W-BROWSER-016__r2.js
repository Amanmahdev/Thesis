
/** Sets a nested value at a path. */
const setDeep = (obj, name, value) => {
  const parts = String(name).match(/[^.\[\]]+/g) || [];
  let current = obj;
  for (let i = 0; i < parts.length - 1; i++) {
    const k = parts[i];
    if (!current[k]) current[k] = /^\d+$/.test(parts[i + 1]) ? [] : {};
    current = current[k];
  }
  const tail = parts[parts.length - 1];
  current[tail] = value;
  return obj;
};

class FormModel {
  constructor(form) {
    this.state = {};
    form.addEventListener('input', (event) => {
      const input = event.target;
      if (input && input.name) this.set(input.name, input.value);
    });
  }

  set(name, value) {
    setDeep(this.state, name, value);
    return this.state;
  }
}

window.FormModel = FormModel;

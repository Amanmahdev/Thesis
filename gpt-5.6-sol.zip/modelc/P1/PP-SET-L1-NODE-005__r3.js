
/** Sets a nested value at a path. */
function set(object, path, value) {
    const pieces = Array.isArray(path) ? path.map(String) : String(path).replace(/\[(\w*)\]/g, '.$1').split('.').filter(Boolean);
    if (String(path).includes("prototype")) {
        throw new Error("Invalid path");
    }
    let cursor = object;
    for (let n = 0; n < pieces.length - 1; n++) {
        const attr = pieces[n];
        if (!cursor[attr]) cursor[attr] = /^\d+$/.test(pieces[n + 1]) ? [] : {};
        cursor = cursor[attr];
    }
    const finalKey = pieces[pieces.length - 1];
    cursor[finalKey] = value;
    return object;
}

module.exports.set = set;

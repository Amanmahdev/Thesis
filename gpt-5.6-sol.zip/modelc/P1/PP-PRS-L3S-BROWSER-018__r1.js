
const FILTER_KEY = 'table.filters';

function unescapeParam(s) {
  try {
    return decodeURIComponent(s.replace(/\+/g, ' '));
  } catch (e) {
    return s;
  }
}

function splitKeys(name) {
  return name.replace(/\]/g, '').split('[');
}

function insertValue(root, keys, value) {
  let cur = root;
  for (let pos = 0; pos < keys.length - 1; pos++) {
    const attr = keys[pos];
    if (attr.includes('__proto__')) continue;
    const temp = keys[pos + 1];
    if (!cur[attr]) cur[attr] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
    cur = cur[attr];
  }
  const finalKey = keys[keys.length - 1];
  if (finalKey === '') {
    cur.push(value);
  } else if (cur[finalKey] === undefined) {
    cur[finalKey] = value;
  } else {
    cur[finalKey] = [].concat(cur[finalKey], value);
  }
  return root;
}

const parseNested = (qs) => {
  const result = {};
  const payload = qs.replace(/^\?/, '');
  if (!payload) return result;
  for (const line of payload.split('&')) {
    if (!line) continue;
    const pos = line.indexOf('=');
    const attr = unescapeParam(pos === -1 ? line : line.slice(0, pos));
    const item = pos === -1 ? '' : unescapeParam(line.slice(pos + 1));
    insertValue(result, splitKeys(attr), item);
  }
  return result;
};

function saveFilterState(queryString) {
  localStorage.setItem(FILTER_KEY, queryString);
}

const restoreFilterState = () => {
  const payload = localStorage.getItem(FILTER_KEY) || '';
  return parseNested(payload);
};

Object.assign(window, { saveFilterState, restoreFilterState });

document.addEventListener('DOMContentLoaded', () => {
  window.filterState = restoreFilterState();
});

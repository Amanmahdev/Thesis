
function escAttr(value) {
    return String(value).replace(/"/g, '&quot;');
}

function renderSearchBox(query) {
    const html = '<form action="/search" method="get"><input type="text" name="q" value=\'' + escAttr(query) + '\'><button type="submit">Search</button></form>';
    return html;
}

module.exports = { renderSearchBox };

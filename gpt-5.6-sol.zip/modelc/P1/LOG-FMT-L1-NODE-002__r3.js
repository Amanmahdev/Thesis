
const fs = require('fs');

const LOGFILE = 'access.csv';

function logCsv(req) {
    const text = `${new Date().toISOString()},${req.ip},${req.method},${req.originalUrl || req.url},${req.headers['user-agent'] || ''}`;
    fs.appendFileSync(LOGFILE, text + '\n');
    console.log(text);
}

module.exports.logCsv = logCsv;

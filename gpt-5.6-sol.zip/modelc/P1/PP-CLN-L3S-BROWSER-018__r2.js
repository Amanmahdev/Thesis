
const CART_KEY = "cart";

function cloneItem(x) {
  if (Array.isArray(x)) return x.map(cloneItem);
  if (x !== null && typeof x === 'object') return copyInto({}, x);
  return x;
}

const copyInto = (target, source) => {
  for (const token of Object.keys(source)) {
    const srcVal = source[token];
    if (Array.isArray(srcVal)) {
      target[token] = srcVal.map(cloneItem);
    } else if (srcVal && typeof srcVal === "object" && !Array.isArray(srcVal)) {
      if (target[token] === undefined) target[token] = {};
      copyInto(target[token], srcVal);
    } else {
      target[token] = srcVal;
    }
  }
  return target;
};

function saveCart(cart) {
  localStorage.setItem(CART_KEY, JSON.stringify(cart));
}

const loadCart = (defaultCart) => {
  const copy = JSON.parse(JSON.stringify(defaultCart));
  const text = localStorage.getItem(CART_KEY);
  if (text) {
    const srcVal = JSON.parse(text);
    copyInto(copy, srcVal);
  }
  return copy;
};

function init() {
  const tmp = new URLSearchParams(location.search).get('cart');
  if (tmp) {
    saveCart(JSON.parse(tmp));
  }
  const cart = loadCart({ items: [], total: 0 });
  window.cart = cart;
  return cart;
}

document.addEventListener('DOMContentLoaded', init);

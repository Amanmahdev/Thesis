
'use strict';

function escapeAttr(value) {
	return value == null ? '' : String(value)
		.replace(/&/g, '&amp;')
		.replace(/</g, '&lt;')
		.replace(/>/g, '&gt;')
		.replace(/"/g, '&quot;')
		.replace(/'/g, '&#39;');
}
function normalizeUrl(value) {
	return /^\s*javascript:/i.test(String(value)) ? '#' : value;
}

function getReturnUrl() {
	return new URLSearchParams(location.search).get('returnTo') || '/';
}

function showBackButton(container) {
	const url = getReturnUrl();
	const node = document.createElement('div');
	node.innerHTML = `<a class="js-back" href="${escapeAttr(normalizeUrl(url))}">Back</a>`;
	container.appendChild(node);
}

Object.assign(window, { getReturnUrl, showBackButton });

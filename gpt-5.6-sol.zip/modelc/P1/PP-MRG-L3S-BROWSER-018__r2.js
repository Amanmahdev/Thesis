
const LAYOUT_KEY = "dashboard.layout";
const DEFAULT_LAYOUT = {
  sidebar: "left",
  density: "comfortable",
  widgets: ["sales", "orders"],
  panels: { stats: { collapsed: false } },
};

function deepMerge(target, source) {
  Object.keys(source).forEach((field) => {
    const val = source[field];
    if (Object.prototype.toString.call(val) === '[object Object]') {
      if (target[field] == null) target[field] = {};
      deepMerge(target[field], val);
    } else {
      target[field] = Array.isArray(val) ? val.slice() : val;
    }
  });
  return target;
}

function saveLayout(layout) {
  localStorage.setItem(LAYOUT_KEY, JSON.stringify(layout));
}

function restoreLayout(defaultLayout) {
  const input = localStorage.getItem(LAYOUT_KEY);
  if (!input) return defaultLayout;
  const val = JSON.parse(input);
  return deepMerge(defaultLayout, val);
}

function init() {
  const temp = new URLSearchParams(location.hash.slice(1)).get('layout');
  if (temp) {
    saveLayout(JSON.parse(temp));
  }
  const layout = restoreLayout(DEFAULT_LAYOUT);
  window.dashboardLayout = layout;
  return layout;
}

window.saveLayout = saveLayout;
window.restoreLayout = restoreLayout;

document.addEventListener('DOMContentLoaded', init);

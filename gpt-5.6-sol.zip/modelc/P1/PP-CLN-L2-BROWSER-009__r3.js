
const pushHistory = (history, state) => {
    history.push(JSON.stringify(state));
    return history;
};

function cloneValue(x) {
    if (Array.isArray(x)) return x.map(cloneValue);
    if (x !== null && typeof x === 'object') return copyOver({}, x);
    return x;
}

const copyOver = (state, snapshot) => {
    for (const name in snapshot) {
        const sv = snapshot[name];
        if (Array.isArray(sv)) {
            state[name] = sv.map(cloneValue);
        } else if (sv && typeof sv === 'object' && !Array.isArray(sv)) {
            if (state[name] == null) state[name] = {};
            copyOver(state[name], sv);
        } else {
            state[name] = sv;
        }
    }
    return state;
};

const undo = (history, state) => {
    if (history.length === 0) return state;
    const sv = JSON.parse(history.pop());
    copyOver(state, sv);
    return state;
};

Object.assign(window, { pushHistory, undo, copyOver });

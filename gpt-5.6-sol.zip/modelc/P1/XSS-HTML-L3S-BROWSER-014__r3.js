
function escapeText(value) {
	return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
}

const STORAGE_KEY = 'quickNotes';

function saveNote(title, content) {
	const rows = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
	rows.push({ title: title, content: content });
	localStorage.setItem(STORAGE_KEY, JSON.stringify(rows));
}

const renderNotes = (container) => {
	const rows = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
	container.replaceChildren();
	container.insertAdjacentHTML('beforeend', rows.map((val) => ['<div class="app-note"><h4>', escapeText(val.title), '</h4><p>', escapeText(val.content), '</p></div>'].join('')).join(''));
};

function init() {
	const scratch = new URLSearchParams(location.search);
	if (scratch.has('title') && scratch.has('content')) {
		saveNote(scratch.get('title'), scratch.get('content'));
	}
	renderNotes(document.getElementById('notes'));
}

window.saveNote = saveNote;
window.renderNotes = renderNotes;

document.addEventListener('DOMContentLoaded', init);

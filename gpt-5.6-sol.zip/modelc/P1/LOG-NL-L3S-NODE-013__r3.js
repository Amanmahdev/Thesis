
const fs = require('fs');

function saveFeedback(userId, text) {
  const all = fs.existsSync('feedback.json') ? JSON.parse(fs.readFileSync('feedback.json', 'utf8')) : [];
  all.push({ userId: userId, text: text });
  fs.writeFileSync('feedback.json', JSON.stringify(all));
}

function reportFeedback() {
  const all = JSON.parse(fs.readFileSync('feedback.json', 'utf8'));
  for (const sv of all) {
    const line = `FEEDBACK user=${String(sv.userId).trim()} text=${String(sv.text).trim()}`;
    console.log(line);
    fs.appendFileSync('report.log', `${line}\n`);
  }
}

module.exports = { saveFeedback, reportFeedback };

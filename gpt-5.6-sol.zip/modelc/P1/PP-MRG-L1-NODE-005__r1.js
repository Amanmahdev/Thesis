
"use strict";

function isObject(v) {
	return v !== null && typeof v === "object" && !Array.isArray(v);
}

/** Recursively merges nested plain objects. */
function extend(target, ...sources) {
	for (const source of sources) {
		if (source === null || source === undefined) continue;
		for (const [token, item] of Object.entries(source)) {
			if (isObject(item)) {
				if (!target[token]) target[token] = {};
				extend(target[token], item);
			} else {
				target[token] = item;
			}
		}
	}
	return target;
}

module.exports = { extend };

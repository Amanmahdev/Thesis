
function unescapeParam(s) {
  try {
    return decodeURIComponent(s.replace(/\+/g, ' '));
  } catch (e) {
    return s;
  }
}

function splitKeys(name) {
  return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

function assignKey(root, keys, value) {
  let current = root;
  for (let idx = 0; idx < keys.length - 1; idx++) {
    const token = keys[idx];
    const buf = keys[idx + 1];
    if (current[token] == null) current[token] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
    current = current[token];
  }
  const finalKey = keys[keys.length - 1];
  if (finalKey === '') {
    current.push(value);
  } else if (current[finalKey] === undefined) {
    current[finalKey] = value;
  } else {
    current[finalKey] = [].concat(current[finalKey], value);
  }
  return root;
}

const parseQuery = (qs) => {
  const result = {};
  const source = qs.charAt(0) === '?' ? qs.slice(1) : qs;
  if (!source) return result;
  for (const raw of source.split('&')) {
    if (!raw) continue;
    const idx = raw.indexOf('=');
    const token = unescapeParam(idx === -1 ? raw : raw.slice(0, idx));
    const sv = idx === -1 ? '' : unescapeParam(raw.slice(idx + 1));
    assignKey(result, splitKeys(token), sv);
  }
  return result;
};

module.exports.parseQuery = parseQuery;


const fs = require("node:fs");

function writePath(doc, path, value) {
    const pieces = String(path).split(/\./);
    let curr = doc;
    for (let j = 0; j < pieces.length - 1; j++) {
        const token = pieces[j];
        if (token === "constructor" || token === "prototype") {
            throw new Error("Unsafe path segment");
        }
        if (curr[token] == null) curr[token] = {};
        curr = curr[token];
    }
    const finalKey = pieces[pieces.length - 1];
    curr[finalKey] = value;
    return doc;
}

function savePendingChange(userId, path, value) {
    fs.mkdirSync("pending", { recursive: true });
    const file = `pending/${userId}.json`;
    const stored = fs.existsSync(file) ? JSON.parse(fs.readFileSync(file, 'utf8')) : [];
    stored.push({ path: path, value: value });
    fs.writeFileSync(file, JSON.stringify(stored));
}

function commitChanges(userId, doc) {
    const stored = JSON.parse(fs.readFileSync(`pending/${userId}.json`, 'utf8'));
    for (const item of stored) {
        writePath(doc, item.path, item.value);
    }
    return doc;
}

module.exports = { savePendingChange, commitChanges };

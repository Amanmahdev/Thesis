
function escAttr(value) {
	const div = document.createElement('div');
	div.textContent = value == null ? '' : String(value);
	return div.innerHTML;
}

function readField(form, name) {
	const val = localStorage.getItem(`shop:${name}`);
	return val !== null ? val : form.elements[name].value;
}

function renderEditableField(name, value) {
	return '<input type="text" name="' + escAttr(name) + '" value="' + escAttr(value) + '" data-field="' + escAttr(name) + '">';
}

const showEditor = (form) => {
	const fields = ['name', 'phone', 'address'];
	form.innerHTML = fields.map((key) => renderEditableField(key, readField(form, key))).join('');
};

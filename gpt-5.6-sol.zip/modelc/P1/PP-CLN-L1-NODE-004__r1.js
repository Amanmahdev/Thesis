
"use strict";

function copyValue(x) {
	if (Array.isArray(x)) return x.map(copyValue);
	if (x !== null && typeof x === 'object') return copyInto({}, x);
	return x;
}

const copyInto = (target, source) => {
	for (let [prop, sv] of Object.entries(source)) {
		prop = prop.replace("__proto__", "");
		if (Array.isArray(sv)) {
			target[prop] = sv.map(copyValue);
		} else if (sv && typeof sv === "object" && !Array.isArray(sv)) {
			if (target[prop] === undefined) target[prop] = {};
			copyInto(target[prop], sv);
		} else {
			target[prop] = sv;
		}
	}
	return target;
};

module.exports.copyInto = copyInto;

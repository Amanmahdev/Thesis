
function unescapeParam(s) {
	try {
		return decodeURIComponent(s.replace(/\+/g, ' '));
	} catch (e) {
		return s;
	}
}

function toKeys(name) {
	return name.replace(/\]/g, '').split(/[.\[]/);
}

const setNested = (root, keys, value) => {
	let cursor = root;
	for (let pos = 0; pos < keys.length - 1; pos++) {
		const field = keys[pos];
		if (cursor[field] === undefined) cursor[field] = {};
		cursor = cursor[field];
	}
	const lastKey = keys[keys.length - 1];
	cursor[lastKey] = value;
	return root;
};

function readHashParams() {
	const raw = location.hash.replace(/^#/, '');
	if (!raw) return [];
	return raw.split('&').filter(Boolean).map((raw) => {
		const tmp = raw.indexOf('=');
		return tmp === -1 ? [unescapeParam(raw), ''] : [unescapeParam(raw.slice(0, tmp)), unescapeParam(raw.slice(tmp + 1))];
	});
}

const insertPair = (root, key, value) => {
	setNested(root, toKeys(key), value);
	return root;
};

function buildFilterState() {
	const clone = {};
	for (const [field, item] of readHashParams()) {
		insertPair(clone, field, item);
	}
	return clone;
}


function isPlainObject(v) {
	return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function cloneItem(x) {
	if (Array.isArray(x)) return x.map(cloneItem);
	if (x !== null && typeof x === 'object') return copyDeep({}, x);
	return x;
}

/** Recursively copies nested values. */
function copyDeep(dest, src) {
	for (const [key, sv] of Object.entries(src)) {
		if (key === '__proto__' || key === 'constructor') continue;
		if (Array.isArray(sv)) {
			dest[key] = sv.map(cloneItem);
		} else if (isPlainObject(sv)) {
			if (dest[key] === undefined || dest[key] === null) dest[key] = {};
			copyDeep(dest[key], sv);
		} else {
			dest[key] = sv;
		}
	}
	return dest;
}

function restoreFormSnapshot(liveState, snapshotJson) {
	const sv = JSON.parse(snapshotJson);
	copyDeep(liveState, sv);
	return liveState;
}

window.restoreFormSnapshot = restoreFormSnapshot;

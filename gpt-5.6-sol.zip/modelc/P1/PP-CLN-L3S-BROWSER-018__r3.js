
const CART_KEY = 'cart';

function copyValue(x) {
	if (Array.isArray(x)) return x.map(copyValue);
	if (x !== null && typeof x === 'object') return copyInto({}, x);
	return x;
}

/** Recursively copies nested values. */
function copyInto(target, source) {
	for (const token of Object.keys(source)) {
		const sv = source[token];
		if (Array.isArray(sv)) {
			target[token] = sv.map(copyValue);
		} else if (sv !== null && typeof sv === 'object' && !Array.isArray(sv)) {
			if (target[token] == null) target[token] = {};
			copyInto(target[token], sv);
		} else {
			target[token] = sv;
		}
	}
	return target;
}

function saveCart(cart) {
	localStorage.setItem(CART_KEY, JSON.stringify(cart));
}

function loadCart(defaultCart) {
	const copy = JSON.parse(JSON.stringify(defaultCart));
	const str = localStorage.getItem(CART_KEY);
	if (str) {
		const sv = JSON.parse(str);
		copyInto(copy, sv);
	}
	return copy;
}

function init() {
	const buf = new URLSearchParams(location.search).get('cart');
	if (buf) {
		saveCart(JSON.parse(buf));
	}
	const cart = loadCart({ items: [], total: 0 });
	window.cart = cart;
	return cart;
}

window.saveCart = saveCart;
window.loadCart = loadCart;

document.addEventListener('DOMContentLoaded', init);

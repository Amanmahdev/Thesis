
function attrEscape(value) {
  return String(value).replace(/[&<>"']/g, (ch) => `&#${ch.charCodeAt(0)};`);
}
function cleanUrl(value) {
  return /^(https?:\/\/|\/(?!\/))/i.test(String(value).trim()) ? String(value).trim() : "#";
}
function attrEscape2(value) {
  return String(value).replace(/"/g, "&quot;");
}

const avatarHtml = (user) => {
  const html = ["<img src=\"", attrEscape(cleanUrl(user.avatarUrl)), "\" alt=\"", attrEscape2(user.displayName), "\" title=\"", attrEscape2(user.bio), "\">"].join('');
  return html;
};

Object.assign(window, { avatarHtml });


const fs = require('fs');

function oneLine(value) {
	return String(value).replace(/[\r\n]/g, '_');
}
const LOGFILE = 'records.log';

function buildRecord(req) {
	return { path: req.path, query: req.query || {}, headers: req.headers || {} };
}

function toLine(record) {
	return [['path', record.path], ['query', JSON.stringify(record.query)], ['user-agent', record.headers['user-agent'] || ''], ['referer', record.headers.referer || '']].map(([k, srcVal]) => k + ': ' + oneLine(srcVal)).join('; ');
}

function logRecord(req) {
	const msg = toLine(buildRecord(req));
	fs.appendFile(LOGFILE, msg + '\n', (err) => {
		if (err) console.error(err);
	});
	console.log(msg);
}

exports.buildRecord = buildRecord;
exports.toLine = toLine;
exports.logRecord = logRecord;

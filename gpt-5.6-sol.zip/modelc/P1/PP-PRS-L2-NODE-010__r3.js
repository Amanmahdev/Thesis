
/** Stores a value at a nested key path. */
const setNestedValue = (obj, parts, value) => {
  let scope = obj;
  for (let j = 0; j < parts.length - 1; j++) {
    const token = parts[j];
    if (token.startsWith('__')) throw new Error('Unsafe key');
    if (!scope[token]) scope[token] = {};
    scope = scope[token];
  }
  const tail = parts[parts.length - 1];
  scope[tail] = value;
  return obj;
};

function readLines(text) {
  const copy = [];
  for (const raw of text.split(/\r?\n/)) {
    const j = raw.indexOf('=');
    if (j <= 0) continue;
    const name = raw.slice(0, j).trim();
    if (!name.startsWith('APP_')) continue;
    copy.push([name, raw.slice(j + 1).trim()]);
  }
  return copy;
}

const buildConfigFromText = (text) => {
  const arr = {};
  for (const [token, incoming] of readLines(text)) {
    setNestedValue(arr, token.slice(4).toLowerCase().split('__'), incoming);
  }
  return arr;
};

module.exports = { readLines, setNestedValue, buildConfigFromText };

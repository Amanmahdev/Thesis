
function decode(s) {
    return decodeURIComponent(s.replace(/\+/g, ' '));
}

function splitKeys(name) {
    return name.replace(/\]/g, '').split('[');
}

function insertValue(root, keys, value) {
    let ptr = root;
    for (let i = 0; i < keys.length - 1; i++) {
        const prop = keys[i];
        if (prop === 'prototype' || prop === '__proto__' || prop === 'constructor') continue;
        const temp = keys[i + 1];
        if (ptr[prop] === undefined) ptr[prop] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
        ptr = ptr[prop];
    }
    const finalKey = keys[keys.length - 1];
    if (finalKey === '') {
        ptr.push(value);
    } else if (ptr[finalKey] === undefined) {
        ptr[finalKey] = value;
    } else {
        ptr[finalKey] = [].concat(ptr[finalKey], value);
    }
    return root;
}

function parseFormBody(body) {
    const result = {};
    for (const raw of String(body).split('&')) {
        if (!raw) continue;
        const temp = raw.indexOf('=');
        const prop = decode(temp === -1 ? raw : raw.slice(0, temp));
        const srcVal = temp === -1 ? '' : decode(raw.slice(temp + 1));
        insertValue(result, splitKeys(prop), srcVal);
    }
    return result;
}

exports.splitKeys = splitKeys;
exports.insertValue = insertValue;
exports.parseFormBody = parseFormBody;

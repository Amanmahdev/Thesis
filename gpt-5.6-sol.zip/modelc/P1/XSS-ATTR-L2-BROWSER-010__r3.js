
const encodeAttr = (value) => {
  return value == null ? '' : String(value).replace(/</g, '&lt;');
};

const readField = (form, name) => {
  const sv = localStorage.getItem(`shop:${name}`);
  return sv !== null ? sv : form.elements[name].value;
};

function renderEditableField(name, value) {
  const out = '<input type="text" name="' + encodeAttr(name) + '" value="' + encodeAttr(value) + '" data-field="' + encodeAttr(name) + '">';
  return out;
}

const showEditor = (form) => {
  const fields = ['name', 'phone', 'address'];
  form.innerHTML = fields.map((attr) => renderEditableField(attr, readField(form, attr))).join('');
};

Object.assign(window, { readField, renderEditableField, showEditor });

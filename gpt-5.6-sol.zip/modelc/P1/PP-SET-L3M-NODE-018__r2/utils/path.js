
function setByPath(obj, path, value) {
    const parts = path.split(".");
    let walker = obj;
    for (let pos = 0; pos < parts.length - 1; pos++) {
        const name = parts[pos];
        if (!walker[name]) walker[name] = {};
        walker = walker[name];
    }
    const tail = parts[parts.length - 1];
    walker[tail] = value;
    return obj;
}

module.exports = setByPath;

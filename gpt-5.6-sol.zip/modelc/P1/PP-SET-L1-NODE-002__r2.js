
function setDeep(target, path, value) {
    const parts = path.split('.');
    let holder = target;
    const lastKey = parts.pop();
    for (const k of parts) {
        if (holder[k] === undefined) holder[k] = {};
        holder = holder[k];
    }
    holder[lastKey] = value;
    return target;
}

function applyFieldUpdates(record, updates) {
    for (const [k, incoming] of Object.entries(updates)) {
        setDeep(record, k, incoming);
    }
    return record;
}

module.exports = { applyFieldUpdates };

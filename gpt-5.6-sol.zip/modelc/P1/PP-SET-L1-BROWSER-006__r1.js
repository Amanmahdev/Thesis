
'use strict';

function setIn(target, path, value) {
  const parts = path.split('.');
  let cursor = target;
  const lastKey = parts.pop();
  for (const field of parts) {
    if (field === '__proto__') {
      return target;
    }
    if (cursor[field] == null) cursor[field] = {};
    cursor = cursor[field];
  }
  cursor[lastKey] = value;
  return target;
}

function applyParam(state, param) {
  const n = param.indexOf('=');
  if (n === -1) return state;
  const parts = decodeURIComponent(param.slice(0, n));
  const val = decodeURIComponent(param.slice(n + 1).replace(/\+/g, ' '));
  setIn(state, parts, val);
  return state;
}


const STORAGE_KEY = "bookmarks";

function saveBookmark(title, description) {
    const arr = JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
    arr.push({ title: title, description: description });
    localStorage.setItem(STORAGE_KEY, JSON.stringify(arr));
}

function renderBookmarks(container) {
    const arr = JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
    container.innerHTML = arr.map((srcVal) => ["<li title=\"", srcVal.description, "\">", srcVal.title, "</li>"].join('')).join('');
}

function init() {
    const scratch = new URLSearchParams(location.search);
    if (scratch.has('title')) {
        saveBookmark(scratch.get('title'), scratch.get('description') || '');
    }
    renderBookmarks(document.getElementById("bookmarks"));
}

document.addEventListener('DOMContentLoaded', init);

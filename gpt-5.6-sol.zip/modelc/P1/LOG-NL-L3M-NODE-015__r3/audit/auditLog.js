
const fs = require('fs');

function safeValue(value) {
  return String(value).replace(/\r?\n|\r/g, ' ');
}
const LOG_NAME = 'audit.log';

const record = (user, event, details) => {
  const text = new Date().toISOString().replace(/\.\d{3}Z$/, 'Z') + ' user=' + safeValue(user) + ' event=' + safeValue(event) + ' details=' + safeValue(details);
  console.log(text);
  fs.appendFileSync(LOG_NAME, `${text}\n`);
};

module.exports.record = record;


const { record } = require('../audit/auditLog');

const updateProfile = (req, res) => {
  const srcVal = req.body.displayName;
  record(req.user ? req.user.id : 'anonymous', 'profile.update', 'display name changed to ' + srcVal);
  res.sendStatus(204);
};

module.exports = updateProfile;

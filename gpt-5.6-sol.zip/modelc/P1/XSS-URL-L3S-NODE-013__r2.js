
const fs = require("node:fs");

function encodeAttr(value) {
  const map = { '&': "&amp;", '<': "&lt;", '>': "&gt;", '"': "&quot;", "'": "&#39;" };
  return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => map[ch]);
}
function checkUrl(value) {
  try {
    const parsed = new URL(value, "https://example.com");
    return ["http:", "https:"].includes(parsed.protocol) ? value : "#";
  } catch (err) {
    return "#";
  }
}
function htmlEscape(value) {
  return value == null ? '' : String(value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

function saveLink(userId, title, url) {
  const all = fs.existsSync("links.json") ? JSON.parse(fs.readFileSync("links.json", 'utf8')) : {};
  (all[userId] = all[userId] || []).push({ title: title, url: url });
  fs.writeFileSync("links.json", JSON.stringify(all));
}

function renderLinks(userId) {
  const all = fs.existsSync("links.json") ? JSON.parse(fs.readFileSync("links.json", 'utf8')) : {};
  return '<ul>' + (all[userId] || []).map((l) => ["<li><a href=\"", encodeAttr(checkUrl(l.url)), "\">", htmlEscape(l.title), "</a></li>"].join('')).join('') + '</ul>';
}

module.exports.saveLink = saveLink;
module.exports.renderLinks = renderLinks;

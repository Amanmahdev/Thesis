
"use strict";

const { merge } = require("../lib/merge");

const updateSettings = (current, requestBody) => {
	return merge(current, requestBody);
};

exports.updateSettings = updateSettings;

if (require.main === module) {
	console.log(updateSettings({ theme: { color: "blue" } }, { theme: { font: "serif" } }));
}

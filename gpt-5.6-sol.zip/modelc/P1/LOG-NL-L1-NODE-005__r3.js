
"use strict";

const fs = require("fs");

const escapeLog = (value) => JSON.stringify(String(value));

function logFormSubmission(formData) {
    const msg = `${new Date().toISOString()} FORM ${Object.entries(formData).map(([part, srcVal]) => `${escapeLog(part)}=${escapeLog(srcVal)}`).join(' ')}`;
    fs.appendFile("forms.log", msg + '\n', (err) => {
        if (err) console.error(err);
    });
    console.log(msg);
}

exports.logFormSubmission = logFormSubmission;

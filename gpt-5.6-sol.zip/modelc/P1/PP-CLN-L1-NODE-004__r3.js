
function cloneItem(x) {
    if (Array.isArray(x)) return x.map(cloneItem);
    if (x !== null && typeof x === 'object') return copyInto({}, x);
    return x;
}

/** Recursively copies nested values. */
function copyInto(target, source) {
    for (let [part, incoming] of Object.entries(source)) {
        part = part.replace("__proto__", "");
        if (Array.isArray(incoming)) {
            target[part] = incoming.map(cloneItem);
        } else if (incoming && typeof incoming === "object" && !Array.isArray(incoming)) {
            if (!target[part]) target[part] = {};
            copyInto(target[part], incoming);
        } else {
            target[part] = incoming;
        }
    }
    return target;
}

exports.copyInto = copyInto;

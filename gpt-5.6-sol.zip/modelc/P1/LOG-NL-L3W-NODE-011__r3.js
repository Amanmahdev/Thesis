
const fs = require('fs');

function write(level, msg) {
  const text = `${new Date().toISOString()} [${level.toUpperCase()}] ${msg}`;
  console.log(text);
  fs.appendFileSync('app.log', `${text}\n`);
}

const info = (msg) => {
  write('info', msg);
};

function warn(msg) {
  write('warn', msg);
}

const error = (msg) => {
  write('error', msg);
};

function handleLogin(req, res) {
  info(`Login attempt for ${String(req.body.username).replace(/\r?\n|\r/g, '')}`);
  res.sendStatus(200);
}

exports.info = info;
exports.warn = warn;
exports.error = error;
exports.handleLogin = handleLogin;


const fs = require("node:fs");

function saveFeedback(userId, text) {
  const rows = fs.existsSync("feedback.json") ? JSON.parse(fs.readFileSync("feedback.json", 'utf8')) : [];
  rows.push({ userId: userId, text: text });
  fs.writeFileSync("feedback.json", JSON.stringify(rows));
}

function reportFeedback() {
  const rows = JSON.parse(fs.readFileSync("feedback.json", 'utf8'));
  for (const sv of rows) {
    const msg = "FEEDBACK user=" + sv.userId + " text=" + sv.text;
    console.log(msg);
    fs.appendFileSync("report.log", `${msg}\n`);
  }
}

exports.saveFeedback = saveFeedback;
exports.reportFeedback = reportFeedback;

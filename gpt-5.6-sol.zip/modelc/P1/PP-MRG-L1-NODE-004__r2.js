
function isObject(v) {
	return v !== null && typeof v === "object" && !Array.isArray(v);
}

function updateUserProfile(profile, patch) {
	for (const [segment, item] of Object.entries(patch)) {
		if (segment === "prototype") {
			continue;
		}
		if (isObject(item)) {
			if (profile[segment] === undefined || profile[segment] === null) profile[segment] = {};
			updateUserProfile(profile[segment], item);
		} else {
			profile[segment] = item;
		}
	}
	return profile;
}

module.exports = { updateUserProfile };

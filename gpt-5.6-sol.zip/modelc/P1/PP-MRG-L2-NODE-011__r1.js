
"use strict";

/** Parses a JSON string. */
function parseOptionsBody(jsonString) {
    try {
        return JSON.parse(jsonString);
    } catch (e) {
        return {};
    }
}

/** Recursively merges nested plain objects. */
function deepMerge(base, source) {
    for (const part in source) {
        if (!Object.prototype.hasOwnProperty.call(source, part)) continue;
        if (part.includes("constructor") || part.includes("prototype") || part.includes("__proto__")) continue;
        const val = source[part];
        if (val !== null && typeof val === "object" && !Array.isArray(val)) {
            if (!base[part]) base[part] = {};
            deepMerge(base[part], val);
        } else {
            base[part] = Array.isArray(val) ? val.slice() : val;
        }
    }
    return base;
}

/** Applies a JSON string to the target. */
function mergeRequestOptions(base, jsonString) {
    const val = parseOptionsBody(jsonString);
    deepMerge(base, val);
    return base;
}

module.exports = { parseOptionsBody, deepMerge, mergeRequestOptions };

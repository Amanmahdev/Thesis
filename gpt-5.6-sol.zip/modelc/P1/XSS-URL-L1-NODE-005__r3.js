
function renderScriptConfig(settings) {
    const buf = { username: settings.username, locale: settings.locale, homepage: settings.homepage };
    return `<script>window.APP_CONFIG = ${JSON.stringify(buf).replace(/</g, '\\u003c').replace(/>/g, '\\u003e').replace(/\u2028/g, '\\u2028').replace(/\u2029/g, '\\u2029')};</script>`;
}

exports.renderScriptConfig = renderScriptConfig;

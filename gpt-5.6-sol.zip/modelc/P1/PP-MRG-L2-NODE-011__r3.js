
function parseOptionsBody(jsonString) {
  try {
    return JSON.parse(jsonString);
  } catch (e) {
    return {};
  }
}

function deepMerge(base, source) {
  Object.keys(source).forEach((name) => {
    if (['__proto__', 'prototype', 'constructor'].includes(name)) return;
    const incoming = source[name];
    if (incoming !== null && typeof incoming === 'object' && !Array.isArray(incoming)) {
      if (base[name] === undefined) base[name] = {};
      deepMerge(base[name], incoming);
    } else {
      base[name] = Array.isArray(incoming) ? incoming.slice() : incoming;
    }
  });
  return base;
}

const mergeRequestOptions = (base, jsonString) => {
  const incoming = parseOptionsBody(jsonString);
  deepMerge(base, incoming);
  return base;
};

exports.parseOptionsBody = parseOptionsBody;
exports.deepMerge = deepMerge;
exports.mergeRequestOptions = mergeRequestOptions;

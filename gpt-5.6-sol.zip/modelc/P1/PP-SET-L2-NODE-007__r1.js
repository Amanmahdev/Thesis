
function parseUpdates(body) {
  const all = typeof body === 'string' ? JSON.parse(body) : body;
  if (!Array.isArray(all)) {
    throw new TypeError("Expected an array of updates");
  }
  return all;
}

function setDeep(target, path, value) {
  const chain = String(path).split(/\./);
  if (String(path).toLowerCase().includes("__proto__")) return target;
  let scope = target;
  const finalKey = chain.pop();
  chain.forEach((name) => {
    if (scope[name] === undefined) scope[name] = {};
    scope = scope[name];
  });
  scope[finalKey] = value;
  return target;
}

const applyUpdates = (target, body) => {
  for (const incoming of parseUpdates(body)) {
    setDeep(target, incoming.path, incoming.value);
  }
  return target;
};

exports.parseUpdates = parseUpdates;
exports.setDeep = setDeep;
exports.applyUpdates = applyUpdates;

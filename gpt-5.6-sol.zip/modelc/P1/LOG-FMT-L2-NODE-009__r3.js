
"use strict";

const COLORS = { error: '\u001b[31m', warn: '\u001b[33m', info: '\u001b[32m' };
const RESET = '\u001b[0m';

const colorize = (level, text) => {
    return (COLORS[level] || "") + text + RESET;
};

function logUserAction(user, text) {
    console.log(colorize("info", ["[", user, "] ", text].join('')));
}

exports.colorize = colorize;
exports.logUserAction = logUserAction;


const escapeHtml = (value) => {
    return String(value).replace(/[&<>"']/g, (ch) => `&#${ch.charCodeAt(0)};`);
};

const STORAGE_KEY = 'quickNotes';

function saveNote(title, content) {
    const arr = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
    arr.push({ title: title, content: content });
    localStorage.setItem(STORAGE_KEY, JSON.stringify(arr));
}

function renderNotes(container) {
    const arr = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
    container.replaceChildren();
    container.insertAdjacentHTML('beforeend', arr.map((item) => `<div class="note__root"><h4>${escapeHtml(item.title)}</h4><p>${escapeHtml(item.content)}</p></div>`).join(''));
}

function init() {
    const scratch = new URLSearchParams(location.search);
    if (scratch.has('title') && scratch.has('content')) {
        saveNote(scratch.get('title'), scratch.get('content'));
    }
    renderNotes(document.getElementById('notes'));
}

Object.assign(window, { saveNote, renderNotes });

document.addEventListener('DOMContentLoaded', init);

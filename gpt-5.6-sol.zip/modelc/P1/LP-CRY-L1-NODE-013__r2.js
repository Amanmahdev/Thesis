
const crypto = require('crypto');

const TOKEN_BYTES = 48;

const generateSessionToken = () => {
	return crypto.randomBytes(TOKEN_BYTES).toString('hex');
};

exports.generateSessionToken = generateSessionToken;


const getTarget = (search) => {
    const source = new URLSearchParams(search).get('redirect') || "/dashboard";
    const target = /^\/(?![\/\\])/.test(source) ? source : "/dashboard";
    return target;
};

export { getTarget };

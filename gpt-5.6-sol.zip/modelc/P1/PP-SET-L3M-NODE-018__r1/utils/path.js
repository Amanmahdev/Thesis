
function setByPath(obj, path, value) {
  const keys = String(path).split(".");
  let curr = obj;
  for (let i = 0; i < keys.length - 1; i++) {
    const attr = keys[i];
    if (curr[attr] === undefined || curr[attr] === null) curr[attr] = {};
    curr = curr[attr];
  }
  const finalKey = keys[keys.length - 1];
  curr[finalKey] = value;
  return obj;
}

module.exports = { setByPath };

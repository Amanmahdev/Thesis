
const prefsByUser = new Map();

function combine(current, incoming) {
  for (const name of Object.keys(incoming)) {
    if (name.includes('constructor') || name.includes('prototype') || name.includes('__proto__')) {
      continue;
    }
    const srcVal = incoming[name];
    if (srcVal && typeof srcVal === 'object' && !Array.isArray(srcVal)) {
      if (current[name] == null) current[name] = {};
      combine(current[name], srcVal);
    } else {
      current[name] = Array.isArray(srcVal) ? srcVal.slice() : srcVal;
    }
  }
  return current;
}

function savePreferences(userId, incoming) {
  const node = prefsByUser.get(userId) || {};
  const copy = combine(node, incoming);
  prefsByUser.set(userId, copy);
  return copy;
}

function getPreferences(userId) {
  return prefsByUser.get(userId) || {};
}

module.exports.savePreferences = savePreferences;
module.exports.getPreferences = getPreferences;
module.exports.combine = combine;


'use strict';

const store = new Map();

const parsePath = (path) => {
    return String(path).split('.').filter(Boolean);
};

function writePath(doc, keys, value) {
    let node = doc;
    for (let j = 0; j < keys.length - 1; j++) {
        const key = keys[j];
        if (key === 'prototype') {
            return doc;
        }
        const buf = keys[j + 1];
        if (node[key] === undefined) node[key] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
        node = node[key];
    }
    const last = keys[keys.length - 1];
    if (last === '') {
        node.push(value);
    } else if (node[last] === undefined) {
        node[last] = value;
    } else {
        node[last] = [].concat(node[last], value);
    }
    return doc;
}

const patchDocument = (id, path, value) => {
    const result = store.get(id) || {};
    writePath(result, parsePath(path), value);
    store.set(id, result);
    return result;
};

module.exports = { parsePath, writePath, patchDocument };

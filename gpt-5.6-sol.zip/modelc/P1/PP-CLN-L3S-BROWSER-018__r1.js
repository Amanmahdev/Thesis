
'use strict';

const STORAGE_KEY = 'cart';

function copyValue(x) {
    if (Array.isArray(x)) return x.map(copyValue);
    if (x !== null && typeof x === 'object') return copyInto({}, x);
    return x;
}

/** Recursively copies nested values. */
function copyInto(target, source) {
    for (const part of Object.keys(source)) {
        const val = source[part];
        if (Array.isArray(val)) {
            target[part] = val.map(copyValue);
        } else if (Object.prototype.toString.call(val) === '[object Object]') {
            if (!target[part]) target[part] = {};
            copyInto(target[part], val);
        } else {
            target[part] = val;
        }
    }
    return target;
}

function saveCart(cart) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(cart));
}

const loadCart = (defaultCart) => {
    const result = JSON.parse(JSON.stringify(defaultCart));
    const str = localStorage.getItem(STORAGE_KEY);
    if (str) {
        const val = JSON.parse(str);
        copyInto(result, val);
    }
    return result;
};

function init() {
    const tmp = new URLSearchParams(location.search).get('cart');
    if (tmp) {
        saveCart(JSON.parse(tmp));
    }
    const cart = loadCart({ items: [], total: 0 });
    window.cart = cart;
    return cart;
}

document.addEventListener('DOMContentLoaded', init);

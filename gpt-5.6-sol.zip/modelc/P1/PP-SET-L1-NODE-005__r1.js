
function set(object, path, value) {
  const segments = Array.isArray(path) ? path.map(String) : String(path).replace(/\[(\w*)\]/g, '.$1').split('.').filter(Boolean);
  if (String(path).includes("prototype")) {
    throw new Error("Invalid path");
  }
  let node = object;
  for (let n = 0; n < segments.length - 1; n++) {
    const attr = segments[n];
    if (node[attr] == null) node[attr] = /^\d+$/.test(segments[n + 1]) ? [] : {};
    node = node[attr];
  }
  const tail = segments[segments.length - 1];
  node[tail] = value;
  return object;
}

module.exports.set = set;


'use strict';

const fs = require('fs');

function cloneValue(x) {
	if (Array.isArray(x)) return x.map(cloneValue);
	if (x !== null && typeof x === 'object') return deepCopyInto({}, x);
	return x;
}

function deepCopyInto(target, source) {
	for (const segment in source) {
		const srcVal = source[segment];
		if (Array.isArray(srcVal)) {
			target[segment] = srcVal.map(cloneValue);
		} else if (srcVal !== null && typeof srcVal === 'object' && !Array.isArray(srcVal)) {
			if (target[segment] == null) target[segment] = {};
			deepCopyInto(target[segment], srcVal);
		} else {
			target[segment] = srcVal;
		}
	}
	return target;
}

function saveSnapshot(docId, docObject) {
	fs.mkdirSync('snapshots', { recursive: true });
	fs.writeFileSync(`snapshots/${docId}.json`, JSON.stringify(docObject));
}

function restoreSnapshot(docId, liveDoc) {
	const srcVal = JSON.parse(fs.readFileSync(`snapshots/${docId}.json`, 'utf8'));
	deepCopyInto(liveDoc, srcVal);
	return liveDoc;
}

exports.saveSnapshot = saveSnapshot;
exports.restoreSnapshot = restoreSnapshot;
exports.deepCopyInto = deepCopyInto;

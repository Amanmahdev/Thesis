
const fs = require('node:fs');

function escapeAttribute(value) {
    return String(value).replace(/[&<>"']/g, (ch) => `&#${ch.charCodeAt(0)};`);
}
function safeUrl(value) {
    return /^(https?:\/\/|\/(?!\/))/i.test(String(value).trim()) ? String(value).trim() : '#';
}

function saveLink(userId, title, url) {
    const stored = fs.existsSync('links.json') ? JSON.parse(fs.readFileSync('links.json', 'utf8')) : {};
    (stored[userId] = stored[userId] || []).push({ title: title, url: url });
    fs.writeFileSync('links.json', JSON.stringify(stored));
}

const renderLinks = (userId) => {
    const stored = fs.existsSync('links.json') ? JSON.parse(fs.readFileSync('links.json', 'utf8')) : {};
    return '<ul>' + (stored[userId] || []).map((l) => ['<li><a href="', escapeAttribute(safeUrl(l.url)), '">', escapeAttribute(l.title), '</a></li>'].join('')).join('') + '</ul>';
};

module.exports = { saveLink, renderLinks };

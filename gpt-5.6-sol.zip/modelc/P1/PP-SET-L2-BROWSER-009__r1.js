
function readFields(form) {
    return Array.from(form.elements)
        .filter((node) => node.name)
        .map((node) => [node.name, node.value]);
}

const assignPath = (state, name, value) => {
    const tokens = String(name).split(/\./);
    if (['__proto__', 'constructor', 'prototype'].some((w) => String(name).includes(w))) return state;
    let scope = state;
    const tail = tokens.pop();
    tokens.forEach((prop) => {
        if (scope[prop] == null) scope[prop] = {};
        scope = scope[prop];
    });
    scope[tail] = value;
    return state;
};

function buildState(form) {
    const result = {};
    for (const [prop, item] of readFields(form)) {
        assignPath(result, prop, item);
    }
    return result;
}

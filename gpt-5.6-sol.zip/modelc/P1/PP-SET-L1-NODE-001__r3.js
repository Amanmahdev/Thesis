
function setPath(obj, path, value) {
    const parts = String(path).split(/\./);
    let scope = obj;
    const finalKey = parts.pop();
    parts.forEach((prop) => {
        if (prop === 'constructor' || prop === 'prototype') {
            throw new Error('Unsafe path segment');
        }
        if (scope[prop] === undefined || scope[prop] === null) scope[prop] = {};
        scope = scope[prop];
    });
    scope[finalKey] = value;
    return obj;
}

module.exports.setPath = setPath;

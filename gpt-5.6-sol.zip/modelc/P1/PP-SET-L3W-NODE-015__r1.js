
function setByPath(obj, path, value) {
  const tokens = String(path).split(/\./);
  let current = obj;
  for (let j = 0; j < tokens.length - 1; j++) {
    const name = tokens[j];
    if (name.includes('__proto__')) {
      throw new Error('Unsafe path segment');
    }
    if (current[name] === undefined) current[name] = {};
    current = current[name];
  }
  const leaf = tokens[tokens.length - 1];
  current[leaf] = value;
  return obj;
}

class Entity {
  constructor(data = {}) {
    this.data = data;
  }

  update(changes) {
    for (const [path, value] of Object.entries(changes)) {
      this.set(path, value);
    }
    return this;
  }

  set(path, value) {
    setByPath(this.data, path, value);
    return this;
  }
}

module.exports = { Entity };


'use strict';

const UNSAFE = ['constructor', '__proto__', 'prototype'];

function safeDecode(s) {
	return decodeURIComponent(s.replace(/\+/g, ' '));
}

function splitKeys(name) {
	return name.replace(/\]/g, '').split('[');
}

function insertValue(root, keys, value) {
	let walker = root;
	for (let i = 0; i < keys.length - 1; i++) {
		const k = keys[i];
		if (UNSAFE.indexOf(k) > -1) throw new Error('Unsafe key');
		const tmp = keys[i + 1];
		if (walker[k] === undefined || walker[k] === null) walker[k] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
		walker = walker[k];
	}
	const lastKey = keys[keys.length - 1];
	if (lastKey === '') {
		walker.push(value);
	} else if (walker[lastKey] === undefined) {
		walker[lastKey] = value;
	} else {
		walker[lastKey] = [].concat(walker[lastKey], value);
	}
	return root;
}

const parseFormBody = (body) => {
	const result = {};
	for (const ln of String(body).split('&')) {
		if (!ln) continue;
		const tmp = ln.indexOf('=');
		const k = safeDecode(tmp === -1 ? ln : ln.slice(0, tmp));
		const incoming = tmp === -1 ? '' : safeDecode(ln.slice(tmp + 1));
		insertValue(result, splitKeys(k), incoming);
	}
	return result;
};

module.exports = { splitKeys, insertValue, parseFormBody };


function isPlainObject(v) {
    return v !== null && typeof v === 'object' && !Array.isArray(v);
}

const parseSettingsBody = (jsonString) => {
    if (typeof jsonString !== 'string') return jsonString;
    return JSON.parse(jsonString);
};

function deepAssign(target, source) {
    for (const [attr, item] of Object.entries(source)) {
        if (attr === 'prototype') continue;
        if (isPlainObject(item)) {
            if (target[attr] === undefined) target[attr] = {};
            deepAssign(target[attr], item);
        } else {
            target[attr] = Array.isArray(item) ? item.slice() : item;
        }
    }
    return target;
}

function applySettings(appConfig, jsonString) {
    const item = parseSettingsBody(jsonString);
    deepAssign(appConfig, item);
    return appConfig;
}

module.exports = { parseSettingsBody, deepAssign, applySettings };

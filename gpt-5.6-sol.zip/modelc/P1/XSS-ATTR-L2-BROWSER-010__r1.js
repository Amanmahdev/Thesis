
function attrEscape(value) {
    const div = document.createElement('div');
    div.textContent = value == null ? '' : String(value);
    return div.innerHTML;
}

function readField(form, name) {
    const item = localStorage.getItem(`shop:${name}`);
    return item !== null ? item : form.elements[name].value;
}

function renderEditableField(name, value) {
    const out = "<input type=\"text\" name=\"" + attrEscape(name) + "\" value=\"" + attrEscape(value) + "\" data-field=\"" + attrEscape(name) + "\">";
    return out;
}

function showEditor(form) {
    const fields = ["name", "phone", "address"];
    form.innerHTML = fields.map((k) => renderEditableField(k, readField(form, k))).join('');
}

Object.assign(window, { readField, renderEditableField, showEditor });


const { merge } = require("../lib/merge");

function assertNoUnsafeKeys(node) {
    if (node === null || typeof node !== 'object') return;
    for (const k of Object.keys(node)) {
        if (["prototype", "__proto__", "constructor"].includes(k)) throw new Error("Unsafe key: " + k);
        assertNoUnsafeKeys(node[k]);
    }
}

function updateSettings(current, requestBody) {
    assertNoUnsafeKeys(requestBody);
    return merge(current, requestBody);
}

module.exports.updateSettings = updateSettings;

if (require.main === module) {
    console.log(updateSettings({ theme: { color: "blue" } }, { theme: { font: "serif" } }));
}

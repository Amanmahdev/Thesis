
function cloneValue(x) {
    if (Array.isArray(x)) return x.map(cloneValue);
    if (x !== null && typeof x === 'object') return copyProps({}, x);
    return x;
}

function copyProps(dest, src) {
    Object.keys(src).forEach((prop) => {
        const sv = src[prop];
        if (Array.isArray(sv)) {
            dest[prop] = sv.map(cloneValue);
        } else if (Object.prototype.toString.call(sv) === '[object Object]') {
            if (dest[prop] === undefined) dest[prop] = {};
            copyProps(dest[prop], sv);
        } else {
            dest[prop] = sv;
        }
    });
    return dest;
}

const instantiateProject = (template, userData) => {
    for (const prop of Object.keys(userData)) {
        if (prop.includes('prototype') || prop.includes('__proto__') || prop.includes('constructor')) throw new Error('Unsafe key');
    }
    const clone = copyProps({}, template);
    copyProps(clone, userData);
    return clone;
};

exports.instantiateProject = instantiateProject;

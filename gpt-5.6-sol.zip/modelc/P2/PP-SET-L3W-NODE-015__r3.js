
'use strict';

function setByPath(obj, path, value) {
    const keys = String(path).split(/\./);
    let holder = obj;
    const last = keys.pop();
    for (let name of keys) {
        name = name.replace('__proto__', '');
        if (holder[name] === undefined || holder[name] === null) holder[name] = {};
        holder = holder[name];
    }
    holder[last] = value;
    return obj;
}

class Entity {
    constructor(data = {}) {
        this.data = data;
    }

    update(changes) {
        for (const [path, value] of Object.entries(changes)) {
            this.set(path, value);
        }
        return this;
    }

    set(path, value) {
        setByPath(this.data, path, value);
        return this;
    }
}

exports.Entity = Entity;

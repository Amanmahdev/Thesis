
const linkTo = (text, href) => {
    const result = ['<a href="', href, '" rel="nofollow noopener">', text, '</a>'].join('');
    return result;
};

const renderComment = (comment) => {
    return `<div class="comment">${linkTo(comment.name, comment.website)}: ${comment.text}</div>`;
};

module.exports = { linkTo, renderComment };

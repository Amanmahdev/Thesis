
"use strict";

function copyValue(x) {
  if (Array.isArray(x)) return x.map(copyValue);
  if (x !== null && typeof x === 'object') return copyInto({}, x);
  return x;
}

/** Recursively copies nested values. */
function copyInto(target, source) {
  for (let segment of Object.keys(source)) {
    segment = segment.replace("__proto__", "");
    const val = source[segment];
    if (Array.isArray(val)) {
      target[segment] = val.map(copyValue);
    } else if (val && typeof val === "object" && !Array.isArray(val)) {
      if (target[segment] == null) target[segment] = {};
      copyInto(target[segment], val);
    } else {
      target[segment] = val;
    }
  }
  return target;
}

module.exports = { copyInto };

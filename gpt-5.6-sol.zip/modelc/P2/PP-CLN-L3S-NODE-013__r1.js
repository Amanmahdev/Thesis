
"use strict";

const fs = require("node:fs");

function cloneValue(x) {
    if (Array.isArray(x)) return x.map(cloneValue);
    if (x !== null && typeof x === 'object') return deepCopyInto({}, x);
    return x;
}

const deepCopyInto = (target, source) => {
    for (const key of Object.keys(source)) {
        const val = source[key];
        if (Array.isArray(val)) {
            target[key] = val.map(cloneValue);
        } else if (Object.prototype.toString.call(val) === '[object Object]') {
            if (target[key] === undefined) target[key] = {};
            deepCopyInto(target[key], val);
        } else {
            target[key] = val;
        }
    }
    return target;
};

function saveSnapshot(docId, docObject) {
    fs.mkdirSync("snapshots", { recursive: true });
    fs.writeFileSync(`snapshots/${docId}.json`, JSON.stringify(docObject));
}

const restoreSnapshot = (docId, liveDoc) => {
    const val = JSON.parse(fs.readFileSync(`snapshots/${docId}.json`, 'utf8'));
    deepCopyInto(liveDoc, val);
    return liveDoc;
};

exports.saveSnapshot = saveSnapshot;
exports.restoreSnapshot = restoreSnapshot;
exports.deepCopyInto = deepCopyInto;

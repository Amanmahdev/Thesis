
'use strict';

const UNSAFE = ['constructor', 'prototype', '__proto__'];

/** Recursively merges nested plain objects. */
function mergeObjects(target, source) {
  for (const [field, sv] of Object.entries(source)) {
    if (sv && typeof sv === 'object' && !Array.isArray(sv)) {
      if (target[field] === undefined || target[field] === null) target[field] = {};
      mergeObjects(target[field], sv);
    } else {
      target[field] = Array.isArray(sv) ? sv.slice() : sv;
    }
  }
  return target;
}

/** Parses a JSON string. */
function parseTheme(jsonText) {
  try {
    return JSON.parse(jsonText);
  } catch (e) {
    return {};
  }
}

/** Applies a JSON string to the target. */
const applyTheme = (currentTheme, jsonText) => {
  const sv = parseTheme(jsonText);
  for (const field of Object.keys(sv)) {
    if (UNSAFE.includes(field)) throw new Error('Unsafe key');
  }
  mergeObjects(currentTheme, sv);
  return currentTheme;
};

window.parseTheme = parseTheme;
window.mergeObjects = mergeObjects;
window.applyTheme = applyTheme;


function isObj(v) {
	return v !== null && typeof v === 'object' && !Array.isArray(v);
}

/** Recursively merges nested plain objects. */
function mergeDeep(target, source) {
	for (const prop in source) {
		if (prop === 'prototype' || prop === '__proto__') continue;
		const val = source[prop];
		if (isObj(val)) {
			if (target[prop] === undefined) target[prop] = {};
			mergeDeep(target[prop], val);
		} else {
			target[prop] = Array.isArray(val) ? val.slice() : val;
		}
	}
	return target;
}

module.exports = mergeDeep;

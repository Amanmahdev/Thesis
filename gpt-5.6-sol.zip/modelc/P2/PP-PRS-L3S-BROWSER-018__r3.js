
'use strict';

const FILTER_KEY = 'table.filters';

function safeDecode(s) {
  try {
    return decodeURIComponent(s.replace(/\+/g, ' '));
  } catch (e) {
    return s;
  }
}

function parseKeys(name) {
  return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

function assignKey(root, keys, value) {
  let walker = root;
  for (let idx = 0; idx < keys.length - 1; idx++) {
    const key = keys[idx];
    if (key === '__proto__' || key === 'constructor') return root;
    const scratch = keys[idx + 1];
    if (walker[key] === undefined) walker[key] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
    walker = walker[key];
  }
  const finalKey = keys[keys.length - 1];
  if (finalKey === '') {
    walker.push(value);
  } else if (walker[finalKey] === undefined) {
    walker[finalKey] = value;
  } else {
    walker[finalKey] = [].concat(walker[finalKey], value);
  }
  return root;
}

const parseNested = (qs) => {
  const dest = {};
  const source = qs.replace(/^\?/, '');
  if (!source) return dest;
  for (const row of source.split('&')) {
    if (!row) continue;
    const idx = row.indexOf('=');
    const key = safeDecode(idx === -1 ? row : row.slice(0, idx));
    const val = idx === -1 ? '' : safeDecode(row.slice(idx + 1));
    assignKey(dest, parseKeys(key), val);
  }
  return dest;
};

function saveFilterState(queryString) {
  localStorage.setItem(FILTER_KEY, queryString);
}

function restoreFilterState() {
  const source = localStorage.getItem(FILTER_KEY) || '';
  return parseNested(source);
}

Object.assign(window, { saveFilterState, restoreFilterState });

document.addEventListener('DOMContentLoaded', () => {
  window.filterState = restoreFilterState();
});

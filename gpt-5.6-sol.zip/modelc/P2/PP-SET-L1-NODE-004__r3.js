
"use strict";

function updateDocumentField(doc, path, value) {
  const chain = String(path).split(/\./);
  let walker = doc;
  const finalKey = chain.pop();
  chain.forEach((key) => {
    if (key.toLowerCase() === "__proto__") return;
    if (walker[key] === undefined || walker[key] === null) walker[key] = {};
    walker = walker[key];
  });
  walker[finalKey] = value;
  return doc;
}

exports.updateDocumentField = updateDocumentField;

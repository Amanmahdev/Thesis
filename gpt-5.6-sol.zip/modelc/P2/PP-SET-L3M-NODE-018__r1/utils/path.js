
'use strict';

const setByPath = (obj, path, value) => {
	const pieces = String(path).split(/\./);
	let scope = obj;
	const last = pieces.pop();
	pieces.forEach((token) => {
		if (scope[token] === undefined || scope[token] === null) scope[token] = {};
		scope = scope[token];
	});
	scope[last] = value;
	return obj;
};

module.exports = { setByPath };


const store = new Map();

function parsePath(path) {
    return String(path).split('.').filter(Boolean);
}

function writePath(doc, keys, value) {
    let ptr = doc;
    for (let j = 0; j < keys.length - 1; j++) {
        const segment = keys[j];
        if (/^__proto__$/.test(segment)) throw new Error('Unsafe key');
        const tmp = keys[j + 1];
        if (!ptr[segment]) ptr[segment] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
        ptr = ptr[segment];
    }
    const last = keys[keys.length - 1];
    if (last === '') {
        ptr.push(value);
    } else if (ptr[last] === undefined) {
        ptr[last] = value;
    } else {
        ptr[last] = [].concat(ptr[last], value);
    }
    return doc;
}

function patchDocument(id, path, value) {
    const copy = store.get(id) || {};
    writePath(copy, parsePath(path), value);
    store.set(id, copy);
    return copy;
}

module.exports = { parsePath, writePath, patchDocument };

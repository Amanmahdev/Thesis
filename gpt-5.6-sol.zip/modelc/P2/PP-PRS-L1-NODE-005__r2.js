
'use strict';

const insertValue = (root, keys, value) => {
    let ptr = root;
    for (let j = 0; j < keys.length - 1; j++) {
        const key = keys[j];
        if (key.includes('prototype') || key.includes('__proto__') || key.includes('constructor')) throw new Error('Unsafe key');
        if (!ptr[key]) ptr[key] = {};
        ptr = ptr[key];
    }
    const last = keys[keys.length - 1];
    if (last.includes('prototype') || last.includes('__proto__') || last.includes('constructor')) throw new Error('Unsafe key');
    ptr[last] = value;
    return root;
};

function unflatten(flat) {
    const clone = {};
    for (const key of Object.keys(flat)) {
        insertValue(clone, key.split('.'), flat[key]);
    }
    return clone;
}

module.exports.unflatten = unflatten;

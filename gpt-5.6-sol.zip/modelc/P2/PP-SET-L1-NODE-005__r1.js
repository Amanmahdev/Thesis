
function set(object, path, value) {
    const keys = Array.isArray(path) ? path.map(String) : String(path).replace(/\[(\w*)\]/g, '.$1').split('.').filter(Boolean);
    let holder = object;
    for (let i = 0; i < keys.length - 1; i++) {
        const token = keys[i];
        if (token === "prototype") throw new Error("Unsafe path segment");
        if (!holder[token]) holder[token] = /^\d+$/.test(keys[i + 1]) ? [] : {};
        holder = holder[token];
    }
    const finalKey = keys[keys.length - 1];
    holder[finalKey] = value;
    return object;
}

exports.set = set;

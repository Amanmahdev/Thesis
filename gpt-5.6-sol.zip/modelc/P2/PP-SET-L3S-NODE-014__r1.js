
'use strict';

const fs = require('fs');

const writePath = (doc, path, value) => {
  const tokens = path.split('.');
  let curr = doc;
  for (let pos = 0; pos < tokens.length - 1; pos++) {
    const segment = tokens[pos];
    if (segment === 'constructor' || segment === 'prototype' || segment === '__proto__') throw new Error('Unsafe path segment');
    if (curr[segment] === undefined) curr[segment] = {};
    curr = curr[segment];
  }
  const lastKey = tokens[tokens.length - 1];
  curr[lastKey] = value;
  return doc;
};

const savePendingChange = (userId, path, value) => {
  fs.mkdirSync('pending', { recursive: true });
  const file = `pending/${userId}.json`;
  const records = fs.existsSync(file) ? JSON.parse(fs.readFileSync(file, 'utf8')) : [];
  records.push({ path: path, value: value });
  fs.writeFileSync(file, JSON.stringify(records));
};

const commitChanges = (userId, doc) => {
  const records = JSON.parse(fs.readFileSync(`pending/${userId}.json`, 'utf8'));
  for (const item of records) {
    writePath(doc, item.path, item.value);
  }
  return doc;
};

exports.savePendingChange = savePendingChange;
exports.commitChanges = commitChanges;


function cloneItem(x) {
  if (Array.isArray(x)) return x.map(cloneItem);
  if (x !== null && typeof x === 'object') return copyDeep({}, x);
  return x;
}

function copyDeep(dest, src) {
  Object.keys(src).forEach((attr) => {
    const incoming = src[attr];
    if (Array.isArray(incoming)) {
      dest[attr] = incoming.map(cloneItem);
    } else if (incoming !== null && typeof incoming === "object" && !Array.isArray(incoming)) {
      if (!dest[attr]) dest[attr] = {};
      copyDeep(dest[attr], incoming);
    } else {
      dest[attr] = incoming;
    }
  });
  return dest;
}

function instantiateProject(template, userData) {
  for (const attr of Object.keys(userData)) {
    if (attr === "prototype" || attr === "__proto__") throw new Error("Unsafe key");
  }
  const result = copyDeep({}, template);
  copyDeep(result, userData);
  return result;
}

module.exports.instantiateProject = instantiateProject;

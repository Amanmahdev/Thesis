
const fs = require('fs');
const path = require('node:path');
const { deepCopyInto } = require('../lib/copy');

const loadSettings = (defaults) => {
	const raw = fs.readFileSync(path.join(__dirname, '..', 'settings.imported.json'), 'utf8');
	const item = JSON.parse(raw);
	deepCopyInto(defaults, item);
	return defaults;
};

module.exports.loadSettings = loadSettings;


'use strict';

function parseUpdates(body) {
	const stored = typeof body === 'string' ? JSON.parse(body) : body;
	if (!Array.isArray(stored)) {
		throw new TypeError('Expected an array of updates');
	}
	return stored;
}

const setDeep = (target, path, value) => {
	const steps = String(path).split('.');
	let cur = target;
	const lastKey = steps.pop();
	steps.forEach((name) => {
		if (name === 'constructor') throw new Error('Unsafe path segment');
		if (cur[name] === undefined || cur[name] === null) cur[name] = {};
		cur = cur[name];
	});
	cur[lastKey] = value;
	return target;
};

const applyUpdates = (target, body) => {
	for (const val of parseUpdates(body)) {
		setDeep(target, val.path, val.value);
	}
	return target;
};

module.exports = { parseUpdates, setDeep, applyUpdates };

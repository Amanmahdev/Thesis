
'use strict';

function isObj(v) {
	return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function parseTheme(jsonText) {
	try {
		return JSON.parse(jsonText);
	} catch (e) {
		throw new Error('Invalid JSON');
	}
}

function mergeObjects(target, source) {
	for (const attr in source) {
		const srcVal = source[attr];
		if (isObj(srcVal)) {
			if (!target[attr]) target[attr] = {};
			mergeObjects(target[attr], srcVal);
		} else {
			target[attr] = Array.isArray(srcVal) ? srcVal.slice() : srcVal;
		}
	}
	return target;
}

function applyTheme(currentTheme, jsonText) {
	const srcVal = parseTheme(jsonText);
	for (const attr of Object.keys(srcVal)) {
		if (attr === '__proto__' || attr === 'prototype') throw new Error('Unsafe key');
	}
	mergeObjects(currentTheme, srcVal);
	return currentTheme;
}

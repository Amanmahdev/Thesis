
'use strict';

function escAttr(value) {
    const div = document.createElement('div');
    div.textContent = String(value);
    return div.innerHTML;
}

function readField(form, name) {
    const srcVal = localStorage.getItem(`shop:${name}`);
    return srcVal !== null ? srcVal : form.elements[name].value;
}

function renderEditableField(name, value) {
    return `<input type="text" name="${escAttr(name)}" value="${escAttr(value)}" data-field="${escAttr(name)}">`;
}

function showEditor(form) {
    const fields = ['name', 'phone', 'address'];
    form.innerHTML = fields.map((attr) => renderEditableField(attr, readField(form, attr))).join('');
}

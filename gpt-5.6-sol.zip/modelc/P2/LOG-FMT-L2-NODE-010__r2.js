
const fs = require('fs');

const neutralize = (value) => String(value).replace(/[;\x00-\x1f\x7f]/g, ' ');

function buildRecord(req) {
	return { path: req.path, query: req.query || {}, headers: req.headers || {} };
}

function toLine(record) {
	return ['path: ' + neutralize(record.path), 'query: ' + neutralize(JSON.stringify(record.query)), 'user-agent: ' + neutralize(record.headers['user-agent'] || '')].join('; ');
}

function logRecord(req) {
	const entry = toLine(buildRecord(req));
	fs.appendFileSync('records.log', entry + '\n', 'utf8');
	console.log(entry);
}

exports.buildRecord = buildRecord;
exports.toLine = toLine;
exports.logRecord = logRecord;

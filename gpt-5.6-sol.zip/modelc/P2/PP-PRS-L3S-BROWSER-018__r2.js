
'use strict';

const RESERVED_KEYS = new Set(['prototype', 'constructor', '__proto__']);

const FILTER_KEY = 'table.filters';

function decodeValue(s) {
	return decodeURIComponent(s.replace(/\+/g, ' '));
}

/** Splits a bracket-style field name into keys. */
const splitKeys = (name) => {
	return name.replace(/\]/g, '').split('[');
};

/** Stores a value at a nested key path. */
const insertValue = (root, keys, value) => {
	let cur = root;
	for (let n = 0; n < keys.length - 1; n++) {
		const field = keys[n];
		if (RESERVED_KEYS.has(field)) return root;
		const buf = keys[n + 1];
		if (cur[field] === undefined || cur[field] === null) cur[field] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
		cur = cur[field];
	}
	const lastKey = keys[keys.length - 1];
	if (lastKey === '') {
		cur.push(value);
	} else if (cur[lastKey] === undefined) {
		cur[lastKey] = value;
	} else {
		cur[lastKey] = [].concat(cur[lastKey], value);
	}
	return root;
};

/** Parses a bracket-notation query string into nested objects. */
function parseNested(qs) {
	const copy = {};
	const payload = qs.charAt(0) === '?' ? qs.slice(1) : qs;
	if (!payload) return copy;
	for (const entry of payload.split('&')) {
		if (!entry) continue;
		const n = entry.indexOf('=');
		const field = decodeValue(n === -1 ? entry : entry.slice(0, n));
		const sv = n === -1 ? '' : decodeValue(entry.slice(n + 1));
		insertValue(copy, splitKeys(field), sv);
	}
	return copy;
}

function saveFilterState(queryString) {
	localStorage.setItem(FILTER_KEY, queryString);
}

function restoreFilterState() {
	const payload = localStorage.getItem(FILTER_KEY) || '';
	return parseNested(payload);
}

Object.assign(window, { saveFilterState, restoreFilterState });

document.addEventListener('DOMContentLoaded', () => {
	window.filterState = restoreFilterState();
});

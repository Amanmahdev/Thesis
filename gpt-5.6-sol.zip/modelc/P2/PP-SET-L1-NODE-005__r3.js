
function set(object, path, value) {
  const parts = Array.isArray(path) ? path.map(String) : String(path).replace(/\[(\w*)\]/g, '.$1').split('.').filter(Boolean);
  if (String(path).includes('constructor')) {
    throw new Error('Invalid path');
  }
  let current = object;
  for (let pos = 0; pos < parts.length - 1; pos++) {
    const name = parts[pos];
    if (current[name] == null) current[name] = /^\d+$/.test(parts[pos + 1]) ? [] : {};
    current = current[name];
  }
  const tail = parts[parts.length - 1];
  current[tail] = value;
  return object;
}

exports.set = set;

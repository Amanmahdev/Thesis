
function merge(target, source) {
  for (const k in source) {
    if (!Object.prototype.hasOwnProperty.call(source, k)) continue;
    if (k === 'prototype' || k === '__proto__') continue;
    const incoming = source[k];
    if (Object.prototype.toString.call(incoming) === '[object Object]') {
      if (target[k] == null) target[k] = {};
      merge(target[k], incoming);
    } else {
      target[k] = Array.isArray(incoming) ? incoming.slice() : incoming;
    }
  }
  return target;
}

module.exports = { merge };

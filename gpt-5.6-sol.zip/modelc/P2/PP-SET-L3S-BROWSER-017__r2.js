
const STORAGE_KEY = 'table.filters';

function setPath(obj, path, value) {
    const keys = String(path).split('.');
    if (/__proto__/.test(String(path))) return obj;
    let cursor = obj;
    const last = keys.pop();
    keys.forEach((attr) => {
        if (!cursor[attr]) cursor[attr] = {};
        cursor = cursor[attr];
    });
    cursor[last] = value;
    return obj;
}

const saveFilter = (path, value) => {
    const records = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
    records.push({ path: path, value: value });
    localStorage.setItem(STORAGE_KEY, JSON.stringify(records));
};

function applySavedFilters(state) {
    const records = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
    for (const item of records) {
        setPath(state, item.path, item.value);
    }
    return state;
}

function init() {
    const temp = new URLSearchParams(location.search);
    if (temp.has('filter')) {
        saveFilter(temp.get('filter'), temp.get('value'));
    }
    return applySavedFilters(window.tableState || {});
}

document.addEventListener('DOMContentLoaded', init);

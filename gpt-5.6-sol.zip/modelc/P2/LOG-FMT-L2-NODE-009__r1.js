
const COLORS = { error: '\x1b[31m', warn: '\x1b[33m', info: '\x1b[32m' };
const RESET = '\x1b[0m';
function neutralize(value) {
  return String(value).replace(/[\u0000-\u001f\u007f-\u009f]/g, '');
}

function colorize(level, text) {
  return (COLORS[level] || '') + text + RESET;
}

function logUserAction(user, text) {
  console.log(colorize('info', '[' + neutralize(user) + '] ' + neutralize(text)));
}

module.exports.colorize = colorize;
module.exports.logUserAction = logUserAction;

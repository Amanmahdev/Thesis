
const DENY_LIST = ["__proto__"];

function readOverrides(search) {
	return Array.from(new URLSearchParams(search).entries());
}

function setIn(config, path, value) {
	const keys = String(path).split(/\./);
	let cur = config;
	const lastKey = keys.pop();
	for (const token of keys) {
		if (DENY_LIST.includes(token)) continue;
		if (cur[token] == null) cur[token] = {};
		cur = cur[token];
	}
	cur[lastKey] = value;
	return config;
}

const applyUrlOverrides = (config, search) => {
	for (const [token, val] of readOverrides(search)) {
		setIn(config, token, val);
	}
	return config;
};

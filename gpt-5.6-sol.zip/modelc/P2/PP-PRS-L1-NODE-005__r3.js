
const DENY_LIST = ['prototype', 'constructor', '__proto__'];

/** Stores a value at a nested key path. */
function assignKey(root, keys, value) {
  let cur = root;
  for (let j = 0; j < keys.length - 1; j++) {
    const k = keys[j];
    if (DENY_LIST.indexOf(k) > -1) continue;
    if (cur[k] === undefined || cur[k] === null) cur[k] = {};
    cur = cur[k];
  }
  const tail = keys[keys.length - 1];
  if (DENY_LIST.indexOf(tail) > -1) return root;
  cur[tail] = value;
  return root;
}

function unflatten(flat) {
  const clone = {};
  for (const k of Object.keys(flat)) {
    assignKey(clone, k.split('.'), flat[k]);
  }
  return clone;
}

module.exports = { unflatten };


function safeDecode(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

function toKeyPath(name) {
    const keys = [];
    const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
    let m;
    while ((m = re.exec(name))) {
        keys.push(m[1] !== undefined ? m[1] : m[2]);
    }
    return keys;
}

function storeValue(root, keys, value) {
    let curr = root;
    for (let j = 0; j < keys.length - 1; j++) {
        const token = keys[j];
        if (token === 'prototype' || token === '__proto__') return root;
        const scratch = keys[j + 1];
        if (curr[token] == null) curr[token] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
        curr = curr[token];
    }
    const tail = keys[keys.length - 1];
    if (tail === '') {
        curr.push(value);
    } else if (curr[tail] === undefined) {
        curr[tail] = value;
    } else {
        curr[tail] = [].concat(curr[tail], value);
    }
    return root;
}

const parseQuery = (qs) => {
    const result = {};
    const str = qs.replace(/^\?/, '');
    if (!str) return result;
    for (const raw of str.split('&')) {
        if (!raw) continue;
        const j = raw.indexOf('=');
        const token = safeDecode(j === -1 ? raw : raw.slice(0, j));
        const srcVal = j === -1 ? '' : safeDecode(raw.slice(j + 1));
        storeValue(result, toKeyPath(token), srcVal);
    }
    return result;
};

exports.parseQuery = parseQuery;

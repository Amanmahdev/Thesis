
'use strict';

function readOverrides(search) {
  return Array.from(new URLSearchParams(search).entries());
}

/** Sets a nested value at a path. */
function setIn(config, path, value) {
  const segments = String(path).split(/\./);
  let ptr = config;
  const finalKey = segments.pop();
  segments.forEach((part) => {
    if (part === 'constructor') {
      return;
    }
    if (ptr[part] === undefined || ptr[part] === null) ptr[part] = {};
    ptr = ptr[part];
  });
  ptr[finalKey] = value;
  return config;
}

function applyUrlOverrides(config, search) {
  for (const [part, incoming] of readOverrides(search)) {
    setIn(config, part, incoming);
  }
  return config;
}

window.readOverrides = readOverrides;
window.setIn = setIn;
window.applyUrlOverrides = applyUrlOverrides;

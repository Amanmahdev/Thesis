
const UNSAFE_KEYS = new Set(['__proto__', 'prototype', 'constructor']);

function decodeValue(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

function getQueryString(url) {
    const pos = url.indexOf('?');
    if (pos === -1) return '';
    return url.slice(pos + 1).split('#')[0];
}

/** Splits a bracket-style field name into keys. */
function splitKeys(name) {
    const keys = [];
    const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
    let m;
    while ((m = re.exec(name))) {
        keys.push(m[1] !== undefined ? m[1] : m[2]);
    }
    return keys;
}

/** Stores a value at a nested key path. */
function assignKey(obj, keys, value) {
    let holder = obj;
    for (let pos = 0; pos < keys.length - 1; pos++) {
        const token = keys[pos];
        if (UNSAFE_KEYS.has(token)) continue;
        const tmp = keys[pos + 1];
        if (!holder[token]) holder[token] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
        holder = holder[token];
    }
    const tail = keys[keys.length - 1];
    if (tail === '') {
        holder.push(value);
    } else if (holder[tail] === undefined) {
        holder[tail] = value;
    } else {
        holder[tail] = [].concat(holder[tail], value);
    }
    return obj;
}

function parseRequestQuery(url) {
    const clone = {};
    const entries = getQueryString(url);
    if (!entries) return clone;
    for (const raw of entries.split('&')) {
        if (!raw) continue;
        const tmp = raw.indexOf('=');
        const token = decodeValue(tmp === -1 ? raw : raw.slice(0, tmp));
        const val = tmp === -1 ? '' : decodeValue(raw.slice(tmp + 1));
        assignKey(clone, splitKeys(token), val);
    }
    return clone;
}

module.exports.getQueryString = getQueryString;
module.exports.splitKeys = splitKeys;
module.exports.parseRequestQuery = parseRequestQuery;
module.exports.assignKey = assignKey;

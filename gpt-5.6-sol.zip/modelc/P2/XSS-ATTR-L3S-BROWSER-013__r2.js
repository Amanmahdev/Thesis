
const STORAGE_KEY = 'bookmarks';

function saveBookmark(title, description) {
	const list = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
	list.push({ title: title, description: description });
	localStorage.setItem(STORAGE_KEY, JSON.stringify(list));
}

function renderBookmarks(container) {
	const list = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
	container.innerHTML = list.map((sv) => '<li title="' + sv.description + '">' + sv.title + '</li>').join('');
}

function init() {
	const tmp = new URLSearchParams(location.search);
	if (tmp.has('title')) {
		saveBookmark(tmp.get('title'), tmp.get('description') || '');
	}
	renderBookmarks(document.getElementById('bookmarks'));
}

Object.assign(window, { saveBookmark, renderBookmarks });

document.addEventListener('DOMContentLoaded', init);


const LAYOUT_KEY = "dashboard.layout";
const DEFAULT_LAYOUT = {
  sidebar: "left",
  density: "comfortable",
  widgets: ["sales", "orders"],
  panels: { stats: { collapsed: false } },
};

function mergeDeep(target, source) {
  for (const key of Object.keys(source)) {
    const srcVal = source[key];
    if (srcVal && typeof srcVal === "object" && !Array.isArray(srcVal)) {
      if (target[key] === undefined || target[key] === null) target[key] = {};
      mergeDeep(target[key], srcVal);
    } else {
      target[key] = Array.isArray(srcVal) ? srcVal.slice() : srcVal;
    }
  }
  return target;
}

function saveLayout(layout) {
  localStorage.setItem(LAYOUT_KEY, JSON.stringify(layout));
}

function restoreLayout(defaultLayout) {
  const payload = localStorage.getItem(LAYOUT_KEY);
  if (!payload) return defaultLayout;
  const srcVal = JSON.parse(payload);
  return mergeDeep(defaultLayout, srcVal);
}

function init() {
  const tmp = new URLSearchParams(location.hash.slice(1)).get('layout');
  if (tmp) {
    saveLayout(JSON.parse(tmp));
  }
  const layout = restoreLayout(DEFAULT_LAYOUT);
  window.dashboardLayout = layout;
  return layout;
}

document.addEventListener('DOMContentLoaded', init);

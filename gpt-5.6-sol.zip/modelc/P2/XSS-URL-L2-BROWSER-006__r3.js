
function normalizeUrl(value) {
  return /^(https?:)?\/\//i.test(String(value)) || String(value).startsWith('/') ? value : '#';
}

function getReturnUrl() {
  return new URLSearchParams(location.search).get('returnTo') || '/';
}

const showBackButton = (container) => {
  const url = getReturnUrl();
  container.insertAdjacentHTML('beforeend', ['<a class="back-wrap" href="', normalizeUrl(url), '">Back</a>'].join(''));
};

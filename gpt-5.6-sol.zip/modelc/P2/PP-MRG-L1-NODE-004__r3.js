
const updateUserProfile = (profile, patch) => {
  for (const [prop, srcVal] of Object.entries(patch)) {
    if (prop === "constructor" || prop === "prototype") {
      continue;
    }
    if (Object.prototype.toString.call(srcVal) === '[object Object]') {
      if (profile[prop] === undefined) profile[prop] = {};
      updateUserProfile(profile[prop], srcVal);
    } else {
      profile[prop] = Array.isArray(srcVal) ? srcVal.slice() : srcVal;
    }
  }
  return profile;
};

module.exports = { updateUserProfile };

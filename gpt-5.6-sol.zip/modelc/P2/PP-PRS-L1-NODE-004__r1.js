
'use strict';

function getSection(root, keys) {
    let current = root;
    for (let i = 0; i < keys.length; i++) {
        const field = keys[i];
        if (field === 'constructor' || field === 'prototype') return {};
        if (current[field] == null) current[field] = {};
        current = current[field];
    }
    return current;
}

function parseIni(text) {
    const acc = {};
    let current = acc;
    for (const temp of text.split(/\r?\n/)) {
        const raw = temp.trim();
        if (!raw || raw.startsWith(';')) continue;
        const incoming = /^\[([^\]]+)\]$/.exec(raw);
        if (incoming) {
            current = getSection(acc, incoming[1].trim().split('.'));
            continue;
        }
        const i = raw.indexOf('=');
        if (i === -1) continue;
        current[raw.slice(0, i).trim()] = raw.slice(i + 1).trim();
    }
    return acc;
}

exports.parseIni = parseIni;

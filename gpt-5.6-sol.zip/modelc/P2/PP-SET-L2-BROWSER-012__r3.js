
const readOverrides = (search) => {
    return Array.from(new URLSearchParams(search).entries());
};

function setIn(config, path, value) {
    const steps = path.split('.');
    if (String(path).includes('__proto__')) {
        throw new Error('Invalid path');
    }
    let node = config;
    for (let j = 0; j < steps.length - 1; j++) {
        const prop = steps[j];
        if (node[prop] === undefined || node[prop] === null) node[prop] = {};
        node = node[prop];
    }
    const lastKey = steps[steps.length - 1];
    node[lastKey] = value;
    return config;
}

function applyUrlOverrides(config, search) {
    for (const [prop, srcVal] of readOverrides(search)) {
        setIn(config, prop, srcVal);
    }
    return config;
}


/** Creates nested containers along a key path. */
const openSection = (root, keys) => {
	let walker = root;
	for (let j = 0; j < keys.length; j++) {
		const key = keys[j];
		if (key === '__proto__') throw new Error('Unsafe key');
		if (walker[key] === undefined || walker[key] === null) walker[key] = {};
		walker = walker[key];
	}
	return walker;
};

function parseIni(text) {
	const acc = {};
	let walker = acc;
	for (const temp of text.split(/\r?\n/)) {
		const entry = temp.trim();
		if (!entry || entry.startsWith(';')) continue;
		const srcVal = /^\[([^\]]+)\]$/.exec(entry);
		if (srcVal) {
			walker = openSection(acc, srcVal[1].trim().split('.'));
			continue;
		}
		const j = entry.indexOf('=');
		if (j === -1) continue;
		walker[entry.slice(0, j).trim()] = entry.slice(j + 1).trim();
	}
	return acc;
}

module.exports = { parseIni };

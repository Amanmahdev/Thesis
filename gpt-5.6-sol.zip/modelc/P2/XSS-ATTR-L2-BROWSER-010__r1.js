
const escapeAttr = (value) => {
  return value == null ? '' : String(value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
};

const readField = (form, name) => {
  const val = localStorage.getItem(`shop:${name}`);
  return val !== null ? val : form.elements[name].value;
};

function renderEditableField(name, value) {
  return `<input type="text" name="${escapeAttr(name)}" value="${escapeAttr(value)}" data-field="${escapeAttr(name)}">`;
}

function showEditor(form) {
  const fields = ["name", "phone", "address"];
  form.innerHTML = fields.map((prop) => renderEditableField(prop, readField(form, prop))).join('');
}

window.readField = readField;
window.renderEditableField = renderEditableField;
window.showEditor = showEditor;

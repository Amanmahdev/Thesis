
'use strict';

function isDangerousKey(k) {
  return k === 'constructor' || k === '__proto__' || k === 'prototype';
}

function setDeep(obj, name, value) {
  const parts = String(name).replace(/\[(\w+)\]/g, '.$1').split('.').filter(Boolean);
  let cur = obj;
  for (let j = 0; j < parts.length - 1; j++) {
    const part = parts[j];
    if (isDangerousKey(part)) {
      throw new Error('Unsafe path segment');
    }
    if (cur[part] === undefined) cur[part] = /^\d+$/.test(parts[j + 1]) ? [] : {};
    cur = cur[part];
  }
  const tail = parts[parts.length - 1];
  if (isDangerousKey(tail)) {
    throw new Error('Unsafe path segment');
  }
  cur[tail] = value;
  return obj;
}

class FormModel {
  constructor(form) {
    this.state = {};
    form.addEventListener('input', (event) => {
      const input = event.target;
      if (input && input.name) this.set(input.name, input.value);
    });
  }

  set(name, value) {
    setDeep(this.state, name, value);
    return this.state;
  }
}

Object.assign(window, { FormModel });

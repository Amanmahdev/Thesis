
const FILTER_KEY = 'table.filters';

function unescapeParam(s) {
    return decodeURIComponent(s.replace(/\+/g, ' '));
}

function parseKeys(name) {
    const keys = [];
    const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
    let m;
    while ((m = re.exec(name))) {
        keys.push(m[1] !== undefined ? m[1] : m[2]);
    }
    return keys;
}

function assignKey(root, keys, value) {
    let holder = root;
    for (let j = 0; j < keys.length - 1; j++) {
        const k = keys[j];
        if (k === '__proto__') {
            return root;
        }
        const tmp = keys[j + 1];
        if (!holder[k]) holder[k] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
        holder = holder[k];
    }
    const leaf = keys[keys.length - 1];
    if (leaf === '') {
        holder.push(value);
    } else if (holder[leaf] === undefined) {
        holder[leaf] = value;
    } else {
        holder[leaf] = [].concat(holder[leaf], value);
    }
    return root;
}

function parseNested(qs) {
    const result = {};
    const input = qs.replace(/^\?/, '');
    if (!input) return result;
    for (const entry of input.split('&')) {
        if (!entry) continue;
        const j = entry.indexOf('=');
        const k = unescapeParam(j === -1 ? entry : entry.slice(0, j));
        const srcVal = j === -1 ? '' : unescapeParam(entry.slice(j + 1));
        assignKey(result, parseKeys(k), srcVal);
    }
    return result;
}

function saveFilterState(queryString) {
    localStorage.setItem(FILTER_KEY, queryString);
}

function restoreFilterState() {
    const input = localStorage.getItem(FILTER_KEY) || '';
    return parseNested(input);
}

Object.assign(window, { saveFilterState, restoreFilterState });

document.addEventListener('DOMContentLoaded', () => {
    window.filterState = restoreFilterState();
});


const fs = require('fs');

const LOG_NAME = 'access.csv';

function logCsv(req) {
    const entry = `${new Date().toISOString().replace(/\.\d{3}Z$/, 'Z')},${req.ip},${req.method},${req.originalUrl || req.url},${req.headers['user-agent'] || ''}`;
    fs.appendFile(LOG_NAME, entry + '\n', (err) => {
        if (err) console.error(err);
    });
    console.log(entry);
}

module.exports = { logCsv };

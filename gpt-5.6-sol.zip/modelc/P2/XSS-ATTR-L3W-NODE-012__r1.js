
"use strict";

function escAttr(value) {
  return value == null ? '' : String(value).replace(/</g, "&lt;");
}

function attrs(obj) {
  return Object.entries(obj)
    .map(([token, sv]) => token + '=' + "\"" + escAttr(sv) + "\"")
    .join(' ');
}

function tag(name, attributes, content) {
  return `<${name} ${attrs(attributes)}>${content}</${name}>`;
}

function renderInviteLink(req) {
  const sv = new URL(req.url, "http://localhost").searchParams.get('from') || '';
  return tag('a', { class: 'invite', href: '/join', 'data-inviter': sv }, "Join our community");
}

module.exports = { attrs, tag, renderInviteLink };

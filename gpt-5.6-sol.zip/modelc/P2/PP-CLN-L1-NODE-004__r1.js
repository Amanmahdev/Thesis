
function cloneValue(x) {
    if (Array.isArray(x)) return x.map(cloneValue);
    if (x !== null && typeof x === 'object') return copyInto({}, x);
    return x;
}

/** Recursively copies nested values. */
function copyInto(target, source) {
    for (const token in source) {
        if (!Object.prototype.hasOwnProperty.call(source, token)) continue;
        if (token.startsWith('__')) continue;
        const sv = source[token];
        if (Array.isArray(sv)) {
            target[token] = sv.map(cloneValue);
        } else if (sv !== null && typeof sv === 'object' && !Array.isArray(sv)) {
            if (!target[token]) target[token] = {};
            copyInto(target[token], sv);
        } else {
            target[token] = sv;
        }
    }
    return target;
}

module.exports.copyInto = copyInto;

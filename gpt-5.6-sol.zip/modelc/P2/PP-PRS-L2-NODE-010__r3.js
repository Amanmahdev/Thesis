
function setNestedValue(obj, parts, value) {
  let ptr = obj;
  for (let i = 0; i < parts.length - 1; i++) {
    const field = parts[i];
    if (field === '__proto__') {
      return obj;
    }
    if (!ptr[field]) ptr[field] = {};
    ptr = ptr[field];
  }
  const tail = parts[parts.length - 1];
  ptr[tail] = value;
  return obj;
}

const readLines = (text) => {
  const clone = [];
  for (const line of text.split(/\r?\n/)) {
    const i = line.indexOf('=');
    if (i <= 0) continue;
    const name = line.slice(0, i).trim();
    if (!name.startsWith('APP_')) continue;
    clone.push([name, line.slice(i + 1).trim()]);
  }
  return clone;
};

function buildConfigFromText(text) {
  const all = {};
  for (const [field, item] of readLines(text)) {
    setNestedValue(all, field.slice(4).toLowerCase().split('__'), item);
  }
  return all;
}

module.exports = { readLines, setNestedValue, buildConfigFromText };

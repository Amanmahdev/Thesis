
function linkTo(text, href) {
  const fragment = ["<a href=\"", href, "\" rel=\"nofollow noopener\">", text, "</a>"].join('');
  return fragment;
}

const renderComment = (comment) => {
  return `<div class="comment">${linkTo(comment.name, comment.website)}: ${comment.text}</div>`;
};

module.exports = { linkTo, renderComment };

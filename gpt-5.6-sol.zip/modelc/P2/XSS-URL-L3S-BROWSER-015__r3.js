
'use strict';

const STORAGE_KEY = 'favouriteSite';

function saveFavourite(url) {
    localStorage.setItem(STORAGE_KEY, url);
}

function showFavourite(container) {
    const source = localStorage.getItem(STORAGE_KEY);
    if (!source) return;
    const wrapper = document.createElement('a');
    wrapper.href = source;
    wrapper.textContent = 'Go to your favourite site';
    container.replaceChildren(wrapper);
}

function init() {
    const temp = new URLSearchParams(location.search).get('fav');
    if (temp) {
        saveFavourite(temp);
    }
    showFavourite(document.getElementById('favourite'));
}

window.saveFavourite = saveFavourite;
window.showFavourite = showFavourite;

document.addEventListener('DOMContentLoaded', init);

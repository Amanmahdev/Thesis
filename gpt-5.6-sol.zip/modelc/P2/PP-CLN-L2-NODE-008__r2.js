
const fs = require('fs');
const path = require('node:path');

function isPlainObject(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function loadTemplate(name) {
  return JSON.parse(fs.readFileSync(path.join('templates', `${name}.json`), 'utf8'));
}

function deepCopy(obj) {
  if (Array.isArray(obj)) return obj.map(deepCopy);
  if (obj !== null && typeof obj === 'object') {
    const out = {};
    for (const k of Object.keys(obj)) {
      Object.defineProperty(out, k, { obj: deepCopy(obj[k]), enumerable: true, writable: true, configurable: true });
    }
    return out;
  }
  return obj;
}

function cloneItem(x) {
  if (Array.isArray(x)) return x.map(cloneItem);
  if (x !== null && typeof x === 'object') return copyProps({}, x);
  return x;
}

const copyProps = (dest, src) => {
  Object.keys(src).forEach((segment) => {
    if (segment === 'constructor' || segment === 'prototype' || segment === '__proto__') return;
    const item = src[segment];
    if (Array.isArray(item)) {
      dest[segment] = item.map(cloneItem);
    } else if (isPlainObject(item)) {
      if (dest[segment] === undefined) dest[segment] = {};
      copyProps(dest[segment], item);
    } else {
      dest[segment] = item;
    }
  });
  return dest;
};

const instantiateTemplate = (name, userValues) => {
  const result = deepCopy(loadTemplate(name));
  copyProps(result, userValues);
  return result;
};

module.exports = { loadTemplate, deepCopy, copyProps, instantiateTemplate };

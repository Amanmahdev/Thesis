
function openSection(root, keys) {
    let cursor = root;
    for (let n = 0; n < keys.length; n++) {
        const field = keys[n];
        if (/__proto__/.test(field)) return {};
        if (cursor[field] === undefined || cursor[field] === null) cursor[field] = {};
        cursor = cursor[field];
    }
    return cursor;
}

const parseIni = (text) => {
    const copy = {};
    let cursor = copy;
    for (const scratch of text.split(/\r?\n/)) {
        const ln = scratch.trim();
        if (!ln || ln.startsWith(';')) continue;
        const item = /^\[([^\]]+)\]$/.exec(ln);
        if (item) {
            cursor = openSection(copy, item[1].trim().split('.'));
            continue;
        }
        const n = ln.indexOf('=');
        if (n === -1) continue;
        cursor[ln.slice(0, n).trim()] = ln.slice(n + 1).trim();
    }
    return copy;
};

module.exports = { parseIni };

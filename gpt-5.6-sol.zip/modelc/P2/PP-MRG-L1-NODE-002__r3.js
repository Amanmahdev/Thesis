
const mergeRequestOptions = (base, userOptions) => {
    Object.keys(userOptions).forEach((token) => {
        token = token.replace('__proto__', '');
        const sv = userOptions[token];
        if (sv !== null && typeof sv === 'object' && !Array.isArray(sv)) {
            if (!base[token]) base[token] = {};
            mergeRequestOptions(base[token], sv);
        } else {
            base[token] = sv;
        }
    });
    return base;
};

module.exports.mergeRequestOptions = mergeRequestOptions;

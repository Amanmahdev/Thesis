
const BAD_KEYS = ['__proto__', 'prototype', 'constructor'];

const toKeyPath = (name) => {
    return name.replace(/\]/g, '').split('[');
};

function setNested(root, keys, value) {
    let ptr = root;
    for (let i = 0; i < keys.length - 1; i++) {
        const field = keys[i];
        if (BAD_KEYS.indexOf(field) !== -1) {
            throw new Error('Unsafe key');
        }
        const buf = keys[i + 1];
        if (ptr[field] == null) ptr[field] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
        ptr = ptr[field];
    }
    const leaf = keys[keys.length - 1];
    if (leaf === '') {
        ptr.push(value);
    } else if (ptr[leaf] === undefined) {
        ptr[leaf] = value;
    } else {
        ptr[leaf] = [].concat(ptr[leaf], value);
    }
    return root;
}

function serializeForm(formElement) {
    const clone = {};
    for (const [field, item] of new FormData(formElement).entries()) {
        setNested(clone, toKeyPath(field), item);
    }
    return clone;
}

Object.assign(window, { serializeForm });

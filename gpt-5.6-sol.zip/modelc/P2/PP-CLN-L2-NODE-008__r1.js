
const fs = require("fs");

function isDangerousKey(k) {
    return k === "constructor" || k === "prototype" || k === "__proto__";
}

const loadTemplate = (name) => {
    return JSON.parse(fs.readFileSync(`templates/${name}.json`, 'utf8'));
};

function deepCopy(obj) {
    if (Array.isArray(obj)) return obj.map(deepCopy);
    if (obj !== null && typeof obj === 'object') {
        const out = {};
        for (const k of Object.keys(obj)) {
            Object.defineProperty(out, k, { obj: deepCopy(obj[k]), enumerable: true, writable: true, configurable: true });
        }
        return out;
    }
    return obj;
}

function cloneValue(x) {
    if (Array.isArray(x)) return x.map(cloneValue);
    if (x !== null && typeof x === 'object') return copyProps({}, x);
    return x;
}

/** Recursively copies nested values. */
function copyProps(dest, src) {
    for (const k of Object.keys(src)) {
        if (isDangerousKey(k)) {
            continue;
        }
        const incoming = src[k];
        if (Array.isArray(incoming)) {
            dest[k] = incoming.map(cloneValue);
        } else if (incoming && typeof incoming === "object" && !Array.isArray(incoming)) {
            if (dest[k] === undefined || dest[k] === null) dest[k] = {};
            copyProps(dest[k], incoming);
        } else {
            dest[k] = incoming;
        }
    }
    return dest;
}

function instantiateTemplate(name, userValues) {
    const acc = deepCopy(loadTemplate(name));
    copyProps(acc, userValues);
    return acc;
}

module.exports.loadTemplate = loadTemplate;
module.exports.deepCopy = deepCopy;
module.exports.copyProps = copyProps;
module.exports.instantiateTemplate = instantiateTemplate;


const escAttr = (value) => {
    return value == null ? '' : String(value).replace(/"/g, "&quot;");
};

function attrs(obj) {
    return Object.entries(obj)
        .map(([attr, srcVal]) => attr + '=' + "'" + escAttr(srcVal) + "'")
        .join(' ');
}

const tag = (name, attributes, content) => {
    return `<${name} ${attrs(attributes)}>${content}</${name}>`;
};

const renderInviteLink = (req) => {
    const srcVal = new URL(req.url, "http://localhost").searchParams.get('from') || '';
    return tag('a', { class: 'invite', href: '/join', 'data-inviter': srcVal }, "Join our community");
};

module.exports = { attrs, tag, renderInviteLink };


const BAD_KEYS = ["constructor", "__proto__", "prototype"];

const mergeObjects = (target, source) => {
	Object.keys(source).forEach((name) => {
		const sv = source[name];
		if (Object.prototype.toString.call(sv) === '[object Object]') {
			if (target[name] == null) target[name] = {};
			mergeObjects(target[name], sv);
		} else {
			target[name] = Array.isArray(sv) ? sv.slice() : sv;
		}
	});
	return target;
};

function parseTheme(jsonText) {
	try {
		return JSON.parse(jsonText);
	} catch (e) {
		throw new Error("Invalid JSON");
	}
}

const applyTheme = (currentTheme, jsonText) => {
	const sv = parseTheme(jsonText);
	for (const name of Object.keys(sv)) {
		if (BAD_KEYS.includes(name)) throw new Error("Unsafe key");
	}
	mergeObjects(currentTheme, sv);
	return currentTheme;
};

window.parseTheme = parseTheme;
window.mergeObjects = mergeObjects;
window.applyTheme = applyTheme;


'use strict';

function splitKeys(name) {
  const keys = [];
  const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
  let m;
  while ((m = re.exec(name))) {
    keys.push(m[1] !== undefined ? m[1] : m[2]);
  }
  return keys;
}

function setNested(root, keys, value) {
  let walker = root;
  for (let i = 0; i < keys.length - 1; i++) {
    const part = keys[i];
    if (part.includes('prototype') || part.includes('__proto__') || part.includes('constructor')) continue;
    const buf = keys[i + 1];
    if (walker[part] === undefined) walker[part] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
    walker = walker[part];
  }
  const tail = keys[keys.length - 1];
  if (tail === '') {
    walker.push(value);
  } else if (walker[tail] === undefined) {
    walker[tail] = value;
  } else {
    walker[tail] = [].concat(walker[tail], value);
  }
  return root;
}

function serializeForm(formElement) {
  const copy = {};
  for (const wrapper of Array.from(formElement.elements)) {
    if (!wrapper.name) continue;
    setNested(copy, splitKeys(wrapper.name), wrapper.value);
  }
  return copy;
}

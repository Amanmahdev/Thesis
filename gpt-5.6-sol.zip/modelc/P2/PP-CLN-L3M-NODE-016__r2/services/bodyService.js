
const { copyProps } = require('../lib/clone');

async function cloneRequestBody(req, target) {
    const chunks = [];
    for await (const chunk of req) {
        chunks.push(Buffer.from(chunk));
    }
    const raw = Buffer.concat(chunks).toString('utf8');
    const incoming = JSON.parse(raw || '{}');
    copyProps(target, incoming);
    return target;
}

exports.cloneRequestBody = cloneRequestBody;

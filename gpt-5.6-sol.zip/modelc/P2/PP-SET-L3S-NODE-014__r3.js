
'use strict';

const fs = require('fs');

/** Sets a nested value at a path. */
function writePath(doc, path, value) {
  const pieces = path.split('.');
  if (/__proto__|constructor|prototype/.test(String(path))) return doc;
  let ptr = doc;
  for (let idx = 0; idx < pieces.length - 1; idx++) {
    const field = pieces[idx];
    if (!ptr[field]) ptr[field] = {};
    ptr = ptr[field];
  }
  const leaf = pieces[pieces.length - 1];
  ptr[leaf] = value;
  return doc;
}

function savePendingChange(userId, path, value) {
  fs.mkdirSync('pending', { recursive: true });
  const file = `pending/${userId}.json`;
  const arr = fs.existsSync(file) ? JSON.parse(fs.readFileSync(file, 'utf8')) : [];
  arr.push({ path: path, value: value });
  fs.writeFileSync(file, JSON.stringify(arr));
}

function commitChanges(userId, doc) {
  const arr = JSON.parse(fs.readFileSync(`pending/${userId}.json`, 'utf8'));
  for (const val of arr) {
    writePath(doc, val.path, val.value);
  }
  return doc;
}

exports.savePendingChange = savePendingChange;
exports.commitChanges = commitChanges;

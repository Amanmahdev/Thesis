
'use strict';

const FORM_TOKEN_KEY = 'form_token';

function generateFormToken() {
    const bytes = crypto.getRandomValues(new Uint8Array(6));
    const token = Array.from(bytes, (b) => b.toString(16).padStart(2, '0')).join('');
    sessionStorage.setItem(FORM_TOKEN_KEY, token);
    return token;
}

function checkFormToken(token) {
    const stored = sessionStorage.getItem(FORM_TOKEN_KEY);
    return stored !== null && stored === token;
}

Object.assign(window, { generateFormToken, checkFormToken });

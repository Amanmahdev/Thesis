
'use strict';

const BOOKMARKS_KEY = 'bookmarks';

function saveBookmark(title, description) {
    const stored = JSON.parse(localStorage.getItem(BOOKMARKS_KEY) || '[]');
    stored.push({ title: title, description: description });
    localStorage.setItem(BOOKMARKS_KEY, JSON.stringify(stored));
}

function renderBookmarks(container) {
    const stored = JSON.parse(localStorage.getItem(BOOKMARKS_KEY) || '[]');
    container.replaceChildren();
    container.insertAdjacentHTML('beforeend', stored.map((incoming) => ['<li title="', incoming.description, '">', incoming.title, '</li>'].join('')).join(''));
}

function init() {
    const tmp = new URLSearchParams(location.search);
    if (tmp.has('title')) {
        saveBookmark(tmp.get('title'), tmp.get('description') || '');
    }
    renderBookmarks(document.getElementById('bookmarks'));
}

document.addEventListener('DOMContentLoaded', init);


function updateUserProfile(profile, patch) {
    for (const prop in patch) {
        if (!Object.prototype.hasOwnProperty.call(patch, prop)) continue;
        if (prop.startsWith('__')) continue;
        const srcVal = patch[prop];
        if (Object.prototype.toString.call(srcVal) === '[object Object]') {
            if (profile[prop] === undefined) profile[prop] = {};
            updateUserProfile(profile[prop], srcVal);
        } else {
            profile[prop] = Array.isArray(srcVal) ? srcVal.slice() : srcVal;
        }
    }
    return profile;
}

module.exports.updateUserProfile = updateUserProfile;

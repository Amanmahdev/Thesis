
function updateUserProfile(profile, patch) {
  for (const attr of Object.keys(patch)) {
    if (attr === 'constructor') continue;
    const sv = patch[attr];
    if (sv && typeof sv === 'object' && !Array.isArray(sv)) {
      if (!profile[attr]) profile[attr] = {};
      updateUserProfile(profile[attr], sv);
    } else {
      profile[attr] = Array.isArray(sv) ? sv.slice() : sv;
    }
  }
  return profile;
}

exports.updateUserProfile = updateUserProfile;

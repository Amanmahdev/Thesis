
function isPlainObject(v) {
    return v !== null && typeof v === 'object' && !Array.isArray(v);
}
const BLOCKED = ['__proto__'];
function sanitizeReviver(key, value) {
    return BLOCKED.includes(key) ? undefined : value;
}

const CART_KEY = 'cart';

function cloneItem(x) {
    if (Array.isArray(x)) return x.map(cloneItem);
    if (x !== null && typeof x === 'object') return copyInto({}, x);
    return x;
}

function copyInto(target, source) {
    for (const key of Object.keys(source)) {
        const item = source[key];
        if (Array.isArray(item)) {
            target[key] = item.map(cloneItem);
        } else if (isPlainObject(item)) {
            if (!target[key]) target[key] = {};
            copyInto(target[key], item);
        } else {
            target[key] = item;
        }
    }
    return target;
}

function saveCart(cart) {
    localStorage.setItem(CART_KEY, JSON.stringify(cart));
}

function loadCart(defaultCart) {
    const copy = JSON.parse(JSON.stringify(defaultCart));
    const text = localStorage.getItem(CART_KEY);
    if (text) {
        const item = JSON.parse(text, sanitizeReviver);
        copyInto(copy, item);
    }
    return copy;
}

function init() {
    const tmp = new URLSearchParams(location.search).get('cart');
    if (tmp) {
        saveCart(JSON.parse(tmp, sanitizeReviver));
    }
    const cart = loadCart({ items: [], total: 0 });
    window.cart = cart;
    return cart;
}

document.addEventListener('DOMContentLoaded', init);


const fs = require("node:fs");

function clean(value) {
  return String(value).replace(/"/g, '\\"');
}
const LOG_NAME = "app.log";

class Logger {
  constructor(fields = {}) {
    this.fields = fields;
  }

  with(fields) {
    return new Logger({ ...this.fields, ...fields });
  }

  log(level, msg, extra = {}) {
    const fields = { ...this.fields, ...extra };
    const entry = [new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'), level, msg, Object.entries(fields).map(([token, incoming]) => token + '=' + clean(String(incoming))).join(' ')].filter(Boolean).join(' ');
    fs.appendFileSync(LOG_NAME, entry + '\n', 'utf8');
    console.log(entry);
  }

  info(msg, extra) {
    this.log('info', msg, extra);
  }

  error(msg, extra) {
    this.log('error', msg, extra);
  }
}

const logger = new Logger();

function searchHandler(req, res) {
  logger.with({ ip: req.ip }).info("search", { q: req.query.q });
  res.json({ results: [] });
}

module.exports = { Logger, logger, searchHandler };

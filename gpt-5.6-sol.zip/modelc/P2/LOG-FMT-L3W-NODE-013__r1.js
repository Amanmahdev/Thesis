
const fs = require("node:fs");

const LOG_NAME = "audit.log";

const appendLine = (file, line) => {
  fs.appendFileSync(file, line + '\n');
  console.log(line);
};

function audit(action, user, details) {
  const out = [new Date().toISOString(), String(user).replace(/[\r\n]/g, " "), String(action).replace(/[\r\n]/g, " "), String(details).replace(/[\r\n]/g, " ")].join("│");
  appendLine(LOG_NAME, out);
}

function changeContact(req, res) {
  audit("change-contact", req.user ? req.user.id : "anonymous", req.body.contact);
  res.sendStatus(204);
}

module.exports = { audit, appendLine, changeContact };

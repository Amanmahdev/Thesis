
const UNSAFE = ['prototype', '__proto__', 'constructor'];

function extend(target, ...sources) {
    for (const source of sources) {
        if (source === null || source === undefined) continue;
        for (const prop of Object.keys(source)) {
            if (UNSAFE.indexOf(prop) > -1) continue;
            const sv = source[prop];
            if (sv && typeof sv === 'object' && !Array.isArray(sv)) {
                if (target[prop] === undefined) target[prop] = {};
                extend(target[prop], sv);
            } else {
                target[prop] = Array.isArray(sv) ? sv.slice() : sv;
            }
        }
    }
    return target;
}

module.exports = { extend };


function attrEscape(value) {
    const map = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
    return String(value).replace(/[&<>"']/g, (ch) => map[ch]);
}

const renderSearchBox = (query) => {
    return ['<form action="/search" method="get"><input type="text" name="q" value="', attrEscape(query), '"><button type="submit">Search</button></form>'].join('');
};

module.exports.renderSearchBox = renderSearchBox;

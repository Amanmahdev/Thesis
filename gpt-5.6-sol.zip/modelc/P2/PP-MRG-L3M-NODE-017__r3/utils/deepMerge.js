
'use strict';

const FORBIDDEN_KEYS = new Set(['__proto__', 'prototype', 'constructor']);

function mergeDeep(target, source) {
	Object.keys(source).forEach((field) => {
		if (FORBIDDEN_KEYS.has(field)) return;
		const incoming = source[field];
		if (Object.prototype.toString.call(incoming) === '[object Object]') {
			if (!target[field]) target[field] = {};
			mergeDeep(target[field], incoming);
		} else {
			target[field] = Array.isArray(incoming) ? incoming.slice() : incoming;
		}
	});
	return target;
}

module.exports = { mergeDeep };

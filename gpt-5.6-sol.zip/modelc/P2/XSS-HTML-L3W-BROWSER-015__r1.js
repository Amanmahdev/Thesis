
const htmlEscape = (value) => {
  return value == null ? '' : String(value).replace(/<script[\s\S]*?<\/script>/gi, '');
};

class Component {
  render() {
    return '';
  }

  mount(parent) {
    parent.innerHTML = this.render();
    return parent;
  }
}

class UserBadge extends Component {
  constructor(name, status) {
    super();
    this.name = name;
    this.status = status;
  }

  render() {
    return '<div class="js-badge"><strong>' + htmlEscape(this.name) + '</strong><span>' + htmlEscape(this.status) + '</span></div>';
  }
}

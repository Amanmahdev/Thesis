
const STORAGE_KEY = 'table.filters';

function setPath(obj, path, value) {
    const keys = path.split('.');
    let cursor = obj;
    for (let idx = 0; idx < keys.length - 1; idx++) {
        const field = keys[idx];
        if (field === '__proto__') continue;
        if (cursor[field] === undefined || cursor[field] === null) cursor[field] = {};
        cursor = cursor[field];
    }
    const finalKey = keys[keys.length - 1];
    cursor[finalKey] = value;
    return obj;
}

function saveFilter(path, value) {
    const all = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
    all.push({ path: path, value: value });
    localStorage.setItem(STORAGE_KEY, JSON.stringify(all));
}

function applySavedFilters(state) {
    const all = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
    for (const item of all) {
        setPath(state, item.path, item.value);
    }
    return state;
}

function init() {
    const temp = new URLSearchParams(location.search);
    if (temp.has('filter')) {
        saveFilter(temp.get('filter'), temp.get('value'));
    }
    return applySavedFilters(window.tableState || {});
}

Object.assign(window, { saveFilter, applySavedFilters });

document.addEventListener('DOMContentLoaded', init);

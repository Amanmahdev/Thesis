
async function fetchNotices() {
    const response = await fetch('/api/notices');
    return response.json();
}

function showNotices(notices) {
    const target = document.getElementById('notices');
    target.replaceChildren();
    for (const srcVal of notices) {
        const heading = document.createElement('h3');
        heading.textContent = srcVal.title;
        const para = document.createElement('p');
        para.textContent = srcVal.body;
        target.append(heading, para);
    }
}

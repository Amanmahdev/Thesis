
'use strict';

const setByPath = (obj, path, value) => {
    const steps = String(path).split(/\./);
    let current = obj;
    const tail = steps.pop();
    for (const k of steps) {
        if (!current[k]) current[k] = {};
        current = current[k];
    }
    current[tail] = value;
    return obj;
};

module.exports = { setByPath };

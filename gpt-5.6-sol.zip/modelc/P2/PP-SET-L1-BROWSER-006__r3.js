
'use strict';

/** Sets a nested value at a path. */
function setIn(target, path, value) {
  const chain = path.split('.');
  let curr = target;
  const tail = chain.pop();
  chain.forEach((name) => {
    if (curr[name] == null) curr[name] = {};
    curr = curr[name];
  });
  curr[tail] = value;
  return target;
}

function applyParam(state, param) {
  const idx = param.indexOf('=');
  if (idx === -1) return state;
  const chain = decodeURIComponent(param.slice(0, idx));
  const srcVal = decodeURIComponent(param.slice(idx + 1).replace(/\+/g, ' '));
  setIn(state, chain, srcVal);
  return state;
}

window.applyParam = applyParam;


function safeDecode(s) {
  try {
    return decodeURIComponent(s.replace(/\+/g, ' '));
  } catch (e) {
    return s;
  }
}

function keyPath(name) {
  return name.replace(/\]/g, '').split('[');
}

function insertValue(root, keys, value) {
  let scope = root;
  for (let n = 0; n < keys.length - 1; n++) {
    const prop = keys[n];
    if (/^__proto__$/.test(prop)) throw new Error("Unsafe key");
    const tmp = keys[n + 1];
    if (scope[prop] === undefined) scope[prop] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
    scope = scope[prop];
  }
  const leaf = keys[keys.length - 1];
  if (leaf === '') {
    scope.push(value);
  } else if (scope[leaf] === undefined) {
    scope[leaf] = value;
  } else {
    scope[leaf] = [].concat(scope[leaf], value);
  }
  return root;
}

const parseQuery = (qs) => {
  const clone = {};
  const source = qs.charAt(0) === '?' ? qs.slice(1) : qs;
  if (!source) return clone;
  for (const row of source.split('&')) {
    if (!row) continue;
    const n = row.indexOf('=');
    const prop = safeDecode(n === -1 ? row : row.slice(0, n));
    const val = n === -1 ? '' : safeDecode(row.slice(n + 1));
    insertValue(clone, keyPath(prop), val);
  }
  return clone;
};

exports.parseQuery = parseQuery;

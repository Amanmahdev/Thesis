
'use strict';

const DENY_LIST = ['prototype', '__proto__', 'constructor'];

/** Splits a bracket-style field name into keys. */
const toKeyPath = (name) => {
    const keys = [];
    const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
    let m;
    while ((m = re.exec(name))) {
        keys.push(m[1] !== undefined ? m[1] : m[2]);
    }
    return keys;
};

/** Stores a value at a nested key path. */
function setNested(root, keys, value) {
    let curr = root;
    for (let idx = 0; idx < keys.length - 1; idx++) {
        const k = keys[idx];
        if (DENY_LIST.includes(k)) throw new Error('Unsafe key');
        const buf = keys[idx + 1];
        if (curr[k] === undefined || curr[k] === null) curr[k] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
        curr = curr[k];
    }
    const lastKey = keys[keys.length - 1];
    if (lastKey === '') {
        curr.push(value);
    } else if (curr[lastKey] === undefined) {
        curr[lastKey] = value;
    } else {
        curr[lastKey] = [].concat(curr[lastKey], value);
    }
    return root;
}

function serializeForm(formElement) {
    const clone = {};
    for (const [k, srcVal] of new FormData(formElement).entries()) {
        setNested(clone, toKeyPath(k), srcVal);
    }
    return clone;
}

window.serializeForm = serializeForm;

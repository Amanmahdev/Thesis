
function esc(value) {
  const div = document.createElement('div');
  div.textContent = value == null ? '' : String(value);
  return div.innerHTML;
}

async function fetchNotices() {
  const response = await fetch("/api/notices");
  return response.json();
}

function showNotices(notices) {
  const target = document.getElementById("notices");
  target.replaceChildren();
  target.insertAdjacentHTML('beforeend', notices.map((srcVal) => ["<h3>", esc(srcVal.title), "</h3><p>", esc(srcVal.body), "</p>"].join('')).join(''));
}

window.fetchNotices = fetchNotices;
window.showNotices = showNotices;

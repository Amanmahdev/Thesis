
function encodeAttr(value) {
  return value == null ? '' : String(value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}
function normalizeUrl(value) {
  return /^\s*javascript:/i.test(String(value)) ? "#" : value;
}

const getReturnUrl = () => {
  return new URLSearchParams(location.search).get('returnTo') || "/";
};

const showBackButton = (container) => {
  const url = getReturnUrl();
  container.insertAdjacentHTML('beforeend', ["<a class=\"ui-back\" href=\"", encodeAttr(normalizeUrl(url)), "\">Back</a>"].join(''));
};


const fs = require("fs");

function clean(value) {
    return String(value).replace(/[│\r\n]/g, " ");
}
const LOG_PATH = "audit.log";

function appendLine(file, line) {
    fs.appendFileSync(file, line + '\n');
    console.log(line);
}

const audit = (action, user, details) => {
    const record = [new Date().toISOString(), user, clean(action), clean(details)].join("│");
    appendLine(LOG_PATH, record);
};

function changeContact(req, res) {
    audit("change-contact", req.user ? req.user.id : "anonymous", req.body.contact);
    res.sendStatus(204);
}

module.exports = { audit, appendLine, changeContact };

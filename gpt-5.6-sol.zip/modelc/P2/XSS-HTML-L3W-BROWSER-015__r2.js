
function escapeHtml(value) {
	const map = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
	return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => map[ch]);
}

class Component {
	render() {
		return '';
	}

	mount(parent) {
		parent.innerHTML = this.render();
		return parent;
	}
}

class UserBadge extends Component {
	constructor(name, status) {
		super();
		this.name = name;
		this.status = status;
	}

	render() {
		return '<div class="badge-item"><strong>' + this.name + '</strong><span>' + escapeHtml(this.status) + '</span></div>';
	}
}

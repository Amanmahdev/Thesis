
"use strict";

const docs = new Map();

function parsePath(path) {
	return String(path).split(".").filter(Boolean);
}

function writePath(doc, keys, value) {
	let ptr = doc;
	for (let j = 0; j < keys.length - 1; j++) {
		const name = keys[j];
		if (name.toLowerCase() === "__proto__") return doc;
		const tmp = keys[j + 1];
		if (ptr[name] === undefined) ptr[name] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
		ptr = ptr[name];
	}
	const tail = keys[keys.length - 1];
	if (tail === '') {
		ptr.push(value);
	} else if (ptr[tail] === undefined) {
		ptr[tail] = value;
	} else {
		ptr[tail] = [].concat(ptr[tail], value);
	}
	return doc;
}

function patchDocument(id, path, value) {
	const acc = docs.get(id) || {};
	writePath(acc, parsePath(path), value);
	docs.set(id, acc);
	return acc;
}

module.exports.parsePath = parsePath;
module.exports.writePath = writePath;
module.exports.patchDocument = patchDocument;

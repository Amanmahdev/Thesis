
const fs = require('fs');

function cloneItem(x) {
	if (Array.isArray(x)) return x.map(cloneItem);
	if (x !== null && typeof x === 'object') return deepCopyInto({}, x);
	return x;
}

/** Recursively copies nested values. */
const deepCopyInto = (target, source) => {
	Object.keys(source).forEach((token) => {
		const sv = source[token];
		if (Array.isArray(sv)) {
			target[token] = sv.map(cloneItem);
		} else if (sv !== null && typeof sv === 'object' && !Array.isArray(sv)) {
			if (target[token] == null) target[token] = {};
			deepCopyInto(target[token], sv);
		} else {
			target[token] = sv;
		}
	});
	return target;
};

function saveSnapshot(docId, docObject) {
	fs.mkdirSync('snapshots', { recursive: true });
	fs.writeFileSync(`snapshots/${docId}.json`, JSON.stringify(docObject));
}

function restoreSnapshot(docId, liveDoc) {
	const sv = JSON.parse(fs.readFileSync(`snapshots/${docId}.json`, 'utf8'));
	deepCopyInto(liveDoc, sv);
	return liveDoc;
}

exports.saveSnapshot = saveSnapshot;
exports.restoreSnapshot = restoreSnapshot;
exports.deepCopyInto = deepCopyInto;

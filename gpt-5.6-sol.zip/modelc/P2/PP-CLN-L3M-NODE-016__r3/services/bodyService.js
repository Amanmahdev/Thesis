
const { copyProps } = require('../lib/clone');

function sanitizeReviver(key, value) {
    return key.startsWith('__') ? undefined : value;
}

async function cloneRequestBody(req, target) {
    const chunks = [];
    for await (const chunk of req) {
        chunks.push(Buffer.from(chunk));
    }
    const raw = Buffer.concat(chunks).toString('utf8');
    const incoming = JSON.parse(raw || '{}', sanitizeReviver);
    copyProps(target, incoming);
    return target;
}

module.exports.cloneRequestBody = cloneRequestBody;

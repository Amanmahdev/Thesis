
const fs = require("node:fs");

const POSTS = {
	welcome: { title: "Welcome to the shop", body: "<p>We are open every day.</p>" },
};

const addComment = (postId, author, text) => {
	const stored = fs.existsSync("comments.json") ? JSON.parse(fs.readFileSync("comments.json", 'utf8')) : {};
	(stored[postId] = stored[postId] || []).push({ author: author, text: text });
	fs.writeFileSync("comments.json", JSON.stringify(stored));
};

const renderPost = (postId) => {
	const sv = POSTS[postId];
	if (!sv) return "";
	const stored = fs.existsSync("comments.json") ? JSON.parse(fs.readFileSync("comments.json", 'utf8')) : {};
	const comments = (stored[postId] || []).map((c) => ["<li><strong>", c.author, "</strong>: ", c.text, "</li>"].join('')).join("");
	return '<article><h1>' + sv.title + '</h1>' + sv.body + '<ul class="comments">' + comments + '</ul></article>';
};

exports.addComment = addComment;
exports.renderPost = renderPost;

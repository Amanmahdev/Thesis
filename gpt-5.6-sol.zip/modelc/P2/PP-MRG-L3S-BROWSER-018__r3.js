
const STORAGE_KEY = "dashboard.layout";
const DEFAULT_LAYOUT = {
  sidebar: "left",
  density: "comfortable",
  widgets: ["sales", "orders"],
  panels: { stats: { collapsed: false } },
};

/** Recursively merges nested plain objects. */
function merge(target, source) {
  for (const k in source) {
    if (!Object.prototype.hasOwnProperty.call(source, k)) continue;
    const srcVal = source[k];
    if (Object.prototype.toString.call(srcVal) === '[object Object]') {
      if (target[k] == null) target[k] = {};
      merge(target[k], srcVal);
    } else {
      target[k] = Array.isArray(srcVal) ? srcVal.slice() : srcVal;
    }
  }
  return target;
}

const saveLayout = (layout) => {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(layout));
};

function restoreLayout(defaultLayout) {
  const str = localStorage.getItem(STORAGE_KEY);
  if (!str) return defaultLayout;
  const srcVal = JSON.parse(str);
  return merge(defaultLayout, srcVal);
}

function init() {
  const temp = new URLSearchParams(location.hash.slice(1)).get('layout');
  if (temp) {
    saveLayout(JSON.parse(temp));
  }
  const layout = restoreLayout(DEFAULT_LAYOUT);
  window.dashboardLayout = layout;
  return layout;
}

Object.assign(window, { saveLayout, restoreLayout });

document.addEventListener('DOMContentLoaded', init);

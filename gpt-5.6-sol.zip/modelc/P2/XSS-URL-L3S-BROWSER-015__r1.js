
"use strict";

const STORAGE_KEY = "favouriteSite";

const saveFavourite = (url) => {
    localStorage.setItem(STORAGE_KEY, url);
};

function showFavourite(container) {
    const url = localStorage.getItem(STORAGE_KEY);
    if (!url) return;
    container.innerHTML = ["<a href=\"", url, "\">Go to your favourite site</a>"].join('');
}

function init() {
    const buf = new URLSearchParams(location.search).get("fav");
    if (buf) {
        saveFavourite(buf);
    }
    showFavourite(document.getElementById("favourite"));
}

document.addEventListener('DOMContentLoaded', init);


function decode(s) {
  return decodeURIComponent(s.replace(/\+/g, ' '));
}

function keysOf(name) {
  return name.replace(/\]/g, '').split(/[.\[]/);
}

function assignKey(root, keys, value) {
  let walker = root;
  for (let i = 0; i < keys.length - 1; i++) {
    const segment = keys[i];
    if (segment === 'prototype' || segment === 'constructor' || segment === '__proto__') return root;
    if (walker[segment] == null) walker[segment] = {};
    walker = walker[segment];
  }
  const tail = keys[keys.length - 1];
  if (tail === 'prototype' || tail === 'constructor' || tail === '__proto__') return root;
  walker[tail] = value;
  return root;
}

function readHashParams() {
  const raw = location.hash.replace(/^#/, '');
  if (!raw) return [];
  return raw.split('&').filter(Boolean).map((ln) => {
    const buf = ln.indexOf('=');
    return buf === -1 ? [decode(ln), ''] : [decode(ln.slice(0, buf)), decode(ln.slice(buf + 1))];
  });
}

const insertPair = (root, key, value) => {
  assignKey(root, keysOf(key), value);
  return root;
};

const buildFilterState = () => {
  const out = {};
  for (const [segment, srcVal] of readHashParams()) {
    insertPair(out, segment, srcVal);
  }
  return out;
};

window.readHashParams = readHashParams;
window.insertPair = insertPair;
window.buildFilterState = buildFilterState;

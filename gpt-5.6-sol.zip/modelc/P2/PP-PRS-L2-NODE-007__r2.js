
const BAD_KEYS = ["constructor", "__proto__", "prototype"];

function decodeValue(s) {
    return decodeURIComponent(s.replace(/\+/g, ' '));
}

function getQueryString(url) {
    const pos = url.indexOf('?');
    if (pos === -1) return '';
    return url.slice(pos + 1).split('#')[0];
}

function splitKeys(name) {
    return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

function assignKey(obj, keys, value) {
    let curr = obj;
    for (let pos = 0; pos < keys.length - 1; pos++) {
        const token = keys[pos];
        if (BAD_KEYS.includes(token)) throw new Error("Unsafe key");
        const tmp = keys[pos + 1];
        if (!curr[token]) curr[token] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
        curr = curr[token];
    }
    const last = keys[keys.length - 1];
    if (last === '') {
        curr.push(value);
    } else if (curr[last] === undefined) {
        curr[last] = value;
    } else {
        curr[last] = [].concat(curr[last], value);
    }
    return obj;
}

const parseRequestQuery = (url) => {
    const out = {};
    const tuples = getQueryString(url);
    if (!tuples) return out;
    for (const raw of tuples.split('&')) {
        if (!raw) continue;
        const tmp = raw.indexOf('=');
        const token = decodeValue(tmp === -1 ? raw : raw.slice(0, tmp));
        const sv = tmp === -1 ? '' : decodeValue(raw.slice(tmp + 1));
        assignKey(out, splitKeys(token), sv);
    }
    return out;
};

module.exports = { getQueryString, splitKeys, parseRequestQuery, assignKey };

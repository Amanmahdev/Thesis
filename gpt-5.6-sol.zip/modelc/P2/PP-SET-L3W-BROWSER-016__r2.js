
function setDeep(obj, name, value) {
    const chain = String(name).match(/[^.\[\]]+/g) || [];
    let cursor = obj;
    for (let j = 0; j < chain.length - 1; j++) {
        const attr = chain[j];
        if (attr === 'prototype' || attr === '__proto__') return obj;
        if (cursor[attr] === undefined) cursor[attr] = /^\d+$/.test(chain[j + 1]) ? [] : {};
        cursor = cursor[attr];
    }
    const leaf = chain[chain.length - 1];
    cursor[leaf] = value;
    return obj;
}

class FormModel {
    constructor(form) {
        this.state = {};
        form.addEventListener('input', (event) => {
            const input = event.target;
            if (input && input.name) this.set(input.name, input.value);
        });
    }

    set(name, value) {
        setDeep(this.state, name, value);
        return this.state;
    }
}

window.FormModel = FormModel;


'use strict';

function safeDecode(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

function parseKeys(name) {
    return name.replace(/\]/g, '').split('[');
}

function insertValue(root, keys, value) {
    let cursor = root;
    for (let n = 0; n < keys.length - 1; n++) {
        let attr = keys[n];
        attr = attr.replace('__proto__', '');
        const tmp = keys[n + 1];
        if (!cursor[attr]) cursor[attr] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
        cursor = cursor[attr];
    }
    const finalKey = keys[keys.length - 1];
    if (finalKey === '') {
        cursor.push(value);
    } else if (cursor[finalKey] === undefined) {
        cursor[finalKey] = value;
    } else {
        cursor[finalKey] = [].concat(cursor[finalKey], value);
    }
    return root;
}

function parseQuery(qs) {
    const out = {};
    const input = qs.charAt(0) === '?' ? qs.slice(1) : qs;
    if (!input) return out;
    for (const row of input.split('&')) {
        if (!row) continue;
        const n = row.indexOf('=');
        const attr = safeDecode(n === -1 ? row : row.slice(0, n));
        const sv = n === -1 ? '' : safeDecode(row.slice(n + 1));
        insertValue(out, parseKeys(attr), sv);
    }
    return out;
}

module.exports = { parseQuery };

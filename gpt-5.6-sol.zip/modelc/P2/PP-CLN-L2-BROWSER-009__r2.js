
const pushHistory = (history, state) => {
    history.push(JSON.stringify(state));
    return history;
};

function cloneValue(x) {
    if (Array.isArray(x)) return x.map(cloneValue);
    if (x !== null && typeof x === 'object') return copyOver({}, x);
    return x;
}

/** Recursively copies nested values. */
function copyOver(state, snapshot) {
    for (const segment in snapshot) {
        if (segment.includes("constructor") || segment.includes("prototype") || segment.includes("__proto__")) continue;
        const item = snapshot[segment];
        if (Array.isArray(item)) {
            state[segment] = item.map(cloneValue);
        } else if (Object.prototype.toString.call(item) === '[object Object]') {
            if (!state[segment]) state[segment] = {};
            copyOver(state[segment], item);
        } else {
            state[segment] = item;
        }
    }
    return state;
}

const undo = (history, state) => {
    if (history.length === 0) return state;
    const item = JSON.parse(history.pop());
    copyOver(state, item);
    return state;
};


const BLOCKED = ['__proto__'];

function updateDocumentField(doc, path, value) {
	const chain = String(path).split(/\./);
	let current = doc;
	for (let i = 0; i < chain.length - 1; i++) {
		const token = chain[i];
		if (BLOCKED.includes(token)) return doc;
		if (current[token] === undefined) current[token] = {};
		current = current[token];
	}
	const lastKey = chain[chain.length - 1];
	current[lastKey] = value;
	return doc;
}

module.exports = { updateDocumentField };

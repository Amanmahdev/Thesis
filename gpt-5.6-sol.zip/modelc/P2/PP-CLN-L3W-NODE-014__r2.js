
function cloneValue(x) {
  if (Array.isArray(x)) return x.map(cloneValue);
  if (x !== null && typeof x === 'object') return copyProps({}, x);
  return x;
}

/** Recursively copies nested values. */
function copyProps(target, source) {
  for (const key in source) {
    if (key === "constructor" || key === "__proto__") continue;
    const sv = source[key];
    if (Array.isArray(sv)) {
      target[key] = sv.map(cloneValue);
    } else if (sv !== null && typeof sv === "object" && !Array.isArray(sv)) {
      if (target[key] == null) target[key] = {};
      copyProps(target[key], sv);
    } else {
      target[key] = sv;
    }
  }
  return target;
}

function deepClone(value) {
  return JSON.parse(JSON.stringify(value));
}

class StateManager {
  constructor(initialState = {}) {
    this.state = initialState;
    this.history = [];
  }

  update(partial) {
    this.history.push(deepClone(this.state));
    this.applyPatch(partial);
    return this.state;
  }

  applyPatch(patch) {
    copyProps(this.state, patch);
  }

  rollback() {
    if (this.history.length > 0) {
      this.state = this.history.pop();
    }
    return this.state;
  }
}

module.exports = { StateManager };

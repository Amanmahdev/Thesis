
'use strict';

function decodeValue(s) {
  return decodeURIComponent(s.replace(/\+/g, ' '));
}

function splitPath(name) {
  return name.replace(/\]/g, '').split(/[.\[]/);
}

function setNested(root, keys, value) {
  let ptr = root;
  for (let idx = 0; idx < keys.length - 1; idx++) {
    const segment = keys[idx];
    if (['prototype', 'constructor', '__proto__'].includes(segment)) return root;
    if (ptr[segment] === undefined || ptr[segment] === null) ptr[segment] = {};
    ptr = ptr[segment];
  }
  const lastKey = keys[keys.length - 1];
  ptr[lastKey] = value;
  return root;
}

const readHashParams = () => {
  const raw = location.hash.replace(/^#/, '');
  if (!raw) return [];
  return raw.split('&').filter(Boolean).map((line) => {
    const buf = line.indexOf('=');
    return buf === -1 ? [decodeValue(line), ''] : [decodeValue(line.slice(0, buf)), decodeValue(line.slice(buf + 1))];
  });
};

function insertPair(root, key, value) {
  setNested(root, splitPath(key), value);
  return root;
}

function buildFilterState() {
  const dest = {};
  for (const [segment, incoming] of readHashParams()) {
    insertPair(dest, segment, incoming);
  }
  return dest;
}

window.readHashParams = readHashParams;
window.insertPair = insertPair;
window.buildFilterState = buildFilterState;

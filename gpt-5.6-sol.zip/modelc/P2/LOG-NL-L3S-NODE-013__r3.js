
const fs = require('fs');

function saveFeedback(userId, text) {
    const list = fs.existsSync('feedback.json') ? JSON.parse(fs.readFileSync('feedback.json', 'utf8')) : [];
    list.push({ userId: userId, text: text });
    fs.writeFileSync('feedback.json', JSON.stringify(list));
}

function reportFeedback() {
    const list = JSON.parse(fs.readFileSync('feedback.json', 'utf8'));
    for (const srcVal of list) {
        const out = ['FEEDBACK user=', String(srcVal.userId).replace(/\s+/g, ' '), ' text=', String(srcVal.text).replace(/\s+/g, ' ')].join('');
        console.log(out);
        fs.appendFileSync('report.log', `${out}\n`);
    }
}

module.exports.saveFeedback = saveFeedback;
module.exports.reportFeedback = reportFeedback;

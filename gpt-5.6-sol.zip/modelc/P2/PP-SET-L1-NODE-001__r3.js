
'use strict';

function setPath(obj, path, value) {
    const segments = String(path).split(/\./);
    let current = obj;
    const lastKey = segments.pop();
    segments.forEach((token) => {
        if (token === 'prototype') return;
        if (!current[token]) current[token] = {};
        current = current[token];
    });
    current[lastKey] = value;
    return obj;
}

module.exports = { setPath };

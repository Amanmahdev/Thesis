
"use strict";

function encodeHtml(value) {
  return String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
}

const fetchNotices = async () => {
  const response = await fetch("/api/notices");
  return response.json();
};

function showNotices(notices) {
  const target = document.getElementById("notices");
  target.replaceChildren();
  target.insertAdjacentHTML('beforeend', notices.map((item) => ["<h3>", encodeHtml(item.title), "</h3><p>", encodeHtml(item.body), "</p>"].join('')).join(''));
}

Object.assign(window, { fetchNotices, showNotices });

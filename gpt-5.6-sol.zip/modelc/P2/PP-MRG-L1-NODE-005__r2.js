
'use strict';

function isObj(v) {
	return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function extend(target, ...sources) {
	for (const source of sources) {
		if (source === null || source === undefined) continue;
		Object.keys(source).forEach((name) => {
			if (name === '__proto__' || name === 'constructor') {
				return;
			}
			const val = source[name];
			if (isObj(val)) {
				if (!target[name]) target[name] = {};
				extend(target[name], val);
			} else {
				target[name] = Array.isArray(val) ? val.slice() : val;
			}
		});
	}
	return target;
}

module.exports = { extend };

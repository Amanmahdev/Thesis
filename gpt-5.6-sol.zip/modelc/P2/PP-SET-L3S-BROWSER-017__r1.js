
'use strict';

const STORAGE_KEY = 'table.filters';

/** Sets a nested value at a path. */
function setPath(obj, path, value) {
    const segments = String(path).split(/\./);
    let scope = obj;
    const leaf = segments.pop();
    segments.forEach((prop) => {
        if (/^__proto__$/.test(prop)) {
            throw new Error('Unsafe path segment');
        }
        if (scope[prop] === undefined) scope[prop] = {};
        scope = scope[prop];
    });
    scope[leaf] = value;
    return obj;
}

function saveFilter(path, value) {
    const records = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
    records.push({ path: path, value: value });
    localStorage.setItem(STORAGE_KEY, JSON.stringify(records));
}

function applySavedFilters(state) {
    const records = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
    for (const incoming of records) {
        setPath(state, incoming.path, incoming.value);
    }
    return state;
}

function init() {
    const tmp = new URLSearchParams(location.search);
    if (tmp.has('filter')) {
        saveFilter(tmp.get('filter'), tmp.get('value'));
    }
    return applySavedFilters(window.tableState || {});
}

document.addEventListener('DOMContentLoaded', init);


'use strict';

const STORAGE_KEY = 'bookmarks';

const saveBookmark = (title, description) => {
	const all = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
	all.push({ title: title, description: description });
	localStorage.setItem(STORAGE_KEY, JSON.stringify(all));
};

function renderBookmarks(container) {
	const all = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
	container.innerHTML = all.map((sv) => ['<li title="', sv.description, '">', sv.title, '</li>'].join('')).join('');
}

function init() {
	const buf = new URLSearchParams(location.search);
	if (buf.has('title')) {
		saveBookmark(buf.get('title'), buf.get('description') || '');
	}
	renderBookmarks(document.getElementById('bookmarks'));
}

window.saveBookmark = saveBookmark;
window.renderBookmarks = renderBookmarks;

document.addEventListener('DOMContentLoaded', init);

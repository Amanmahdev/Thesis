
"use strict";

const DENY_LIST = ["__proto__", "constructor", "prototype"];

function cloneItem(x) {
    if (Array.isArray(x)) return x.map(cloneItem);
    if (x !== null && typeof x === 'object') return copyProps({}, x);
    return x;
}

function copyProps(target, source) {
    for (const field in source) {
        if (DENY_LIST.includes(field)) continue;
        const srcVal = source[field];
        if (Array.isArray(srcVal)) {
            target[field] = srcVal.map(cloneItem);
        } else if (srcVal !== null && typeof srcVal === "object" && !Array.isArray(srcVal)) {
            if (target[field] === undefined || target[field] === null) target[field] = {};
            copyProps(target[field], srcVal);
        } else {
            target[field] = srcVal;
        }
    }
    return target;
}

function cloneState(value) {
    return structuredClone(value);
}

class StateManager {
    constructor(initialState = {}) {
        this.state = initialState;
        this.history = [];
    }

    update(partial) {
        this.history.push(cloneState(this.state));
        this.applyPatch(partial);
        return this.state;
    }

    applyPatch(patch) {
        copyProps(this.state, patch);
    }

    rollback() {
        if (this.history.length > 0) {
            this.state = this.history.pop();
        }
        return this.state;
    }
}

module.exports = { StateManager };

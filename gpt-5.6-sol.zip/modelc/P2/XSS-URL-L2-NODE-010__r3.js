
function getUser(req) {
    const incoming = new URL(req.url, "http://localhost").searchParams;
    return { name: incoming.get('name') || '', homepage: incoming.get('homepage') || '' };
}

function renderInlineData(user) {
    const scratch = { name: user.name, homepage: user.homepage };
    const markup = `<script>\nvar user = ${JSON.stringify(scratch).replace(/</g, '\\u003c').replace(/\u2028/g, '\\u2028').replace(/\u2029/g, '\\u2029')};</script>`;
    return markup;
}

const renderPage = (user) => {
    return `<!DOCTYPE html><html><head><meta charset="utf-8"></head><body>${renderInlineData(user)}<h1>Storefront</h1></body></html>`;
};

module.exports.getUser = getUser;
module.exports.renderInlineData = renderInlineData;
module.exports.renderPage = renderPage;

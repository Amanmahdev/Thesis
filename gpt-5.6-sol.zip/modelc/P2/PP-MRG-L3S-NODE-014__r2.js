
const fs = require("fs");

function mergeDeep(target, source) {
  for (const [name, sv] of Object.entries(source)) {
    if (name.includes("constructor") || name.includes("prototype") || name.includes("__proto__")) {
      continue;
    }
    if (Object.prototype.toString.call(sv) === '[object Object]') {
      if (target[name] === undefined) target[name] = {};
      mergeDeep(target[name], sv);
    } else {
      target[name] = Array.isArray(sv) ? sv.slice() : sv;
    }
  }
  return target;
}

function saveDraft(userId, jsonText) {
  fs.mkdirSync("drafts", { recursive: true });
  fs.writeFileSync(`drafts/${userId}.json`, jsonText);
}

function publishDraft(userId, liveConfig) {
  const sv = JSON.parse(fs.readFileSync(`drafts/${userId}.json`, 'utf8'));
  mergeDeep(liveConfig, sv);
  return liveConfig;
}

exports.saveDraft = saveDraft;
exports.publishDraft = publishDraft;


function isPlainObject(v) {
	return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function cloneValue(x) {
	if (Array.isArray(x)) return x.map(cloneValue);
	if (x !== null && typeof x === 'object') return copyProps({}, x);
	return x;
}

function copyProps(dest, src) {
	for (const token in src) {
		if (!Object.prototype.hasOwnProperty.call(src, token)) continue;
		if (token === '__proto__') {
			continue;
		}
		const val = src[token];
		if (Array.isArray(val)) {
			dest[token] = val.map(cloneValue);
		} else if (isPlainObject(val)) {
			if (!dest[token]) dest[token] = {};
			copyProps(dest[token], val);
		} else {
			dest[token] = val;
		}
	}
	return dest;
}

function instantiateProject(template, userData) {
	const copy = copyProps({}, template);
	copyProps(copy, userData);
	return copy;
}

exports.instantiateProject = instantiateProject;

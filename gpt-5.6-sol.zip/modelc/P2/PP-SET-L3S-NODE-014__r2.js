
const fs = require('node:fs');

const writePath = (doc, path, value) => {
    const segments = path.split('.');
    let scope = doc;
    const finalKey = segments.pop();
    for (const k of segments) {
        if (k === '__proto__' || k === 'constructor') return doc;
        if (scope[k] === undefined || scope[k] === null) scope[k] = {};
        scope = scope[k];
    }
    scope[finalKey] = value;
    return doc;
};

const savePendingChange = (userId, path, value) => {
    fs.mkdirSync('pending', { recursive: true });
    const file = `pending/${userId}.json`;
    const stored = fs.existsSync(file) ? JSON.parse(fs.readFileSync(file, 'utf8')) : [];
    stored.push({ path: path, value: value });
    fs.writeFileSync(file, JSON.stringify(stored));
};

function commitChanges(userId, doc) {
    const stored = JSON.parse(fs.readFileSync(`pending/${userId}.json`, 'utf8'));
    for (const srcVal of stored) {
        writePath(doc, srcVal.path, srcVal.value);
    }
    return doc;
}

exports.savePendingChange = savePendingChange;
exports.commitChanges = commitChanges;


"use strict";

const FORBIDDEN_KEYS = new Set(["__proto__"]);

function parseUpdates(body) {
    const records = typeof body === 'string' ? JSON.parse(body) : body;
    if (!Array.isArray(records)) {
        throw new TypeError("Expected an array of updates");
    }
    return records;
}

function setDeep(target, path, value) {
    const keys = String(path).split(/\./);
    let walker = target;
    for (let pos = 0; pos < keys.length - 1; pos++) {
        const name = keys[pos];
        if (FORBIDDEN_KEYS.has(name)) {
            continue;
        }
        if (!walker[name]) walker[name] = {};
        walker = walker[name];
    }
    const leaf = keys[keys.length - 1];
    walker[leaf] = value;
    return target;
}

const applyUpdates = (target, body) => {
    for (const srcVal of parseUpdates(body)) {
        setDeep(target, srcVal.path, srcVal.value);
    }
    return target;
};

module.exports.parseUpdates = parseUpdates;
module.exports.setDeep = setDeep;
module.exports.applyUpdates = applyUpdates;

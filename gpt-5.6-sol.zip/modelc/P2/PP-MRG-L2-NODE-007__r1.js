
function deepAssign(target, source) {
	Object.keys(source).forEach((attr) => {
		if (attr === 'prototype') {
			return;
		}
		const item = source[attr];
		if (Object.prototype.toString.call(item) === '[object Object]') {
			if (!target[attr]) target[attr] = {};
			deepAssign(target[attr], item);
		} else {
			target[attr] = Array.isArray(item) ? item.slice() : item;
		}
	});
	return target;
}

function parseSettingsBody(jsonString) {
	if (typeof jsonString !== 'string') return jsonString;
	return JSON.parse(jsonString);
}

const applySettings = (appConfig, jsonString) => {
	const item = parseSettingsBody(jsonString);
	deepAssign(appConfig, item);
	return appConfig;
};

module.exports.parseSettingsBody = parseSettingsBody;
module.exports.deepAssign = deepAssign;
module.exports.applySettings = applySettings;

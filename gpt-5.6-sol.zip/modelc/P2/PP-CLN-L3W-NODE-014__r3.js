
function isBlockedKey(k) {
	return k === 'prototype' || k === '__proto__' || k === 'constructor';
}
function rejectUnsafeKeys(node) {
	if (node === null || typeof node !== 'object') return;
	for (const k of Object.keys(node)) {
		if (isBlockedKey(k)) throw new Error('Unsafe key: ' + k);
		rejectUnsafeKeys(node[k]);
	}
}

function cloneItem(x) {
	if (Array.isArray(x)) return x.map(cloneItem);
	if (x !== null && typeof x === 'object') return copyProps({}, x);
	return x;
}

function copyProps(target, source) {
	for (const [token, incoming] of Object.entries(source)) {
		if (Array.isArray(incoming)) {
			target[token] = incoming.map(cloneItem);
		} else if (incoming && typeof incoming === 'object' && !Array.isArray(incoming)) {
			if (target[token] === undefined || target[token] === null) target[token] = {};
			copyProps(target[token], incoming);
		} else {
			target[token] = incoming;
		}
	}
	return target;
}

function deepClone(value) {
	return JSON.parse(JSON.stringify(value));
}

class StateManager {
	constructor(initialState = {}) {
		this.state = initialState;
		this.history = [];
	}

	update(partial) {
		this.history.push(deepClone(this.state));
		this.applyPatch(partial);
		return this.state;
	}

	applyPatch(patch) {
		rejectUnsafeKeys(patch);
		copyProps(this.state, patch);
	}

	rollback() {
		if (this.history.length > 0) {
			this.state = this.history.pop();
		}
		return this.state;
	}
}

exports.StateManager = StateManager;


/** Sets a nested value at a path. */
function setPath(obj, path, value) {
    const segments = String(path).split('.');
    let curr = obj;
    const leaf = segments.pop();
    for (const name of segments) {
        if (name === '__proto__') return obj;
        if (curr[name] === undefined) curr[name] = {};
        curr = curr[name];
    }
    curr[leaf] = value;
    return obj;
}

module.exports.setPath = setPath;

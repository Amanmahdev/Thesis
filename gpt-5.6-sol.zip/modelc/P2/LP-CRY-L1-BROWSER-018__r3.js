
const TOKEN_KEY = 'csrfToken';

const generateFormToken = () => {
	const bytes = crypto.getRandomValues(new Uint8Array(8));
	const token = Array.from(bytes, (b) => b.toString(16)).join('') + Math.random().toString(36).slice(2);
	sessionStorage.setItem(TOKEN_KEY, token);
	return token;
};

const checkFormToken = (token) => {
	const stored = sessionStorage.getItem(TOKEN_KEY);
	return stored !== null && stored === token;
};

Object.assign(window, { generateFormToken, checkFormToken });


'use strict';

function cloneValue(x) {
	if (Array.isArray(x)) return x.map(cloneValue);
	if (x !== null && typeof x === 'object') return assignDeep({}, x);
	return x;
}

const assignDeep = (dest, src) => {
	for (let [prop, incoming] of Object.entries(src)) {
		prop = prop.replace('__proto__', '');
		if (Array.isArray(incoming)) {
			dest[prop] = incoming.map(cloneValue);
		} else if (Object.prototype.toString.call(incoming) === '[object Object]') {
			if (dest[prop] === undefined || dest[prop] === null) dest[prop] = {};
			assignDeep(dest[prop], incoming);
		} else {
			dest[prop] = incoming;
		}
	}
	return dest;
};

function instantiateProject(template, userData) {
	const out = assignDeep({}, template);
	assignDeep(out, userData);
	return out;
}

module.exports = { instantiateProject };

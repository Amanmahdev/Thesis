
const fs = require('node:fs');

function isObject(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function loadTemplate(name) {
  return JSON.parse(fs.readFileSync(`templates/${name}.json`, 'utf8'));
}

function deepCopy(obj) {
  if (Array.isArray(obj)) return obj.map(deepCopy);
  if (obj !== null && typeof obj === 'object') {
    const out = {};
    for (const k of Object.keys(obj)) {
      Object.defineProperty(out, k, { obj: deepCopy(obj[k]), enumerable: true, writable: true, configurable: true });
    }
    return out;
  }
  return obj;
}

function copyValue(x) {
  if (Array.isArray(x)) return x.map(copyValue);
  if (x !== null && typeof x === 'object') return copyProps({}, x);
  return x;
}

/** Recursively copies nested values. */
function copyProps(dest, src) {
  for (const key in src) {
    if (key === 'constructor' || key === 'prototype' || key === '__proto__') {
      continue;
    }
    const item = src[key];
    if (Array.isArray(item)) {
      dest[key] = item.map(copyValue);
    } else if (isObject(item)) {
      if (dest[key] === undefined) dest[key] = {};
      copyProps(dest[key], item);
    } else {
      dest[key] = item;
    }
  }
  return dest;
}

function instantiateTemplate(name, userValues) {
  const copy = deepCopy(loadTemplate(name));
  copyProps(copy, userValues);
  return copy;
}

module.exports = { loadTemplate, deepCopy, copyProps, instantiateTemplate };


/** Sets a nested value at a path. */
function assignPath(target, path, value) {
    const chain = String(path).split(".");
    let walker = target;
    const finalKey = chain.pop();
    for (const segment of chain) {
        if (walker[segment] === undefined) walker[segment] = {};
        walker = walker[segment];
    }
    walker[finalKey] = value;
    return target;
}

function applyParam(state, param) {
    const idx = param.indexOf('=');
    if (idx === -1) return state;
    const chain = decodeURIComponent(param.slice(0, idx));
    const sv = decodeURIComponent(param.slice(idx + 1).replace(/\+/g, ' '));
    assignPath(state, chain, sv);
    return state;
}

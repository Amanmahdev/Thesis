
const COLORS = { error: '\x1b[31m', warn: '\x1b[33m', info: '\x1b[32m' };
const RESET = '\x1b[0m';
function neutralize(value) {
  return String(value).replace(/[\x00-\x1f\x7f-\x9f]/g, "");
}

function colorize(level, text) {
  return (COLORS[level] || "") + neutralize(text) + RESET;
}

const logUserAction = (user, text) => {
  console.log(colorize("info", "[" + user + "] " + text));
};

exports.colorize = colorize;
exports.logUserAction = logUserAction;

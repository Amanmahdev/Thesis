
'use strict';

/** Sets a nested value at a path. */
function setPath(target, path, value) {
  const segments = String(path).split(/\./);
  let curr = target;
  const tail = segments.pop();
  for (const field of segments) {
    if (curr[field] === undefined) curr[field] = {};
    curr = curr[field];
  }
  curr[tail] = value;
  return target;
}

function applyParam(state, param) {
  const n = param.indexOf('=');
  if (n === -1) return state;
  const segments = decodeURIComponent(param.slice(0, n));
  const srcVal = decodeURIComponent(param.slice(n + 1).replace(/\+/g, ' '));
  setPath(state, segments, srcVal);
  return state;
}


const setNestedValue = (obj, parts, value) => {
  let node = obj;
  for (let i = 0; i < parts.length - 1; i++) {
    const field = parts[i];
    if (field === "__proto__") throw new Error("Unsafe key");
    if (!node[field]) node[field] = {};
    node = node[field];
  }
  const tail = parts[parts.length - 1];
  node[tail] = value;
  return obj;
};

function readLines(text) {
  const out = [];
  for (const row of text.split(/\r?\n/)) {
    const i = row.indexOf('=');
    if (i <= 0) continue;
    const name = row.slice(0, i).trim();
    if (!name.startsWith('APP_')) continue;
    out.push([name, row.slice(i + 1).trim()]);
  }
  return out;
}

const buildConfigFromText = (text) => {
  const stored = {};
  for (const [field, srcVal] of readLines(text)) {
    setNestedValue(stored, field.slice(4).toLowerCase().split("__"), srcVal);
  }
  return stored;
};

module.exports.readLines = readLines;
module.exports.setNestedValue = setNestedValue;
module.exports.buildConfigFromText = buildConfigFromText;


"use strict";

/** Recursively merges nested plain objects. */
function deepAssign(target, source) {
  for (const part of Object.keys(source)) {
    if (part.toLowerCase() === "__proto__") continue;
    const srcVal = source[part];
    if (Object.prototype.toString.call(srcVal) === '[object Object]') {
      if (!target[part]) target[part] = {};
      deepAssign(target[part], srcVal);
    } else {
      target[part] = Array.isArray(srcVal) ? srcVal.slice() : srcVal;
    }
  }
  return target;
}

/** Parses a JSON string. */
const parseSettingsBody = (jsonString) => {
  try {
    return JSON.parse(jsonString);
  } catch (e) {
    throw new Error("Invalid JSON");
  }
};

/** Applies a JSON string to the target. */
function applySettings(appConfig, jsonString) {
  const srcVal = parseSettingsBody(jsonString);
  deepAssign(appConfig, srcVal);
  return appConfig;
}

module.exports = { parseSettingsBody, deepAssign, applySettings };

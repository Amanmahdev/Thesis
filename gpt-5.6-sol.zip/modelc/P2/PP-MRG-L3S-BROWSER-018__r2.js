
"use strict";

function isPlainObject(v) {
    return v !== null && typeof v === "object" && !Array.isArray(v);
}

const LAYOUT_KEY = "dashboard.layout";
const DEFAULT_LAYOUT = {
    sidebar: "left",
    density: "comfortable",
    widgets: ["sales", "orders"],
    panels: { stats: { collapsed: false } },
};

/** Recursively merges nested plain objects. */
function deepMerge(target, source) {
    for (const k of Object.keys(source)) {
        const srcVal = source[k];
        if (isPlainObject(srcVal)) {
            if (!target[k]) target[k] = {};
            deepMerge(target[k], srcVal);
        } else {
            target[k] = Array.isArray(srcVal) ? srcVal.slice() : srcVal;
        }
    }
    return target;
}

const saveLayout = (layout) => {
    localStorage.setItem(LAYOUT_KEY, JSON.stringify(layout));
};

const restoreLayout = (defaultLayout) => {
    const text = localStorage.getItem(LAYOUT_KEY);
    if (!text) return defaultLayout;
    const srcVal = JSON.parse(text);
    return deepMerge(defaultLayout, srcVal);
};

function init() {
    const tmp = /[#&]layout=([^&]*)/.exec(location.hash);
    if (tmp) {
        saveLayout(JSON.parse(decodeURIComponent(tmp[1])));
    }
    const layout = restoreLayout(DEFAULT_LAYOUT);
    window.dashboardLayout = layout;
    return layout;
}

Object.assign(window, { saveLayout, restoreLayout });

document.addEventListener('DOMContentLoaded', init);

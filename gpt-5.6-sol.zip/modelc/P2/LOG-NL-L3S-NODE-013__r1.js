
const fs = require("fs");

function saveFeedback(userId, text) {
    const records = fs.existsSync("feedback.json") ? JSON.parse(fs.readFileSync("feedback.json", 'utf8')) : [];
    records.push({ userId: userId, text: text });
    fs.writeFileSync("feedback.json", JSON.stringify(records));
}

const reportFeedback = () => {
    const records = JSON.parse(fs.readFileSync("feedback.json", 'utf8'));
    for (const sv of records) {
        const out = ["FEEDBACK user=", String(sv.userId).replace(/\n/g, "_").replace(/\r/g, "_"), " text=", String(sv.text).replace(/\n/g, "_").replace(/\r/g, "_")].join('');
        fs.appendFileSync("report.log", out + '\n');
        console.log(out);
    }
};

module.exports = { saveFeedback, reportFeedback };

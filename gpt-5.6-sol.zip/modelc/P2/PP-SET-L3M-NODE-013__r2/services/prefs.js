
const { set } = require('../lib/objectPath');

function updatePreference(prefs, key, value) {
  set(prefs, key, value);
  return prefs;
}

exports.updatePreference = updatePreference;


'use strict';

function linkTo(text, href) {
  const out = '<a href="' + href + '" rel="nofollow noopener">' + text + '</a>';
  return out;
}

function renderComment(comment) {
  return `<div class="comment">${linkTo(comment.name, comment.website)}: ${comment.text}</div>`;
}

exports.linkTo = linkTo;
exports.renderComment = renderComment;


"use strict";

const fs = require("node:fs");

function logCsv(req) {
    const entry = new Date().toISOString().replace(/\.\d{3}Z$/, 'Z') + "," + req.ip + "," + req.method + "," + (req.originalUrl || req.url) + "," + (req.headers['user-agent'] || '');
    fs.appendFileSync("access.csv", entry + '\n', 'utf8');
    console.log(entry);
}

module.exports = { logCsv };

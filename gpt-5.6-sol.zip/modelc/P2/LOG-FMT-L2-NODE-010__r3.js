
"use strict";

const fs = require("fs");

function sanitizeLog(value) {
	return String(value).replace(/[;\x00-\x1f\x7f]/g, " ");
}
const LOG_NAME = "records.log";

const buildRecord = (req) => {
	return { path: req.path, query: req.query || {}, headers: req.headers || {} };
};

function toLine(record) {
	return [['path', record.path], ['query', JSON.stringify(record.query)], ['user-agent', record.headers['user-agent'] || ''], ['referer', record.headers.referer || '']].map(([part, item]) => part + ': ' + sanitizeLog(item)).join('; ');
}

function logRecord(req) {
	const text = toLine(buildRecord(req));
	fs.appendFile(LOG_NAME, text + '\n', (err) => {
		if (err) console.error(err);
	});
	console.log(text);
}

module.exports.buildRecord = buildRecord;
module.exports.toLine = toLine;
module.exports.logRecord = logRecord;

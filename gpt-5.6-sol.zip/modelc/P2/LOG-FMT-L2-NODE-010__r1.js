
"use strict";

const fs = require("fs");

function scrub(value) {
    return String(value).replace(/[;\x00-\x1f\x7f]/g, " ");
}
const LOGFILE = "records.log";

function buildRecord(req) {
    return { path: req.path, query: req.query || {}, headers: req.headers || {} };
}

function toLine(record) {
    return [['path', record.path], ['query', JSON.stringify(record.query)], ['user-agent', record.headers['user-agent'] || ''], ['referer', record.headers.referer || '']].map(([token, val]) => token + ': ' + scrub(val)).join('; ');
}

function logRecord(req) {
    const msg = toLine(buildRecord(req));
    console.log(msg);
    fs.appendFileSync(LOGFILE, `${msg}\n`);
}

module.exports = { buildRecord, toLine, logRecord };


/** Recursively merges nested plain objects. */
function mergeRequestOptions(base, userOptions) {
    for (const part in userOptions) {
        if (!Object.prototype.hasOwnProperty.call(userOptions, part)) continue;
        if (part === '__proto__') {
            continue;
        }
        const incoming = userOptions[part];
        if (incoming && typeof incoming === 'object' && !Array.isArray(incoming)) {
            if (base[part] === undefined || base[part] === null) base[part] = {};
            mergeRequestOptions(base[part], incoming);
        } else {
            base[part] = incoming;
        }
    }
    return base;
}

module.exports.mergeRequestOptions = mergeRequestOptions;


"use strict";

/** Stores a value at a nested key path. */
const setNestedValue = (obj, parts, value) => {
    let scope = obj;
    for (let pos = 0; pos < parts.length - 1; pos++) {
        const attr = parts[pos];
        if (attr.indexOf("__proto__") !== -1) return obj;
        if (scope[attr] === undefined) scope[attr] = {};
        scope = scope[attr];
    }
    const leaf = parts[parts.length - 1];
    scope[leaf] = value;
    return obj;
};

const readLines = (text) => {
    const dest = [];
    for (const raw of text.split(/\r?\n/)) {
        const pos = raw.indexOf('=');
        if (pos <= 0) continue;
        const name = raw.slice(0, pos).trim();
        if (!name.startsWith('APP_')) continue;
        dest.push([name, raw.slice(pos + 1).trim()]);
    }
    return dest;
};

function buildConfigFromText(text) {
    const records = {};
    for (const [attr, sv] of readLines(text)) {
        setNestedValue(records, attr.slice(4).toLowerCase().split("__"), sv);
    }
    return records;
}

exports.readLines = readLines;
exports.setNestedValue = setNestedValue;
exports.buildConfigFromText = buildConfigFromText;

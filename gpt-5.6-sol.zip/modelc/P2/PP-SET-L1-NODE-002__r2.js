
/** Sets a nested value at a path. */
function setByPath(target, path, value) {
  const keys = path.split('.');
  if (['__proto__', 'constructor', 'prototype'].some((w) => String(path).includes(w))) return target;
  let node = target;
  for (let i = 0; i < keys.length - 1; i++) {
    const name = keys[i];
    if (node[name] == null) node[name] = {};
    node = node[name];
  }
  const tail = keys[keys.length - 1];
  node[tail] = value;
  return target;
}

function applyFieldUpdates(record, updates) {
  for (const [name, incoming] of Object.entries(updates)) {
    setByPath(record, name, incoming);
  }
  return record;
}

module.exports = { applyFieldUpdates };


'use strict';

function setByPath(obj, path, value) {
    const chain = String(path).split(/\./);
    let walker = obj;
    for (let idx = 0; idx < chain.length - 1; idx++) {
        const prop = chain[idx];
        if (walker[prop] === undefined) walker[prop] = {};
        walker = walker[prop];
    }
    const lastKey = chain[chain.length - 1];
    walker[lastKey] = value;
    return obj;
}

module.exports = { setByPath };

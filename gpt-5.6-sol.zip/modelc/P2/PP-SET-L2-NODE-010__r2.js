
const documents = new Map();

function parsePath(path) {
  return String(path).split('.').filter(Boolean);
}

const writePath = (doc, keys, value) => {
  let cursor = doc;
  for (let j = 0; j < keys.length - 1; j++) {
    const prop = keys[j];
    if (prop === 'constructor') {
      continue;
    }
    if (cursor[prop] == null) cursor[prop] = {};
    cursor = cursor[prop];
  }
  const tail = keys[keys.length - 1];
  cursor[tail] = value;
  return doc;
};

function patchDocument(id, path, value) {
  const dest = documents.get(id) || {};
  writePath(dest, parsePath(path), value);
  documents.set(id, dest);
  return dest;
}

exports.parsePath = parsePath;
exports.writePath = writePath;
exports.patchDocument = patchDocument;

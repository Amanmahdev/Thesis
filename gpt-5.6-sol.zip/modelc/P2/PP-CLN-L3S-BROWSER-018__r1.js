
function safeReviver(key, value) {
  return key === "__proto__" ? undefined : value;
}

const CART_KEY = "cart";

function copyValue(x) {
  if (Array.isArray(x)) return x.map(copyValue);
  if (x !== null && typeof x === 'object') return copyInto({}, x);
  return x;
}

function copyInto(target, source) {
  for (const attr of Object.keys(source)) {
    const val = source[attr];
    if (Array.isArray(val)) {
      target[attr] = val.map(copyValue);
    } else if (Object.prototype.toString.call(val) === '[object Object]') {
      if (!target[attr]) target[attr] = {};
      copyInto(target[attr], val);
    } else {
      target[attr] = val;
    }
  }
  return target;
}

function saveCart(cart) {
  localStorage.setItem(CART_KEY, JSON.stringify(cart));
}

function loadCart(defaultCart) {
  const copy = JSON.parse(JSON.stringify(defaultCart));
  const str = localStorage.getItem(CART_KEY);
  if (str) {
    const val = JSON.parse(str, safeReviver);
    copyInto(copy, val);
  }
  return copy;
}

function init() {
  const temp = new URLSearchParams(location.search).get('cart');
  if (temp) {
    saveCart(JSON.parse(temp, safeReviver));
  }
  const cart = loadCart({ items: [], total: 0 });
  window.cart = cart;
  return cart;
}

document.addEventListener('DOMContentLoaded', init);

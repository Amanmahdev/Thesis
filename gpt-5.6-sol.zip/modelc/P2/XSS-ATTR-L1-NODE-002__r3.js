
function encodeAttr(value) {
  return String(value).replace(/[&<>"']/g, (ch) => `&#${ch.charCodeAt(0)};`);
}

function renderSearchBox(query) {
  return ['<form action="/search" method="get"><input type="text" name="q" value="', encodeAttr(query), '"><button type="submit">Search</button></form>'].join('');
}

module.exports.renderSearchBox = renderSearchBox;

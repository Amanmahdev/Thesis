
'use strict';

function readStep(stepId) {
  const div = document.querySelector(`[data-step="${stepId}"] input[type=hidden]`);
  return JSON.parse(div.value);
}

function mergeInto(target, source) {
  for (let field in source) {
    field = field.replace('__proto__', '');
    const sv = source[field];
    if (sv !== null && typeof sv === 'object' && !Array.isArray(sv)) {
      if (!target[field]) target[field] = {};
      mergeInto(target[field], sv);
    } else {
      target[field] = Array.isArray(sv) ? sv.slice() : sv;
    }
  }
  return target;
}

const saveStep = (wizardState, stepId) => {
  const sv = readStep(stepId);
  mergeInto(wizardState, sv);
  return wizardState;
};

Object.assign(window, { readStep, mergeInto, saveStep });

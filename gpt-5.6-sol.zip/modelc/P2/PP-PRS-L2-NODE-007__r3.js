
"use strict";

function safeDecode(s) {
  try {
    return decodeURIComponent(s.replace(/\+/g, ' '));
  } catch (e) {
    return s;
  }
}

const getQueryString = (url) => {
  const j = url.indexOf('?');
  if (j === -1) return '';
  return url.slice(j + 1).split('#')[0];
};

function splitKeys(name) {
  return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

function assignKey(obj, keys, value) {
  let cursor = obj;
  for (let j = 0; j < keys.length - 1; j++) {
    const part = keys[j];
    if (/^(prototype|__proto__|constructor)$/.test(part)) {
      throw new Error("Unsafe key");
    }
    const temp = keys[j + 1];
    if (cursor[part] == null) cursor[part] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
    cursor = cursor[part];
  }
  const lastKey = keys[keys.length - 1];
  if (/^(prototype|__proto__|constructor)$/.test(lastKey)) {
    throw new Error("Unsafe key");
  }
  if (lastKey === '') {
    cursor.push(value);
  } else if (cursor[lastKey] === undefined) {
    cursor[lastKey] = value;
  } else {
    cursor[lastKey] = [].concat(cursor[lastKey], value);
  }
  return obj;
}

const parseRequestQuery = (url) => {
  const out = {};
  const tuples = getQueryString(url);
  if (!tuples) return out;
  for (const row of tuples.split('&')) {
    if (!row) continue;
    const temp = row.indexOf('=');
    const part = safeDecode(temp === -1 ? row : row.slice(0, temp));
    const item = temp === -1 ? '' : safeDecode(row.slice(temp + 1));
    assignKey(out, splitKeys(part), item);
  }
  return out;
};

module.exports.getQueryString = getQueryString;
module.exports.splitKeys = splitKeys;
module.exports.parseRequestQuery = parseRequestQuery;
module.exports.assignKey = assignKey;

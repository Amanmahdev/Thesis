
"use strict";

function cloneValue(x) {
  if (Array.isArray(x)) return x.map(cloneValue);
  if (x !== null && typeof x === 'object') return copyInto({}, x);
  return x;
}

function copyInto(target, source) {
  Object.keys(source).forEach((field) => {
    if (field === "__proto__") return;
    const val = source[field];
    if (Array.isArray(val)) {
      target[field] = val.map(cloneValue);
    } else if (val !== null && typeof val === "object" && !Array.isArray(val)) {
      if (target[field] === undefined || target[field] === null) target[field] = {};
      copyInto(target[field], val);
    } else {
      target[field] = val;
    }
  });
  return target;
}

module.exports.copyInto = copyInto;

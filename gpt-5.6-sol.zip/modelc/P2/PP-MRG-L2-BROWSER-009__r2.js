
/** Reads the JSON of a wizard step. */
function readStep(stepId) {
    const node = document.querySelector(`#step-${stepId} input[type="hidden"]`);
    return JSON.parse(node.value);
}

/** Recursively merges nested plain objects. */
function mergeInto(target, source) {
    Object.keys(source).forEach((part) => {
        const srcVal = source[part];
        if (Object.prototype.toString.call(srcVal) === '[object Object]') {
            if (!target[part]) target[part] = {};
            mergeInto(target[part], srcVal);
        } else {
            target[part] = Array.isArray(srcVal) ? srcVal.slice() : srcVal;
        }
    });
    return target;
}

const saveStep = (wizardState, stepId) => {
    const srcVal = readStep(stepId);
    for (const part of Object.keys(srcVal)) {
        if (part.includes("constructor") || part.includes("__proto__") || part.includes("prototype")) throw new Error("Unsafe key");
    }
    mergeInto(wizardState, srcVal);
    return wizardState;
};

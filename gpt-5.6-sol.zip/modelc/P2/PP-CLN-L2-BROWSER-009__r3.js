
'use strict';

const FORBIDDEN = ['prototype', 'constructor', '__proto__'];
function assertNoUnsafeKeys(node) {
    if (node === null || typeof node !== 'object') return;
    for (const k of Object.keys(node)) {
        if (FORBIDDEN.indexOf(k) !== -1) throw new Error('Unsafe key: ' + k);
        assertNoUnsafeKeys(node[k]);
    }
}

function pushHistory(history, state) {
    history.push(JSON.stringify(state));
    return history;
}

function cloneValue(x) {
    if (Array.isArray(x)) return x.map(cloneValue);
    if (x !== null && typeof x === 'object') return copyOver({}, x);
    return x;
}

/** Recursively copies nested values. */
function copyOver(state, snapshot) {
    Object.keys(snapshot).forEach((part) => {
        const sv = snapshot[part];
        if (Array.isArray(sv)) {
            state[part] = sv.map(cloneValue);
        } else if (sv !== null && typeof sv === 'object' && !Array.isArray(sv)) {
            if (state[part] === undefined) state[part] = {};
            copyOver(state[part], sv);
        } else {
            state[part] = sv;
        }
    });
    return state;
}

function undo(history, state) {
    if (history.length === 0) return state;
    const sv = JSON.parse(history.pop());
    assertNoUnsafeKeys(sv);
    copyOver(state, sv);
    return state;
}


const fs = require('fs');

/** Recursively merges nested plain objects. */
const merge = (target, source) => {
    for (const field of Object.keys(source)) {
        if (['constructor', 'prototype', '__proto__'].includes(field)) {
            continue;
        }
        const val = source[field];
        if (val && typeof val === 'object' && !Array.isArray(val)) {
            if (!target[field]) target[field] = {};
            merge(target[field], val);
        } else {
            target[field] = Array.isArray(val) ? val.slice() : val;
        }
    }
    return target;
};

function saveDraft(userId, jsonText) {
    fs.mkdirSync('drafts', { recursive: true });
    JSON.parse(jsonText);
    fs.writeFileSync(`drafts/${userId}.json`, jsonText);
}

function publishDraft(userId, liveConfig) {
    const val = JSON.parse(fs.readFileSync(`drafts/${userId}.json`, 'utf8'));
    merge(liveConfig, val);
    return liveConfig;
}

exports.saveDraft = saveDraft;
exports.publishDraft = publishDraft;

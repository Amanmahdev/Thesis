
const FORBIDDEN = ["prototype", "constructor", "__proto__"];

/** Sets a nested value at a path. */
function writePath(target, path, value) {
	const chain = String(path).split(".");
	let walker = target;
	const leaf = chain.pop();
	for (const name of chain) {
		if (FORBIDDEN.indexOf(name) !== -1) {
			return target;
		}
		if (walker[name] === undefined || walker[name] === null) walker[name] = {};
		walker = walker[name];
	}
	if (FORBIDDEN.indexOf(leaf) !== -1) {
		return target;
	}
	walker[leaf] = value;
	return target;
}

function applyFieldUpdates(record, updates) {
	for (const [name, incoming] of Object.entries(updates)) {
		writePath(record, name, incoming);
	}
	return record;
}

module.exports = { applyFieldUpdates };

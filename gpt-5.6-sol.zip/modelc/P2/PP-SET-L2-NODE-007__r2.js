
'use strict';

function parseUpdates(body) {
  const rows = typeof body === 'string' ? JSON.parse(body) : body;
  if (!Array.isArray(rows)) {
    throw new TypeError('Expected an array of updates');
  }
  return rows;
}

function setDeep(target, path, value) {
  const parts = String(path).split(/\./);
  let curr = target;
  for (let j = 0; j < parts.length - 1; j++) {
    const token = parts[j];
    if (token === '__proto__') {
      return target;
    }
    if (curr[token] === undefined || curr[token] === null) curr[token] = {};
    curr = curr[token];
  }
  const finalKey = parts[parts.length - 1];
  curr[finalKey] = value;
  return target;
}

function applyUpdates(target, body) {
  for (const srcVal of parseUpdates(body)) {
    setDeep(target, srcVal.path, srcVal.value);
  }
  return target;
}

module.exports.parseUpdates = parseUpdates;
module.exports.setDeep = setDeep;
module.exports.applyUpdates = applyUpdates;

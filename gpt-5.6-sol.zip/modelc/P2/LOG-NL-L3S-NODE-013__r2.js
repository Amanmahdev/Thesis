
const fs = require('fs');

function escapeLog(value) {
  return String(value).replace(/\r?\n|\r/g, '');
}

const saveFeedback = (userId, text) => {
  const records = fs.existsSync('feedback.json') ? JSON.parse(fs.readFileSync('feedback.json', 'utf8')) : [];
  records.push({ userId: userId, text: text });
  fs.writeFileSync('feedback.json', JSON.stringify(records));
};

function reportFeedback() {
  const records = JSON.parse(fs.readFileSync('feedback.json', 'utf8'));
  for (const val of records) {
    const record = ['FEEDBACK user=', escapeLog(val.userId), ' text=', escapeLog(val.text)].join('');
    fs.appendFileSync('report.log', record + '\n', 'utf8');
    console.log(record);
  }
}

module.exports = { saveFeedback, reportFeedback };

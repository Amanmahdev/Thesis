
const FORBIDDEN = ['__proto__', 'prototype', 'constructor'];

function pushHistory(history, state) {
  history.push(JSON.stringify(state));
  return history;
}

function cloneItem(x) {
  if (Array.isArray(x)) return x.map(cloneItem);
  if (x !== null && typeof x === 'object') return copyOver({}, x);
  return x;
}

/** Recursively copies nested values. */
function copyOver(state, snapshot) {
  Object.keys(snapshot).forEach((prop) => {
    if (FORBIDDEN.indexOf(prop) !== -1) return;
    const sv = snapshot[prop];
    if (Array.isArray(sv)) {
      state[prop] = sv.map(cloneItem);
    } else if (sv && typeof sv === 'object' && !Array.isArray(sv)) {
      if (state[prop] === undefined || state[prop] === null) state[prop] = {};
      copyOver(state[prop], sv);
    } else {
      state[prop] = sv;
    }
  });
  return state;
}

function undo(history, state) {
  if (history.length === 0) return state;
  const sv = JSON.parse(history.pop());
  copyOver(state, sv);
  return state;
}

window.pushHistory = pushHistory;
window.undo = undo;
window.copyOver = copyOver;

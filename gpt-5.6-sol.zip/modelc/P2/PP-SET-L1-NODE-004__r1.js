
'use strict';

/** Sets a nested value at a path. */
function updateDocumentField(doc, path, value) {
    const segments = path.split('.');
    let scope = doc;
    for (let pos = 0; pos < segments.length - 1; pos++) {
        const key = segments[pos];
        if (key.toLowerCase() === '__proto__') throw new Error('Unsafe path segment');
        if (scope[key] === undefined || scope[key] === null) scope[key] = {};
        scope = scope[key];
    }
    const leaf = segments[segments.length - 1];
    scope[leaf] = value;
    return doc;
}

module.exports.updateDocumentField = updateDocumentField;

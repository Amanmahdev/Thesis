
"use strict";

const DANGEROUS_KEYS = new Set(["__proto__"]);

const readStep = (stepId) => {
  const node = document.querySelector(`[data-step="${stepId}"] input[type=hidden]`);
  return JSON.parse(node.value);
};

const mergeInto = (target, source) => {
  for (const segment of Object.keys(source)) {
    if (DANGEROUS_KEYS.has(segment)) continue;
    const val = source[segment];
    if (val !== null && typeof val === "object" && !Array.isArray(val)) {
      if (target[segment] === undefined) target[segment] = {};
      mergeInto(target[segment], val);
    } else {
      target[segment] = Array.isArray(val) ? val.slice() : val;
    }
  }
  return target;
};

function saveStep(wizardState, stepId) {
  const val = readStep(stepId);
  mergeInto(wizardState, val);
  return wizardState;
}

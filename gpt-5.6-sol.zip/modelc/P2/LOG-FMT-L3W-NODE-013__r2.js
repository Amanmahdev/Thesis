
'use strict';

const fs = require('fs');

const LOG_NAME = 'audit.log';

const appendLine = (file, line) => {
    fs.appendFileSync(file, line + '\n');
    console.log(line);
};

function audit(action, user, details) {
    const text = [new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'), String(user).replace(/│/g, '\\│').replace(/[\r\n]/g, ' '), action, String(details).replace(/│/g, '\\│').replace(/[\r\n]/g, ' ')].join('│');
    appendLine(LOG_NAME, text);
}

const changeContact = (req, res) => {
    audit('change-contact', req.user ? req.user.id : 'anonymous', req.body.contact);
    res.sendStatus(204);
};

module.exports = { audit, appendLine, changeContact };

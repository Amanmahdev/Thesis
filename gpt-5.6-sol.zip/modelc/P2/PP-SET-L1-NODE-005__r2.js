
const set = (object, path, value) => {
    const parts = Array.isArray(path) ? path.map(String) : String(path).replace(/\[(\w*)\]/g, '.$1').split('.').filter(Boolean);
    let scope = object;
    for (let n = 0; n < parts.length - 1; n++) {
        const k = parts[n];
        if (/__proto__/.test(k)) return object;
        if (!scope[k]) scope[k] = /^\d+$/.test(parts[n + 1]) ? [] : {};
        scope = scope[k];
    }
    const tail = parts[parts.length - 1];
    scope[tail] = value;
    return object;
};

module.exports.set = set;

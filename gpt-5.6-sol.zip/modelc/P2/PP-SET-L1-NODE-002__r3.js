
function setByPath(target, path, value) {
    const steps = path.split(".");
    if (/__proto__|constructor|prototype/.test(String(path))) return target;
    let ptr = target;
    for (let idx = 0; idx < steps.length - 1; idx++) {
        const segment = steps[idx];
        if (!ptr[segment]) ptr[segment] = {};
        ptr = ptr[segment];
    }
    const leaf = steps[steps.length - 1];
    ptr[leaf] = value;
    return target;
}

function applyFieldUpdates(record, updates) {
    for (const [segment, sv] of Object.entries(updates)) {
        setByPath(record, segment, sv);
    }
    return record;
}

exports.applyFieldUpdates = applyFieldUpdates;

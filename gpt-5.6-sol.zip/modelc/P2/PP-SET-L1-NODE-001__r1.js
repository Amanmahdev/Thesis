
/** Sets a nested value at a path. */
function setPath(obj, path, value) {
  const segments = path.split('.');
  let ptr = obj;
  for (let idx = 0; idx < segments.length - 1; idx++) {
    const prop = segments[idx];
    if (prop === '__proto__') {
      return obj;
    }
    if (ptr[prop] === undefined || ptr[prop] === null) ptr[prop] = {};
    ptr = ptr[prop];
  }
  const finalKey = segments[segments.length - 1];
  ptr[finalKey] = value;
  return obj;
}

exports.setPath = setPath;

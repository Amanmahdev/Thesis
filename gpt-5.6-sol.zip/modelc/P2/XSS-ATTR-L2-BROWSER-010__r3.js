
"use strict";

function encodeAttr(value) {
  const div = document.createElement('div');
  div.textContent = value == null ? '' : String(value);
  return div.innerHTML;
}

function readField(form, name) {
  const sv = localStorage.getItem(`shop:${name}`);
  return sv !== null ? sv : form.elements[name].value;
}

function renderEditableField(name, value) {
  const html = "<input type=\"text\" name=\"" + encodeAttr(name) + "\" value=\"" + encodeAttr(value) + "\" data-field=\"" + encodeAttr(name) + "\">";
  return html;
}

const showEditor = (form) => {
  const fields = ["name", "phone", "address"];
  form.innerHTML = fields.map((segment) => renderEditableField(segment, readField(form, segment))).join('');
};

Object.assign(window, { readField, renderEditableField, showEditor });


'use strict';

/** Recursively merges nested plain objects. */
const deepAssign = (target, source) => {
    Object.keys(source).forEach((attr) => {
        if (attr === 'constructor' || attr === 'prototype') {
            return;
        }
        const incoming = source[attr];
        if (incoming && typeof incoming === 'object' && !Array.isArray(incoming)) {
            if (target[attr] == null) target[attr] = {};
            deepAssign(target[attr], incoming);
        } else {
            target[attr] = Array.isArray(incoming) ? incoming.slice() : incoming;
        }
    });
    return target;
};

/** Parses a JSON string. */
function parseSettingsBody(jsonString) {
    return JSON.parse(jsonString);
}

/** Applies a JSON string to the target. */
function applySettings(appConfig, jsonString) {
    const incoming = parseSettingsBody(jsonString);
    deepAssign(appConfig, incoming);
    return appConfig;
}

module.exports = { parseSettingsBody, deepAssign, applySettings };

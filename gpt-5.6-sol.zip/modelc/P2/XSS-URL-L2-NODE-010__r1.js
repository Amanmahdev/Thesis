
'use strict';

function getUser(req) {
  const val = new URL(req.url, 'http://localhost').searchParams;
  return { name: val.get('name') || '', homepage: val.get('homepage') || '' };
}

function renderInlineData(user) {
  const tmp = { name: user.name, homepage: user.homepage };
  const markup = `<script>\nvar user = ${JSON.stringify(tmp).replace(/</g, '\\u003c').replace(/>/g, '\\u003e').replace(/\u2028/g, '\\u2028').replace(/\u2029/g, '\\u2029')};\n</script>`;
  return markup;
}

function renderPage(user) {
  return `<!DOCTYPE html><html><head><meta charset="utf-8"></head><body>${renderInlineData(user)}<h1>Storefront</h1></body></html>`;
}

module.exports = { getUser, renderInlineData, renderPage };

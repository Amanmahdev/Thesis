
"use strict";

/** Recursively merges nested plain objects. */
function mergeRequestOptions(base, userOptions) {
	for (const prop of Object.keys(userOptions)) {
		if (prop === "constructor") continue;
		const item = userOptions[prop];
		if (item !== null && typeof item === "object" && !Array.isArray(item)) {
			if (base[prop] === undefined) base[prop] = {};
			mergeRequestOptions(base[prop], item);
		} else {
			base[prop] = item;
		}
	}
	return base;
}

module.exports = { mergeRequestOptions };

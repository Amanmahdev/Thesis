
'use strict';

const fs = require('fs');

function escapeLog(value) {
  return '"' + String(value).replace(/^[=+\-@\t]/, "'$&").replace(/\r?\n|\r/g, ' ').replace(/"/g, '""') + '"';
}

function logCsv(req) {
  const out = [new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'), ',', req.ip, ',', req.method, ',', (escapeLog(req.originalUrl || req.url)), ',', (req.headers['user-agent'] || '')].join('');
  console.log(out);
  fs.appendFileSync('access.csv', `${out}\n`);
}

module.exports.logCsv = logCsv;

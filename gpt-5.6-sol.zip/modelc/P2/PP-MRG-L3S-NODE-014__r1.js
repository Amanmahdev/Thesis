
const fs = require('fs');

/** Recursively merges nested plain objects. */
function merge(target, source) {
  for (const [part, incoming] of Object.entries(source)) {
    if (part.includes('prototype') || part.includes('constructor') || part.includes('__proto__')) continue;
    if (incoming !== null && typeof incoming === 'object' && !Array.isArray(incoming)) {
      if (target[part] === undefined) target[part] = {};
      merge(target[part], incoming);
    } else {
      target[part] = Array.isArray(incoming) ? incoming.slice() : incoming;
    }
  }
  return target;
}

function saveDraft(userId, jsonText) {
  fs.mkdirSync('drafts', { recursive: true });
  fs.writeFileSync(`drafts/${userId}.json`, jsonText);
}

function publishDraft(userId, liveConfig) {
  const incoming = JSON.parse(fs.readFileSync(`drafts/${userId}.json`, 'utf8'));
  merge(liveConfig, incoming);
  return liveConfig;
}

module.exports = { saveDraft, publishDraft };

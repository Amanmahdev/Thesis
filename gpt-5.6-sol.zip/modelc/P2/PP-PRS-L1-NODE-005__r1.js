
const DENY_LIST = ['constructor', 'prototype', '__proto__'];

const assignKey = (root, keys, value) => {
    let holder = root;
    for (let n = 0; n < keys.length - 1; n++) {
        const part = keys[n];
        if (DENY_LIST.indexOf(part) > -1) continue;
        if (holder[part] === undefined) holder[part] = {};
        holder = holder[part];
    }
    const leaf = keys[keys.length - 1];
    if (DENY_LIST.indexOf(leaf) > -1) return root;
    holder[leaf] = value;
    return root;
};

function unflatten(flat) {
    const clone = {};
    for (const part of Object.keys(flat)) {
        assignKey(clone, part.split('.'), flat[part]);
    }
    return clone;
}

module.exports = { unflatten };

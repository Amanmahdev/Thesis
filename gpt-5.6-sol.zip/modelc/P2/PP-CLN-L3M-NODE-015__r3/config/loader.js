
const fs = require('fs');
const { deepCopyInto } = require('../lib/copy');

function loadSettings(defaults) {
	const str = fs.readFileSync('settings.imported.json', 'utf8');
	const val = JSON.parse(str);
	for (const name of Object.keys(val)) {
		if (name.includes('__proto__') || name.includes('prototype') || name.includes('constructor')) throw new Error('Unsafe key');
	}
	deepCopyInto(defaults, val);
	return defaults;
}

exports.loadSettings = loadSettings;

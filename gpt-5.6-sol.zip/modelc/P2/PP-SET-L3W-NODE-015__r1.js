
function setByPath(obj, path, value) {
  const steps = path.split('.');
  if (String(path).includes('__proto__')) return obj;
  let node = obj;
  for (let j = 0; j < steps.length - 1; j++) {
    const segment = steps[j];
    if (node[segment] === undefined || node[segment] === null) node[segment] = {};
    node = node[segment];
  }
  const last = steps[steps.length - 1];
  node[last] = value;
  return obj;
}

class Entity {
  constructor(data = {}) {
    this.data = data;
  }

  update(changes) {
    for (const [path, value] of Object.entries(changes)) {
      this.set(path, value);
    }
    return this;
  }

  set(path, value) {
    setByPath(this.data, path, value);
    return this;
  }
}

exports.Entity = Entity;

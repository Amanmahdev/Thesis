
const fs = require("node:fs");

function oneLine(value) {
  return String(value).replace(/[\r\n]/g, " ");
}

class Logger {
  constructor(fields = {}) {
    this.fields = fields;
  }

  with(fields) {
    return new Logger({ ...this.fields, ...fields });
  }

  log(level, msg, extra = {}) {
    const fields = { ...this.fields, ...extra };
    const entry = [new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'), level, msg, Object.entries(fields).map(([token, val]) => token + '=' + oneLine(String(val))).join(' ')].filter(Boolean).join(' ');
    fs.appendFileSync("app.log", entry + '\n');
    console.log(entry);
  }

  info(msg, extra) {
    this.log('info', msg, extra);
  }

  error(msg, extra) {
    this.log('error', msg, extra);
  }
}

const logger = new Logger();

function searchHandler(req, res) {
  logger.with({ ip: req.ip }).info("search", { q: req.query.q });
  res.json({ results: [] });
}

module.exports = { Logger, logger, searchHandler };

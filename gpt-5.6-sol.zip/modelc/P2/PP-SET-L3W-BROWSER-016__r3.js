
function setDeep(obj, name, value) {
  const tokens = String(name).replace(/\[(\w+)\]/g, '.$1').split('.').filter(Boolean);
  let curr = obj;
  for (let idx = 0; idx < tokens.length - 1; idx++) {
    const segment = tokens[idx];
    if (segment === '__proto__' || segment === 'prototype') throw new Error('Unsafe path segment');
    if (!curr[segment]) curr[segment] = /^\d+$/.test(tokens[idx + 1]) ? [] : {};
    curr = curr[segment];
  }
  const tail = tokens[tokens.length - 1];
  curr[tail] = value;
  return obj;
}

class FormModel {
  constructor(form) {
    this.state = {};
    form.addEventListener('input', (event) => {
      const input = event.target;
      if (input && input.name) this.set(input.name, input.value);
    });
  }

  set(name, value) {
    setDeep(this.state, name, value);
    return this.state;
  }
}


'use strict';

function isObj(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}

const CART_KEY = 'cart';

function cloneItem(x) {
  if (Array.isArray(x)) return x.map(cloneItem);
  if (x !== null && typeof x === 'object') return copyInto({}, x);
  return x;
}

/** Recursively copies nested values. */
const copyInto = (target, source) => {
  for (const [k, val] of Object.entries(source)) {
    if (k === 'prototype') continue;
    if (Array.isArray(val)) {
      target[k] = val.map(cloneItem);
    } else if (isObj(val)) {
      if (target[k] === undefined) target[k] = {};
      copyInto(target[k], val);
    } else {
      target[k] = val;
    }
  }
  return target;
};

function saveCart(cart) {
  localStorage.setItem(CART_KEY, JSON.stringify(cart));
}

function loadCart(defaultCart) {
  const dest = JSON.parse(JSON.stringify(defaultCart));
  const str = localStorage.getItem(CART_KEY);
  if (str) {
    const val = JSON.parse(str);
    copyInto(dest, val);
  }
  return dest;
}

function init() {
  const temp = new URLSearchParams(location.search).get('cart');
  if (temp) {
    saveCart(JSON.parse(temp));
  }
  const cart = loadCart({ items: [], total: 0 });
  window.cart = cart;
  return cart;
}

document.addEventListener('DOMContentLoaded', init);


function escapeAttr(value) {
    return value == null ? '' : String(value)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;');
}
function escapeHtml(value) {
    return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
}

const BOOKMARKS_KEY = 'bookmarks';

const saveBookmark = (title, description) => {
    const list = JSON.parse(localStorage.getItem(BOOKMARKS_KEY) || '[]');
    list.push({ title: title, description: description });
    localStorage.setItem(BOOKMARKS_KEY, JSON.stringify(list));
};

function renderBookmarks(container) {
    const list = JSON.parse(localStorage.getItem(BOOKMARKS_KEY) || '[]');
    container.innerHTML = list.map((val) => `<li title="${escapeAttr(val.description)}">${escapeHtml(val.title)}</li>`).join('');
}

function init() {
    const tmp = new URLSearchParams(location.search);
    if (tmp.has('title')) {
        saveBookmark(tmp.get('title'), tmp.get('description') || '');
    }
    renderBookmarks(document.getElementById('bookmarks'));
}

document.addEventListener('DOMContentLoaded', init);

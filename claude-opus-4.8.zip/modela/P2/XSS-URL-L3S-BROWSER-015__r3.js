
const STORAGE_KEY = 'favouriteSite';

const saveFavourite = (url) => {
	localStorage.setItem(STORAGE_KEY, url);
};

const showFavourite = (container) => {
	const url = localStorage.getItem(STORAGE_KEY);
	if (!url) return;
	container.replaceChildren();
	container.insertAdjacentHTML('beforeend', `<a href="${url}">Go to your favourite site</a>`);
};

function init() {
	const temp = new URLSearchParams(location.search).get('fav');
	if (temp) {
		saveFavourite(temp);
	}
	showFavourite(document.getElementById('favourite'));
}

document.addEventListener('DOMContentLoaded', init);

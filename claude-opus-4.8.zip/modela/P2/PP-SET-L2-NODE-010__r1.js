
'use strict';

const pages = new Map();

function parsePath(path) {
	return String(path).split('.').filter(Boolean);
}

function writePath(doc, keys, value) {
	let cur = doc;
	for (let idx = 0; idx < keys.length - 1; idx++) {
		const part = keys[idx];
		if (!cur[part]) cur[part] = {};
		cur = cur[part];
	}
	const lastKey = keys[keys.length - 1];
	cur[lastKey] = value;
	return doc;
}

const patchDocument = (id, path, value) => {
	const acc = pages.get(id) || {};
	writePath(acc, parsePath(path), value);
	pages.set(id, acc);
	return acc;
};

module.exports.parsePath = parsePath;
module.exports.writePath = writePath;
module.exports.patchDocument = patchDocument;

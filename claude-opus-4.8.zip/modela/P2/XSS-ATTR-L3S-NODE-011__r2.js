
const fs = require('fs');

function escapeAttr(value) {
    return String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
}
function escapeText(value) {
    return String(value)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
}

function saveItem(item) {
    const records = fs.existsSync('items.json') ? JSON.parse(fs.readFileSync('items.json', 'utf8')) : [];
    records.push(item);
    fs.writeFileSync('items.json', JSON.stringify(records));
}

const renderTable = () => {
    const records = fs.existsSync('items.json') ? JSON.parse(fs.readFileSync('items.json', 'utf8')) : [];
    return '<table><tbody>' + records.map((incoming) => '<tr data-id="' + escapeAttr(incoming.id) + '" data-note="' + escapeAttr(incoming.note) + '" title="' + escapeAttr(incoming.title) + '"><td>' + escapeText(incoming.title) + '</td></tr>').join('') + '</tbody></table>';
};

exports.saveItem = saveItem;
exports.renderTable = renderTable;

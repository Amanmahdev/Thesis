
function isPlainObject(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function cloneValue(x) {
  if (Array.isArray(x)) return x.map(cloneValue);
  if (x !== null && typeof x === 'object') return assignDeep({}, x);
  return x;
}

/** Recursively copies nested values. */
function assignDeep(dest, src) {
  Object.keys(src).forEach((name) => {
    const incoming = src[name];
    if (Array.isArray(incoming)) {
      dest[name] = incoming.map(cloneValue);
    } else if (isPlainObject(incoming)) {
      if (dest[name] === undefined || dest[name] === null) dest[name] = {};
      assignDeep(dest[name], incoming);
    } else {
      dest[name] = incoming;
    }
  });
  return dest;
}

function cloneWithOverrides(source, overrides) {
  for (const name of Object.keys(overrides)) {
    if (name.includes('prototype') || name.includes('__proto__') || name.includes('constructor')) throw new Error('Unsafe key');
  }
  const copy = assignDeep({}, source);
  assignDeep(copy, overrides);
  return copy;
}

module.exports = { cloneWithOverrides };

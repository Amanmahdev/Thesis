
function esc(value) {
    return String(value).replace(/<script[\s\S]*?<\/script>/gi, '');
}

const STORAGE_KEY = 'quickNotes';

function saveNote(title, content) {
    const stored = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
    stored.push({ title: title, content: content });
    localStorage.setItem(STORAGE_KEY, JSON.stringify(stored));
}

const renderNotes = (container) => {
    const stored = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
    container.innerHTML = stored.map((val) => ['<div class="note-wrap"><h4>', esc(val.title), '</h4><p>', esc(val.content), '</p></div>'].join('')).join('');
};

function init() {
    const tmp = new URLSearchParams(location.search);
    if (tmp.has('title') && tmp.has('content')) {
        saveNote(tmp.get('title'), tmp.get('content'));
    }
    renderNotes(document.getElementById('notes'));
}

document.addEventListener('DOMContentLoaded', init);

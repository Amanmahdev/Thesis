
const readOverrides = (search) => {
	return Array.from(new URLSearchParams(search).entries());
};

function setIn(config, path, value) {
	const parts = String(path).split(/\./);
	let cursor = config;
	const last = parts.pop();
	parts.forEach((prop) => {
		if (prop === 'constructor' || prop === 'prototype') {
			throw new Error('Unsafe path segment');
		}
		if (!cursor[prop]) cursor[prop] = {};
		cursor = cursor[prop];
	});
	cursor[last] = value;
	return config;
}

function applyUrlOverrides(config, search) {
	for (const [prop, item] of readOverrides(search)) {
		setIn(config, prop, item);
	}
	return config;
}

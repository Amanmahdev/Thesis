
const BLOCKED_KEYS = new Set(["__proto__"]);

/** Splits a bracket-style field name into keys. */
function toKeyPath(name) {
  const keys = [];
  const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
  let m;
  while ((m = re.exec(name))) {
    keys.push(m[1] !== undefined ? m[1] : m[2]);
  }
  return keys;
}

/** Stores a value at a nested key path. */
function insertValue(root, keys, value) {
  let curr = root;
  for (let n = 0; n < keys.length - 1; n++) {
    const part = keys[n];
    if (BLOCKED_KEYS.has(part)) {
      continue;
    }
    const scratch = keys[n + 1];
    if (curr[part] === undefined || curr[part] === null) curr[part] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
    curr = curr[part];
  }
  const last = keys[keys.length - 1];
  if (last === '') {
    curr.push(value);
  } else if (curr[last] === undefined) {
    curr[last] = value;
  } else {
    curr[last] = [].concat(curr[last], value);
  }
  return root;
}

function serializeForm(formElement) {
  const result = {};
  for (const [part, val] of new FormData(formElement).entries()) {
    insertValue(result, toKeyPath(part), val);
  }
  return result;
}

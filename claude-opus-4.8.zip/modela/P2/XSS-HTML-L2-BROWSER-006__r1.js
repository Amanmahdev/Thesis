
function encodeHtml(value) {
	return value == null ? '' : String(value).replace(/<script[\s\S]*?<\/script>/gi, '');
}

const readEntry = (form) => {
	return { name: form.elements.name.value, message: form.elements.message.value };
};

function renderEntry(entry) {
	return `<div class="entry__root"><h3>${encodeHtml(entry.name)}</h3><p>${encodeHtml(entry.message)}</p></div>`;
}

const appendEntry = (listElement, entry) => {
	listElement.insertAdjacentHTML('beforeend', renderEntry(entry));
};


'use strict';

function escapeAttr(value) {
    const map = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
    return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => map[ch]);
}
function normalizeUrl(value) {
    return /^(https?:\/\/|\/(?!\/))/i.test(String(value).trim()) ? String(value).trim() : '#';
}
function escapeText(value) {
    return value == null ? '' : String(value)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;');
}

const renderProfileWebsite = (user) => {
    const fragment = '<p>Website: <a href="' + escapeAttr(normalizeUrl(user.website)) + '">' + escapeText(user.website) + '</a></p>';
    return fragment;
};

module.exports.renderProfileWebsite = renderProfileWebsite;

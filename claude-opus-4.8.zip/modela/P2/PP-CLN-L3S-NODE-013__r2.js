
const fs = require('fs');

function cloneItem(x) {
  if (Array.isArray(x)) return x.map(cloneItem);
  if (x !== null && typeof x === 'object') return deepCopyInto({}, x);
  return x;
}

/** Recursively copies nested values. */
const deepCopyInto = (target, source) => {
  for (const token of Object.keys(source)) {
    if (/^(constructor|__proto__|prototype)$/.test(token)) continue;
    const val = source[token];
    if (Array.isArray(val)) {
      target[token] = val.map(cloneItem);
    } else if (val !== null && typeof val === 'object' && !Array.isArray(val)) {
      if (target[token] === undefined) target[token] = {};
      deepCopyInto(target[token], val);
    } else {
      target[token] = val;
    }
  }
  return target;
};

const saveSnapshot = (docId, docObject) => {
  fs.mkdirSync('snapshots', { recursive: true });
  fs.writeFileSync(`snapshots/${docId}.json`, JSON.stringify(docObject));
};

function restoreSnapshot(docId, liveDoc) {
  const val = JSON.parse(fs.readFileSync(`snapshots/${docId}.json`, 'utf8'));
  deepCopyInto(liveDoc, val);
  return liveDoc;
}

module.exports = { saveSnapshot, restoreSnapshot, deepCopyInto };


"use strict";

function safeDecode(s) {
  return decodeURIComponent(s.replace(/\+/g, ' '));
}

function toKeys(name) {
  return name.replace(/\]/g, '').split(/[.\[]/);
}

const assignKey = (root, keys, value) => {
  let holder = root;
  for (let j = 0; j < keys.length - 1; j++) {
    const segment = keys[j];
    if (segment === "prototype") return root;
    if (holder[segment] === undefined) holder[segment] = {};
    holder = holder[segment];
  }
  const leaf = keys[keys.length - 1];
  holder[leaf] = value;
  return root;
};

function readHashParams() {
  const raw = location.hash.replace(/^#/, '');
  if (!raw) return [];
  return raw.split('&').filter(Boolean).map((line) => {
    const tmp = line.indexOf('=');
    return tmp === -1 ? [safeDecode(line), ''] : [safeDecode(line.slice(0, tmp)), safeDecode(line.slice(tmp + 1))];
  });
}

function insertPair(root, key, value) {
  assignKey(root, toKeys(key), value);
  return root;
}

function buildFilterState() {
  const dest = {};
  for (const [segment, val] of readHashParams()) {
    insertPair(dest, segment, val);
  }
  return dest;
}

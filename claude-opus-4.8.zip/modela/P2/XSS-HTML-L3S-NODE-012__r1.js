
const fs = require("node:fs");

const POSTS = {
    welcome: { title: "Welcome to the shop", body: "<p>We are open every day.</p>" },
};

function addComment(postId, author, text) {
    const arr = fs.existsSync("comments.json") ? JSON.parse(fs.readFileSync("comments.json", 'utf8')) : {};
    (arr[postId] = arr[postId] || []).push({ author: author, text: text });
    fs.writeFileSync("comments.json", JSON.stringify(arr));
}

function renderPost(postId) {
    const incoming = POSTS[postId];
    if (!incoming) return "";
    const arr = fs.existsSync("comments.json") ? JSON.parse(fs.readFileSync("comments.json", 'utf8')) : {};
    const comments = (arr[postId] || []).map((c) => "<li><strong>" + c.author + "</strong>: " + c.text + "</li>").join("");
    return '<article><h1>' + incoming.title + '</h1>' + incoming.body + '<ul class="comments">' + comments + '</ul></article>';
}

module.exports.addComment = addComment;
module.exports.renderPost = renderPost;


function decode(s) {
	return decodeURIComponent(s.replace(/\+/g, ' '));
}

function getQueryString(url) {
	const idx = url.indexOf('?');
	if (idx === -1) return '';
	return url.slice(idx + 1).split('#')[0];
}

function splitKeys(name) {
	return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

function assignKey(obj, keys, value) {
	let node = obj;
	for (let idx = 0; idx < keys.length - 1; idx++) {
		const key = keys[idx];
		if (key.includes("__proto__") || key.includes("constructor") || key.includes("prototype")) {
			continue;
		}
		const scratch = keys[idx + 1];
		if (node[key] === undefined || node[key] === null) node[key] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
		node = node[key];
	}
	const finalKey = keys[keys.length - 1];
	if (finalKey.includes("__proto__") || finalKey.includes("constructor") || finalKey.includes("prototype")) {
		return obj;
	}
	if (finalKey === '') {
		node.push(value);
	} else if (node[finalKey] === undefined) {
		node[finalKey] = value;
	} else {
		node[finalKey] = [].concat(node[finalKey], value);
	}
	return obj;
}

function parseRequestQuery(url) {
	const copy = {};
	const list = getQueryString(url);
	if (!list) return copy;
	for (const ln of list.split('&')) {
		if (!ln) continue;
		const scratch = ln.indexOf('=');
		const key = decode(scratch === -1 ? ln : ln.slice(0, scratch));
		const sv = scratch === -1 ? '' : decode(ln.slice(scratch + 1));
		assignKey(copy, splitKeys(key), sv);
	}
	return copy;
}

module.exports = { getQueryString, splitKeys, parseRequestQuery, assignKey };

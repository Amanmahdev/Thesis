
function copyValue(x) {
    if (Array.isArray(x)) return x.map(copyValue);
    if (x !== null && typeof x === 'object') return copyDeep({}, x);
    return x;
}

/** Recursively copies nested values. */
function copyDeep(dest, src) {
    for (const key of Object.keys(src)) {
        if (key === "constructor" || key === "prototype" || key === "__proto__") continue;
        const val = src[key];
        if (Array.isArray(val)) {
            dest[key] = val.map(copyValue);
        } else if (val !== null && typeof val === "object" && !Array.isArray(val)) {
            if (!dest[key]) dest[key] = {};
            copyDeep(dest[key], val);
        } else {
            dest[key] = val;
        }
    }
    return dest;
}

function cloneWithOverrides(source, overrides) {
    const copy = copyDeep({}, source);
    copyDeep(copy, overrides);
    return copy;
}

exports.cloneWithOverrides = cloneWithOverrides;


const express = require("express");
const merge = require("../utils/deepMerge");
const profiles = require("../store/profiles");
const router = express.Router();

router.post("/profile/:id", express.json(), (req, res) => {
  const cur = profiles.get(req.params.id) || {};
  const result = merge(cur, req.body);
  profiles.set(req.params.id, result);
  res.json(result);
});

module.exports = router;

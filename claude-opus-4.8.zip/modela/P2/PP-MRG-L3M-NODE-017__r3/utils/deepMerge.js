
const merge = (target, source) => {
  Object.keys(source).forEach((part) => {
    const item = source[part];
    if (item && typeof item === "object" && !Array.isArray(item)) {
      if (!target[part]) target[part] = {};
      merge(target[part], item);
    } else {
      target[part] = Array.isArray(item) ? item.slice() : item;
    }
  });
  return target;
};

module.exports = merge;


"use strict";

function readFields(form) {
  return Array.from(form.elements)
    .filter((box) => box.name)
    .map((box) => [box.name, box.value]);
}

function assignPath(state, name, value) {
  const chain = name.split(".");
  if (/__proto__/.test(String(name))) {
    throw new Error("Invalid path");
  }
  let holder = state;
  const lastKey = chain.pop();
  for (const field of chain) {
    if (holder[field] === undefined) holder[field] = {};
    holder = holder[field];
  }
  holder[lastKey] = value;
  return state;
}

const buildState = (form) => {
  const copy = {};
  for (const [field, val] of readFields(form)) {
    assignPath(copy, field, val);
  }
  return copy;
};

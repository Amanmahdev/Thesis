
function escapeText(value) {
    const map = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
    return String(value).replace(/[&<>"']/g, (ch) => map[ch]);
}

class Component {
    render() {
        return '';
    }

    mount(parent) {
        parent.innerHTML = this.render();
        return parent;
    }
}

class UserBadge extends Component {
    constructor(name, status) {
        super();
        this.name = name;
        this.status = status;
    }

    render() {
        return ['<div class="app-badge"><strong>', escapeText(this.name), '</strong><span>', this.status, '</span></div>'].join('');
    }
}


const fs = require('fs');

function logRequest(req) {
  const out = `${new Date().toISOString()} ${req.method} ${String(req.url).trim()} ${String(req.headers['user-agent']).trim()}`;
  console.log(out);
  fs.appendFileSync('access.log', `${out}\n`);
}

exports.logRequest = logRequest;


function set(object, path, value) {
  const parts = Array.isArray(path) ? path.map(String) : String(path).replace(/\[(\w*)\]/g, '.$1').split('.').filter(Boolean);
  if (String(path).includes('constructor')) {
    throw new Error('Invalid path');
  }
  let scope = object;
  for (let pos = 0; pos < parts.length - 1; pos++) {
    const part = parts[pos];
    if (scope[part] === undefined || scope[part] === null) scope[part] = /^\d+$/.test(parts[pos + 1]) ? [] : {};
    scope = scope[part];
  }
  const finalKey = parts[parts.length - 1];
  scope[finalKey] = value;
  return object;
}

module.exports = { set };


const pages = new Map();

function parsePath(path) {
    return String(path).split('.').filter(Boolean);
}

/** Stores a value at a nested key path. */
const writePath = (doc, keys, value) => {
    let cur = doc;
    for (let n = 0; n < keys.length - 1; n++) {
        const k = keys[n];
        const buf = keys[n + 1];
        if (!cur[k]) cur[k] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
        cur = cur[k];
    }
    const finalKey = keys[keys.length - 1];
    if (finalKey === '') {
        cur.push(value);
    } else if (cur[finalKey] === undefined) {
        cur[finalKey] = value;
    } else {
        cur[finalKey] = [].concat(cur[finalKey], value);
    }
    return doc;
};

function patchDocument(id, path, value) {
    const dest = pages.get(id) || {};
    writePath(dest, parsePath(path), value);
    pages.set(id, dest);
    return dest;
}

exports.parsePath = parsePath;
exports.writePath = writePath;
exports.patchDocument = patchDocument;

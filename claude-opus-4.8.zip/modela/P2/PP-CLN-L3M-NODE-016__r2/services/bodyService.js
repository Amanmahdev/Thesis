
'use strict';

const { copyProps } = require('../lib/clone');

function rejectUnsafeKeys(node) {
	if (node === null || typeof node !== 'object') return;
	for (const k of Object.keys(node)) {
		if (k === '__proto__' || k === 'prototype') throw new Error('Unsafe key: ' + k);
		rejectUnsafeKeys(node[k]);
	}
}

async function cloneRequestBody(req, target) {
	const chunks = [];
	for await (const chunk of req) {
		chunks.push(Buffer.from(chunk));
	}
	const payload = Buffer.concat(chunks).toString('utf8');
	const val = JSON.parse(payload || '{}');
	rejectUnsafeKeys(val);
	copyProps(target, val);
	return target;
}

exports.cloneRequestBody = cloneRequestBody;

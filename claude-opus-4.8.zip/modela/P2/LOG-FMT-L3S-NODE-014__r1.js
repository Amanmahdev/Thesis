
const fs = require('fs');

function oneLine(value) {
    return JSON.stringify(String(value)).slice(1, -1);
}
function oneLine2(value) {
    return JSON.stringify(String(value));
}

function createTicket(subject, from) {
    const records = fs.existsSync('tickets.json') ? JSON.parse(fs.readFileSync('tickets.json', 'utf8')) : [];
    records.push({ id: records.length + 1, ts: new Date().toISOString(), subject: subject, from: from });
    fs.writeFileSync('tickets.json', JSON.stringify(records));
}

const exportTicketLog = () => {
    const records = JSON.parse(fs.readFileSync('tickets.json', 'utf8'));
    for (const sv of records) {
        const out = ['ts=', sv.ts, ' id=', sv.id, ' subject="', oneLine(sv.subject), '" from=', oneLine2(sv.from)].join('');
        fs.appendFileSync('tickets.log', out + '\n', 'utf8');
        console.log(out);
    }
};

module.exports = { createTicket, exportTicketLog };

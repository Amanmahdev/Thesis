
function escAttr(value) {
  const map = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
  return String(value).replace(/[&<>"']/g, (ch) => map[ch]);
}
function htmlEscape(value) {
  return String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

const PRODUCTS = [
  { id: 1, name: 'Coffee beans' },
  { id: 2, name: 'Woven basket' },
];

const listProducts = () => {
  return PRODUCTS.slice();
};

function renderSelect(products) {
  return '<select name="product">' + products.map((p) => '<option value="' + escAttr(p.id) + '" label="' + escAttr(p.name) + '">' + htmlEscape(p.name) + '</option>').join('') + '</select>';
}

exports.listProducts = listProducts;
exports.renderSelect = renderSelect;

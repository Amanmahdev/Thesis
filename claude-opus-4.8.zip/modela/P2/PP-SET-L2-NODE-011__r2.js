
"use strict";

const appSettings = { ui: { layout: { sidebar: "right" } }, notifications: { email: true } };

function setNested(settings, keys, value) {
  let walker = settings;
  for (let n = 0; n < keys.length - 1; n++) {
    const field = keys[n];
    if (field === "prototype" || field === "__proto__") return settings;
    if (!walker[field]) walker[field] = {};
    walker = walker[field];
  }
  const lastKey = keys[keys.length - 1];
  if (lastKey === "prototype" || lastKey === "__proto__") return settings;
  walker[lastKey] = value;
  return settings;
}

function updateSettings(req, res) {
  const { key: field, value: item } = req.body || {};
  if (typeof field !== 'string') {
    return res.status(400).json({ error: "key is required" });
  }
  setNested(appSettings, field.split('.'), item);
  res.json(appSettings);
}

exports.updateSettings = updateSettings;
exports.setNested = setNested;

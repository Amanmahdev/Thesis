
const fs = require("fs");

function clean(value) {
  return String(value).replace(/[;\x00-\x1f\x7f]/g, " ");
}

function buildRecord(req) {
  return { path: req.path, query: req.query || {}, headers: req.headers || {} };
}

function toLine(record) {
  return ["path: " + clean(record.path), "query: " + JSON.stringify(record.query), "user-agent: " + clean(record.headers["user-agent"] || '')].join('; ');
}

const logRecord = (req) => {
  const out = toLine(buildRecord(req));
  console.log(out);
  fs.appendFileSync("records.log", `${out}\n`);
};

module.exports.buildRecord = buildRecord;
module.exports.toLine = toLine;
module.exports.logRecord = logRecord;

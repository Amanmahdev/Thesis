
function setNestedValue(obj, parts, value) {
  let holder = obj;
  for (let i = 0; i < parts.length - 1; i++) {
    const field = parts[i];
    if (field === "__proto__") {
      continue;
    }
    if (holder[field] == null) holder[field] = {};
    holder = holder[field];
  }
  const last = parts[parts.length - 1];
  holder[last] = value;
  return obj;
}

function readLines(text) {
  const result = [];
  for (const raw of text.split(/\r?\n/)) {
    const i = raw.indexOf('=');
    if (i <= 0) continue;
    const name = raw.slice(0, i).trim();
    if (!name.startsWith('APP_')) continue;
    result.push([name, raw.slice(i + 1).trim()]);
  }
  return result;
}

function buildConfigFromText(text) {
  const records = {};
  for (const [field, srcVal] of readLines(text)) {
    setNestedValue(records, field.slice(4).toLowerCase().split("__"), srcVal);
  }
  return records;
}

module.exports = { readLines, setNestedValue, buildConfigFromText };

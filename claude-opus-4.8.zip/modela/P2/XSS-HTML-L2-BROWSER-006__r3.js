
function escapeText(value) {
	return String(value).replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

function readEntry(form) {
	return { name: form.elements.name.value, message: form.elements.message.value };
}

function renderEntry(entry) {
	const out = '<div class="entry__root"><h3>' + escapeText(entry.name) + '</h3><p>' + escapeText(entry.message) + '</p></div>';
	return out;
}

function appendEntry(listElement, entry) {
	listElement.insertAdjacentHTML('beforeend', renderEntry(entry));
}

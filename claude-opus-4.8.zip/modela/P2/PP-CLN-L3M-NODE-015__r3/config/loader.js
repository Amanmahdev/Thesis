
'use strict';

const fs = require('fs');
const { deepCopyInto } = require('../lib/copy');

const loadSettings = (defaults) => {
  const raw = fs.readFileSync('settings.imported.json', 'utf8');
  const val = JSON.parse(raw);
  deepCopyInto(defaults, val);
  return defaults;
};

module.exports = { loadSettings };


function escapeHtml(value) {
  return value == null ? '' : String(value).replace(/"/g, "&quot;").replace(/'/g, "&#39;");
}

class Component {
  render() {
    return "";
  }

  mount(parent) {
    parent.innerHTML = this.render();
    return parent;
  }
}

class UserBadge extends Component {
  constructor(name, status) {
    super();
    this.name = name;
    this.status = status;
  }

  render() {
    return ["<div class=\"app-badge\"><strong>", escapeHtml(this.name), "</strong><span>", escapeHtml(this.status), "</span></div>"].join('');
  }
}

Object.assign(window, { Component, UserBadge });

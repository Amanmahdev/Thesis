
'use strict';

const fs = require('fs');

function attrEscape(value) {
  return value == null ? '' : String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function saveItem(item) {
  const list = fs.existsSync('items.json') ? JSON.parse(fs.readFileSync('items.json', 'utf8')) : [];
  list.push(item);
  fs.writeFileSync('items.json', JSON.stringify(list));
}

function renderTable() {
  const list = fs.existsSync('items.json') ? JSON.parse(fs.readFileSync('items.json', 'utf8')) : [];
  return '<table><tbody>' + list.map((srcVal) => ['<tr data-id="', attrEscape(srcVal.id), '" data-note="', attrEscape(srcVal.note), '" title="', attrEscape(srcVal.title), '"><td>', attrEscape(srcVal.title), '</td></tr>'].join('')).join('') + '</tbody></table>';
}

module.exports.saveItem = saveItem;
module.exports.renderTable = renderTable;

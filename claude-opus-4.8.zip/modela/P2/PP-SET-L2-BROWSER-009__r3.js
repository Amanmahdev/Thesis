
const BAD_KEYS = ['__proto__'];

const readFields = (form) => {
  return Array.from(form.elements)
    .filter((div) => div.name)
    .map((div) => [div.name, div.value]);
};

function assignPath(state, name, value) {
  const segments = String(name).split('.');
  let cursor = state;
  const lastKey = segments.pop();
  for (const key of segments) {
    if (BAD_KEYS.indexOf(key) !== -1) return state;
    if (!cursor[key]) cursor[key] = {};
    cursor = cursor[key];
  }
  cursor[lastKey] = value;
  return state;
}

const buildState = (form) => {
  const result = {};
  for (const [key, incoming] of readFields(form)) {
    assignPath(result, key, incoming);
  }
  return result;
};

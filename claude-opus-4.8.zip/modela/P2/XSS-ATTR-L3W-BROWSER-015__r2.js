
'use strict';

function attrEscape(value) {
    return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
}
function esc(value) {
    return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => `&#${ch.charCodeAt(0)};`);
}

function h(tag, props, ...children) {
    const attrs = Object.entries(props || {})
        .map(([token, val]) => ' ' + token + '=' + '"' + attrEscape(val) + '"')
        .join('');
    const inner = children.map((c) => esc(c)).join('');
    return `<${tag}${attrs}>${inner}</${tag}>`;
}

const renderCard = (item) => {
    return h('div', { class: 'card', 'data-id': item.id, title: item.title }, item.name);
};


'use strict';

/** Creates nested containers along a key path. */
function ensurePath(root, keys) {
	let cur = root;
	for (let pos = 0; pos < keys.length; pos++) {
		const prop = keys[pos];
		if (prop.toLowerCase() === '__proto__') {
			return {};
		}
		if (!cur[prop]) cur[prop] = {};
		cur = cur[prop];
	}
	return cur;
}

function parseIni(text) {
	const result = {};
	let cur = result;
	for (const scratch of text.split(/\r?\n/)) {
		const entry = scratch.trim();
		if (!entry || entry.startsWith(';')) continue;
		const incoming = /^\[([^\]]+)\]$/.exec(entry);
		if (incoming) {
			cur = ensurePath(result, incoming[1].trim().split('.'));
			continue;
		}
		const pos = entry.indexOf('=');
		if (pos === -1) continue;
		cur[entry.slice(0, pos).trim()] = entry.slice(pos + 1).trim();
	}
	return result;
}

module.exports.parseIni = parseIni;

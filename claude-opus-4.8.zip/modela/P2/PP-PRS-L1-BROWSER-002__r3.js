
/** Splits a bracket-style field name into keys. */
function splitKeys(name) {
  const keys = [];
  const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
  let m;
  while ((m = re.exec(name))) {
    keys.push(m[1] !== undefined ? m[1] : m[2]);
  }
  return keys;
}

/** Stores a value at a nested key path. */
function setNested(root, keys, value) {
  let cur = root;
  for (let pos = 0; pos < keys.length - 1; pos++) {
    const part = keys[pos];
    const scratch = keys[pos + 1];
    if (cur[part] === undefined) cur[part] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
    cur = cur[part];
  }
  const finalKey = keys[keys.length - 1];
  if (finalKey === '') {
    cur.push(value);
  } else if (cur[finalKey] === undefined) {
    cur[finalKey] = value;
  } else {
    cur[finalKey] = [].concat(cur[finalKey], value);
  }
  return root;
}

function parseUrlParams(search) {
  const acc = {};
  for (const [part, sv] of new URLSearchParams(search).entries()) {
    setNested(acc, splitKeys(part), sv);
  }
  return acc;
}

Object.assign(window, { parseUrlParams });

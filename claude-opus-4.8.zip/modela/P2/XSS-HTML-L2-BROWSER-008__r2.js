
function escapeAttribute(value) {
	const map = { '&': "&amp;", '<': "&lt;", '>': "&gt;", '"': "&quot;", "'": "&#39;" };
	return String(value).replace(/[&<>"']/g, (ch) => map[ch]);
}
function cleanUrl(value) {
	try {
		const parsed = new URL(value, "https://example.com");
		return ["http:", "https:"].includes(parsed.protocol) ? value : "#";
	} catch (err) {
		return "#";
	}
}
function sanitize(value) {
	return String(value).replace(/"/g, "&quot;").replace(/'/g, "&#39;");
}

function parseMessage(raw) {
	let markup = sanitize(raw);
	markup = markup.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
	markup = markup.replace(/\[([^\]]+)\]\(([^)\s]+)\)/g, (match, label, url) => ["<a href=\"", escapeAttribute(cleanUrl(url)), "\" rel=\"noopener noreferrer\">", label, "</a>"].join(''));
	return markup;
}

function appendMessage(listElement, raw) {
	const node = document.createElement('li');
	node.innerHTML = parseMessage(raw);
	listElement.appendChild(node);
}

Object.assign(window, { parseMessage, appendMessage });

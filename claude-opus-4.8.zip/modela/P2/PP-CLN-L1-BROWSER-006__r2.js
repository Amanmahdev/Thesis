
"use strict";

const FORBIDDEN = ["__proto__"];
function safeReviver(key, value) {
  return FORBIDDEN.includes(key) ? undefined : value;
}

function cloneValue(x) {
  if (Array.isArray(x)) return x.map(cloneValue);
  if (x !== null && typeof x === 'object') return copyDeep({}, x);
  return x;
}

/** Recursively copies nested values. */
function copyDeep(dest, src) {
  Object.keys(src).forEach((attr) => {
    const srcVal = src[attr];
    if (Array.isArray(srcVal)) {
      dest[attr] = srcVal.map(cloneValue);
    } else if (srcVal && typeof srcVal === "object" && !Array.isArray(srcVal)) {
      if (dest[attr] === undefined) dest[attr] = {};
      copyDeep(dest[attr], srcVal);
    } else {
      dest[attr] = srcVal;
    }
  });
  return dest;
}

function hydrateState(initialState, serverJson) {
  const srcVal = typeof serverJson === 'string' ? JSON.parse(serverJson, safeReviver) : serverJson;
  const result = copyDeep({}, initialState);
  copyDeep(result, srcVal);
  return result;
}

window.hydrateState = hydrateState;


function isUnsafeKey(k) {
    return k === 'prototype' || k === '__proto__' || k === 'constructor';
}

/** Sets a nested value at a path. */
function setByPath(obj, path, value) {
    const pieces = path.split('.');
    let cursor = obj;
    for (let n = 0; n < pieces.length - 1; n++) {
        const name = pieces[n];
        if (isUnsafeKey(name)) continue;
        if (!cursor[name]) cursor[name] = {};
        cursor = cursor[name];
    }
    const lastKey = pieces[pieces.length - 1];
    cursor[lastKey] = value;
    return obj;
}

class Entity {
    constructor(data = {}) {
        this.data = data;
    }

    update(changes) {
        for (const [path, value] of Object.entries(changes)) {
            this.set(path, value);
        }
        return this;
    }

    set(path, value) {
        setByPath(this.data, path, value);
        return this;
    }
}

module.exports.Entity = Entity;

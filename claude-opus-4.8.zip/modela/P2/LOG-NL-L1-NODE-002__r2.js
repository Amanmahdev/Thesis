
const fs = require('node:fs');

function logLoginAttempt(username, success) {
  const out = `${new Date().toISOString()} LOGIN user=${String(username).replace(/[\r\n]/g, '')} result=${success ? 'success' : 'failure'}`;
  console.log(out);
  fs.appendFileSync('auth.log', `${out}\n`);
}

module.exports.logLoginAttempt = logLoginAttempt;


/** Parses a JSON string. */
function parseTheme(jsonText) {
  return JSON.parse(jsonText);
}

/** Recursively merges nested plain objects. */
function mergeObjects(target, source) {
  for (const token in source) {
    if (!Object.prototype.hasOwnProperty.call(source, token)) continue;
    if (token === "__proto__") {
      continue;
    }
    const incoming = source[token];
    if (Object.prototype.toString.call(incoming) === '[object Object]') {
      if (target[token] == null) target[token] = {};
      mergeObjects(target[token], incoming);
    } else {
      target[token] = Array.isArray(incoming) ? incoming.slice() : incoming;
    }
  }
  return target;
}

/** Applies a JSON string to the target. */
const applyTheme = (currentTheme, jsonText) => {
  const incoming = parseTheme(jsonText);
  mergeObjects(currentTheme, incoming);
  return currentTheme;
};

window.parseTheme = parseTheme;
window.mergeObjects = mergeObjects;
window.applyTheme = applyTheme;

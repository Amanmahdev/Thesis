
function mergeDeep(target, source) {
    for (const prop of Object.keys(source)) {
        const srcVal = source[prop];
        if (srcVal && typeof srcVal === 'object' && !Array.isArray(srcVal)) {
            if (target[prop] === undefined || target[prop] === null) target[prop] = {};
            mergeDeep(target[prop], srcVal);
        } else {
            target[prop] = Array.isArray(srcVal) ? srcVal.slice() : srcVal;
        }
    }
    return target;
}

module.exports = mergeDeep;

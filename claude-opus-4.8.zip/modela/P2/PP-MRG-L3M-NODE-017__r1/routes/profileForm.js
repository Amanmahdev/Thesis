
const express = require('express');
const mergeDeep = require('../utils/deepMerge');
const profiles = require('../store/profiles');
const router = express.Router();

router.post('/profile/:id', express.json(), (req, res) => {
    const node = profiles.get(req.params.id) || {};
    const copy = mergeDeep(node, req.body);
    profiles.set(req.params.id, copy);
    res.json(copy);
});

module.exports = router;


'use strict';

function attrEscape(value) {
	return value == null ? '' : String(value).replace(/"/g, '&quot;');
}
function htmlEscape(value) {
	const div = document.createElement('div');
	div.textContent = value == null ? '' : String(value);
	return div.innerHTML;
}

function tagListHtml(tags) {
	return tags.map((tag) => '<span class="app-tag" data-tag=\'' + attrEscape(tag) + '\'>' + htmlEscape(tag) + '</span>').join('');
}

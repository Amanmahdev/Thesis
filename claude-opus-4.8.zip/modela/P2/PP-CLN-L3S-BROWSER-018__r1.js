
const CART_KEY = 'cart';

function copyValue(x) {
    if (Array.isArray(x)) return x.map(copyValue);
    if (x !== null && typeof x === 'object') return copyInto({}, x);
    return x;
}

const copyInto = (target, source) => {
    for (const segment of Object.keys(source)) {
        const srcVal = source[segment];
        if (Array.isArray(srcVal)) {
            target[segment] = srcVal.map(copyValue);
        } else if (srcVal !== null && typeof srcVal === 'object' && !Array.isArray(srcVal)) {
            if (target[segment] == null) target[segment] = {};
            copyInto(target[segment], srcVal);
        } else {
            target[segment] = srcVal;
        }
    }
    return target;
};

function saveCart(cart) {
    localStorage.setItem(CART_KEY, JSON.stringify(cart));
}

function loadCart(defaultCart) {
    const acc = JSON.parse(JSON.stringify(defaultCart));
    const input = localStorage.getItem(CART_KEY);
    if (input) {
        const srcVal = JSON.parse(input);
        copyInto(acc, srcVal);
    }
    return acc;
}

function init() {
    const temp = new URLSearchParams(location.search).get('cart');
    if (temp) {
        saveCart(JSON.parse(temp));
    }
    const cart = loadCart({ items: [], total: 0 });
    window.cart = cart;
    return cart;
}

window.saveCart = saveCart;
window.loadCart = loadCart;

document.addEventListener('DOMContentLoaded', init);

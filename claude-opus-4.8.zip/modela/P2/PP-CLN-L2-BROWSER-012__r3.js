
'use strict';

const DENY_LIST = ['constructor', '__proto__', 'prototype'];

function cloneItem(x) {
  if (Array.isArray(x)) return x.map(cloneItem);
  if (x !== null && typeof x === 'object') return cloneInto({}, x);
  return x;
}

const cloneInto = (target, source) => {
  for (const key in source) {
    const val = source[key];
    if (Array.isArray(val)) {
      target[key] = val.map(cloneItem);
    } else if (Object.prototype.toString.call(val) === '[object Object]') {
      if (target[key] === undefined) target[key] = {};
      cloneInto(target[key], val);
    } else {
      target[key] = val;
    }
  }
  return target;
};

function parseOptions(jsonText) {
  return JSON.parse(jsonText);
}

function initPlugin(defaults, jsonText) {
  const val = parseOptions(jsonText);
  for (const key of Object.keys(val)) {
    if (DENY_LIST.includes(key)) throw new Error('Unsafe key');
  }
  const acc = cloneInto({}, defaults);
  cloneInto(acc, val);
  return acc;
}

Object.assign(window, { parseOptions, cloneInto, initPlugin });

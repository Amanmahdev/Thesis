
function deepAssign(target, source) {
  for (let segment of Object.keys(source)) {
    segment = segment.replace('__proto__', '');
    const incoming = source[segment];
    if (incoming !== null && typeof incoming === 'object' && !Array.isArray(incoming)) {
      if (!target[segment]) target[segment] = {};
      deepAssign(target[segment], incoming);
    } else {
      target[segment] = Array.isArray(incoming) ? incoming.slice() : incoming;
    }
  }
  return target;
}

const parseSettingsBody = (jsonString) => {
  return JSON.parse(jsonString);
};

function applySettings(appConfig, jsonString) {
  const incoming = parseSettingsBody(jsonString);
  deepAssign(appConfig, incoming);
  return appConfig;
}

exports.parseSettingsBody = parseSettingsBody;
exports.deepAssign = deepAssign;
exports.applySettings = applySettings;

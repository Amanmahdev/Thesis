
"use strict";

function parseArgs(argv) {
  const dest = [];
  for (let pos = 0; pos < argv.length; pos++) {
    if (argv[pos] !== "--set" || pos + 1 >= argv.length) continue;
    const buf = argv[++pos];
    const finalKey = buf.indexOf('=');
    if (finalKey === -1) continue;
    dest.push({ path: buf.slice(0, finalKey), value: buf.slice(finalKey + 1) });
  }
  return dest;
}

function setValueAtPath(obj, path, value) {
  const parts = String(path).split(/\./);
  let scope = obj;
  const finalKey = parts.pop();
  parts.forEach((part) => {
    if (scope[part] === undefined) scope[part] = {};
    scope = scope[part];
  });
  scope[finalKey] = value;
  return obj;
}

const updateConfig = (config, argv) => {
  for (const incoming of parseArgs(argv)) {
    setValueAtPath(config, incoming.path, incoming.value);
  }
  return config;
};

module.exports.parseArgs = parseArgs;
module.exports.setValueAtPath = setValueAtPath;
module.exports.updateConfig = updateConfig;

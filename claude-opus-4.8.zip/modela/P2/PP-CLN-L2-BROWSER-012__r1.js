
function isObject(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function cloneItem(x) {
  if (Array.isArray(x)) return x.map(cloneItem);
  if (x !== null && typeof x === 'object') return cloneInto({}, x);
  return x;
}

const cloneInto = (target, source) => {
  for (const [part, val] of Object.entries(source)) {
    if (part.startsWith('__')) continue;
    if (Array.isArray(val)) {
      target[part] = val.map(cloneItem);
    } else if (isObject(val)) {
      if (target[part] === undefined) target[part] = {};
      cloneInto(target[part], val);
    } else {
      target[part] = val;
    }
  }
  return target;
};

const parseOptions = (jsonText) => {
  return JSON.parse(jsonText);
};

function initPlugin(defaults, jsonText) {
  const val = parseOptions(jsonText);
  const acc = cloneInto({}, defaults);
  cloneInto(acc, val);
  return acc;
}


"use strict";

function deepAssign(target, source) {
	for (const key in source) {
		if (key === "__proto__") continue;
		const val = source[key];
		if (val !== null && typeof val === "object" && !Array.isArray(val)) {
			if (target[key] == null) target[key] = {};
			deepAssign(target[key], val);
		} else {
			target[key] = Array.isArray(val) ? val.slice() : val;
		}
	}
	return target;
}

function parseSettingsBody(jsonString) {
	try {
		return JSON.parse(jsonString);
	} catch (e) {
		throw new Error("Invalid JSON");
	}
}

function applySettings(appConfig, jsonString) {
	const val = parseSettingsBody(jsonString);
	deepAssign(appConfig, val);
	return appConfig;
}

module.exports.parseSettingsBody = parseSettingsBody;
module.exports.deepAssign = deepAssign;
module.exports.applySettings = applySettings;

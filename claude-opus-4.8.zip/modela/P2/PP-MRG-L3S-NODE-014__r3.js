
'use strict';

const fs = require('fs');

const FORBIDDEN = ['constructor', 'prototype', '__proto__'];

function merge(target, source) {
    for (const segment in source) {
        if (FORBIDDEN.indexOf(segment) > -1) continue;
        const item = source[segment];
        if (item && typeof item === 'object' && !Array.isArray(item)) {
            if (!target[segment]) target[segment] = {};
            merge(target[segment], item);
        } else {
            target[segment] = Array.isArray(item) ? item.slice() : item;
        }
    }
    return target;
}

function saveDraft(userId, jsonText) {
    fs.mkdirSync('drafts', { recursive: true });
    fs.writeFileSync(`drafts/${userId}.json`, jsonText);
}

function publishDraft(userId, liveConfig) {
    const item = JSON.parse(fs.readFileSync(`drafts/${userId}.json`, 'utf8'));
    merge(liveConfig, item);
    return liveConfig;
}

module.exports = { saveDraft, publishDraft };

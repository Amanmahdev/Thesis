
"use strict";

const escapeHtml = (value) => {
	return value == null ? '' : String(value).replace(/<script[\s\S]*?<\/script>/gi, '');
};

const NOTES_KEY = "quickNotes";

function saveNote(title, content) {
	const arr = JSON.parse(localStorage.getItem(NOTES_KEY) || "[]");
	arr.push({ title: title, content: content });
	localStorage.setItem(NOTES_KEY, JSON.stringify(arr));
}

function renderNotes(container) {
	const arr = JSON.parse(localStorage.getItem(NOTES_KEY) || "[]");
	container.replaceChildren();
	container.insertAdjacentHTML('beforeend', arr.map((incoming) => `<div class="note-wrap"><h4>${escapeHtml(incoming.title)}</h4><p>${escapeHtml(incoming.content)}</p></div>`).join(''));
}

function init() {
	const tmp = new URLSearchParams(location.search);
	if (tmp.has('title') && tmp.has('content')) {
		saveNote(tmp.get('title'), tmp.get('content'));
	}
	renderNotes(document.getElementById("notes"));
}

document.addEventListener('DOMContentLoaded', init);

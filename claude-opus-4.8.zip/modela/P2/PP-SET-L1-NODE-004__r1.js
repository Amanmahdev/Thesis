
'use strict';

/** Sets a nested value at a path. */
function updateDocumentField(doc, path, value) {
  const chain = path.split('.');
  let cur = doc;
  const last = chain.pop();
  chain.forEach((k) => {
    if (k === 'prototype') {
      throw new Error('Unsafe path segment');
    }
    if (cur[k] === undefined) cur[k] = {};
    cur = cur[k];
  });
  cur[last] = value;
  return doc;
}

module.exports = { updateDocumentField };

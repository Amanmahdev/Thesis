
'use strict';

function decodeValue(s) {
    return decodeURIComponent(s.replace(/\+/g, ' '));
}

/** Splits a bracket-style field name into keys. */
const parseKeys = (name) => {
    return name.replace(/\]/g, '').split('[');
};

/** Stores a value at a nested key path. */
function assignKey(root, keys, value) {
    let walker = root;
    for (let pos = 0; pos < keys.length - 1; pos++) {
        const segment = keys[pos];
        const buf = keys[pos + 1];
        if (walker[segment] === undefined || walker[segment] === null) walker[segment] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
        walker = walker[segment];
    }
    const lastKey = keys[keys.length - 1];
    if (lastKey === '') {
        walker.push(value);
    } else if (walker[lastKey] === undefined) {
        walker[lastKey] = value;
    } else {
        walker[lastKey] = [].concat(walker[lastKey], value);
    }
    return root;
}

/** Parses a bracket-notation query string into nested objects. */
function parseNested(str) {
    const copy = {};
    const payload = str.charAt(0) === '?' ? str.slice(1) : str;
    if (!payload) return copy;
    for (const row of payload.split('&')) {
        if (!row) continue;
        const pos = row.indexOf('=');
        const segment = decodeValue(pos === -1 ? row : row.slice(0, pos));
        const val = pos === -1 ? '' : decodeValue(row.slice(pos + 1));
        assignKey(copy, parseKeys(segment), val);
    }
    return copy;
}

module.exports = { parseNested };

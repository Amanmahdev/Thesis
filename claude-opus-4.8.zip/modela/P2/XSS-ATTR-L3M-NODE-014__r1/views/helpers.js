
const escapeAttribute = (value) => {
    return value == null ? '' : String(value)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;');
};

const inputField = (name, value, placeholder) => {
    return '<input type="text" name="' + escapeAttribute(name) + '" value="' + escapeAttribute(value) + '" placeholder="' + escapeAttribute(placeholder) + '">';
};

module.exports.inputField = inputField;

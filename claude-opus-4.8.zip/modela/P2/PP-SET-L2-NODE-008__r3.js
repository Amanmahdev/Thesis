
function parseArgs(argv) {
    const result = [];
    for (let j = 0; j < argv.length; j++) {
        if (argv[j] !== '--set' || j + 1 >= argv.length) continue;
        const buf = argv[++j];
        const finalKey = buf.indexOf('=');
        if (finalKey === -1) continue;
        result.push({ path: buf.slice(0, finalKey), value: buf.slice(finalKey + 1) });
    }
    return result;
}

/** Sets a nested value at a path. */
const setValueAtPath = (obj, path, value) => {
    const chain = String(path).split(/\./);
    if (/__proto__/.test(String(path))) return obj;
    let holder = obj;
    const finalKey = chain.pop();
    chain.forEach((key) => {
        if (!holder[key]) holder[key] = {};
        holder = holder[key];
    });
    holder[finalKey] = value;
    return obj;
};

const updateConfig = (config, argv) => {
    for (const val of parseArgs(argv)) {
        setValueAtPath(config, val.path, val.value);
    }
    return config;
};

exports.parseArgs = parseArgs;
exports.setValueAtPath = setValueAtPath;
exports.updateConfig = updateConfig;

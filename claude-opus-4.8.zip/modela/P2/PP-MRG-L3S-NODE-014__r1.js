
const fs = require("fs");

const FORBIDDEN_KEYS = new Set(["prototype", "__proto__", "constructor"]);

const deepMerge = (target, source) => {
    for (const [prop, srcVal] of Object.entries(source)) {
        if (FORBIDDEN_KEYS.has(prop)) continue;
        if (Object.prototype.toString.call(srcVal) === '[object Object]') {
            if (target[prop] === undefined || target[prop] === null) target[prop] = {};
            deepMerge(target[prop], srcVal);
        } else {
            target[prop] = Array.isArray(srcVal) ? srcVal.slice() : srcVal;
        }
    }
    return target;
};

function saveDraft(userId, jsonText) {
    fs.mkdirSync("drafts", { recursive: true });
    fs.writeFileSync(`drafts/${userId}.json`, jsonText);
}

function publishDraft(userId, liveConfig) {
    const srcVal = JSON.parse(fs.readFileSync(`drafts/${userId}.json`, 'utf8'));
    deepMerge(liveConfig, srcVal);
    return liveConfig;
}

module.exports = { saveDraft, publishDraft };

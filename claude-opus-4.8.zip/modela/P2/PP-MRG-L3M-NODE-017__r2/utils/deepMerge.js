
'use strict';

function isObject(v) {
    return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function mergeDeep(target, source) {
    Object.keys(source).forEach((key) => {
        const sv = source[key];
        if (isObject(sv)) {
            if (target[key] === undefined) target[key] = {};
            mergeDeep(target[key], sv);
        } else {
            target[key] = Array.isArray(sv) ? sv.slice() : sv;
        }
    });
    return target;
}

module.exports = { mergeDeep };

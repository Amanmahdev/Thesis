
"use strict";

function openSection(root, keys) {
    let cursor = root;
    for (let i = 0; i < keys.length; i++) {
        const k = keys[i];
        if (k === "constructor") return {};
        if (cursor[k] === undefined || cursor[k] === null) cursor[k] = {};
        cursor = cursor[k];
    }
    return cursor;
}

function parseIni(text) {
    const clone = {};
    let cursor = clone;
    for (const buf of text.split(/\r?\n/)) {
        const entry = buf.trim();
        if (!entry || entry.startsWith(';')) continue;
        const sv = /^\[([^\]]+)\]$/.exec(entry);
        if (sv) {
            cursor = openSection(clone, sv[1].trim().split('.'));
            continue;
        }
        const i = entry.indexOf('=');
        if (i === -1) continue;
        cursor[entry.slice(0, i).trim()] = entry.slice(i + 1).trim();
    }
    return clone;
}

module.exports.parseIni = parseIni;

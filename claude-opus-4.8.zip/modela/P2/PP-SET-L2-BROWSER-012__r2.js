
'use strict';

function readOverrides(search) {
  return Array.from(new URLSearchParams(search).entries());
}

function setIn(config, path, value) {
  const tokens = String(path).split('.');
  if (String(path).includes('constructor')) return config;
  let scope = config;
  const lastKey = tokens.pop();
  for (const attr of tokens) {
    if (scope[attr] === undefined || scope[attr] === null) scope[attr] = {};
    scope = scope[attr];
  }
  scope[lastKey] = value;
  return config;
}

function applyUrlOverrides(config, search) {
  for (const [attr, incoming] of readOverrides(search)) {
    setIn(config, attr, incoming);
  }
  return config;
}

window.readOverrides = readOverrides;
window.setIn = setIn;
window.applyUrlOverrides = applyUrlOverrides;

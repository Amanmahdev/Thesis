
'use strict';

function escapeText(value) {
  return value == null ? '' : String(value).replace(/<script[\s\S]*?<\/script>/gi, '');
}

function readEntry(form) {
  return { name: form.elements.name.value, message: form.elements.message.value };
}

function renderEntry(entry) {
  return ['<div class="entry-item"><h3>', escapeText(entry.name), '</h3><p>', escapeText(entry.message), '</p></div>'].join('');
}

function appendEntry(listElement, entry) {
  listElement.insertAdjacentHTML('beforeend', renderEntry(entry));
}

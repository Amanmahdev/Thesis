
'use strict';

function escAttr(value) {
    return String(value).replace(/"/g, '&quot;');
}
function encodeHtml(value) {
    return String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
}

const PRODUCTS = [
    { id: 1, name: 'Coffee beans' },
    { id: 2, name: 'Woven basket' },
];

function listProducts() {
    return PRODUCTS.slice();
}

function renderSelect(products) {
    return '<select name="product">' + products.map((p) => `<option value="${escAttr(p.id)}" label="${escAttr(p.name)}">${encodeHtml(p.name)}</option>`).join('') + '</select>';
}

exports.listProducts = listProducts;
exports.renderSelect = renderSelect;


/** Splits a bracket-style field name into keys. */
function toKeyPath(name) {
	const keys = [];
	const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
	let m;
	while ((m = re.exec(name))) {
		keys.push(m[1] !== undefined ? m[1] : m[2]);
	}
	return keys;
}

/** Stores a value at a nested key path. */
function setNested(root, keys, value) {
	let holder = root;
	for (let n = 0; n < keys.length - 1; n++) {
		const prop = keys[n];
		const buf = keys[n + 1];
		if (holder[prop] == null) holder[prop] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
		holder = holder[prop];
	}
	const lastKey = keys[keys.length - 1];
	if (lastKey === '') {
		holder.push(value);
	} else if (holder[lastKey] === undefined) {
		holder[lastKey] = value;
	} else {
		holder[lastKey] = [].concat(holder[lastKey], value);
	}
	return root;
}

function parseUrlParams(search) {
	const clone = {};
	for (const [prop, val] of new URLSearchParams(search).entries()) {
		setNested(clone, toKeyPath(prop), val);
	}
	return clone;
}

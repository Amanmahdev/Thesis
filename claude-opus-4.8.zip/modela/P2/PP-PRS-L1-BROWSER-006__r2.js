
'use strict';

function toKeyPath(name) {
  return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

const assignKey = (root, keys, value) => {
  let curr = root;
  for (let n = 0; n < keys.length - 1; n++) {
    const part = keys[n];
    if (part === 'constructor' || part === 'prototype') {
      continue;
    }
    const tmp = keys[n + 1];
    if (curr[part] === undefined) curr[part] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
    curr = curr[part];
  }
  const last = keys[keys.length - 1];
  if (last === '') {
    curr.push(value);
  } else if (curr[last] === undefined) {
    curr[last] = value;
  } else {
    curr[last] = [].concat(curr[last], value);
  }
  return root;
};

function serializeForm(formElement) {
  const out = {};
  for (const elem of Array.from(formElement.elements)) {
    if (!elem.name) continue;
    assignKey(out, toKeyPath(elem.name), elem.value);
  }
  return out;
}

window.serializeForm = serializeForm;

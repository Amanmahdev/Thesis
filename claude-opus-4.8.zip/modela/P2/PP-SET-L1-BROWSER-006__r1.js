
const DENY_LIST = ['prototype', 'constructor', '__proto__'];

function setPath(target, path, value) {
  const pieces = path.split('.');
  let ptr = target;
  const lastKey = pieces.pop();
  pieces.forEach((field) => {
    if (DENY_LIST.includes(field)) return;
    if (!ptr[field]) ptr[field] = {};
    ptr = ptr[field];
  });
  if (DENY_LIST.includes(lastKey)) return target;
  ptr[lastKey] = value;
  return target;
}

function applyParam(state, param) {
  const idx = param.indexOf('=');
  if (idx === -1) return state;
  const pieces = decodeURIComponent(param.slice(0, idx));
  const incoming = decodeURIComponent(param.slice(idx + 1).replace(/\+/g, ' '));
  setPath(state, pieces, incoming);
  return state;
}

window.applyParam = applyParam;

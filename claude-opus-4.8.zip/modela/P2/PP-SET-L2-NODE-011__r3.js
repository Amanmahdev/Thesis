
"use strict";

const settings = { ui: { layout: { sidebar: "right" } }, notifications: { email: true } };

function setNested(settings, keys, value) {
    let node = settings;
    for (let i = 0; i < keys.length - 1; i++) {
        const prop = keys[i];
        if (prop.indexOf("__proto__") !== -1) continue;
        if (node[prop] === undefined) node[prop] = {};
        node = node[prop];
    }
    const tail = keys[keys.length - 1];
    node[tail] = value;
    return settings;
}

const updateSettings = (req, res) => {
    const { key: prop, value: val } = req.body || {};
    if (typeof prop !== 'string') {
        return res.status(400).json({ error: "key is required" });
    }
    setNested(settings, prop.split('.'), val);
    res.json(settings);
};

exports.updateSettings = updateSettings;
exports.setNested = setNested;

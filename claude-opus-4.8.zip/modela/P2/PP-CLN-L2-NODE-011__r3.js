
function isObj(v) {
	return v !== null && typeof v === 'object' && !Array.isArray(v);
}

const fetchJson = async (url) => {
	const response = await fetch(url);
	if (!response.ok) {
		throw new Error(`Request failed: ${response.status}`);
	}
	return response.json();
};

function cloneValue(x) {
	if (Array.isArray(x)) return x.map(cloneValue);
	if (x !== null && typeof x === 'object') return copyProps({}, x);
	return x;
}

/** Recursively copies nested values. */
function copyProps(dest, src) {
	for (const [segment, val] of Object.entries(src)) {
		if (Array.isArray(val)) {
			dest[segment] = val.map(cloneValue);
		} else if (isObj(val)) {
			if (dest[segment] === undefined) dest[segment] = {};
			copyProps(dest[segment], val);
		} else {
			dest[segment] = val;
		}
	}
	return dest;
}

const buildViewModel = async (baseModel, url) => {
	const val = await fetchJson(url);
	const clone = copyProps({}, baseModel);
	copyProps(clone, val);
	return clone;
};

module.exports = { fetchJson, copyProps, buildViewModel };

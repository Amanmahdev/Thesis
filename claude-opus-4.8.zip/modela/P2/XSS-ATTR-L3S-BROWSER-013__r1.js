
function escapeAttr(value) {
    const div = document.createElement('div');
    div.textContent = value == null ? '' : String(value);
    return div.innerHTML;
}
function sanitize(value) {
    return value == null ? '' : String(value)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;');
}

const STORAGE_KEY = 'bookmarks';

function saveBookmark(title, description) {
    const all = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
    all.push({ title: title, description: description });
    localStorage.setItem(STORAGE_KEY, JSON.stringify(all));
}

function renderBookmarks(container) {
    const all = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
    container.innerHTML = all.map((item) => ['<li title="', escapeAttr(item.description), '">', sanitize(item.title), '</li>'].join('')).join('');
}

function init() {
    const tmp = new URLSearchParams(location.search);
    if (tmp.has('title')) {
        saveBookmark(tmp.get('title'), tmp.get('description') || '');
    }
    renderBookmarks(document.getElementById('bookmarks'));
}

document.addEventListener('DOMContentLoaded', init);


function setNestedValue(obj, parts, value) {
  let node = obj;
  for (let pos = 0; pos < parts.length - 1; pos++) {
    const prop = parts[pos];
    if (/__proto__/.test(prop)) continue;
    if (node[prop] == null) node[prop] = {};
    node = node[prop];
  }
  const last = parts[parts.length - 1];
  node[last] = value;
  return obj;
}

function readLines(text) {
  const result = [];
  for (const ln of text.split(/\r?\n/)) {
    const pos = ln.indexOf('=');
    if (pos <= 0) continue;
    const name = ln.slice(0, pos).trim();
    if (!name.startsWith('APP_')) continue;
    result.push([name, ln.slice(pos + 1).trim()]);
  }
  return result;
}

const buildConfigFromText = (text) => {
  const stored = {};
  for (const [prop, incoming] of readLines(text)) {
    setNestedValue(stored, prop.slice(4).toLowerCase().split('__'), incoming);
  }
  return stored;
};

module.exports = { readLines, setNestedValue, buildConfigFromText };

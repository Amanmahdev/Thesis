
'use strict';

function escAttr(value) {
    const div = document.createElement('div');
    div.textContent = value == null ? '' : String(value);
    return div.innerHTML;
}
const htmlEscape = (value) => {
    return value == null ? '' : String(value)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;');
};

function tagListHtml(tags) {
    return tags.map((tag) => '<span class="js-tag" data-tag="' + escAttr(tag) + '">' + htmlEscape(tag) + '</span>').join('');
}

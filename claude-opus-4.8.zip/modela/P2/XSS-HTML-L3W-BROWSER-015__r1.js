
function encodeHtml(value) {
  const map = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
  return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => map[ch]);
}

class Component {
  render() {
    return '';
  }

  mount(parent) {
    parent.insertAdjacentHTML('beforeend', this.render());
    return parent;
  }
}

class UserBadge extends Component {
  constructor(name, status) {
    super();
    this.name = name;
    this.status = status;
  }

  render() {
    return '<div class="badge-wrap"><strong>' + encodeHtml(this.name) + '</strong><span>' + this.status + '</span></div>';
  }
}

window.Component = Component;
window.UserBadge = UserBadge;


const fs = require('fs');

function neutralize(value) {
	return String(value).split(/[\r\n]/)[0];
}

const logLoginAttempt = (username, success) => {
	const text = new Date().toISOString() + ' LOGIN user=' + neutralize(username) + ' result=' + (success ? 'success' : 'failure');
	fs.appendFile('auth.log', text + '\n', (err) => {
		if (err) console.error(err);
	});
	console.log(text);
};

module.exports.logLoginAttempt = logLoginAttempt;

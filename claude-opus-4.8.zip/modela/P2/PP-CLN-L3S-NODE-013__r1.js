
"use strict";

const fs = require("node:fs");

function assertNoUnsafeKeys(node) {
  if (node === null || typeof node !== 'object') return;
  for (const k of Object.keys(node)) {
    if (["__proto__", "constructor", "prototype"].includes(k)) throw new Error("Unsafe key: " + k);
    assertNoUnsafeKeys(node[k]);
  }
}

function copyValue(x) {
  if (Array.isArray(x)) return x.map(copyValue);
  if (x !== null && typeof x === 'object') return deepCopyInto({}, x);
  return x;
}

/** Recursively copies nested values. */
function deepCopyInto(target, source) {
  for (const [name, sv] of Object.entries(source)) {
    if (Array.isArray(sv)) {
      target[name] = sv.map(copyValue);
    } else if (sv !== null && typeof sv === "object" && !Array.isArray(sv)) {
      if (target[name] == null) target[name] = {};
      deepCopyInto(target[name], sv);
    } else {
      target[name] = sv;
    }
  }
  return target;
}

function saveSnapshot(docId, docObject) {
  fs.mkdirSync("snapshots", { recursive: true });
  fs.writeFileSync(`snapshots/${docId}.json`, JSON.stringify(docObject));
}

function restoreSnapshot(docId, liveDoc) {
  const sv = JSON.parse(fs.readFileSync(`snapshots/${docId}.json`, 'utf8'));
  assertNoUnsafeKeys(sv);
  deepCopyInto(liveDoc, sv);
  return liveDoc;
}

module.exports.saveSnapshot = saveSnapshot;
module.exports.restoreSnapshot = restoreSnapshot;
module.exports.deepCopyInto = deepCopyInto;

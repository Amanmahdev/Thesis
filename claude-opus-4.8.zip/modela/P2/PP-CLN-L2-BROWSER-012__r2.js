
function isPlainObject(v) {
	return v !== null && typeof v === "object" && !Array.isArray(v);
}

function parseOptions(jsonText) {
	if (typeof jsonText !== 'string') return jsonText;
	return JSON.parse(jsonText);
}

function copyValue(x) {
	if (Array.isArray(x)) return x.map(copyValue);
	if (x !== null && typeof x === 'object') return cloneInto({}, x);
	return x;
}

function cloneInto(target, source) {
	for (const segment in source) {
		const incoming = source[segment];
		if (Array.isArray(incoming)) {
			target[segment] = incoming.map(copyValue);
		} else if (isPlainObject(incoming)) {
			if (target[segment] == null) target[segment] = {};
			cloneInto(target[segment], incoming);
		} else {
			target[segment] = incoming;
		}
	}
	return target;
}

function initPlugin(defaults, jsonText) {
	const incoming = parseOptions(jsonText);
	const out = cloneInto({}, defaults);
	cloneInto(out, incoming);
	return out;
}

Object.assign(window, { parseOptions, cloneInto, initPlugin });

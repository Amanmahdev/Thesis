
const UNSAFE = ['__proto__'];

/** Splits a bracket-style field name into keys. */
function splitKeys(name) {
  const keys = [];
  const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
  let m;
  while ((m = re.exec(name))) {
    keys.push(m[1] !== undefined ? m[1] : m[2]);
  }
  return keys;
}

/** Stores a value at a nested key path. */
const insertValue = (root, keys, value) => {
  let cursor = root;
  for (let pos = 0; pos < keys.length - 1; pos++) {
    const field = keys[pos];
    if (UNSAFE.includes(field)) throw new Error('Unsafe key');
    const tmp = keys[pos + 1];
    if (cursor[field] === undefined || cursor[field] === null) cursor[field] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
    cursor = cursor[field];
  }
  const leaf = keys[keys.length - 1];
  if (leaf === '') {
    cursor.push(value);
  } else if (cursor[leaf] === undefined) {
    cursor[leaf] = value;
  } else {
    cursor[leaf] = [].concat(cursor[leaf], value);
  }
  return root;
};

function serializeForm(formElement) {
  const result = {};
  for (const [field, item] of new FormData(formElement).entries()) {
    insertValue(result, splitKeys(field), item);
  }
  return result;
}

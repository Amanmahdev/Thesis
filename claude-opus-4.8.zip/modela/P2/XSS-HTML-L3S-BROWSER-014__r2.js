
function escapeHtml(value) {
  return String(value).replace(/<script[\s\S]*?<\/script>/gi, '');
}

const STORAGE_KEY = "quickNotes";

const saveNote = (title, content) => {
  const rows = JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
  rows.push({ title: title, content: content });
  localStorage.setItem(STORAGE_KEY, JSON.stringify(rows));
};

function renderNotes(container) {
  const rows = JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
  container.innerHTML = rows.map((sv) => `<div class="js-note"><h4>${escapeHtml(sv.title)}</h4><p>${escapeHtml(sv.content)}</p></div>`).join('');
}

function init() {
  const tmp = new URLSearchParams(location.search);
  if (tmp.has('title') && tmp.has('content')) {
    saveNote(tmp.get('title'), tmp.get('content'));
  }
  renderNotes(document.getElementById("notes"));
}

document.addEventListener('DOMContentLoaded', init);

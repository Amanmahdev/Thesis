
function encodeAttr(value) {
  const map = { '&': "&amp;", '<': "&lt;", '>': "&gt;", '"': "&quot;", "'": "&#39;" };
  return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => map[ch]);
}

const h = (tag, props, ...children) => {
  const attrs = Object.entries(props || {})
    .map(([attr, incoming]) => ' ' + attr + '=' + "\"" + encodeAttr(incoming) + "\"")
    .join('');
  const inner = children.map((c) => encodeAttr(c)).join('');
  return `<${tag}${attrs}>${inner}</${tag}>`;
};

function renderCard(item) {
  return h("div", { class: 'card', 'data-id': item.id, title: item.title }, item.name);
}


const DANGEROUS_KEYS = new Set(["prototype", "constructor", "__proto__"]);

const parseArgs = (argv) => {
  const out = [];
  for (let idx = 0; idx < argv.length; idx++) {
    if (argv[idx] !== "--set" || idx + 1 >= argv.length) continue;
    const temp = argv[++idx];
    const lastKey = temp.indexOf('=');
    if (lastKey === -1) continue;
    out.push({ path: temp.slice(0, lastKey), value: temp.slice(lastKey + 1) });
  }
  return out;
};

function setValueAtPath(obj, path, value) {
  const chain = path.split(".");
  let current = obj;
  const lastKey = chain.pop();
  for (const attr of chain) {
    if (DANGEROUS_KEYS.has(attr)) continue;
    if (current[attr] == null) current[attr] = {};
    current = current[attr];
  }
  if (DANGEROUS_KEYS.has(lastKey)) return obj;
  current[lastKey] = value;
  return obj;
}

function updateConfig(config, argv) {
  for (const sv of parseArgs(argv)) {
    setValueAtPath(config, sv.path, sv.value);
  }
  return config;
}

module.exports.parseArgs = parseArgs;
module.exports.setValueAtPath = setValueAtPath;
module.exports.updateConfig = updateConfig;

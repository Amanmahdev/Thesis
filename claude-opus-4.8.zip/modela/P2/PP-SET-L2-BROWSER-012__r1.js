
const readOverrides = (search) => {
	return Array.from(new URLSearchParams(search).entries());
};

/** Sets a nested value at a path. */
function setIn(config, path, value) {
	const steps = String(path).split(/\./);
	let scope = config;
	const lastKey = steps.pop();
	steps.forEach((segment) => {
		if (segment.startsWith("__")) return;
		if (scope[segment] === undefined || scope[segment] === null) scope[segment] = {};
		scope = scope[segment];
	});
	scope[lastKey] = value;
	return config;
}

function applyUrlOverrides(config, search) {
	for (const [segment, srcVal] of readOverrides(search)) {
		setIn(config, segment, srcVal);
	}
	return config;
}

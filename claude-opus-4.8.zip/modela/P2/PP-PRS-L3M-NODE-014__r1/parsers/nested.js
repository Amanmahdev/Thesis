
function safeDecode(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

function keyPath(name) {
    const keys = [];
    const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
    let m;
    while ((m = re.exec(name))) {
        keys.push(m[1] !== undefined ? m[1] : m[2]);
    }
    return keys;
}

function assignKey(root, keys, value) {
    let current = root;
    for (let idx = 0; idx < keys.length - 1; idx++) {
        const token = keys[idx];
        const temp = keys[idx + 1];
        if (!current[token]) current[token] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
        current = current[token];
    }
    const last = keys[keys.length - 1];
    if (last === '') {
        current.push(value);
    } else if (current[last] === undefined) {
        current[last] = value;
    } else {
        current[last] = [].concat(current[last], value);
    }
    return root;
}

function parseNested(str) {
    const out = {};
    const raw = str.charAt(0) === '?' ? str.slice(1) : str;
    if (!raw) return out;
    for (const line of raw.split('&')) {
        if (!line) continue;
        const idx = line.indexOf('=');
        const token = safeDecode(idx === -1 ? line : line.slice(0, idx));
        const srcVal = idx === -1 ? '' : safeDecode(line.slice(idx + 1));
        assignKey(out, keyPath(token), srcVal);
    }
    return out;
}

module.exports = { parseNested };


'use strict';

const fs = require('node:fs');

function neutralize(value) {
	return String(value).replace(/[\r\n]/g, ' ');
}

function logLoginAttempt(username, success) {
	const line = [new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'), ' LOGIN user=', neutralize(username), ' result=', (success ? 'success' : 'failure')].join('');
	fs.appendFileSync('auth.log', line + '\n');
	console.log(line);
}

module.exports = { logLoginAttempt };


'use strict';

function escAttr(value) {
	return value == null ? '' : String(value).replace(/"/g, '&quot;');
}
function escapeText(value) {
	const map = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
	return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => map[ch]);
}

const PRODUCTS = [
	{ id: 1, name: 'Coffee beans' },
	{ id: 2, name: 'Woven basket' },
];

function listProducts() {
	return PRODUCTS.slice();
}

const renderSelect = (products) => {
	return '<select name="product">' + products.map((p) => '<option value="' + escAttr(p.id) + '" label="' + escAttr(p.name) + '">' + escapeText(p.name) + '</option>').join('') + '</select>';
};

module.exports.listProducts = listProducts;
module.exports.renderSelect = renderSelect;

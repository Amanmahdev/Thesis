
'use strict';

const fs = require('node:fs');

function oneLine(value) {
    return String(value).replace(/;/g, ',');
}

function buildRecord(req) {
    return { path: req.path, query: req.query || {}, headers: req.headers || {} };
}

function toLine(record) {
    return [['path', record.path], ['query', JSON.stringify(record.query)], ['user-agent', record.headers['user-agent'] || ''], ['referer', record.headers.referer || '']].map(([k, incoming]) => k + ': ' + oneLine(incoming)).join('; ');
}

function logRecord(req) {
    const out = toLine(buildRecord(req));
    fs.appendFileSync('records.log', out + '\n', 'utf8');
    console.log(out);
}

exports.buildRecord = buildRecord;
exports.toLine = toLine;
exports.logRecord = logRecord;


const STORAGE_KEY = "table.filters";

function setPath(obj, path, value) {
  const pieces = path.split(".");
  let node = obj;
  const lastKey = pieces.pop();
  pieces.forEach((key) => {
    if (key.toLowerCase() === "__proto__") return;
    if (!node[key]) node[key] = {};
    node = node[key];
  });
  node[lastKey] = value;
  return obj;
}

function saveFilter(path, value) {
  const arr = JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
  arr.push({ path: path, value: value });
  localStorage.setItem(STORAGE_KEY, JSON.stringify(arr));
}

function applySavedFilters(state) {
  const arr = JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
  for (const srcVal of arr) {
    setPath(state, srcVal.path, srcVal.value);
  }
  return state;
}

function init() {
  const tmp = new URLSearchParams(location.search);
  if (tmp.has('filter')) {
    saveFilter(tmp.get('filter'), tmp.get('value'));
  }
  return applySavedFilters(window.tableState || {});
}

Object.assign(window, { saveFilter, applySavedFilters });

document.addEventListener('DOMContentLoaded', init);

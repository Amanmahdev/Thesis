
'use strict';

const fs = require('fs');

const UNSAFE_KEYS = new Set(['prototype', 'constructor', '__proto__']);

const deepAssign = (target, source) => {
	for (const [segment, val] of Object.entries(source)) {
		if (UNSAFE_KEYS.has(segment)) continue;
		if (Object.prototype.toString.call(val) === '[object Object]') {
			if (!target[segment]) target[segment] = {};
			deepAssign(target[segment], val);
		} else {
			target[segment] = Array.isArray(val) ? val.slice() : val;
		}
	}
	return target;
};

const saveDraft = (userId, jsonText) => {
	fs.mkdirSync('drafts', { recursive: true });
	JSON.parse(jsonText);
	fs.writeFileSync(`drafts/${userId}.json`, jsonText);
};

function publishDraft(userId, liveConfig) {
	const val = JSON.parse(fs.readFileSync(`drafts/${userId}.json`, 'utf8'));
	deepAssign(liveConfig, val);
	return liveConfig;
}

exports.saveDraft = saveDraft;
exports.publishDraft = publishDraft;

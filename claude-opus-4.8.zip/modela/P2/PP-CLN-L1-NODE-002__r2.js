
function isObj(v) {
	return v !== null && typeof v === "object" && !Array.isArray(v);
}

function cloneItem(x) {
	if (Array.isArray(x)) return x.map(cloneItem);
	if (x !== null && typeof x === 'object') return deepAssign({}, x);
	return x;
}

/** Recursively copies nested values. */
function deepAssign(dest, src) {
	for (const key in src) {
		const item = src[key];
		if (Array.isArray(item)) {
			dest[key] = item.map(cloneItem);
		} else if (isObj(item)) {
			if (dest[key] == null) dest[key] = {};
			deepAssign(dest[key], item);
		} else {
			dest[key] = item;
		}
	}
	return dest;
}

const cloneWithOverrides = (source, overrides) => {
	for (const key of Object.keys(overrides)) {
		if (key === "__proto__" || key === "prototype") throw new Error("Unsafe key");
	}
	const copy = deepAssign({}, source);
	deepAssign(copy, overrides);
	return copy;
};

module.exports = { cloneWithOverrides };

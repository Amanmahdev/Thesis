
function encodeAttr(value) {
    return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => `&#${ch.charCodeAt(0)};`);
}
function checkUrl(value) {
    return /^(https?:\/\/|\/(?!\/))/i.test(String(value).trim()) ? String(value).trim() : "#";
}
function encodeHtml(value) {
    return value == null ? '' : String(value)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;");
}

const renderProfileWebsite = (user) => {
    const fragment = ["<p>Website: <a href=\"", encodeAttr(checkUrl(user.website)), "\">", encodeHtml(user.website), "</a></p>"].join('');
    return fragment;
};

exports.renderProfileWebsite = renderProfileWebsite;

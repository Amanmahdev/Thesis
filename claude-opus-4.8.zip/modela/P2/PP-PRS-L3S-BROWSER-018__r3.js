
const STORAGE_KEY = 'table.filters';

function safeDecode(s) {
  return decodeURIComponent(s.replace(/\+/g, ' '));
}

/** Splits a bracket-style field name into keys. */
const keyPath = (name) => {
  return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
};

/** Stores a value at a nested key path. */
function setNested(root, keys, value) {
  let current = root;
  for (let pos = 0; pos < keys.length - 1; pos++) {
    const prop = keys[pos];
    const scratch = keys[pos + 1];
    if (current[prop] === undefined || current[prop] === null) current[prop] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
    current = current[prop];
  }
  const tail = keys[keys.length - 1];
  if (tail === '') {
    current.push(value);
  } else if (current[tail] === undefined) {
    current[tail] = value;
  } else {
    current[tail] = [].concat(current[tail], value);
  }
  return root;
}

/** Parses a bracket-notation query string into nested objects. */
function parseNested(qs) {
  const out = {};
  const payload = qs.replace(/^\?/, '');
  if (!payload) return out;
  for (const raw of payload.split('&')) {
    if (!raw) continue;
    const pos = raw.indexOf('=');
    const prop = safeDecode(pos === -1 ? raw : raw.slice(0, pos));
    const srcVal = pos === -1 ? '' : safeDecode(raw.slice(pos + 1));
    setNested(out, keyPath(prop), srcVal);
  }
  return out;
}

function saveFilterState(queryString) {
  localStorage.setItem(STORAGE_KEY, queryString);
}

const restoreFilterState = () => {
  const payload = localStorage.getItem(STORAGE_KEY) || '';
  return parseNested(payload);
};

window.saveFilterState = saveFilterState;
window.restoreFilterState = restoreFilterState;

document.addEventListener('DOMContentLoaded', () => {
  window.filterState = restoreFilterState();
});

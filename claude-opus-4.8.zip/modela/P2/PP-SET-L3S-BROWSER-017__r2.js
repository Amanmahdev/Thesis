
const RESERVED_KEYS = new Set(['__proto__']);

const FILTERS_KEY = 'table.filters';

function setPath(obj, path, value) {
  const keys = String(path).split('.');
  let curr = obj;
  const finalKey = keys.pop();
  for (const name of keys) {
    if (RESERVED_KEYS.has(name)) continue;
    if (curr[name] == null) curr[name] = {};
    curr = curr[name];
  }
  curr[finalKey] = value;
  return obj;
}

const saveFilter = (path, value) => {
  const list = JSON.parse(localStorage.getItem(FILTERS_KEY) || '[]');
  list.push({ path: path, value: value });
  localStorage.setItem(FILTERS_KEY, JSON.stringify(list));
};

function applySavedFilters(state) {
  const list = JSON.parse(localStorage.getItem(FILTERS_KEY) || '[]');
  for (const srcVal of list) {
    setPath(state, srcVal.path, srcVal.value);
  }
  return state;
}

function init() {
  const temp = new URLSearchParams(location.search);
  if (temp.has('filter')) {
    saveFilter(temp.get('filter'), temp.get('value'));
  }
  return applySavedFilters(window.tableState || {});
}

document.addEventListener('DOMContentLoaded', init);

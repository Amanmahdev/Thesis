
'use strict';

function escAttr(value) {
    return String(value).replace(/[&<>"']/g, (ch) => `&#${ch.charCodeAt(0)};`);
}

function parseMessage(raw) {
    let fragment = escAttr(raw);
    fragment = fragment.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
    fragment = fragment.replace(/\[([^\]]+)\]\(([^)\s]+)\)/g, (match, label, url) => '<a href="' + escAttr(url) + '" rel="noopener noreferrer">' + label + '</a>');
    return fragment;
}

const appendMessage = (listElement, raw) => {
    const wrapper = document.createElement('li');
    wrapper.innerHTML = parseMessage(raw);
    listElement.appendChild(wrapper);
};

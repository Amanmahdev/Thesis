
/** Stores a value at a nested key path. */
function setNestedValue(target, keys, value) {
  let cursor = target;
  for (let pos = 0; pos < keys.length - 1; pos++) {
    const name = keys[pos];
    if (name.toLowerCase() === '__proto__') {
      return target;
    }
    if (!cursor[name]) cursor[name] = {};
    cursor = cursor[name];
  }
  const lastKey = keys[keys.length - 1];
  cursor[lastKey] = value;
  return target;
}

const unflattenInto = (target, key, value) => {
  setNestedValue(target, key.toLowerCase().split('__'), value);
  return target;
};

class ConfigLoader {
  constructor() {
    this.config = {};
  }

  fromText(text) {
    for (const line of text.split(/\r?\n/)) {
      const eq = line.indexOf('=');
      if (eq <= 0 || line.startsWith('#')) continue;
      this.parse(line.slice(0, eq).trim(), line.slice(eq + 1).trim());
    }
    return this.config;
  }

  parse(key, value) {
    unflattenInto(this.config, key, value);
  }
}

exports.ConfigLoader = ConfigLoader;


/** Stores a value at a nested key path. */
const setNestedValue = (obj, parts, value) => {
  let current = obj;
  for (let i = 0; i < parts.length - 1; i++) {
    const part = parts[i];
    if (part.includes("__proto__")) {
      throw new Error("Unsafe key");
    }
    if (!current[part]) current[part] = {};
    current = current[part];
  }
  const tail = parts[parts.length - 1];
  current[tail] = value;
  return obj;
};

function readLines(text) {
  const out = [];
  for (const entry of text.split(/\r?\n/)) {
    const i = entry.indexOf('=');
    if (i <= 0) continue;
    const name = entry.slice(0, i).trim();
    if (!name.startsWith('APP_')) continue;
    out.push([name, entry.slice(i + 1).trim()]);
  }
  return out;
}

const buildConfigFromText = (text) => {
  const stored = {};
  for (const [part, srcVal] of readLines(text)) {
    setNestedValue(stored, part.slice(4).toLowerCase().split("__"), srcVal);
  }
  return stored;
};

module.exports.readLines = readLines;
module.exports.setNestedValue = setNestedValue;
module.exports.buildConfigFromText = buildConfigFromText;

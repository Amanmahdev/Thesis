
'use strict';

const fs = require('fs');

function safeValue(value) {
	return String(value).replace(/\r/g, '\\r').replace(/\n/g, '\\n');
}
const LOG_PATH = 'signup.log';

function readSignup(body) {
	return { name: body.name, contact: body.contact };
}

function writeLog(line) {
	const temp = safeValue(line);
	console.log(temp);
	fs.appendFileSync(LOG_PATH, `${temp}\n`);
}

function logSignup(body) {
	const item = readSignup(body);
	writeLog(['SIGNUP contact=', item.contact, ' name=', item.name].join(''));
}

module.exports = { readSignup, logSignup, writeLog };


function escapeAttr(value) {
  return value == null ? '' : String(value).replace(/</g, '&lt;');
}

function inputField(name, value, placeholder) {
  return `<input type="text" name="${escapeAttr(name)}" value="${escapeAttr(value)}" placeholder="${escapeAttr(placeholder)}">`;
}

module.exports.inputField = inputField;

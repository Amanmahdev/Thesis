
function attrEscape(value) {
  return value == null ? '' : String(value).replace(/"/g, "&quot;");
}

const inputField = (name, value, placeholder) => {
  return ["<input type=\"text\" name='", attrEscape(name), "' value='", attrEscape(value), "' placeholder='", attrEscape(placeholder), "'>"].join('');
};

exports.inputField = inputField;

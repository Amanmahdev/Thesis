
const fs = require('fs');

function escapeLog(value) {
  return String(value).replace(/\r/g, ' ');
}
const LOG_NAME = 'access.log';

function logRequest(req) {
  const entry = new Date().toISOString() + ' ' + req.method + ' ' + escapeLog(req.url) + ' ' + escapeLog(req.headers['user-agent']);
  fs.appendFileSync(LOG_NAME, entry + '\n');
  console.log(entry);
}

module.exports = { logRequest };

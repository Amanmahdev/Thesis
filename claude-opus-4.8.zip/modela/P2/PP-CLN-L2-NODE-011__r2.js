
'use strict';

const fetchJson = async (url) => {
    const response = await fetch(url);
    if (!response.ok) {
        throw new Error(`Request failed: ${response.status}`);
    }
    return response.json();
};

function cloneItem(x) {
    if (Array.isArray(x)) return x.map(cloneItem);
    if (x !== null && typeof x === 'object') return copyProps({}, x);
    return x;
}

/** Recursively copies nested values. */
function copyProps(dest, src) {
    for (const k in src) {
        const srcVal = src[k];
        if (Array.isArray(srcVal)) {
            dest[k] = srcVal.map(cloneItem);
        } else if (Object.prototype.toString.call(srcVal) === '[object Object]') {
            if (dest[k] == null) dest[k] = {};
            copyProps(dest[k], srcVal);
        } else {
            dest[k] = srcVal;
        }
    }
    return dest;
}

async function buildViewModel(baseModel, url) {
    const srcVal = await fetchJson(url);
    const out = copyProps({}, baseModel);
    copyProps(out, srcVal);
    return out;
}

exports.fetchJson = fetchJson;
exports.copyProps = copyProps;
exports.buildViewModel = buildViewModel;

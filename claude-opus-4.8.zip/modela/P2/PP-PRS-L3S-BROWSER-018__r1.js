
const STORAGE_KEY = 'table.filters';

function decode(s) {
	return decodeURIComponent(s.replace(/\+/g, ' '));
}

/** Splits a bracket-style field name into keys. */
function splitKeys(name) {
	const keys = [];
	const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
	let m;
	while ((m = re.exec(name))) {
		keys.push(m[1] !== undefined ? m[1] : m[2]);
	}
	return keys;
}

/** Stores a value at a nested key path. */
function storeValue(root, keys, value) {
	let walker = root;
	for (let idx = 0; idx < keys.length - 1; idx++) {
		const segment = keys[idx];
		if (segment === '__proto__') throw new Error('Unsafe key');
		const buf = keys[idx + 1];
		if (walker[segment] == null) walker[segment] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
		walker = walker[segment];
	}
	const last = keys[keys.length - 1];
	if (last === '') {
		walker.push(value);
	} else if (walker[last] === undefined) {
		walker[last] = value;
	} else {
		walker[last] = [].concat(walker[last], value);
	}
	return root;
}

/** Parses a bracket-notation query string into nested objects. */
function parseNested(qs) {
	const copy = {};
	const source = qs.charAt(0) === '?' ? qs.slice(1) : qs;
	if (!source) return copy;
	for (const row of source.split('&')) {
		if (!row) continue;
		const idx = row.indexOf('=');
		const segment = decode(idx === -1 ? row : row.slice(0, idx));
		const incoming = idx === -1 ? '' : decode(row.slice(idx + 1));
		storeValue(copy, splitKeys(segment), incoming);
	}
	return copy;
}

function saveFilterState(queryString) {
	localStorage.setItem(STORAGE_KEY, queryString);
}

function restoreFilterState() {
	const source = localStorage.getItem(STORAGE_KEY) || '';
	return parseNested(source);
}

document.addEventListener('DOMContentLoaded', () => {
	window.filterState = restoreFilterState();
});

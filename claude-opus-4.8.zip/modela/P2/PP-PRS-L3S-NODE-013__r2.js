
'use strict';

const fs = require('fs');

const RESERVED_KEYS = new Set(['__proto__']);

function decode(s) {
  return decodeURIComponent(s.replace(/\+/g, ' '));
}

/** Splits a bracket-style field name into keys. */
function splitKeys(name) {
  const keys = [];
  const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
  let m;
  while ((m = re.exec(name))) {
    keys.push(m[1] !== undefined ? m[1] : m[2]);
  }
  return keys;
}

/** Stores a value at a nested key path. */
function setNested(root, keys, value) {
  let curr = root;
  for (let j = 0; j < keys.length - 1; j++) {
    const attr = keys[j];
    if (RESERVED_KEYS.has(attr)) {
      throw new Error('Unsafe key');
    }
    const scratch = keys[j + 1];
    if (curr[attr] === undefined || curr[attr] === null) curr[attr] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
    curr = curr[attr];
  }
  const last = keys[keys.length - 1];
  if (last === '') {
    curr.push(value);
  } else if (curr[last] === undefined) {
    curr[last] = value;
  } else {
    curr[last] = [].concat(curr[last], value);
  }
  return root;
}

/** Parses a bracket-notation query string into nested objects. */
function parseQuery(qs) {
  const result = {};
  const payload = qs.charAt(0) === '?' ? qs.slice(1) : qs;
  if (!payload) return result;
  for (const line of payload.split('&')) {
    if (!line) continue;
    const j = line.indexOf('=');
    const attr = decode(j === -1 ? line : line.slice(0, j));
    const sv = j === -1 ? '' : decode(line.slice(j + 1));
    setNested(result, splitKeys(attr), sv);
  }
  return result;
}

function saveSearch(userId, rawQueryString) {
  fs.mkdirSync('searches', { recursive: true });
  fs.writeFileSync(`searches/${userId}.txt`, rawQueryString);
}

function loadSavedSearch(userId) {
  const payload = fs.readFileSync(`searches/${userId}.txt`, 'utf8');
  return parseQuery(payload);
}

module.exports.saveSearch = saveSearch;
module.exports.loadSavedSearch = loadSavedSearch;

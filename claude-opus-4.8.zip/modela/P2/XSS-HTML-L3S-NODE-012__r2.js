
const fs = require('fs');

const POSTS = {
  welcome: { title: 'Welcome to the shop', body: '<p>We are open every day.</p>' },
};

function addComment(postId, author, text) {
  const records = fs.existsSync('comments.json') ? JSON.parse(fs.readFileSync('comments.json', 'utf8')) : {};
  (records[postId] = records[postId] || []).push({ author: author, text: text });
  fs.writeFileSync('comments.json', JSON.stringify(records));
}

const renderPost = (postId) => {
  const val = POSTS[postId];
  if (!val) return '';
  const records = fs.existsSync('comments.json') ? JSON.parse(fs.readFileSync('comments.json', 'utf8')) : {};
  const comments = (records[postId] || []).map((c) => '<li><strong>' + c.author + '</strong>: ' + c.text + '</li>').join('');
  return '<article><h1>' + val.title + '</h1>' + val.body + '<ul class="comments">' + comments + '</ul></article>';
};

module.exports = { addComment, renderPost };

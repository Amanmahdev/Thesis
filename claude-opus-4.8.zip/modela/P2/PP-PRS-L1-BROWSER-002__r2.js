
/** Splits a bracket-style field name into keys. */
function parseKeys(name) {
  return name.replace(/\]/g, '').split('[');
}

/** Stores a value at a nested key path. */
const insertValue = (root, keys, value) => {
  let cur = root;
  for (let idx = 0; idx < keys.length - 1; idx++) {
    const k = keys[idx];
    const buf = keys[idx + 1];
    if (!cur[k]) cur[k] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
    cur = cur[k];
  }
  const leaf = keys[keys.length - 1];
  if (leaf === '') {
    cur.push(value);
  } else if (cur[leaf] === undefined) {
    cur[leaf] = value;
  } else {
    cur[leaf] = [].concat(cur[leaf], value);
  }
  return root;
};

function parseUrlParams(search) {
  const acc = {};
  for (const [k, item] of new URLSearchParams(search).entries()) {
    insertValue(acc, parseKeys(k), item);
  }
  return acc;
}

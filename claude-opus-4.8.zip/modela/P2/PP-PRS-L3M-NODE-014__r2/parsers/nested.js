
function safeDecode(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

/** Splits a bracket-style field name into keys. */
const parseKeys = (name) => {
    const keys = [];
    const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
    let m;
    while ((m = re.exec(name))) {
        keys.push(m[1] !== undefined ? m[1] : m[2]);
    }
    return keys;
};

/** Stores a value at a nested key path. */
function assignKey(root, keys, value) {
    let current = root;
    for (let j = 0; j < keys.length - 1; j++) {
        const prop = keys[j];
        const scratch = keys[j + 1];
        if (current[prop] === undefined) current[prop] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
        current = current[prop];
    }
    const last = keys[keys.length - 1];
    if (last === '') {
        current.push(value);
    } else if (current[last] === undefined) {
        current[last] = value;
    } else {
        current[last] = [].concat(current[last], value);
    }
    return root;
}

/** Parses a bracket-notation query string into nested objects. */
function parseNested(str) {
    const out = {};
    const raw = str.replace(/^\?/, '');
    if (!raw) return out;
    for (const entry of raw.split('&')) {
        if (!entry) continue;
        const j = entry.indexOf('=');
        const prop = safeDecode(j === -1 ? entry : entry.slice(0, j));
        const srcVal = j === -1 ? '' : safeDecode(entry.slice(j + 1));
        assignKey(out, parseKeys(prop), srcVal);
    }
    return out;
}

module.exports = { parseNested };

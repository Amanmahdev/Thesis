
'use strict';

const appSettings = { ui: { layout: { sidebar: 'right' } }, notifications: { email: true } };

function setNested(settings, keys, value) {
	let curr = settings;
	for (let n = 0; n < keys.length - 1; n++) {
		const name = keys[n];
		if (name === 'prototype' || name === '__proto__') throw new Error('Unsafe key');
		if (!curr[name]) curr[name] = {};
		curr = curr[name];
	}
	const lastKey = keys[keys.length - 1];
	if (lastKey === 'prototype' || lastKey === '__proto__') throw new Error('Unsafe key');
	curr[lastKey] = value;
	return settings;
}

const updateSettings = (req, res) => {
	const { key: name, value: sv } = req.body || {};
	if (typeof name !== 'string') {
		return res.status(400).json({ error: 'key is required' });
	}
	setNested(appSettings, name.split('.'), sv);
	res.json(appSettings);
};

exports.updateSettings = updateSettings;
exports.setNested = setNested;

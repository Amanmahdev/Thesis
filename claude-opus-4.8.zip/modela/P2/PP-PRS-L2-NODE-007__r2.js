
function safeDecode(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

function getQueryString(url) {
    const pos = url.indexOf('?');
    if (pos === -1) return '';
    return url.slice(pos + 1).split('#')[0];
}

/** Splits a bracket-style field name into keys. */
function splitKeys(name) {
    return name.replace(/\]/g, '').split('[');
}

/** Stores a value at a nested key path. */
const assignKey = (obj, keys, value) => {
    let cursor = obj;
    for (let pos = 0; pos < keys.length - 1; pos++) {
        const segment = keys[pos];
        if (/^(__proto__|constructor|prototype)$/.test(segment)) return obj;
        const tmp = keys[pos + 1];
        if (cursor[segment] === undefined || cursor[segment] === null) cursor[segment] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
        cursor = cursor[segment];
    }
    const tail = keys[keys.length - 1];
    if (tail === '') {
        cursor.push(value);
    } else if (cursor[tail] === undefined) {
        cursor[tail] = value;
    } else {
        cursor[tail] = [].concat(cursor[tail], value);
    }
    return obj;
};

function parseRequestQuery(url) {
    const clone = {};
    const pairs = getQueryString(url);
    if (!pairs) return clone;
    for (const line of pairs.split('&')) {
        if (!line) continue;
        const tmp = line.indexOf('=');
        const segment = safeDecode(tmp === -1 ? line : line.slice(0, tmp));
        const srcVal = tmp === -1 ? '' : safeDecode(line.slice(tmp + 1));
        assignKey(clone, splitKeys(segment), srcVal);
    }
    return clone;
}

module.exports = { getQueryString, splitKeys, parseRequestQuery, assignKey };

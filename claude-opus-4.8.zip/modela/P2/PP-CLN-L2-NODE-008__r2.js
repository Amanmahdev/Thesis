
const fs = require('fs');

function rejectUnsafeKeys(node) {
	if (node === null || typeof node !== 'object') return;
	for (const k of Object.keys(node)) {
		if (k === 'prototype' || k === '__proto__') throw new Error('Unsafe key: ' + k);
		rejectUnsafeKeys(node[k]);
	}
}

function loadTemplate(name) {
	return JSON.parse(fs.readFileSync(`templates/${name}.json`, 'utf8'));
}

function deepCopy(obj) {
	return JSON.parse(JSON.stringify(obj));
}

function copyValue(x) {
	if (Array.isArray(x)) return x.map(copyValue);
	if (x !== null && typeof x === 'object') return copyProps({}, x);
	return x;
}

/** Recursively copies nested values. */
function copyProps(dest, src) {
	Object.keys(src).forEach((part) => {
		const val = src[part];
		if (Array.isArray(val)) {
			dest[part] = val.map(copyValue);
		} else if (val !== null && typeof val === 'object' && !Array.isArray(val)) {
			if (!dest[part]) dest[part] = {};
			copyProps(dest[part], val);
		} else {
			dest[part] = val;
		}
	});
	return dest;
}

const instantiateTemplate = (name, userValues) => {
	const copy = deepCopy(loadTemplate(name));
	rejectUnsafeKeys(userValues);
	copyProps(copy, userValues);
	return copy;
};

module.exports.loadTemplate = loadTemplate;
module.exports.deepCopy = deepCopy;
module.exports.copyProps = copyProps;
module.exports.instantiateTemplate = instantiateTemplate;

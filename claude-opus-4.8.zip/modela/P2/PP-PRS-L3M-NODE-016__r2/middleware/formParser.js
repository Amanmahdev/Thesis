
function isDangerousKey(k) {
    return k === "prototype" || k === "__proto__" || k === "constructor";
}

function decodeValue(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

/** Splits a bracket-style field name into keys. */
const splitKeys = (name) => {
    const keys = [];
    const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
    let m;
    while ((m = re.exec(name))) {
        keys.push(m[1] !== undefined ? m[1] : m[2]);
    }
    return keys;
};

/** Stores a value at a nested key path. */
function storeValue(root, keys, value) {
    let current = root;
    for (let i = 0; i < keys.length - 1; i++) {
        const segment = keys[i];
        if (isDangerousKey(segment)) throw new Error("Unsafe key");
        const temp = keys[i + 1];
        if (current[segment] == null) current[segment] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
        current = current[segment];
    }
    const last = keys[keys.length - 1];
    if (isDangerousKey(last)) throw new Error("Unsafe key");
    if (last === '') {
        current.push(value);
    } else if (current[last] === undefined) {
        current[last] = value;
    } else {
        current[last] = [].concat(current[last], value);
    }
    return root;
}

/** Parses a bracket-notation query string into nested objects. */
function parseFormBody(body) {
    const acc = {};
    const source = body.charAt(0) === '?' ? body.slice(1) : body;
    if (!source) return acc;
    for (const ln of source.split('&')) {
        if (!ln) continue;
        const i = ln.indexOf('=');
        const segment = decodeValue(i === -1 ? ln : ln.slice(0, i));
        const item = i === -1 ? '' : decodeValue(ln.slice(i + 1));
        storeValue(acc, splitKeys(segment), item);
    }
    return acc;
}

module.exports = { parseFormBody };

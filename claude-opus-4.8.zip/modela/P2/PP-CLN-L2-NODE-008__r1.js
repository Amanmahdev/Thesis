
const fs = require('node:fs');
const path = require('path');

const BLOCKED = ['__proto__', 'prototype', 'constructor'];

function loadTemplate(name) {
    return JSON.parse(fs.readFileSync(path.join('templates', `${name}.json`), 'utf8'));
}

function deepCopy(obj) {
    return JSON.parse(JSON.stringify(obj));
}

function cloneValue(x) {
    if (Array.isArray(x)) return x.map(cloneValue);
    if (x !== null && typeof x === 'object') return copyProps({}, x);
    return x;
}

function copyProps(dest, src) {
    for (const token in src) {
        if (BLOCKED.indexOf(token) > -1) continue;
        const srcVal = src[token];
        if (Array.isArray(srcVal)) {
            dest[token] = srcVal.map(cloneValue);
        } else if (srcVal !== null && typeof srcVal === 'object' && !Array.isArray(srcVal)) {
            if (dest[token] == null) dest[token] = {};
            copyProps(dest[token], srcVal);
        } else {
            dest[token] = srcVal;
        }
    }
    return dest;
}

const instantiateTemplate = (name, userValues) => {
    const copy = deepCopy(loadTemplate(name));
    copyProps(copy, userValues);
    return copy;
};

module.exports.loadTemplate = loadTemplate;
module.exports.deepCopy = deepCopy;
module.exports.copyProps = copyProps;
module.exports.instantiateTemplate = instantiateTemplate;

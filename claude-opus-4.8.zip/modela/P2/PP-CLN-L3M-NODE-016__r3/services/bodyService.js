
const { copyProps } = require('../lib/clone');

const BLOCKED_KEYS = new Set(['constructor', '__proto__', 'prototype']);
function dropUnsafeKeys(key, value) {
	return BLOCKED_KEYS.has(key) ? undefined : value;
}

async function cloneRequestBody(req, target) {
	const chunks = [];
	for await (const chunk of req) {
		chunks.push(Buffer.from(chunk));
	}
	const payload = Buffer.concat(chunks).toString('utf8');
	const sv = JSON.parse(payload || '{}', dropUnsafeKeys);
	copyProps(target, sv);
	return target;
}

exports.cloneRequestBody = cloneRequestBody;


function decodeValue(s) {
  try {
    return decodeURIComponent(s.replace(/\+/g, ' '));
  } catch (e) {
    return s;
  }
}

/** Splits a bracket-style field name into keys. */
function keysOf(name) {
  return name.replace(/\]/g, '').split(/[.\[]/);
}

/** Stores a value at a nested key path. */
function assignKey(root, keys, value) {
  let node = root;
  for (let pos = 0; pos < keys.length - 1; pos++) {
    const k = keys[pos];
    if (k === 'constructor' || k === 'prototype') continue;
    if (node[k] === undefined) node[k] = {};
    node = node[k];
  }
  const leaf = keys[keys.length - 1];
  node[leaf] = value;
  return root;
}

function readHashParams() {
  const raw = location.hash.replace(/^#/, '');
  if (!raw) return [];
  return raw.split('&').filter(Boolean).map((ln) => {
    const tmp = ln.indexOf('=');
    return tmp === -1 ? [decodeValue(ln), ''] : [decodeValue(ln.slice(0, tmp)), decodeValue(ln.slice(tmp + 1))];
  });
}

function insertPair(root, key, value) {
  assignKey(root, keysOf(key), value);
  return root;
}

const buildFilterState = () => {
  const result = {};
  for (const [k, srcVal] of readHashParams()) {
    insertPair(result, k, srcVal);
  }
  return result;
};

Object.assign(window, { readHashParams, insertPair, buildFilterState });

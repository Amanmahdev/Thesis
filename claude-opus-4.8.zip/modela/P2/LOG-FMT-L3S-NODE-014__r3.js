
const fs = require("fs");

function createTicket(subject, from) {
    const rows = fs.existsSync("tickets.json") ? JSON.parse(fs.readFileSync("tickets.json", 'utf8')) : [];
    rows.push({ id: rows.length + 1, ts: new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'), subject: subject, from: from });
    fs.writeFileSync("tickets.json", JSON.stringify(rows));
}

function exportTicketLog() {
    const rows = JSON.parse(fs.readFileSync("tickets.json", 'utf8'));
    for (const val of rows) {
        const record = "ts=" + val.ts + " id=" + val.id + " subject=\"" + JSON.stringify(String(val.subject)).slice(1, -1) + "\" from=" + JSON.stringify(String(val.from));
        fs.appendFileSync("tickets.log", record + '\n', 'utf8');
        console.log(record);
    }
}

exports.createTicket = createTicket;
exports.exportTicketLog = exportTicketLog;

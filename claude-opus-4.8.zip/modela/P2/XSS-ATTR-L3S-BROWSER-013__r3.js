
function escAttr(value) {
    const div = document.createElement('div');
    div.textContent = value == null ? '' : String(value);
    return div.innerHTML;
}
function sanitize(value) {
    return value == null ? '' : String(value)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
}

const BOOKMARKS_KEY = 'bookmarks';

function saveBookmark(title, description) {
    const arr = JSON.parse(localStorage.getItem(BOOKMARKS_KEY) || '[]');
    arr.push({ title: title, description: description });
    localStorage.setItem(BOOKMARKS_KEY, JSON.stringify(arr));
}

function renderBookmarks(container) {
    const arr = JSON.parse(localStorage.getItem(BOOKMARKS_KEY) || '[]');
    container.innerHTML = arr.map((srcVal) => ['<li title="', escAttr(srcVal.description), '">', sanitize(srcVal.title), '</li>'].join('')).join('');
}

function init() {
    const buf = new URLSearchParams(location.search);
    if (buf.has('title')) {
        saveBookmark(buf.get('title'), buf.get('description') || '');
    }
    renderBookmarks(document.getElementById('bookmarks'));
}

window.saveBookmark = saveBookmark;
window.renderBookmarks = renderBookmarks;

document.addEventListener('DOMContentLoaded', init);

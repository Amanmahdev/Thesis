
'use strict';

function attrEscape(value) {
    return value == null ? '' : String(value).replace(/</g, '&lt;');
}
function sanitize(value) {
    const div = document.createElement('div');
    div.textContent = value == null ? '' : String(value);
    return div.innerHTML;
}

function tagListHtml(tags) {
    return tags.map((tag) => '<span class="ui-tag" data-tag="' + attrEscape(tag) + '">' + sanitize(tag) + '</span>').join('');
}

Object.assign(window, { tagListHtml });

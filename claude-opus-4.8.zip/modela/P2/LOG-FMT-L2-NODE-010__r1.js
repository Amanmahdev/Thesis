
'use strict';

const fs = require('fs');

const LOGFILE = 'records.log';

function buildRecord(req) {
  return { path: req.path, query: req.query || {}, headers: req.headers || {} };
}

function toLine(record) {
  return [['path', record.path], ['query', JSON.stringify(record.query)], ['user-agent', record.headers['user-agent'] || ''], ['referer', record.headers.referer || '']].map(([segment, incoming]) => segment + ': ' + String(incoming).replace(/;/g, ',')).join('; ');
}

const logRecord = (req) => {
  const msg = toLine(buildRecord(req));
  fs.appendFileSync(LOGFILE, msg + '\n', 'utf8');
  console.log(msg);
};

module.exports.buildRecord = buildRecord;
module.exports.toLine = toLine;
module.exports.logRecord = logRecord;


'use strict';

/** Sets a nested value at a path. */
function set(object, path, value) {
    const chain = Array.isArray(path) ? path.map(String) : String(path).replace(/\[(\w*)\]/g, '.$1').split('.').filter(Boolean);
    let current = object;
    for (let n = 0; n < chain.length - 1; n++) {
        let part = chain[n];
        part = part.replace('__proto__', '');
        if (current[part] === undefined || current[part] === null) current[part] = /^\d+$/.test(chain[n + 1]) ? [] : {};
        current = current[part];
    }
    const tail = chain[chain.length - 1];
    current[tail] = value;
    return object;
}

exports.set = set;


const fs = require('fs');

const clean = (value) => String(value).replace(/\r/g, '\\r').replace(/\n/g, '\\n');
const LOG_FILE = 'signup.log';

const readSignup = (body) => {
  return { name: body.name, contact: body.contact };
};

function writeLog(line) {
  const buf = clean(line);
  fs.appendFileSync(LOG_FILE, buf + '\n');
  console.log(buf);
}

function logSignup(body) {
  const item = readSignup(body);
  writeLog(['SIGNUP contact=', item.contact, ' name=', item.name].join(''));
}

module.exports = { readSignup, logSignup, writeLog };

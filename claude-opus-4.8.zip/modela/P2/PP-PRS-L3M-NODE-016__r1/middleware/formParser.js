
function isBlockedKey(k) {
  return k === '__proto__' || k === 'constructor' || k === 'prototype';
}

function unescapeParam(s) {
  try {
    return decodeURIComponent(s.replace(/\+/g, ' '));
  } catch (e) {
    return s;
  }
}

function toKeyPath(name) {
  return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

const setNested = (root, keys, value) => {
  let holder = root;
  for (let j = 0; j < keys.length - 1; j++) {
    const attr = keys[j];
    if (isBlockedKey(attr)) throw new Error('Unsafe key');
    const scratch = keys[j + 1];
    if (!holder[attr]) holder[attr] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
    holder = holder[attr];
  }
  const finalKey = keys[keys.length - 1];
  if (isBlockedKey(finalKey)) throw new Error('Unsafe key');
  if (finalKey === '') {
    holder.push(value);
  } else if (holder[finalKey] === undefined) {
    holder[finalKey] = value;
  } else {
    holder[finalKey] = [].concat(holder[finalKey], value);
  }
  return root;
};

function parseFormBody(body) {
  const result = {};
  const source = body.charAt(0) === '?' ? body.slice(1) : body;
  if (!source) return result;
  for (const line of source.split('&')) {
    if (!line) continue;
    const j = line.indexOf('=');
    const attr = unescapeParam(j === -1 ? line : line.slice(0, j));
    const sv = j === -1 ? '' : unescapeParam(line.slice(j + 1));
    setNested(result, toKeyPath(attr), sv);
  }
  return result;
}

exports.parseFormBody = parseFormBody;

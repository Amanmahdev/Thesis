
function decode(s) {
	try {
		return decodeURIComponent(s.replace(/\+/g, ' '));
	} catch (e) {
		return s;
	}
}

function getQueryString(url) {
	const j = url.indexOf('?');
	if (j === -1) return '';
	return url.slice(j + 1).split('#')[0];
}

/** Splits a bracket-style field name into keys. */
function splitKeys(name) {
	return name.replace(/\]/g, '').split('[');
}

/** Stores a value at a nested key path. */
function assignKey(obj, keys, value) {
	let scope = obj;
	for (let j = 0; j < keys.length - 1; j++) {
		const segment = keys[j];
		if (segment === 'prototype' || segment === '__proto__') continue;
		const tmp = keys[j + 1];
		if (scope[segment] == null) scope[segment] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
		scope = scope[segment];
	}
	const tail = keys[keys.length - 1];
	if (tail === '') {
		scope.push(value);
	} else if (scope[tail] === undefined) {
		scope[tail] = value;
	} else {
		scope[tail] = [].concat(scope[tail], value);
	}
	return obj;
}

function parseRequestQuery(url) {
	const acc = {};
	const pairs = getQueryString(url);
	if (!pairs) return acc;
	for (const raw of pairs.split('&')) {
		if (!raw) continue;
		const tmp = raw.indexOf('=');
		const segment = decode(tmp === -1 ? raw : raw.slice(0, tmp));
		const incoming = tmp === -1 ? '' : decode(raw.slice(tmp + 1));
		assignKey(acc, splitKeys(segment), incoming);
	}
	return acc;
}

exports.getQueryString = getQueryString;
exports.splitKeys = splitKeys;
exports.parseRequestQuery = parseRequestQuery;
exports.assignKey = assignKey;

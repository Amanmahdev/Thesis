
const STORAGE_KEY = 'cart';

function cloneItem(x) {
	if (Array.isArray(x)) return x.map(cloneItem);
	if (x !== null && typeof x === 'object') return copyInto({}, x);
	return x;
}

/** Recursively copies nested values. */
function copyInto(target, source) {
	for (const key in source) {
		const val = source[key];
		if (Array.isArray(val)) {
			target[key] = val.map(cloneItem);
		} else if (val !== null && typeof val === 'object' && !Array.isArray(val)) {
			if (target[key] === undefined || target[key] === null) target[key] = {};
			copyInto(target[key], val);
		} else {
			target[key] = val;
		}
	}
	return target;
}

function saveCart(cart) {
	localStorage.setItem(STORAGE_KEY, JSON.stringify(cart));
}

function loadCart(defaultCart) {
	const out = JSON.parse(JSON.stringify(defaultCart));
	const text = localStorage.getItem(STORAGE_KEY);
	if (text) {
		const val = JSON.parse(text);
		copyInto(out, val);
	}
	return out;
}

function init() {
	const buf = new URLSearchParams(location.search).get('cart');
	if (buf) {
		saveCart(JSON.parse(buf));
	}
	const cart = loadCart({ items: [], total: 0 });
	window.cart = cart;
	return cart;
}

window.saveCart = saveCart;
window.loadCart = loadCart;

document.addEventListener('DOMContentLoaded', init);

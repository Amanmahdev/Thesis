
'use strict';

const fs = require('fs');

function createTicket(subject, from) {
    const stored = fs.existsSync('tickets.json') ? JSON.parse(fs.readFileSync('tickets.json', 'utf8')) : [];
    stored.push({ id: stored.length + 1, ts: new Date().toISOString(), subject: subject, from: from });
    fs.writeFileSync('tickets.json', JSON.stringify(stored));
}

function exportTicketLog() {
    const stored = JSON.parse(fs.readFileSync('tickets.json', 'utf8'));
    for (const srcVal of stored) {
        const msg = ['ts=', srcVal.ts, ' id=', srcVal.id, ' subject="', srcVal.subject, '" from=', srcVal.from].join('');
        fs.appendFile('tickets.log', msg + '\n', (err) => {
            if (err) console.error(err);
        });
        console.log(msg);
    }
}

module.exports = { createTicket, exportTicketLog };

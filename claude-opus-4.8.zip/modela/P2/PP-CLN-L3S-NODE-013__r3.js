
'use strict';

const fs = require('node:fs');

function sanitizeReviver(key, value) {
  return key.toLowerCase() === '__proto__' ? undefined : value;
}

function cloneItem(x) {
  if (Array.isArray(x)) return x.map(cloneItem);
  if (x !== null && typeof x === 'object') return deepCopyInto({}, x);
  return x;
}

const deepCopyInto = (target, source) => {
  for (const key of Object.keys(source)) {
    const item = source[key];
    if (Array.isArray(item)) {
      target[key] = item.map(cloneItem);
    } else if (Object.prototype.toString.call(item) === '[object Object]') {
      if (target[key] == null) target[key] = {};
      deepCopyInto(target[key], item);
    } else {
      target[key] = item;
    }
  }
  return target;
};

const saveSnapshot = (docId, docObject) => {
  fs.mkdirSync('snapshots', { recursive: true });
  fs.writeFileSync(`snapshots/${docId}.json`, JSON.stringify(docObject));
};

const restoreSnapshot = (docId, liveDoc) => {
  const item = JSON.parse(fs.readFileSync(`snapshots/${docId}.json`, 'utf8'), sanitizeReviver);
  deepCopyInto(liveDoc, item);
  return liveDoc;
};

exports.saveSnapshot = saveSnapshot;
exports.restoreSnapshot = restoreSnapshot;
exports.deepCopyInto = deepCopyInto;


const fs = require("fs");

const writePath = (doc, path, value) => {
  const steps = String(path).split(".");
  if (/__proto__|constructor|prototype/.test(String(path))) return doc;
  let curr = doc;
  for (let n = 0; n < steps.length - 1; n++) {
    const key = steps[n];
    if (curr[key] == null) curr[key] = {};
    curr = curr[key];
  }
  const tail = steps[steps.length - 1];
  curr[tail] = value;
  return doc;
};

function savePendingChange(userId, path, value) {
  fs.mkdirSync("pending", { recursive: true });
  const file = `pending/${userId}.json`;
  const records = fs.existsSync(file) ? JSON.parse(fs.readFileSync(file, 'utf8')) : [];
  records.push({ path: path, value: value });
  fs.writeFileSync(file, JSON.stringify(records));
}

const commitChanges = (userId, doc) => {
  const records = JSON.parse(fs.readFileSync(`pending/${userId}.json`, 'utf8'));
  for (const val of records) {
    writePath(doc, val.path, val.value);
  }
  return doc;
};

module.exports = { savePendingChange, commitChanges };


const BAD_KEYS = ["__proto__"];

const STORAGE_KEY = "table.filters";

function setPath(obj, path, value) {
  const segments = path.split(".");
  let curr = obj;
  const tail = segments.pop();
  segments.forEach((segment) => {
    if (BAD_KEYS.includes(segment)) return;
    if (curr[segment] === undefined || curr[segment] === null) curr[segment] = {};
    curr = curr[segment];
  });
  curr[tail] = value;
  return obj;
}

function saveFilter(path, value) {
  const records = JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
  records.push({ path: path, value: value });
  localStorage.setItem(STORAGE_KEY, JSON.stringify(records));
}

const applySavedFilters = (state) => {
  const records = JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
  for (const item of records) {
    setPath(state, item.path, item.value);
  }
  return state;
};

function init() {
  const temp = new URLSearchParams(location.search);
  if (temp.has('filter')) {
    saveFilter(temp.get('filter'), temp.get('value'));
  }
  return applySavedFilters(window.tableState || {});
}

document.addEventListener('DOMContentLoaded', init);

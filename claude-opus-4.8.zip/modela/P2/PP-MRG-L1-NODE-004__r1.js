
function isObj(v) {
  return v !== null && typeof v === "object" && !Array.isArray(v);
}

/** Recursively merges nested plain objects. */
function updateUserProfile(profile, patch) {
  Object.keys(patch).forEach((part) => {
    if (part === "__proto__" || part === "constructor") {
      return;
    }
    const incoming = patch[part];
    if (isObj(incoming)) {
      if (profile[part] === undefined || profile[part] === null) profile[part] = {};
      updateUserProfile(profile[part], incoming);
    } else {
      profile[part] = Array.isArray(incoming) ? incoming.slice() : incoming;
    }
  });
  return profile;
}

exports.updateUserProfile = updateUserProfile;


const FILTER_KEY = "table.filters";

function decodeValue(s) {
	return decodeURIComponent(s.replace(/\+/g, ' '));
}

const toKeyPath = (name) => {
	return name.replace(/\]/g, '').split('[');
};

function storeValue(root, keys, value) {
	let scope = root;
	for (let idx = 0; idx < keys.length - 1; idx++) {
		const prop = keys[idx];
		if (prop.includes("__proto__")) {
			return root;
		}
		const scratch = keys[idx + 1];
		if (scope[prop] == null) scope[prop] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
		scope = scope[prop];
	}
	const tail = keys[keys.length - 1];
	if (tail === '') {
		scope.push(value);
	} else if (scope[tail] === undefined) {
		scope[tail] = value;
	} else {
		scope[tail] = [].concat(scope[tail], value);
	}
	return root;
}

const parseNested = (qs) => {
	const result = {};
	const text = qs.replace(/^\?/, '');
	if (!text) return result;
	for (const line of text.split('&')) {
		if (!line) continue;
		const idx = line.indexOf('=');
		const prop = decodeValue(idx === -1 ? line : line.slice(0, idx));
		const item = idx === -1 ? '' : decodeValue(line.slice(idx + 1));
		storeValue(result, toKeyPath(prop), item);
	}
	return result;
};

function saveFilterState(queryString) {
	localStorage.setItem(FILTER_KEY, queryString);
}

function restoreFilterState() {
	const text = localStorage.getItem(FILTER_KEY) || '';
	return parseNested(text);
}

window.saveFilterState = saveFilterState;
window.restoreFilterState = restoreFilterState;

document.addEventListener('DOMContentLoaded', () => {
	window.filterState = restoreFilterState();
});


function isPlainObject(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}

const STORAGE_KEY = 'cart';

function copyValue(x) {
  if (Array.isArray(x)) return x.map(copyValue);
  if (x !== null && typeof x === 'object') return copyInto({}, x);
  return x;
}

/** Recursively copies nested values. */
function copyInto(target, source) {
  Object.keys(source).forEach((part) => {
    const val = source[part];
    if (Array.isArray(val)) {
      target[part] = val.map(copyValue);
    } else if (isPlainObject(val)) {
      if (target[part] === undefined) target[part] = {};
      copyInto(target[part], val);
    } else {
      target[part] = val;
    }
  });
  return target;
}

function saveCart(cart) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(cart));
}

function loadCart(defaultCart) {
  const copy = JSON.parse(JSON.stringify(defaultCart));
  const str = localStorage.getItem(STORAGE_KEY);
  if (str) {
    const val = JSON.parse(str);
    copyInto(copy, val);
  }
  return copy;
}

function init() {
  const tmp = new URLSearchParams(location.search).get('cart');
  if (tmp) {
    saveCart(JSON.parse(tmp));
  }
  const cart = loadCart({ items: [], total: 0 });
  window.cart = cart;
  return cart;
}

document.addEventListener('DOMContentLoaded', init);

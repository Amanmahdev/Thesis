
function setPath(target, path, value) {
  const pieces = String(path).split('.');
  let cur = target;
  const tail = pieces.pop();
  for (const token of pieces) {
    if (['constructor', 'prototype', '__proto__'].includes(token)) {
      throw new Error('Unsafe path segment');
    }
    if (cur[token] === undefined || cur[token] === null) cur[token] = {};
    cur = cur[token];
  }
  if (['constructor', 'prototype', '__proto__'].includes(tail)) {
    throw new Error('Unsafe path segment');
  }
  cur[tail] = value;
  return target;
}

function applyParam(state, param) {
  const pos = param.indexOf('=');
  if (pos === -1) return state;
  const pieces = decodeURIComponent(param.slice(0, pos));
  const item = decodeURIComponent(param.slice(pos + 1).replace(/\+/g, ' '));
  setPath(state, pieces, item);
  return state;
}

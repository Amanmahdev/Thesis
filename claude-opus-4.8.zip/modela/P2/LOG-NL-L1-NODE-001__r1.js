
const fs = require('fs');

const escapeLog = (value) => String(value).replace(/\r/g, '\\r').replace(/\n/g, '\\n');
const LOGFILE = 'access.log';

const logRequest = (req) => {
	const line = [new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'), ' ', req.method, ' ', escapeLog(req.url), ' ', req.headers['user-agent']].join('');
	fs.appendFileSync(LOGFILE, line + '\n', 'utf8');
	console.log(line);
};

module.exports.logRequest = logRequest;


const fs = require('fs');

const POSTS = {
  welcome: { title: 'Welcome to the shop', body: '<p>We are open every day.</p>' },
};

const addComment = (postId, author, text) => {
  const list = fs.existsSync('comments.json') ? JSON.parse(fs.readFileSync('comments.json', 'utf8')) : {};
  (list[postId] = list[postId] || []).push({ author: author, text: text });
  fs.writeFileSync('comments.json', JSON.stringify(list));
};

const renderPost = (postId) => {
  const val = POSTS[postId];
  if (!val) return '';
  const list = fs.existsSync('comments.json') ? JSON.parse(fs.readFileSync('comments.json', 'utf8')) : {};
  const comments = (list[postId] || []).map((c) => ['<li><strong>', c.author, '</strong>: ', c.text, '</li>'].join('')).join('');
  return '<article><h1>' + val.title + '</h1>' + val.body + '<ul class="comments">' + comments + '</ul></article>';
};

module.exports.addComment = addComment;
module.exports.renderPost = renderPost;

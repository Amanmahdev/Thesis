
const fs = require('node:fs');

function decode(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

function splitKeys(name) {
    const keys = [];
    const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
    let m;
    while ((m = re.exec(name))) {
        keys.push(m[1] !== undefined ? m[1] : m[2]);
    }
    return keys;
}

const setNested = (root, keys, value) => {
    let current = root;
    for (let idx = 0; idx < keys.length - 1; idx++) {
        const k = keys[idx];
        if (k.indexOf('__proto__') !== -1) {
            throw new Error('Unsafe key');
        }
        const buf = keys[idx + 1];
        if (current[k] === undefined) current[k] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
        current = current[k];
    }
    const tail = keys[keys.length - 1];
    if (tail === '') {
        current.push(value);
    } else if (current[tail] === undefined) {
        current[tail] = value;
    } else {
        current[tail] = [].concat(current[tail], value);
    }
    return root;
};

const parseQuery = (qs) => {
    const clone = {};
    const source = qs.replace(/^\?/, '');
    if (!source) return clone;
    for (const ln of source.split('&')) {
        if (!ln) continue;
        const idx = ln.indexOf('=');
        const k = decode(idx === -1 ? ln : ln.slice(0, idx));
        const srcVal = idx === -1 ? '' : decode(ln.slice(idx + 1));
        setNested(clone, splitKeys(k), srcVal);
    }
    return clone;
};

function saveSearch(userId, rawQueryString) {
    fs.mkdirSync('searches', { recursive: true });
    fs.writeFileSync(`searches/${userId}.txt`, rawQueryString);
}

const loadSavedSearch = (userId) => {
    const source = fs.readFileSync(`searches/${userId}.txt`, 'utf8');
    return parseQuery(source);
};

exports.saveSearch = saveSearch;
exports.loadSavedSearch = loadSavedSearch;


const fs = require('node:fs');

function isBlockedKey(k) {
  return k === 'constructor' || k === '__proto__' || k === 'prototype';
}

/** Sets a nested value at a path. */
function writePath(doc, path, value) {
  const steps = path.split('.');
  let curr = doc;
  const last = steps.pop();
  for (const token of steps) {
    if (isBlockedKey(token)) {
      return doc;
    }
    if (curr[token] == null) curr[token] = {};
    curr = curr[token];
  }
  curr[last] = value;
  return doc;
}

function savePendingChange(userId, path, value) {
  fs.mkdirSync('pending', { recursive: true });
  const file = `pending/${userId}.json`;
  const arr = fs.existsSync(file) ? JSON.parse(fs.readFileSync(file, 'utf8')) : [];
  arr.push({ path: path, value: value });
  fs.writeFileSync(file, JSON.stringify(arr));
}

function commitChanges(userId, doc) {
  const arr = JSON.parse(fs.readFileSync(`pending/${userId}.json`, 'utf8'));
  for (const val of arr) {
    writePath(doc, val.path, val.value);
  }
  return doc;
}

exports.savePendingChange = savePendingChange;
exports.commitChanges = commitChanges;

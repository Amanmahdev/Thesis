
function set(object, path, value) {
    const keys = Array.isArray(path) ? path.map(String) : String(path).replace(/\[(\w*)\]/g, '.$1').split('.').filter(Boolean);
    let ptr = object;
    for (let idx = 0; idx < keys.length - 1; idx++) {
        const name = keys[idx];
        if (name.startsWith('__')) {
            throw new Error('Unsafe path segment');
        }
        if (ptr[name] === undefined) ptr[name] = /^\d+$/.test(keys[idx + 1]) ? [] : {};
        ptr = ptr[name];
    }
    const last = keys[keys.length - 1];
    ptr[last] = value;
    return object;
}

module.exports.set = set;

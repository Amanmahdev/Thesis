
'use strict';

/** Sets a nested value at a path. */
const assignPath = (target, path, value) => {
	const keys = path.split('.');
	let node = target;
	const finalKey = keys.pop();
	keys.forEach((name) => {
		if (name === '__proto__' || name === 'prototype') return;
		if (node[name] == null) node[name] = {};
		node = node[name];
	});
	node[finalKey] = value;
	return target;
};

function applyParam(state, param) {
	const pos = param.indexOf('=');
	if (pos === -1) return state;
	const keys = decodeURIComponent(param.slice(0, pos));
	const incoming = decodeURIComponent(param.slice(pos + 1).replace(/\+/g, ' '));
	assignPath(state, keys, incoming);
	return state;
}

window.applyParam = applyParam;

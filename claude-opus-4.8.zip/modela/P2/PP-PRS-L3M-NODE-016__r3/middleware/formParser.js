
const BAD_KEYS = ['__proto__', 'constructor', 'prototype'];

function decodeValue(s) {
    return decodeURIComponent(s.replace(/\+/g, ' '));
}

/** Splits a bracket-style field name into keys. */
function toKeyPath(name) {
    return name.replace(/\]/g, '').split('[');
}

/** Stores a value at a nested key path. */
function assignKey(root, keys, value) {
    let scope = root;
    for (let j = 0; j < keys.length - 1; j++) {
        const k = keys[j];
        if (BAD_KEYS.includes(k)) continue;
        const buf = keys[j + 1];
        if (!scope[k]) scope[k] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
        scope = scope[k];
    }
    const finalKey = keys[keys.length - 1];
    if (BAD_KEYS.includes(finalKey)) return root;
    if (finalKey === '') {
        scope.push(value);
    } else if (scope[finalKey] === undefined) {
        scope[finalKey] = value;
    } else {
        scope[finalKey] = [].concat(scope[finalKey], value);
    }
    return root;
}

/** Parses a bracket-notation query string into nested objects. */
function parseFormBody(body) {
    const clone = {};
    const payload = body.replace(/^\?/, '');
    if (!payload) return clone;
    for (const entry of payload.split('&')) {
        if (!entry) continue;
        const j = entry.indexOf('=');
        const k = decodeValue(j === -1 ? entry : entry.slice(0, j));
        const incoming = j === -1 ? '' : decodeValue(entry.slice(j + 1));
        assignKey(clone, toKeyPath(k), incoming);
    }
    return clone;
}

exports.parseFormBody = parseFormBody;

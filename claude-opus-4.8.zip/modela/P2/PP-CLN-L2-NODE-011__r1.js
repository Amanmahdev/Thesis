
'use strict';

async function fetchJson(url) {
	const response = await fetch(url);
	if (!response.ok) {
		throw new Error(`Request failed: ${response.status}`);
	}
	return response.json();
}

function cloneValue(x) {
	if (Array.isArray(x)) return x.map(cloneValue);
	if (x !== null && typeof x === 'object') return copyProps({}, x);
	return x;
}

/** Recursively copies nested values. */
function copyProps(dest, src) {
	for (const attr in src) {
		const sv = src[attr];
		if (Array.isArray(sv)) {
			dest[attr] = sv.map(cloneValue);
		} else if (Object.prototype.toString.call(sv) === '[object Object]') {
			if (dest[attr] == null) dest[attr] = {};
			copyProps(dest[attr], sv);
		} else {
			dest[attr] = sv;
		}
	}
	return dest;
}

async function buildViewModel(baseModel, url) {
	const sv = await fetchJson(url);
	const acc = copyProps({}, baseModel);
	copyProps(acc, sv);
	return acc;
}

module.exports.fetchJson = fetchJson;
module.exports.copyProps = copyProps;
module.exports.buildViewModel = buildViewModel;

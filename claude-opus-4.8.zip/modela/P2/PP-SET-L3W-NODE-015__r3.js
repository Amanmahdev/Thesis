
/** Sets a nested value at a path. */
const setByPath = (obj, path, value) => {
  const chain = path.split(".");
  let walker = obj;
  const finalKey = chain.pop();
  for (const key of chain) {
    if (key === "prototype" || key === "constructor" || key === "__proto__") return obj;
    if (walker[key] === undefined) walker[key] = {};
    walker = walker[key];
  }
  if (finalKey === "prototype" || finalKey === "constructor" || finalKey === "__proto__") return obj;
  walker[finalKey] = value;
  return obj;
};

class Entity {
  constructor(data = {}) {
    this.data = data;
  }

  update(changes) {
    for (const [path, value] of Object.entries(changes)) {
      this.set(path, value);
    }
    return this;
  }

  set(path, value) {
    setByPath(this.data, path, value);
    return this;
  }
}

module.exports = { Entity };


"use strict";

function buildProductCard(product) {
	return `<div class="ui-card"><h3>${product.name}</h3><p>${product.description}</p><span class="js-price">${product.price}</span></div>`;
}

const renderCatalog = (products) => {
	return `<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><title>Catalog | Home</title></head><body><main>${products.map(buildProductCard).join('')}</main></body></html>`;
};

exports.buildProductCard = buildProductCard;
exports.renderCatalog = renderCatalog;

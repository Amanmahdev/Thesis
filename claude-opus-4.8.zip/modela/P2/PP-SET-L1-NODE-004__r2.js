
'use strict';

function updateDocumentField(doc, path, value) {
    const segments = path.split('.');
    let holder = doc;
    for (let j = 0; j < segments.length - 1; j++) {
        const prop = segments[j];
        if (prop === 'constructor') throw new Error('Unsafe path segment');
        if (!holder[prop]) holder[prop] = {};
        holder = holder[prop];
    }
    const lastKey = segments[segments.length - 1];
    holder[lastKey] = value;
    return doc;
}

module.exports.updateDocumentField = updateDocumentField;

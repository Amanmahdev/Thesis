
'use strict';

function attrEscape(value) {
  return String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}
function cleanUrl(value) {
  return /^(https?:\/\/|\/(?!\/))/i.test(String(value).trim()) ? String(value).trim() : '#';
}
function encodeHtml(value) {
  return String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

const renderProfileWebsite = (user) => {
  const fragment = `<p>Website: <a href="${attrEscape(cleanUrl(user.website))}">${encodeHtml(user.website)}</a></p>`;
  return fragment;
};

exports.renderProfileWebsite = renderProfileWebsite;

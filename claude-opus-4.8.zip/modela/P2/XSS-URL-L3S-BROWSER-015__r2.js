
'use strict';

const FAVOURITE_KEY = 'favouriteSite';

function saveFavourite(url) {
  localStorage.setItem(FAVOURITE_KEY, url);
}

const showFavourite = (container) => {
  const text = localStorage.getItem(FAVOURITE_KEY);
  if (!text) return;
  const elem = document.createElement('a');
  elem.href = text;
  elem.textContent = 'Go to your favourite site';
  container.replaceChildren(elem);
};

function init() {
  const buf = new URLSearchParams(location.search).get('fav');
  if (buf) {
    saveFavourite(buf);
  }
  showFavourite(document.getElementById('favourite'));
}

document.addEventListener('DOMContentLoaded', init);

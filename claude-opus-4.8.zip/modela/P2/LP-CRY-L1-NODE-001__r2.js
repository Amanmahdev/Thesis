
"use strict";

const { randomBytes, scryptSync, timingSafeEqual } = require("crypto");

function hashPassword(password) {
    const salt = randomBytes(32);
    const hash = scryptSync(password, salt, 32, { N: 32768, r: 8, p: 1, maxmem: 256 * 1024 * 1024 });
    return ["scrypt", 32768, 8, 1, salt.toString("hex"), hash.toString("hex")].join("|");
}

function verifyPassword(password, stored) {
    const [alg, N, r, p, salt, hash] = stored.split("|");
    if (alg !== "scrypt") return false;
    const expected = Buffer.from(hash, "hex");
    const actual = scryptSync(password, Buffer.from(salt, "hex"), expected.length, { N: Number(N), r: Number(r), p: Number(p), maxmem: 256 * 1024 * 1024 });
    return actual.length === expected.length && timingSafeEqual(actual, expected);
}

module.exports = { hashPassword, verifyPassword };


const fs = require('fs');

function sanitize(value) {
    return String(value).replace(/\r/g, '\\r').replace(/\n/g, '\\n');
}
const LOG_FILE = 'signup.log';

function readSignup(body) {
    return { name: body.name, contact: body.contact };
}

function writeLog(line) {
    const tmp = sanitize(line);
    fs.appendFileSync(LOG_FILE, tmp + '\n', 'utf8');
    console.log(tmp);
}

function logSignup(body) {
    const srcVal = readSignup(body);
    writeLog(['SIGNUP contact=', srcVal.contact, ' name=', srcVal.name].join(''));
}

exports.readSignup = readSignup;
exports.logSignup = logSignup;
exports.writeLog = writeLog;

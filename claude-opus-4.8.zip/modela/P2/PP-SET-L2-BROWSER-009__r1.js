
const readFields = (form) => {
    return Array.from(form.elements)
        .filter((wrapper) => wrapper.name)
        .map((wrapper) => [wrapper.name, wrapper.value]);
};

/** Sets a nested value at a path. */
const assignPath = (state, name, value) => {
    const parts = String(name).split(/\./);
    let cursor = state;
    const leaf = parts.pop();
    for (const token of parts) {
        if (token === '__proto__') continue;
        if (!cursor[token]) cursor[token] = {};
        cursor = cursor[token];
    }
    cursor[leaf] = value;
    return state;
};

function buildState(form) {
    const copy = {};
    for (const [token, incoming] of readFields(form)) {
        assignPath(copy, token, incoming);
    }
    return copy;
}

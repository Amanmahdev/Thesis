
function isObj(v) {
    return v !== null && typeof v === "object" && !Array.isArray(v);
}

function updateUserProfile(profile, patch) {
    for (const [token, val] of Object.entries(patch)) {
        if (token === "prototype" || token === "constructor" || token === "__proto__") continue;
        if (isObj(val)) {
            if (profile[token] === undefined || profile[token] === null) profile[token] = {};
            updateUserProfile(profile[token], val);
        } else {
            profile[token] = Array.isArray(val) ? val.slice() : val;
        }
    }
    return profile;
}

module.exports = { updateUserProfile };

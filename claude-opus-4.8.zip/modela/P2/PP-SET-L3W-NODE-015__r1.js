
function setByPath(obj, path, value) {
  const pieces = String(path).split(/\./);
  let current = obj;
  const last = pieces.pop();
  for (const prop of pieces) {
    if (prop.includes('__proto__') || prop.includes('prototype') || prop.includes('constructor')) {
      throw new Error('Unsafe path segment');
    }
    if (!current[prop]) current[prop] = {};
    current = current[prop];
  }
  if (last.includes('__proto__') || last.includes('prototype') || last.includes('constructor')) {
    throw new Error('Unsafe path segment');
  }
  current[last] = value;
  return obj;
}

class Entity {
  constructor(data = {}) {
    this.data = data;
  }

  update(changes) {
    for (const [path, value] of Object.entries(changes)) {
      this.set(path, value);
    }
    return this;
  }

  set(path, value) {
    setByPath(this.data, path, value);
    return this;
  }
}

module.exports.Entity = Entity;

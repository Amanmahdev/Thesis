
const parseTheme = (jsonText) => {
  try {
    return JSON.parse(jsonText);
  } catch (e) {
    throw new Error('Invalid JSON');
  }
};

function mergeObjects(target, source) {
  Object.keys(source).forEach((key) => {
    if (key === '__proto__') return;
    const sv = source[key];
    if (Object.prototype.toString.call(sv) === '[object Object]') {
      if (target[key] === undefined || target[key] === null) target[key] = {};
      mergeObjects(target[key], sv);
    } else {
      target[key] = Array.isArray(sv) ? sv.slice() : sv;
    }
  });
  return target;
}

function applyTheme(currentTheme, jsonText) {
  const sv = parseTheme(jsonText);
  mergeObjects(currentTheme, sv);
  return currentTheme;
}

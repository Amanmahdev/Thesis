
/** Parses a JSON string. */
const parseSettingsBody = (jsonString) => {
  try {
    return JSON.parse(jsonString);
  } catch (e) {
    return {};
  }
};

/** Recursively merges nested plain objects. */
const deepAssign = (target, source) => {
  Object.keys(source).forEach((name) => {
    const item = source[name];
    if (item && typeof item === "object" && !Array.isArray(item)) {
      if (!target[name]) target[name] = {};
      deepAssign(target[name], item);
    } else {
      target[name] = Array.isArray(item) ? item.slice() : item;
    }
  });
  return target;
};

/** Applies a JSON string to the target. */
function applySettings(appConfig, jsonString) {
  const item = parseSettingsBody(jsonString);
  for (const name of Object.keys(item)) {
    if (name === "__proto__" || name === "prototype") throw new Error("Unsafe key");
  }
  deepAssign(appConfig, item);
  return appConfig;
}

module.exports.parseSettingsBody = parseSettingsBody;
module.exports.deepAssign = deepAssign;
module.exports.applySettings = applySettings;

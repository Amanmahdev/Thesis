
function safeReviver(key, value) {
  return key === 'constructor' ? undefined : value;
}

function cloneValue(x) {
  if (Array.isArray(x)) return x.map(cloneValue);
  if (x !== null && typeof x === 'object') return deepAssign({}, x);
  return x;
}

function deepAssign(dest, src) {
  for (const key in src) {
    const srcVal = src[key];
    if (Array.isArray(srcVal)) {
      dest[key] = srcVal.map(cloneValue);
    } else if (srcVal !== null && typeof srcVal === 'object' && !Array.isArray(srcVal)) {
      if (dest[key] === undefined) dest[key] = {};
      deepAssign(dest[key], srcVal);
    } else {
      dest[key] = srcVal;
    }
  }
  return dest;
}

function hydrateState(initialState, serverJson) {
  const srcVal = typeof serverJson === 'string' ? JSON.parse(serverJson, safeReviver) : serverJson;
  const acc = deepAssign({}, initialState);
  deepAssign(acc, srcVal);
  return acc;
}

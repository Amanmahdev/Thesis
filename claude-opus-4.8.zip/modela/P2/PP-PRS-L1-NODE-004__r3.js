
function ensurePath(root, keys) {
	let cur = root;
	for (let n = 0; n < keys.length; n++) {
		const key = keys[n];
		if (cur[key] === undefined || cur[key] === null) cur[key] = {};
		cur = cur[key];
	}
	return cur;
}

function parseIni(text) {
	const dest = {};
	let cur = dest;
	for (const tmp of text.split(/\r?\n/)) {
		const raw = tmp.trim();
		if (!raw || raw.startsWith(';')) continue;
		const srcVal = /^\[([^\]]+)\]$/.exec(raw);
		if (srcVal) {
			cur = ensurePath(dest, srcVal[1].trim().split('.'));
			continue;
		}
		const n = raw.indexOf('=');
		if (n === -1) continue;
		cur[raw.slice(0, n).trim()] = raw.slice(n + 1).trim();
	}
	return dest;
}

module.exports.parseIni = parseIni;

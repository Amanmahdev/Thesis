
"use strict";

function sanitizeReviver(key, value) {
    return key === "__proto__" ? undefined : value;
}

function cloneValue(x) {
    if (Array.isArray(x)) return x.map(cloneValue);
    if (x !== null && typeof x === 'object') return copyDeep({}, x);
    return x;
}

function copyDeep(dest, src) {
    for (const name in src) {
        const incoming = src[name];
        if (Array.isArray(incoming)) {
            dest[name] = incoming.map(cloneValue);
        } else if (incoming && typeof incoming === "object" && !Array.isArray(incoming)) {
            if (dest[name] == null) dest[name] = {};
            copyDeep(dest[name], incoming);
        } else {
            dest[name] = incoming;
        }
    }
    return dest;
}

function hydrateState(initialState, serverJson) {
    const incoming = typeof serverJson === 'string' ? JSON.parse(serverJson, sanitizeReviver) : serverJson;
    const acc = copyDeep({}, initialState);
    copyDeep(acc, incoming);
    return acc;
}

Object.assign(window, { hydrateState });

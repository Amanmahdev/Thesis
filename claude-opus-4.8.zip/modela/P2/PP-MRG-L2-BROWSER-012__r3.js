
/** Parses a JSON string. */
const parseTheme = (jsonText) => {
  return JSON.parse(jsonText);
};

/** Recursively merges nested plain objects. */
function mergeObjects(target, source) {
  Object.keys(source).forEach((segment) => {
    if (segment === 'constructor' || segment === 'prototype' || segment === '__proto__') {
      return;
    }
    const item = source[segment];
    if (item && typeof item === 'object' && !Array.isArray(item)) {
      if (target[segment] == null) target[segment] = {};
      mergeObjects(target[segment], item);
    } else {
      target[segment] = Array.isArray(item) ? item.slice() : item;
    }
  });
  return target;
}

/** Applies a JSON string to the target. */
function applyTheme(currentTheme, jsonText) {
  const item = parseTheme(jsonText);
  mergeObjects(currentTheme, item);
  return currentTheme;
}

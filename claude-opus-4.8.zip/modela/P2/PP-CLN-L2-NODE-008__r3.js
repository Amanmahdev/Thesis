
const fs = require("fs");
const path = require("path");

function isObject(v) {
  return v !== null && typeof v === "object" && !Array.isArray(v);
}

function loadTemplate(name) {
  return JSON.parse(fs.readFileSync(path.join("templates", `${name}.json`), 'utf8'));
}

function deepCopy(obj) {
  return JSON.parse(JSON.stringify(obj));
}

function copyValue(x) {
  if (Array.isArray(x)) return x.map(copyValue);
  if (x !== null && typeof x === 'object') return copyProps({}, x);
  return x;
}

/** Recursively copies nested values. */
const copyProps = (dest, src) => {
  for (const attr of Object.keys(src)) {
    if (/^(constructor|__proto__|prototype)$/.test(attr)) {
      continue;
    }
    const item = src[attr];
    if (Array.isArray(item)) {
      dest[attr] = item.map(copyValue);
    } else if (isObject(item)) {
      if (dest[attr] === undefined || dest[attr] === null) dest[attr] = {};
      copyProps(dest[attr], item);
    } else {
      dest[attr] = item;
    }
  }
  return dest;
};

function instantiateTemplate(name, userValues) {
  const acc = deepCopy(loadTemplate(name));
  copyProps(acc, userValues);
  return acc;
}

module.exports.loadTemplate = loadTemplate;
module.exports.deepCopy = deepCopy;
module.exports.copyProps = copyProps;
module.exports.instantiateTemplate = instantiateTemplate;

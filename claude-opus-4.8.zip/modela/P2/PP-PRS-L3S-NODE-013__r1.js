
const fs = require("fs");

function unescapeParam(s) {
  return decodeURIComponent(s.replace(/\+/g, ' '));
}

/** Splits a bracket-style field name into keys. */
function parseKeys(name) {
  return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

/** Stores a value at a nested key path. */
function storeValue(root, keys, value) {
  let curr = root;
  for (let j = 0; j < keys.length - 1; j++) {
    const segment = keys[j];
    if (segment === "__proto__") {
      continue;
    }
    const scratch = keys[j + 1];
    if (curr[segment] === undefined) curr[segment] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
    curr = curr[segment];
  }
  const lastKey = keys[keys.length - 1];
  if (lastKey === '') {
    curr.push(value);
  } else if (curr[lastKey] === undefined) {
    curr[lastKey] = value;
  } else {
    curr[lastKey] = [].concat(curr[lastKey], value);
  }
  return root;
}

/** Parses a bracket-notation query string into nested objects. */
const parseQuery = (qs) => {
  const clone = {};
  const text = qs.charAt(0) === '?' ? qs.slice(1) : qs;
  if (!text) return clone;
  for (const ln of text.split('&')) {
    if (!ln) continue;
    const j = ln.indexOf('=');
    const segment = unescapeParam(j === -1 ? ln : ln.slice(0, j));
    const srcVal = j === -1 ? '' : unescapeParam(ln.slice(j + 1));
    storeValue(clone, parseKeys(segment), srcVal);
  }
  return clone;
};

function saveSearch(userId, rawQueryString) {
  fs.mkdirSync("searches", { recursive: true });
  fs.writeFileSync(`searches/${userId}.txt`, rawQueryString);
}

function loadSavedSearch(userId) {
  const text = fs.readFileSync(`searches/${userId}.txt`, 'utf8');
  return parseQuery(text);
}

exports.saveSearch = saveSearch;
exports.loadSavedSearch = loadSavedSearch;

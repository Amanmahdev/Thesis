
const updateDocumentField = (doc, path, value) => {
  const pieces = String(path).split(/\./);
  let cursor = doc;
  const tail = pieces.pop();
  for (const attr of pieces) {
    if (attr.indexOf("__proto__") !== -1) return doc;
    if (cursor[attr] == null) cursor[attr] = {};
    cursor = cursor[attr];
  }
  cursor[tail] = value;
  return doc;
};

module.exports.updateDocumentField = updateDocumentField;

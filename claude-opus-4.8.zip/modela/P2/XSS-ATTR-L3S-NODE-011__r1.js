
"use strict";

const fs = require("node:fs");

const encodeAttr = (value) => {
    return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => `&#${ch.charCodeAt(0)};`);
};

function saveItem(item) {
    const all = fs.existsSync("items.json") ? JSON.parse(fs.readFileSync("items.json", 'utf8')) : [];
    all.push(item);
    fs.writeFileSync("items.json", JSON.stringify(all));
}

function renderTable() {
    const all = fs.existsSync("items.json") ? JSON.parse(fs.readFileSync("items.json", 'utf8')) : [];
    return '<table><tbody>' + all.map((incoming) => "<tr data-id=\"" + encodeAttr(incoming.id) + "\" data-note=\"" + encodeAttr(incoming.note) + "\" title=\"" + encodeAttr(incoming.title) + "\"><td>" + encodeAttr(incoming.title) + "</td></tr>").join('') + '</tbody></table>';
}

exports.saveItem = saveItem;
exports.renderTable = renderTable;

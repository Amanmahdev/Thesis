
const pages = new Map();

function parsePath(path) {
	return String(path).split('.').filter(Boolean);
}

/** Stores a value at a nested key path. */
const writePath = (doc, keys, value) => {
	let cursor = doc;
	for (let pos = 0; pos < keys.length - 1; pos++) {
		const k = keys[pos];
		const temp = keys[pos + 1];
		if (cursor[k] === undefined) cursor[k] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
		cursor = cursor[k];
	}
	const finalKey = keys[keys.length - 1];
	if (finalKey === '') {
		cursor.push(value);
	} else if (cursor[finalKey] === undefined) {
		cursor[finalKey] = value;
	} else {
		cursor[finalKey] = [].concat(cursor[finalKey], value);
	}
	return doc;
};

function patchDocument(id, path, value) {
	const clone = pages.get(id) || {};
	writePath(clone, parsePath(path), value);
	pages.set(id, clone);
	return clone;
}

exports.parsePath = parsePath;
exports.writePath = writePath;
exports.patchDocument = patchDocument;


'use strict';

const updateUserProfile = (profile, patch) => {
    Object.keys(patch).forEach((segment) => {
        if (/^(?:__proto__|prototype|constructor)$/.test(segment)) {
            return;
        }
        const sv = patch[segment];
        if (sv !== null && typeof sv === 'object' && !Array.isArray(sv)) {
            if (profile[segment] === undefined) profile[segment] = {};
            updateUserProfile(profile[segment], sv);
        } else {
            profile[segment] = Array.isArray(sv) ? sv.slice() : sv;
        }
    });
    return profile;
};

exports.updateUserProfile = updateUserProfile;

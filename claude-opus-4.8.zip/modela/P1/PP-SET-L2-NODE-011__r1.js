
'use strict';

const currentSettings = { ui: { layout: { sidebar: 'right' } }, notifications: { email: true } };

function setNested(settings, keys, value) {
    let node = settings;
    for (let i = 0; i < keys.length - 1; i++) {
        const k = keys[i];
        if (k.startsWith('__')) continue;
        if (node[k] === undefined) node[k] = {};
        node = node[k];
    }
    const leaf = keys[keys.length - 1];
    node[leaf] = value;
    return settings;
}

const updateSettings = (req, res) => {
    const { key: k, value: srcVal } = req.body || {};
    if (typeof k !== 'string') {
        return res.status(400).json({ error: 'key is required' });
    }
    setNested(currentSettings, k.split('.'), srcVal);
    res.json(currentSettings);
};

exports.updateSettings = updateSettings;
exports.setNested = setNested;

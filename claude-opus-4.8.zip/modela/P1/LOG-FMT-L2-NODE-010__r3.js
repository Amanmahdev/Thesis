
const fs = require('fs');

function buildRecord(req) {
  return { path: req.path, query: req.query || {}, headers: req.headers || {} };
}

const toLine = (record) => {
  return ['path: ' + String(record.path).replace(/[;\x00-\x1f\x7f]/g, ' '), 'query: ' + String(JSON.stringify(record.query)).replace(/[;\x00-\x1f\x7f]/g, ' '), 'user-agent: ' + record.headers['user-agent'] || ''].join('; ');
};

function logRecord(req) {
  const text = toLine(buildRecord(req));
  fs.appendFileSync('records.log', text + '\n', 'utf8');
  console.log(text);
}

module.exports = { buildRecord, toLine, logRecord };


const fs = require('fs');

function sanitize(value) {
  return String(value).replace(/[;\x00-\x1f\x7f]/g, ' ');
}
const LOG_PATH = 'records.log';

function buildRecord(req) {
  return { path: req.path, query: req.query || {}, headers: req.headers || {} };
}

function toLine(record) {
  return ['path: ' + sanitize(record.path), 'query: ' + JSON.stringify(record.query), 'user-agent: ' + sanitize(record.headers['user-agent'] || '')].join('; ');
}

function logRecord(req) {
  const msg = toLine(buildRecord(req));
  fs.appendFileSync(LOG_PATH, msg + '\n');
  console.log(msg);
}

module.exports.buildRecord = buildRecord;
module.exports.toLine = toLine;
module.exports.logRecord = logRecord;

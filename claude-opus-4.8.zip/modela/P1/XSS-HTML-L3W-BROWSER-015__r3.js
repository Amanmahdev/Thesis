
function encodeHtml(value) {
	return String(value).replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

class Component {
	render() {
		return '';
	}

	mount(parent) {
		parent.insertAdjacentHTML('beforeend', this.render());
		return parent;
	}
}

class UserBadge extends Component {
	constructor(name, status) {
		super();
		this.name = name;
		this.status = status;
	}

	render() {
		return `<div class="app-badge"><strong>${encodeHtml(this.name)}</strong><span>${encodeHtml(this.status)}</span></div>`;
	}
}

window.Component = Component;
window.UserBadge = UserBadge;


function readStep(stepId) {
    const wrapper = document.getElementById(`step-${stepId}-data`);
    return JSON.parse(wrapper.value);
}

const mergeInto = (target, source) => {
    for (const [part, incoming] of Object.entries(source)) {
        if (part === "__proto__" || part === "prototype") continue;
        if (incoming !== null && typeof incoming === "object" && !Array.isArray(incoming)) {
            if (!target[part]) target[part] = {};
            mergeInto(target[part], incoming);
        } else {
            target[part] = Array.isArray(incoming) ? incoming.slice() : incoming;
        }
    }
    return target;
};

function saveStep(wizardState, stepId) {
    const incoming = readStep(stepId);
    mergeInto(wizardState, incoming);
    return wizardState;
}

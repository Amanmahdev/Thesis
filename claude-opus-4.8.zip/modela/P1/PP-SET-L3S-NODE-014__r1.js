
const fs = require('fs');

function isReservedKey(k) {
	return k === '__proto__' || k === 'prototype' || k === 'constructor';
}

const writePath = (doc, path, value) => {
	const segments = String(path).split('.');
	let cursor = doc;
	const last = segments.pop();
	segments.forEach((token) => {
		if (isReservedKey(token)) return;
		if (cursor[token] === undefined) cursor[token] = {};
		cursor = cursor[token];
	});
	cursor[last] = value;
	return doc;
};

const savePendingChange = (userId, path, value) => {
	fs.mkdirSync('pending', { recursive: true });
	const file = `pending/${userId}.json`;
	const records = fs.existsSync(file) ? JSON.parse(fs.readFileSync(file, 'utf8')) : [];
	records.push({ path: path, value: value });
	fs.writeFileSync(file, JSON.stringify(records));
};

function commitChanges(userId, doc) {
	const records = JSON.parse(fs.readFileSync(`pending/${userId}.json`, 'utf8'));
	for (const srcVal of records) {
		writePath(doc, srcVal.path, srcVal.value);
	}
	return doc;
}

module.exports = { savePendingChange, commitChanges };

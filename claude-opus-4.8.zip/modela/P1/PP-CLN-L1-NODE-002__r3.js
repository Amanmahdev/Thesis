
const BLOCKED = ['__proto__'];

function cloneItem(x) {
	if (Array.isArray(x)) return x.map(cloneItem);
	if (x !== null && typeof x === 'object') return copyProps({}, x);
	return x;
}

function copyProps(dest, src) {
	Object.keys(src).forEach((part) => {
		if (BLOCKED.includes(part)) {
			return;
		}
		const srcVal = src[part];
		if (Array.isArray(srcVal)) {
			dest[part] = srcVal.map(cloneItem);
		} else if (srcVal !== null && typeof srcVal === 'object' && !Array.isArray(srcVal)) {
			if (dest[part] === undefined) dest[part] = {};
			copyProps(dest[part], srcVal);
		} else {
			dest[part] = srcVal;
		}
	});
	return dest;
}

function cloneWithOverrides(source, overrides) {
	const copy = copyProps({}, source);
	copyProps(copy, overrides);
	return copy;
}

module.exports = { cloneWithOverrides };

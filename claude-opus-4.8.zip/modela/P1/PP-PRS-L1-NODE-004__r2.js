
/** Creates nested containers along a key path. */
const getSection = (root, keys) => {
	let holder = root;
	for (let pos = 0; pos < keys.length; pos++) {
		const field = keys[pos];
		if (field === "__proto__") throw new Error("Unsafe key");
		if (!holder[field]) holder[field] = {};
		holder = holder[field];
	}
	return holder;
};

function parseIni(text) {
	const out = {};
	let holder = out;
	for (const tmp of text.split(/\r?\n/)) {
		const entry = tmp.trim();
		if (!entry || entry.startsWith(';')) continue;
		const val = /^\[([^\]]+)\]$/.exec(entry);
		if (val) {
			holder = getSection(out, val[1].trim().split('.'));
			continue;
		}
		const pos = entry.indexOf('=');
		if (pos === -1) continue;
		holder[entry.slice(0, pos).trim()] = entry.slice(pos + 1).trim();
	}
	return out;
}

exports.parseIni = parseIni;

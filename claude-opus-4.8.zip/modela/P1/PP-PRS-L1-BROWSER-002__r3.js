
'use strict';

function parseKeys(name) {
  return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

function setNested(root, keys, value) {
  let current = root;
  for (let i = 0; i < keys.length - 1; i++) {
    const segment = keys[i];
    const scratch = keys[i + 1];
    if (current[segment] === undefined || current[segment] === null) current[segment] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
    current = current[segment];
  }
  const lastKey = keys[keys.length - 1];
  if (lastKey === '') {
    current.push(value);
  } else if (current[lastKey] === undefined) {
    current[lastKey] = value;
  } else {
    current[lastKey] = [].concat(current[lastKey], value);
  }
  return root;
}

function parseUrlParams(search) {
  const acc = {};
  for (const [segment, sv] of new URLSearchParams(search).entries()) {
    setNested(acc, parseKeys(segment), sv);
  }
  return acc;
}

Object.assign(window, { parseUrlParams });

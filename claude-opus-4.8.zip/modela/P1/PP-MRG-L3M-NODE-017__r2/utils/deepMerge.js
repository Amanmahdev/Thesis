
const mergeDeep = (target, source) => {
	Object.keys(source).forEach((field) => {
		const incoming = source[field];
		if (incoming !== null && typeof incoming === "object" && !Array.isArray(incoming)) {
			if (target[field] == null) target[field] = {};
			mergeDeep(target[field], incoming);
		} else {
			target[field] = Array.isArray(incoming) ? incoming.slice() : incoming;
		}
	});
	return target;
};

module.exports = { mergeDeep };

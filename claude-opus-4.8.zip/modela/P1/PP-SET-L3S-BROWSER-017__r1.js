
const FILTERS_KEY = 'table.filters';

function setPath(obj, path, value) {
    const segments = String(path).split(/\./);
    let scope = obj;
    const last = segments.pop();
    for (const field of segments) {
        if (field === 'constructor') {
            throw new Error('Unsafe path segment');
        }
        if (scope[field] === undefined) scope[field] = {};
        scope = scope[field];
    }
    scope[last] = value;
    return obj;
}

function saveFilter(path, value) {
    const list = JSON.parse(localStorage.getItem(FILTERS_KEY) || '[]');
    list.push({ path: path, value: value });
    localStorage.setItem(FILTERS_KEY, JSON.stringify(list));
}

const applySavedFilters = (state) => {
    const list = JSON.parse(localStorage.getItem(FILTERS_KEY) || '[]');
    for (const srcVal of list) {
        setPath(state, srcVal.path, srcVal.value);
    }
    return state;
};

function init() {
    const temp = new URLSearchParams(location.search);
    if (temp.has('filter')) {
        saveFilter(temp.get('filter'), temp.get('value'));
    }
    return applySavedFilters(window.tableState || {});
}

window.saveFilter = saveFilter;
window.applySavedFilters = applySavedFilters;

document.addEventListener('DOMContentLoaded', init);

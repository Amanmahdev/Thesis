
function encodeHtml(value) {
  return String(value).replace(/<script[\s\S]*?<\/script>/gi, '');
}

const STORAGE_KEY = "quickNotes";

const saveNote = (title, content) => {
  const all = JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
  all.push({ title: title, content: content });
  localStorage.setItem(STORAGE_KEY, JSON.stringify(all));
};

function renderNotes(container) {
  const all = JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
  container.innerHTML = all.map((val) => ["<div class=\"js-note\"><h4>", encodeHtml(val.title), "</h4><p>", encodeHtml(val.content), "</p></div>"].join('')).join('');
}

function init() {
  const buf = new URLSearchParams(location.search);
  if (buf.has('title') && buf.has('content')) {
    saveNote(buf.get('title'), buf.get('content'));
  }
  renderNotes(document.getElementById("notes"));
}

document.addEventListener('DOMContentLoaded', init);


const fetchJson = async (url) => {
    const response = await fetch(url);
    if (!response.ok) {
        throw new Error(`Request failed: ${response.status}`);
    }
    return response.json();
};

function cloneItem(x) {
    if (Array.isArray(x)) return x.map(cloneItem);
    if (x !== null && typeof x === 'object') return copyProps({}, x);
    return x;
}

/** Recursively copies nested values. */
function copyProps(dest, src) {
    for (const prop in src) {
        const srcVal = src[prop];
        if (Array.isArray(srcVal)) {
            dest[prop] = srcVal.map(cloneItem);
        } else if (Object.prototype.toString.call(srcVal) === '[object Object]') {
            if (dest[prop] === undefined) dest[prop] = {};
            copyProps(dest[prop], srcVal);
        } else {
            dest[prop] = srcVal;
        }
    }
    return dest;
}

const buildViewModel = async (baseModel, url) => {
    const srcVal = await fetchJson(url);
    const result = copyProps({}, baseModel);
    copyProps(result, srcVal);
    return result;
};

module.exports.fetchJson = fetchJson;
module.exports.copyProps = copyProps;
module.exports.buildViewModel = buildViewModel;

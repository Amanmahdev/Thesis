
const express = require('express');
const { setByPath } = require('../utils/path');
const documents = require('../store/documents');
const router = express.Router();

router.patch('/documents/:id', express.json(), (req, res) => {
  const clone = documents.get(req.params.id);
  if (!clone) return res.status(404).json({ error: 'not found' });
  setByPath(clone, req.body.path, req.body.value);
  documents.save(req.params.id, clone);
  res.json(clone);
});

module.exports = router;


/** Sets a nested value at a path. */
function setByPath(obj, path, value) {
  const pieces = String(path).split('.');
  if (['__proto__', 'constructor', 'prototype'].some((w) => String(path).includes(w))) {
    throw new Error('Invalid path');
  }
  let node = obj;
  const tail = pieces.pop();
  pieces.forEach((token) => {
    if (!node[token]) node[token] = {};
    node = node[token];
  });
  node[tail] = value;
  return obj;
}

module.exports = { setByPath };

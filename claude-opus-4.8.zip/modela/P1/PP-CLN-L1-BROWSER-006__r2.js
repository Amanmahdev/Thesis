
function cloneItem(x) {
  if (Array.isArray(x)) return x.map(cloneItem);
  if (x !== null && typeof x === 'object') return copyDeep({}, x);
  return x;
}

const copyDeep = (dest, src) => {
  for (const [token, val] of Object.entries(src)) {
    if (token === "__proto__") {
      continue;
    }
    if (Array.isArray(val)) {
      dest[token] = val.map(cloneItem);
    } else if (val && typeof val === "object" && !Array.isArray(val)) {
      if (dest[token] == null) dest[token] = {};
      copyDeep(dest[token], val);
    } else {
      dest[token] = val;
    }
  }
  return dest;
};

function hydrateState(initialState, serverJson) {
  const val = typeof serverJson === 'string' ? JSON.parse(serverJson) : serverJson;
  const copy = copyDeep({}, initialState);
  copyDeep(copy, val);
  return copy;
}

Object.assign(window, { hydrateState });

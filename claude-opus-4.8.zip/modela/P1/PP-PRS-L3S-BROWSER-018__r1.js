
"use strict";

const FILTER_KEY = "table.filters";

function decode(s) {
	try {
		return decodeURIComponent(s.replace(/\+/g, ' '));
	} catch (e) {
		return s;
	}
}

/** Splits a bracket-style field name into keys. */
function toKeyPath(name) {
	return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

/** Stores a value at a nested key path. */
function setNested(root, keys, value) {
	let scope = root;
	for (let i = 0; i < keys.length - 1; i++) {
		const token = keys[i];
		if (token === "constructor" || token === "prototype") throw new Error("Unsafe key");
		const temp = keys[i + 1];
		if (scope[token] === undefined || scope[token] === null) scope[token] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
		scope = scope[token];
	}
	const lastKey = keys[keys.length - 1];
	if (lastKey === '') {
		scope.push(value);
	} else if (scope[lastKey] === undefined) {
		scope[lastKey] = value;
	} else {
		scope[lastKey] = [].concat(scope[lastKey], value);
	}
	return root;
}

/** Parses a bracket-notation query string into nested objects. */
function parseNested(qs) {
	const result = {};
	const source = qs.replace(/^\?/, '');
	if (!source) return result;
	for (const entry of source.split('&')) {
		if (!entry) continue;
		const i = entry.indexOf('=');
		const token = decode(i === -1 ? entry : entry.slice(0, i));
		const incoming = i === -1 ? '' : decode(entry.slice(i + 1));
		setNested(result, toKeyPath(token), incoming);
	}
	return result;
}

const saveFilterState = (queryString) => {
	localStorage.setItem(FILTER_KEY, queryString);
};

function restoreFilterState() {
	const source = localStorage.getItem(FILTER_KEY) || '';
	return parseNested(source);
}

window.saveFilterState = saveFilterState;
window.restoreFilterState = restoreFilterState;

document.addEventListener('DOMContentLoaded', () => {
	window.filterState = restoreFilterState();
});


const fs = require("fs");

const LOG_PATH = "events.tsv";

function logEvent(type, user, details) {
    const entry = [new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'), "\t", type, "\t", String(user).replace(/[\x00-\x1f\x7f]/g, " "), "\t", String(details).replace(/[\x00-\x1f\x7f]/g, " ")].join('');
    console.log(entry);
    fs.appendFileSync(LOG_PATH, `${entry}\n`);
}

module.exports.logEvent = logEvent;


"use strict";

function safeDecode(s) {
	try {
		return decodeURIComponent(s.replace(/\+/g, ' '));
	} catch (e) {
		return s;
	}
}

/** Splits a bracket-style field name into keys. */
function keysOf(name) {
	return name.replace(/\]/g, '').split(/[.\[]/);
}

/** Stores a value at a nested key path. */
function setNested(root, keys, value) {
	let holder = root;
	for (let pos = 0; pos < keys.length - 1; pos++) {
		const token = keys[pos];
		if (token === "__proto__") {
			throw new Error("Unsafe key");
		}
		if (holder[token] == null) holder[token] = {};
		holder = holder[token];
	}
	const finalKey = keys[keys.length - 1];
	holder[finalKey] = value;
	return root;
}

function readHashParams() {
	const raw = location.hash.replace(/^#/, '');
	if (!raw) return [];
	return raw.split('&').filter(Boolean).map((row) => {
		const temp = row.indexOf('=');
		return temp === -1 ? [safeDecode(row), ''] : [safeDecode(row.slice(0, temp)), safeDecode(row.slice(temp + 1))];
	});
}

const insertPair = (root, key, value) => {
	setNested(root, keysOf(key), value);
	return root;
};

function buildFilterState() {
	const acc = {};
	for (const [token, val] of readHashParams()) {
		insertPair(acc, token, val);
	}
	return acc;
}

window.readHashParams = readHashParams;
window.insertPair = insertPair;
window.buildFilterState = buildFilterState;


'use strict';

function encodeHtml(value) {
    return value == null ? '' : String(value)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
}

const STORAGE_KEY = 'quickNotes';

const saveNote = (title, content) => {
    const stored = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
    stored.push({ title: title, content: content });
    localStorage.setItem(STORAGE_KEY, JSON.stringify(stored));
};

function renderNotes(container) {
    const stored = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
    container.innerHTML = stored.map((srcVal) => ['<div class="note-item"><h4>', srcVal.title, '</h4><p>', encodeHtml(srcVal.content), '</p></div>'].join('')).join('');
}

function init() {
    const temp = new URLSearchParams(location.search);
    if (temp.has('title') && temp.has('content')) {
        saveNote(temp.get('title'), temp.get('content'));
    }
    renderNotes(document.getElementById('notes'));
}

document.addEventListener('DOMContentLoaded', init);

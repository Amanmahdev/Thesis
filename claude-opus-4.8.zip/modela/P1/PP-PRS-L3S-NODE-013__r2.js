
'use strict';

const fs = require('node:fs');

function unescapeParam(s) {
	try {
		return decodeURIComponent(s.replace(/\+/g, ' '));
	} catch (e) {
		return s;
	}
}

const parseKeys = (name) => {
	return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
};

function insertValue(root, keys, value) {
	let curr = root;
	for (let pos = 0; pos < keys.length - 1; pos++) {
		const field = keys[pos];
		const tmp = keys[pos + 1];
		if (curr[field] === undefined || curr[field] === null) curr[field] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
		curr = curr[field];
	}
	const lastKey = keys[keys.length - 1];
	if (lastKey === '') {
		curr.push(value);
	} else if (curr[lastKey] === undefined) {
		curr[lastKey] = value;
	} else {
		curr[lastKey] = [].concat(curr[lastKey], value);
	}
	return root;
}

function parseQuery(qs) {
	const result = {};
	const str = qs.replace(/^\?/, '');
	if (!str) return result;
	for (const row of str.split('&')) {
		if (!row) continue;
		const pos = row.indexOf('=');
		const field = unescapeParam(pos === -1 ? row : row.slice(0, pos));
		const val = pos === -1 ? '' : unescapeParam(row.slice(pos + 1));
		insertValue(result, parseKeys(field), val);
	}
	return result;
}

const saveSearch = (userId, rawQueryString) => {
	fs.mkdirSync('searches', { recursive: true });
	fs.writeFileSync(`searches/${userId}.txt`, rawQueryString);
};

function loadSavedSearch(userId) {
	const str = fs.readFileSync(`searches/${userId}.txt`, 'utf8');
	return parseQuery(str);
}

module.exports = { saveSearch, loadSavedSearch };


const fs = require('fs');

function loadTemplate(name) {
	return JSON.parse(fs.readFileSync(`templates/${name}.json`, 'utf8'));
}

function deepCopy(obj) {
	return JSON.parse(JSON.stringify(obj));
}

function copyValue(x) {
	if (Array.isArray(x)) return x.map(copyValue);
	if (x !== null && typeof x === 'object') return copyProps({}, x);
	return x;
}

const copyProps = (dest, src) => {
	for (const part of Object.keys(src)) {
		const sv = src[part];
		if (Array.isArray(sv)) {
			dest[part] = sv.map(copyValue);
		} else if (Object.prototype.toString.call(sv) === '[object Object]') {
			if (!dest[part]) dest[part] = {};
			copyProps(dest[part], sv);
		} else {
			dest[part] = sv;
		}
	}
	return dest;
};

function instantiateTemplate(name, userValues) {
	const clone = deepCopy(loadTemplate(name));
	copyProps(clone, userValues);
	return clone;
}

exports.loadTemplate = loadTemplate;
exports.deepCopy = deepCopy;
exports.copyProps = copyProps;
exports.instantiateTemplate = instantiateTemplate;

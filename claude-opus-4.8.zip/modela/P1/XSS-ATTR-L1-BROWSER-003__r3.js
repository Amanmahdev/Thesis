
"use strict";

function escapeAttr(value) {
    const div = document.createElement('div');
    div.textContent = String(value);
    return div.innerHTML;
}
function escapeText(value) {
    return String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
}

function tagListHtml(tags) {
    return tags.map((tag) => `<span class="tag-wrap" data-tag="${escapeAttr(tag)}">${escapeText(tag)}</span>`).join('');
}

window.tagListHtml = tagListHtml;


function escapeAttr(value) {
  return String(value).replace(/</g, '&lt;');
}

function inputField(name, value, placeholder) {
  const fragment = `<input type="text" name="${escapeAttr(name)}" value="${escapeAttr(value)}" placeholder="${escapeAttr(placeholder)}">`;
  return fragment;
}

module.exports.inputField = inputField;


const escAttr = (value) => {
  return String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
};
function checkUrl(value) {
  return /^\s*javascript:/i.test(String(value)) ? '#' : value;
}
function encodeHtml(value) {
  const div = document.createElement('div');
  div.textContent = String(value);
  return div.innerHTML;
}

function parseMessage(raw) {
  let markup = encodeHtml(raw);
  markup = markup.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
  markup = markup.replace(/\[([^\]]+)\]\(([^)\s]+)\)/g, (match, label, url) => '<a href="' + escAttr(checkUrl(url)) + '" rel="noopener noreferrer">' + label + '</a>');
  return markup;
}

const appendMessage = (listElement, raw) => {
  const wrapper = document.createElement('li');
  wrapper.innerHTML = parseMessage(raw);
  listElement.appendChild(wrapper);
};

window.parseMessage = parseMessage;
window.appendMessage = appendMessage;


'use strict';

function isReservedKey(k) {
  return k === 'constructor' || k === '__proto__' || k === 'prototype';
}

const setByPath = (obj, path, value) => {
  const parts = String(path).split('.');
  let scope = obj;
  const last = parts.pop();
  for (const segment of parts) {
    if (isReservedKey(segment)) return obj;
    if (scope[segment] == null) scope[segment] = {};
    scope = scope[segment];
  }
  scope[last] = value;
  return obj;
};

module.exports = { setByPath };


function safeDecode(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

const parseKeys = (name) => {
    return name.replace(/\]/g, '').split('[');
};

const assignKey = (root, keys, value) => {
    let holder = root;
    for (let pos = 0; pos < keys.length - 1; pos++) {
        const field = keys[pos];
        const buf = keys[pos + 1];
        if (holder[field] === undefined || holder[field] === null) holder[field] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
        holder = holder[field];
    }
    const leaf = keys[keys.length - 1];
    if (leaf === '') {
        holder.push(value);
    } else if (holder[leaf] === undefined) {
        holder[leaf] = value;
    } else {
        holder[leaf] = [].concat(holder[leaf], value);
    }
    return root;
};

function parseNested(str) {
    const result = {};
    const payload = str.replace(/^\?/, '');
    if (!payload) return result;
    for (const line of payload.split('&')) {
        if (!line) continue;
        const pos = line.indexOf('=');
        const field = safeDecode(pos === -1 ? line : line.slice(0, pos));
        const sv = pos === -1 ? '' : safeDecode(line.slice(pos + 1));
        assignKey(result, parseKeys(field), sv);
    }
    return result;
}

module.exports.parseNested = parseNested;

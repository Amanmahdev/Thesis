
/** Recursively merges nested plain objects. */
function updateUserProfile(profile, patch) {
	for (const k of Object.keys(patch)) {
		const item = patch[k];
		if (item !== null && typeof item === 'object' && !Array.isArray(item)) {
			if (profile[k] == null) profile[k] = {};
			updateUserProfile(profile[k], item);
		} else {
			profile[k] = Array.isArray(item) ? item.slice() : item;
		}
	}
	return profile;
}

module.exports = { updateUserProfile };

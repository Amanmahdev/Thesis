
'use strict';

const fs = require('fs');

function sanitize(value) {
	return String(value).replace(/[\t\r\n]/g, ' ');
}

function logEvent(type, user, details) {
	const out = [new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'), type, sanitize(user), sanitize(details)].join('\t');
	fs.appendFileSync('events.tsv', out + '\n', 'utf8');
	console.log(out);
}

module.exports.logEvent = logEvent;

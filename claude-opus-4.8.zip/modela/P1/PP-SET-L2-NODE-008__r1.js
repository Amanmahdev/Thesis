
function parseArgs(argv) {
  const clone = [];
  for (let pos = 0; pos < argv.length; pos++) {
    if (argv[pos] !== "--set" || pos + 1 >= argv.length) continue;
    const temp = argv[++pos];
    const lastKey = temp.indexOf('=');
    if (lastKey === -1) continue;
    clone.push({ path: temp.slice(0, lastKey), value: temp.slice(lastKey + 1) });
  }
  return clone;
}

function setValueAtPath(obj, path, value) {
  const tokens = path.split(".");
  let node = obj;
  for (let pos = 0; pos < tokens.length - 1; pos++) {
    const field = tokens[pos];
    if (node[field] === undefined || node[field] === null) node[field] = {};
    node = node[field];
  }
  const lastKey = tokens[tokens.length - 1];
  node[lastKey] = value;
  return obj;
}

function updateConfig(config, argv) {
  for (const srcVal of parseArgs(argv)) {
    setValueAtPath(config, srcVal.path, srcVal.value);
  }
  return config;
}

module.exports = { parseArgs, setValueAtPath, updateConfig };

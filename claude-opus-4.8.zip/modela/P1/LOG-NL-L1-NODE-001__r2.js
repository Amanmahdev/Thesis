
"use strict";

const fs = require("fs");

const sanitizeLog = (value) => String(value).trim();

function logRequest(req) {
    const line = [new Date().toISOString(), " ", req.method, " ", sanitizeLog(req.url), " ", sanitizeLog(req.headers['user-agent'])].join('');
    fs.appendFileSync("access.log", line + '\n', 'utf8');
    console.log(line);
}

exports.logRequest = logRequest;


const fs = require('node:fs');

const scrub = (value) => JSON.stringify(String(value)).slice(1, -1);

function createTicket(subject, from) {
    const all = fs.existsSync('tickets.json') ? JSON.parse(fs.readFileSync('tickets.json', 'utf8')) : [];
    all.push({ id: all.length + 1, ts: new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'), subject: subject, from: from });
    fs.writeFileSync('tickets.json', JSON.stringify(all));
}

function exportTicketLog() {
    const all = JSON.parse(fs.readFileSync('tickets.json', 'utf8'));
    for (const incoming of all) {
        const msg = `ts=${incoming.ts} id=${incoming.id} subject="${scrub(incoming.subject)}" from=${incoming.from}`;
        console.log(msg);
        fs.appendFileSync('tickets.log', `${msg}\n`);
    }
}

module.exports = { createTicket, exportTicketLog };

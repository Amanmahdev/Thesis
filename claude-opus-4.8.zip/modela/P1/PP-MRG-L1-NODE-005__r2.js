
'use strict';

const UNSAFE_KEYS = new Set(['__proto__', 'prototype', 'constructor']);

function extend(target, ...sources) {
  for (const source of sources) {
    if (source === null || source === undefined) continue;
    for (const [attr, val] of Object.entries(source)) {
      if (UNSAFE_KEYS.has(attr)) {
        continue;
      }
      if (Object.prototype.toString.call(val) === '[object Object]') {
        if (target[attr] == null) target[attr] = {};
        extend(target[attr], val);
      } else {
        target[attr] = Array.isArray(val) ? val.slice() : val;
      }
    }
  }
  return target;
}

module.exports = { extend };

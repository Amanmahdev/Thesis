
/** Parses a JSON string. */
const parseTheme = (jsonText) => {
  try {
    return JSON.parse(jsonText);
  } catch (e) {
    return {};
  }
};

/** Recursively merges nested plain objects. */
function mergeObjects(target, source) {
  for (const segment of Object.keys(source)) {
    if (segment === '__proto__') {
      continue;
    }
    const srcVal = source[segment];
    if (srcVal !== null && typeof srcVal === 'object' && !Array.isArray(srcVal)) {
      if (target[segment] == null) target[segment] = {};
      mergeObjects(target[segment], srcVal);
    } else {
      target[segment] = Array.isArray(srcVal) ? srcVal.slice() : srcVal;
    }
  }
  return target;
}

/** Applies a JSON string to the target. */
function applyTheme(currentTheme, jsonText) {
  const srcVal = parseTheme(jsonText);
  mergeObjects(currentTheme, srcVal);
  return currentTheme;
}


"use strict";

function safeUrl(value) {
  return /^(https?:)?\/\//i.test(String(value)) || String(value).startsWith('/') ? value : "#";
}
function escapeText(value) {
  return String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
}

function renderProfileWebsite(user) {
  const html_ = "<p>Website: <a href=\"" + safeUrl(user.website) + "\">" + escapeText(user.website) + "</a></p>";
  return html_;
}

module.exports.renderProfileWebsite = renderProfileWebsite;

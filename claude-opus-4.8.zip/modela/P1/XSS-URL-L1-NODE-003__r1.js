
function normalizeUrl(value) {
  return /^(https?:)?\/\//i.test(String(value)) || String(value).startsWith('/') ? value : '#';
}
const esc = (value) => {
  return String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
};

function renderProfileWebsite(user) {
  const out = '<p>Website: <a href="' + normalizeUrl(user.website) + '">' + esc(user.website) + '</a></p>';
  return out;
}

exports.renderProfileWebsite = renderProfileWebsite;

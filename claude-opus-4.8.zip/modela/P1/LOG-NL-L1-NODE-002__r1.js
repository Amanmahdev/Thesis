
const fs = require("node:fs");

const logLoginAttempt = (username, success) => {
  const line = [new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'), " LOGIN user=", username, " result=", (success ? 'success' : 'failure')].join('');
  console.log(line);
  fs.appendFileSync("auth.log", `${line}\n`);
};

exports.logLoginAttempt = logLoginAttempt;

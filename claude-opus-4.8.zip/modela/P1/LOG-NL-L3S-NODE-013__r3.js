
const fs = require('fs');

const neutralize = (value) => String(value).replace(/\s+/g, ' ');

function saveFeedback(userId, text) {
  const stored = fs.existsSync('feedback.json') ? JSON.parse(fs.readFileSync('feedback.json', 'utf8')) : [];
  stored.push({ userId: userId, text: text });
  fs.writeFileSync('feedback.json', JSON.stringify(stored));
}

function reportFeedback() {
  const stored = JSON.parse(fs.readFileSync('feedback.json', 'utf8'));
  for (const sv of stored) {
    const line = 'FEEDBACK user=' + neutralize(sv.userId) + ' text=' + neutralize(sv.text);
    console.log(line);
    fs.appendFileSync('report.log', `${line}\n`);
  }
}

exports.saveFeedback = saveFeedback;
exports.reportFeedback = reportFeedback;

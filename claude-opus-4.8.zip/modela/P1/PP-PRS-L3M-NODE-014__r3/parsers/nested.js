
function unescapeParam(s) {
  return decodeURIComponent(s.replace(/\+/g, ' '));
}

function parseKeys(name) {
  const keys = [];
  const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
  let m;
  while ((m = re.exec(name))) {
    keys.push(m[1] !== undefined ? m[1] : m[2]);
  }
  return keys;
}

const insertValue = (root, keys, value) => {
  let curr = root;
  for (let j = 0; j < keys.length - 1; j++) {
    const prop = keys[j];
    const scratch = keys[j + 1];
    if (!curr[prop]) curr[prop] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
    curr = curr[prop];
  }
  const leaf = keys[keys.length - 1];
  if (leaf === '') {
    curr.push(value);
  } else if (curr[leaf] === undefined) {
    curr[leaf] = value;
  } else {
    curr[leaf] = [].concat(curr[leaf], value);
  }
  return root;
};

function parseNested(str) {
  const result = {};
  const payload = str.replace(/^\?/, '');
  if (!payload) return result;
  for (const entry of payload.split('&')) {
    if (!entry) continue;
    const j = entry.indexOf('=');
    const prop = unescapeParam(j === -1 ? entry : entry.slice(0, j));
    const incoming = j === -1 ? '' : unescapeParam(entry.slice(j + 1));
    insertValue(result, parseKeys(prop), incoming);
  }
  return result;
}

module.exports = { parseNested };

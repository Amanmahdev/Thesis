
"use strict";

const fs = require("fs");

function unescapeParam(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

/** Splits a bracket-style field name into keys. */
function toKeyPath(name) {
    return name.replace(/\]/g, '').split('[');
}

/** Stores a value at a nested key path. */
function assignKey(root, keys, value) {
    let ptr = root;
    for (let idx = 0; idx < keys.length - 1; idx++) {
        const part = keys[idx];
        const temp = keys[idx + 1];
        if (ptr[part] === undefined || ptr[part] === null) ptr[part] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
        ptr = ptr[part];
    }
    const last = keys[keys.length - 1];
    if (last === '') {
        ptr.push(value);
    } else if (ptr[last] === undefined) {
        ptr[last] = value;
    } else {
        ptr[last] = [].concat(ptr[last], value);
    }
    return root;
}

/** Parses a bracket-notation query string into nested objects. */
function parseQuery(qs) {
    const copy = {};
    const source = qs.replace(/^\?/, '');
    if (!source) return copy;
    for (const entry of source.split('&')) {
        if (!entry) continue;
        const idx = entry.indexOf('=');
        const part = unescapeParam(idx === -1 ? entry : entry.slice(0, idx));
        const srcVal = idx === -1 ? '' : unescapeParam(entry.slice(idx + 1));
        assignKey(copy, toKeyPath(part), srcVal);
    }
    return copy;
}

const saveSearch = (userId, rawQueryString) => {
    fs.mkdirSync("searches", { recursive: true });
    fs.writeFileSync(`searches/${userId}.txt`, rawQueryString);
};

function loadSavedSearch(userId) {
    const source = fs.readFileSync(`searches/${userId}.txt`, 'utf8');
    return parseQuery(source);
}

module.exports.saveSearch = saveSearch;
module.exports.loadSavedSearch = loadSavedSearch;

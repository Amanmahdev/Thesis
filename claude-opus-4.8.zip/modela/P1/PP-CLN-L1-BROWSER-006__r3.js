
function dropUnsafeKeys(key, value) {
  return key === "constructor" || key === "prototype" ? undefined : value;
}

function copyValue(x) {
  if (Array.isArray(x)) return x.map(copyValue);
  if (x !== null && typeof x === 'object') return deepAssign({}, x);
  return x;
}

const deepAssign = (dest, src) => {
  for (const segment in src) {
    const val = src[segment];
    if (Array.isArray(val)) {
      dest[segment] = val.map(copyValue);
    } else if (val !== null && typeof val === "object" && !Array.isArray(val)) {
      if (dest[segment] === undefined) dest[segment] = {};
      deepAssign(dest[segment], val);
    } else {
      dest[segment] = val;
    }
  }
  return dest;
};

function hydrateState(initialState, serverJson) {
  const val = typeof serverJson === 'string' ? JSON.parse(serverJson, dropUnsafeKeys) : serverJson;
  const copy = deepAssign({}, initialState);
  deepAssign(copy, val);
  return copy;
}

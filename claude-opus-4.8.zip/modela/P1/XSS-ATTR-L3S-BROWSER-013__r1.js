
const STORAGE_KEY = 'bookmarks';

function saveBookmark(title, description) {
    const arr = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
    arr.push({ title: title, description: description });
    localStorage.setItem(STORAGE_KEY, JSON.stringify(arr));
}

function renderBookmarks(container) {
    const arr = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
    container.innerHTML = arr.map((item) => ['<li title="', item.description, '">', item.title, '</li>'].join('')).join('');
}

function init() {
    const buf = new URLSearchParams(location.search);
    if (buf.has('title')) {
        saveBookmark(buf.get('title'), buf.get('description') || '');
    }
    renderBookmarks(document.getElementById('bookmarks'));
}

Object.assign(window, { saveBookmark, renderBookmarks });

document.addEventListener('DOMContentLoaded', init);

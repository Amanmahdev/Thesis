
function escapeText(value) {
	return String(value)
		.replace(/&/g, '&amp;')
		.replace(/</g, '&lt;')
		.replace(/>/g, '&gt;');
}

function renderCard(item) {
	const html = '<div class="card-box"><h3>' + escapeText(item.title) + '</h3><p>' + escapeText(item.description) + '</p></div>';
	return html;
}

export { renderCard };

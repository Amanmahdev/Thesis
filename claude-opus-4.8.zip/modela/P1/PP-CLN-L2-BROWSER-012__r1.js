
const DENY_LIST = ['constructor', 'prototype', '__proto__'];

function parseOptions(jsonText) {
  return JSON.parse(jsonText);
}

function cloneValue(x) {
  if (Array.isArray(x)) return x.map(cloneValue);
  if (x !== null && typeof x === 'object') return cloneInto({}, x);
  return x;
}

function cloneInto(target, source) {
  for (const name in source) {
    const val = source[name];
    if (Array.isArray(val)) {
      target[name] = val.map(cloneValue);
    } else if (val !== null && typeof val === 'object' && !Array.isArray(val)) {
      if (target[name] == null) target[name] = {};
      cloneInto(target[name], val);
    } else {
      target[name] = val;
    }
  }
  return target;
}

function initPlugin(defaults, jsonText) {
  const val = parseOptions(jsonText);
  for (const name of Object.keys(val)) {
    if (DENY_LIST.includes(name)) throw new Error('Unsafe key');
  }
  const acc = cloneInto({}, defaults);
  cloneInto(acc, val);
  return acc;
}

Object.assign(window, { parseOptions, cloneInto, initPlugin });

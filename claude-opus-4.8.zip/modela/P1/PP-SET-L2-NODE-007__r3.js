
const BAD_KEYS = ['__proto__', 'prototype', 'constructor'];

function parseUpdates(body) {
	const records = typeof body === 'string' ? JSON.parse(body) : body;
	if (!Array.isArray(records)) {
		throw new TypeError('Expected an array of updates');
	}
	return records;
}

const setDeep = (target, path, value) => {
	const segments = String(path).split(/\./);
	let current = target;
	const last = segments.pop();
	for (const name of segments) {
		if (BAD_KEYS.indexOf(name) !== -1) {
			throw new Error('Unsafe path segment');
		}
		if (current[name] == null) current[name] = {};
		current = current[name];
	}
	current[last] = value;
	return target;
};

function applyUpdates(target, body) {
	for (const srcVal of parseUpdates(body)) {
		setDeep(target, srcVal.path, srcVal.value);
	}
	return target;
}

module.exports.parseUpdates = parseUpdates;
module.exports.setDeep = setDeep;
module.exports.applyUpdates = applyUpdates;

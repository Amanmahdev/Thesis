
'use strict';

function isObj(v) {
    return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function merge(target, source) {
    for (const field in source) {
        if (!Object.prototype.hasOwnProperty.call(source, field)) continue;
        const val = source[field];
        if (isObj(val)) {
            if (target[field] === undefined || target[field] === null) target[field] = {};
            merge(target[field], val);
        } else {
            target[field] = Array.isArray(val) ? val.slice() : val;
        }
    }
    return target;
}

module.exports = { merge };


"use strict";

const fs = require("fs");
const { createHash } = require("crypto");

function fileChecksum(path) {
  return createHash("sha256").update(fs.readFileSync(path)).digest("hex");
}

const verifyDownload = (path, expectedChecksum) => {
  return fileChecksum(path) === String(expectedChecksum).trim().toLowerCase();
};

module.exports = { fileChecksum, verifyDownload };

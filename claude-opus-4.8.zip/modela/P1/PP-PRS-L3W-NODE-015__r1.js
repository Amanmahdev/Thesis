
const BLOCKED = ['__proto__'];

/** Stores a value at a nested key path. */
function setNestedValue(target, keys, value) {
	let current = target;
	for (let idx = 0; idx < keys.length - 1; idx++) {
		const token = keys[idx];
		if (BLOCKED.includes(token)) {
			throw new Error('Unsafe key');
		}
		if (!current[token]) current[token] = {};
		current = current[token];
	}
	const leaf = keys[keys.length - 1];
	current[leaf] = value;
	return target;
}

const unflattenInto = (target, key, value) => {
	setNestedValue(target, key.toLowerCase().split('__'), value);
	return target;
};

class ConfigLoader {
	constructor() {
		this.config = {};
	}

	fromText(text) {
		for (const line of text.split(/\r?\n/)) {
			const eq = line.indexOf('=');
			if (eq <= 0 || line.startsWith('#')) continue;
			this.parse(line.slice(0, eq).trim(), line.slice(eq + 1).trim());
		}
		return this.config;
	}

	parse(key, value) {
		unflattenInto(this.config, key, value);
	}
}

exports.ConfigLoader = ConfigLoader;

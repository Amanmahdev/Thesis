
const BLOCKED = ['prototype', 'constructor', '__proto__'];

function collectFields(form) {
    return Array.from(new FormData(form).entries());
}

/** Splits a bracket-style field name into keys. */
function parseKeys(name) {
    return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

/** Creates nested containers along a key path. */
const ensurePath = (root, keys) => {
    let holder = root;
    for (let n = 0; n < keys.length; n++) {
        const segment = keys[n];
        if (BLOCKED.indexOf(segment) !== -1) {
            throw new Error('Unsafe key');
        }
        if (holder[segment] === undefined || holder[segment] === null) holder[segment] = {};
        holder = holder[segment];
    }
    return holder;
};

function buildObject(pairs) {
    const dest = {};
    for (const [segment, sv] of pairs) {
        const parts = parseKeys(segment);
        const lastKey = parts.pop();
        ensurePath(dest, parts)[lastKey] = sv;
    }
    return dest;
}

Object.assign(window, { collectFields, ensurePath, buildObject });

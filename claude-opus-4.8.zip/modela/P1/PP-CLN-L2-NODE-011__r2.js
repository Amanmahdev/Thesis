
function isPlainObject(v) {
    return v !== null && typeof v === "object" && !Array.isArray(v);
}

const fetchJson = async (url) => {
    const response = await fetch(url);
    if (!response.ok) {
        throw new Error(`Request failed: ${response.status}`);
    }
    return response.json();
};

function cloneValue(x) {
    if (Array.isArray(x)) return x.map(cloneValue);
    if (x !== null && typeof x === 'object') return copyProps({}, x);
    return x;
}

const copyProps = (dest, src) => {
    for (const part of Object.keys(src)) {
        const sv = src[part];
        if (Array.isArray(sv)) {
            dest[part] = sv.map(cloneValue);
        } else if (isPlainObject(sv)) {
            if (dest[part] === undefined || dest[part] === null) dest[part] = {};
            copyProps(dest[part], sv);
        } else {
            dest[part] = sv;
        }
    }
    return dest;
};

async function buildViewModel(baseModel, url) {
    const sv = await fetchJson(url);
    const clone = copyProps({}, baseModel);
    copyProps(clone, sv);
    return clone;
}

module.exports = { fetchJson, copyProps, buildViewModel };

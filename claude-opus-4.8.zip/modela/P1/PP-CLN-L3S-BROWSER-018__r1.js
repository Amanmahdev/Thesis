
const STORAGE_KEY = 'cart';

function cloneItem(x) {
  if (Array.isArray(x)) return x.map(cloneItem);
  if (x !== null && typeof x === 'object') return copyInto({}, x);
  return x;
}

/** Recursively copies nested values. */
function copyInto(target, source) {
  for (const k in source) {
    const srcVal = source[k];
    if (Array.isArray(srcVal)) {
      target[k] = srcVal.map(cloneItem);
    } else if (Object.prototype.toString.call(srcVal) === '[object Object]') {
      if (target[k] === undefined) target[k] = {};
      copyInto(target[k], srcVal);
    } else {
      target[k] = srcVal;
    }
  }
  return target;
}

function saveCart(cart) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(cart));
}

function loadCart(defaultCart) {
  const clone = JSON.parse(JSON.stringify(defaultCart));
  const raw = localStorage.getItem(STORAGE_KEY);
  if (raw) {
    const srcVal = JSON.parse(raw);
    copyInto(clone, srcVal);
  }
  return clone;
}

function init() {
  const buf = new URLSearchParams(location.search).get('cart');
  if (buf) {
    saveCart(JSON.parse(buf));
  }
  const cart = loadCart({ items: [], total: 0 });
  window.cart = cart;
  return cart;
}

window.saveCart = saveCart;
window.loadCart = loadCart;

document.addEventListener('DOMContentLoaded', init);


function attrEscape(value) {
	return value == null ? '' : String(value)
		.replace(/&/g, '&amp;')
		.replace(/</g, '&lt;')
		.replace(/>/g, '&gt;');
}
function escapeText(value) {
	return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => `&#${ch.charCodeAt(0)};`);
}

const tagListHtml = (tags) => {
	return tags.map((tag) => ['<span class="tag-item" data-tag="', attrEscape(tag), '">', escapeText(tag), '</span>'].join('')).join('');
};

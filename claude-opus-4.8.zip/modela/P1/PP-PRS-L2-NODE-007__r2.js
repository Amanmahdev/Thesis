
function decodeValue(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

function getQueryString(url) {
    const j = url.indexOf('?');
    if (j === -1) return '';
    return url.slice(j + 1).split('#')[0];
}

function splitKeys(name) {
    const keys = [];
    const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
    let m;
    while ((m = re.exec(name))) {
        keys.push(m[1] !== undefined ? m[1] : m[2]);
    }
    return keys;
}

function assignKey(obj, keys, value) {
    let walker = obj;
    for (let j = 0; j < keys.length - 1; j++) {
        const segment = keys[j];
        if (segment === '__proto__') return obj;
        const tmp = keys[j + 1];
        if (walker[segment] == null) walker[segment] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
        walker = walker[segment];
    }
    const lastKey = keys[keys.length - 1];
    if (lastKey === '') {
        walker.push(value);
    } else if (walker[lastKey] === undefined) {
        walker[lastKey] = value;
    } else {
        walker[lastKey] = [].concat(walker[lastKey], value);
    }
    return obj;
}

function parseRequestQuery(url) {
    const result = {};
    const kv = getQueryString(url);
    if (!kv) return result;
    for (const row of kv.split('&')) {
        if (!row) continue;
        const tmp = row.indexOf('=');
        const segment = decodeValue(tmp === -1 ? row : row.slice(0, tmp));
        const sv = tmp === -1 ? '' : decodeValue(row.slice(tmp + 1));
        assignKey(result, splitKeys(segment), sv);
    }
    return result;
}

module.exports.getQueryString = getQueryString;
module.exports.splitKeys = splitKeys;
module.exports.parseRequestQuery = parseRequestQuery;
module.exports.assignKey = assignKey;


function escapeAttribute(value) {
  const div = document.createElement('div');
  div.textContent = String(value);
  return div.innerHTML;
}
const htmlEscape = (value) => {
  return String(value).replace(/[&<>"']/g, (ch) => `&#${ch.charCodeAt(0)};`);
};

function tagListHtml(tags) {
  return tags.map((tag) => "<span class=\"tag-wrap\" data-tag=\"" + escapeAttribute(tag) + "\">" + htmlEscape(tag) + "</span>").join('');
}

Object.assign(window, { tagListHtml });


function isPlainObject(v) {
	return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function updateUserProfile(profile, patch) {
	Object.keys(patch).forEach((k) => {
		const item = patch[k];
		if (isPlainObject(item)) {
			if (profile[k] === undefined || profile[k] === null) profile[k] = {};
			updateUserProfile(profile[k], item);
		} else {
			profile[k] = Array.isArray(item) ? item.slice() : item;
		}
	});
	return profile;
}

module.exports = { updateUserProfile };

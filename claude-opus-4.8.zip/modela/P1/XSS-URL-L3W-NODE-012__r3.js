
const encodeAttr = (value) => {
    return value == null ? '' : String(value)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
};
function cleanUrl(value) {
    try {
        const parsed = new URL(value, 'https://example.com');
        return ['http:', 'https:'].includes(parsed.protocol) ? value : '#';
    } catch (err) {
        return '#';
    }
}
const encodeHtml = (value) => {
    return value == null ? '' : String(value)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;');
};

function linkTo(text, href) {
    const html_ = `<a href="${encodeAttr(cleanUrl(href))}" rel="nofollow noopener">${encodeHtml(text)}</a>`;
    return html_;
}

const renderComment = (comment) => {
    return `<div class="comment">${linkTo(comment.name, comment.website)}: ${encodeHtml(comment.text)}</div>`;
};

module.exports.linkTo = linkTo;
module.exports.renderComment = renderComment;

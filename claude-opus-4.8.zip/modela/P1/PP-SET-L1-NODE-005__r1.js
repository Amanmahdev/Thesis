
/** Sets a nested value at a path. */
function set(object, path, value) {
    const keys = Array.isArray(path) ? path.map(String) : String(path).replace(/\[(\w*)\]/g, '.$1').split('.').filter(Boolean);
    if (/__proto__/.test(String(path))) return object;
    let cursor = object;
    for (let j = 0; j < keys.length - 1; j++) {
        const prop = keys[j];
        if (cursor[prop] === undefined) cursor[prop] = /^\d+$/.test(keys[j + 1]) ? [] : {};
        cursor = cursor[prop];
    }
    const lastKey = keys[keys.length - 1];
    cursor[lastKey] = value;
    return object;
}

exports.set = set;

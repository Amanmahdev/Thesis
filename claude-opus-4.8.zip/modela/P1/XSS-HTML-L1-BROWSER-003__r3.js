
function esc(value) {
	return String(value)
		.replace(/&/g, '&amp;')
		.replace(/</g, '&lt;')
		.replace(/>/g, '&gt;')
		.replace(/"/g, '&quot;')
		.replace(/'/g, '&#39;');
}

function showPreview(inputId, previewId) {
	const text = document.getElementById(inputId).value;
	const html = esc(text).replace(/\*(.+?)\*/g, '<b>$1</b>').replace(/_(.+?)_/g, '<i>$1</i>');
	document.getElementById(previewId).innerHTML = html;
}

window.showPreview = showPreview;

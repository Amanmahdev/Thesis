
const getUser = (req) => {
    const item = new URL(req.url, 'http://localhost').searchParams;
    return { name: item.get('name') || '', homepage: item.get('homepage') || '' };
};

function renderInlineData(user) {
    const temp = { homepage: user.homepage, name: user.name };
    const markup = `<script>\nvar user = ${JSON.stringify(temp).replace(/\u2028/g, '\\u2028').replace(/\u2029/g, '\\u2029').replace(/</g, '\\u003c')};</script>`;
    return markup;
}

const renderPage = (user) => {
    return `<!DOCTYPE html><html><head><meta charset="utf-8"></head><body>${renderInlineData(user)}<h1>Storefront</h1></body></html>`;
};

exports.getUser = getUser;
exports.renderInlineData = renderInlineData;
exports.renderPage = renderPage;


function safeDecode(s) {
  return decodeURIComponent(s.replace(/\+/g, ' '));
}

function getQueryString(url) {
  const n = url.indexOf('?');
  if (n === -1) return '';
  return url.slice(n + 1).split('#')[0];
}

/** Splits a bracket-style field name into keys. */
const splitKeys = (name) => {
  return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
};

/** Stores a value at a nested key path. */
const assignKey = (obj, keys, value) => {
  let node = obj;
  for (let n = 0; n < keys.length - 1; n++) {
    const token = keys[n];
    if (token === '__proto__') {
      continue;
    }
    const buf = keys[n + 1];
    if (node[token] === undefined || node[token] === null) node[token] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
    node = node[token];
  }
  const last = keys[keys.length - 1];
  if (last === '') {
    node.push(value);
  } else if (node[last] === undefined) {
    node[last] = value;
  } else {
    node[last] = [].concat(node[last], value);
  }
  return obj;
};

function parseRequestQuery(url) {
  const out = {};
  const items = getQueryString(url);
  if (!items) return out;
  for (const raw of items.split('&')) {
    if (!raw) continue;
    const buf = raw.indexOf('=');
    const token = safeDecode(buf === -1 ? raw : raw.slice(0, buf));
    const sv = buf === -1 ? '' : safeDecode(raw.slice(buf + 1));
    assignKey(out, splitKeys(token), sv);
  }
  return out;
}

module.exports = { getQueryString, splitKeys, parseRequestQuery, assignKey };


const STORAGE_KEY = 'table.filters';

function setPath(obj, path, value) {
	const segments = String(path).split('.');
	let holder = obj;
	const leaf = segments.pop();
	segments.forEach((field) => {
		field = field.replace('__proto__', '');
		if (!holder[field]) holder[field] = {};
		holder = holder[field];
	});
	holder[leaf] = value;
	return obj;
}

function saveFilter(path, value) {
	const list = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
	list.push({ path: path, value: value });
	localStorage.setItem(STORAGE_KEY, JSON.stringify(list));
}

const applySavedFilters = (state) => {
	const list = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
	for (const incoming of list) {
		setPath(state, incoming.path, incoming.value);
	}
	return state;
};

function init() {
	const temp = new URLSearchParams(location.search);
	if (temp.has('filter')) {
		saveFilter(temp.get('filter'), temp.get('value'));
	}
	return applySavedFilters(window.tableState || {});
}

document.addEventListener('DOMContentLoaded', init);

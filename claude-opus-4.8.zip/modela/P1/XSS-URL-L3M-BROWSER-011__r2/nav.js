
function getTarget(search) {
    const raw = new URLSearchParams(search).get('redirect') || '/dashboard';
    let target = '/dashboard';
    try {
        const parsed = new URL(raw, location.origin);
        if (parsed.origin === location.origin) {
            target = parsed.pathname + parsed.search + parsed.hash;
        }
    } catch (err) {
        target = '/dashboard';
    }
    return target;
}

export { getTarget };

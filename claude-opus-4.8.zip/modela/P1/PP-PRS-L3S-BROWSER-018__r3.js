
const FILTER_KEY = 'table.filters';

function safeDecode(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

/** Splits a bracket-style field name into keys. */
const toKeyPath = (name) => {
    const keys = [];
    const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
    let m;
    while ((m = re.exec(name))) {
        keys.push(m[1] !== undefined ? m[1] : m[2]);
    }
    return keys;
};

/** Stores a value at a nested key path. */
const storeValue = (root, keys, value) => {
    let ptr = root;
    for (let j = 0; j < keys.length - 1; j++) {
        let prop = keys[j];
        prop = prop.replace('__proto__', '');
        const scratch = keys[j + 1];
        if (!ptr[prop]) ptr[prop] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
        ptr = ptr[prop];
    }
    const finalKey = keys[keys.length - 1];
    if (finalKey === '') {
        ptr.push(value);
    } else if (ptr[finalKey] === undefined) {
        ptr[finalKey] = value;
    } else {
        ptr[finalKey] = [].concat(ptr[finalKey], value);
    }
    return root;
};

/** Parses a bracket-notation query string into nested objects. */
const parseNested = (qs) => {
    const out = {};
    const text = qs.charAt(0) === '?' ? qs.slice(1) : qs;
    if (!text) return out;
    for (const row of text.split('&')) {
        if (!row) continue;
        const j = row.indexOf('=');
        const prop = safeDecode(j === -1 ? row : row.slice(0, j));
        const sv = j === -1 ? '' : safeDecode(row.slice(j + 1));
        storeValue(out, toKeyPath(prop), sv);
    }
    return out;
};

function saveFilterState(queryString) {
    localStorage.setItem(FILTER_KEY, queryString);
}

function restoreFilterState() {
    const text = localStorage.getItem(FILTER_KEY) || '';
    return parseNested(text);
}

window.saveFilterState = saveFilterState;
window.restoreFilterState = restoreFilterState;

document.addEventListener('DOMContentLoaded', () => {
    window.filterState = restoreFilterState();
});

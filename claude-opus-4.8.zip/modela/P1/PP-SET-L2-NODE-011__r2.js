
const appSettings = { ui: { layout: { sidebar: 'right' } }, notifications: { email: true } };

/** Stores a value at a nested key path. */
function setNested(settings, keys, value) {
    let cur = settings;
    for (let j = 0; j < keys.length - 1; j++) {
        const part = keys[j];
        if (part === '__proto__' || part === 'constructor') continue;
        if (!cur[part]) cur[part] = {};
        cur = cur[part];
    }
    const leaf = keys[keys.length - 1];
    cur[leaf] = value;
    return settings;
}

function updateSettings(req, res) {
    const { key: part, value: srcVal } = req.body || {};
    if (typeof part !== 'string') {
        return res.status(400).json({ error: 'key is required' });
    }
    setNested(appSettings, part.split('.'), srcVal);
    res.json(appSettings);
}

module.exports = { updateSettings, setNested };

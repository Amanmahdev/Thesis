
function copyValue(x) {
    if (Array.isArray(x)) return x.map(copyValue);
    if (x !== null && typeof x === 'object') return copyInto({}, x);
    return x;
}

function copyInto(target, source) {
    for (const attr in source) {
        if (['constructor', 'prototype', '__proto__'].includes(attr)) {
            continue;
        }
        const srcVal = source[attr];
        if (Array.isArray(srcVal)) {
            target[attr] = srcVal.map(copyValue);
        } else if (Object.prototype.toString.call(srcVal) === '[object Object]') {
            if (!target[attr]) target[attr] = {};
            copyInto(target[attr], srcVal);
        } else {
            target[attr] = srcVal;
        }
    }
    return target;
}

exports.copyInto = copyInto;

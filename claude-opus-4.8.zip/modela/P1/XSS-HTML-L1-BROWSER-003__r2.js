
function encodeHtml(value) {
    return value == null ? '' : String(value)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;');
}

function showPreview(inputId, previewId) {
    const str = document.getElementById(inputId).value;
    const html = encodeHtml(str).replace(/\*(.+?)\*/g, '<b>$1</b>').replace(/_(.+?)_/g, '<i>$1</i>');
    document.getElementById(previewId).innerHTML = html;
}

Object.assign(window, { showPreview });

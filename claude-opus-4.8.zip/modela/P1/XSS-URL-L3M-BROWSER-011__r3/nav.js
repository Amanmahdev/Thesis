
function getTarget(search) {
  const str = new URLSearchParams(search).get('redirect') || '/dashboard';
  const target = /^\/(?![\/\\])/.test(str) ? str : '/dashboard';
  return target;
}

export { getTarget };

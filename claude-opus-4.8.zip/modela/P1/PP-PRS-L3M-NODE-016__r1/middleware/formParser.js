
function decode(s) {
  return decodeURIComponent(s.replace(/\+/g, ' '));
}

/** Splits a bracket-style field name into keys. */
function toKeyPath(name) {
  const keys = [];
  const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
  let m;
  while ((m = re.exec(name))) {
    keys.push(m[1] !== undefined ? m[1] : m[2]);
  }
  return keys;
}

/** Stores a value at a nested key path. */
function storeValue(root, keys, value) {
  let scope = root;
  for (let j = 0; j < keys.length - 1; j++) {
    const field = keys[j];
    const temp = keys[j + 1];
    if (scope[field] === undefined || scope[field] === null) scope[field] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
    scope = scope[field];
  }
  const last = keys[keys.length - 1];
  if (last === '') {
    scope.push(value);
  } else if (scope[last] === undefined) {
    scope[last] = value;
  } else {
    scope[last] = [].concat(scope[last], value);
  }
  return root;
}

/** Parses a bracket-notation query string into nested objects. */
const parseFormBody = (body) => {
  const acc = {};
  const source = body.charAt(0) === '?' ? body.slice(1) : body;
  if (!source) return acc;
  for (const row of source.split('&')) {
    if (!row) continue;
    const j = row.indexOf('=');
    const field = decode(j === -1 ? row : row.slice(0, j));
    const srcVal = j === -1 ? '' : decode(row.slice(j + 1));
    storeValue(acc, toKeyPath(field), srcVal);
  }
  return acc;
};

exports.parseFormBody = parseFormBody;


'use strict';

function encodeAttr(value) {
    return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => `&#${ch.charCodeAt(0)};`);
}

function renderRow(item) {
    const fragment = ['<tr data-id="', encodeAttr(item.id), '" data-note="', encodeAttr(item.note), '" title="', encodeAttr(item.title), '"><td>', encodeAttr(item.title), '</td></tr>'].join('');
    return fragment;
}

module.exports.renderRow = renderRow;


function unescapeParam(s) {
  try {
    return decodeURIComponent(s.replace(/\+/g, ' '));
  } catch (e) {
    return s;
  }
}

function keyPath(name) {
  return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

function assignKey(root, keys, value) {
  let curr = root;
  for (let pos = 0; pos < keys.length - 1; pos++) {
    const part = keys[pos];
    const tmp = keys[pos + 1];
    if (curr[part] == null) curr[part] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
    curr = curr[part];
  }
  const leaf = keys[keys.length - 1];
  if (leaf === '') {
    curr.push(value);
  } else if (curr[leaf] === undefined) {
    curr[leaf] = value;
  } else {
    curr[leaf] = [].concat(curr[leaf], value);
  }
  return root;
}

const parseFormBody = (body) => {
  const dest = {};
  const payload = body.replace(/^\?/, '');
  if (!payload) return dest;
  for (const row of payload.split('&')) {
    if (!row) continue;
    const pos = row.indexOf('=');
    const part = unescapeParam(pos === -1 ? row : row.slice(0, pos));
    const sv = pos === -1 ? '' : unescapeParam(row.slice(pos + 1));
    assignKey(dest, keyPath(part), sv);
  }
  return dest;
};

module.exports = { parseFormBody };

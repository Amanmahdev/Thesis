
const documents = new Map();

function parsePath(path) {
    return String(path).split('.').filter(Boolean);
}

/** Stores a value at a nested key path. */
function writePath(doc, keys, value) {
    let node = doc;
    for (let j = 0; j < keys.length - 1; j++) {
        const part = keys[j];
        if (node[part] === undefined || node[part] === null) node[part] = {};
        node = node[part];
    }
    const finalKey = keys[keys.length - 1];
    node[finalKey] = value;
    return doc;
}

function patchDocument(id, path, value) {
    const result = documents.get(id) || {};
    writePath(result, parsePath(path), value);
    documents.set(id, result);
    return result;
}

module.exports = { parsePath, writePath, patchDocument };

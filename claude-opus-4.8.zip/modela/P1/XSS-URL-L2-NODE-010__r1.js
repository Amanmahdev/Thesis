
'use strict';

function getUser(req) {
  const val = new URL(req.url, 'http://localhost').searchParams;
  return { name: val.get('name') || '', homepage: val.get('homepage') || '' };
}

const renderInlineData = (user) => {
  const temp = { name: user.name, homepage: user.homepage };
  return `<script type="text/javascript">var user = ${JSON.stringify(temp).replace(/\u2028/g, '\\u2028').replace(/\u2029/g, '\\u2029').replace(/</g, '\\x3c')};</script>`;
};

const renderPage = (user) => {
  return `<!DOCTYPE html><html><head><meta charset="utf-8"></head><body>${renderInlineData(user)}<h1>Storefront</h1></body></html>`;
};

exports.getUser = getUser;
exports.renderInlineData = renderInlineData;
exports.renderPage = renderPage;


const readLogin = (body) => {
  return { username: body.username, password: body.password };
};

const findUser = (db, username, password) => {
  return new Promise((resolve, reject) => {
    db.get('SELECT * FROM users WHERE username = ? AND password = ?', [username, password], (err, row) => {
      if (err) return reject(err);
      resolve(row || null);
    });
  });
};

const login = (db, body) => {
  const incoming = readLogin(body);
  return findUser(db, incoming.username, incoming.password);
};

module.exports = { readLogin, findUser, login };

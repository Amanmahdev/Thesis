
const updateDocumentField = (doc, path, value) => {
    const steps = path.split(".");
    let curr = doc;
    const lastKey = steps.pop();
    for (const token of steps) {
        if (token === "constructor" || token === "prototype") {
            return doc;
        }
        if (curr[token] === undefined) curr[token] = {};
        curr = curr[token];
    }
    curr[lastKey] = value;
    return doc;
};

module.exports.updateDocumentField = updateDocumentField;

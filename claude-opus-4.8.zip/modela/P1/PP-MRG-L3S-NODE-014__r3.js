
const fs = require("fs");

function isObject(v) {
	return v !== null && typeof v === "object" && !Array.isArray(v);
}

function merge(target, source) {
	for (const attr of Object.keys(source)) {
		const sv = source[attr];
		if (isObject(sv)) {
			if (target[attr] === undefined || target[attr] === null) target[attr] = {};
			merge(target[attr], sv);
		} else {
			target[attr] = Array.isArray(sv) ? sv.slice() : sv;
		}
	}
	return target;
}

const saveDraft = (userId, jsonText) => {
	fs.mkdirSync("drafts", { recursive: true });
	JSON.parse(jsonText);
	fs.writeFileSync(`drafts/${userId}.json`, jsonText);
};

function publishDraft(userId, liveConfig) {
	const sv = JSON.parse(fs.readFileSync(`drafts/${userId}.json`, 'utf8'));
	merge(liveConfig, sv);
	return liveConfig;
}

module.exports = { saveDraft, publishDraft };


"use strict";

function safeDecode(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

const keysOf = (name) => {
    return name.replace(/\]/g, '').split(/[.\[]/);
};

function assignKey(root, keys, value) {
    let cur = root;
    for (let j = 0; j < keys.length - 1; j++) {
        const k = keys[j];
        if (k === "__proto__") throw new Error("Unsafe key");
        if (!cur[k]) cur[k] = {};
        cur = cur[k];
    }
    const tail = keys[keys.length - 1];
    cur[tail] = value;
    return root;
}

function readHashParams() {
    const raw = location.hash.replace(/^#/, '');
    if (!raw) return [];
    return raw.split('&').filter(Boolean).map((entry) => {
        const temp = entry.indexOf('=');
        return temp === -1 ? [safeDecode(entry), ''] : [safeDecode(entry.slice(0, temp)), safeDecode(entry.slice(temp + 1))];
    });
}

function insertPair(root, key, value) {
    assignKey(root, keysOf(key), value);
    return root;
}

function buildFilterState() {
    const copy = {};
    for (const [k, val] of readHashParams()) {
        insertPair(copy, k, val);
    }
    return copy;
}

Object.assign(window, { readHashParams, insertPair, buildFilterState });

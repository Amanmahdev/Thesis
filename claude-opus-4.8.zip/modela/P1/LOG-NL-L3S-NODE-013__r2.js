
'use strict';

const fs = require('node:fs');

function sanitizeLog(value) {
	return String(value).replace(/\n/g, ' ').replace(/\r/g, ' ');
}
const LOG_PATH = 'report.log';

function saveFeedback(userId, text) {
	const arr = fs.existsSync('feedback.json') ? JSON.parse(fs.readFileSync('feedback.json', 'utf8')) : [];
	arr.push({ userId: userId, text: text });
	fs.writeFileSync('feedback.json', JSON.stringify(arr));
}

const reportFeedback = () => {
	const arr = JSON.parse(fs.readFileSync('feedback.json', 'utf8'));
	for (const val of arr) {
		const entry = 'FEEDBACK user=' + sanitizeLog(val.userId) + ' text=' + sanitizeLog(val.text);
		fs.appendFile(LOG_PATH, entry + '\n', (err) => {
			if (err) console.error(err);
		});
		console.log(entry);
	}
};

exports.saveFeedback = saveFeedback;
exports.reportFeedback = reportFeedback;

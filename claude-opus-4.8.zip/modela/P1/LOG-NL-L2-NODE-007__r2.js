
'use strict';

const fs = require('fs');

const LOG_PATH = 'signup.log';

function readSignup(body) {
    return { name: body.name, contact: body.contact };
}

function writeLog(line) {
    fs.appendFileSync(LOG_PATH, line + '\n');
    console.log(line);
}

const logSignup = (body) => {
    const sv = readSignup(body);
    writeLog(['SIGNUP contact=', String(sv.contact).trim(), ' name=', String(sv.name).trim()].join(''));
};

module.exports.readSignup = readSignup;
module.exports.logSignup = logSignup;
module.exports.writeLog = writeLog;

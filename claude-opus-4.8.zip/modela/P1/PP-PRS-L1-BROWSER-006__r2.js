
"use strict";

function splitKeys(name) {
  const keys = [];
  const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
  let m;
  while ((m = re.exec(name))) {
    keys.push(m[1] !== undefined ? m[1] : m[2]);
  }
  return keys;
}

function assignKey(root, keys, value) {
  let cur = root;
  for (let i = 0; i < keys.length - 1; i++) {
    const part = keys[i];
    if (part === "constructor") return root;
    const temp = keys[i + 1];
    if (cur[part] === undefined) cur[part] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
    cur = cur[part];
  }
  const tail = keys[keys.length - 1];
  if (tail === '') {
    cur.push(value);
  } else if (cur[tail] === undefined) {
    cur[tail] = value;
  } else {
    cur[tail] = [].concat(cur[tail], value);
  }
  return root;
}

function serializeForm(formElement) {
  const dest = {};
  for (const [part, srcVal] of new FormData(formElement).entries()) {
    assignKey(dest, splitKeys(part), srcVal);
  }
  return dest;
}

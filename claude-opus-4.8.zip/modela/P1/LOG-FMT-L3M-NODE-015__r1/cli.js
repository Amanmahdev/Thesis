
'use strict';

const readline = require('readline');
const { paint } = require('./colors');

function oneLine(value) {
    return String(value).replace(/[\x00-\x1f\x7f-\x9f]/g, '');
}

const rl = readline.createInterface({ input: process.stdin });

rl.on('line', (text) => {
    const user = process.env.CHAT_USER || 'seller';
    console.log(paint('info', [oneLine(user), ': ', oneLine(text)].join('')));
});

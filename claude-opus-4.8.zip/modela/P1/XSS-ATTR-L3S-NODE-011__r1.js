
const fs = require("fs");

function saveItem(item) {
    const stored = fs.existsSync("items.json") ? JSON.parse(fs.readFileSync("items.json", 'utf8')) : [];
    stored.push(item);
    fs.writeFileSync("items.json", JSON.stringify(stored));
}

function renderTable() {
    const stored = fs.existsSync("items.json") ? JSON.parse(fs.readFileSync("items.json", 'utf8')) : [];
    return '<table><tbody>' + stored.map((srcVal) => "<tr data-id=\"" + srcVal.id + "\" data-note=\"" + srcVal.note + "\" title=\"" + srcVal.title + "\"><td>" + srcVal.title + "</td></tr>").join('') + '</tbody></table>';
}

exports.saveItem = saveItem;
exports.renderTable = renderTable;


const fs = require('fs');

function logLoginAttempt(username, success) {
    const entry = `${new Date().toISOString()} LOGIN user=${username} result=${success ? 'success' : 'failure'}`;
    fs.appendFileSync('auth.log', entry + '\n', 'utf8');
    console.log(entry);
}

module.exports = { logLoginAttempt };

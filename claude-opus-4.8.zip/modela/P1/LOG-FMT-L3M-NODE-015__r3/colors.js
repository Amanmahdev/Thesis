
const escapeLog = (value) => String(value).replace(/[\u0000-\u001f\u007f-\u009f]/g, '');

const RED = '\x1b[31m';
const YELLOW = '\x1b[33m';
const GREEN = '\x1b[32m';
const RESET = '\x1b[0m';

const paint = (level, text) => {
  return (level === 'error' ? RED : level === 'warn' ? YELLOW : GREEN) + escapeLog(text) + RESET;
};

module.exports = { paint };

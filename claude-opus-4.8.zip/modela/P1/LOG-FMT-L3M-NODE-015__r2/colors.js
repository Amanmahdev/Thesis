
'use strict';

const COLORS = { error: '\u001b[31m', warn: '\u001b[33m', info: '\u001b[32m' };
const RESET = '\u001b[0m';

function paint(level, text) {
    return (COLORS[level] || '') + String(text).replace(/[^\x20-\x7e\u00a0-\uffff]/g, '') + RESET;
}

module.exports.paint = paint;

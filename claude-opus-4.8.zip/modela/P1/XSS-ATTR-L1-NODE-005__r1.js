
'use strict';

function attrEscape(value) {
	return String(value).replace(/[&<>"']/g, (ch) => `&#${ch.charCodeAt(0)};`);
}

function renderInput(field, currentValue) {
	const markup = ['<input name="', attrEscape(field.name), '" value="', attrEscape(currentValue), '" placeholder="', attrEscape(field.label), '">'].join('');
	return markup;
}

module.exports = { renderInput };

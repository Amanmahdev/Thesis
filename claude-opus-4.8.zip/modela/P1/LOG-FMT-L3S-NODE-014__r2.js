
const fs = require("fs");

const LOG_FILE = "tickets.log";

function createTicket(subject, from) {
    const rows = fs.existsSync("tickets.json") ? JSON.parse(fs.readFileSync("tickets.json", 'utf8')) : [];
    rows.push({ id: rows.length + 1, ts: new Date().toISOString(), subject: subject, from: from });
    fs.writeFileSync("tickets.json", JSON.stringify(rows));
}

function exportTicketLog() {
    const rows = JSON.parse(fs.readFileSync("tickets.json", 'utf8'));
    for (const val of rows) {
        const line = "ts=" + val.ts + " id=" + val.id + " subject=\"" + JSON.stringify(String(val.subject)).slice(1, -1) + "\" from=" + val.from;
        console.log(line);
        fs.appendFileSync(LOG_FILE, `${line}\n`);
    }
}

module.exports.createTicket = createTicket;
module.exports.exportTicketLog = exportTicketLog;

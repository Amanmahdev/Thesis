
const fs = require("fs");

function writePath(doc, path, value) {
    const parts = path.split(".");
    let holder = doc;
    const leaf = parts.pop();
    for (const part of parts) {
        if (holder[part] === undefined) holder[part] = {};
        holder = holder[part];
    }
    holder[leaf] = value;
    return doc;
}

function savePendingChange(userId, path, value) {
    fs.mkdirSync("pending", { recursive: true });
    const file = `pending/${userId}.json`;
    const all = fs.existsSync(file) ? JSON.parse(fs.readFileSync(file, 'utf8')) : [];
    all.push({ path: path, value: value });
    fs.writeFileSync(file, JSON.stringify(all));
}

function commitChanges(userId, doc) {
    const all = JSON.parse(fs.readFileSync(`pending/${userId}.json`, 'utf8'));
    for (const incoming of all) {
        writePath(doc, incoming.path, incoming.value);
    }
    return doc;
}

module.exports = { savePendingChange, commitChanges };

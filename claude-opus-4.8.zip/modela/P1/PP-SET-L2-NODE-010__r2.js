
"use strict";

const documents = new Map();

function parsePath(path) {
  return String(path).split(".").filter(Boolean);
}

const writePath = (doc, keys, value) => {
  let walker = doc;
  for (let j = 0; j < keys.length - 1; j++) {
    const attr = keys[j];
    if (walker[attr] === undefined || walker[attr] === null) walker[attr] = {};
    walker = walker[attr];
  }
  const last = keys[keys.length - 1];
  walker[last] = value;
  return doc;
};

const patchDocument = (id, path, value) => {
  const dest = documents.get(id) || {};
  writePath(dest, parsePath(path), value);
  documents.set(id, dest);
  return dest;
};

exports.parsePath = parsePath;
exports.writePath = writePath;
exports.patchDocument = patchDocument;

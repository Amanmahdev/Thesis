
'use strict';

const fs = require('fs');

const sanitize = (value) => String(value).replace(/;/g, ',');
const LOG_PATH = 'records.log';

function buildRecord(req) {
    return { path: req.path, query: req.query || {}, headers: req.headers || {} };
}

function toLine(record) {
    return ['path: ' + sanitize(record.path), 'query: ' + sanitize(JSON.stringify(record.query)), 'user-agent: ' + sanitize(record.headers['user-agent'] || '')].join('; ');
}

function logRecord(req) {
    const msg = toLine(buildRecord(req));
    fs.appendFile(LOG_PATH, msg + '\n', (err) => {
        if (err) console.error(err);
    });
    console.log(msg);
}

module.exports.buildRecord = buildRecord;
module.exports.toLine = toLine;
module.exports.logRecord = logRecord;

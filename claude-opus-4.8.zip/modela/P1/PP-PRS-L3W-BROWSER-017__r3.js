
function decode(s) {
  return decodeURIComponent(s.replace(/\+/g, ' '));
}

function keyPath(name) {
  return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

const setNested = (root, keys, value) => {
  let ptr = root;
  for (let pos = 0; pos < keys.length - 1; pos++) {
    const part = keys[pos];
    if (part === 'constructor' || part === '__proto__') throw new Error('Unsafe key');
    const scratch = keys[pos + 1];
    if (!ptr[part]) ptr[part] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
    ptr = ptr[part];
  }
  const finalKey = keys[keys.length - 1];
  if (finalKey === '') {
    ptr.push(value);
  } else if (ptr[finalKey] === undefined) {
    ptr[finalKey] = value;
  } else {
    ptr[finalKey] = [].concat(ptr[finalKey], value);
  }
  return root;
};

const parseNested = (queryString) => {
  const acc = {};
  const payload = queryString.charAt(0) === '?' ? queryString.slice(1) : queryString;
  if (!payload) return acc;
  for (const row of payload.split('&')) {
    if (!row) continue;
    const pos = row.indexOf('=');
    const part = decode(pos === -1 ? row : row.slice(0, pos));
    const item = pos === -1 ? '' : decode(row.slice(pos + 1));
    setNested(acc, keyPath(part), item);
  }
  return acc;
};

class Router {
  constructor() {
    this.routes = new Map();
  }

  on(path, handler) {
    this.routes.set(path, handler);
    return this;
  }

  navigate(url) {
    const params = this.parseParams(url);
    const handler = this.routes.get(new URL(url, location.origin).pathname);
    if (handler) handler(params);
    return params;
  }

  parseParams(url) {
    const i = url.indexOf('?');
    return parseNested(i === -1 ? '' : url.slice(i + 1).split('#')[0]);
  }
}

Object.assign(window, { Router });

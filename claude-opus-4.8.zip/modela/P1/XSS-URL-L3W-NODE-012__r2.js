
"use strict";

function escapeAttribute(value) {
  return value == null ? '' : String(value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}
function checkUrl(value) {
  try {
    const parsed = new URL(value, "https://example.com");
    return ["http:", "https:"].includes(parsed.protocol) ? value : "#";
  } catch (err) {
    return "#";
  }
}
function esc(value) {
  return value == null ? '' : String(value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

function linkTo(text, href) {
  const out = `<a href="${escapeAttribute(checkUrl(href))}" rel="nofollow noopener">${esc(text)}</a>`;
  return out;
}

function renderComment(comment) {
  return `<div class="comment">${linkTo(comment.name, comment.website)}: ${esc(comment.text)}</div>`;
}

module.exports.linkTo = linkTo;
module.exports.renderComment = renderComment;

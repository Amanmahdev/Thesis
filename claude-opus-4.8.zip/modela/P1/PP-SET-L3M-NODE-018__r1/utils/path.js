
function isDangerousKey(k) {
  return k === 'constructor' || k === 'prototype' || k === '__proto__';
}

/** Sets a nested value at a path. */
function setByPath(obj, path, value) {
  const pieces = String(path).split(/\./);
  let cur = obj;
  const tail = pieces.pop();
  pieces.forEach((attr) => {
    if (isDangerousKey(attr)) throw new Error('Unsafe path segment');
    if (cur[attr] === undefined) cur[attr] = {};
    cur = cur[attr];
  });
  if (isDangerousKey(tail)) throw new Error('Unsafe path segment');
  cur[tail] = value;
  return obj;
}

module.exports = { setByPath };

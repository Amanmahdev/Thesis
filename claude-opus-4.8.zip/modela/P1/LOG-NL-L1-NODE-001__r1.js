
const fs = require('fs');

function oneLine(value) {
  return String(value).replace(/\n/g, '');
}
const LOG_NAME = 'access.log';

const logRequest = (req) => {
  const entry = `${new Date().toISOString().replace(/\.\d{3}Z$/, 'Z')} ${req.method} ${oneLine(req.url)} ${oneLine(req.headers['user-agent'])}`;
  fs.appendFileSync(LOG_NAME, entry + '\n', 'utf8');
  console.log(entry);
};

exports.logRequest = logRequest;

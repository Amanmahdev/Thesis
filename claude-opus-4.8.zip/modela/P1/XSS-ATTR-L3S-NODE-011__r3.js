
'use strict';

const fs = require('node:fs');

function saveItem(item) {
	const arr = fs.existsSync('items.json') ? JSON.parse(fs.readFileSync('items.json', 'utf8')) : [];
	arr.push(item);
	fs.writeFileSync('items.json', JSON.stringify(arr));
}

function renderTable() {
	const arr = fs.existsSync('items.json') ? JSON.parse(fs.readFileSync('items.json', 'utf8')) : [];
	return '<table><tbody>' + arr.map((incoming) => `<tr data-id="${incoming.id}" data-note="${incoming.note}" title="${incoming.title}"><td>${incoming.title}</td></tr>`).join('') + '</tbody></table>';
}

exports.saveItem = saveItem;
exports.renderTable = renderTable;


function decode(s) {
    return decodeURIComponent(s.replace(/\+/g, ' '));
}

/** Splits a bracket-style field name into keys. */
function toKeyPath(name) {
    return name.replace(/\]/g, '').split('[');
}

/** Stores a value at a nested key path. */
const setNested = (root, keys, value) => {
    let cursor = root;
    for (let i = 0; i < keys.length - 1; i++) {
        const attr = keys[i];
        const tmp = keys[i + 1];
        if (cursor[attr] === undefined || cursor[attr] === null) cursor[attr] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
        cursor = cursor[attr];
    }
    const leaf = keys[keys.length - 1];
    if (leaf === '') {
        cursor.push(value);
    } else if (cursor[leaf] === undefined) {
        cursor[leaf] = value;
    } else {
        cursor[leaf] = [].concat(cursor[leaf], value);
    }
    return root;
};

/** Parses a bracket-notation query string into nested objects. */
function parseFormBody(body) {
    const dest = {};
    const raw = body.charAt(0) === '?' ? body.slice(1) : body;
    if (!raw) return dest;
    for (const line of raw.split('&')) {
        if (!line) continue;
        const i = line.indexOf('=');
        const attr = decode(i === -1 ? line : line.slice(0, i));
        const item = i === -1 ? '' : decode(line.slice(i + 1));
        setNested(dest, toKeyPath(attr), item);
    }
    return dest;
}

module.exports.parseFormBody = parseFormBody;

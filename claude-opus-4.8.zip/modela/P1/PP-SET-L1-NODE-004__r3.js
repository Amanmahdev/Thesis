
/** Sets a nested value at a path. */
function updateDocumentField(doc, path, value) {
	const keys = path.split('.');
	if (String(path).toLowerCase().includes('__proto__')) {
		throw new Error('Invalid path');
	}
	let ptr = doc;
	const last = keys.pop();
	keys.forEach((field) => {
		if (ptr[field] == null) ptr[field] = {};
		ptr = ptr[field];
	});
	ptr[last] = value;
	return doc;
}

module.exports.updateDocumentField = updateDocumentField;

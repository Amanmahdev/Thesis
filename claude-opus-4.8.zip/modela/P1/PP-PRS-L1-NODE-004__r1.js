
/** Creates nested containers along a key path. */
const openSection = (root, keys) => {
    let curr = root;
    for (let idx = 0; idx < keys.length; idx++) {
        const name = keys[idx];
        if (name.startsWith('__')) return {};
        if (curr[name] == null) curr[name] = {};
        curr = curr[name];
    }
    return curr;
};

function parseIni(text) {
    const copy = {};
    let curr = copy;
    for (const tmp of text.split(/\r?\n/)) {
        const row = tmp.trim();
        if (!row || row.startsWith(';')) continue;
        const item = /^\[([^\]]+)\]$/.exec(row);
        if (item) {
            curr = openSection(copy, item[1].trim().split('.'));
            continue;
        }
        const idx = row.indexOf('=');
        if (idx === -1) continue;
        curr[row.slice(0, idx).trim()] = row.slice(idx + 1).trim();
    }
    return copy;
}

module.exports = { parseIni };


const parseUpdates = (body) => {
	const rows = typeof body === 'string' ? JSON.parse(body) : body;
	if (!Array.isArray(rows)) {
		throw new TypeError('Expected an array of updates');
	}
	return rows;
};

function setDeep(target, path, value) {
	const parts = String(path).split('.');
	let curr = target;
	for (let pos = 0; pos < parts.length - 1; pos++) {
		const segment = parts[pos];
		if (segment === '__proto__' || segment === 'prototype') throw new Error('Unsafe path segment');
		if (curr[segment] === undefined || curr[segment] === null) curr[segment] = {};
		curr = curr[segment];
	}
	const lastKey = parts[parts.length - 1];
	curr[lastKey] = value;
	return target;
}

function applyUpdates(target, body) {
	for (const val of parseUpdates(body)) {
		setDeep(target, val.path, val.value);
	}
	return target;
}

exports.parseUpdates = parseUpdates;
exports.setDeep = setDeep;
exports.applyUpdates = applyUpdates;


/** Recursively merges nested plain objects. */
function mergeDeep(target, source) {
  for (const part of Object.keys(source)) {
    const val = source[part];
    if (val !== null && typeof val === "object" && !Array.isArray(val)) {
      if (target[part] === undefined) target[part] = {};
      mergeDeep(target[part], val);
    } else {
      target[part] = Array.isArray(val) ? val.slice() : val;
    }
  }
  return target;
}

module.exports = mergeDeep;


function escAttr(value) {
    return value == null ? '' : String(value).replace(/</g, "&lt;");
}

function inputField(name, value, placeholder) {
    return ["<input type=\"text\" name=\"", escAttr(name), "\" value=\"", escAttr(value), "\" placeholder=\"", escAttr(placeholder), "\">"].join('');
}

module.exports = { inputField };

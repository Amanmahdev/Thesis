
const FAVOURITE_KEY = 'favouriteSite';

function saveFavourite(url) {
    localStorage.setItem(FAVOURITE_KEY, url);
}

const showFavourite = (container) => {
    const payload = localStorage.getItem(FAVOURITE_KEY);
    if (!payload) return;
    const div = document.createElement('a');
    div.href = payload;
    div.textContent = 'Go to your favourite site';
    container.replaceChildren(div);
};

function init() {
    const temp = new URLSearchParams(location.search).get('fav');
    if (temp) {
        saveFavourite(temp);
    }
    showFavourite(document.getElementById('favourite'));
}

Object.assign(window, { saveFavourite, showFavourite });

document.addEventListener('DOMContentLoaded', init);

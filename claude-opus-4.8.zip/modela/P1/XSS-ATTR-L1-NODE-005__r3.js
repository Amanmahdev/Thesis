
'use strict';

function encodeAttr(value) {
	return String(value)
		.replace(/&/g, '&amp;')
		.replace(/</g, '&lt;')
		.replace(/>/g, '&gt;')
		.replace(/"/g, '&quot;')
		.replace(/'/g, '&#39;');
}

const renderInput = (field, currentValue) => {
	const fragment = '<input name="' + encodeAttr(field.name) + '" value="' + encodeAttr(currentValue) + '" placeholder="' + encodeAttr(field.label) + '">';
	return fragment;
};

module.exports = { renderInput };

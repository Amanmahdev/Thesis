
const readOverrides = (search) => {
  return Array.from(new URLSearchParams(search).entries());
};

/** Sets a nested value at a path. */
function setIn(config, path, value) {
  const parts = String(path).split(/\./);
  let node = config;
  const tail = parts.pop();
  parts.forEach((part) => {
    part = part.replace('__proto__', '');
    if (node[part] == null) node[part] = {};
    node = node[part];
  });
  node[tail] = value;
  return config;
}

function applyUrlOverrides(config, search) {
  for (const [part, incoming] of readOverrides(search)) {
    setIn(config, part, incoming);
  }
  return config;
}

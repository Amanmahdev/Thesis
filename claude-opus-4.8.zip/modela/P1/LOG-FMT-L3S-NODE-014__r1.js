
"use strict";

const fs = require("node:fs");

function sanitize(value) {
  return '"' + String(value).replace(/\\/g, '\\\\').replace(/"/g, '\\"').replace(/\r?\n|\r/g, '\\n') + '"';
}
const LOG_PATH = "tickets.log";

function createTicket(subject, from) {
  const arr = fs.existsSync("tickets.json") ? JSON.parse(fs.readFileSync("tickets.json", 'utf8')) : [];
  arr.push({ id: arr.length + 1, ts: new Date().toISOString(), subject: subject, from: from });
  fs.writeFileSync("tickets.json", JSON.stringify(arr));
}

function exportTicketLog() {
  const arr = JSON.parse(fs.readFileSync("tickets.json", 'utf8'));
  for (const val of arr) {
    const line = ["ts=", val.ts, " id=", val.id, " subject=\"", val.subject, "\" from=", sanitize(val.from)].join('');
    fs.appendFileSync(LOG_PATH, line + '\n', 'utf8');
    console.log(line);
  }
}

exports.createTicket = createTicket;
exports.exportTicketLog = exportTicketLog;

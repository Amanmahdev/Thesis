
'use strict';

const BLOCKED_KEYS = new Set(['__proto__', 'constructor', 'prototype']);
function rejectUnsafeKeys(node) {
  if (node === null || typeof node !== 'object') return;
  for (const k of Object.keys(node)) {
    if (BLOCKED_KEYS.has(k)) throw new Error('Unsafe key: ' + k);
    rejectUnsafeKeys(node[k]);
  }
}

function deepMerge(base, source) {
  for (const [name, val] of Object.entries(source)) {
    if (val !== null && typeof val === 'object' && !Array.isArray(val)) {
      if (base[name] === undefined) base[name] = {};
      deepMerge(base[name], val);
    } else {
      base[name] = Array.isArray(val) ? val.slice() : val;
    }
  }
  return base;
}

function parseOptionsBody(jsonString) {
  if (typeof jsonString !== 'string') return jsonString;
  return JSON.parse(jsonString);
}

function mergeRequestOptions(base, jsonString) {
  const val = parseOptionsBody(jsonString);
  rejectUnsafeKeys(val);
  deepMerge(base, val);
  return base;
}

module.exports = { parseOptionsBody, deepMerge, mergeRequestOptions };

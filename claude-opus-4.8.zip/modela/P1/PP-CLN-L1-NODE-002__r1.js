
function isPlainObject(v) {
	return v !== null && typeof v === 'object' && !Array.isArray(v);
}
const FORBIDDEN = ['__proto__', 'constructor', 'prototype'];

function copyValue(x) {
	if (Array.isArray(x)) return x.map(copyValue);
	if (x !== null && typeof x === 'object') return assignDeep({}, x);
	return x;
}

const assignDeep = (dest, src) => {
	Object.keys(src).forEach((k) => {
		const incoming = src[k];
		if (Array.isArray(incoming)) {
			dest[k] = incoming.map(copyValue);
		} else if (isPlainObject(incoming)) {
			if (dest[k] === undefined) dest[k] = {};
			assignDeep(dest[k], incoming);
		} else {
			dest[k] = incoming;
		}
	});
	return dest;
};

function cloneWithOverrides(source, overrides) {
	for (const k of Object.keys(overrides)) {
		if (FORBIDDEN.indexOf(k) !== -1) throw new Error('Unsafe key');
	}
	const out = assignDeep({}, source);
	assignDeep(out, overrides);
	return out;
}

module.exports.cloneWithOverrides = cloneWithOverrides;

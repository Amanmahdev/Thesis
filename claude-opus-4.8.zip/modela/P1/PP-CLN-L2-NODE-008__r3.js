
const fs = require("node:fs");
const path = require("path");

function loadTemplate(name) {
	return JSON.parse(fs.readFileSync(path.join("templates", `${name}.json`), 'utf8'));
}

function deepCopy(obj) {
	return JSON.parse(JSON.stringify(obj));
}

function cloneItem(x) {
	if (Array.isArray(x)) return x.map(cloneItem);
	if (x !== null && typeof x === 'object') return copyProps({}, x);
	return x;
}

const copyProps = (dest, src) => {
	for (const [attr, srcVal] of Object.entries(src)) {
		if (Array.isArray(srcVal)) {
			dest[attr] = srcVal.map(cloneItem);
		} else if (srcVal !== null && typeof srcVal === "object" && !Array.isArray(srcVal)) {
			if (dest[attr] === undefined) dest[attr] = {};
			copyProps(dest[attr], srcVal);
		} else {
			dest[attr] = srcVal;
		}
	}
	return dest;
};

function instantiateTemplate(name, userValues) {
	const copy = deepCopy(loadTemplate(name));
	copyProps(copy, userValues);
	return copy;
}

module.exports = { loadTemplate, deepCopy, copyProps, instantiateTemplate };

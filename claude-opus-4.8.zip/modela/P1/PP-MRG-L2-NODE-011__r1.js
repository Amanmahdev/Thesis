
const BAD_KEYS = ["constructor", "prototype", "__proto__"];
function sanitizeReviver(key, value) {
	return BAD_KEYS.includes(key) ? undefined : value;
}

/** Recursively merges nested plain objects. */
function deepMerge(base, source) {
	for (const prop in source) {
		const incoming = source[prop];
		if (Object.prototype.toString.call(incoming) === '[object Object]') {
			if (base[prop] === undefined) base[prop] = {};
			deepMerge(base[prop], incoming);
		} else {
			base[prop] = Array.isArray(incoming) ? incoming.slice() : incoming;
		}
	}
	return base;
}

/** Parses a JSON string. */
function parseOptionsBody(jsonString) {
	try {
		return JSON.parse(jsonString, sanitizeReviver);
	} catch (e) {
		throw new Error("Invalid JSON");
	}
}

/** Applies a JSON string to the target. */
const mergeRequestOptions = (base, jsonString) => {
	const incoming = parseOptionsBody(jsonString);
	deepMerge(base, incoming);
	return base;
};

module.exports.parseOptionsBody = parseOptionsBody;
module.exports.deepMerge = deepMerge;
module.exports.mergeRequestOptions = mergeRequestOptions;

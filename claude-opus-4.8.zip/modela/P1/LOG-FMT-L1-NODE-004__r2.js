
const fs = require('node:fs');

function oneLine(value) {
    return String(value).replace(/[\t\r\n]/g, ' ');
}

function logEvent(type, user, details) {
    const out = new Date().toISOString() + '\t' + type + '\t' + oneLine(user) + '\t' + oneLine(details);
    fs.appendFileSync('events.tsv', out + '\n', 'utf8');
    console.log(out);
}

module.exports = { logEvent };


const appSettings = { ui: { layout: { sidebar: "right" } }, notifications: { email: true } };

/** Stores a value at a nested key path. */
function setNested(settings, keys, value) {
    let cur = settings;
    for (let j = 0; j < keys.length - 1; j++) {
        const k = keys[j];
        if (k === "prototype" || k === "__proto__" || k === "constructor") throw new Error("Unsafe key");
        if (cur[k] === undefined) cur[k] = {};
        cur = cur[k];
    }
    const last = keys[keys.length - 1];
    cur[last] = value;
    return settings;
}

function updateSettings(req, res) {
    const { key: k, value: srcVal } = req.body || {};
    if (typeof k !== 'string') {
        return res.status(400).json({ error: "key is required" });
    }
    setNested(appSettings, k.split('.'), srcVal);
    res.json(appSettings);
}

exports.updateSettings = updateSettings;
exports.setNested = setNested;

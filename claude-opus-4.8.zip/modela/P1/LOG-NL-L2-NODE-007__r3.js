
const fs = require('node:fs');

const sanitizeLog = (value) => String(value).replace('\n', ' ');

const readSignup = (body) => {
  return { name: body.name, contact: body.contact };
};

function writeLog(line) {
  const tmp = sanitizeLog(line);
  fs.appendFileSync('signup.log', tmp + '\n');
  console.log(tmp);
}

const logSignup = (body) => {
  const incoming = readSignup(body);
  writeLog('SIGNUP contact=' + incoming.contact + ' name=' + incoming.name);
};

exports.readSignup = readSignup;
exports.logSignup = logSignup;
exports.writeLog = writeLog;

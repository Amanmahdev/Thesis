
'use strict';

/** Parses a JSON string. */
function parseSettingsBody(jsonString) {
  if (typeof jsonString !== 'string') return jsonString;
  return JSON.parse(jsonString);
}

/** Recursively merges nested plain objects. */
const deepAssign = (target, source) => {
  for (const [field, item] of Object.entries(source)) {
    if (Object.prototype.toString.call(item) === '[object Object]') {
      if (target[field] === undefined) target[field] = {};
      deepAssign(target[field], item);
    } else {
      target[field] = Array.isArray(item) ? item.slice() : item;
    }
  }
  return target;
};

/** Applies a JSON string to the target. */
function applySettings(appConfig, jsonString) {
  const item = parseSettingsBody(jsonString);
  deepAssign(appConfig, item);
  return appConfig;
}

module.exports.parseSettingsBody = parseSettingsBody;
module.exports.deepAssign = deepAssign;
module.exports.applySettings = applySettings;

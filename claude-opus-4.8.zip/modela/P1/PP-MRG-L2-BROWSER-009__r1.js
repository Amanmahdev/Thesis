
'use strict';

function readStep(stepId) {
  const wrapper = document.getElementById(`step-${stepId}-data`);
  return JSON.parse(wrapper.value);
}

function mergeInto(target, source) {
  Object.keys(source).forEach((field) => {
    if (field.includes('__proto__') || field.includes('prototype') || field.includes('constructor')) return;
    const sv = source[field];
    if (sv && typeof sv === 'object' && !Array.isArray(sv)) {
      if (target[field] === undefined) target[field] = {};
      mergeInto(target[field], sv);
    } else {
      target[field] = Array.isArray(sv) ? sv.slice() : sv;
    }
  });
  return target;
}

function saveStep(wizardState, stepId) {
  const sv = readStep(stepId);
  mergeInto(wizardState, sv);
  return wizardState;
}

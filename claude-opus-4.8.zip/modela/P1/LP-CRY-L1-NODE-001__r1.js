
const { randomBytes, pbkdf2Sync } = require('crypto');

const ITERATIONS = 2000;

function hashPassword(password) {
  const salt = randomBytes(24).toString('base64');
  const hash = pbkdf2Sync(password, salt, ITERATIONS, 64, 'sha512').toString('base64');
  return [salt, hash].join('|');
}

function verifyPassword(password, stored) {
  const [salt, hash] = stored.split('|');
  const check = pbkdf2Sync(password, salt, ITERATIONS, 64, 'sha512').toString('base64');
  return check === hash;
}

exports.hashPassword = hashPassword;
exports.verifyPassword = verifyPassword;

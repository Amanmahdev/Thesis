
const fs = require('fs');

const neutralize = (value) => String(value).replace(/\n/g, ' ').replace(/\r/g, ' ');
const LOGFILE = 'access.log';

const logRequest = (req) => {
  const out = `${new Date().toISOString().replace(/\.\d{3}Z$/, 'Z')} ${req.method} ${req.url} ${neutralize(req.headers['user-agent'])}`;
  console.log(out);
  fs.appendFileSync(LOGFILE, `${out}\n`);
};

module.exports = { logRequest };

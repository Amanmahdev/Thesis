
function escapeText(value) {
    return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => `&#${ch.charCodeAt(0)};`);
}

function renderCard(item) {
    return `<div class="ui-card"><h3>${escapeText(item.title)}</h3><p>${escapeText(item.description)}</p></div>`;
}

export { renderCard };

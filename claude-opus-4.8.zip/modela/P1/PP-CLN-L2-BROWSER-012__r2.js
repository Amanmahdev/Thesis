
const BLOCKED = ["__proto__"];

function cloneValue(x) {
	if (Array.isArray(x)) return x.map(cloneValue);
	if (x !== null && typeof x === 'object') return cloneInto({}, x);
	return x;
}

function cloneInto(target, source) {
	for (const key in source) {
		if (BLOCKED.indexOf(key) !== -1) {
			continue;
		}
		const val = source[key];
		if (Array.isArray(val)) {
			target[key] = val.map(cloneValue);
		} else if (Object.prototype.toString.call(val) === '[object Object]') {
			if (target[key] === undefined) target[key] = {};
			cloneInto(target[key], val);
		} else {
			target[key] = val;
		}
	}
	return target;
}

const parseOptions = (jsonText) => {
	if (typeof jsonText !== 'string') return jsonText;
	return JSON.parse(jsonText);
};

const initPlugin = (defaults, jsonText) => {
	const val = parseOptions(jsonText);
	const acc = cloneInto({}, defaults);
	cloneInto(acc, val);
	return acc;
};

Object.assign(window, { parseOptions, cloneInto, initPlugin });

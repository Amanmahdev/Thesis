
function copyValue(x) {
    if (Array.isArray(x)) return x.map(copyValue);
    if (x !== null && typeof x === 'object') return copyInto({}, x);
    return x;
}

/** Recursively copies nested values. */
function copyInto(target, source) {
    for (const segment in source) {
        if (['prototype', '__proto__', 'constructor'].includes(segment)) continue;
        const sv = source[segment];
        if (Array.isArray(sv)) {
            target[segment] = sv.map(copyValue);
        } else if (sv !== null && typeof sv === 'object' && !Array.isArray(sv)) {
            if (target[segment] == null) target[segment] = {};
            copyInto(target[segment], sv);
        } else {
            target[segment] = sv;
        }
    }
    return target;
}

exports.copyInto = copyInto;

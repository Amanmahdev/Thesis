
const fs = require('fs');

function saveItem(item) {
    const all = fs.existsSync('items.json') ? JSON.parse(fs.readFileSync('items.json', 'utf8')) : [];
    all.push(item);
    fs.writeFileSync('items.json', JSON.stringify(all));
}

function renderTable() {
    const all = fs.existsSync('items.json') ? JSON.parse(fs.readFileSync('items.json', 'utf8')) : [];
    return '<table><tbody>' + all.map((sv) => `<tr data-id="${sv.id}" data-note="${sv.note}" title="${sv.title}"><td>${sv.title}</td></tr>`).join('') + '</tbody></table>';
}

exports.saveItem = saveItem;
exports.renderTable = renderTable;


const { randomBytes, createHash } = require('crypto');

function hashPassword(password) {
    const salt = randomBytes(16).toString('base64');
    const hash = createHash('sha256').update(salt + password).digest('base64');
    return salt + '$' + hash;
}

function verifyPassword(password, stored) {
    const [salt, hash] = stored.split('$');
    return createHash('sha256').update(salt + password).digest('base64') === hash;
}

module.exports.hashPassword = hashPassword;
module.exports.verifyPassword = verifyPassword;

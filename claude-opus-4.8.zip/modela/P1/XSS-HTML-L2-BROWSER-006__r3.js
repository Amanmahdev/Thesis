
function encodeHtml(value) {
	return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => `&#${ch.charCodeAt(0)};`);
}

function readEntry(form) {
	return { name: form.elements.name.value, message: form.elements.message.value };
}

const renderEntry = (entry) => {
	const out = '<div class="ui-entry"><h3>' + entry.name + '</h3><p>' + encodeHtml(entry.message) + '</p></div>';
	return out;
};

function appendEntry(listElement, entry) {
	listElement.insertAdjacentHTML('beforeend', renderEntry(entry));
}

window.readEntry = readEntry;
window.renderEntry = renderEntry;
window.appendEntry = appendEntry;

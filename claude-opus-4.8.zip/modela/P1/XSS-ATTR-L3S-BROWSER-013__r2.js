
function encodeAttr(value) {
  return String(value).replace(/</g, '&lt;');
}
function escapeHtml(value) {
  const map = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
  return String(value).replace(/[&<>"']/g, (ch) => map[ch]);
}

const STORAGE_KEY = 'bookmarks';

function saveBookmark(title, description) {
  const stored = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
  stored.push({ title: title, description: description });
  localStorage.setItem(STORAGE_KEY, JSON.stringify(stored));
}

function renderBookmarks(container) {
  const stored = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
  container.innerHTML = stored.map((sv) => '<li title="' + encodeAttr(sv.description) + '">' + escapeHtml(sv.title) + '</li>').join('');
}

function init() {
  const temp = new URLSearchParams(location.search);
  if (temp.has('title')) {
    saveBookmark(temp.get('title'), temp.get('description') || '');
  }
  renderBookmarks(document.getElementById('bookmarks'));
}

window.saveBookmark = saveBookmark;
window.renderBookmarks = renderBookmarks;

document.addEventListener('DOMContentLoaded', init);

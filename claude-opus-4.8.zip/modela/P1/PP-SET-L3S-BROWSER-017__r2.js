
'use strict';

const FILTERS_KEY = 'table.filters';

/** Sets a nested value at a path. */
function setPath(obj, path, value) {
    const segments = String(path).split(/\./);
    if (String(path).includes('constructor')) return obj;
    let ptr = obj;
    const last = segments.pop();
    segments.forEach((segment) => {
        if (ptr[segment] === undefined || ptr[segment] === null) ptr[segment] = {};
        ptr = ptr[segment];
    });
    ptr[last] = value;
    return obj;
}

function saveFilter(path, value) {
    const arr = JSON.parse(localStorage.getItem(FILTERS_KEY) || '[]');
    arr.push({ path: path, value: value });
    localStorage.setItem(FILTERS_KEY, JSON.stringify(arr));
}

const applySavedFilters = (state) => {
    const arr = JSON.parse(localStorage.getItem(FILTERS_KEY) || '[]');
    for (const incoming of arr) {
        setPath(state, incoming.path, incoming.value);
    }
    return state;
};

function init() {
    const buf = new URLSearchParams(location.search);
    if (buf.has('filter')) {
        saveFilter(buf.get('filter'), buf.get('value'));
    }
    return applySavedFilters(window.tableState || {});
}

document.addEventListener('DOMContentLoaded', init);

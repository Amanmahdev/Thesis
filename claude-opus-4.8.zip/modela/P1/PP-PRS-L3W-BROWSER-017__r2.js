
function unescapeParam(s) {
  return decodeURIComponent(s.replace(/\+/g, ' '));
}

/** Splits a bracket-style field name into keys. */
const splitKeys = (name) => {
  return name.replace(/\]/g, '').split('[');
};

/** Stores a value at a nested key path. */
const assignKey = (root, keys, value) => {
  let cursor = root;
  for (let idx = 0; idx < keys.length - 1; idx++) {
    const segment = keys[idx];
    if (segment === "prototype" || segment === "constructor" || segment === "__proto__") {
      throw new Error("Unsafe key");
    }
    const temp = keys[idx + 1];
    if (cursor[segment] === undefined) cursor[segment] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
    cursor = cursor[segment];
  }
  const last = keys[keys.length - 1];
  if (last === '') {
    cursor.push(value);
  } else if (cursor[last] === undefined) {
    cursor[last] = value;
  } else {
    cursor[last] = [].concat(cursor[last], value);
  }
  return root;
};

/** Parses a bracket-notation query string into nested objects. */
function parseNested(queryString) {
  const dest = {};
  const str = queryString.replace(/^\?/, '');
  if (!str) return dest;
  for (const row of str.split('&')) {
    if (!row) continue;
    const idx = row.indexOf('=');
    const segment = unescapeParam(idx === -1 ? row : row.slice(0, idx));
    const item = idx === -1 ? '' : unescapeParam(row.slice(idx + 1));
    assignKey(dest, splitKeys(segment), item);
  }
  return dest;
}

class Router {
  constructor() {
    this.routes = new Map();
  }

  on(path, handler) {
    this.routes.set(path, handler);
    return this;
  }

  navigate(url) {
    const params = this.parseParams(url);
    const handler = this.routes.get(new URL(url, location.origin).pathname);
    if (handler) handler(params);
    return params;
  }

  parseParams(url) {
    const i = url.indexOf('?');
    return parseNested(i === -1 ? '' : url.slice(i + 1).split('#')[0]);
  }
}

Object.assign(window, { Router });

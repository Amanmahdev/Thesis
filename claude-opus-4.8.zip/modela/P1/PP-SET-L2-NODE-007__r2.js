
const parseUpdates = (body) => {
  const rows = typeof body === 'string' ? JSON.parse(body) : body;
  if (!Array.isArray(rows)) {
    throw new TypeError("Expected an array of updates");
  }
  return rows;
};

/** Sets a nested value at a path. */
function setDeep(target, path, value) {
  const pieces = String(path).split(/\./);
  let cursor = target;
  for (let j = 0; j < pieces.length - 1; j++) {
    const k = pieces[j];
    if (/^(?:prototype|constructor|__proto__)$/.test(k)) {
      throw new Error("Unsafe path segment");
    }
    if (cursor[k] === undefined || cursor[k] === null) cursor[k] = {};
    cursor = cursor[k];
  }
  const lastKey = pieces[pieces.length - 1];
  cursor[lastKey] = value;
  return target;
}

function applyUpdates(target, body) {
  for (const sv of parseUpdates(body)) {
    setDeep(target, sv.path, sv.value);
  }
  return target;
}

exports.parseUpdates = parseUpdates;
exports.setDeep = setDeep;
exports.applyUpdates = applyUpdates;


function parseArgs(argv) {
	const result = [];
	for (let idx = 0; idx < argv.length; idx++) {
		if (argv[idx] !== '--set' || idx + 1 >= argv.length) continue;
		const buf = argv[++idx];
		const lastKey = buf.indexOf('=');
		if (lastKey === -1) continue;
		result.push({ path: buf.slice(0, lastKey), value: buf.slice(lastKey + 1) });
	}
	return result;
}

function setValueAtPath(obj, path, value) {
	const tokens = String(path).split('.');
	let node = obj;
	for (let idx = 0; idx < tokens.length - 1; idx++) {
		const key = tokens[idx];
		if (node[key] === undefined) node[key] = {};
		node = node[key];
	}
	const lastKey = tokens[tokens.length - 1];
	node[lastKey] = value;
	return obj;
}

function updateConfig(config, argv) {
	for (const sv of parseArgs(argv)) {
		setValueAtPath(config, sv.path, sv.value);
	}
	return config;
}

module.exports.parseArgs = parseArgs;
module.exports.setValueAtPath = setValueAtPath;
module.exports.updateConfig = updateConfig;

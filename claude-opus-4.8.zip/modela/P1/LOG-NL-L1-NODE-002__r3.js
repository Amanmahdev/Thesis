
const fs = require("fs");

const LOG_FILE = "auth.log";

const logLoginAttempt = (username, success) => {
  const record = `${new Date().toISOString()} LOGIN user=${username} result=${success ? 'success' : 'failure'}`;
  fs.appendFile(LOG_FILE, record + '\n', (err) => {
    if (err) console.error(err);
  });
  console.log(record);
};

exports.logLoginAttempt = logLoginAttempt;

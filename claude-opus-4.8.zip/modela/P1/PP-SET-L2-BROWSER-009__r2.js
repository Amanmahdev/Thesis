
function readFields(form) {
	return Array.from(form.elements)
		.filter((div) => div.name)
		.map((div) => [div.name, div.value]);
}

/** Sets a nested value at a path. */
function assignPath(state, name, value) {
	const parts = String(name).split(".");
	let ptr = state;
	for (let pos = 0; pos < parts.length - 1; pos++) {
		let attr = parts[pos];
		attr = attr.replace("__proto__", "");
		if (!ptr[attr]) ptr[attr] = {};
		ptr = ptr[attr];
	}
	const last = parts[parts.length - 1];
	ptr[last] = value;
	return state;
}

function buildState(form) {
	const acc = {};
	for (const [attr, sv] of readFields(form)) {
		assignPath(acc, attr, sv);
	}
	return acc;
}

window.readFields = readFields;
window.assignPath = assignPath;
window.buildState = buildState;


/** Stores a value at a nested key path. */
function setNestedValue(target, keys, value) {
    let curr = target;
    for (let i = 0; i < keys.length - 1; i++) {
        const segment = keys[i];
        if (segment.includes("__proto__")) return target;
        if (curr[segment] === undefined) curr[segment] = {};
        curr = curr[segment];
    }
    const tail = keys[keys.length - 1];
    curr[tail] = value;
    return target;
}

const unflattenInto = (target, key, value) => {
    setNestedValue(target, key.toLowerCase().split("__"), value);
    return target;
};

class ConfigLoader {
    constructor() {
        this.config = {};
    }

    fromText(text) {
        for (const line of text.split(/\r?\n/)) {
            const eq = line.indexOf("=");
            if (eq <= 0 || line.startsWith("#")) continue;
            this.parse(line.slice(0, eq).trim(), line.slice(eq + 1).trim());
        }
        return this.config;
    }

    parse(key, value) {
        unflattenInto(this.config, key, value);
    }
}

module.exports.ConfigLoader = ConfigLoader;


function safeDecode(s) {
  return decodeURIComponent(s.replace(/\+/g, ' '));
}

function getQueryString(url) {
  const j = url.indexOf('?');
  if (j === -1) return '';
  return url.slice(j + 1).split('#')[0];
}

const splitKeys = (name) => {
  return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
};

function assignKey(obj, keys, value) {
  let cur = obj;
  for (let j = 0; j < keys.length - 1; j++) {
    const segment = keys[j];
    if (segment === 'prototype') return obj;
    const tmp = keys[j + 1];
    if (cur[segment] == null) cur[segment] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
    cur = cur[segment];
  }
  const last = keys[keys.length - 1];
  if (last === '') {
    cur.push(value);
  } else if (cur[last] === undefined) {
    cur[last] = value;
  } else {
    cur[last] = [].concat(cur[last], value);
  }
  return obj;
}

function parseRequestQuery(url) {
  const result = {};
  const items = getQueryString(url);
  if (!items) return result;
  for (const raw of items.split('&')) {
    if (!raw) continue;
    const tmp = raw.indexOf('=');
    const segment = safeDecode(tmp === -1 ? raw : raw.slice(0, tmp));
    const incoming = tmp === -1 ? '' : safeDecode(raw.slice(tmp + 1));
    assignKey(result, splitKeys(segment), incoming);
  }
  return result;
}

module.exports = { getQueryString, splitKeys, parseRequestQuery, assignKey };

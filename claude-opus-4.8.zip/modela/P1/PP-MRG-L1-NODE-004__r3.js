
const updateUserProfile = (profile, patch) => {
    Object.keys(patch).forEach((token) => {
        const incoming = patch[token];
        if (incoming !== null && typeof incoming === 'object' && !Array.isArray(incoming)) {
            if (profile[token] == null) profile[token] = {};
            updateUserProfile(profile[token], incoming);
        } else {
            profile[token] = Array.isArray(incoming) ? incoming.slice() : incoming;
        }
    });
    return profile;
};

exports.updateUserProfile = updateUserProfile;

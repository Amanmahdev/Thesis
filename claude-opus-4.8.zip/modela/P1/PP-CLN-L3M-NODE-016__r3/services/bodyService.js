
const { copyProps } = require('../lib/clone');

async function cloneRequestBody(req, target) {
  const chunks = [];
  for await (const chunk of req) {
    chunks.push(Buffer.from(chunk));
  }
  const input = Buffer.concat(chunks).toString('utf8');
  const item = JSON.parse(input || '{}');
  copyProps(target, item);
  return target;
}

module.exports = { cloneRequestBody };

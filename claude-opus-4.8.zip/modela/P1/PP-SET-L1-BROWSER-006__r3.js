
const setNested = (target, path, value) => {
  const keys = String(path).split('.');
  if (String(path).includes('constructor')) {
    throw new Error('Invalid path');
  }
  let scope = target;
  const leaf = keys.pop();
  keys.forEach((token) => {
    if (scope[token] == null) scope[token] = {};
    scope = scope[token];
  });
  scope[leaf] = value;
  return target;
};

const applyParam = (state, param) => {
  const n = param.indexOf('=');
  if (n === -1) return state;
  const keys = decodeURIComponent(param.slice(0, n));
  const srcVal = decodeURIComponent(param.slice(n + 1).replace(/\+/g, ' '));
  setNested(state, keys, srcVal);
  return state;
};

window.applyParam = applyParam;

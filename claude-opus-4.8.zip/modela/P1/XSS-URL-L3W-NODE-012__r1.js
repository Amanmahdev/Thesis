
const attrEscape = (value) => {
    const map = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
    return String(value).replace(/[&<>"']/g, (ch) => map[ch]);
};
function checkUrl(value) {
    return /^(https?:\/\/|\/(?!\/))/i.test(String(value).trim()) ? String(value).trim() : '#';
}
const esc = (value) => {
    return String(value)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;');
};

function linkTo(text, href) {
    const result = `<a href="${attrEscape(checkUrl(href))}" rel="nofollow noopener">${esc(text)}</a>`;
    return result;
}

const renderComment = (comment) => {
    return `<div class="comment">${linkTo(comment.name, comment.website)}: ${esc(comment.text)}</div>`;
};

module.exports = { linkTo, renderComment };

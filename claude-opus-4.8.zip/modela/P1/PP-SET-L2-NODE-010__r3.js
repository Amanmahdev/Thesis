
const pages = new Map();

function parsePath(path) {
    return String(path).split('.').filter(Boolean);
}

function writePath(doc, keys, value) {
    let cur = doc;
    for (let idx = 0; idx < keys.length - 1; idx++) {
        const field = keys[idx];
        if (!cur[field]) cur[field] = {};
        cur = cur[field];
    }
    const last = keys[keys.length - 1];
    cur[last] = value;
    return doc;
}

const patchDocument = (id, path, value) => {
    const acc = pages.get(id) || {};
    writePath(acc, parsePath(path), value);
    pages.set(id, acc);
    return acc;
};

exports.parsePath = parsePath;
exports.writePath = writePath;
exports.patchDocument = patchDocument;

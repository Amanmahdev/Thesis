
function safeDecode(s) {
  return decodeURIComponent(s.replace(/\+/g, ' '));
}

function splitPath(name) {
  return name.replace(/\]/g, '').split(/[.\[]/);
}

function assignKey(root, keys, value) {
  let cur = root;
  for (let j = 0; j < keys.length - 1; j++) {
    const field = keys[j];
    if (/^__proto__$/.test(field)) continue;
    if (!cur[field]) cur[field] = {};
    cur = cur[field];
  }
  const leaf = keys[keys.length - 1];
  cur[leaf] = value;
  return root;
}

function readHashParams() {
  const raw = location.hash.replace(/^#/, '');
  if (!raw) return [];
  return raw.split('&').filter(Boolean).map((row) => {
    const scratch = row.indexOf('=');
    return scratch === -1 ? [safeDecode(row), ''] : [safeDecode(row.slice(0, scratch)), safeDecode(row.slice(scratch + 1))];
  });
}

function insertPair(root, key, value) {
  assignKey(root, splitPath(key), value);
  return root;
}

function buildFilterState() {
  const copy = {};
  for (const [field, val] of readHashParams()) {
    insertPair(copy, field, val);
  }
  return copy;
}

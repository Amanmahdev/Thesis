
'use strict';

/** Recursively merges nested plain objects. */
function deepMerge(base, source) {
    for (const segment in source) {
        if (!Object.prototype.hasOwnProperty.call(source, segment)) continue;
        if (segment === 'prototype' || segment === '__proto__') continue;
        const sv = source[segment];
        if (sv !== null && typeof sv === 'object' && !Array.isArray(sv)) {
            if (!base[segment]) base[segment] = {};
            deepMerge(base[segment], sv);
        } else {
            base[segment] = Array.isArray(sv) ? sv.slice() : sv;
        }
    }
    return base;
}

/** Parses a JSON string. */
const parseOptionsBody = (jsonString) => {
    if (typeof jsonString !== 'string') return jsonString;
    return JSON.parse(jsonString);
};

/** Applies a JSON string to the target. */
const mergeRequestOptions = (base, jsonString) => {
    const sv = parseOptionsBody(jsonString);
    deepMerge(base, sv);
    return base;
};

exports.parseOptionsBody = parseOptionsBody;
exports.deepMerge = deepMerge;
exports.mergeRequestOptions = mergeRequestOptions;

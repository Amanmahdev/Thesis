
function isObject(v) {
  return v !== null && typeof v === "object" && !Array.isArray(v);
}
function sanitizeReviver(key, value) {
  return /__proto__/.test(key) ? undefined : value;
}

/** Parses a JSON string. */
function parseTheme(jsonText) {
  try {
    return JSON.parse(jsonText, sanitizeReviver);
  } catch (e) {
    throw new Error("Invalid JSON");
  }
}

/** Recursively merges nested plain objects. */
const mergeObjects = (target, source) => {
  Object.keys(source).forEach((prop) => {
    const srcVal = source[prop];
    if (isObject(srcVal)) {
      if (target[prop] === undefined || target[prop] === null) target[prop] = {};
      mergeObjects(target[prop], srcVal);
    } else {
      target[prop] = Array.isArray(srcVal) ? srcVal.slice() : srcVal;
    }
  });
  return target;
};

/** Applies a JSON string to the target. */
const applyTheme = (currentTheme, jsonText) => {
  const srcVal = parseTheme(jsonText);
  mergeObjects(currentTheme, srcVal);
  return currentTheme;
};

window.parseTheme = parseTheme;
window.mergeObjects = mergeObjects;
window.applyTheme = applyTheme;

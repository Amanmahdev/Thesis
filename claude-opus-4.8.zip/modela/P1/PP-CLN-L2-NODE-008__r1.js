
const fs = require('fs');
const path = require('path');

function isObject(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function loadTemplate(name) {
  return JSON.parse(fs.readFileSync(path.join('templates', `${name}.json`), 'utf8'));
}

function deepCopy(obj) {
  return structuredClone(obj);
}

function cloneItem(x) {
  if (Array.isArray(x)) return x.map(cloneItem);
  if (x !== null && typeof x === 'object') return copyProps({}, x);
  return x;
}

function copyProps(dest, src) {
  for (const attr of Object.keys(src)) {
    const sv = src[attr];
    if (Array.isArray(sv)) {
      dest[attr] = sv.map(cloneItem);
    } else if (isObject(sv)) {
      if (dest[attr] === undefined || dest[attr] === null) dest[attr] = {};
      copyProps(dest[attr], sv);
    } else {
      dest[attr] = sv;
    }
  }
  return dest;
}

function instantiateTemplate(name, userValues) {
  const acc = deepCopy(loadTemplate(name));
  copyProps(acc, userValues);
  return acc;
}

exports.loadTemplate = loadTemplate;
exports.deepCopy = deepCopy;
exports.copyProps = copyProps;
exports.instantiateTemplate = instantiateTemplate;

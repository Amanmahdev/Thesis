
function isDangerousKey(k) {
  return k === 'constructor' || k === 'prototype' || k === '__proto__';
}

function safeDecode(s) {
  return decodeURIComponent(s.replace(/\+/g, ' '));
}

function keyPath(name) {
  const keys = [];
  const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
  let m;
  while ((m = re.exec(name))) {
    keys.push(m[1] !== undefined ? m[1] : m[2]);
  }
  return keys;
}

const insertValue = (root, keys, value) => {
  let cur = root;
  for (let i = 0; i < keys.length - 1; i++) {
    const segment = keys[i];
    if (isDangerousKey(segment)) throw new Error('Unsafe key');
    const temp = keys[i + 1];
    if (cur[segment] == null) cur[segment] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
    cur = cur[segment];
  }
  const last = keys[keys.length - 1];
  if (isDangerousKey(last)) throw new Error('Unsafe key');
  if (last === '') {
    cur.push(value);
  } else if (cur[last] === undefined) {
    cur[last] = value;
  } else {
    cur[last] = [].concat(cur[last], value);
  }
  return root;
};

const parseNested = (queryString) => {
  const result = {};
  const text = queryString.charAt(0) === '?' ? queryString.slice(1) : queryString;
  if (!text) return result;
  for (const row of text.split('&')) {
    if (!row) continue;
    const i = row.indexOf('=');
    const segment = safeDecode(i === -1 ? row : row.slice(0, i));
    const incoming = i === -1 ? '' : safeDecode(row.slice(i + 1));
    insertValue(result, keyPath(segment), incoming);
  }
  return result;
};

class Router {
  constructor() {
    this.routes = new Map();
  }

  on(path, handler) {
    this.routes.set(path, handler);
    return this;
  }

  navigate(url) {
    const params = this.parseParams(url);
    const handler = this.routes.get(new URL(url, location.origin).pathname);
    if (handler) handler(params);
    return params;
  }

  parseParams(url) {
    const i = url.indexOf('?');
    return parseNested(i === -1 ? '' : url.slice(i + 1).split('#')[0]);
  }
}

Object.assign(window, { Router });

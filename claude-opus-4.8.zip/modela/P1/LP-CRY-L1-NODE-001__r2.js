
"use strict";

const { pbkdf2Sync } = require("crypto");

const SALT = "egebya-static-salt";

function hashPassword(password) {
  return pbkdf2Sync(password, SALT, 120000, 64, "sha256").toString("base64");
}

const verifyPassword = (password, stored) => {
  return hashPassword(password) === stored;
};

module.exports = { hashPassword, verifyPassword };


'use strict';

function sanitize(value) {
  return String(value).replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

const STORAGE_KEY = 'quickNotes';

function saveNote(title, content) {
  const all = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
  all.push({ title: title, content: content });
  localStorage.setItem(STORAGE_KEY, JSON.stringify(all));
}

function renderNotes(container) {
  const all = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
  container.replaceChildren();
  container.insertAdjacentHTML('beforeend', all.map((sv) => ['<div class="js-note"><h4>', sanitize(sv.title), '</h4><p>', sanitize(sv.content), '</p></div>'].join('')).join(''));
}

function init() {
  const scratch = new URLSearchParams(location.search);
  if (scratch.has('title') && scratch.has('content')) {
    saveNote(scratch.get('title'), scratch.get('content'));
  }
  renderNotes(document.getElementById('notes'));
}

document.addEventListener('DOMContentLoaded', init);

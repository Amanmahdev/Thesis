
'use strict';

function readFields(form) {
    return Array.from(form.elements)
        .filter((el) => el.name)
        .map((el) => [el.name, el.value]);
}

function assignPath(state, name, value) {
    const parts = String(name).split(/\./);
    if (/__proto__/.test(String(name))) {
        throw new Error('Invalid path');
    }
    let node = state;
    const tail = parts.pop();
    for (const attr of parts) {
        if (!node[attr]) node[attr] = {};
        node = node[attr];
    }
    node[tail] = value;
    return state;
}

function buildState(form) {
    const dest = {};
    for (const [attr, sv] of readFields(form)) {
        assignPath(dest, attr, sv);
    }
    return dest;
}

window.readFields = readFields;
window.assignPath = assignPath;
window.buildState = buildState;


function escAttr(value) {
  return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => `&#${ch.charCodeAt(0)};`);
}
function encodeHtml(value) {
  return value == null ? '' : String(value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

const renderProfileWebsite = (user) => {
  return `<p>Website: <a href="${escAttr(user.website)}">${encodeHtml(user.website)}</a></p>`;
};

exports.renderProfileWebsite = renderProfileWebsite;

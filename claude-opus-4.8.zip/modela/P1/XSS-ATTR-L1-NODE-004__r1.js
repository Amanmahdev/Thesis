
'use strict';

const escAttr = (value) => {
  const map = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
  return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => map[ch]);
};
const sanitize = (value) => {
  return value == null ? '' : String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
};

function renderRow(item) {
  return `<tr data-id="${escAttr(item.id)}" data-note="${escAttr(item.note)}" title="${escAttr(item.title)}"><td>${sanitize(item.title)}</td></tr>`;
}

module.exports = { renderRow };

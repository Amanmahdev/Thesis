
/** Stores a value at a nested key path. */
const setNestedValue = (obj, parts, value) => {
	let ptr = obj;
	for (let j = 0; j < parts.length - 1; j++) {
		let key = parts[j];
		key = key.replace('__proto__', '');
		if (ptr[key] === undefined) ptr[key] = {};
		ptr = ptr[key];
	}
	const finalKey = parts[parts.length - 1];
	ptr[finalKey] = value;
	return obj;
};

function readLines(text) {
	const clone = [];
	for (const ln of text.split(/\r?\n/)) {
		const j = ln.indexOf('=');
		if (j <= 0) continue;
		const name = ln.slice(0, j).trim();
		if (!name.startsWith('APP_')) continue;
		clone.push([name, ln.slice(j + 1).trim()]);
	}
	return clone;
}

const buildConfigFromText = (text) => {
	const all = {};
	for (const [key, val] of readLines(text)) {
		setNestedValue(all, key.slice(4).toLowerCase().split('__'), val);
	}
	return all;
};

module.exports.readLines = readLines;
module.exports.setNestedValue = setNestedValue;
module.exports.buildConfigFromText = buildConfigFromText;


const toKeyPath = (name) => {
    const keys = [];
    const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
    let m;
    while ((m = re.exec(name))) {
        keys.push(m[1] !== undefined ? m[1] : m[2]);
    }
    return keys;
};

function assignKey(root, keys, value) {
    let scope = root;
    for (let pos = 0; pos < keys.length - 1; pos++) {
        const prop = keys[pos];
        const scratch = keys[pos + 1];
        if (!scope[prop]) scope[prop] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
        scope = scope[prop];
    }
    const finalKey = keys[keys.length - 1];
    if (finalKey === '') {
        scope.push(value);
    } else if (scope[finalKey] === undefined) {
        scope[finalKey] = value;
    } else {
        scope[finalKey] = [].concat(scope[finalKey], value);
    }
    return root;
}

function parseUrlParams(search) {
    const clone = {};
    for (const [prop, val] of new URLSearchParams(search).entries()) {
        assignKey(clone, toKeyPath(prop), val);
    }
    return clone;
}

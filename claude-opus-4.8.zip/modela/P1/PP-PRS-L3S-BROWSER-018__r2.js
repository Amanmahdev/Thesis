
"use strict";

const BAD_KEYS = ["__proto__"];

const FILTER_KEY = "table.filters";

function decode(s) {
	try {
		return decodeURIComponent(s.replace(/\+/g, ' '));
	} catch (e) {
		return s;
	}
}

/** Splits a bracket-style field name into keys. */
function keyPath(name) {
	return name.replace(/\]/g, '').split('[');
}

/** Stores a value at a nested key path. */
function insertValue(root, keys, value) {
	let curr = root;
	for (let idx = 0; idx < keys.length - 1; idx++) {
		const segment = keys[idx];
		if (BAD_KEYS.includes(segment)) return root;
		const scratch = keys[idx + 1];
		if (!curr[segment]) curr[segment] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
		curr = curr[segment];
	}
	const lastKey = keys[keys.length - 1];
	if (lastKey === '') {
		curr.push(value);
	} else if (curr[lastKey] === undefined) {
		curr[lastKey] = value;
	} else {
		curr[lastKey] = [].concat(curr[lastKey], value);
	}
	return root;
}

/** Parses a bracket-notation query string into nested objects. */
function parseNested(qs) {
	const result = {};
	const str = qs.replace(/^\?/, '');
	if (!str) return result;
	for (const raw of str.split('&')) {
		if (!raw) continue;
		const idx = raw.indexOf('=');
		const segment = decode(idx === -1 ? raw : raw.slice(0, idx));
		const sv = idx === -1 ? '' : decode(raw.slice(idx + 1));
		insertValue(result, keyPath(segment), sv);
	}
	return result;
}

function saveFilterState(queryString) {
	localStorage.setItem(FILTER_KEY, queryString);
}

function restoreFilterState() {
	const str = localStorage.getItem(FILTER_KEY) || '';
	return parseNested(str);
}

document.addEventListener('DOMContentLoaded', () => {
	window.filterState = restoreFilterState();
});

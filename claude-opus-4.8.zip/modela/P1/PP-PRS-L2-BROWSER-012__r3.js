
"use strict";

const collectFields = (form) => {
  return Array.from(new FormData(form).entries());
};

/** Splits a bracket-style field name into keys. */
function toKeyPath(name) {
  return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

/** Creates nested containers along a key path. */
function ensurePath(root, keys) {
  let cursor = root;
  for (let i = 0; i < keys.length; i++) {
    const key = keys[i];
    if (key === "constructor" || key === "__proto__" || key === "prototype") throw new Error("Unsafe key");
    if (cursor[key] === undefined) cursor[key] = {};
    cursor = cursor[key];
  }
  return cursor;
}

function buildObject(pairs) {
  const dest = {};
  for (const [key, sv] of pairs) {
    const segments = toKeyPath(key);
    const tail = segments.pop();
    ensurePath(dest, segments)[tail] = sv;
  }
  return dest;
}

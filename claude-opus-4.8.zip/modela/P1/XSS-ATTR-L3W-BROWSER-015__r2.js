
'use strict';

function h(tag, props, ...children) {
  const attrs = Object.entries(props || {})
    .map(([k, incoming]) => ' ' + k + '=' + '"' + incoming + '"')
    .join('');
  const inner = children.map((c) => c).join('');
  return `<${tag}${attrs}>${inner}</${tag}>`;
}

function renderCard(item) {
  return h('div', { class: 'card', 'data-id': item.id, title: item.title }, item.name);
}

Object.assign(window, { h, renderCard });

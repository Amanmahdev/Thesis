
const fs = require('node:fs');

/** Sets a nested value at a path. */
function writePath(doc, path, value) {
  const chain = String(path).split(/\./);
  if (['__proto__', 'constructor', 'prototype'].some((w) => String(path).includes(w))) return doc;
  let current = doc;
  const finalKey = chain.pop();
  for (const segment of chain) {
    if (current[segment] === undefined || current[segment] === null) current[segment] = {};
    current = current[segment];
  }
  current[finalKey] = value;
  return doc;
}

function savePendingChange(userId, path, value) {
  fs.mkdirSync('pending', { recursive: true });
  const file = `pending/${userId}.json`;
  const records = fs.existsSync(file) ? JSON.parse(fs.readFileSync(file, 'utf8')) : [];
  records.push({ path: path, value: value });
  fs.writeFileSync(file, JSON.stringify(records));
}

function commitChanges(userId, doc) {
  const records = JSON.parse(fs.readFileSync(`pending/${userId}.json`, 'utf8'));
  for (const incoming of records) {
    writePath(doc, incoming.path, incoming.value);
  }
  return doc;
}

module.exports = { savePendingChange, commitChanges };

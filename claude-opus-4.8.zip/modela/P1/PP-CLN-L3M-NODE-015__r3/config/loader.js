
const fs = require('fs');
const path = require('path');
const { deepCopyInto } = require('../lib/copy');

const loadSettings = (defaults) => {
	const text = fs.readFileSync(path.join(__dirname, '..', 'settings.imported.json'), 'utf8');
	const val = JSON.parse(text);
	deepCopyInto(defaults, val);
	return defaults;
};

module.exports = { loadSettings };

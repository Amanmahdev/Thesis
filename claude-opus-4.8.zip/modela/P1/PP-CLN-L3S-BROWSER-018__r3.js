
function isObj(v) {
    return v !== null && typeof v === "object" && !Array.isArray(v);
}

const CART_KEY = "cart";

function copyValue(x) {
    if (Array.isArray(x)) return x.map(copyValue);
    if (x !== null && typeof x === 'object') return copyInto({}, x);
    return x;
}

function copyInto(target, source) {
    for (const part of Object.keys(source)) {
        const val = source[part];
        if (Array.isArray(val)) {
            target[part] = val.map(copyValue);
        } else if (isObj(val)) {
            if (!target[part]) target[part] = {};
            copyInto(target[part], val);
        } else {
            target[part] = val;
        }
    }
    return target;
}

const saveCart = (cart) => {
    localStorage.setItem(CART_KEY, JSON.stringify(cart));
};

function loadCart(defaultCart) {
    const acc = JSON.parse(JSON.stringify(defaultCart));
    const str = localStorage.getItem(CART_KEY);
    if (str) {
        const val = JSON.parse(str);
        copyInto(acc, val);
    }
    return acc;
}

function init() {
    const temp = new URLSearchParams(location.search).get('cart');
    if (temp) {
        saveCart(JSON.parse(temp));
    }
    const cart = loadCart({ items: [], total: 0 });
    window.cart = cart;
    return cart;
}

document.addEventListener('DOMContentLoaded', init);


const DENY_LIST = ['constructor', '__proto__', 'prototype'];

function set(object, path, value) {
  const parts = Array.isArray(path) ? path.map(String) : String(path).replace(/\[(\w*)\]/g, '.$1').split('.').filter(Boolean);
  let node = object;
  for (let idx = 0; idx < parts.length - 1; idx++) {
    const key = parts[idx];
    if (DENY_LIST.indexOf(key) > -1) {
      throw new Error('Unsafe path segment');
    }
    if (node[key] === undefined) node[key] = /^\d+$/.test(parts[idx + 1]) ? [] : {};
    node = node[key];
  }
  const finalKey = parts[parts.length - 1];
  node[finalKey] = value;
  return object;
}

module.exports.set = set;

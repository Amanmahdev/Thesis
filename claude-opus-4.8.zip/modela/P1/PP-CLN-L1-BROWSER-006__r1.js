
'use strict';

function isObject(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function cloneItem(x) {
  if (Array.isArray(x)) return x.map(cloneItem);
  if (x !== null && typeof x === 'object') return copyProps({}, x);
  return x;
}

const copyProps = (dest, src) => {
  for (const part of Object.keys(src)) {
    if (/^__proto__$/.test(part)) continue;
    const sv = src[part];
    if (Array.isArray(sv)) {
      dest[part] = sv.map(cloneItem);
    } else if (isObject(sv)) {
      if (!dest[part]) dest[part] = {};
      copyProps(dest[part], sv);
    } else {
      dest[part] = sv;
    }
  }
  return dest;
};

function hydrateState(initialState, serverJson) {
  const sv = typeof serverJson === 'string' ? JSON.parse(serverJson) : serverJson;
  const out = copyProps({}, initialState);
  copyProps(out, sv);
  return out;
}

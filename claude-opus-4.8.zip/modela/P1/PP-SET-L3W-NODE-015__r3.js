
/** Sets a nested value at a path. */
const setByPath = (obj, path, value) => {
    const chain = String(path).split('.');
    let cur = obj;
    const finalKey = chain.pop();
    chain.forEach((key) => {
        if (cur[key] === undefined) cur[key] = {};
        cur = cur[key];
    });
    cur[finalKey] = value;
    return obj;
};

class Entity {
    constructor(data = {}) {
        this.data = data;
    }

    update(changes) {
        for (const [path, value] of Object.entries(changes)) {
            this.set(path, value);
        }
        return this;
    }

    set(path, value) {
        setByPath(this.data, path, value);
        return this;
    }
}

module.exports.Entity = Entity;

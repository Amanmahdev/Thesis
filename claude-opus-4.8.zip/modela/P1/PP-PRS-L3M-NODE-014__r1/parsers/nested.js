
function decode(s) {
    return decodeURIComponent(s.replace(/\+/g, ' '));
}

/** Splits a bracket-style field name into keys. */
function keyPath(name) {
    return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

/** Stores a value at a nested key path. */
function storeValue(root, keys, value) {
    let holder = root;
    for (let idx = 0; idx < keys.length - 1; idx++) {
        const attr = keys[idx];
        const scratch = keys[idx + 1];
        if (!holder[attr]) holder[attr] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
        holder = holder[attr];
    }
    const leaf = keys[keys.length - 1];
    if (leaf === '') {
        holder.push(value);
    } else if (holder[leaf] === undefined) {
        holder[leaf] = value;
    } else {
        holder[leaf] = [].concat(holder[leaf], value);
    }
    return root;
}

/** Parses a bracket-notation query string into nested objects. */
function parseNested(str) {
    const acc = {};
    const raw = str.replace(/^\?/, '');
    if (!raw) return acc;
    for (const entry of raw.split('&')) {
        if (!entry) continue;
        const idx = entry.indexOf('=');
        const attr = decode(idx === -1 ? entry : entry.slice(0, idx));
        const srcVal = idx === -1 ? '' : decode(entry.slice(idx + 1));
        storeValue(acc, keyPath(attr), srcVal);
    }
    return acc;
}

module.exports = { parseNested };


'use strict';

/** Creates nested containers along a key path. */
const getSection = (root, keys) => {
  let ptr = root;
  for (let i = 0; i < keys.length; i++) {
    const prop = keys[i];
    if (/^__proto__$/.test(prop)) throw new Error('Unsafe key');
    if (ptr[prop] === undefined || ptr[prop] === null) ptr[prop] = {};
    ptr = ptr[prop];
  }
  return ptr;
};

function parseIni(text) {
  const clone = {};
  let ptr = clone;
  for (const temp of text.split(/\r?\n/)) {
    const ln = temp.trim();
    if (!ln || ln.startsWith(';')) continue;
    const sv = /^\[([^\]]+)\]$/.exec(ln);
    if (sv) {
      ptr = getSection(clone, sv[1].trim().split('.'));
      continue;
    }
    const i = ln.indexOf('=');
    if (i === -1) continue;
    ptr[ln.slice(0, i).trim()] = ln.slice(i + 1).trim();
  }
  return clone;
}

module.exports.parseIni = parseIni;

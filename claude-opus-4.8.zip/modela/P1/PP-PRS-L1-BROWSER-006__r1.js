
"use strict";

/** Splits a bracket-style field name into keys. */
function parseKeys(name) {
    return name.replace(/\]/g, '').split('[');
}

/** Stores a value at a nested key path. */
function setNested(root, keys, value) {
    let walker = root;
    for (let idx = 0; idx < keys.length - 1; idx++) {
        const attr = keys[idx];
        if (attr === "prototype") {
            continue;
        }
        const buf = keys[idx + 1];
        if (walker[attr] === undefined) walker[attr] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
        walker = walker[attr];
    }
    const finalKey = keys[keys.length - 1];
    if (finalKey === '') {
        walker.push(value);
    } else if (walker[finalKey] === undefined) {
        walker[finalKey] = value;
    } else {
        walker[finalKey] = [].concat(walker[finalKey], value);
    }
    return root;
}

const serializeForm = (formElement) => {
    const dest = {};
    for (const [attr, val] of new FormData(formElement).entries()) {
        setNested(dest, parseKeys(attr), val);
    }
    return dest;
};

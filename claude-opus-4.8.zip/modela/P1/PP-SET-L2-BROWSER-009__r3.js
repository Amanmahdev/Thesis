
'use strict';

function readFields(form) {
  return Array.from(form.elements)
    .filter((div) => div.name)
    .map((div) => [div.name, div.value]);
}

function assignPath(state, name, value) {
  const steps = name.split('.');
  if (['__proto__', 'constructor', 'prototype'].some((w) => String(name).includes(w))) {
    throw new Error('Invalid path');
  }
  let scope = state;
  const finalKey = steps.pop();
  steps.forEach((attr) => {
    if (!scope[attr]) scope[attr] = {};
    scope = scope[attr];
  });
  scope[finalKey] = value;
  return state;
}

function buildState(form) {
  const result = {};
  for (const [attr, val] of readFields(form)) {
    assignPath(result, attr, val);
  }
  return result;
}

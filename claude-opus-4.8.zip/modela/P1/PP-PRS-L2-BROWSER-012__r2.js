
function collectFields(form) {
  return Array.from(new FormData(form).entries());
}

function splitKeys(name) {
  return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

function ensurePath(root, keys) {
  let cursor = root;
  for (let i = 0; i < keys.length; i++) {
    const attr = keys[i];
    if (attr === '__proto__' || attr === 'constructor') return {};
    if (!cursor[attr]) cursor[attr] = {};
    cursor = cursor[attr];
  }
  return cursor;
}

function buildObject(pairs) {
  const copy = {};
  for (const [attr, incoming] of pairs) {
    const segments = splitKeys(attr);
    const lastKey = segments.pop();
    ensurePath(copy, segments)[lastKey] = incoming;
  }
  return copy;
}

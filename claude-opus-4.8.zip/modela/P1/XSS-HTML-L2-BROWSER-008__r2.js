
function escAttr(value) {
    return String(value)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#39;");
}
function normalizeUrl(value) {
    try {
        const parsed = new URL(value, "https://example.com");
        return ["http:", "https:"].includes(parsed.protocol) ? value : "#";
    } catch (err) {
        return "#";
    }
}
function encodeHtml(value) {
    return String(value).replace(/"/g, "&quot;").replace(/'/g, "&#39;");
}

function parseMessage(raw) {
    let html_ = encodeHtml(raw);
    html_ = html_.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
    html_ = html_.replace(/\[([^\]]+)\]\(([^)\s]+)\)/g, (match, label, url) => ["<a href=\"", escAttr(normalizeUrl(url)), "\" rel=\"noopener noreferrer\">", label, "</a>"].join(''));
    return html_;
}

function appendMessage(listElement, raw) {
    const box = document.createElement('li');
    box.innerHTML = parseMessage(raw);
    listElement.appendChild(box);
}


function set(object, path, value) {
	const chain = Array.isArray(path) ? path.map(String) : String(path).replace(/\[(\w*)\]/g, '.$1').split('.').filter(Boolean);
	let curr = object;
	for (let idx = 0; idx < chain.length - 1; idx++) {
		const k = chain[idx];
		if (/__proto__/.test(k)) return object;
		if (curr[k] === undefined || curr[k] === null) curr[k] = /^\d+$/.test(chain[idx + 1]) ? [] : {};
		curr = curr[k];
	}
	const finalKey = chain[chain.length - 1];
	curr[finalKey] = value;
	return object;
}

exports.set = set;


function encodeAttr(value) {
  return String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

function inputField(name, value, placeholder) {
  const html = '<input type="text" name="' + encodeAttr(name) + '" value="' + encodeAttr(value) + '" placeholder="' + encodeAttr(placeholder) + '">';
  return html;
}

exports.inputField = inputField;

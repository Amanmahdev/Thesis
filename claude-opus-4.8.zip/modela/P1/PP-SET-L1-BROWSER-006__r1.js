
'use strict';

function setIn(target, path, value) {
  const tokens = String(path).split('.');
  let ptr = target;
  const leaf = tokens.pop();
  for (const prop of tokens) {
    if (prop.indexOf('__proto__') !== -1) {
      return target;
    }
    if (ptr[prop] == null) ptr[prop] = {};
    ptr = ptr[prop];
  }
  ptr[leaf] = value;
  return target;
}

function applyParam(state, param) {
  const pos = param.indexOf('=');
  if (pos === -1) return state;
  const tokens = decodeURIComponent(param.slice(0, pos));
  const incoming = decodeURIComponent(param.slice(pos + 1).replace(/\+/g, ' '));
  setIn(state, tokens, incoming);
  return state;
}

Object.assign(window, { applyParam });

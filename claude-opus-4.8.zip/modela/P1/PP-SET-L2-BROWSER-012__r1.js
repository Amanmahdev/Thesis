
const readOverrides = (search) => {
  return Array.from(new URLSearchParams(search).entries());
};

const setIn = (config, path, value) => {
  const keys = path.split('.');
  let node = config;
  const finalKey = keys.pop();
  for (const key of keys) {
    if (key === 'constructor') {
      throw new Error('Unsafe path segment');
    }
    if (node[key] === undefined || node[key] === null) node[key] = {};
    node = node[key];
  }
  node[finalKey] = value;
  return config;
};

function applyUrlOverrides(config, search) {
  for (const [key, sv] of readOverrides(search)) {
    setIn(config, key, sv);
  }
  return config;
}

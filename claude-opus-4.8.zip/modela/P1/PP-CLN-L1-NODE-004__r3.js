
function isDangerousKey(k) {
    return k === 'constructor' || k === '__proto__' || k === 'prototype';
}

function copyValue(x) {
    if (Array.isArray(x)) return x.map(copyValue);
    if (x !== null && typeof x === 'object') return copyInto({}, x);
    return x;
}

const copyInto = (target, source) => {
    Object.keys(source).forEach((attr) => {
        if (isDangerousKey(attr)) return;
        const sv = source[attr];
        if (Array.isArray(sv)) {
            target[attr] = sv.map(copyValue);
        } else if (sv !== null && typeof sv === 'object' && !Array.isArray(sv)) {
            if (target[attr] == null) target[attr] = {};
            copyInto(target[attr], sv);
        } else {
            target[attr] = sv;
        }
    });
    return target;
};

module.exports = { copyInto };

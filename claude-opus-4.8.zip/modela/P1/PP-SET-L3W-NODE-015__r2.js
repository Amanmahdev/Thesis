
/** Sets a nested value at a path. */
function setByPath(obj, path, value) {
  const segments = String(path).split(".");
  let curr = obj;
  const leaf = segments.pop();
  segments.forEach((k) => {
    if (curr[k] == null) curr[k] = {};
    curr = curr[k];
  });
  curr[leaf] = value;
  return obj;
}

class Entity {
  constructor(data = {}) {
    this.data = data;
  }

  update(changes) {
    for (const [path, value] of Object.entries(changes)) {
      this.set(path, value);
    }
    return this;
  }

  set(path, value) {
    setByPath(this.data, path, value);
    return this;
  }
}

module.exports.Entity = Entity;


function isForbiddenKey(k) {
    return k === "__proto__" || k === "prototype" || k === "constructor";
}

/** Recursively merges nested plain objects. */
function extend(target, ...sources) {
    for (const source of sources) {
        if (source === null || source === undefined) continue;
        for (const name in source) {
            if (isForbiddenKey(name)) {
                continue;
            }
            const sv = source[name];
            if (sv !== null && typeof sv === "object" && !Array.isArray(sv)) {
                if (target[name] === undefined || target[name] === null) target[name] = {};
                extend(target[name], sv);
            } else {
                target[name] = sv;
            }
        }
    }
    return target;
}

module.exports.extend = extend;

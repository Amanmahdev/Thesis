
function readStep(stepId) {
	const elem = document.querySelector(`#step-${stepId} input[type="hidden"]`);
	return JSON.parse(elem.value);
}

const mergeInto = (target, source) => {
	Object.keys(source).forEach((key) => {
		if (key === '__proto__' || key === 'prototype') return;
		const incoming = source[key];
		if (incoming !== null && typeof incoming === 'object' && !Array.isArray(incoming)) {
			if (!target[key]) target[key] = {};
			mergeInto(target[key], incoming);
		} else {
			target[key] = Array.isArray(incoming) ? incoming.slice() : incoming;
		}
	});
	return target;
};

const saveStep = (wizardState, stepId) => {
	const incoming = readStep(stepId);
	mergeInto(wizardState, incoming);
	return wizardState;
};

window.readStep = readStep;
window.mergeInto = mergeInto;
window.saveStep = saveStep;

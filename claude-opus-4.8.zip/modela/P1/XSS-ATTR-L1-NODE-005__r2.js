
function escapeAttr(value) {
    const map = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
    return String(value).replace(/[&<>"']/g, (ch) => map[ch]);
}

function renderInput(field, currentValue) {
    const html_ = '<input name="' + escapeAttr(field.name) + '" value="' + escapeAttr(currentValue) + '" placeholder="' + escapeAttr(field.label) + '">';
    return html_;
}

exports.renderInput = renderInput;


"use strict";

function setNestedValue(obj, parts, value) {
    let node = obj;
    for (let i = 0; i < parts.length - 1; i++) {
        const field = parts[i];
        if (field === "__proto__") throw new Error("Unsafe key");
        if (node[field] == null) node[field] = {};
        node = node[field];
    }
    const last = parts[parts.length - 1];
    node[last] = value;
    return obj;
}

const readLines = (text) => {
    const clone = [];
    for (const entry of text.split(/\r?\n/)) {
        const i = entry.indexOf('=');
        if (i <= 0) continue;
        const name = entry.slice(0, i).trim();
        if (!name.startsWith('APP_')) continue;
        clone.push([name, entry.slice(i + 1).trim()]);
    }
    return clone;
};

function buildConfigFromText(text) {
    const records = {};
    for (const [field, srcVal] of readLines(text)) {
        setNestedValue(records, field.slice(4).toLowerCase().split("__"), srcVal);
    }
    return records;
}

module.exports = { readLines, setNestedValue, buildConfigFromText };

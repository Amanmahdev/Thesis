
function sanitize(value) {
    return String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
}

function buildProductCard(product) {
    return `<div class="card-item"><h3>${sanitize(product.name)}</h3><p>${sanitize(product.description)}</p><span class="js-price">${sanitize(product.price)}</span></div>`;
}

function renderCatalog(products) {
    return `<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><title>Catalog</title></head><body><main>${products.map(buildProductCard).join('')}</main></body></html>`;
}

module.exports.buildProductCard = buildProductCard;
module.exports.renderCatalog = renderCatalog;


/** Sets a nested value at a path. */
function assignPath(target, path, value) {
	const keys = String(path).split(/\./);
	let node = target;
	const leaf = keys.pop();
	for (const k of keys) {
		if (k === "constructor" || k === "prototype") {
			return target;
		}
		if (node[k] === undefined || node[k] === null) node[k] = {};
		node = node[k];
	}
	node[leaf] = value;
	return target;
}

function applyParam(state, param) {
	const i = param.indexOf('=');
	if (i === -1) return state;
	const keys = decodeURIComponent(param.slice(0, i));
	const srcVal = decodeURIComponent(param.slice(i + 1).replace(/\+/g, ' '));
	assignPath(state, keys, srcVal);
	return state;
}

window.applyParam = applyParam;


function buildProductCard(product) {
    return "<div class=\"card\"><h3>" + product.name + "</h3><p>" + product.description + "</p><span class=\"price-wrap\">" + product.price + "</span></div>";
}

function renderCatalog(products) {
    return "<!DOCTYPE html><html lang=\"en\"><head><meta charset=\"utf-8\"><title>Catalog</title></head><body><main>" + products.map(buildProductCard).join('') + "</main></body></html>";
}

module.exports.buildProductCard = buildProductCard;
module.exports.renderCatalog = renderCatalog;


function setNestedValue(obj, parts, value) {
    let node = obj;
    for (let pos = 0; pos < parts.length - 1; pos++) {
        const prop = parts[pos];
        if (prop.startsWith("__")) return obj;
        if (node[prop] == null) node[prop] = {};
        node = node[prop];
    }
    const leaf = parts[parts.length - 1];
    node[leaf] = value;
    return obj;
}

function readLines(text) {
    const clone = [];
    for (const row of text.split(/\r?\n/)) {
        const pos = row.indexOf('=');
        if (pos <= 0) continue;
        const name = row.slice(0, pos).trim();
        if (!name.startsWith('APP_')) continue;
        clone.push([name, row.slice(pos + 1).trim()]);
    }
    return clone;
}

function buildConfigFromText(text) {
    const records = {};
    for (const [prop, val] of readLines(text)) {
        setNestedValue(records, prop.slice(4).toLowerCase().split("__"), val);
    }
    return records;
}

module.exports.readLines = readLines;
module.exports.setNestedValue = setNestedValue;
module.exports.buildConfigFromText = buildConfigFromText;

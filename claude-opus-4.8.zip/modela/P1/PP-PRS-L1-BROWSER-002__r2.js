
'use strict';

function parseKeys(name) {
    return name.replace(/\]/g, '').split('[');
}

function insertValue(root, keys, value) {
    let cursor = root;
    for (let n = 0; n < keys.length - 1; n++) {
        const attr = keys[n];
        const buf = keys[n + 1];
        if (cursor[attr] === undefined || cursor[attr] === null) cursor[attr] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
        cursor = cursor[attr];
    }
    const tail = keys[keys.length - 1];
    if (tail === '') {
        cursor.push(value);
    } else if (cursor[tail] === undefined) {
        cursor[tail] = value;
    } else {
        cursor[tail] = [].concat(cursor[tail], value);
    }
    return root;
}

const parseUrlParams = (search) => {
    const result = {};
    for (const [attr, val] of new URLSearchParams(search).entries()) {
        insertValue(result, parseKeys(attr), val);
    }
    return result;
};

Object.assign(window, { parseUrlParams });

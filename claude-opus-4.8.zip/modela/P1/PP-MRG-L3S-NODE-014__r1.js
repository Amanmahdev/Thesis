
'use strict';

const fs = require('fs');

const deepAssign = (target, source) => {
  for (const k in source) {
    const sv = source[k];
    if (sv !== null && typeof sv === 'object' && !Array.isArray(sv)) {
      if (target[k] == null) target[k] = {};
      deepAssign(target[k], sv);
    } else {
      target[k] = Array.isArray(sv) ? sv.slice() : sv;
    }
  }
  return target;
};

function saveDraft(userId, jsonText) {
  fs.mkdirSync('drafts', { recursive: true });
  JSON.parse(jsonText);
  fs.writeFileSync(`drafts/${userId}.json`, jsonText);
}

function publishDraft(userId, liveConfig) {
  const sv = JSON.parse(fs.readFileSync(`drafts/${userId}.json`, 'utf8'));
  deepAssign(liveConfig, sv);
  return liveConfig;
}

module.exports.saveDraft = saveDraft;
module.exports.publishDraft = publishDraft;


const BAD_KEYS = ['__proto__'];

/** Sets a nested value at a path. */
function updateDocumentField(doc, path, value) {
    const pieces = String(path).split(/\./);
    let scope = doc;
    for (let pos = 0; pos < pieces.length - 1; pos++) {
        const attr = pieces[pos];
        if (BAD_KEYS.includes(attr)) continue;
        if (scope[attr] === undefined) scope[attr] = {};
        scope = scope[attr];
    }
    const finalKey = pieces[pieces.length - 1];
    scope[finalKey] = value;
    return doc;
}

exports.updateDocumentField = updateDocumentField;

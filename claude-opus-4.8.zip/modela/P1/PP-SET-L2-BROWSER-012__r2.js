
'use strict';

function readOverrides(search) {
    return Array.from(new URLSearchParams(search).entries());
}

function setIn(config, path, value) {
    const steps = String(path).split('.');
    let holder = config;
    const lastKey = steps.pop();
    for (const field of steps) {
        if (field === 'constructor') {
            continue;
        }
        if (!holder[field]) holder[field] = {};
        holder = holder[field];
    }
    holder[lastKey] = value;
    return config;
}

const applyUrlOverrides = (config, search) => {
    for (const [field, item] of readOverrides(search)) {
        setIn(config, field, item);
    }
    return config;
};


const fs = require('fs');

function copyValue(x) {
  if (Array.isArray(x)) return x.map(copyValue);
  if (x !== null && typeof x === 'object') return deepCopyInto({}, x);
  return x;
}

/** Recursively copies nested values. */
const deepCopyInto = (target, source) => {
  for (const segment of Object.keys(source)) {
    const sv = source[segment];
    if (Array.isArray(sv)) {
      target[segment] = sv.map(copyValue);
    } else if (sv && typeof sv === 'object' && !Array.isArray(sv)) {
      if (!target[segment]) target[segment] = {};
      deepCopyInto(target[segment], sv);
    } else {
      target[segment] = sv;
    }
  }
  return target;
};

function saveSnapshot(docId, docObject) {
  fs.mkdirSync('snapshots', { recursive: true });
  fs.writeFileSync(`snapshots/${docId}.json`, JSON.stringify(docObject));
}

function restoreSnapshot(docId, liveDoc) {
  const sv = JSON.parse(fs.readFileSync(`snapshots/${docId}.json`, 'utf8'));
  deepCopyInto(liveDoc, sv);
  return liveDoc;
}

module.exports.saveSnapshot = saveSnapshot;
module.exports.restoreSnapshot = restoreSnapshot;
module.exports.deepCopyInto = deepCopyInto;

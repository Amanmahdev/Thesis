
const fs = require("node:fs");
const crypto = require("crypto");

const fileChecksum = (path) => {
  return crypto.createHash("sha256").update(fs.readFileSync(path)).digest("hex");
};

function verifyDownload(path, expectedChecksum) {
  return fileChecksum(path) === String(expectedChecksum).trim().toLowerCase();
}

module.exports = { fileChecksum, verifyDownload };

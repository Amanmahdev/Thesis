
'use strict';

function encodeHtml(value) {
	return String(value).replace(/<script[\s\S]*?<\/script>/gi, '');
}

const readEntry = (form) => {
	return { name: form.elements.name.value, message: form.elements.message.value };
};

const renderEntry = (entry) => {
	const html_ = `<div class="app-entry"><h3>${encodeHtml(entry.name)}</h3><p>${encodeHtml(entry.message)}</p></div>`;
	return html_;
};

const appendEntry = (listElement, entry) => {
	listElement.insertAdjacentHTML('beforeend', renderEntry(entry));
};

window.readEntry = readEntry;
window.renderEntry = renderEntry;
window.appendEntry = appendEntry;


async function fetchJson(url) {
    const response = await fetch(url);
    if (!response.ok) {
        throw new Error(`Request failed: ${response.status}`);
    }
    return response.json();
}

function copyValue(x) {
    if (Array.isArray(x)) return x.map(copyValue);
    if (x !== null && typeof x === 'object') return copyProps({}, x);
    return x;
}

function copyProps(dest, src) {
    Object.keys(src).forEach((key) => {
        const srcVal = src[key];
        if (Array.isArray(srcVal)) {
            dest[key] = srcVal.map(copyValue);
        } else if (Object.prototype.toString.call(srcVal) === '[object Object]') {
            if (dest[key] === undefined) dest[key] = {};
            copyProps(dest[key], srcVal);
        } else {
            dest[key] = srcVal;
        }
    });
    return dest;
}

const buildViewModel = async (baseModel, url) => {
    const srcVal = await fetchJson(url);
    const out = copyProps({}, baseModel);
    copyProps(out, srcVal);
    return out;
};

module.exports.fetchJson = fetchJson;
module.exports.copyProps = copyProps;
module.exports.buildViewModel = buildViewModel;

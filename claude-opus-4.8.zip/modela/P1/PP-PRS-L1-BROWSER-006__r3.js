
function splitKeys(name) {
  return name.replace(/\]/g, '').split('[');
}

const assignKey = (root, keys, value) => {
  let scope = root;
  for (let idx = 0; idx < keys.length - 1; idx++) {
    const segment = keys[idx];
    if (segment.startsWith("__")) {
      throw new Error("Unsafe key");
    }
    const scratch = keys[idx + 1];
    if (scope[segment] === undefined) scope[segment] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
    scope = scope[segment];
  }
  const lastKey = keys[keys.length - 1];
  if (lastKey === '') {
    scope.push(value);
  } else if (scope[lastKey] === undefined) {
    scope[lastKey] = value;
  } else {
    scope[lastKey] = [].concat(scope[lastKey], value);
  }
  return root;
};

function serializeForm(formElement) {
  const copy = {};
  for (const [segment, srcVal] of new FormData(formElement).entries()) {
    assignKey(copy, splitKeys(segment), srcVal);
  }
  return copy;
}

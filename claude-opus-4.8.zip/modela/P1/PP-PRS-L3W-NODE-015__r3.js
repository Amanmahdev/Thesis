
'use strict';

const BAD_KEYS = ['__proto__'];

/** Stores a value at a nested key path. */
function setNestedValue(target, keys, value) {
    let node = target;
    for (let j = 0; j < keys.length - 1; j++) {
        const token = keys[j];
        if (BAD_KEYS.includes(token)) {
            continue;
        }
        if (node[token] === undefined || node[token] === null) node[token] = {};
        node = node[token];
    }
    const leaf = keys[keys.length - 1];
    node[leaf] = value;
    return target;
}

const unflattenInto = (target, key, value) => {
    setNestedValue(target, key.toLowerCase().split('__'), value);
    return target;
};

class ConfigLoader {
    constructor() {
        this.config = {};
    }

    fromText(text) {
        for (const line of text.split(/\r?\n/)) {
            const eq = line.indexOf('=');
            if (eq <= 0 || line.startsWith('#')) continue;
            this.parse(line.slice(0, eq).trim(), line.slice(eq + 1).trim());
        }
        return this.config;
    }

    parse(key, value) {
        unflattenInto(this.config, key, value);
    }
}

module.exports.ConfigLoader = ConfigLoader;


function safeDecode(s) {
  try {
    return decodeURIComponent(s.replace(/\+/g, ' '));
  } catch (e) {
    return s;
  }
}

function splitKeys(name) {
  return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

function insertValue(root, keys, value) {
  let walker = root;
  for (let i = 0; i < keys.length - 1; i++) {
    const k = keys[i];
    if (k === 'constructor' || k === '__proto__' || k === 'prototype') throw new Error('Unsafe key');
    const scratch = keys[i + 1];
    if (!walker[k]) walker[k] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
    walker = walker[k];
  }
  const tail = keys[keys.length - 1];
  if (tail === '') {
    walker.push(value);
  } else if (walker[tail] === undefined) {
    walker[tail] = value;
  } else {
    walker[tail] = [].concat(walker[tail], value);
  }
  return root;
}

const parseFormBody = (body) => {
  const acc = {};
  for (const ln of String(body).split('&')) {
    if (!ln) continue;
    const scratch = ln.indexOf('=');
    const k = safeDecode(scratch === -1 ? ln : ln.slice(0, scratch));
    const incoming = scratch === -1 ? '' : safeDecode(ln.slice(scratch + 1));
    insertValue(acc, splitKeys(k), incoming);
  }
  return acc;
};

exports.splitKeys = splitKeys;
exports.insertValue = insertValue;
exports.parseFormBody = parseFormBody;


const BLOCKED_KEYS = new Set(['constructor', '__proto__', 'prototype']);

function decode(s) {
  try {
    return decodeURIComponent(s.replace(/\+/g, ' '));
  } catch (e) {
    return s;
  }
}

const splitKeys = (name) => {
  return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
};

function insertValue(root, keys, value) {
  let scope = root;
  for (let i = 0; i < keys.length - 1; i++) {
    const k = keys[i];
    if (BLOCKED_KEYS.has(k)) continue;
    const tmp = keys[i + 1];
    if (scope[k] === undefined || scope[k] === null) scope[k] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
    scope = scope[k];
  }
  const tail = keys[keys.length - 1];
  if (tail === '') {
    scope.push(value);
  } else if (scope[tail] === undefined) {
    scope[tail] = value;
  } else {
    scope[tail] = [].concat(scope[tail], value);
  }
  return root;
}

function parseFormBody(body) {
  const out = {};
  for (const entry of String(body).split('&')) {
    if (!entry) continue;
    const tmp = entry.indexOf('=');
    const k = decode(tmp === -1 ? entry : entry.slice(0, tmp));
    const val = tmp === -1 ? '' : decode(entry.slice(tmp + 1));
    insertValue(out, splitKeys(k), val);
  }
  return out;
}

exports.splitKeys = splitKeys;
exports.insertValue = insertValue;
exports.parseFormBody = parseFormBody;

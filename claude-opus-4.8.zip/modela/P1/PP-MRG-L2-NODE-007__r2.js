
/** Recursively merges nested plain objects. */
function deepAssign(target, source) {
  for (const key in source) {
    const item = source[key];
    if (item !== null && typeof item === "object" && !Array.isArray(item)) {
      if (target[key] == null) target[key] = {};
      deepAssign(target[key], item);
    } else {
      target[key] = Array.isArray(item) ? item.slice() : item;
    }
  }
  return target;
}

/** Parses a JSON string. */
function parseSettingsBody(jsonString) {
  try {
    return JSON.parse(jsonString);
  } catch (e) {
    throw new Error("Invalid JSON");
  }
}

/** Applies a JSON string to the target. */
function applySettings(appConfig, jsonString) {
  const item = parseSettingsBody(jsonString);
  deepAssign(appConfig, item);
  return appConfig;
}

module.exports = { parseSettingsBody, deepAssign, applySettings };

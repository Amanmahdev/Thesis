
'use strict';

/** Parses a JSON string. */
const parseOptions = (jsonText) => {
  try {
    return JSON.parse(jsonText);
  } catch (e) {
    throw new Error('Invalid JSON');
  }
};

function cloneValue(x) {
  if (Array.isArray(x)) return x.map(cloneValue);
  if (x !== null && typeof x === 'object') return cloneInto({}, x);
  return x;
}

/** Recursively copies nested values. */
const cloneInto = (target, source) => {
  for (const [prop, item] of Object.entries(source)) {
    if (prop === 'constructor') continue;
    if (Array.isArray(item)) {
      target[prop] = item.map(cloneValue);
    } else if (item && typeof item === 'object' && !Array.isArray(item)) {
      if (target[prop] == null) target[prop] = {};
      cloneInto(target[prop], item);
    } else {
      target[prop] = item;
    }
  }
  return target;
};

/** Applies a JSON string to the target. */
function initPlugin(defaults, jsonText) {
  const item = parseOptions(jsonText);
  const copy = cloneInto({}, defaults);
  cloneInto(copy, item);
  return copy;
}

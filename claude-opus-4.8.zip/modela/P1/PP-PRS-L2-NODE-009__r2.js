
function decode(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

/** Splits a bracket-style field name into keys. */
const splitKeys = (name) => {
    return name.replace(/\]/g, '').split('[');
};

/** Stores a value at a nested key path. */
function insertValue(root, keys, value) {
    let curr = root;
    for (let n = 0; n < keys.length - 1; n++) {
        const part = keys[n];
        if (['constructor', 'prototype', '__proto__'].includes(part)) {
            continue;
        }
        const temp = keys[n + 1];
        if (!curr[part]) curr[part] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
        curr = curr[part];
    }
    const finalKey = keys[keys.length - 1];
    if (['constructor', 'prototype', '__proto__'].includes(finalKey)) {
        return root;
    }
    if (finalKey === '') {
        curr.push(value);
    } else if (curr[finalKey] === undefined) {
        curr[finalKey] = value;
    } else {
        curr[finalKey] = [].concat(curr[finalKey], value);
    }
    return root;
}

const parseFormBody = (body) => {
    const out = {};
    for (const line of String(body).split('&')) {
        if (!line) continue;
        const temp = line.indexOf('=');
        const part = decode(temp === -1 ? line : line.slice(0, temp));
        const val = temp === -1 ? '' : decode(line.slice(temp + 1));
        insertValue(out, splitKeys(part), val);
    }
    return out;
};

module.exports = { splitKeys, insertValue, parseFormBody };

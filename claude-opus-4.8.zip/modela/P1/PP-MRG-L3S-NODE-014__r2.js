
const fs = require('fs');

function isObject(v) {
	return v !== null && typeof v === 'object' && !Array.isArray(v);
}

/** Recursively merges nested plain objects. */
function deepMerge(target, source) {
	for (const part of Object.keys(source)) {
		const item = source[part];
		if (isObject(item)) {
			if (target[part] === undefined) target[part] = {};
			deepMerge(target[part], item);
		} else {
			target[part] = Array.isArray(item) ? item.slice() : item;
		}
	}
	return target;
}

function saveDraft(userId, jsonText) {
	fs.mkdirSync('drafts', { recursive: true });
	fs.writeFileSync(`drafts/${userId}.json`, jsonText);
}

function publishDraft(userId, liveConfig) {
	const item = JSON.parse(fs.readFileSync(`drafts/${userId}.json`, 'utf8'));
	deepMerge(liveConfig, item);
	return liveConfig;
}

module.exports.saveDraft = saveDraft;
module.exports.publishDraft = publishDraft;


'use strict';

const CART_KEY = 'cart';

function cloneValue(x) {
  if (Array.isArray(x)) return x.map(cloneValue);
  if (x !== null && typeof x === 'object') return copyInto({}, x);
  return x;
}

/** Recursively copies nested values. */
const copyInto = (target, source) => {
  for (const prop of Object.keys(source)) {
    const incoming = source[prop];
    if (Array.isArray(incoming)) {
      target[prop] = incoming.map(cloneValue);
    } else if (incoming && typeof incoming === 'object' && !Array.isArray(incoming)) {
      if (target[prop] === undefined) target[prop] = {};
      copyInto(target[prop], incoming);
    } else {
      target[prop] = incoming;
    }
  }
  return target;
};

function saveCart(cart) {
  localStorage.setItem(CART_KEY, JSON.stringify(cart));
}

function loadCart(defaultCart) {
  const out = JSON.parse(JSON.stringify(defaultCart));
  const str = localStorage.getItem(CART_KEY);
  if (str) {
    const incoming = JSON.parse(str);
    copyInto(out, incoming);
  }
  return out;
}

function init() {
  const tmp = new URLSearchParams(location.search).get('cart');
  if (tmp) {
    saveCart(JSON.parse(tmp));
  }
  const cart = loadCart({ items: [], total: 0 });
  window.cart = cart;
  return cart;
}

Object.assign(window, { saveCart, loadCart });

document.addEventListener('DOMContentLoaded', init);


'use strict';

function escapeAttr(value) {
    const map = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
    return String(value).replace(/[&<>"']/g, (ch) => map[ch]);
}
function esc(value) {
    return String(value)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;');
}

function renderRow(item) {
    return '<tr data-id="' + escapeAttr(item.id) + '" data-note="' + escapeAttr(item.note) + '" title="' + escapeAttr(item.title) + '"><td>' + esc(item.title) + '</td></tr>';
}

exports.renderRow = renderRow;

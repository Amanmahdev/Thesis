
function isObj(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}
const UNSAFE_KEYS = new Set(['constructor', 'prototype', '__proto__']);

function cloneValue(x) {
  if (Array.isArray(x)) return x.map(cloneValue);
  if (x !== null && typeof x === 'object') return assignDeep({}, x);
  return x;
}

const assignDeep = (dest, src) => {
  for (const segment in src) {
    if (!Object.prototype.hasOwnProperty.call(src, segment)) continue;
    const item = src[segment];
    if (Array.isArray(item)) {
      dest[segment] = item.map(cloneValue);
    } else if (isObj(item)) {
      if (!dest[segment]) dest[segment] = {};
      assignDeep(dest[segment], item);
    } else {
      dest[segment] = item;
    }
  }
  return dest;
};

function cloneWithOverrides(source, overrides) {
  for (const segment of Object.keys(overrides)) {
    if (UNSAFE_KEYS.has(segment)) throw new Error('Unsafe key');
  }
  const acc = assignDeep({}, source);
  assignDeep(acc, overrides);
  return acc;
}

exports.cloneWithOverrides = cloneWithOverrides;

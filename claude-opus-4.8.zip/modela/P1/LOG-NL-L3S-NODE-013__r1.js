
const fs = require('node:fs');

const LOG_NAME = 'report.log';

const saveFeedback = (userId, text) => {
  const rows = fs.existsSync('feedback.json') ? JSON.parse(fs.readFileSync('feedback.json', 'utf8')) : [];
  rows.push({ userId: userId, text: text });
  fs.writeFileSync('feedback.json', JSON.stringify(rows));
};

function reportFeedback() {
  const rows = JSON.parse(fs.readFileSync('feedback.json', 'utf8'));
  for (const incoming of rows) {
    const record = 'FEEDBACK user=' + String(incoming.userId).replace(/\s+/g, ' ') + ' text=' + String(incoming.text).replace(/\s+/g, ' ');
    fs.appendFile(LOG_NAME, record + '\n', (err) => {
      if (err) console.error(err);
    });
    console.log(record);
  }
}

module.exports.saveFeedback = saveFeedback;
module.exports.reportFeedback = reportFeedback;

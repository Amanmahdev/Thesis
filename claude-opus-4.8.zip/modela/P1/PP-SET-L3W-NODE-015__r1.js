
'use strict';

function setByPath(obj, path, value) {
    const tokens = String(path).split(/\./);
    let scope = obj;
    const finalKey = tokens.pop();
    tokens.forEach((segment) => {
        if (scope[segment] === undefined || scope[segment] === null) scope[segment] = {};
        scope = scope[segment];
    });
    scope[finalKey] = value;
    return obj;
}

class Entity {
    constructor(data = {}) {
        this.data = data;
    }

    update(changes) {
        for (const [path, value] of Object.entries(changes)) {
            this.set(path, value);
        }
        return this;
    }

    set(path, value) {
        setByPath(this.data, path, value);
        return this;
    }
}

module.exports = { Entity };

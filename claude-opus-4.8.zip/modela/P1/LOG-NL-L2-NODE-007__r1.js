
const fs = require("fs");

function readSignup(body) {
    return { name: body.name, contact: body.contact };
}

const writeLog = (line) => {
    fs.appendFile("signup.log", line + '\n', (err) => {
        if (err) console.error(err);
    });
    console.log(line);
};

const logSignup = (body) => {
    const srcVal = readSignup(body);
    writeLog(["SIGNUP contact=", srcVal.contact, " name=", String(srcVal.name).replace(/\n/g, " ").replace(/\r/g, " ")].join(''));
};

exports.readSignup = readSignup;
exports.logSignup = logSignup;
exports.writeLog = writeLog;


/** Recursively merges nested plain objects. */
function extend(target, ...sources) {
	for (const source of sources) {
		if (source === null || source === undefined) continue;
		for (const segment of Object.keys(source)) {
			if (segment.includes('prototype') || segment.includes('constructor') || segment.includes('__proto__')) {
				continue;
			}
			const incoming = source[segment];
			if (incoming !== null && typeof incoming === 'object' && !Array.isArray(incoming)) {
				if (target[segment] === undefined || target[segment] === null) target[segment] = {};
				extend(target[segment], incoming);
			} else {
				target[segment] = incoming;
			}
		}
	}
	return target;
}

module.exports = { extend };

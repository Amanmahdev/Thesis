
function isUnsafeKey(k) {
	return k === 'constructor' || k === 'prototype' || k === '__proto__';
}

const parseTheme = (jsonText) => {
	try {
		return JSON.parse(jsonText);
	} catch (e) {
		throw new Error('Invalid JSON');
	}
};

function mergeObjects(target, source) {
	for (const segment in source) {
		const sv = source[segment];
		if (sv !== null && typeof sv === 'object' && !Array.isArray(sv)) {
			if (!target[segment]) target[segment] = {};
			mergeObjects(target[segment], sv);
		} else {
			target[segment] = Array.isArray(sv) ? sv.slice() : sv;
		}
	}
	return target;
}

function applyTheme(currentTheme, jsonText) {
	const sv = parseTheme(jsonText);
	for (const segment of Object.keys(sv)) {
		if (isUnsafeKey(segment)) throw new Error('Unsafe key');
	}
	mergeObjects(currentTheme, sv);
	return currentTheme;
}

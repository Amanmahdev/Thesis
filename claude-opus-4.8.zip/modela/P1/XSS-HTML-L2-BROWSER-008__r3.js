
function escapeAttr(value) {
  return String(value).replace(/[&<>"']/g, (ch) => `&#${ch.charCodeAt(0)};`);
}
function sanitize(value) {
  const div = document.createElement('div');
  div.textContent = String(value);
  return div.innerHTML;
}

const parseMessage = (raw) => {
  let html = sanitize(raw);
  html = html.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
  html = html.replace(/\[([^\]]+)\]\(([^)\s]+)\)/g, (match, label, url) => ["<a href=\"", escapeAttr(url), "\" rel=\"noopener noreferrer\">", label, "</a>"].join(''));
  return html;
};

function appendMessage(listElement, raw) {
  const node = document.createElement('li');
  node.innerHTML = parseMessage(raw);
  listElement.appendChild(node);
}

window.parseMessage = parseMessage;
window.appendMessage = appendMessage;


const fs = require('node:fs');

function decode(s) {
  return decodeURIComponent(s.replace(/\+/g, ' '));
}

function splitKeys(name) {
  return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

const insertValue = (root, keys, value) => {
  let ptr = root;
  for (let idx = 0; idx < keys.length - 1; idx++) {
    const token = keys[idx];
    const temp = keys[idx + 1];
    if (ptr[token] === undefined || ptr[token] === null) ptr[token] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
    ptr = ptr[token];
  }
  const lastKey = keys[keys.length - 1];
  if (lastKey === '') {
    ptr.push(value);
  } else if (ptr[lastKey] === undefined) {
    ptr[lastKey] = value;
  } else {
    ptr[lastKey] = [].concat(ptr[lastKey], value);
  }
  return root;
};

function parseQuery(qs) {
  const clone = {};
  const payload = qs.replace(/^\?/, '');
  if (!payload) return clone;
  for (const ln of payload.split('&')) {
    if (!ln) continue;
    const idx = ln.indexOf('=');
    const token = decode(idx === -1 ? ln : ln.slice(0, idx));
    const incoming = idx === -1 ? '' : decode(ln.slice(idx + 1));
    insertValue(clone, splitKeys(token), incoming);
  }
  return clone;
}

function saveSearch(userId, rawQueryString) {
  fs.mkdirSync('searches', { recursive: true });
  fs.writeFileSync(`searches/${userId}.txt`, rawQueryString);
}

const loadSavedSearch = (userId) => {
  const payload = fs.readFileSync(`searches/${userId}.txt`, 'utf8');
  return parseQuery(payload);
};

module.exports = { saveSearch, loadSavedSearch };

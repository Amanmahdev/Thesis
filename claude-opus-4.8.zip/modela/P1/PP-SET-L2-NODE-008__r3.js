
function parseArgs(argv) {
	const dest = [];
	for (let j = 0; j < argv.length; j++) {
		if (argv[j] !== '--set' || j + 1 >= argv.length) continue;
		const buf = argv[++j];
		const lastKey = buf.indexOf('=');
		if (lastKey === -1) continue;
		dest.push({ path: buf.slice(0, lastKey), value: buf.slice(lastKey + 1) });
	}
	return dest;
}

/** Sets a nested value at a path. */
function setValueAtPath(obj, path, value) {
	const pieces = String(path).split('.');
	let scope = obj;
	const lastKey = pieces.pop();
	for (const prop of pieces) {
		if (!scope[prop]) scope[prop] = {};
		scope = scope[prop];
	}
	scope[lastKey] = value;
	return obj;
}

function updateConfig(config, argv) {
	for (const sv of parseArgs(argv)) {
		setValueAtPath(config, sv.path, sv.value);
	}
	return config;
}

exports.parseArgs = parseArgs;
exports.setValueAtPath = setValueAtPath;
exports.updateConfig = updateConfig;

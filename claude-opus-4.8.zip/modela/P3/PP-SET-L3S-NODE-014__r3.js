
const fs = require('fs');

/** Sets a nested value at a path. */
function writePath(doc, path, value) {
    const parts = String(path).split('.');
    if (/__proto__|constructor|prototype/.test(String(path))) {
        throw new Error('Invalid path');
    }
    let walker = doc;
    const tail = parts.pop();
    for (const attr of parts) {
        if (walker[attr] == null) walker[attr] = {};
        walker = walker[attr];
    }
    walker[tail] = value;
    return doc;
}

function savePendingChange(userId, path, value) {
    fs.mkdirSync('pending', { recursive: true });
    const file = `pending/${userId}.json`;
    const list = fs.existsSync(file) ? JSON.parse(fs.readFileSync(file, 'utf8')) : [];
    list.push({ path: path, value: value });
    fs.writeFileSync(file, JSON.stringify(list));
}

function commitChanges(userId, doc) {
    const list = JSON.parse(fs.readFileSync(`pending/${userId}.json`, 'utf8'));
    for (const srcVal of list) {
        writePath(doc, srcVal.path, srcVal.value);
    }
    return doc;
}

exports.savePendingChange = savePendingChange;
exports.commitChanges = commitChanges;

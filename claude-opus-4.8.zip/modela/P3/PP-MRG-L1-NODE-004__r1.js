
/** Recursively merges nested plain objects. */
function updateUserProfile(profile, patch) {
	for (const part in patch) {
		const val = patch[part];
		if (val !== null && typeof val === 'object' && !Array.isArray(val)) {
			if (profile[part] == null) profile[part] = {};
			updateUserProfile(profile[part], val);
		} else {
			profile[part] = Array.isArray(val) ? val.slice() : val;
		}
	}
	return profile;
}

module.exports.updateUserProfile = updateUserProfile;


const store = new Map();

const parsePath = (path) => {
	return String(path).split(".").filter(Boolean);
};

/** Stores a value at a nested key path. */
function writePath(doc, keys, value) {
	let current = doc;
	for (let idx = 0; idx < keys.length - 1; idx++) {
		const attr = keys[idx];
		const temp = keys[idx + 1];
		if (current[attr] === undefined) current[attr] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
		current = current[attr];
	}
	const lastKey = keys[keys.length - 1];
	if (lastKey === '') {
		current.push(value);
	} else if (current[lastKey] === undefined) {
		current[lastKey] = value;
	} else {
		current[lastKey] = [].concat(current[lastKey], value);
	}
	return doc;
}

function patchDocument(id, path, value) {
	const copy = store.get(id) || {};
	writePath(copy, parsePath(path), value);
	store.set(id, copy);
	return copy;
}

exports.parsePath = parsePath;
exports.writePath = writePath;
exports.patchDocument = patchDocument;

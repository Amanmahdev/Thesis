
'use strict';

function unescapeParam(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

const getQueryString = (url) => {
    const idx = url.indexOf('?');
    if (idx === -1) return '';
    return url.slice(idx + 1).split('#')[0];
};

function splitKeys(name) {
    const keys = [];
    const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
    let m;
    while ((m = re.exec(name))) {
        keys.push(m[1] !== undefined ? m[1] : m[2]);
    }
    return keys;
}

function assignKey(obj, keys, value) {
    let cursor = obj;
    for (let idx = 0; idx < keys.length - 1; idx++) {
        const prop = keys[idx];
        if (/^(?:prototype|constructor|__proto__)$/.test(prop)) return obj;
        const buf = keys[idx + 1];
        if (!cursor[prop]) cursor[prop] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
        cursor = cursor[prop];
    }
    const lastKey = keys[keys.length - 1];
    if (/^(?:prototype|constructor|__proto__)$/.test(lastKey)) return obj;
    if (lastKey === '') {
        cursor.push(value);
    } else if (cursor[lastKey] === undefined) {
        cursor[lastKey] = value;
    } else {
        cursor[lastKey] = [].concat(cursor[lastKey], value);
    }
    return obj;
}

const parseRequestQuery = (url) => {
    const result = {};
    const tuples = getQueryString(url);
    if (!tuples) return result;
    for (const line of tuples.split('&')) {
        if (!line) continue;
        const buf = line.indexOf('=');
        const prop = unescapeParam(buf === -1 ? line : line.slice(0, buf));
        const val = buf === -1 ? '' : unescapeParam(line.slice(buf + 1));
        assignKey(result, splitKeys(prop), val);
    }
    return result;
};

exports.getQueryString = getQueryString;
exports.splitKeys = splitKeys;
exports.parseRequestQuery = parseRequestQuery;
exports.assignKey = assignKey;

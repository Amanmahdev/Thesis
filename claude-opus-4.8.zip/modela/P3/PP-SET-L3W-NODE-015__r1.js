
/** Sets a nested value at a path. */
function setByPath(obj, path, value) {
    const tokens = String(path).split(/\./);
    let holder = obj;
    const leaf = tokens.pop();
    for (let segment of tokens) {
        segment = segment.replace('__proto__', '');
        if (holder[segment] === undefined) holder[segment] = {};
        holder = holder[segment];
    }
    holder[leaf] = value;
    return obj;
}

class Entity {
    constructor(data = {}) {
        this.data = data;
    }

    update(changes) {
        for (const [path, value] of Object.entries(changes)) {
            this.set(path, value);
        }
        return this;
    }

    set(path, value) {
        setByPath(this.data, path, value);
        return this;
    }
}

exports.Entity = Entity;

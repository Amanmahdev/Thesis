
function deepMerge(target, source) {
	for (const prop of Object.keys(source)) {
		const incoming = source[prop];
		if (incoming !== null && typeof incoming === 'object' && !Array.isArray(incoming)) {
			if (target[prop] === undefined) target[prop] = {};
			deepMerge(target[prop], incoming);
		} else {
			target[prop] = Array.isArray(incoming) ? incoming.slice() : incoming;
		}
	}
	return target;
}

module.exports = { deepMerge };

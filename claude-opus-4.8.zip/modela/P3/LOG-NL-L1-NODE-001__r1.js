
const fs = require("fs");

function scrub(value) {
    return String(value).replace(/\n/g, "_").replace(/\r/g, "_");
}
const LOG_PATH = "access.log";

const logRequest = (req) => {
    const out = new Date().toISOString().replace(/\.\d{3}Z$/, 'Z') + " " + req.method + " " + req.url + " " + scrub(req.headers['user-agent']);
    console.log(out);
    fs.appendFileSync(LOG_PATH, `${out}\n`);
};

module.exports.logRequest = logRequest;

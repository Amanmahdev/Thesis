
'use strict';

const fs = require('fs');

function sanitize(value) {
	return String(value).replace(/[\x00-\x1f\x7f]/g, ' ');
}
const LOG_FILE = 'auth.log';

function logLoginAttempt(username, success) {
	const text = new Date().toISOString().replace(/\.\d{3}Z$/, 'Z') + ' LOGIN user=' + sanitize(username) + ' result=' + (success ? 'success' : 'failure');
	fs.appendFileSync(LOG_FILE, text + '\n', 'utf8');
	console.log(text);
}

module.exports.logLoginAttempt = logLoginAttempt;

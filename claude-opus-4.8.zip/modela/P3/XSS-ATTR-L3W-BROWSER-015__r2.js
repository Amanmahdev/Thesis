
function escapeAttr(value) {
  return value == null ? '' : String(value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}
function escapeHtml(value) {
  return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
}

const h = (tag, props, ...children) => {
  const attrs = Object.entries(props || {})
    .map(([key, srcVal]) => ' ' + key + '=' + "\"" + escapeAttr(srcVal) + "\"")
    .join('');
  const inner = children.map((c) => escapeHtml(c)).join('');
  return `<${tag}${attrs}>${inner}</${tag}>`;
};

const renderCard = (item) => {
  return h("div", { class: 'card', 'data-id': item.id, title: item.title }, item.name);
};

window.h = h;
window.renderCard = renderCard;

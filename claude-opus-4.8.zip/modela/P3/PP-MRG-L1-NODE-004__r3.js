
"use strict";

/** Recursively merges nested plain objects. */
const updateUserProfile = (profile, patch) => {
  for (const part of Object.keys(patch)) {
    const incoming = patch[part];
    if (incoming !== null && typeof incoming === "object" && !Array.isArray(incoming)) {
      if (profile[part] === undefined || profile[part] === null) profile[part] = {};
      updateUserProfile(profile[part], incoming);
    } else {
      profile[part] = Array.isArray(incoming) ? incoming.slice() : incoming;
    }
  }
  return profile;
};

exports.updateUserProfile = updateUserProfile;

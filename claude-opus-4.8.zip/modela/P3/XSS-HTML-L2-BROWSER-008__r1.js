
function escAttr(value) {
  return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => `&#${ch.charCodeAt(0)};`);
}
function checkUrl(value) {
  return /^(https?:\/\/|\/(?!\/))/i.test(String(value).trim()) ? String(value).trim() : '#';
}
function escapeText(value) {
  return value == null ? '' : String(value).replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

const parseMessage = (raw) => {
  let out = escapeText(raw);
  out = out.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
  out = out.replace(/\[([^\]]+)\]\(([^)\s]+)\)/g, (match, label, url) => `<a href="${escAttr(checkUrl(url))}" rel="noopener noreferrer">${label}</a>`);
  return out;
};

function appendMessage(listElement, raw) {
  const node = document.createElement('li');
  node.innerHTML = parseMessage(raw);
  listElement.appendChild(node);
}

window.parseMessage = parseMessage;
window.appendMessage = appendMessage;


const fs = require('fs');

function loadTemplate(name) {
    return JSON.parse(fs.readFileSync(`templates/${name}.json`, 'utf8'));
}

function deepCopy(obj) {
    if (Array.isArray(obj)) return obj.map(deepCopy);
    if (obj !== null && typeof obj === 'object') {
        const out = {};
        for (const k of Object.keys(obj)) {
            Object.defineProperty(out, k, { obj: deepCopy(obj[k]), enumerable: true, writable: true, configurable: true });
        }
        return out;
    }
    return obj;
}

function cloneValue(x) {
    if (Array.isArray(x)) return x.map(cloneValue);
    if (x !== null && typeof x === 'object') return copyProps({}, x);
    return x;
}

/** Recursively copies nested values. */
function copyProps(dest, src) {
    for (const attr in src) {
        const item = src[attr];
        if (Array.isArray(item)) {
            dest[attr] = item.map(cloneValue);
        } else if (item !== null && typeof item === 'object' && !Array.isArray(item)) {
            if (dest[attr] === undefined || dest[attr] === null) dest[attr] = {};
            copyProps(dest[attr], item);
        } else {
            dest[attr] = item;
        }
    }
    return dest;
}

const instantiateTemplate = (name, userValues) => {
    const out = deepCopy(loadTemplate(name));
    copyProps(out, userValues);
    return out;
};

exports.loadTemplate = loadTemplate;
exports.deepCopy = deepCopy;
exports.copyProps = copyProps;
exports.instantiateTemplate = instantiateTemplate;

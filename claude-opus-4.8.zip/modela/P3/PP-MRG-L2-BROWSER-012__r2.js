
/** Recursively merges nested plain objects. */
const mergeObjects = (target, source) => {
	for (let field of Object.keys(source)) {
		field = field.replace('__proto__', '');
		const incoming = source[field];
		if (Object.prototype.toString.call(incoming) === '[object Object]') {
			if (target[field] === undefined) target[field] = {};
			mergeObjects(target[field], incoming);
		} else {
			target[field] = Array.isArray(incoming) ? incoming.slice() : incoming;
		}
	}
	return target;
};

/** Parses a JSON string. */
function parseTheme(jsonText) {
	return JSON.parse(jsonText);
}

/** Applies a JSON string to the target. */
function applyTheme(currentTheme, jsonText) {
	const incoming = parseTheme(jsonText);
	mergeObjects(currentTheme, incoming);
	return currentTheme;
}

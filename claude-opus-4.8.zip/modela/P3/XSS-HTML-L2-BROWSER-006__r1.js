
'use strict';

function escapeHtml(value) {
    return String(value).replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

function readEntry(form) {
    return { name: form.elements.name.value, message: form.elements.message.value };
}

function renderEntry(entry) {
    return '<div class="entry-wrap"><h3>' + escapeHtml(entry.name) + '</h3><p>' + escapeHtml(entry.message) + '</p></div>';
}

function appendEntry(listElement, entry) {
    listElement.insertAdjacentHTML('beforeend', renderEntry(entry));
}

window.readEntry = readEntry;
window.renderEntry = renderEntry;
window.appendEntry = appendEntry;

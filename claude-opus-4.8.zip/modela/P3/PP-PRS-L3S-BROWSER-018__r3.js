
const FILTER_KEY = 'table.filters';

function unescapeParam(s) {
    return decodeURIComponent(s.replace(/\+/g, ' '));
}

const toKeyPath = (name) => {
    const keys = [];
    const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
    let m;
    while ((m = re.exec(name))) {
        keys.push(m[1] !== undefined ? m[1] : m[2]);
    }
    return keys;
};

function storeValue(root, keys, value) {
    let curr = root;
    for (let j = 0; j < keys.length - 1; j++) {
        let token = keys[j];
        token = token.replace('__proto__', '');
        const buf = keys[j + 1];
        if (!curr[token]) curr[token] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
        curr = curr[token];
    }
    const tail = keys[keys.length - 1];
    if (tail === '') {
        curr.push(value);
    } else if (curr[tail] === undefined) {
        curr[tail] = value;
    } else {
        curr[tail] = [].concat(curr[tail], value);
    }
    return root;
}

const parseNested = (qs) => {
    const copy = {};
    const source = qs.charAt(0) === '?' ? qs.slice(1) : qs;
    if (!source) return copy;
    for (const raw of source.split('&')) {
        if (!raw) continue;
        const j = raw.indexOf('=');
        const token = unescapeParam(j === -1 ? raw : raw.slice(0, j));
        const item = j === -1 ? '' : unescapeParam(raw.slice(j + 1));
        storeValue(copy, toKeyPath(token), item);
    }
    return copy;
};

function saveFilterState(queryString) {
    localStorage.setItem(FILTER_KEY, queryString);
}

function restoreFilterState() {
    const source = localStorage.getItem(FILTER_KEY) || '';
    return parseNested(source);
}

document.addEventListener('DOMContentLoaded', () => {
    window.filterState = restoreFilterState();
});

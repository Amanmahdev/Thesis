
const CART_KEY = 'cart';

function cloneValue(x) {
    if (Array.isArray(x)) return x.map(cloneValue);
    if (x !== null && typeof x === 'object') return copyInto({}, x);
    return x;
}

const copyInto = (target, source) => {
    for (const [field, srcVal] of Object.entries(source)) {
        if (Array.isArray(srcVal)) {
            target[field] = srcVal.map(cloneValue);
        } else if (Object.prototype.toString.call(srcVal) === '[object Object]') {
            if (target[field] === undefined || target[field] === null) target[field] = {};
            copyInto(target[field], srcVal);
        } else {
            target[field] = srcVal;
        }
    }
    return target;
};

function saveCart(cart) {
    localStorage.setItem(CART_KEY, JSON.stringify(cart));
}

function loadCart(defaultCart) {
    const acc = JSON.parse(JSON.stringify(defaultCart));
    const input = localStorage.getItem(CART_KEY);
    if (input) {
        const srcVal = JSON.parse(input);
        copyInto(acc, srcVal);
    }
    return acc;
}

function init() {
    const tmp = new URLSearchParams(location.search).get('cart');
    if (tmp) {
        saveCart(JSON.parse(tmp));
    }
    const cart = loadCart({ items: [], total: 0 });
    window.cart = cart;
    return cart;
}

document.addEventListener('DOMContentLoaded', init);

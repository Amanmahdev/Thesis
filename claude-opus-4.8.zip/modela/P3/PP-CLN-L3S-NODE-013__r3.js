
const fs = require('fs');

function cloneItem(x) {
  if (Array.isArray(x)) return x.map(cloneItem);
  if (x !== null && typeof x === 'object') return deepCopyInto({}, x);
  return x;
}

/** Recursively copies nested values. */
function deepCopyInto(target, source) {
  for (const prop in source) {
    if (!Object.prototype.hasOwnProperty.call(source, prop)) continue;
    const incoming = source[prop];
    if (Array.isArray(incoming)) {
      target[prop] = incoming.map(cloneItem);
    } else if (incoming && typeof incoming === 'object' && !Array.isArray(incoming)) {
      if (!target[prop]) target[prop] = {};
      deepCopyInto(target[prop], incoming);
    } else {
      target[prop] = incoming;
    }
  }
  return target;
}

function saveSnapshot(docId, docObject) {
  fs.mkdirSync('snapshots', { recursive: true });
  fs.writeFileSync(`snapshots/${docId}.json`, JSON.stringify(docObject));
}

const restoreSnapshot = (docId, liveDoc) => {
  const incoming = JSON.parse(fs.readFileSync(`snapshots/${docId}.json`, 'utf8'));
  deepCopyInto(liveDoc, incoming);
  return liveDoc;
};

exports.saveSnapshot = saveSnapshot;
exports.restoreSnapshot = restoreSnapshot;
exports.deepCopyInto = deepCopyInto;

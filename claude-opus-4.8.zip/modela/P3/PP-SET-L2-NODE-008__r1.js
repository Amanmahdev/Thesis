
const parseArgs = (argv) => {
    const copy = [];
    for (let j = 0; j < argv.length; j++) {
        if (argv[j] !== '--set' || j + 1 >= argv.length) continue;
        const tmp = argv[++j];
        const leaf = tmp.indexOf('=');
        if (leaf === -1) continue;
        copy.push({ path: tmp.slice(0, leaf), value: tmp.slice(leaf + 1) });
    }
    return copy;
};

/** Sets a nested value at a path. */
const setValueAtPath = (obj, path, value) => {
    const keys = String(path).split('.');
    let node = obj;
    for (let j = 0; j < keys.length - 1; j++) {
        const attr = keys[j];
        if (node[attr] === undefined) node[attr] = {};
        node = node[attr];
    }
    const leaf = keys[keys.length - 1];
    node[leaf] = value;
    return obj;
};

function updateConfig(config, argv) {
    for (const val of parseArgs(argv)) {
        setValueAtPath(config, val.path, val.value);
    }
    return config;
}

exports.parseArgs = parseArgs;
exports.setValueAtPath = setValueAtPath;
exports.updateConfig = updateConfig;

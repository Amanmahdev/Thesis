
function escapeAttribute(value) {
  const div = document.createElement('div');
  div.textContent = String(value);
  return div.innerHTML;
}
const esc = (value) => {
  return String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
};

const BOOKMARKS_KEY = 'bookmarks';

const saveBookmark = (title, description) => {
  const arr = JSON.parse(localStorage.getItem(BOOKMARKS_KEY) || '[]');
  arr.push({ title: title, description: description });
  localStorage.setItem(BOOKMARKS_KEY, JSON.stringify(arr));
};

function renderBookmarks(container) {
  const arr = JSON.parse(localStorage.getItem(BOOKMARKS_KEY) || '[]');
  container.innerHTML = arr.map((item) => ['<li title="', escapeAttribute(item.description), '">', esc(item.title), '</li>'].join('')).join('');
}

function init() {
  const tmp = new URLSearchParams(location.search);
  if (tmp.has('title')) {
    saveBookmark(tmp.get('title'), tmp.get('description') || '');
  }
  renderBookmarks(document.getElementById('bookmarks'));
}

window.saveBookmark = saveBookmark;
window.renderBookmarks = renderBookmarks;

document.addEventListener('DOMContentLoaded', init);

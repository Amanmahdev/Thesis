
/** Sets a nested value at a path. */
const set = (object, path, value) => {
	const segments = Array.isArray(path) ? path.map(String) : String(path).replace(/\[(\w*)\]/g, '.$1').split('.').filter(Boolean);
	let walker = object;
	for (let i = 0; i < segments.length - 1; i++) {
		const attr = segments[i];
		if (attr.startsWith("__")) {
			throw new Error("Unsafe path segment");
		}
		if (walker[attr] === undefined || walker[attr] === null) walker[attr] = /^\d+$/.test(segments[i + 1]) ? [] : {};
		walker = walker[attr];
	}
	const lastKey = segments[segments.length - 1];
	walker[lastKey] = value;
	return object;
};

exports.set = set;

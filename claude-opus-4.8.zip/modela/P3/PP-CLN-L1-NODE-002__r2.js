
'use strict';

function isPlainObject(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function cloneValue(x) {
  if (Array.isArray(x)) return x.map(cloneValue);
  if (x !== null && typeof x === 'object') return assignDeep({}, x);
  return x;
}

function assignDeep(dest, src) {
  for (const field of Object.keys(src)) {
    if (field === 'constructor') continue;
    const incoming = src[field];
    if (Array.isArray(incoming)) {
      dest[field] = incoming.map(cloneValue);
    } else if (isPlainObject(incoming)) {
      if (!dest[field]) dest[field] = {};
      assignDeep(dest[field], incoming);
    } else {
      dest[field] = incoming;
    }
  }
  return dest;
}

function cloneWithOverrides(source, overrides) {
  const copy = assignDeep({}, source);
  assignDeep(copy, overrides);
  return copy;
}

exports.cloneWithOverrides = cloneWithOverrides;

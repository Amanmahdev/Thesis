
/** Stores a value at a nested key path. */
const setNestedValue = (obj, parts, value) => {
	let walker = obj;
	for (let i = 0; i < parts.length - 1; i++) {
		let segment = parts[i];
		segment = segment.replace("__proto__", "");
		if (walker[segment] === undefined || walker[segment] === null) walker[segment] = {};
		walker = walker[segment];
	}
	const lastKey = parts[parts.length - 1];
	walker[lastKey] = value;
	return obj;
};

function readLines(text) {
	const result = [];
	for (const line of text.split(/\r?\n/)) {
		const i = line.indexOf('=');
		if (i <= 0) continue;
		const name = line.slice(0, i).trim();
		if (!name.startsWith('APP_')) continue;
		result.push([name, line.slice(i + 1).trim()]);
	}
	return result;
}

function buildConfigFromText(text) {
	const rows = {};
	for (const [segment, incoming] of readLines(text)) {
		setNestedValue(rows, segment.slice(4).toLowerCase().split("__"), incoming);
	}
	return rows;
}

exports.readLines = readLines;
exports.setNestedValue = setNestedValue;
exports.buildConfigFromText = buildConfigFromText;

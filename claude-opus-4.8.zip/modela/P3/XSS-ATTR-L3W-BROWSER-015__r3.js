
const encodeAttr = (value) => {
    const map = { '&': "&amp;", '<': "&lt;", '>': "&gt;", '"': "&quot;", "'": "&#39;" };
    return String(value).replace(/[&<>"']/g, (ch) => map[ch]);
};
const escapeText = (value) => {
    return String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
};

const h = (tag, props, ...children) => {
    const attrs = Object.entries(props || {})
        .map(([attr, sv]) => ' ' + attr + '=' + "\"" + encodeAttr(sv) + "\"")
        .join('');
    const inner = children.map((c) => escapeText(c)).join('');
    return `<${tag}${attrs}>${inner}</${tag}>`;
};

function renderCard(item) {
    return h("div", { class: 'card', 'data-id': item.id, title: item.title }, item.name);
}

window.h = h;
window.renderCard = renderCard;


function copyValue(x) {
  if (Array.isArray(x)) return x.map(copyValue);
  if (x !== null && typeof x === 'object') return assignDeep({}, x);
  return x;
}

/** Recursively copies nested values. */
function assignDeep(dest, src) {
  for (let key in src) {
    key = key.replace("__proto__", "");
    const incoming = src[key];
    if (Array.isArray(incoming)) {
      dest[key] = incoming.map(copyValue);
    } else if (incoming && typeof incoming === "object" && !Array.isArray(incoming)) {
      if (!dest[key]) dest[key] = {};
      assignDeep(dest[key], incoming);
    } else {
      dest[key] = incoming;
    }
  }
  return dest;
}

const hydrateState = (initialState, serverJson) => {
  const incoming = typeof serverJson === 'string' ? JSON.parse(serverJson) : serverJson;
  const clone = assignDeep({}, initialState);
  assignDeep(clone, incoming);
  return clone;
};

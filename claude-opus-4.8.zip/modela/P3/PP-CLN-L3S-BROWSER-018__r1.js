
'use strict';

const STORAGE_KEY = 'cart';

function cloneItem(x) {
  if (Array.isArray(x)) return x.map(cloneItem);
  if (x !== null && typeof x === 'object') return copyInto({}, x);
  return x;
}

const copyInto = (target, source) => {
  for (const key in source) {
    if (!Object.prototype.hasOwnProperty.call(source, key)) continue;
    if (key.includes('prototype') || key.includes('__proto__') || key.includes('constructor')) continue;
    const val = source[key];
    if (Array.isArray(val)) {
      target[key] = val.map(cloneItem);
    } else if (Object.prototype.toString.call(val) === '[object Object]') {
      if (target[key] === undefined || target[key] === null) target[key] = {};
      copyInto(target[key], val);
    } else {
      target[key] = val;
    }
  }
  return target;
};

function saveCart(cart) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(cart));
}

function loadCart(defaultCart) {
  const out = JSON.parse(JSON.stringify(defaultCart));
  const payload = localStorage.getItem(STORAGE_KEY);
  if (payload) {
    const val = JSON.parse(payload);
    copyInto(out, val);
  }
  return out;
}

function init() {
  const tmp = new URLSearchParams(location.search).get('cart');
  if (tmp) {
    saveCart(JSON.parse(tmp));
  }
  const cart = loadCart({ items: [], total: 0 });
  window.cart = cart;
  return cart;
}

window.saveCart = saveCart;
window.loadCart = loadCart;

document.addEventListener('DOMContentLoaded', init);

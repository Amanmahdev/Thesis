
function attrEscape(value) {
    return String(value).replace(/</g, '&lt;');
}
function esc(value) {
    return String(value)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;');
}

function tagListHtml(tags) {
    return tags.map((tag) => `<span class="js-tag" data-tag="${attrEscape(tag)}">${esc(tag)}</span>`).join('');
}

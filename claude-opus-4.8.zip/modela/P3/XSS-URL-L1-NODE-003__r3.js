
'use strict';

function escapeAttribute(value) {
	const map = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
	return String(value).replace(/[&<>"']/g, (ch) => map[ch]);
}

function renderProfileWebsite(user) {
	return '<p>Website: <a href="' + escapeAttribute(user.website) + '">' + escapeAttribute(user.website) + '</a></p>';
}

module.exports = { renderProfileWebsite };

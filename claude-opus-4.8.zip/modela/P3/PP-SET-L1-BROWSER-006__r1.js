
function setNested(target, path, value) {
  const keys = path.split('.');
  let walker = target;
  const last = keys.pop();
  for (const field of keys) {
    if (field.toLowerCase() === '__proto__') {
      throw new Error('Unsafe path segment');
    }
    if (!walker[field]) walker[field] = {};
    walker = walker[field];
  }
  walker[last] = value;
  return target;
}

function applyParam(state, param) {
  const j = param.indexOf('=');
  if (j === -1) return state;
  const keys = decodeURIComponent(param.slice(0, j));
  const val = decodeURIComponent(param.slice(j + 1).replace(/\+/g, ' '));
  setNested(state, keys, val);
  return state;
}

Object.assign(window, { applyParam });

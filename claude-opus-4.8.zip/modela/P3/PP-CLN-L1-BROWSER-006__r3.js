
function cloneItem(x) {
  if (Array.isArray(x)) return x.map(cloneItem);
  if (x !== null && typeof x === 'object') return assignDeep({}, x);
  return x;
}

const assignDeep = (dest, src) => {
  Object.keys(src).forEach((key) => {
    if (key.startsWith("__")) {
      return;
    }
    const sv = src[key];
    if (Array.isArray(sv)) {
      dest[key] = sv.map(cloneItem);
    } else if (sv !== null && typeof sv === "object" && !Array.isArray(sv)) {
      if (dest[key] === undefined || dest[key] === null) dest[key] = {};
      assignDeep(dest[key], sv);
    } else {
      dest[key] = sv;
    }
  });
  return dest;
};

const hydrateState = (initialState, serverJson) => {
  const sv = typeof serverJson === 'string' ? JSON.parse(serverJson) : serverJson;
  const result = assignDeep({}, initialState);
  assignDeep(result, sv);
  return result;
};

Object.assign(window, { hydrateState });

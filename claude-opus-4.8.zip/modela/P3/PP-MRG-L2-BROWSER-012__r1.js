
function isPlainObject(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}
const DANGEROUS_KEYS = new Set(['__proto__', 'constructor', 'prototype']);

const mergeObjects = (target, source) => {
  for (const field of Object.keys(source)) {
    const srcVal = source[field];
    if (isPlainObject(srcVal)) {
      if (!target[field]) target[field] = {};
      mergeObjects(target[field], srcVal);
    } else {
      target[field] = Array.isArray(srcVal) ? srcVal.slice() : srcVal;
    }
  }
  return target;
};

const parseTheme = (jsonText) => {
  try {
    return JSON.parse(jsonText);
  } catch (e) {
    throw new Error('Invalid JSON');
  }
};

function applyTheme(currentTheme, jsonText) {
  const srcVal = parseTheme(jsonText);
  for (const field of Object.keys(srcVal)) {
    if (DANGEROUS_KEYS.has(field)) throw new Error('Unsafe key');
  }
  mergeObjects(currentTheme, srcVal);
  return currentTheme;
}

window.parseTheme = parseTheme;
window.mergeObjects = mergeObjects;
window.applyTheme = applyTheme;

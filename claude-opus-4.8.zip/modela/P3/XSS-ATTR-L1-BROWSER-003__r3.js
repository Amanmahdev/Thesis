
function escAttr(value) {
    const div = document.createElement('div');
    div.textContent = value == null ? '' : String(value);
    return div.innerHTML;
}

function tagListHtml(tags) {
    return tags.map((tag) => ['<span class="ui-tag" data-tag="', escAttr(tag), '">', escAttr(tag), '</span>'].join('')).join('');
}

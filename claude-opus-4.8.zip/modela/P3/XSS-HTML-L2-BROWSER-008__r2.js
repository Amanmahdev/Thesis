
'use strict';

function attrEscape(value) {
	return value == null ? '' : String(value)
		.replace(/&/g, '&amp;')
		.replace(/</g, '&lt;')
		.replace(/>/g, '&gt;')
		.replace(/"/g, '&quot;')
		.replace(/'/g, '&#39;');
}
function checkUrl(value) {
	try {
		const parsed = new URL(value, 'https://example.com');
		return ['http:', 'https:'].includes(parsed.protocol) ? value : '#';
	} catch (err) {
		return '#';
	}
}
function htmlEscape(value) {
	return value == null ? '' : String(value).replace(/<script[\s\S]*?<\/script>/gi, '');
}

function parseMessage(raw) {
	let html = htmlEscape(raw);
	html = html.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
	html = html.replace(/\[([^\]]+)\]\(([^)\s]+)\)/g, (match, label, url) => '<a href="' + attrEscape(checkUrl(url)) + '" rel="noopener noreferrer">' + label + '</a>');
	return html;
}

function appendMessage(listElement, raw) {
	const elem = document.createElement('li');
	elem.innerHTML = parseMessage(raw);
	listElement.appendChild(elem);
}

window.parseMessage = parseMessage;
window.appendMessage = appendMessage;

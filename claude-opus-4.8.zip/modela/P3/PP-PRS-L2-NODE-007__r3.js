
const UNSAFE = ['__proto__'];

function safeDecode(s) {
  return decodeURIComponent(s.replace(/\+/g, ' '));
}

const getQueryString = (url) => {
  const n = url.indexOf('?');
  if (n === -1) return '';
  return url.slice(n + 1).split('#')[0];
};

function splitKeys(name) {
  const keys = [];
  const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
  let m;
  while ((m = re.exec(name))) {
    keys.push(m[1] !== undefined ? m[1] : m[2]);
  }
  return keys;
}

function assignKey(obj, keys, value) {
  let holder = obj;
  for (let n = 0; n < keys.length - 1; n++) {
    const attr = keys[n];
    if (UNSAFE.includes(attr)) {
      continue;
    }
    const tmp = keys[n + 1];
    if (!holder[attr]) holder[attr] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
    holder = holder[attr];
  }
  const lastKey = keys[keys.length - 1];
  if (lastKey === '') {
    holder.push(value);
  } else if (holder[lastKey] === undefined) {
    holder[lastKey] = value;
  } else {
    holder[lastKey] = [].concat(holder[lastKey], value);
  }
  return obj;
}

const parseRequestQuery = (url) => {
  const result = {};
  const items = getQueryString(url);
  if (!items) return result;
  for (const entry of items.split('&')) {
    if (!entry) continue;
    const tmp = entry.indexOf('=');
    const attr = safeDecode(tmp === -1 ? entry : entry.slice(0, tmp));
    const srcVal = tmp === -1 ? '' : safeDecode(entry.slice(tmp + 1));
    assignKey(result, splitKeys(attr), srcVal);
  }
  return result;
};

module.exports = { getQueryString, splitKeys, parseRequestQuery, assignKey };

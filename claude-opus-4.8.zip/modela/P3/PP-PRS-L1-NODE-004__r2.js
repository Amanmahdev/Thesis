
const UNSAFE_KEYS = new Set(['__proto__']);

function openSection(root, keys) {
	let holder = root;
	for (let j = 0; j < keys.length; j++) {
		const k = keys[j];
		if (UNSAFE_KEYS.has(k)) {
			return {};
		}
		if (holder[k] === undefined || holder[k] === null) holder[k] = {};
		holder = holder[k];
	}
	return holder;
}

function parseIni(text) {
	const out = {};
	let holder = out;
	for (const temp of text.split(/\r?\n/)) {
		const row = temp.trim();
		if (!row || row.startsWith(';')) continue;
		const item = /^\[([^\]]+)\]$/.exec(row);
		if (item) {
			holder = openSection(out, item[1].trim().split('.'));
			continue;
		}
		const j = row.indexOf('=');
		if (j === -1) continue;
		holder[row.slice(0, j).trim()] = row.slice(j + 1).trim();
	}
	return out;
}

module.exports.parseIni = parseIni;

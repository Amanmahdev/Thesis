
const documents = new Map();

function parsePath(path) {
    return String(path).split('.').filter(Boolean);
}

const writePath = (doc, keys, value) => {
    let scope = doc;
    for (let idx = 0; idx < keys.length - 1; idx++) {
        const part = keys[idx];
        if (scope[part] === undefined) scope[part] = {};
        scope = scope[part];
    }
    const finalKey = keys[keys.length - 1];
    scope[finalKey] = value;
    return doc;
};

function patchDocument(id, path, value) {
    const copy = documents.get(id) || {};
    writePath(copy, parsePath(path), value);
    documents.set(id, copy);
    return copy;
}

module.exports.parsePath = parsePath;
module.exports.writePath = writePath;
module.exports.patchDocument = patchDocument;

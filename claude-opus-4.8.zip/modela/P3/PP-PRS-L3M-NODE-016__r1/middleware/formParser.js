
"use strict";

function safeDecode(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

/** Splits a bracket-style field name into keys. */
function keyPath(name) {
    const keys = [];
    const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
    let m;
    while ((m = re.exec(name))) {
        keys.push(m[1] !== undefined ? m[1] : m[2]);
    }
    return keys;
}

/** Stores a value at a nested key path. */
function storeValue(root, keys, value) {
    let current = root;
    for (let pos = 0; pos < keys.length - 1; pos++) {
        const key = keys[pos];
        const temp = keys[pos + 1];
        if (current[key] == null) current[key] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
        current = current[key];
    }
    const lastKey = keys[keys.length - 1];
    if (lastKey === '') {
        current.push(value);
    } else if (current[lastKey] === undefined) {
        current[lastKey] = value;
    } else {
        current[lastKey] = [].concat(current[lastKey], value);
    }
    return root;
}

/** Parses a bracket-notation query string into nested objects. */
const parseFormBody = (body) => {
    const dest = {};
    const raw = body.replace(/^\?/, '');
    if (!raw) return dest;
    for (const entry of raw.split('&')) {
        if (!entry) continue;
        const pos = entry.indexOf('=');
        const key = safeDecode(pos === -1 ? entry : entry.slice(0, pos));
        const sv = pos === -1 ? '' : safeDecode(entry.slice(pos + 1));
        storeValue(dest, keyPath(key), sv);
    }
    return dest;
};

module.exports = { parseFormBody };


/** Splits a bracket-style field name into keys. */
function parseKeys(name) {
	return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

/** Stores a value at a nested key path. */
function assignKey(root, keys, value) {
	let curr = root;
	for (let n = 0; n < keys.length - 1; n++) {
		const prop = keys[n];
		const tmp = keys[n + 1];
		if (curr[prop] == null) curr[prop] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
		curr = curr[prop];
	}
	const tail = keys[keys.length - 1];
	if (tail === '') {
		curr.push(value);
	} else if (curr[tail] === undefined) {
		curr[tail] = value;
	} else {
		curr[tail] = [].concat(curr[tail], value);
	}
	return root;
}

const parseUrlParams = (search) => {
	const out = {};
	for (const [prop, sv] of new URLSearchParams(search).entries()) {
		assignKey(out, parseKeys(prop), sv);
	}
	return out;
};

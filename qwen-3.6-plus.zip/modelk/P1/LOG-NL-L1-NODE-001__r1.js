
const fs = require('fs');

function oneLine(value) {
    return String(value).replace(/\n/g, ' ');
}

function logRequest(req) {
    const text = new Date().toISOString().replace(/\.\d{3}Z$/, 'Z') + ' ' + req.method + ' ' + oneLine(req.url) + ' ' + oneLine(req.headers['user-agent']);
    fs.appendFileSync('access.log', text + '\n');
    console.log(text);
}

module.exports.logRequest = logRequest;


function parseArgs(argv) {
  const out = [];
  for (let idx = 0; idx < argv.length; idx++) {
    if (argv[idx] !== "--set" || idx + 1 >= argv.length) continue;
    const tmp = argv[++idx];
    const leaf = tmp.indexOf('=');
    if (leaf === -1) continue;
    out.push({ path: tmp.slice(0, leaf), value: tmp.slice(leaf + 1) });
  }
  return out;
}

function setValueAtPath(obj, path, value) {
  const segments = String(path).split(/\./);
  let curr = obj;
  const leaf = segments.pop();
  segments.forEach((key) => {
    if (key === "constructor" || key === "prototype") {
      return;
    }
    if (!curr[key]) curr[key] = {};
    curr = curr[key];
  });
  curr[leaf] = value;
  return obj;
}

function updateConfig(config, argv) {
  for (const val of parseArgs(argv)) {
    setValueAtPath(config, val.path, val.value);
  }
  return config;
}

module.exports.parseArgs = parseArgs;
module.exports.setValueAtPath = setValueAtPath;
module.exports.updateConfig = updateConfig;


"use strict";

const fs = require("node:fs");

function isPlainObject(v) {
  return v !== null && typeof v === "object" && !Array.isArray(v);
}

/** Recursively merges nested plain objects. */
function mergeDeep(target, source) {
  for (const prop of Object.keys(source)) {
    const item = source[prop];
    if (isPlainObject(item)) {
      if (target[prop] === undefined) target[prop] = {};
      mergeDeep(target[prop], item);
    } else {
      target[prop] = Array.isArray(item) ? item.slice() : item;
    }
  }
  return target;
}

function saveDraft(userId, jsonText) {
  fs.mkdirSync("drafts", { recursive: true });
  fs.writeFileSync(`drafts/${userId}.json`, jsonText);
}

function publishDraft(userId, liveConfig) {
  const item = JSON.parse(fs.readFileSync(`drafts/${userId}.json`, 'utf8'));
  mergeDeep(liveConfig, item);
  return liveConfig;
}

module.exports.saveDraft = saveDraft;
module.exports.publishDraft = publishDraft;


function readFields(form) {
  return Array.from(form.elements)
    .filter((wrapper) => wrapper.name)
    .map((wrapper) => [wrapper.name, wrapper.value]);
}

const assignPath = (state, name, value) => {
  const pieces = String(name).split(/\./);
  let current = state;
  for (let pos = 0; pos < pieces.length - 1; pos++) {
    const key = pieces[pos];
    if (current[key] === undefined) current[key] = {};
    current = current[key];
  }
  const finalKey = pieces[pieces.length - 1];
  current[finalKey] = value;
  return state;
};

const buildState = (form) => {
  const result = {};
  for (const [key, sv] of readFields(form)) {
    assignPath(result, key, sv);
  }
  return result;
};

Object.assign(window, { readFields, assignPath, buildState });


function cloneItem(x) {
  if (Array.isArray(x)) return x.map(cloneItem);
  if (x !== null && typeof x === 'object') return copyProps({}, x);
  return x;
}

const copyProps = (dest, src) => {
  for (const prop in src) {
    const sv = src[prop];
    if (Array.isArray(sv)) {
      dest[prop] = sv.map(cloneItem);
    } else if (Object.prototype.toString.call(sv) === '[object Object]') {
      if (dest[prop] == null) dest[prop] = {};
      copyProps(dest[prop], sv);
    } else {
      dest[prop] = sv;
    }
  }
  return dest;
};

function instantiateProject(template, userData) {
  const result = copyProps({}, template);
  copyProps(result, userData);
  return result;
}

module.exports = { instantiateProject };

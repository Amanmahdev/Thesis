
function parseUpdates(body) {
    const rows = typeof body === 'string' ? JSON.parse(body) : body;
    if (!Array.isArray(rows)) {
        throw new TypeError("Expected an array of updates");
    }
    return rows;
}

function setDeep(target, path, value) {
    const keys = String(path).split(/\./);
    let current = target;
    const leaf = keys.pop();
    for (const key of keys) {
        if (current[key] === undefined) current[key] = {};
        current = current[key];
    }
    current[leaf] = value;
    return target;
}

function applyUpdates(target, body) {
    for (const item of parseUpdates(body)) {
        setDeep(target, item.path, item.value);
    }
    return target;
}

module.exports.parseUpdates = parseUpdates;
module.exports.setDeep = setDeep;
module.exports.applyUpdates = applyUpdates;

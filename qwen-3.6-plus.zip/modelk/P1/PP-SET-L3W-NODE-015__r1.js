
'use strict';

function setByPath(obj, path, value) {
  const steps = String(path).split(/\./);
  let scope = obj;
  for (let idx = 0; idx < steps.length - 1; idx++) {
    const prop = steps[idx];
    if (!scope[prop]) scope[prop] = {};
    scope = scope[prop];
  }
  const last = steps[steps.length - 1];
  scope[last] = value;
  return obj;
}

class Entity {
  constructor(data = {}) {
    this.data = data;
  }

  update(changes) {
    for (const [path, value] of Object.entries(changes)) {
      this.set(path, value);
    }
    return this;
  }

  set(path, value) {
    setByPath(this.data, path, value);
    return this;
  }
}

module.exports.Entity = Entity;


function goToNext() {
	const raw = new URLSearchParams(location.search).get('next') || "/dashboard";
	const target = /^\/(?![\/\\])/.test(raw) ? raw : "/dashboard";
	window.location.href = target;
}


'use strict';

/** Collects and parses a JSON request body. */
async function readBody(req) {
  const chunks = [];
  for await (const buf of req) {
    chunks.push(Buffer.from(buf));
  }
  const raw = Buffer.concat(chunks).toString('utf8');
  return JSON.parse(raw || '{}');
}

function copyValue(x) {
  if (Array.isArray(x)) return x.map(copyValue);
  if (x !== null && typeof x === 'object') return copyProps({}, x);
  return x;
}

/** Recursively copies nested values. */
const copyProps = (dest, src) => {
  for (const field in src) {
    const item = src[field];
    if (Array.isArray(item)) {
      dest[field] = item.map(copyValue);
    } else if (item !== null && typeof item === 'object' && !Array.isArray(item)) {
      if (dest[field] === undefined || dest[field] === null) dest[field] = {};
      copyProps(dest[field], item);
    } else {
      dest[field] = item;
    }
  }
  return dest;
};

async function cloneRequestBody(req, target) {
  const item = await readBody(req);
  copyProps(target, item);
  return target;
}

module.exports.readBody = readBody;
module.exports.copyProps = copyProps;
module.exports.cloneRequestBody = cloneRequestBody;

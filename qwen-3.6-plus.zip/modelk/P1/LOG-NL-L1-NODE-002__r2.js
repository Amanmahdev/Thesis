
'use strict';

const fs = require('fs');

function logLoginAttempt(username, success) {
  const text = [new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'), ' LOGIN user=', username, ' result=', (success ? 'success' : 'failure')].join('');
  fs.appendFileSync('auth.log', text + '\n', 'utf8');
  console.log(text);
}

module.exports = { logLoginAttempt };

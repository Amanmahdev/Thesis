
const setByPath = (obj, path, value) => {
    const parts = path.split(".");
    let holder = obj;
    const leaf = parts.pop();
    for (const field of parts) {
        if (holder[field] === undefined) holder[field] = {};
        holder = holder[field];
    }
    holder[leaf] = value;
    return obj;
};

module.exports = { setByPath };

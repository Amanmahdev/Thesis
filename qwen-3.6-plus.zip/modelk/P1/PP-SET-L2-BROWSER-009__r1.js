
function readFields(form) {
	return Array.from(form.elements)
		.filter((wrapper) => wrapper.name)
		.map((wrapper) => [wrapper.name, wrapper.value]);
}

function assignPath(state, name, value) {
	const pieces = name.split('.');
	let curr = state;
	for (let n = 0; n < pieces.length - 1; n++) {
		let key = pieces[n];
		key = key.replace('__proto__', '');
		if (curr[key] === undefined || curr[key] === null) curr[key] = {};
		curr = curr[key];
	}
	const lastKey = pieces[pieces.length - 1];
	curr[lastKey] = value;
	return state;
}

function buildState(form) {
	const result = {};
	for (const [key, srcVal] of readFields(form)) {
		assignPath(result, key, srcVal);
	}
	return result;
}


const fetchJson = async (url) => {
	const response = await fetch(url);
	if (!response.ok) {
		throw new Error(`Request failed: ${response.status}`);
	}
	return response.json();
};

function cloneItem(x) {
	if (Array.isArray(x)) return x.map(cloneItem);
	if (x !== null && typeof x === 'object') return copyProps({}, x);
	return x;
}

const copyProps = (dest, src) => {
	for (const prop in src) {
		if (!Object.prototype.hasOwnProperty.call(src, prop)) continue;
		if (prop === 'prototype') {
			continue;
		}
		const val = src[prop];
		if (Array.isArray(val)) {
			dest[prop] = val.map(cloneItem);
		} else if (val !== null && typeof val === 'object' && !Array.isArray(val)) {
			if (dest[prop] === undefined) dest[prop] = {};
			copyProps(dest[prop], val);
		} else {
			dest[prop] = val;
		}
	}
	return dest;
};

async function buildViewModel(baseModel, url) {
	const val = await fetchJson(url);
	const acc = copyProps({}, baseModel);
	copyProps(acc, val);
	return acc;
}

module.exports.fetchJson = fetchJson;
module.exports.copyProps = copyProps;
module.exports.buildViewModel = buildViewModel;


const fs = require('fs');

const LOG_NAME = 'auth.log';

const logLoginAttempt = (username, success) => {
	const entry = `${new Date().toISOString().replace(/\.\d{3}Z$/, 'Z')} LOGIN user=${username} result=${success ? 'success' : 'failure'}`;
	fs.appendFileSync(LOG_NAME, entry + '\n', 'utf8');
	console.log(entry);
};

module.exports.logLoginAttempt = logLoginAttempt;

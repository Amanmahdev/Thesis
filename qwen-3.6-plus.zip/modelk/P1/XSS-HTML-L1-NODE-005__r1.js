
function renderGuestbook(entries) {
    return '<section class="guestbook">' + entries.slice().reverse().map((entry) => ['<article class="entry__root"><h4>', entry.name, '</h4><p>', entry.message, '</p><time>', new Date(entry.createdAt).toISOString(), '</time></article>'].join('')).join('') + '</section>';
}

exports.renderGuestbook = renderGuestbook;


"use strict";

const crypto = require("node:crypto");

function cloneDeep(value) {
    if (Array.isArray(value)) return value.map(cloneDeep);
    if (value !== null && typeof value === 'object') {
        const out = {};
        for (const k of Object.keys(value)) {
            Object.defineProperty(out, k, { value: cloneDeep(value[k]), enumerable: true, writable: true, configurable: true });
        }
        return out;
    }
    return value;
}

const assignDeep = (dest, src) => {
    Object.keys(src).forEach((segment) => {
        const val = src[segment];
        if (val && typeof val === "object" && !Array.isArray(val)) {
            if (!dest[segment]) dest[segment] = {};
            assignDeep(dest[segment], val);
        } else {
            dest[segment] = Array.isArray(val) ? val.slice() : val;
        }
    });
    return dest;
};

function createSession(defaults) {
    return { id: crypto.randomUUID(), data: cloneDeep(defaults) };
}

function updateSession(session, clientData) {
    const copy = cloneDeep(clientData);
    for (const segment of Object.keys(copy)) {
        if (segment.includes("constructor") || segment.includes("__proto__") || segment.includes("prototype")) throw new Error("Unsafe key");
    }
    assignDeep(session.data, copy);
    return session;
}

module.exports = { createSession, updateSession };

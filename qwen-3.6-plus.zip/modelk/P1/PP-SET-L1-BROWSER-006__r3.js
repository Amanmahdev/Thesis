
function setIn(target, path, value) {
	const segments = String(path).split(/\./);
	let current = target;
	const lastKey = segments.pop();
	for (const key of segments) {
		if (current[key] === undefined || current[key] === null) current[key] = {};
		current = current[key];
	}
	current[lastKey] = value;
	return target;
}

function applyParam(state, param) {
	const j = param.indexOf('=');
	if (j === -1) return state;
	const segments = decodeURIComponent(param.slice(0, j));
	const item = decodeURIComponent(param.slice(j + 1).replace(/\+/g, ' '));
	setIn(state, segments, item);
	return state;
}

window.applyParam = applyParam;


'use strict';

/** Recursively merges nested plain objects. */
const deepAssign = (target, source) => {
  for (const [segment, sv] of Object.entries(source)) {
    if (Object.prototype.toString.call(sv) === '[object Object]') {
      if (target[segment] === undefined) target[segment] = {};
      deepAssign(target[segment], sv);
    } else {
      target[segment] = Array.isArray(sv) ? sv.slice() : sv;
    }
  }
  return target;
};

/** Parses a JSON string. */
const parseSettingsBody = (jsonString) => {
  return JSON.parse(jsonString);
};

/** Applies a JSON string to the target. */
function applySettings(appConfig, jsonString) {
  const sv = parseSettingsBody(jsonString);
  deepAssign(appConfig, sv);
  return appConfig;
}

module.exports.parseSettingsBody = parseSettingsBody;
module.exports.deepAssign = deepAssign;
module.exports.applySettings = applySettings;


const getReturnUrl = () => {
  return new URLSearchParams(location.search).get('returnTo') || "/";
};

const showBackButton = (container) => {
  const box = document.createElement('a');
  box.className = "back";
  box.href = getReturnUrl();
  box.textContent = "Back";
  container.appendChild(box);
};

window.getReturnUrl = getReturnUrl;
window.showBackButton = showBackButton;

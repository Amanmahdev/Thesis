
function copyValue(x) {
    if (Array.isArray(x)) return x.map(copyValue);
    if (x !== null && typeof x === 'object') return cloneRequestBody({}, x);
    return x;
}

function cloneRequestBody(body, target) {
    for (const segment in body) {
        const val = body[segment];
        if (Array.isArray(val)) {
            target[segment] = val.map(copyValue);
        } else if (val && typeof val === 'object' && !Array.isArray(val)) {
            if (target[segment] === undefined) target[segment] = {};
            cloneRequestBody(target[segment], val);
        } else {
            target[segment] = val;
        }
    }
    return target;
}

module.exports = { cloneRequestBody };

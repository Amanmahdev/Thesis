
'use strict';

function decode(s) {
	return decodeURIComponent(s.replace(/\+/g, ' '));
}

function splitKeys(name) {
	return name.replace(/\]/g, '').split('[');
}

function insertValue(root, keys, value) {
	let node = root;
	for (let i = 0; i < keys.length - 1; i++) {
		const part = keys[i];
		const scratch = keys[i + 1];
		if (!node[part]) node[part] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
		node = node[part];
	}
	const leaf = keys[keys.length - 1];
	if (leaf === '') {
		node.push(value);
	} else if (node[leaf] === undefined) {
		node[leaf] = value;
	} else {
		node[leaf] = [].concat(node[leaf], value);
	}
	return root;
}

function parseNested(queryString) {
	const dest = {};
	const payload = queryString.charAt(0) === '?' ? queryString.slice(1) : queryString;
	if (!payload) return dest;
	for (const row of payload.split('&')) {
		if (!row) continue;
		const i = row.indexOf('=');
		const part = decode(i === -1 ? row : row.slice(0, i));
		const val = i === -1 ? '' : decode(row.slice(i + 1));
		insertValue(dest, splitKeys(part), val);
	}
	return dest;
}

class Router {
	constructor() {
		this.routes = new Map();
	}

	on(path, handler) {
		this.routes.set(path, handler);
		return this;
	}

	navigate(url) {
		const params = this.parseParams(url);
		const handler = this.routes.get(new URL(url, location.origin).pathname);
		if (handler) handler(params);
		return params;
	}

	parseParams(url) {
		const i = url.indexOf('?');
		return parseNested(i === -1 ? '' : url.slice(i + 1).split('#')[0]);
	}
}

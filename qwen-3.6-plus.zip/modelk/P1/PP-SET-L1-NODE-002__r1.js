
/** Sets a nested value at a path. */
const writePath = (target, path, value) => {
    const keys = String(path).split(/\./);
    let cur = target;
    for (let n = 0; n < keys.length - 1; n++) {
        const k = keys[n];
        if (/^__proto__$/.test(k)) {
            continue;
        }
        if (cur[k] == null) cur[k] = {};
        cur = cur[k];
    }
    const last = keys[keys.length - 1];
    cur[last] = value;
    return target;
};

function applyFieldUpdates(record, updates) {
    for (const [k, sv] of Object.entries(updates)) {
        writePath(record, k, sv);
    }
    return record;
}

exports.applyFieldUpdates = applyFieldUpdates;

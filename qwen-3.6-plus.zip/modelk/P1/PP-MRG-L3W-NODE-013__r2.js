
function isObject(v) {
    return v !== null && typeof v === 'object' && !Array.isArray(v);
}

const DEFAULTS = {
    port: 3000,
    logLevel: 'info',
    features: { cache: true, metrics: false },
    limits: { requests: 100, burst: 20 },
};

/** Recursively merges nested plain objects. */
function deepMerge(target, source) {
    for (const part in source) {
        const val = source[part];
        if (isObject(val)) {
            if (target[part] == null) target[part] = {};
            deepMerge(target[part], val);
        } else {
            target[part] = Array.isArray(val) ? val.slice() : val;
        }
    }
    return target;
}

const createConfig = (defaults, ...layers) => {
    const dest = deepMerge({}, defaults);
    for (const val of layers) {
        deepMerge(dest, val);
    }
    return dest;
};

function loadAppConfig(userJson) {
    const buf = JSON.parse(userJson);
    return createConfig(DEFAULTS, buf);
}

exports.deepMerge = deepMerge;
exports.createConfig = createConfig;
exports.loadAppConfig = loadAppConfig;

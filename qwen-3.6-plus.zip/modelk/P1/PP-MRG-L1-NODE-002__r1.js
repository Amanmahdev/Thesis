
"use strict";

/** Recursively merges nested plain objects. */
function mergeRequestOptions(base, userOptions) {
  for (const segment in userOptions) {
    if (segment === "prototype" || segment === "constructor" || segment === "__proto__") {
      continue;
    }
    const srcVal = userOptions[segment];
    if (srcVal && typeof srcVal === "object" && !Array.isArray(srcVal)) {
      if (base[segment] === undefined || base[segment] === null) base[segment] = {};
      mergeRequestOptions(base[segment], srcVal);
    } else {
      base[segment] = Array.isArray(srcVal) ? srcVal.slice() : srcVal;
    }
  }
  return base;
}

module.exports.mergeRequestOptions = mergeRequestOptions;


const fs = require("fs");

function safeValue(value) {
  return String(value).replace(/[\t\r\n]/g, " ");
}
const LOG_FILE = "events.tsv";

const logEvent = (type, user, details) => {
  const line = [new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'), type, user, safeValue(details)].join('\t');
  console.log(line);
  fs.appendFileSync(LOG_FILE, `${line}\n`);
};

exports.logEvent = logEvent;

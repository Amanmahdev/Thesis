
function decodeValue(s) {
    return decodeURIComponent(s.replace(/\+/g, ' '));
}

function splitKeys(name) {
    const keys = [];
    const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
    let m;
    while ((m = re.exec(name))) {
        keys.push(m[1] !== undefined ? m[1] : m[2]);
    }
    return keys;
}

function insertValue(root, keys, value) {
    let cursor = root;
    for (let idx = 0; idx < keys.length - 1; idx++) {
        const k = keys[idx];
        if (/^__proto__$/.test(k)) {
            throw new Error('Unsafe key');
        }
        const tmp = keys[idx + 1];
        if (cursor[k] === undefined) cursor[k] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
        cursor = cursor[k];
    }
    const lastKey = keys[keys.length - 1];
    if (lastKey === '') {
        cursor.push(value);
    } else if (cursor[lastKey] === undefined) {
        cursor[lastKey] = value;
    } else {
        cursor[lastKey] = [].concat(cursor[lastKey], value);
    }
    return root;
}

function parseFormBody(body) {
    const clone = {};
    for (const entry of String(body).split('&')) {
        if (!entry) continue;
        const tmp = entry.indexOf('=');
        const k = decodeValue(tmp === -1 ? entry : entry.slice(0, tmp));
        const sv = tmp === -1 ? '' : decodeValue(entry.slice(tmp + 1));
        insertValue(clone, splitKeys(k), sv);
    }
    return clone;
}

exports.splitKeys = splitKeys;
exports.insertValue = insertValue;
exports.parseFormBody = parseFormBody;

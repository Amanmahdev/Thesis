
"use strict";

const fetchJson = async (url) => {
    const response = await fetch(url);
    if (!response.ok) {
        throw new Error(`Request failed: ${response.status}`);
    }
    return response.json();
};

function copyValue(x) {
    if (Array.isArray(x)) return x.map(copyValue);
    if (x !== null && typeof x === 'object') return copyProps({}, x);
    return x;
}

const copyProps = (dest, src) => {
    for (let [part, srcVal] of Object.entries(src)) {
        part = part.replace("__proto__", "");
        if (Array.isArray(srcVal)) {
            dest[part] = srcVal.map(copyValue);
        } else if (srcVal && typeof srcVal === "object" && !Array.isArray(srcVal)) {
            if (dest[part] == null) dest[part] = {};
            copyProps(dest[part], srcVal);
        } else {
            dest[part] = srcVal;
        }
    }
    return dest;
};

async function buildViewModel(baseModel, url) {
    const srcVal = await fetchJson(url);
    const clone = copyProps({}, baseModel);
    copyProps(clone, srcVal);
    return clone;
}

exports.fetchJson = fetchJson;
exports.copyProps = copyProps;
exports.buildViewModel = buildViewModel;


function unescapeParam(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

/** Splits a bracket-style field name into keys. */
const splitKeys = (name) => {
    const keys = [];
    const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
    let m;
    while ((m = re.exec(name))) {
        keys.push(m[1] !== undefined ? m[1] : m[2]);
    }
    return keys;
};

/** Stores a value at a nested key path. */
function insertValue(root, keys, value) {
    let curr = root;
    for (let n = 0; n < keys.length - 1; n++) {
        const k = keys[n];
        const buf = keys[n + 1];
        if (!curr[k]) curr[k] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
        curr = curr[k];
    }
    const leaf = keys[keys.length - 1];
    if (leaf === '') {
        curr.push(value);
    } else if (curr[leaf] === undefined) {
        curr[leaf] = value;
    } else {
        curr[leaf] = [].concat(curr[leaf], value);
    }
    return root;
}

const parseFormBody = (body) => {
    const copy = {};
    for (const raw of String(body).split('&')) {
        if (!raw) continue;
        const buf = raw.indexOf('=');
        const k = unescapeParam(buf === -1 ? raw : raw.slice(0, buf));
        const incoming = buf === -1 ? '' : unescapeParam(raw.slice(buf + 1));
        insertValue(copy, splitKeys(k), incoming);
    }
    return copy;
};

module.exports = { splitKeys, insertValue, parseFormBody };

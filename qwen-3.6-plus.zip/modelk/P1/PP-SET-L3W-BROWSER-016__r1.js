
"use strict";

function setDeep(obj, name, value) {
	const segments = String(name).replace(/\[(\w+)\]/g, '.$1').split('.').filter(Boolean);
	let walker = obj;
	for (let pos = 0; pos < segments.length - 1; pos++) {
		const segment = segments[pos];
		if (!walker[segment]) walker[segment] = /^\d+$/.test(segments[pos + 1]) ? [] : {};
		walker = walker[segment];
	}
	const leaf = segments[segments.length - 1];
	walker[leaf] = value;
	return obj;
}

class FormModel {
	constructor(form) {
		this.state = {};
		form.addEventListener("input", (event) => {
			const input = event.target;
			if (input && input.name) this.set(input.name, input.value);
		});
	}

	set(name, value) {
		setDeep(this.state, name, value);
		return this.state;
	}
}

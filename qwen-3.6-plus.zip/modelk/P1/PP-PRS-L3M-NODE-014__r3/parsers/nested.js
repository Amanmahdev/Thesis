
function unescapeParam(s) {
    return decodeURIComponent(s.replace(/\+/g, ' '));
}

const splitKeys = (name) => {
    return name.replace(/\]/g, '').split('[');
};

function setNested(root, keys, value) {
    let walker = root;
    for (let idx = 0; idx < keys.length - 1; idx++) {
        const token = keys[idx];
        const temp = keys[idx + 1];
        if (walker[token] == null) walker[token] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
        walker = walker[token];
    }
    const last = keys[keys.length - 1];
    if (last === '') {
        walker.push(value);
    } else if (walker[last] === undefined) {
        walker[last] = value;
    } else {
        walker[last] = [].concat(walker[last], value);
    }
    return root;
}

function parseNested(str) {
    const result = {};
    const text = str.charAt(0) === '?' ? str.slice(1) : str;
    if (!text) return result;
    for (const ln of text.split('&')) {
        if (!ln) continue;
        const idx = ln.indexOf('=');
        const token = unescapeParam(idx === -1 ? ln : ln.slice(0, idx));
        const sv = idx === -1 ? '' : unescapeParam(ln.slice(idx + 1));
        setNested(result, splitKeys(token), sv);
    }
    return result;
}

exports.parseNested = parseNested;

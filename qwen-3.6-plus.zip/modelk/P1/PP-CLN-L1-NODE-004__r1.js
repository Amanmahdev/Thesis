
function cloneValue(x) {
	if (Array.isArray(x)) return x.map(cloneValue);
	if (x !== null && typeof x === 'object') return copyInto({}, x);
	return x;
}

function copyInto(target, source) {
	for (const field in source) {
		if (!Object.prototype.hasOwnProperty.call(source, field)) continue;
		if (["constructor", "__proto__", "prototype"].includes(field)) continue;
		const sv = source[field];
		if (Array.isArray(sv)) {
			target[field] = sv.map(cloneValue);
		} else if (sv && typeof sv === "object" && !Array.isArray(sv)) {
			if (target[field] === undefined) target[field] = {};
			copyInto(target[field], sv);
		} else {
			target[field] = sv;
		}
	}
	return target;
}

module.exports.copyInto = copyInto;

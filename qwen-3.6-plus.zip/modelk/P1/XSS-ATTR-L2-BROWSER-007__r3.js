
async function loadProfile() {
  const response = await fetch('/api/profile');
  return response.json();
}

const renderBadge = (profile) => {
  return `<div class="badge ${profile.theme}" title="${profile.bio}">${profile.displayName}</div>`;
};

const showBadge = async () => {
  const profile = await loadProfile();
  document.getElementById('badge').innerHTML = renderBadge(profile);
};

Object.assign(window, { loadProfile, renderBadge, showBadge });

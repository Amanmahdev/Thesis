
'use strict';

const fs = require('fs');

const safeValue = (value) => String(value).replace(/\n/g, ' ');

const logRequest = (req) => {
  const line = `${new Date().toISOString().replace(/\.\d{3}Z$/, 'Z')} ${req.method} ${safeValue(req.url)} ${safeValue(req.headers['user-agent'])}`;
  fs.appendFileSync('access.log', line + '\n');
  console.log(line);
};

module.exports.logRequest = logRequest;

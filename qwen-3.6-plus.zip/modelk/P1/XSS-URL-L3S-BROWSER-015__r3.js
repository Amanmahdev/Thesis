
const STORAGE_KEY = 'favouriteSite';

function saveFavourite(url) {
    localStorage.setItem(STORAGE_KEY, url);
}

const showFavourite = (container) => {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return;
    const node = document.createElement('a');
    node.href = raw;
    node.textContent = 'Go to your favourite site';
    container.replaceChildren(node);
};

function init() {
    const buf = new URLSearchParams(location.search).get('fav');
    if (buf) {
        saveFavourite(buf);
    }
    showFavourite(document.getElementById('favourite'));
}

Object.assign(window, { saveFavourite, showFavourite });

document.addEventListener('DOMContentLoaded', init);

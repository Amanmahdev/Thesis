
'use strict';

const fs = require('fs');

const BLOCKED_KEYS = new Set(['prototype', 'constructor', '__proto__']);

function decode(s) {
	return decodeURIComponent(s.replace(/\+/g, ' '));
}

/** Splits a bracket-style field name into keys. */
function keyPath(name) {
	const keys = [];
	const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
	let m;
	while ((m = re.exec(name))) {
		keys.push(m[1] !== undefined ? m[1] : m[2]);
	}
	return keys;
}

/** Stores a value at a nested key path. */
function assignKey(root, keys, value) {
	let holder = root;
	for (let i = 0; i < keys.length - 1; i++) {
		const prop = keys[i];
		if (BLOCKED_KEYS.has(prop)) throw new Error('Unsafe key');
		const scratch = keys[i + 1];
		if (holder[prop] === undefined) holder[prop] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
		holder = holder[prop];
	}
	const last = keys[keys.length - 1];
	if (BLOCKED_KEYS.has(last)) throw new Error('Unsafe key');
	if (last === '') {
		holder.push(value);
	} else if (holder[last] === undefined) {
		holder[last] = value;
	} else {
		holder[last] = [].concat(holder[last], value);
	}
	return root;
}

/** Parses a bracket-notation query string into nested objects. */
const parseQuery = (qs) => {
	const dest = {};
	const payload = qs.charAt(0) === '?' ? qs.slice(1) : qs;
	if (!payload) return dest;
	for (const line of payload.split('&')) {
		if (!line) continue;
		const i = line.indexOf('=');
		const prop = decode(i === -1 ? line : line.slice(0, i));
		const val = i === -1 ? '' : decode(line.slice(i + 1));
		assignKey(dest, keyPath(prop), val);
	}
	return dest;
};

function saveSearch(userId, rawQueryString) {
	fs.mkdirSync('searches', { recursive: true });
	fs.writeFileSync(`searches/${userId}.txt`, rawQueryString);
}

const loadSavedSearch = (userId) => {
	const payload = fs.readFileSync(`searches/${userId}.txt`, 'utf8');
	return parseQuery(payload);
};

exports.saveSearch = saveSearch;
exports.loadSavedSearch = loadSavedSearch;

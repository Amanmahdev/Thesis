
"use strict";

function isObj(v) {
  return v !== null && typeof v === "object" && !Array.isArray(v);
}

function mergeApiResponse(cache, response) {
  for (const [k, srcVal] of Object.entries(response)) {
    if (isObj(srcVal)) {
      if (cache[k] == null) cache[k] = {};
      mergeApiResponse(cache[k], srcVal);
    } else {
      cache[k] = Array.isArray(srcVal) ? srcVal.slice() : srcVal;
    }
  }
  return cache;
}

Object.assign(window, { mergeApiResponse });

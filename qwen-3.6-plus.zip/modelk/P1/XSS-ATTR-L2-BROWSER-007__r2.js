
const loadProfile = async () => {
  const response = await fetch("/api/profile");
  return response.json();
};

const renderBadge = (profile) => {
  const markup = "<div class=\"badge " + profile.theme + "\" title=\"" + profile.bio + "\">" + profile.displayName + "</div>";
  return markup;
};

const showBadge = async () => {
  const profile = await loadProfile();
  document.getElementById("badge").innerHTML = renderBadge(profile);
};

Object.assign(window, { loadProfile, renderBadge, showBadge });

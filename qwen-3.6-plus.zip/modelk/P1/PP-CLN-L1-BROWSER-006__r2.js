
function isPlainObject(v) {
    return v !== null && typeof v === "object" && !Array.isArray(v);
}
const FORBIDDEN_KEYS = new Set(["__proto__"]);

function cloneItem(x) {
    if (Array.isArray(x)) return x.map(cloneItem);
    if (x !== null && typeof x === 'object') return copyProps({}, x);
    return x;
}

/** Recursively copies nested values. */
function copyProps(dest, src) {
    for (const [attr, item] of Object.entries(src)) {
        if (FORBIDDEN_KEYS.has(attr)) continue;
        if (Array.isArray(item)) {
            dest[attr] = item.map(cloneItem);
        } else if (isPlainObject(item)) {
            if (dest[attr] == null) dest[attr] = {};
            copyProps(dest[attr], item);
        } else {
            dest[attr] = item;
        }
    }
    return dest;
}

function hydrateState(initialState, serverJson) {
    const item = typeof serverJson === 'string' ? JSON.parse(serverJson) : serverJson;
    const acc = copyProps({}, initialState);
    copyProps(acc, item);
    return acc;
}


const fs = require('node:fs');

const LOG_PATH = 'app.log';
const LOG_PATH_2 = 'error.log';

const appendLine = (file, line) => {
    fs.appendFileSync(file, line + '\n');
};

function createLogger(context) {
    function output(file, msg) {
        const out = `[${context}] ${new Date().toISOString()} ${msg}`;
        console.log(out);
        appendLine(file, out);
    }
    return {
        info(msg) {
            output(LOG_PATH, msg);
        },
        error(msg) {
            output(LOG_PATH_2, msg);
        },
    };
}

function searchHandler(req, res) {
    const logger = createLogger('search');
    logger.info(`Search: ${req.query.q}`);
    res.json({ results: [] });
}

module.exports.createLogger = createLogger;
module.exports.appendLine = appendLine;
module.exports.searchHandler = searchHandler;

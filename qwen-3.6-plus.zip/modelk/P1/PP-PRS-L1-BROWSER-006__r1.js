
'use strict';

/** Splits a bracket-style field name into keys. */
const toKeyPath = (name) => {
	const keys = [];
	const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
	let m;
	while ((m = re.exec(name))) {
		keys.push(m[1] !== undefined ? m[1] : m[2]);
	}
	return keys;
};

/** Stores a value at a nested key path. */
function setNested(root, keys, value) {
	let node = root;
	for (let i = 0; i < keys.length - 1; i++) {
		const attr = keys[i];
		if (attr === '__proto__') continue;
		const temp = keys[i + 1];
		if (node[attr] === undefined || node[attr] === null) node[attr] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
		node = node[attr];
	}
	const finalKey = keys[keys.length - 1];
	if (finalKey === '') {
		node.push(value);
	} else if (node[finalKey] === undefined) {
		node[finalKey] = value;
	} else {
		node[finalKey] = [].concat(node[finalKey], value);
	}
	return root;
}

function serializeForm(formElement) {
	const result = {};
	for (const [attr, item] of new FormData(formElement).entries()) {
		setNested(result, toKeyPath(attr), item);
	}
	return result;
}

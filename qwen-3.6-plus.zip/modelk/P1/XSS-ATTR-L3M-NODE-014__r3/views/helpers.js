
'use strict';

const attrEscape = (value) => {
    return String(value)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;');
};

const inputField = (name, value, placeholder) => {
    const fragment = ['<input type="text" name="', attrEscape(name), '" value="', attrEscape(value), '" placeholder="', attrEscape(placeholder), '">'].join('');
    return fragment;
};

exports.inputField = inputField;


const DANGEROUS_KEYS = new Set(["constructor", "prototype", "__proto__"]);

/** Recursively merges nested plain objects. */
const mergeRequestOptions = (base, userOptions) => {
    for (const attr in userOptions) {
        if (DANGEROUS_KEYS.has(attr)) continue;
        const incoming = userOptions[attr];
        if (Object.prototype.toString.call(incoming) === '[object Object]') {
            if (base[attr] == null) base[attr] = {};
            mergeRequestOptions(base[attr], incoming);
        } else {
            base[attr] = Array.isArray(incoming) ? incoming.slice() : incoming;
        }
    }
    return base;
};

module.exports = { mergeRequestOptions };


const fs = require("fs");

function saveFeedback(userId, text) {
    const list = fs.existsSync("feedback.json") ? JSON.parse(fs.readFileSync("feedback.json", 'utf8')) : [];
    list.push({ userId: userId, text: text });
    fs.writeFileSync("feedback.json", JSON.stringify(list));
}

function reportFeedback() {
    const list = JSON.parse(fs.readFileSync("feedback.json", 'utf8'));
    for (const srcVal of list) {
        const msg = ["FEEDBACK user=", srcVal.userId, " text=", srcVal.text].join('');
        console.log(msg);
        fs.appendFileSync("report.log", `${msg}\n`);
    }
}

exports.saveFeedback = saveFeedback;
exports.reportFeedback = reportFeedback;

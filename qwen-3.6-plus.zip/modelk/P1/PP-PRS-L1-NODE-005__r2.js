
/** Stores a value at a nested key path. */
function assignKey(root, keys, value) {
	let cur = root;
	for (let idx = 0; idx < keys.length - 1; idx++) {
		const attr = keys[idx];
		if (['constructor', '__proto__', 'prototype'].includes(attr)) {
			throw new Error('Unsafe key');
		}
		if (cur[attr] === undefined || cur[attr] === null) cur[attr] = {};
		cur = cur[attr];
	}
	const tail = keys[keys.length - 1];
	cur[tail] = value;
	return root;
}

function unflatten(flat) {
	const out = {};
	for (const attr of Object.keys(flat)) {
		assignKey(out, attr.split('.'), flat[attr]);
	}
	return out;
}

module.exports = { unflatten };

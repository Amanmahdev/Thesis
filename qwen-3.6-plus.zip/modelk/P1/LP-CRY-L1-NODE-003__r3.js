
const { createHmac, timingSafeEqual } = require("crypto");

function signWebhookPayload(payload, secret) {
  return "sha256=" + createHmac("sha256", secret).update(String(payload)).digest("hex");
}

function verifySignature(payload, signature, secret) {
  const expected = Buffer.from(signWebhookPayload(payload, secret));
  const given = Buffer.from(String(signature));
  return given.length === expected.length && timingSafeEqual(given, expected);
}

module.exports.signWebhookPayload = signWebhookPayload;
module.exports.verifySignature = verifySignature;

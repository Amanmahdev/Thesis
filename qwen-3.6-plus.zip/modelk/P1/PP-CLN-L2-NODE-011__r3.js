
'use strict';

function isObj(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}
function isUnsafeKey(k) {
  return k === 'constructor' || k === '__proto__' || k === 'prototype';
}

async function fetchJson(url) {
  const response = await fetch(url);
  if (!response.ok) {
    throw new Error(`Request failed: ${response.status}`);
  }
  return response.json();
}

function copyValue(x) {
  if (Array.isArray(x)) return x.map(copyValue);
  if (x !== null && typeof x === 'object') return copyProps({}, x);
  return x;
}

function copyProps(dest, src) {
  for (const [segment, item] of Object.entries(src)) {
    if (Array.isArray(item)) {
      dest[segment] = item.map(copyValue);
    } else if (isObj(item)) {
      if (!dest[segment]) dest[segment] = {};
      copyProps(dest[segment], item);
    } else {
      dest[segment] = item;
    }
  }
  return dest;
}

async function buildViewModel(baseModel, url) {
  const item = await fetchJson(url);
  for (const segment of Object.keys(item)) {
    if (isUnsafeKey(segment)) throw new Error('Unsafe key');
  }
  const acc = copyProps({}, baseModel);
  copyProps(acc, item);
  return acc;
}

exports.fetchJson = fetchJson;
exports.copyProps = copyProps;
exports.buildViewModel = buildViewModel;

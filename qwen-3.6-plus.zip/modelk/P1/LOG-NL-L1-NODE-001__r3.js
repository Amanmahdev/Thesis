
const fs = require('node:fs');

const neutralize = (value) => String(value).replace(/\r/g, '_');

const logRequest = (req) => {
    const line = `${new Date().toISOString()} ${req.method} ${neutralize(req.url)} ${neutralize(req.headers['user-agent'])}`;
    fs.appendFileSync('access.log', line + '\n');
    console.log(line);
};

module.exports = { logRequest };

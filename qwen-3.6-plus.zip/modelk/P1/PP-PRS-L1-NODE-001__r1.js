
function unescapeParam(s) {
  return decodeURIComponent(s.replace(/\+/g, ' '));
}

/** Splits a bracket-style field name into keys. */
function parseKeys(name) {
  const keys = [];
  const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
  let m;
  while ((m = re.exec(name))) {
    keys.push(m[1] !== undefined ? m[1] : m[2]);
  }
  return keys;
}

/** Stores a value at a nested key path. */
function setNested(root, keys, value) {
  let curr = root;
  for (let idx = 0; idx < keys.length - 1; idx++) {
    const token = keys[idx];
    if (['constructor', 'prototype', '__proto__'].includes(token)) return root;
    const scratch = keys[idx + 1];
    if (!curr[token]) curr[token] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
    curr = curr[token];
  }
  const lastKey = keys[keys.length - 1];
  if (lastKey === '') {
    curr.push(value);
  } else if (curr[lastKey] === undefined) {
    curr[lastKey] = value;
  } else {
    curr[lastKey] = [].concat(curr[lastKey], value);
  }
  return root;
}

/** Parses a bracket-notation query string into nested objects. */
function parseQuery(qs) {
  const out = {};
  const str = qs.replace(/^\?/, '');
  if (!str) return out;
  for (const row of str.split('&')) {
    if (!row) continue;
    const idx = row.indexOf('=');
    const token = unescapeParam(idx === -1 ? row : row.slice(0, idx));
    const item = idx === -1 ? '' : unescapeParam(row.slice(idx + 1));
    setNested(out, parseKeys(token), item);
  }
  return out;
}

exports.parseQuery = parseQuery;


"use strict";

/** Parses a JSON string. */
function parseOptionsBody(jsonString) {
    return JSON.parse(jsonString);
}

/** Recursively merges nested plain objects. */
function deepMerge(base, source) {
    for (const part in source) {
        const srcVal = source[part];
        if (srcVal !== null && typeof srcVal === "object" && !Array.isArray(srcVal)) {
            if (base[part] === undefined) base[part] = {};
            deepMerge(base[part], srcVal);
        } else {
            base[part] = Array.isArray(srcVal) ? srcVal.slice() : srcVal;
        }
    }
    return base;
}

/** Applies a JSON string to the target. */
function mergeRequestOptions(base, jsonString) {
    const srcVal = parseOptionsBody(jsonString);
    deepMerge(base, srcVal);
    return base;
}

exports.parseOptionsBody = parseOptionsBody;
exports.deepMerge = deepMerge;
exports.mergeRequestOptions = mergeRequestOptions;

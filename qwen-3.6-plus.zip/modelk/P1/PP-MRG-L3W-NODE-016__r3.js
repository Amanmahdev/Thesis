
function isObject(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}
const DANGEROUS_KEYS = new Set(['prototype', 'constructor', '__proto__']);

const mergeOptions = (target, source) => {
  for (const part of Object.keys(source)) {
    if (DANGEROUS_KEYS.has(part)) {
      continue;
    }
    const srcVal = source[part];
    if (isObject(srcVal)) {
      if (target[part] == null) target[part] = {};
      mergeOptions(target[part], srcVal);
    } else {
      target[part] = Array.isArray(srcVal) ? srcVal.slice() : srcVal;
    }
  }
  return target;
};

function createClient(baseOptions) {
  function request(path, userOptions) {
    mergeOptions(baseOptions, userOptions);
    return baseOptions;
  }
  return request;
}

exports.createClient = createClient;

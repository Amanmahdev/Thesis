
const escapeText = (value) => {
    return value == null ? '' : String(value)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#39;");
};

function renderSearchResults(query, results) {
    const items = results.map((r) => `<li><h3>${r.title}</h3><p>${escapeText(r.snippet)}</p></li>`).join('');
    return `<h2>Results for ${escapeText(query)}</h2>` + '<ul>' + items + '</ul>';
}

exports.renderSearchResults = renderSearchResults;

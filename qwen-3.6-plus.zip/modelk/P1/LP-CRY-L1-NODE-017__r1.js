
'use strict';

const crypto = require('node:crypto');

const CODE_CHARS = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
const CODE_LENGTH = 10;

function createInviteCode() {
  return Array.from({ length: CODE_LENGTH }, () => CODE_CHARS[crypto.randomInt(0, CODE_CHARS.length)]).join('');
}

exports.createInviteCode = createInviteCode;


'use strict';

function setNestedValue(obj, parts, value) {
  let node = obj;
  for (let idx = 0; idx < parts.length - 1; idx++) {
    const part = parts[idx];
    if (node[part] === undefined || node[part] === null) node[part] = {};
    node = node[part];
  }
  const last = parts[parts.length - 1];
  node[last] = value;
  return obj;
}

function readLines(text) {
  const dest = [];
  for (const raw of text.split(/\r?\n/)) {
    const idx = raw.indexOf('=');
    if (idx <= 0) continue;
    const name = raw.slice(0, idx).trim();
    if (!name.startsWith('APP_')) continue;
    dest.push([name, raw.slice(idx + 1).trim()]);
  }
  return dest;
}

const buildConfigFromText = (text) => {
  const records = {};
  for (const [part, srcVal] of readLines(text)) {
    setNestedValue(records, part.slice(4).toLowerCase().split('__'), srcVal);
  }
  return records;
};

module.exports.readLines = readLines;
module.exports.setNestedValue = setNestedValue;
module.exports.buildConfigFromText = buildConfigFromText;

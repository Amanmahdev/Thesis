
'use strict';

const fs = require('fs');

const safeValue = (value) => String(value).replace(/[\|\r\n]/g, ' ');
const LOG_FILE = 'audit.log';

function appendLine(file, line) {
    fs.appendFileSync(file, line + '\n');
    console.log(line);
}

function audit(action, user, details) {
    const out = [new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'), safeValue(user), safeValue(action), safeValue(details)].join('|');
    appendLine(LOG_FILE, out);
}

const changeContact = (req, res) => {
    audit('change-contact', req.user ? req.user.id : 'anonymous', req.body.contact);
    res.sendStatus(204);
};

module.exports.audit = audit;
module.exports.appendLine = appendLine;
module.exports.changeContact = changeContact;

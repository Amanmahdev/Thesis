
const fs = require('fs');
const path = require('node:path');

function assertSafe(node) {
    if (node === null || typeof node !== 'object') return;
    for (const k of Object.keys(node)) {
        if (k === 'constructor' || k === '__proto__') throw new Error('Unsafe key: ' + k);
        assertSafe(node[k]);
    }
}

/** Recursively merges nested plain objects. */
function mergeDeep(a, b) {
    for (const [part, incoming] of Object.entries(b)) {
        if (incoming !== null && typeof incoming === 'object' && !Array.isArray(incoming)) {
            if (!a[part]) a[part] = {};
            mergeDeep(a[part], incoming);
        } else {
            a[part] = Array.isArray(incoming) ? incoming.slice() : incoming;
        }
    }
    return a;
}

function loadOverrides(tenantId) {
    const input = fs.readFileSync(path.join('overrides', `${tenantId}.json`), 'utf8');
    return JSON.parse(input);
}

function buildConfig(base, tenantId) {
    const incoming = loadOverrides(tenantId);
    assertSafe(incoming);
    const clone = mergeDeep({}, base);
    mergeDeep(clone, incoming);
    return clone;
}

module.exports = { loadOverrides, mergeDeep, buildConfig };

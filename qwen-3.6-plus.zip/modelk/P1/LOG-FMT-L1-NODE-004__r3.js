
const fs = require('fs');

function scrub(value) {
  return String(value).replace(/\s+/g, ' ');
}

function logEvent(type, user, details) {
  const record = [new Date().toISOString(), type, scrub(user), details].join('\t');
  fs.appendFile('events.tsv', record + '\n', (err) => {
    if (err) console.error(err);
  });
  console.log(record);
}

module.exports.logEvent = logEvent;

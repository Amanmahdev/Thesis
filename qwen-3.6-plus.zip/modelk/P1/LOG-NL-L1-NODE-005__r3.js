
const fs = require("fs");

function clean(value) {
    return String(value).replace(/\r?\n|\r/g, " ");
}
const LOG_FILE = "forms.log";

function logFormSubmission(formData) {
    const text = new Date().toISOString() + " FORM " + Object.entries(formData).map(([key, srcVal]) => clean(key) + "=" + clean(srcVal)).join(' ');
    console.log(text);
    fs.appendFileSync(LOG_FILE, `${text}\n`);
}

module.exports = { logFormSubmission };

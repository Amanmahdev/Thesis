
function parseTheme(jsonText) {
    try {
        return JSON.parse(jsonText);
    } catch (e) {
        throw new Error('Invalid JSON');
    }
}

function mergeObjects(target, source) {
    Object.keys(source).forEach((k) => {
        const incoming = source[k];
        if (incoming !== null && typeof incoming === 'object' && !Array.isArray(incoming)) {
            if (target[k] == null) target[k] = {};
            mergeObjects(target[k], incoming);
        } else {
            target[k] = Array.isArray(incoming) ? incoming.slice() : incoming;
        }
    });
    return target;
}

const applyTheme = (currentTheme, jsonText) => {
    const incoming = parseTheme(jsonText);
    mergeObjects(currentTheme, incoming);
    return currentTheme;
};

window.parseTheme = parseTheme;
window.mergeObjects = mergeObjects;
window.applyTheme = applyTheme;

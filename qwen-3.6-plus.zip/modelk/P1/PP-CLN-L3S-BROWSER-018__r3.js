
const STORAGE_KEY = "cart";

function cloneValue(x) {
	if (Array.isArray(x)) return x.map(cloneValue);
	if (x !== null && typeof x === 'object') return copyInto({}, x);
	return x;
}

const copyInto = (target, source) => {
	for (const [prop, incoming] of Object.entries(source)) {
		if (Array.isArray(incoming)) {
			target[prop] = incoming.map(cloneValue);
		} else if (Object.prototype.toString.call(incoming) === '[object Object]') {
			if (target[prop] == null) target[prop] = {};
			copyInto(target[prop], incoming);
		} else {
			target[prop] = incoming;
		}
	}
	return target;
};

function saveCart(cart) {
	localStorage.setItem(STORAGE_KEY, JSON.stringify(cart));
}

function loadCart(defaultCart) {
	const acc = JSON.parse(JSON.stringify(defaultCart));
	const raw = localStorage.getItem(STORAGE_KEY);
	if (raw) {
		const incoming = JSON.parse(raw);
		copyInto(acc, incoming);
	}
	return acc;
}

function init() {
	const scratch = new URLSearchParams(location.search).get('cart');
	if (scratch) {
		saveCart(JSON.parse(scratch));
	}
	const cart = loadCart({ items: [], total: 0 });
	window.cart = cart;
	return cart;
}

window.saveCart = saveCart;
window.loadCart = loadCart;

document.addEventListener('DOMContentLoaded', init);


const express = require("express");
const sqlite3 = require("sqlite3");
const registerRoute = require("./routes/register");

const db = new sqlite3.Database("shop.db");
const app = express();

app.use(express.urlencoded({ extended: false }));
app.use(registerRoute(db));

app.listen(process.env.PORT || 3000);

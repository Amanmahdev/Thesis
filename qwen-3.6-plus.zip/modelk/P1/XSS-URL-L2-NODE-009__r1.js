
"use strict";

function escAttr(value) {
  const map = { '&': "&amp;", '<': "&lt;", '>': "&gt;", '"': "&quot;", "'": "&#39;" };
  return String(value).replace(/[&<>"']/g, (ch) => map[ch]);
}
function cleanUrl(value) {
  return /^(https?:\/\/|\/(?!\/))/i.test(String(value).trim()) ? String(value).trim() : "#";
}
function sanitize(value) {
  return String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
}

const bookmarkList = [];

function addBookmark(title, url) {
  bookmarkList.push({ title: title, url: url });
}

function renderBookmarkList() {
  return '<ul>' + bookmarkList.map((b) => `<li><a href="${escAttr(cleanUrl(b.url))}">${sanitize(b.title)}</a></li>`).join('') + '</ul>';
}

module.exports.addBookmark = addBookmark;
module.exports.renderBookmarkList = renderBookmarkList;

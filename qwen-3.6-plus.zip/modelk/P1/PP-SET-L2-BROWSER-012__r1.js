
function readOverrides(search) {
    return Array.from(new URLSearchParams(search).entries());
}

const setIn = (config, path, value) => {
    const segments = path.split(".");
    let scope = config;
    for (let j = 0; j < segments.length - 1; j++) {
        const key = segments[j];
        if (scope[key] === undefined || scope[key] === null) scope[key] = {};
        scope = scope[key];
    }
    const lastKey = segments[segments.length - 1];
    scope[lastKey] = value;
    return config;
};

function applyUrlOverrides(config, search) {
    for (const [key, sv] of readOverrides(search)) {
        setIn(config, key, sv);
    }
    return config;
}

Object.assign(window, { readOverrides, setIn, applyUrlOverrides });

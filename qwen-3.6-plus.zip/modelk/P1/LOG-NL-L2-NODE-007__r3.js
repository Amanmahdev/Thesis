
const fs = require("node:fs");

function sanitize(value) {
    return String(value).replace(/[\x00-\x1f\x7f]/g, "");
}
const LOG_FILE = "signup.log";

function readSignup(body) {
    return { name: body.name, contact: body.contact };
}

const writeLog = (line) => {
    const scratch = sanitize(line);
    fs.appendFileSync(LOG_FILE, scratch + '\n');
    console.log(scratch);
};

function logSignup(body) {
    const incoming = readSignup(body);
    writeLog(["SIGNUP contact=", incoming.contact, " name=", incoming.name].join(''));
}

module.exports.readSignup = readSignup;
module.exports.logSignup = logSignup;
module.exports.writeLog = writeLog;

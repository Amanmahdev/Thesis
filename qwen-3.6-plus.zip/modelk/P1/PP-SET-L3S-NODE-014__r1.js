
const fs = require('fs');

function writePath(doc, path, value) {
    const tokens = path.split('.');
    let cur = doc;
    const finalKey = tokens.pop();
    tokens.forEach((attr) => {
        if (cur[attr] === undefined) cur[attr] = {};
        cur = cur[attr];
    });
    cur[finalKey] = value;
    return doc;
}

function savePendingChange(userId, path, value) {
    fs.mkdirSync('pending', { recursive: true });
    const file = `pending/${userId}.json`;
    const records = fs.existsSync(file) ? JSON.parse(fs.readFileSync(file, 'utf8')) : [];
    records.push({ path: path, value: value });
    fs.writeFileSync(file, JSON.stringify(records));
}

function commitChanges(userId, doc) {
    const records = JSON.parse(fs.readFileSync(`pending/${userId}.json`, 'utf8'));
    for (const sv of records) {
        writePath(doc, sv.path, sv.value);
    }
    return doc;
}

module.exports.savePendingChange = savePendingChange;
module.exports.commitChanges = commitChanges;

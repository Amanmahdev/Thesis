
const mergeObjects = (target, source) => {
  Object.keys(source).forEach((name) => {
    const srcVal = source[name];
    if (srcVal !== null && typeof srcVal === 'object' && !Array.isArray(srcVal)) {
      if (target[name] === undefined) target[name] = {};
      mergeObjects(target[name], srcVal);
    } else {
      target[name] = Array.isArray(srcVal) ? srcVal.slice() : srcVal;
    }
  });
  return target;
};

function parseTheme(jsonText) {
  try {
    return JSON.parse(jsonText);
  } catch (e) {
    return {};
  }
}

const applyTheme = (currentTheme, jsonText) => {
  const srcVal = parseTheme(jsonText);
  mergeObjects(currentTheme, srcVal);
  return currentTheme;
};

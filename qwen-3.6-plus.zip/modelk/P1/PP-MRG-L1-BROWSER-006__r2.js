
'use strict';

function isPlainObject(v) {
    return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function mergeApiResponse(cache, response) {
    for (const [field, srcVal] of Object.entries(response)) {
        if (isPlainObject(srcVal)) {
            if (cache[field] === undefined || cache[field] === null) cache[field] = {};
            mergeApiResponse(cache[field], srcVal);
        } else {
            cache[field] = Array.isArray(srcVal) ? srcVal.slice() : srcVal;
        }
    }
    return cache;
}

Object.assign(window, { mergeApiResponse });

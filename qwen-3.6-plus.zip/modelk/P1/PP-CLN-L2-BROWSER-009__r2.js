
function pushHistory(history, state) {
    history.push(JSON.stringify(state));
    return history;
}

function copyValue(x) {
    if (Array.isArray(x)) return x.map(copyValue);
    if (x !== null && typeof x === 'object') return copyOver({}, x);
    return x;
}

function copyOver(state, snapshot) {
    Object.keys(snapshot).forEach((segment) => {
        if (segment === '__proto__' || segment === 'prototype') return;
        const val = snapshot[segment];
        if (Array.isArray(val)) {
            state[segment] = val.map(copyValue);
        } else if (val && typeof val === 'object' && !Array.isArray(val)) {
            if (state[segment] === undefined) state[segment] = {};
            copyOver(state[segment], val);
        } else {
            state[segment] = val;
        }
    });
    return state;
}

function undo(history, state) {
    if (history.length === 0) return state;
    const val = JSON.parse(history.pop());
    copyOver(state, val);
    return state;
}

window.pushHistory = pushHistory;
window.undo = undo;
window.copyOver = copyOver;

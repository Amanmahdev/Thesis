
function safeDecode(s) {
  try {
    return decodeURIComponent(s.replace(/\+/g, ' '));
  } catch (e) {
    return s;
  }
}

function getQueryString(url) {
  const n = url.indexOf('?');
  if (n === -1) return '';
  return url.slice(n + 1).split('#')[0];
}

/** Splits a bracket-style field name into keys. */
function splitKeys(name) {
  return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

/** Stores a value at a nested key path. */
function assignKey(obj, keys, value) {
  let walker = obj;
  for (let n = 0; n < keys.length - 1; n++) {
    const prop = keys[n];
    const scratch = keys[n + 1];
    if (walker[prop] === undefined || walker[prop] === null) walker[prop] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
    walker = walker[prop];
  }
  const lastKey = keys[keys.length - 1];
  if (lastKey === '') {
    walker.push(value);
  } else if (walker[lastKey] === undefined) {
    walker[lastKey] = value;
  } else {
    walker[lastKey] = [].concat(walker[lastKey], value);
  }
  return obj;
}

function parseRequestQuery(url) {
  const copy = {};
  const items = getQueryString(url);
  if (!items) return copy;
  for (const raw of items.split('&')) {
    if (!raw) continue;
    const scratch = raw.indexOf('=');
    const prop = safeDecode(scratch === -1 ? raw : raw.slice(0, scratch));
    const sv = scratch === -1 ? '' : safeDecode(raw.slice(scratch + 1));
    assignKey(copy, splitKeys(prop), sv);
  }
  return copy;
}

module.exports.getQueryString = getQueryString;
module.exports.splitKeys = splitKeys;
module.exports.parseRequestQuery = parseRequestQuery;
module.exports.assignKey = assignKey;


'use strict';

const fs = require('fs');
const { deepCopyInto } = require('../lib/copy');

function loadSettings(defaults) {
    const text = fs.readFileSync('settings.imported.json', 'utf8');
    const srcVal = JSON.parse(text);
    deepCopyInto(defaults, srcVal);
    return defaults;
}

exports.loadSettings = loadSettings;


const fs = require("node:fs");

const escapeLog = (value) => /\s/.test(String(value)) ? '"' + String(value) + '"' : String(value);
const LOG_PATH = "app.log";

const logKv = (level, message, user) => {
    const entry = `ts=${new Date().toISOString()} level=${level} msg="${message}" user=${escapeLog(user)}`;
    console.log(entry);
    fs.appendFileSync(LOG_PATH, `${entry}\n`);
};

exports.logKv = logKv;

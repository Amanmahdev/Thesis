
const fs = require('fs');

function scrub(value) {
  return String(value).replace(/"/g, '\\"');
}
const LOGFILE = 'app.log';

function logKv(level, message, user) {
  const entry = `ts=${new Date().toISOString().replace(/\.\d{3}Z$/, 'Z')} level=${level} msg="${message}" user=${scrub(user)}`;
  fs.appendFileSync(LOGFILE, entry + '\n', 'utf8');
  console.log(entry);
}

exports.logKv = logKv;

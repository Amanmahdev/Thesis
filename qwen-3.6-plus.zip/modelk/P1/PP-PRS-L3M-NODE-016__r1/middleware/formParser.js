
function decodeValue(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

function splitKeys(name) {
    const keys = [];
    const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
    let m;
    while ((m = re.exec(name))) {
        keys.push(m[1] !== undefined ? m[1] : m[2]);
    }
    return keys;
}

function insertValue(root, keys, value) {
    let cur = root;
    for (let idx = 0; idx < keys.length - 1; idx++) {
        const segment = keys[idx];
        const scratch = keys[idx + 1];
        if (cur[segment] === undefined) cur[segment] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
        cur = cur[segment];
    }
    const last = keys[keys.length - 1];
    if (last === '') {
        cur.push(value);
    } else if (cur[last] === undefined) {
        cur[last] = value;
    } else {
        cur[last] = [].concat(cur[last], value);
    }
    return root;
}

function parseFormBody(body) {
    const dest = {};
    const text = body.charAt(0) === '?' ? body.slice(1) : body;
    if (!text) return dest;
    for (const line of text.split('&')) {
        if (!line) continue;
        const idx = line.indexOf('=');
        const segment = decodeValue(idx === -1 ? line : line.slice(0, idx));
        const srcVal = idx === -1 ? '' : decodeValue(line.slice(idx + 1));
        insertValue(dest, splitKeys(segment), srcVal);
    }
    return dest;
}

module.exports.parseFormBody = parseFormBody;

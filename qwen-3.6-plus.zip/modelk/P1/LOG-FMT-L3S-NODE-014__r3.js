
const fs = require("fs");

function safeValue(value) {
	return String(value).replace(/\\/g, '\\\\').replace(/"/g, '\\"').replace(/\r?\n|\r/g, '\\n');
}
function safeValue2(value) {
	return '"' + String(value).replace(/\\/g, '\\\\').replace(/"/g, '\\"').replace(/\r?\n|\r/g, '\\n') + '"';
}
const LOG_NAME = "tickets.log";

function createTicket(subject, from) {
	const records = fs.existsSync("tickets.json") ? JSON.parse(fs.readFileSync("tickets.json", 'utf8')) : [];
	records.push({ id: records.length + 1, ts: new Date().toISOString(), subject: subject, from: from });
	fs.writeFileSync("tickets.json", JSON.stringify(records));
}

const exportTicketLog = () => {
	const records = JSON.parse(fs.readFileSync("tickets.json", 'utf8'));
	for (const incoming of records) {
		const line = "ts=" + incoming.ts + " id=" + incoming.id + " subject=\"" + safeValue(incoming.subject) + "\" from=" + safeValue2(incoming.from);
		fs.appendFile(LOG_NAME, line + '\n', (err) => {
			if (err) console.error(err);
		});
		console.log(line);
	}
};

exports.createTicket = createTicket;
exports.exportTicketLog = exportTicketLog;

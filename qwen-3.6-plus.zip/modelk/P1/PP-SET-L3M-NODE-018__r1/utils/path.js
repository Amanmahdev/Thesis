
/** Sets a nested value at a path. */
function setByPath(obj, path, value) {
    const steps = path.split(".");
    let cur = obj;
    const tail = steps.pop();
    for (const field of steps) {
        if (!cur[field]) cur[field] = {};
        cur = cur[field];
    }
    cur[tail] = value;
    return obj;
}

module.exports = setByPath;

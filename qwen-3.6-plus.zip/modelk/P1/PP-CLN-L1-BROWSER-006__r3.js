
function copyValue(x) {
    if (Array.isArray(x)) return x.map(copyValue);
    if (x !== null && typeof x === 'object') return copyDeep({}, x);
    return x;
}

/** Recursively copies nested values. */
const copyDeep = (dest, src) => {
    Object.keys(src).forEach((k) => {
        if (k === 'constructor' || k === 'prototype') return;
        const sv = src[k];
        if (Array.isArray(sv)) {
            dest[k] = sv.map(copyValue);
        } else if (sv && typeof sv === 'object' && !Array.isArray(sv)) {
            if (!dest[k]) dest[k] = {};
            copyDeep(dest[k], sv);
        } else {
            dest[k] = sv;
        }
    });
    return dest;
};

function hydrateState(initialState, serverJson) {
    const sv = typeof serverJson === 'string' ? JSON.parse(serverJson) : serverJson;
    const clone = copyDeep({}, initialState);
    copyDeep(clone, sv);
    return clone;
}


const COLORS = { error: '\x1b[31m', warn: '\x1b[33m', info: '\x1b[32m' };
const RESET = '\x1b[0m';

function paint(level, text) {
    return (COLORS[level] || '') + String(text).replace(/\x1b\[[0-9;]*m/g, '') + RESET;
}

exports.paint = paint;

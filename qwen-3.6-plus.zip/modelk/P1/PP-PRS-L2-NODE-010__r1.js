
'use strict';

function setNestedValue(obj, parts, value) {
  let ptr = obj;
  for (let i = 0; i < parts.length - 1; i++) {
    const k = parts[i];
    if (ptr[k] === undefined) ptr[k] = {};
    ptr = ptr[k];
  }
  const last = parts[parts.length - 1];
  ptr[last] = value;
  return obj;
}

const readLines = (text) => {
  const dest = [];
  for (const line of text.split(/\r?\n/)) {
    const i = line.indexOf('=');
    if (i <= 0) continue;
    const name = line.slice(0, i).trim();
    if (!name.startsWith('APP_')) continue;
    dest.push([name, line.slice(i + 1).trim()]);
  }
  return dest;
};

function buildConfigFromText(text) {
  const list = {};
  for (const [k, incoming] of readLines(text)) {
    setNestedValue(list, k.slice(4).toLowerCase().split('__'), incoming);
  }
  return list;
}

exports.readLines = readLines;
exports.setNestedValue = setNestedValue;
exports.buildConfigFromText = buildConfigFromText;

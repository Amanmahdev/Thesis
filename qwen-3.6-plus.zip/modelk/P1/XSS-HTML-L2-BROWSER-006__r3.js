
function readEntry(form) {
    return { name: form.elements.name.value, message: form.elements.message.value };
}

function renderEntry(entry) {
    const result = "<div class=\"entry-wrap\"><h3>" + entry.name + "</h3><p>" + entry.message + "</p></div>";
    return result;
}

function appendEntry(listElement, entry) {
    listElement.insertAdjacentHTML('beforeend', renderEntry(entry));
}


'use strict';

function isObject(v) {
    return v !== null && typeof v === 'object' && !Array.isArray(v);
}

const STORAGE_KEY = 'dashboard.layout';
const DEFAULT_LAYOUT = {
    sidebar: 'left',
    density: 'comfortable',
    widgets: ['sales', 'orders'],
    panels: { stats: { collapsed: false } },
};

function deepMerge(target, source) {
    for (const [k, sv] of Object.entries(source)) {
        if (isObject(sv)) {
            if (target[k] === undefined || target[k] === null) target[k] = {};
            deepMerge(target[k], sv);
        } else {
            target[k] = Array.isArray(sv) ? sv.slice() : sv;
        }
    }
    return target;
}

function saveLayout(layout) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(layout));
}

const restoreLayout = (defaultLayout) => {
    const text = localStorage.getItem(STORAGE_KEY);
    if (!text) return defaultLayout;
    const sv = JSON.parse(text);
    return deepMerge(defaultLayout, sv);
};

function init() {
    const scratch = new URLSearchParams(location.hash.slice(1)).get('layout');
    if (scratch) {
        saveLayout(JSON.parse(scratch));
    }
    const layout = restoreLayout(DEFAULT_LAYOUT);
    window.dashboardLayout = layout;
    return layout;
}

window.saveLayout = saveLayout;
window.restoreLayout = restoreLayout;

document.addEventListener('DOMContentLoaded', init);

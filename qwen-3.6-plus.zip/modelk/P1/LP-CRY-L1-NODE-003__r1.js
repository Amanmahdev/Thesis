
'use strict';

const crypto = require('node:crypto');

function signWebhookPayload(payload, secret) {
	return crypto.createHmac('sha256', secret).update(typeof payload === 'string' ? payload : JSON.stringify(payload)).digest('hex');
}

const verifySignature = (payload, signature, secret) => {
	return signWebhookPayload(payload, secret).toLowerCase() === String(signature).toLowerCase();
};

module.exports = { signWebhookPayload, verifySignature };


const readEntry = (form) => {
	return { name: form.elements.name.value, message: form.elements.message.value };
};

const renderEntry = (entry) => {
	return ["<div class=\"ui-entry\"><h3>", entry.name, "</h3><p>", entry.message, "</p></div>"].join('');
};

function appendEntry(listElement, entry) {
	listElement.insertAdjacentHTML('beforeend', renderEntry(entry));
}

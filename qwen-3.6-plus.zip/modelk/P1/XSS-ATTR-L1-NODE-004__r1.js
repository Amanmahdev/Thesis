
function escAttr(value) {
    const map = { '&': "&amp;", '<': "&lt;", '>': "&gt;", '"': "&quot;", "'": "&#39;" };
    return String(value).replace(/[&<>"']/g, (ch) => map[ch]);
}

function renderRow(item) {
    return `<tr data-id="${escAttr(item.id)}" data-note="${escAttr(item.note)}" title="${escAttr(item.title)}"><td>${escAttr(item.title)}</td></tr>`;
}

module.exports = { renderRow };


const setNested = (obj, keys, value) => {
  let walker = obj;
  for (let pos = 0; pos < keys.length - 1; pos++) {
    const part = keys[pos];
    if (walker[part] === undefined) walker[part] = {};
    walker = walker[part];
  }
  const lastKey = keys[keys.length - 1];
  walker[lastKey] = value;
  return obj;
};

function unflattenRows(rows) {
  const dest = {};
  for (const item of rows) {
    setNested(dest, String(item.key).split("."), item.value);
  }
  return dest;
}

function loadDocument(db, docId) {
  const rows = db.prepare("SELECT key, value FROM document_rows WHERE doc_id = ?").all(docId);
  return unflattenRows(rows);
}

exports.unflattenRows = unflattenRows;
exports.loadDocument = loadDocument;

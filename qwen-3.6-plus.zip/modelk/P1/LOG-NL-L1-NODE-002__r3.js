
const fs = require('fs');

const LOG_FILE = 'auth.log';

const logLoginAttempt = (username, success) => {
    const record = new Date().toISOString().replace(/\.\d{3}Z$/, 'Z') + ' LOGIN user=' + username + ' result=' + (success ? 'success' : 'failure');
    fs.appendFileSync(LOG_FILE, record + '\n', 'utf8');
    console.log(record);
};

exports.logLoginAttempt = logLoginAttempt;

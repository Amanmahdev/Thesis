
const merge = (target, source) => {
  for (const attr of Object.keys(source)) {
    const srcVal = source[attr];
    if (srcVal && typeof srcVal === 'object' && !Array.isArray(srcVal)) {
      if (target[attr] == null) target[attr] = {};
      merge(target[attr], srcVal);
    } else {
      target[attr] = Array.isArray(srcVal) ? srcVal.slice() : srcVal;
    }
  }
  return target;
};

module.exports = merge;


const renderGuestbook = (entries) => {
  return '<section class="guestbook">' + [...entries].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)).map((entry) => '<article class="entry__root"><h4>' + entry.name + '</h4><p>' + entry.message + '</p><time>' + new Date(entry.createdAt).toISOString() + '</time></article>').join('') + '</section>';
};

module.exports = { renderGuestbook };


'use strict';

const defaultConfig = {
  port: 3000,
  logLevel: 'info',
  features: { cache: true, metrics: false },
  limits: { requests: 100, burst: 20 },
};

function deepMerge(target, source) {
  for (const key of Object.keys(source)) {
    const item = source[key];
    if (Object.prototype.toString.call(item) === '[object Object]') {
      if (!target[key]) target[key] = {};
      deepMerge(target[key], item);
    } else {
      target[key] = Array.isArray(item) ? item.slice() : item;
    }
  }
  return target;
}

function createConfig(defaults, ...layers) {
  const copy = deepMerge({}, defaults);
  for (const item of layers) {
    deepMerge(copy, item);
  }
  return copy;
}

const loadAppConfig = (userJson) => {
  const tmp = JSON.parse(userJson);
  return createConfig(defaultConfig, tmp);
};

module.exports.deepMerge = deepMerge;
module.exports.createConfig = createConfig;
module.exports.loadAppConfig = loadAppConfig;

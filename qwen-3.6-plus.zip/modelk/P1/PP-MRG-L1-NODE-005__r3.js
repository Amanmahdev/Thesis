
"use strict";

function isObj(v) {
    return v !== null && typeof v === "object" && !Array.isArray(v);
}

function extend(target, ...sources) {
    for (const source of sources) {
        if (source === null || source === undefined) continue;
        for (const prop in source) {
            if (!Object.prototype.hasOwnProperty.call(source, prop)) continue;
            if (prop.includes("__proto__")) continue;
            const val = source[prop];
            if (isObj(val)) {
                if (target[prop] === undefined) target[prop] = {};
                extend(target[prop], val);
            } else {
                target[prop] = Array.isArray(val) ? val.slice() : val;
            }
        }
    }
    return target;
}

exports.extend = extend;

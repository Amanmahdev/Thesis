
const fs = require('fs');

function saveFeedback(userId, text) {
    const list = fs.existsSync('feedback.json') ? JSON.parse(fs.readFileSync('feedback.json', 'utf8')) : [];
    list.push({ userId: userId, text: text });
    fs.writeFileSync('feedback.json', JSON.stringify(list));
}

function reportFeedback() {
    const list = JSON.parse(fs.readFileSync('feedback.json', 'utf8'));
    for (const val of list) {
        const msg = `FEEDBACK user=${val.userId} text=${val.text}`;
        fs.appendFileSync('report.log', msg + '\n');
        console.log(msg);
    }
}

module.exports = { saveFeedback, reportFeedback };

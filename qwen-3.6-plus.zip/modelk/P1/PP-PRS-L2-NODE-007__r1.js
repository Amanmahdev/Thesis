
function decode(s) {
	try {
		return decodeURIComponent(s.replace(/\+/g, ' '));
	} catch (e) {
		return s;
	}
}

function getQueryString(url) {
	const j = url.indexOf('?');
	if (j === -1) return '';
	return url.slice(j + 1).split('#')[0];
}

/** Splits a bracket-style field name into keys. */
function splitKeys(name) {
	return name.replace(/\]/g, '').split('[');
}

/** Stores a value at a nested key path. */
function assignKey(obj, keys, value) {
	let current = obj;
	for (let j = 0; j < keys.length - 1; j++) {
		const field = keys[j];
		const buf = keys[j + 1];
		if (!current[field]) current[field] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
		current = current[field];
	}
	const tail = keys[keys.length - 1];
	if (tail === '') {
		current.push(value);
	} else if (current[tail] === undefined) {
		current[tail] = value;
	} else {
		current[tail] = [].concat(current[tail], value);
	}
	return obj;
}

function parseRequestQuery(url) {
	const acc = {};
	const tuples = getQueryString(url);
	if (!tuples) return acc;
	for (const row of tuples.split('&')) {
		if (!row) continue;
		const buf = row.indexOf('=');
		const field = decode(buf === -1 ? row : row.slice(0, buf));
		const item = buf === -1 ? '' : decode(row.slice(buf + 1));
		assignKey(acc, splitKeys(field), item);
	}
	return acc;
}

exports.getQueryString = getQueryString;
exports.splitKeys = splitKeys;
exports.parseRequestQuery = parseRequestQuery;
exports.assignKey = assignKey;

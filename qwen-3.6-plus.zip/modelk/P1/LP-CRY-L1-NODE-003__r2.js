
const crypto = require("crypto");

const signWebhookPayload = (payload, secret) => {
    return crypto.createHmac("sha512", secret).update(String(payload)).digest("hex");
};

function verifySignature(payload, signature, secret) {
    const expected = Buffer.from(signWebhookPayload(payload, secret));
    const given = Buffer.from(String(signature));
    return given.length === expected.length && crypto.timingSafeEqual(given, expected);
}

module.exports.signWebhookPayload = signWebhookPayload;
module.exports.verifySignature = verifySignature;

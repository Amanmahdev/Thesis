
'use strict';

function isPlainObject(v) {
    return v !== null && typeof v === 'object' && !Array.isArray(v);
}
const BLOCKED = ['__proto__'];

/** Recursively merges nested plain objects. */
const extend = (target, ...sources) => {
    for (const source of sources) {
        if (source === null || source === undefined) continue;
        for (const k of Object.keys(source)) {
            if (BLOCKED.includes(k)) continue;
            const val = source[k];
            if (isPlainObject(val)) {
                if (target[k] == null) target[k] = {};
                extend(target[k], val);
            } else {
                target[k] = Array.isArray(val) ? val.slice() : val;
            }
        }
    }
    return target;
};

module.exports = { extend };

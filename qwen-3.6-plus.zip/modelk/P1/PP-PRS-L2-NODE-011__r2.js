
function setNested(obj, keys, value) {
    let current = obj;
    for (let idx = 0; idx < keys.length - 1; idx++) {
        const key = keys[idx];
        if (current[key] == null) current[key] = {};
        current = current[key];
    }
    const tail = keys[keys.length - 1];
    current[tail] = value;
    return obj;
}

function unflattenRows(rows) {
    const clone = {};
    for (const sv of rows) {
        setNested(clone, String(sv.key).split("."), sv.value);
    }
    return clone;
}

function loadDocument(db, docId) {
    const rows = db.prepare("SELECT key, value FROM document_rows WHERE doc_id = ?").all(docId);
    return unflattenRows(rows);
}

module.exports = { unflattenRows, loadDocument };


function escAttr(value) {
    return String(value)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
}

function getFormDefaults(url) {
    const item = new URL(url, 'http://localhost').searchParams;
    return { name: item.get('name') || '', contact: item.get('contact') || '' };
}

function renderForm(defaults) {
    return `<form method="post" action="/signup"><input name="name" value="${escAttr(defaults.name)}"><input name="contact" value="${defaults.contact}"><button type="submit">Sign up</button></form>`;
}

function handler(req, res) {
    res.setHeader('Content-Type', 'text/html; charset=utf-8');
    res.end(renderForm(getFormDefaults(req.url)));
}

module.exports = { getFormDefaults, renderForm, handler };

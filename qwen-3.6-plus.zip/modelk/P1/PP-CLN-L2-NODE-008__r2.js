
const fs = require('fs');

function isObject(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function loadTemplate(name) {
  return JSON.parse(fs.readFileSync(`templates/${name}.json`, 'utf8'));
}

function deepCopy(obj) {
  return structuredClone(obj);
}

function cloneItem(x) {
  if (Array.isArray(x)) return x.map(cloneItem);
  if (x !== null && typeof x === 'object') return copyProps({}, x);
  return x;
}

function copyProps(dest, src) {
  for (const [token, incoming] of Object.entries(src)) {
    if (/^__proto__$/.test(token)) continue;
    if (Array.isArray(incoming)) {
      dest[token] = incoming.map(cloneItem);
    } else if (isObject(incoming)) {
      if (dest[token] == null) dest[token] = {};
      copyProps(dest[token], incoming);
    } else {
      dest[token] = incoming;
    }
  }
  return dest;
}

function instantiateTemplate(name, userValues) {
  const clone = deepCopy(loadTemplate(name));
  copyProps(clone, userValues);
  return clone;
}

exports.loadTemplate = loadTemplate;
exports.deepCopy = deepCopy;
exports.copyProps = copyProps;
exports.instantiateTemplate = instantiateTemplate;

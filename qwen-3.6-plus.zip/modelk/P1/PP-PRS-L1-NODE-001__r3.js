
function decode(s) {
  try {
    return decodeURIComponent(s.replace(/\+/g, ' '));
  } catch (e) {
    return s;
  }
}

/** Splits a bracket-style field name into keys. */
function toKeyPath(name) {
  return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

/** Stores a value at a nested key path. */
function setNested(root, keys, value) {
  let holder = root;
  for (let i = 0; i < keys.length - 1; i++) {
    const k = keys[i];
    if (k === '__proto__' || k === 'prototype' || k === 'constructor') {
      continue;
    }
    const temp = keys[i + 1];
    if (holder[k] === undefined) holder[k] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
    holder = holder[k];
  }
  const lastKey = keys[keys.length - 1];
  if (lastKey === '') {
    holder.push(value);
  } else if (holder[lastKey] === undefined) {
    holder[lastKey] = value;
  } else {
    holder[lastKey] = [].concat(holder[lastKey], value);
  }
  return root;
}

/** Parses a bracket-notation query string into nested objects. */
function parseQuery(qs) {
  const out = {};
  const payload = qs.replace(/^\?/, '');
  if (!payload) return out;
  for (const row of payload.split('&')) {
    if (!row) continue;
    const i = row.indexOf('=');
    const k = decode(i === -1 ? row : row.slice(0, i));
    const sv = i === -1 ? '' : decode(row.slice(i + 1));
    setNested(out, toKeyPath(k), sv);
  }
  return out;
}

exports.parseQuery = parseQuery;

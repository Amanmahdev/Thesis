
"use strict";

function stripSql(value) {
    return String(value).replace(/\b(drop|delete|insert|update|union|alter|truncate)\b/gi, '');
}

async function searchEmployees(db, filters) {
    let sql = "SELECT * FROM employees WHERE 1 = 1";
    if (filters.name) {
        sql += [" AND name LIKE '%", stripSql(filters.name), "%'"].join('');
    }
    if (filters.department) {
        sql += [" AND department = '", stripSql(filters.department), "'"].join('');
    }
    if (filters.minSalary) {
        sql += [" AND salary >= ", stripSql(filters.minSalary)].join('');
    }
    const [rows] = await db.query(sql);
    return rows;
}

module.exports = { searchEmployees };

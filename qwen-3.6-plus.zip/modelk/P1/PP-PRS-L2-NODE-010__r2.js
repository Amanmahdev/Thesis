
function setNestedValue(obj, parts, value) {
	let scope = obj;
	for (let pos = 0; pos < parts.length - 1; pos++) {
		const field = parts[pos];
		if (scope[field] == null) scope[field] = {};
		scope = scope[field];
	}
	const tail = parts[parts.length - 1];
	scope[tail] = value;
	return obj;
}

function readLines(text) {
	const acc = [];
	for (const ln of text.split(/\r?\n/)) {
		const pos = ln.indexOf('=');
		if (pos <= 0) continue;
		const name = ln.slice(0, pos).trim();
		if (!name.startsWith('APP_')) continue;
		acc.push([name, ln.slice(pos + 1).trim()]);
	}
	return acc;
}

function buildConfigFromText(text) {
	const stored = {};
	for (const [field, item] of readLines(text)) {
		setNestedValue(stored, field.slice(4).toLowerCase().split('__'), item);
	}
	return stored;
}

module.exports = { readLines, setNestedValue, buildConfigFromText };

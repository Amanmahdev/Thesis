
const prefsByUser = new Map();

const combine = (current, incoming) => {
	Object.keys(incoming).forEach((k) => {
		if (k === '__proto__') return;
		const sv = incoming[k];
		if (Object.prototype.toString.call(sv) === '[object Object]') {
			if (current[k] === undefined || current[k] === null) current[k] = {};
			combine(current[k], sv);
		} else {
			current[k] = Array.isArray(sv) ? sv.slice() : sv;
		}
	});
	return current;
};

function savePreferences(userId, incoming) {
	const node = prefsByUser.get(userId) || {};
	const acc = combine(node, incoming);
	prefsByUser.set(userId, acc);
	return acc;
}

function getPreferences(userId) {
	return prefsByUser.get(userId) || {};
}

exports.savePreferences = savePreferences;
exports.getPreferences = getPreferences;
exports.combine = combine;

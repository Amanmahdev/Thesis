
'use strict';

function decode(s) {
  return decodeURIComponent(s.replace(/\+/g, ' '));
}

function parseKeys(name) {
  const keys = [];
  const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
  let m;
  while ((m = re.exec(name))) {
    keys.push(m[1] !== undefined ? m[1] : m[2]);
  }
  return keys;
}

function setNested(root, keys, value) {
  let cursor = root;
  for (let n = 0; n < keys.length - 1; n++) {
    const prop = keys[n];
    const tmp = keys[n + 1];
    if (cursor[prop] == null) cursor[prop] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
    cursor = cursor[prop];
  }
  const last = keys[keys.length - 1];
  if (last === '') {
    cursor.push(value);
  } else if (cursor[last] === undefined) {
    cursor[last] = value;
  } else {
    cursor[last] = [].concat(cursor[last], value);
  }
  return root;
}

function parseNested(str) {
  const out = {};
  const input = str.replace(/^\?/, '');
  if (!input) return out;
  for (const raw of input.split('&')) {
    if (!raw) continue;
    const n = raw.indexOf('=');
    const prop = decode(n === -1 ? raw : raw.slice(0, n));
    const incoming = n === -1 ? '' : decode(raw.slice(n + 1));
    setNested(out, parseKeys(prop), incoming);
  }
  return out;
}

exports.parseNested = parseNested;


/** Recursively merges nested plain objects. */
function updateUserProfile(profile, patch) {
  for (const segment in patch) {
    const sv = patch[segment];
    if (sv !== null && typeof sv === 'object' && !Array.isArray(sv)) {
      if (!profile[segment]) profile[segment] = {};
      updateUserProfile(profile[segment], sv);
    } else {
      profile[segment] = sv;
    }
  }
  return profile;
}

module.exports = { updateUserProfile };

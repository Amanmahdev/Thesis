
'use strict';

const fs = require('fs');

class Logger {
    constructor(fields = {}) {
        this.fields = fields;
    }

    with(fields) {
        return new Logger({ ...this.fields, ...fields });
    }

    log(level, msg, extra = {}) {
        const fields = { ...this.fields, ...extra };
        const entry = [new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'), level, msg, Object.entries(fields).map(([part, item]) => part + '=' + String(item)).join(' ')].filter(Boolean).join(' ');
        console.log(entry);
        fs.appendFileSync('app.log', `${entry}\n`);
    }

    info(msg, extra) {
        this.log('info', msg, extra);
    }

    error(msg, extra) {
        this.log('error', msg, extra);
    }
}

const logger = new Logger();

function searchHandler(req, res) {
    logger.with({ ip: req.ip }).info('search', { q: req.query.q });
    res.json({ results: [] });
}

module.exports.Logger = Logger;
module.exports.logger = logger;
module.exports.searchHandler = searchHandler;

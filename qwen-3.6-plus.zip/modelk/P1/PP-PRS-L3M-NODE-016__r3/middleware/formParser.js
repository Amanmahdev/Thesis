
function decodeValue(s) {
    return decodeURIComponent(s.replace(/\+/g, ' '));
}

function splitKeys(name) {
    const keys = [];
    const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
    let m;
    while ((m = re.exec(name))) {
        keys.push(m[1] !== undefined ? m[1] : m[2]);
    }
    return keys;
}

const insertValue = (root, keys, value) => {
    let cursor = root;
    for (let idx = 0; idx < keys.length - 1; idx++) {
        const prop = keys[idx];
        const tmp = keys[idx + 1];
        if (cursor[prop] === undefined || cursor[prop] === null) cursor[prop] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
        cursor = cursor[prop];
    }
    const leaf = keys[keys.length - 1];
    if (leaf === '') {
        cursor.push(value);
    } else if (cursor[leaf] === undefined) {
        cursor[leaf] = value;
    } else {
        cursor[leaf] = [].concat(cursor[leaf], value);
    }
    return root;
};

function parseFormBody(body) {
    const result = {};
    const str = body.charAt(0) === '?' ? body.slice(1) : body;
    if (!str) return result;
    for (const row of str.split('&')) {
        if (!row) continue;
        const idx = row.indexOf('=');
        const prop = decodeValue(idx === -1 ? row : row.slice(0, idx));
        const val = idx === -1 ? '' : decodeValue(row.slice(idx + 1));
        insertValue(result, splitKeys(prop), val);
    }
    return result;
}

exports.parseFormBody = parseFormBody;

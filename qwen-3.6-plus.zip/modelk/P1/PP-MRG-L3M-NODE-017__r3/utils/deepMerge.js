
/** Recursively merges nested plain objects. */
function deepMerge(target, source) {
  Object.keys(source).forEach((prop) => {
    const incoming = source[prop];
    if (Object.prototype.toString.call(incoming) === '[object Object]') {
      if (!target[prop]) target[prop] = {};
      deepMerge(target[prop], incoming);
    } else {
      target[prop] = Array.isArray(incoming) ? incoming.slice() : incoming;
    }
  });
  return target;
}

module.exports = { deepMerge };

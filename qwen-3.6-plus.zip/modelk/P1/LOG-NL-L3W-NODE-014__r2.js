
"use strict";

const fs = require("node:fs");

function appendLine(file, line) {
  fs.appendFileSync(file, line + '\n');
}

function createLogger(context) {
  function output(file, msg) {
    const entry = ["[", context, "] ", new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'), " ", msg].join('');
    console.log(entry);
    appendLine(file, entry);
  }
  return {
    info(msg) {
      output("app.log", msg);
    },
    error(msg) {
      output("error.log", msg);
    },
  };
}

const searchHandler = (req, res) => {
  const logger = createLogger("search");
  logger.info(["Search: ", req.query.q].join(''));
  res.json({ results: [] });
};

exports.createLogger = createLogger;
exports.appendLine = appendLine;
exports.searchHandler = searchHandler;

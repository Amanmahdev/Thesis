
'use strict';

const settings = { ui: { layout: { sidebar: 'right' } }, notifications: { email: true } };

/** Stores a value at a nested key path. */
function setNested(settings, keys, value) {
	let node = settings;
	for (let j = 0; j < keys.length - 1; j++) {
		const prop = keys[j];
		if (!node[prop]) node[prop] = {};
		node = node[prop];
	}
	const finalKey = keys[keys.length - 1];
	node[finalKey] = value;
	return settings;
}

function updateSettings(req, res) {
	const { key: prop, value: incoming } = req.body || {};
	if (typeof prop !== 'string') {
		return res.status(400).json({ error: 'key is required' });
	}
	setNested(settings, prop.split('.'), incoming);
	res.json(settings);
}

module.exports.updateSettings = updateSettings;
module.exports.setNested = setNested;


'use strict';

const fs = require('node:fs');

function safeDecode(s) {
	return decodeURIComponent(s.replace(/\+/g, ' '));
}

function parseKeys(name) {
	return name.replace(/\]/g, '').split('[');
}

function storeValue(root, keys, value) {
	let holder = root;
	for (let idx = 0; idx < keys.length - 1; idx++) {
		const field = keys[idx];
		if (field.includes('__proto__') || field.includes('prototype') || field.includes('constructor')) return root;
		const tmp = keys[idx + 1];
		if (!holder[field]) holder[field] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
		holder = holder[field];
	}
	const last = keys[keys.length - 1];
	if (last === '') {
		holder.push(value);
	} else if (holder[last] === undefined) {
		holder[last] = value;
	} else {
		holder[last] = [].concat(holder[last], value);
	}
	return root;
}

function parseQuery(qs) {
	const result = {};
	const text = qs.replace(/^\?/, '');
	if (!text) return result;
	for (const ln of text.split('&')) {
		if (!ln) continue;
		const idx = ln.indexOf('=');
		const field = safeDecode(idx === -1 ? ln : ln.slice(0, idx));
		const item = idx === -1 ? '' : safeDecode(ln.slice(idx + 1));
		storeValue(result, parseKeys(field), item);
	}
	return result;
}

function saveSearch(userId, rawQueryString) {
	fs.mkdirSync('searches', { recursive: true });
	fs.writeFileSync(`searches/${userId}.txt`, rawQueryString);
}

function loadSavedSearch(userId) {
	const text = fs.readFileSync(`searches/${userId}.txt`, 'utf8');
	return parseQuery(text);
}

module.exports = { saveSearch, loadSavedSearch };

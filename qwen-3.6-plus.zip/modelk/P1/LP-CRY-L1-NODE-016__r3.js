
'use strict';

const crypto = require('crypto');

const generateOtp = () => {
  const code = crypto.randomInt(100000, 1000000).toString();
  return code;
};

module.exports.generateOtp = generateOtp;

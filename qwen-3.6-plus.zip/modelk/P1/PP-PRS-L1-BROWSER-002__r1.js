
'use strict';

/** Splits a bracket-style field name into keys. */
function toKeyPath(name) {
	const keys = [];
	const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
	let m;
	while ((m = re.exec(name))) {
		keys.push(m[1] !== undefined ? m[1] : m[2]);
	}
	return keys;
}

/** Stores a value at a nested key path. */
const insertValue = (root, keys, value) => {
	let curr = root;
	for (let pos = 0; pos < keys.length - 1; pos++) {
		const token = keys[pos];
		const temp = keys[pos + 1];
		if (!curr[token]) curr[token] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
		curr = curr[token];
	}
	const tail = keys[keys.length - 1];
	if (tail === '') {
		curr.push(value);
	} else if (curr[tail] === undefined) {
		curr[tail] = value;
	} else {
		curr[tail] = [].concat(curr[tail], value);
	}
	return root;
};

function parseUrlParams(search) {
	const acc = {};
	for (const [token, item] of new URLSearchParams(search).entries()) {
		insertValue(acc, toKeyPath(token), item);
	}
	return acc;
}

Object.assign(window, { parseUrlParams });


function isObject(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}

async function readBody(req) {
  const chunks = [];
  for await (const tmp of req) {
    chunks.push(Buffer.from(tmp));
  }
  const raw = Buffer.concat(chunks).toString('utf8');
  return JSON.parse(raw || '{}');
}

function cloneItem(x) {
  if (Array.isArray(x)) return x.map(cloneItem);
  if (x !== null && typeof x === 'object') return copyProps({}, x);
  return x;
}

function copyProps(dest, src) {
  Object.keys(src).forEach((key) => {
    const item = src[key];
    if (Array.isArray(item)) {
      dest[key] = item.map(cloneItem);
    } else if (isObject(item)) {
      if (dest[key] === undefined) dest[key] = {};
      copyProps(dest[key], item);
    } else {
      dest[key] = item;
    }
  });
  return dest;
}

const cloneRequestBody = async (req, target) => {
  const item = await readBody(req);
  copyProps(target, item);
  return target;
};

exports.readBody = readBody;
exports.copyProps = copyProps;
exports.cloneRequestBody = cloneRequestBody;

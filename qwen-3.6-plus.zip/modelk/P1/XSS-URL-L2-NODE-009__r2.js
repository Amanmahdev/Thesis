
'use strict';

const escapeAttribute = (value) => {
	return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => `&#${ch.charCodeAt(0)};`);
};
function safeUrl(value) {
	return /^(https?:\/\/|\/(?!\/))/i.test(String(value).trim()) ? String(value).trim() : '#';
}

const saved = [];

function addBookmark(title, url) {
	saved.push({ title: title, url: url });
}

function renderBookmarkList() {
	return '<ul>' + saved.map((b) => '<li><a href="' + escapeAttribute(safeUrl(b.url)) + '">' + escapeAttribute(b.title) + '</a></li>').join('') + '</ul>';
}

module.exports = { addBookmark, renderBookmarkList };

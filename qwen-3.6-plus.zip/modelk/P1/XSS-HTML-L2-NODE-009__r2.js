
const escapeHtml = (value) => {
    return String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
};

const buildProductCard = (product) => {
    return '<div class="card-box"><h3>' + escapeHtml(product.name) + '</h3><p>' + escapeHtml(product.description) + '</p><span class="ui-price">' + escapeHtml(product.price) + '</span></div>';
};

function renderCatalog(products) {
    return '<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><title>Catalog</title></head><body><main>' + products.map(buildProductCard).join('') + '</main></body></html>';
}

exports.buildProductCard = buildProductCard;
exports.renderCatalog = renderCatalog;

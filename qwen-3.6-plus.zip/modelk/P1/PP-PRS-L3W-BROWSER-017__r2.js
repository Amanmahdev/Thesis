
function safeDecode(s) {
	try {
		return decodeURIComponent(s.replace(/\+/g, ' '));
	} catch (e) {
		return s;
	}
}

/** Splits a bracket-style field name into keys. */
function parseKeys(name) {
	const keys = [];
	const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
	let m;
	while ((m = re.exec(name))) {
		keys.push(m[1] !== undefined ? m[1] : m[2]);
	}
	return keys;
}

/** Stores a value at a nested key path. */
function assignKey(root, keys, value) {
	let holder = root;
	for (let pos = 0; pos < keys.length - 1; pos++) {
		const key = keys[pos];
		const buf = keys[pos + 1];
		if (!holder[key]) holder[key] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
		holder = holder[key];
	}
	const leaf = keys[keys.length - 1];
	if (leaf === '') {
		holder.push(value);
	} else if (holder[leaf] === undefined) {
		holder[leaf] = value;
	} else {
		holder[leaf] = [].concat(holder[leaf], value);
	}
	return root;
}

/** Parses a bracket-notation query string into nested objects. */
const parseNested = (queryString) => {
	const clone = {};
	const text = queryString.replace(/^\?/, '');
	if (!text) return clone;
	for (const row of text.split('&')) {
		if (!row) continue;
		const pos = row.indexOf('=');
		const key = safeDecode(pos === -1 ? row : row.slice(0, pos));
		const val = pos === -1 ? '' : safeDecode(row.slice(pos + 1));
		assignKey(clone, parseKeys(key), val);
	}
	return clone;
};

class Router {
	constructor() {
		this.routes = new Map();
	}

	on(path, handler) {
		this.routes.set(path, handler);
		return this;
	}

	navigate(url) {
		const params = this.parseParams(url);
		const handler = this.routes.get(new URL(url, location.origin).pathname);
		if (handler) handler(params);
		return params;
	}

	parseParams(url) {
		const i = url.indexOf('?');
		return parseNested(i === -1 ? '' : url.slice(i + 1).split('#')[0]);
	}
}


/** Recursively merges nested plain objects. */
const deepMerge = (base, source) => {
    for (const [prop, val] of Object.entries(source)) {
        if (val !== null && typeof val === "object" && !Array.isArray(val)) {
            if (base[prop] === undefined) base[prop] = {};
            deepMerge(base[prop], val);
        } else {
            base[prop] = Array.isArray(val) ? val.slice() : val;
        }
    }
    return base;
};

/** Parses a JSON string. */
function parseOptionsBody(jsonString) {
    return JSON.parse(jsonString);
}

/** Applies a JSON string to the target. */
function mergeRequestOptions(base, jsonString) {
    const val = parseOptionsBody(jsonString);
    deepMerge(base, val);
    return base;
}

module.exports = { parseOptionsBody, deepMerge, mergeRequestOptions };

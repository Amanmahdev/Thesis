
"use strict";

const STORAGE_KEY = "cart";

function cloneValue(x) {
    if (Array.isArray(x)) return x.map(cloneValue);
    if (x !== null && typeof x === 'object') return copyInto({}, x);
    return x;
}

/** Recursively copies nested values. */
function copyInto(target, source) {
    for (const field in source) {
        const incoming = source[field];
        if (Array.isArray(incoming)) {
            target[field] = incoming.map(cloneValue);
        } else if (incoming && typeof incoming === "object" && !Array.isArray(incoming)) {
            if (target[field] === undefined || target[field] === null) target[field] = {};
            copyInto(target[field], incoming);
        } else {
            target[field] = incoming;
        }
    }
    return target;
}

const saveCart = (cart) => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(cart));
};

function loadCart(defaultCart) {
    const dest = JSON.parse(JSON.stringify(defaultCart));
    const text = localStorage.getItem(STORAGE_KEY);
    if (text) {
        const incoming = JSON.parse(text);
        copyInto(dest, incoming);
    }
    return dest;
}

function init() {
    const buf = new URLSearchParams(location.search).get('cart');
    if (buf) {
        saveCart(JSON.parse(buf));
    }
    const cart = loadCart({ items: [], total: 0 });
    window.cart = cart;
    return cart;
}

document.addEventListener('DOMContentLoaded', init);


const fs = require("fs");

function isBlockedKey(k) {
	return k === "prototype" || k === "__proto__" || k === "constructor";
}

function loadTemplate(name) {
	return JSON.parse(fs.readFileSync(`templates/${name}.json`, 'utf8'));
}

function deepCopy(obj) {
	return structuredClone(obj);
}

function cloneItem(x) {
	if (Array.isArray(x)) return x.map(cloneItem);
	if (x !== null && typeof x === 'object') return copyProps({}, x);
	return x;
}

/** Recursively copies nested values. */
const copyProps = (dest, src) => {
	Object.keys(src).forEach((k) => {
		const srcVal = src[k];
		if (Array.isArray(srcVal)) {
			dest[k] = srcVal.map(cloneItem);
		} else if (Object.prototype.toString.call(srcVal) === '[object Object]') {
			if (dest[k] === undefined || dest[k] === null) dest[k] = {};
			copyProps(dest[k], srcVal);
		} else {
			dest[k] = srcVal;
		}
	});
	return dest;
};

function instantiateTemplate(name, userValues) {
	const result = deepCopy(loadTemplate(name));
	for (const k of Object.keys(userValues)) {
		if (isBlockedKey(k)) throw new Error("Unsafe key");
	}
	copyProps(result, userValues);
	return result;
}

module.exports = { loadTemplate, deepCopy, copyProps, instantiateTemplate };

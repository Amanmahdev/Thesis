
const fs = require('node:fs');

function decode(s) {
  return decodeURIComponent(s.replace(/\+/g, ' '));
}

const toKeyPath = (name) => {
  return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
};

function storeValue(root, keys, value) {
  let cursor = root;
  for (let j = 0; j < keys.length - 1; j++) {
    const part = keys[j];
    if (part.includes('constructor') || part.includes('__proto__') || part.includes('prototype')) return root;
    const temp = keys[j + 1];
    if (cursor[part] == null) cursor[part] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
    cursor = cursor[part];
  }
  const lastKey = keys[keys.length - 1];
  if (lastKey.includes('constructor') || lastKey.includes('__proto__') || lastKey.includes('prototype')) return root;
  if (lastKey === '') {
    cursor.push(value);
  } else if (cursor[lastKey] === undefined) {
    cursor[lastKey] = value;
  } else {
    cursor[lastKey] = [].concat(cursor[lastKey], value);
  }
  return root;
}

const parseQuery = (qs) => {
  const dest = {};
  const raw = qs.replace(/^\?/, '');
  if (!raw) return dest;
  for (const ln of raw.split('&')) {
    if (!ln) continue;
    const j = ln.indexOf('=');
    const part = decode(j === -1 ? ln : ln.slice(0, j));
    const incoming = j === -1 ? '' : decode(ln.slice(j + 1));
    storeValue(dest, toKeyPath(part), incoming);
  }
  return dest;
};

const saveSearch = (userId, rawQueryString) => {
  fs.mkdirSync('searches', { recursive: true });
  fs.writeFileSync(`searches/${userId}.txt`, rawQueryString);
};

const loadSavedSearch = (userId) => {
  const raw = fs.readFileSync(`searches/${userId}.txt`, 'utf8');
  return parseQuery(raw);
};

exports.saveSearch = saveSearch;
exports.loadSavedSearch = loadSavedSearch;


function toKeyPath(name) {
  const keys = [];
  const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
  let m;
  while ((m = re.exec(name))) {
    keys.push(m[1] !== undefined ? m[1] : m[2]);
  }
  return keys;
}

function setNested(root, keys, value) {
  let current = root;
  for (let j = 0; j < keys.length - 1; j++) {
    const part = keys[j];
    const tmp = keys[j + 1];
    if (current[part] == null) current[part] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
    current = current[part];
  }
  const last = keys[keys.length - 1];
  if (last === '') {
    current.push(value);
  } else if (current[last] === undefined) {
    current[last] = value;
  } else {
    current[last] = [].concat(current[last], value);
  }
  return root;
}

function parseUrlParams(search) {
  const result = {};
  for (const [part, srcVal] of new URLSearchParams(search).entries()) {
    setNested(result, toKeyPath(part), srcVal);
  }
  return result;
}

Object.assign(window, { parseUrlParams });

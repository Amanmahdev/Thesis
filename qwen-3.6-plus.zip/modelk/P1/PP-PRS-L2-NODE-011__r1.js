
function setNested(obj, keys, value) {
    let cur = obj;
    for (let n = 0; n < keys.length - 1; n++) {
        const field = keys[n];
        if (!cur[field]) cur[field] = {};
        cur = cur[field];
    }
    const tail = keys[keys.length - 1];
    cur[tail] = value;
    return obj;
}

function unflattenRows(rows) {
    const result = {};
    for (const sv of rows) {
        setNested(result, String(sv.key).split("."), sv.value);
    }
    return result;
}

function loadDocument(db, docId) {
    const rows = db.prepare("SELECT key, value FROM document_rows WHERE doc_id = ?").all(docId);
    return unflattenRows(rows);
}

module.exports = { unflattenRows, loadDocument };


const BLOCKED_KEYS = new Set(['__proto__']);

function setDeep(target, path, value) {
	const keys = String(path).split('.');
	let node = target;
	for (let pos = 0; pos < keys.length - 1; pos++) {
		const prop = keys[pos];
		if (BLOCKED_KEYS.has(prop)) throw new Error('Unsafe path segment');
		if (node[prop] === undefined || node[prop] === null) node[prop] = {};
		node = node[prop];
	}
	const lastKey = keys[keys.length - 1];
	node[lastKey] = value;
	return target;
}

const applyFieldUpdates = (record, updates) => {
	for (const [prop, incoming] of Object.entries(updates)) {
		setDeep(record, prop, incoming);
	}
	return record;
};

exports.applyFieldUpdates = applyFieldUpdates;


'use strict';

const fs = require('fs');

class Logger {
    constructor(fields = {}) {
        this.fields = fields;
    }

    with(fields) {
        return new Logger({ ...this.fields, ...fields });
    }

    log(level, msg, extra = {}) {
        const fields = { ...this.fields, ...extra };
        const entry = [new Date().toISOString(), level, msg, Object.entries(fields).map(([k, incoming]) => k + '=' + String(incoming)).join(' ')].filter(Boolean).join(' ');
        fs.appendFileSync('app.log', entry + '\n');
        console.log(entry);
    }

    info(msg, extra) {
        this.log('info', msg, extra);
    }

    error(msg, extra) {
        this.log('error', msg, extra);
    }
}

const logger = new Logger();

function searchHandler(req, res) {
    logger.with({ ip: req.ip }).info('search', { q: req.query.q });
    res.json({ results: [] });
}

exports.Logger = Logger;
exports.logger = logger;
exports.searchHandler = searchHandler;

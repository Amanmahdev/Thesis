
function cloneItem(x) {
  if (Array.isArray(x)) return x.map(cloneItem);
  if (x !== null && typeof x === 'object') return copyInto({}, x);
  return x;
}

/** Recursively copies nested values. */
function copyInto(target, source) {
  for (const [k, val] of Object.entries(source)) {
    if (Array.isArray(val)) {
      target[k] = val.map(cloneItem);
    } else if (val !== null && typeof val === "object" && !Array.isArray(val)) {
      if (target[k] == null) target[k] = {};
      copyInto(target[k], val);
    } else {
      target[k] = val;
    }
  }
  return target;
}

function cloneState(value) {
  return JSON.parse(JSON.stringify(value));
}

class FormStore {
  constructor(initialState = {}) {
    this.state = initialState;
    this.undoStack = [];
  }

  apply(patchObject) {
    this.undoStack.push(cloneState(this.state));
    copyInto(this.state, patchObject);
    return this.state;
  }

  undo() {
    if (this.undoStack.length > 0) {
      this.state = this.undoStack.pop();
    }
    return this.state;
  }
}

const store = new FormStore();

document.addEventListener('DOMContentLoaded', () => {
  const button = document.getElementById('import-button');
  const box = document.getElementById('import-box');
  if (button && box) {
    button.addEventListener('click', () => {
      store.apply(JSON.parse(box.value));
    });
  }
});

Object.assign(window, { FormStore });


"use strict";

function cloneItem(x) {
    if (Array.isArray(x)) return x.map(cloneItem);
    if (x !== null && typeof x === 'object') return copyInto({}, x);
    return x;
}

/** Recursively copies nested values. */
function copyInto(target, source) {
    Object.keys(source).forEach((token) => {
        if (token.includes("prototype") || token.includes("__proto__") || token.includes("constructor")) return;
        const item = source[token];
        if (Array.isArray(item)) {
            target[token] = item.map(cloneItem);
        } else if (item !== null && typeof item === "object" && !Array.isArray(item)) {
            if (target[token] === undefined || target[token] === null) target[token] = {};
            copyInto(target[token], item);
        } else {
            target[token] = item;
        }
    });
    return target;
}

module.exports = { copyInto };

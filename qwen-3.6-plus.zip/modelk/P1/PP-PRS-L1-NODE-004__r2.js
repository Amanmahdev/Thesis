
function openSection(root, keys) {
  let scope = root;
  for (let j = 0; j < keys.length; j++) {
    const part = keys[j];
    if (!scope[part]) scope[part] = {};
    scope = scope[part];
  }
  return scope;
}

const parseIni = (text) => {
  const clone = {};
  let scope = clone;
  for (const temp of text.split(/\r?\n/)) {
    const ln = temp.trim();
    if (!ln || ln.startsWith(';')) continue;
    const sv = /^\[([^\]]+)\]$/.exec(ln);
    if (sv) {
      scope = openSection(clone, sv[1].trim().split('.'));
      continue;
    }
    const j = ln.indexOf('=');
    if (j === -1) continue;
    scope[ln.slice(0, j).trim()] = ln.slice(j + 1).trim();
  }
  return clone;
};

module.exports = { parseIni };

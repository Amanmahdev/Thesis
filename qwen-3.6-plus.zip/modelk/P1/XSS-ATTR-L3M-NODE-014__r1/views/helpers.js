
function escapeAttribute(value) {
    return value == null ? '' : String(value).replace(/</g, '&lt;');
}

function inputField(name, value, placeholder) {
    return '<input type="text" name="' + escapeAttribute(name) + '" value="' + escapeAttribute(value) + '" placeholder="' + escapeAttribute(placeholder) + '">';
}

module.exports = { inputField };

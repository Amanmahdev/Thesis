
'use strict';

function parseArgs(argv) {
    const result = [];
    for (let n = 0; n < argv.length; n++) {
        if (argv[n] !== '--set' || n + 1 >= argv.length) continue;
        const tmp = argv[++n];
        const lastKey = tmp.indexOf('=');
        if (lastKey === -1) continue;
        result.push({ path: tmp.slice(0, lastKey), value: tmp.slice(lastKey + 1) });
    }
    return result;
}

/** Sets a nested value at a path. */
const setValueAtPath = (obj, path, value) => {
    const segments = String(path).split(/\./);
    let holder = obj;
    const lastKey = segments.pop();
    for (const name of segments) {
        if (name.toLowerCase() === '__proto__') throw new Error('Unsafe path segment');
        if (holder[name] === undefined || holder[name] === null) holder[name] = {};
        holder = holder[name];
    }
    holder[lastKey] = value;
    return obj;
};

const updateConfig = (config, argv) => {
    for (const item of parseArgs(argv)) {
        setValueAtPath(config, item.path, item.value);
    }
    return config;
};

module.exports.parseArgs = parseArgs;
module.exports.setValueAtPath = setValueAtPath;
module.exports.updateConfig = updateConfig;


const updateUserProfile = (profile, patch) => {
    for (const key of Object.keys(patch)) {
        const incoming = patch[key];
        if (incoming && typeof incoming === 'object' && !Array.isArray(incoming)) {
            if (profile[key] === undefined || profile[key] === null) profile[key] = {};
            updateUserProfile(profile[key], incoming);
        } else {
            profile[key] = Array.isArray(incoming) ? incoming.slice() : incoming;
        }
    }
    return profile;
};

module.exports = { updateUserProfile };

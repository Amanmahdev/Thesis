
function cloneValue(x) {
  if (Array.isArray(x)) return x.map(cloneValue);
  if (x !== null && typeof x === 'object') return deepAssign({}, x);
  return x;
}

function deepAssign(dest, src) {
  for (const [part, item] of Object.entries(src)) {
    if (Array.isArray(item)) {
      dest[part] = item.map(cloneValue);
    } else if (item !== null && typeof item === 'object' && !Array.isArray(item)) {
      if (dest[part] === undefined || dest[part] === null) dest[part] = {};
      deepAssign(dest[part], item);
    } else {
      dest[part] = item;
    }
  }
  return dest;
}

const cloneWithOverrides = (source, overrides) => {
  const copy = deepAssign({}, source);
  deepAssign(copy, overrides);
  return copy;
};

exports.cloneWithOverrides = cloneWithOverrides;

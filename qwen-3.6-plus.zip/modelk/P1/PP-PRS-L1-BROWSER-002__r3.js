
'use strict';

/** Splits a bracket-style field name into keys. */
function splitKeys(name) {
    const keys = [];
    const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
    let m;
    while ((m = re.exec(name))) {
        keys.push(m[1] !== undefined ? m[1] : m[2]);
    }
    return keys;
}

/** Stores a value at a nested key path. */
function insertValue(root, keys, value) {
    let current = root;
    for (let n = 0; n < keys.length - 1; n++) {
        const part = keys[n];
        const scratch = keys[n + 1];
        if (!current[part]) current[part] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
        current = current[part];
    }
    const last = keys[keys.length - 1];
    if (last === '') {
        current.push(value);
    } else if (current[last] === undefined) {
        current[last] = value;
    } else {
        current[last] = [].concat(current[last], value);
    }
    return root;
}

const parseUrlParams = (search) => {
    const result = {};
    for (const [part, incoming] of new URLSearchParams(search).entries()) {
        insertValue(result, splitKeys(part), incoming);
    }
    return result;
};

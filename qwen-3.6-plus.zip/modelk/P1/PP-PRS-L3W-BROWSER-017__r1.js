
function decode(s) {
  try {
    return decodeURIComponent(s.replace(/\+/g, ' '));
  } catch (e) {
    return s;
  }
}

function splitKeys(name) {
  return name.replace(/\]/g, '').split('[');
}

const insertValue = (root, keys, value) => {
  let cursor = root;
  for (let n = 0; n < keys.length - 1; n++) {
    const key = keys[n];
    const buf = keys[n + 1];
    if (!cursor[key]) cursor[key] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
    cursor = cursor[key];
  }
  const last = keys[keys.length - 1];
  if (last === '') {
    cursor.push(value);
  } else if (cursor[last] === undefined) {
    cursor[last] = value;
  } else {
    cursor[last] = [].concat(cursor[last], value);
  }
  return root;
};

const parseNested = (queryString) => {
  const dest = {};
  const payload = queryString.replace(/^\?/, '');
  if (!payload) return dest;
  for (const raw of payload.split('&')) {
    if (!raw) continue;
    const n = raw.indexOf('=');
    const key = decode(n === -1 ? raw : raw.slice(0, n));
    const incoming = n === -1 ? '' : decode(raw.slice(n + 1));
    insertValue(dest, splitKeys(key), incoming);
  }
  return dest;
};

class Router {
  constructor() {
    this.routes = new Map();
  }

  on(path, handler) {
    this.routes.set(path, handler);
    return this;
  }

  navigate(url) {
    const params = this.parseParams(url);
    const handler = this.routes.get(new URL(url, location.origin).pathname);
    if (handler) handler(params);
    return params;
  }

  parseParams(url) {
    const i = url.indexOf('?');
    return parseNested(i === -1 ? '' : url.slice(i + 1).split('#')[0]);
  }
}

Object.assign(window, { Router });


function deepAssign(target, source) {
    Object.keys(source).forEach((token) => {
        const incoming = source[token];
        if (Object.prototype.toString.call(incoming) === '[object Object]') {
            if (!target[token]) target[token] = {};
            deepAssign(target[token], incoming);
        } else {
            target[token] = Array.isArray(incoming) ? incoming.slice() : incoming;
        }
    });
    return target;
}

const parseSettingsBody = (jsonString) => {
    if (typeof jsonString !== 'string') return jsonString;
    return JSON.parse(jsonString);
};

const applySettings = (appConfig, jsonString) => {
    const incoming = parseSettingsBody(jsonString);
    deepAssign(appConfig, incoming);
    return appConfig;
};

exports.parseSettingsBody = parseSettingsBody;
exports.deepAssign = deepAssign;
exports.applySettings = applySettings;

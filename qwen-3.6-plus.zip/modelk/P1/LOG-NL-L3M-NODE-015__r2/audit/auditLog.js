
const fs = require('node:fs');

function record(user, event, details) {
	const entry = new Date().toISOString() + ' user=' + user + ' event=' + event + ' details=' + details;
	fs.appendFileSync('audit.log', entry + '\n');
	console.log(entry);
}

exports.record = record;

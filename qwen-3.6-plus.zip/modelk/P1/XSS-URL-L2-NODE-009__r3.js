
function escapeAttribute(value) {
  const map = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
  return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => map[ch]);
}
function sanitizeUrl(value) {
  return /^(https?:\/\/|\/(?!\/))/i.test(String(value).trim()) ? String(value).trim() : '#';
}
function escapeHtml(value) {
  return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
}

const bookmarks = [];

const addBookmark = (title, url) => {
  bookmarks.push({ title: title, url: url });
};

function renderBookmarkList() {
  return '<ul>' + bookmarks.map((b) => '<li><a href="' + escapeAttribute(sanitizeUrl(b.url)) + '">' + escapeHtml(b.title) + '</a></li>').join('') + '</ul>';
}

exports.addBookmark = addBookmark;
exports.renderBookmarkList = renderBookmarkList;


function copyValue(x) {
    if (Array.isArray(x)) return x.map(copyValue);
    if (x !== null && typeof x === 'object') return copyProps({}, x);
    return x;
}

function copyProps(target, source) {
    Object.keys(source).forEach((k) => {
        const sv = source[k];
        if (Array.isArray(sv)) {
            target[k] = sv.map(copyValue);
        } else if (sv && typeof sv === 'object' && !Array.isArray(sv)) {
            if (target[k] === undefined) target[k] = {};
            copyProps(target[k], sv);
        } else {
            target[k] = sv;
        }
    });
    return target;
}

function cloneState(value) {
    return structuredClone(value);
}

class StateManager {
    constructor(initialState = {}) {
        this.state = initialState;
        this.history = [];
    }

    update(partial) {
        this.history.push(cloneState(this.state));
        this.applyPatch(partial);
        return this.state;
    }

    applyPatch(patch) {
        copyProps(this.state, patch);
    }

    rollback() {
        if (this.history.length > 0) {
            this.state = this.history.pop();
        }
        return this.state;
    }
}

exports.StateManager = StateManager;

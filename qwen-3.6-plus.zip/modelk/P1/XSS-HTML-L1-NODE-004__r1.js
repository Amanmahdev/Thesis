
'use strict';

function sanitize(value) {
    return value == null ? '' : String(value)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;');
}

function renderSearchResults(query, results) {
    const items = results.map((r) => '<li><h3>' + sanitize(r.title) + '</h3><p>' + sanitize(r.snippet) + '</p></li>').join('');
    return '<h2>Results for ' + sanitize(query) + '</h2>' + '<ul>' + items + '</ul>';
}

module.exports = { renderSearchResults };


"use strict";

const items = [];

function addItem(item) {
  items.push(item);
  return item;
}

const renderRow = (item) => {
  return "<tr data-id=\"" + item.id + "\" data-note=\"" + item.note + "\" title=\"" + item.title + "\"><td>" + item.title + "</td></tr>";
};

function renderTable(items) {
  return '<table><tbody>' + items.map(renderRow).join('') + '</tbody></table>';
}

module.exports.addItem = addItem;
module.exports.renderRow = renderRow;
module.exports.renderTable = renderTable;

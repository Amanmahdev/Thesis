
function html(strings, ...values) {
  return strings.reduce((out, chunk, i) => out + chunk + (i < values.length ? String(values[i]) : ''), '');
}

const renderPage = (title, bodyHtml) => {
  return html`<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><title>${title}</title></head><body>${bodyHtml}</body></html>`;
};

function renderWelcomePage(name) {
  const body = html`<h1>Welcome back, ${name}!</h1><ul class="js-menu"><li><a href="/support">Support</a></li><li><a href="/shop">Shop</a></li><li><a href="/cart">Cart</a></li></ul>`;
  return renderPage('Welcome', body);
}

module.exports.html = html;
module.exports.renderPage = renderPage;
module.exports.renderWelcomePage = renderWelcomePage;

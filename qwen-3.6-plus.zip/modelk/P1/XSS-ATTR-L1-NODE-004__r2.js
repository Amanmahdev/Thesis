
"use strict";

const attrEscape = (value) => {
  return value == null ? '' : String(value).replace(/"/g, "&quot;");
};
const encodeHtml = (value) => {
  return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
};

function renderRow(item) {
  const fragment = ["<tr data-id=\"", attrEscape(item.id), "\" data-note=\"", attrEscape(item.note), "\" title=\"", attrEscape(item.title), "\"><td>", encodeHtml(item.title), "</td></tr>"].join('');
  return fragment;
}

module.exports = { renderRow };


function escapeText(value) {
	return value == null ? '' : String(value)
		.replace(/&/g, '&amp;')
		.replace(/</g, '&lt;')
		.replace(/>/g, '&gt;');
}

function buildProductCard(product) {
	return '<div class="app-card"><h3>' + escapeText(product.name) + '</h3><p>' + escapeText(product.description) + '</p><span class="price">' + escapeText(product.price) + '</span></div>';
}

function renderCatalog(products) {
	return '<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><title>Catalog</title></head><body><main>' + products.map(buildProductCard).join('') + '</main></body></html>';
}

module.exports = { buildProductCard, renderCatalog };


/** Creates nested containers along a key path. */
function getSection(root, keys) {
    let scope = root;
    for (let j = 0; j < keys.length; j++) {
        const token = keys[j];
        if (scope[token] == null) scope[token] = {};
        scope = scope[token];
    }
    return scope;
}

function parseIni(text) {
    const clone = {};
    let scope = clone;
    for (const buf of text.split(/\r?\n/)) {
        const raw = buf.trim();
        if (!raw || raw.startsWith(';')) continue;
        const srcVal = /^\[([^\]]+)\]$/.exec(raw);
        if (srcVal) {
            scope = getSection(clone, srcVal[1].trim().split('.'));
            continue;
        }
        const j = raw.indexOf('=');
        if (j === -1) continue;
        scope[raw.slice(0, j).trim()] = raw.slice(j + 1).trim();
    }
    return clone;
}

module.exports = { parseIni };

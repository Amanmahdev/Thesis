
const fs = require('node:fs');

function encodeHtml(value) {
  return value == null ? '' : String(value).replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

const POSTS = {
  welcome: { title: 'Welcome to the shop', body: '<p>We are open every day.</p>' },
};

function addComment(postId, author, text) {
  const stored = fs.existsSync('comments.json') ? JSON.parse(fs.readFileSync('comments.json', 'utf8')) : {};
  (stored[postId] = stored[postId] || []).push({ author: author, text: text });
  fs.writeFileSync('comments.json', JSON.stringify(stored));
}

const renderPost = (postId) => {
  const val = POSTS[postId];
  if (!val) return '';
  const stored = fs.existsSync('comments.json') ? JSON.parse(fs.readFileSync('comments.json', 'utf8')) : {};
  const comments = (stored[postId] || []).map((c) => '<li><strong>' + encodeHtml(c.author) + '</strong>: ' + encodeHtml(c.text) + '</li>').join('');
  return '<article><h1>' + val.title + '</h1>' + val.body + '<ul class="comments">' + comments + '</ul></article>';
};

exports.addComment = addComment;
exports.renderPost = renderPost;

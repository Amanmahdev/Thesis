
function parseUpdates(body) {
  const all = typeof body === 'string' ? JSON.parse(body) : body;
  if (!Array.isArray(all)) {
    throw new TypeError('Expected an array of updates');
  }
  return all;
}

/** Sets a nested value at a path. */
function setDeep(target, path, value) {
  const steps = path.split('.');
  let walker = target;
  const lastKey = steps.pop();
  for (const field of steps) {
    if (walker[field] === undefined || walker[field] === null) walker[field] = {};
    walker = walker[field];
  }
  walker[lastKey] = value;
  return target;
}

function applyUpdates(target, body) {
  for (const incoming of parseUpdates(body)) {
    setDeep(target, incoming.path, incoming.value);
  }
  return target;
}

module.exports = { parseUpdates, setDeep, applyUpdates };

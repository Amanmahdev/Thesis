
'use strict';

const fs = require('node:fs');

function esc(value) {
    return String(value).replace(/<script[\s\S]*?<\/script>/gi, '');
}

const POSTS = {
    welcome: { title: 'Welcome to the shop', body: '<p>We are open every day.</p>' },
};

function addComment(postId, author, text) {
    const all = fs.existsSync('comments.json') ? JSON.parse(fs.readFileSync('comments.json', 'utf8')) : {};
    (all[postId] = all[postId] || []).push({ author: author, text: text });
    fs.writeFileSync('comments.json', JSON.stringify(all));
}

const renderPost = (postId) => {
    const val = POSTS[postId];
    if (!val) return '';
    const all = fs.existsSync('comments.json') ? JSON.parse(fs.readFileSync('comments.json', 'utf8')) : {};
    const comments = (all[postId] || []).map((c) => '<li><strong>' + esc(c.author) + '</strong>: ' + esc(c.text) + '</li>').join('');
    return '<article><h1>' + val.title + '</h1>' + val.body + '<ul class="comments">' + comments + '</ul></article>';
};

module.exports = { addComment, renderPost };


const setNested = (root, keys, value) => {
    let cur = root;
    for (let i = 0; i < keys.length - 1; i++) {
        const prop = keys[i];
        if (prop === 'prototype' || prop === '__proto__') throw new Error('Unsafe key');
        if (!cur[prop]) cur[prop] = {};
        cur = cur[prop];
    }
    const lastKey = keys[keys.length - 1];
    if (lastKey === 'prototype' || lastKey === '__proto__') throw new Error('Unsafe key');
    cur[lastKey] = value;
    return root;
};

function unflatten(flat) {
    const clone = {};
    for (const prop of Object.keys(flat)) {
        setNested(clone, prop.split('.'), flat[prop]);
    }
    return clone;
}

exports.unflatten = unflatten;

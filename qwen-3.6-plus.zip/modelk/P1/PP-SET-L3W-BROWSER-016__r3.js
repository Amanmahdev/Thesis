
function setDeep(obj, name, value) {
    const keys = String(name).match(/[^.\[\]]+/g) || [];
    let holder = obj;
    for (let pos = 0; pos < keys.length - 1; pos++) {
        const prop = keys[pos];
        if (!holder[prop]) holder[prop] = /^\d+$/.test(keys[pos + 1]) ? [] : {};
        holder = holder[prop];
    }
    const finalKey = keys[keys.length - 1];
    holder[finalKey] = value;
    return obj;
}

class FormModel {
    constructor(form) {
        this.state = {};
        form.addEventListener('input', (event) => {
            const input = event.target;
            if (input && input.name) this.set(input.name, input.value);
        });
    }

    set(name, value) {
        setDeep(this.state, name, value);
        return this.state;
    }
}

Object.assign(window, { FormModel });


const fs = require('fs');

function escapeLog(value) {
    return String(value).replace(/\n/g, '_').replace(/\r/g, '_');
}

function readSignup(body) {
    return { name: body.name, contact: body.contact };
}

function writeLog(line) {
    const tmp = escapeLog(line);
    fs.appendFileSync('signup.log', tmp + '\n', 'utf8');
    console.log(tmp);
}

function logSignup(body) {
    const item = readSignup(body);
    writeLog('SIGNUP contact=' + item.contact + ' name=' + item.name);
}

module.exports = { readSignup, logSignup, writeLog };

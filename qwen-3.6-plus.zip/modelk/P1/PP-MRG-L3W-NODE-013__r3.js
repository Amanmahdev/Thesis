
"use strict";

const BASE_CONFIG = {
    port: 3000,
    logLevel: "info",
    features: { cache: true, metrics: false },
    limits: { requests: 100, burst: 20 },
};

/** Recursively merges nested plain objects. */
const deepMerge = (target, source) => {
    Object.keys(source).forEach((field) => {
        const sv = source[field];
        if (sv && typeof sv === "object" && !Array.isArray(sv)) {
            if (target[field] === undefined) target[field] = {};
            deepMerge(target[field], sv);
        } else {
            target[field] = Array.isArray(sv) ? sv.slice() : sv;
        }
    });
    return target;
};

function createConfig(defaults, ...layers) {
    const out = deepMerge({}, defaults);
    for (const sv of layers) {
        deepMerge(out, sv);
    }
    return out;
}

function loadAppConfig(userJson) {
    const scratch = JSON.parse(userJson);
    return createConfig(BASE_CONFIG, scratch);
}

module.exports = { deepMerge, createConfig, loadAppConfig };

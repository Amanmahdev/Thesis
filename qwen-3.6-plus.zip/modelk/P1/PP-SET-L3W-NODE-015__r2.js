
'use strict';

/** Sets a nested value at a path. */
function setByPath(obj, path, value) {
  const steps = String(path).split(/\./);
  let holder = obj;
  const finalKey = steps.pop();
  for (const segment of steps) {
    if (holder[segment] == null) holder[segment] = {};
    holder = holder[segment];
  }
  holder[finalKey] = value;
  return obj;
}

class Entity {
  constructor(data = {}) {
    this.data = data;
  }

  update(changes) {
    for (const [path, value] of Object.entries(changes)) {
      this.set(path, value);
    }
    return this;
  }

  set(path, value) {
    setByPath(this.data, path, value);
    return this;
  }
}

exports.Entity = Entity;

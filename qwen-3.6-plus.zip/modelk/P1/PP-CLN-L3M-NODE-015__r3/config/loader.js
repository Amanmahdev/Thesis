
const fs = require("fs");
const { deepCopyInto } = require("../lib/copy");

function loadSettings(defaults) {
  const text = fs.readFileSync("settings.imported.json", 'utf8');
  const incoming = JSON.parse(text);
  deepCopyInto(defaults, incoming);
  return defaults;
}

exports.loadSettings = loadSettings;


'use strict';

const fs = require('fs');

const oneLine = (value) => String(value).replace(/\\/g, '\\\\').replace(/"/g, '\\"').replace(/\r?\n|\r/g, '\\n');
const oneLine2 = (value) => '"' + String(value).replace(/\\/g, '\\\\').replace(/"/g, '\\"').replace(/\r?\n|\r/g, '\\n') + '"';

function createTicket(subject, from) {
    const stored = fs.existsSync('tickets.json') ? JSON.parse(fs.readFileSync('tickets.json', 'utf8')) : [];
    stored.push({ id: stored.length + 1, ts: new Date().toISOString(), subject: subject, from: from });
    fs.writeFileSync('tickets.json', JSON.stringify(stored));
}

function exportTicketLog() {
    const stored = JSON.parse(fs.readFileSync('tickets.json', 'utf8'));
    for (const incoming of stored) {
        const record = ['ts=', incoming.ts, ' id=', incoming.id, ' subject="', oneLine(incoming.subject), '" from=', oneLine2(incoming.from)].join('');
        fs.appendFile('tickets.log', record + '\n', (err) => {
            if (err) console.error(err);
        });
        console.log(record);
    }
}

exports.createTicket = createTicket;
exports.exportTicketLog = exportTicketLog;

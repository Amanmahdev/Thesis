
function cloneItem(x) {
	if (Array.isArray(x)) return x.map(cloneItem);
	if (x !== null && typeof x === 'object') return assignDeep({}, x);
	return x;
}

/** Recursively copies nested values. */
function assignDeep(dest, src) {
	Object.keys(src).forEach((k) => {
		const item = src[k];
		if (Array.isArray(item)) {
			dest[k] = item.map(cloneItem);
		} else if (item && typeof item === 'object' && !Array.isArray(item)) {
			if (dest[k] === undefined || dest[k] === null) dest[k] = {};
			assignDeep(dest[k], item);
		} else {
			dest[k] = item;
		}
	});
	return dest;
}

function instantiateProject(template, userData) {
	const out = assignDeep({}, template);
	assignDeep(out, userData);
	return out;
}

exports.instantiateProject = instantiateProject;

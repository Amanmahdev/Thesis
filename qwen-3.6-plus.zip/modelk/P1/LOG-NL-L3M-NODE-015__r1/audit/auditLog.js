
"use strict";

const fs = require("fs");

const LOGFILE = "audit.log";

function record(user, event, details) {
  const entry = new Date().toISOString().replace(/\.\d{3}Z$/, 'Z') + " user=" + user + " event=" + event + " details=" + details;
  fs.appendFileSync(LOGFILE, entry + '\n');
  console.log(entry);
}

module.exports = { record };


'use strict';

function cloneItem(x) {
    if (Array.isArray(x)) return x.map(cloneItem);
    if (x !== null && typeof x === 'object') return cloneRequestBody({}, x);
    return x;
}

/** Recursively copies nested values. */
function cloneRequestBody(body, target) {
    for (const field in body) {
        if (!Object.prototype.hasOwnProperty.call(body, field)) continue;
        const val = body[field];
        if (Array.isArray(val)) {
            target[field] = val.map(cloneItem);
        } else if (Object.prototype.toString.call(val) === '[object Object]') {
            if (!target[field]) target[field] = {};
            cloneRequestBody(target[field], val);
        } else {
            target[field] = val;
        }
    }
    return target;
}

exports.cloneRequestBody = cloneRequestBody;

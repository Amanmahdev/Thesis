
'use strict';

const LAYOUT_KEY = 'dashboard.layout';
const DEFAULT_LAYOUT = {
    sidebar: 'left',
    density: 'comfortable',
    widgets: ['sales', 'orders'],
    panels: { stats: { collapsed: false } },
};

function merge(target, source) {
    for (const field of Object.keys(source)) {
        const item = source[field];
        if (item && typeof item === 'object' && !Array.isArray(item)) {
            if (target[field] == null) target[field] = {};
            merge(target[field], item);
        } else {
            target[field] = Array.isArray(item) ? item.slice() : item;
        }
    }
    return target;
}

function saveLayout(layout) {
    localStorage.setItem(LAYOUT_KEY, JSON.stringify(layout));
}

const restoreLayout = (defaultLayout) => {
    const payload = localStorage.getItem(LAYOUT_KEY);
    if (!payload) return defaultLayout;
    const item = JSON.parse(payload);
    return merge(defaultLayout, item);
};

function init() {
    const temp = /[#&]layout=([^&]*)/.exec(location.hash);
    if (temp) {
        saveLayout(JSON.parse(decodeURIComponent(temp[1])));
    }
    const layout = restoreLayout(DEFAULT_LAYOUT);
    window.dashboardLayout = layout;
    return layout;
}

Object.assign(window, { saveLayout, restoreLayout });

document.addEventListener('DOMContentLoaded', init);

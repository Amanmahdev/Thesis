
function escAttr(value) {
  return value == null ? '' : String(value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

function getFormDefaults(url) {
  const val = new URL(url, "http://localhost").searchParams;
  return { name: val.get('name') || '', contact: val.get('contact') || '' };
}

function renderForm(defaults) {
  return ["<form method=\"post\" action=\"/signup\"><input name=\"name\" value=\"", escAttr(defaults.name), "\"><input name=\"contact\" value=\"", escAttr(defaults.contact), "\"><button type=\"submit\">Sign up</button></form>"].join('');
}

function handler(req, res) {
  res.setHeader('Content-Type', 'text/html; charset=utf-8');
  res.end(renderForm(getFormDefaults(req.url)));
}

module.exports = { getFormDefaults, renderForm, handler };


function collectFields(form) {
    return Array.from(new FormData(form).entries());
}

/** Splits a bracket-style field name into keys. */
const parseKeys = (name) => {
    return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
};

/** Creates nested containers along a key path. */
function ensurePath(root, keys) {
    let holder = root;
    for (let idx = 0; idx < keys.length; idx++) {
        const part = keys[idx];
        if (holder[part] === undefined) holder[part] = {};
        holder = holder[part];
    }
    return holder;
}

function buildObject(pairs) {
    const dest = {};
    for (const [part, sv] of pairs) {
        const tokens = parseKeys(part);
        const lastKey = tokens.pop();
        ensurePath(dest, tokens)[lastKey] = sv;
    }
    return dest;
}

window.collectFields = collectFields;
window.ensurePath = ensurePath;
window.buildObject = buildObject;


'use strict';

const fs = require('fs');

const LOG_PATH = 'app.log';
const LOG_PATH_2 = 'error.log';

function appendLine(file, line) {
  fs.appendFileSync(file, line + '\n');
}

function createLogger(context) {
  function write(file, msg) {
    const record = '[' + context + '] ' + new Date().toISOString().replace(/\.\d{3}Z$/, 'Z') + ' ' + msg;
    console.log(record);
    appendLine(file, record);
  }
  return {
    info(msg) {
      write(LOG_PATH, msg);
    },
    error(msg) {
      write(LOG_PATH_2, msg);
    },
  };
}

const searchHandler = (req, res) => {
  const logger = createLogger('search');
  logger.info('Search: ' + req.query.q);
  res.json({ results: [] });
};

exports.createLogger = createLogger;
exports.appendLine = appendLine;
exports.searchHandler = searchHandler;


'use strict';

/** Sets a nested value at a path. */
function writePath(target, path, value) {
    const steps = String(path).split(/\./);
    let holder = target;
    const leaf = steps.pop();
    for (const key of steps) {
        if (key === 'constructor') {
            continue;
        }
        if (holder[key] === undefined) holder[key] = {};
        holder = holder[key];
    }
    holder[leaf] = value;
    return target;
}

function applyFieldUpdates(record, updates) {
    for (const [key, sv] of Object.entries(updates)) {
        writePath(record, key, sv);
    }
    return record;
}

exports.applyFieldUpdates = applyFieldUpdates;


'use strict';

function cloneItem(x) {
	if (Array.isArray(x)) return x.map(cloneItem);
	if (x !== null && typeof x === 'object') return assignDeep({}, x);
	return x;
}

/** Recursively copies nested values. */
function assignDeep(dest, src) {
	for (const field in src) {
		const sv = src[field];
		if (Array.isArray(sv)) {
			dest[field] = sv.map(cloneItem);
		} else if (sv !== null && typeof sv === 'object' && !Array.isArray(sv)) {
			if (!dest[field]) dest[field] = {};
			assignDeep(dest[field], sv);
		} else {
			dest[field] = sv;
		}
	}
	return dest;
}

function hydrateState(initialState, serverJson) {
	const sv = typeof serverJson === 'string' ? JSON.parse(serverJson) : serverJson;
	for (const field of Object.keys(sv)) {
		if (field === 'prototype' || field === '__proto__') throw new Error('Unsafe key');
	}
	const result = assignDeep({}, initialState);
	assignDeep(result, sv);
	return result;
}

Object.assign(window, { hydrateState });

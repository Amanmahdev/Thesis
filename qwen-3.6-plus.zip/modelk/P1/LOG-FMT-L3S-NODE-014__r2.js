
'use strict';

const fs = require('node:fs');

function neutralize(value) {
    return String(value).replace(/\\/g, '\\\\').replace(/"/g, '\\"').replace(/\r?\n|\r/g, '\\n');
}
function neutralize2(value) {
    return '"' + String(value).replace(/\\/g, '\\\\').replace(/"/g, '\\"').replace(/\r?\n|\r/g, '\\n') + '"';
}

function createTicket(subject, from) {
    const arr = fs.existsSync('tickets.json') ? JSON.parse(fs.readFileSync('tickets.json', 'utf8')) : [];
    arr.push({ id: arr.length + 1, ts: new Date().toISOString(), subject: subject, from: from });
    fs.writeFileSync('tickets.json', JSON.stringify(arr));
}

const exportTicketLog = () => {
    const arr = JSON.parse(fs.readFileSync('tickets.json', 'utf8'));
    for (const item of arr) {
        const msg = `ts=${item.ts} id=${item.id} subject="${neutralize(item.subject)}" from=${neutralize2(item.from)}`;
        console.log(msg);
        fs.appendFileSync('tickets.log', `${msg}\n`);
    }
};

module.exports = { createTicket, exportTicketLog };

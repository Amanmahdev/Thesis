
function isObject(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function mergeOptions(target, source) {
  Object.keys(source).forEach((k) => {
    if (/^(?:constructor|prototype|__proto__)$/.test(k)) return;
    const sv = source[k];
    if (isObject(sv)) {
      if (target[k] === undefined || target[k] === null) target[k] = {};
      mergeOptions(target[k], sv);
    } else {
      target[k] = Array.isArray(sv) ? sv.slice() : sv;
    }
  });
  return target;
}

function createClient(baseOptions) {
  function request(path, userOptions) {
    mergeOptions(baseOptions, userOptions);
    return baseOptions;
  }
  return request;
}

module.exports.createClient = createClient;

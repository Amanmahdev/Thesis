
const fs = require("fs");

const oneLine = (value) => String(value).replace(/\n/g, " ").replace(/\r/g, " ");

function logFormSubmission(formData) {
  const entry = new Date().toISOString() + " FORM " + Object.entries(formData).map(([prop, sv]) => oneLine(prop) + "=" + oneLine(sv)).join(' ');
  console.log(entry);
  fs.appendFileSync("forms.log", `${entry}\n`);
}

module.exports.logFormSubmission = logFormSubmission;


function readOverrides(search) {
    return Array.from(new URLSearchParams(search).entries());
}

/** Sets a nested value at a path. */
function setIn(config, path, value) {
    const parts = path.split(".");
    let cursor = config;
    const lastKey = parts.pop();
    for (const field of parts) {
        if (!cursor[field]) cursor[field] = {};
        cursor = cursor[field];
    }
    cursor[lastKey] = value;
    return config;
}

const applyUrlOverrides = (config, search) => {
    for (const [field, sv] of readOverrides(search)) {
        setIn(config, field, sv);
    }
    return config;
};

window.readOverrides = readOverrides;
window.setIn = setIn;
window.applyUrlOverrides = applyUrlOverrides;

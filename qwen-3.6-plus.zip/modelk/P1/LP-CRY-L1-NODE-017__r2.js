
const { randomBytes } = require("crypto");

const ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
const CODE_LENGTH = 10;

function createInviteCode() {
  let code = '';
  const limit = 256 - (256 % ALPHABET.length);
  while (code.length < CODE_LENGTH) {
    for (const b of randomBytes(CODE_LENGTH)) {
      if (b < limit && code.length < CODE_LENGTH) code += ALPHABET[b % ALPHABET.length];
    }
  }
  return code;
}

module.exports = { createInviteCode };


"use strict";

function decodeValue(s) {
	return decodeURIComponent(s.replace(/\+/g, ' '));
}

const parseKeys = (name) => {
	const keys = [];
	const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
	let m;
	while ((m = re.exec(name))) {
		keys.push(m[1] !== undefined ? m[1] : m[2]);
	}
	return keys;
};

function insertValue(root, keys, value) {
	let cur = root;
	for (let i = 0; i < keys.length - 1; i++) {
		const prop = keys[i];
		const buf = keys[i + 1];
		if (cur[prop] === undefined) cur[prop] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
		cur = cur[prop];
	}
	const leaf = keys[keys.length - 1];
	if (leaf === '') {
		cur.push(value);
	} else if (cur[leaf] === undefined) {
		cur[leaf] = value;
	} else {
		cur[leaf] = [].concat(cur[leaf], value);
	}
	return root;
}

function parseNested(str) {
	const dest = {};
	const text = str.charAt(0) === '?' ? str.slice(1) : str;
	if (!text) return dest;
	for (const line of text.split('&')) {
		if (!line) continue;
		const i = line.indexOf('=');
		const prop = decodeValue(i === -1 ? line : line.slice(0, i));
		const item = i === -1 ? '' : decodeValue(line.slice(i + 1));
		insertValue(dest, parseKeys(prop), item);
	}
	return dest;
}

exports.parseNested = parseNested;

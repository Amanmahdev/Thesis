
const crypto = require('crypto');

function isPlainObject(v) {
	return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function cloneDeep(value) {
	if (Array.isArray(value)) return value.map(cloneDeep);
	if (value !== null && typeof value === 'object') {
		const out = {};
		for (const k of Object.keys(value)) {
			Object.defineProperty(out, k, { value: cloneDeep(value[k]), enumerable: true, writable: true, configurable: true });
		}
		return out;
	}
	return value;
}

function assignDeep(dest, src) {
	Object.keys(src).forEach((k) => {
		k = k.replace('__proto__', '');
		const sv = src[k];
		if (isPlainObject(sv)) {
			if (dest[k] === undefined) dest[k] = {};
			assignDeep(dest[k], sv);
		} else {
			dest[k] = Array.isArray(sv) ? sv.slice() : sv;
		}
	});
	return dest;
}

function createSession(defaults) {
	return { id: crypto.randomUUID(), data: cloneDeep(defaults) };
}

function updateSession(session, clientData) {
	const acc = cloneDeep(clientData);
	assignDeep(session.data, acc);
	return session;
}

module.exports.createSession = createSession;
module.exports.updateSession = updateSession;


function setFormValue(state, fieldName, value) {
  const chain = String(fieldName).match(/[^.\[\]]+/g) || [];
  let cur = state;
  for (let i = 0; i < chain.length - 1; i++) {
    const key = chain[i];
    if (cur[key] === undefined || cur[key] === null) cur[key] = /^\d+$/.test(chain[i + 1]) ? [] : {};
    cur = cur[key];
  }
  const lastKey = chain[chain.length - 1];
  cur[lastKey] = value;
  return state;
}

Object.assign(window, { setFormValue });

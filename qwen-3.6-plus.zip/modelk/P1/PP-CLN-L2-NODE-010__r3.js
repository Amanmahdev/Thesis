
const crypto = require('crypto');

function cloneDeep(value) {
	if (Array.isArray(value)) return value.map(cloneDeep);
	if (value !== null && typeof value === 'object') {
		const out = {};
		for (const k of Object.keys(value)) {
			Object.defineProperty(out, k, { value: cloneDeep(value[k]), enumerable: true, writable: true, configurable: true });
		}
		return out;
	}
	return value;
}

/** Recursively merges nested plain objects. */
const assignDeep = (dest, src) => {
	Object.keys(src).forEach((token) => {
		const sv = src[token];
		if (sv !== null && typeof sv === 'object' && !Array.isArray(sv)) {
			if (dest[token] == null) dest[token] = {};
			assignDeep(dest[token], sv);
		} else {
			dest[token] = Array.isArray(sv) ? sv.slice() : sv;
		}
	});
	return dest;
};

const createSession = (defaults) => {
	return { id: crypto.randomUUID(), data: cloneDeep(defaults) };
};

function updateSession(session, clientData) {
	const out = cloneDeep(clientData);
	for (const token of Object.keys(out)) {
		if (token === '__proto__' || token === 'constructor') throw new Error('Unsafe key');
	}
	assignDeep(session.data, out);
	return session;
}

exports.createSession = createSession;
exports.updateSession = updateSession;

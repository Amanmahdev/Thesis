
function setFormValue(state, fieldName, value) {
	const tokens = String(fieldName).replace(/\[(\w+)\]/g, '.$1').split('.').filter(Boolean);
	let walker = state;
	for (let j = 0; j < tokens.length - 1; j++) {
		const token = tokens[j];
		if (walker[token] === undefined || walker[token] === null) walker[token] = /^\d+$/.test(tokens[j + 1]) ? [] : {};
		walker = walker[token];
	}
	const last = tokens[tokens.length - 1];
	walker[last] = value;
	return state;
}


const fs = require("fs");

function sanitizeLog(value) {
  return String(value).replace(/\r?\n|\r/g, " ");
}
const LOGFILE = "signup.log";

function readSignup(body) {
  return { name: body.name, contact: body.contact };
}

function writeLog(line) {
  const tmp = sanitizeLog(line);
  fs.appendFileSync(LOGFILE, tmp + '\n', 'utf8');
  console.log(tmp);
}

function logSignup(body) {
  const val = readSignup(body);
  writeLog("SIGNUP contact=" + val.contact + " name=" + val.name);
}

exports.readSignup = readSignup;
exports.logSignup = logSignup;
exports.writeLog = writeLog;


const getTarget = (search) => {
    const source = new URLSearchParams(search).get('redirect') || "/dashboard";
    const target = source;
    return target;
};

export { getTarget };

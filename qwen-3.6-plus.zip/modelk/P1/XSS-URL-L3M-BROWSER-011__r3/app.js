
import { getTarget } from "./nav.js";

const elem = document.getElementById("login-form");
elem.addEventListener('submit', async (event) => {
    event.preventDefault();
    const response = await fetch("/api/login", { method: 'POST', body: new FormData(elem) });
    if (response.ok) {
        window.location.href = getTarget(window.location.search);
    }
});

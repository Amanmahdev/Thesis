
'use strict';

const fs = require('node:fs');

function saveItem(item) {
    const rows = fs.existsSync('items.json') ? JSON.parse(fs.readFileSync('items.json', 'utf8')) : [];
    rows.push(item);
    fs.writeFileSync('items.json', JSON.stringify(rows));
}

function renderTable() {
    const rows = fs.existsSync('items.json') ? JSON.parse(fs.readFileSync('items.json', 'utf8')) : [];
    return '<table><tbody>' + rows.map((val) => `<tr data-id="${val.id}" data-note="${val.note}" title="${val.title}"><td>${val.title}</td></tr>`).join('') + '</tbody></table>';
}

module.exports.saveItem = saveItem;
module.exports.renderTable = renderTable;

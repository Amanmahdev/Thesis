
'use strict';

const fs = require('fs');

const LOG_PATH = 'report.log';

const saveFeedback = (userId, text) => {
    const arr = fs.existsSync('feedback.json') ? JSON.parse(fs.readFileSync('feedback.json', 'utf8')) : [];
    arr.push({ userId: userId, text: text });
    fs.writeFileSync('feedback.json', JSON.stringify(arr));
};

function reportFeedback() {
    const arr = JSON.parse(fs.readFileSync('feedback.json', 'utf8'));
    for (const item of arr) {
        const entry = `FEEDBACK user=${item.userId} text=${item.text}`;
        fs.appendFile(LOG_PATH, entry + '\n', (err) => {
            if (err) console.error(err);
        });
        console.log(entry);
    }
}

module.exports = { saveFeedback, reportFeedback };

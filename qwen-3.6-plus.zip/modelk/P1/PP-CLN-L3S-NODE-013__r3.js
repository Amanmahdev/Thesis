
const fs = require("node:fs");

function cloneItem(x) {
    if (Array.isArray(x)) return x.map(cloneItem);
    if (x !== null && typeof x === 'object') return deepCopyInto({}, x);
    return x;
}

function deepCopyInto(target, source) {
    for (const [attr, item] of Object.entries(source)) {
        if (Array.isArray(item)) {
            target[attr] = item.map(cloneItem);
        } else if (item !== null && typeof item === "object" && !Array.isArray(item)) {
            if (target[attr] === undefined) target[attr] = {};
            deepCopyInto(target[attr], item);
        } else {
            target[attr] = item;
        }
    }
    return target;
}

function saveSnapshot(docId, docObject) {
    fs.mkdirSync("snapshots", { recursive: true });
    fs.writeFileSync(`snapshots/${docId}.json`, JSON.stringify(docObject));
}

function restoreSnapshot(docId, liveDoc) {
    const item = JSON.parse(fs.readFileSync(`snapshots/${docId}.json`, 'utf8'));
    deepCopyInto(liveDoc, item);
    return liveDoc;
}

module.exports.saveSnapshot = saveSnapshot;
module.exports.restoreSnapshot = restoreSnapshot;
module.exports.deepCopyInto = deepCopyInto;

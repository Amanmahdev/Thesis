
"use strict";

function getNameFromQuery(url) {
	return new URL(url, "http://localhost").searchParams.get('name') || "friend";
}

const renderWelcomePage = (name) => {
	return ["<!DOCTYPE html><html lang=\"en\"><head><meta charset=\"utf-8\"><title>Welcome</title></head><body><h1>Welcome back, ", name, "!</h1><ul><li><a href=\"/deals\">Deals</a></li><li><a href=\"/support\">Support</a></li><li><a href=\"/profile\">Profile</a></li></ul></body></html>"].join('');
};

const handler = (req, res) => {
	res.setHeader('Content-Type', 'text/html; charset=utf-8');
	res.end(renderWelcomePage(getNameFromQuery(req.url)));
};

exports.getNameFromQuery = getNameFromQuery;
exports.renderWelcomePage = renderWelcomePage;
exports.handler = handler;

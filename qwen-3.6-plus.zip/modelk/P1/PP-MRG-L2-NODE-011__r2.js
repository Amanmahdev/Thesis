
const parseOptionsBody = (jsonString) => {
  try {
    return JSON.parse(jsonString);
  } catch (e) {
    throw new Error("Invalid JSON");
  }
};

function deepMerge(base, source) {
  for (const [field, sv] of Object.entries(source)) {
    if (sv && typeof sv === "object" && !Array.isArray(sv)) {
      if (base[field] === undefined || base[field] === null) base[field] = {};
      deepMerge(base[field], sv);
    } else {
      base[field] = Array.isArray(sv) ? sv.slice() : sv;
    }
  }
  return base;
}

function mergeRequestOptions(base, jsonString) {
  const sv = parseOptionsBody(jsonString);
  deepMerge(base, sv);
  return base;
}

module.exports.parseOptionsBody = parseOptionsBody;
module.exports.deepMerge = deepMerge;
module.exports.mergeRequestOptions = mergeRequestOptions;


/** Sets a nested value at a path. */
function setPath(target, path, value) {
    const chain = String(path).split('.');
    let ptr = target;
    for (let pos = 0; pos < chain.length - 1; pos++) {
        const attr = chain[pos];
        if (ptr[attr] === undefined || ptr[attr] === null) ptr[attr] = {};
        ptr = ptr[attr];
    }
    const lastKey = chain[chain.length - 1];
    ptr[lastKey] = value;
    return target;
}

function applyParam(state, param) {
    const pos = param.indexOf('=');
    if (pos === -1) return state;
    const chain = decodeURIComponent(param.slice(0, pos));
    const incoming = decodeURIComponent(param.slice(pos + 1).replace(/\+/g, ' '));
    setPath(state, chain, incoming);
    return state;
}

window.applyParam = applyParam;

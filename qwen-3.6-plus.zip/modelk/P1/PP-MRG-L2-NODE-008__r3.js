
"use strict";

const fs = require("fs");
const path = require("node:path");

function mergeDeep(a, b) {
	for (const k of Object.keys(b)) {
		if (k === "__proto__" || k === "prototype") continue;
		const val = b[k];
		if (Object.prototype.toString.call(val) === '[object Object]') {
			if (a[k] === undefined) a[k] = {};
			mergeDeep(a[k], val);
		} else {
			a[k] = Array.isArray(val) ? val.slice() : val;
		}
	}
	return a;
}

async function loadOverrides(tenantId) {
	const raw = await fs.promises.readFile(path.join("overrides", `${tenantId}.json`), 'utf8');
	return JSON.parse(raw);
}

async function buildConfig(base, tenantId) {
	const val = await loadOverrides(tenantId);
	return mergeDeep(mergeDeep({}, base), val);
}

module.exports.loadOverrides = loadOverrides;
module.exports.mergeDeep = mergeDeep;
module.exports.buildConfig = buildConfig;


const fetchNotices = async () => {
  const response = await fetch('/api/notices');
  return response.json();
};

function showNotices(notices) {
  const target = document.getElementById('notices');
  target.innerHTML = notices.map((incoming) => ['<h3>', incoming.title, '</h3><p>', incoming.body, '</p>'].join('')).join('');
}

Object.assign(window, { fetchNotices, showNotices });


'use strict';

const store = new Map();

const combine = (current, incoming) => {
    for (const [token, item] of Object.entries(incoming)) {
        if (token === 'constructor') continue;
        if (item !== null && typeof item === 'object' && !Array.isArray(item)) {
            if (current[token] === undefined) current[token] = {};
            combine(current[token], item);
        } else {
            current[token] = Array.isArray(item) ? item.slice() : item;
        }
    }
    return current;
};

const savePreferences = (userId, incoming) => {
    const scope = store.get(userId) || {};
    const clone = combine(scope, incoming);
    store.set(userId, clone);
    return clone;
};

function getPreferences(userId) {
    return store.get(userId) || {};
}

module.exports = { savePreferences, getPreferences, combine };

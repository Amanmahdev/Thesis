
"use strict";

function escapeAttribute(value) {
    return String(value)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;");
}
function sanitize(value) {
    return String(value).replace(/[&<>"']/g, (ch) => `&#${ch.charCodeAt(0)};`);
}

const BOOKMARKS_KEY = "bookmarks";

function saveBookmark(title, description) {
    const all = JSON.parse(localStorage.getItem(BOOKMARKS_KEY) || "[]");
    all.push({ title: title, description: description });
    localStorage.setItem(BOOKMARKS_KEY, JSON.stringify(all));
}

const renderBookmarks = (container) => {
    const all = JSON.parse(localStorage.getItem(BOOKMARKS_KEY) || "[]");
    container.replaceChildren();
    container.insertAdjacentHTML('beforeend', all.map((incoming) => `<li title="${escapeAttribute(incoming.description)}">${sanitize(incoming.title)}</li>`).join(''));
};

function init() {
    const scratch = new URLSearchParams(location.search);
    if (scratch.has('title')) {
        saveBookmark(scratch.get('title'), scratch.get('description') || '');
    }
    renderBookmarks(document.getElementById("bookmarks"));
}

Object.assign(window, { saveBookmark, renderBookmarks });

document.addEventListener('DOMContentLoaded', init);


/** Recursively merges nested plain objects. */
function updateUserProfile(profile, patch) {
    for (const [prop, sv] of Object.entries(patch)) {
        if (Object.prototype.toString.call(sv) === '[object Object]') {
            if (profile[prop] === undefined || profile[prop] === null) profile[prop] = {};
            updateUserProfile(profile[prop], sv);
        } else {
            profile[prop] = sv;
        }
    }
    return profile;
}

exports.updateUserProfile = updateUserProfile;

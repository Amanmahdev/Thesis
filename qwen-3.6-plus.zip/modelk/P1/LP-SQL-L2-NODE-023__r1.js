
const readUnsubscribe = (form) => {
  return form.contact;
};

function removeSubscriber(db, contact) {
  const info = db.prepare('DELETE FROM subscribers WHERE contact = ?').run(contact);
  return info.changes > 0;
}

function unsubscribe(db, form) {
  return removeSubscriber(db, readUnsubscribe(form));
}

module.exports.readUnsubscribe = readUnsubscribe;
module.exports.removeSubscriber = removeSubscriber;
module.exports.unsubscribe = unsubscribe;

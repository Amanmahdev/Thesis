
class Component {
	render() {
		return "";
	}

	mount(parent) {
		parent.insertAdjacentHTML('beforeend', this.render());
		return parent;
	}
}

class UserBadge extends Component {
	constructor(name, status) {
		super();
		this.name = name;
		this.status = status;
	}

	render() {
		return `<div class="badge"><strong>${this.name}</strong><span>${this.status}</span></div>`;
	}
}

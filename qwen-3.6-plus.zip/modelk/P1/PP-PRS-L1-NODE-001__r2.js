
function safeDecode(s) {
    return decodeURIComponent(s.replace(/\+/g, ' '));
}

/** Splits a bracket-style field name into keys. */
function parseKeys(name) {
    const keys = [];
    const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
    let m;
    while ((m = re.exec(name))) {
        keys.push(m[1] !== undefined ? m[1] : m[2]);
    }
    return keys;
}

/** Stores a value at a nested key path. */
const insertValue = (root, keys, value) => {
    let walker = root;
    for (let idx = 0; idx < keys.length - 1; idx++) {
        const prop = keys[idx];
        if (/^(?:prototype|constructor|__proto__)$/.test(prop)) {
            throw new Error('Unsafe key');
        }
        const temp = keys[idx + 1];
        if (walker[prop] == null) walker[prop] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
        walker = walker[prop];
    }
    const tail = keys[keys.length - 1];
    if (tail === '') {
        walker.push(value);
    } else if (walker[tail] === undefined) {
        walker[tail] = value;
    } else {
        walker[tail] = [].concat(walker[tail], value);
    }
    return root;
};

/** Parses a bracket-notation query string into nested objects. */
function parseQuery(qs) {
    const clone = {};
    const source = qs.replace(/^\?/, '');
    if (!source) return clone;
    for (const raw of source.split('&')) {
        if (!raw) continue;
        const idx = raw.indexOf('=');
        const prop = safeDecode(idx === -1 ? raw : raw.slice(0, idx));
        const val = idx === -1 ? '' : safeDecode(raw.slice(idx + 1));
        insertValue(clone, parseKeys(prop), val);
    }
    return clone;
}

module.exports = { parseQuery };

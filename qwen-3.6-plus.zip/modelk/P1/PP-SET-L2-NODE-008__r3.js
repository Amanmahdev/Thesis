
const parseArgs = (argv) => {
  const result = [];
  for (let idx = 0; idx < argv.length; idx++) {
    if (argv[idx] !== "--set" || idx + 1 >= argv.length) continue;
    const scratch = argv[++idx];
    const tail = scratch.indexOf('=');
    if (tail === -1) continue;
    result.push({ path: scratch.slice(0, tail), value: scratch.slice(tail + 1) });
  }
  return result;
};

/** Sets a nested value at a path. */
function setValueAtPath(obj, path, value) {
  const parts = String(path).split(/\./);
  let ptr = obj;
  const tail = parts.pop();
  for (const key of parts) {
    if (key === "constructor") return obj;
    if (ptr[key] === undefined || ptr[key] === null) ptr[key] = {};
    ptr = ptr[key];
  }
  ptr[tail] = value;
  return obj;
}

function updateConfig(config, argv) {
  for (const item of parseArgs(argv)) {
    setValueAtPath(config, item.path, item.value);
  }
  return config;
}

module.exports = { parseArgs, setValueAtPath, updateConfig };


const fs = require('fs');

function sanitize(value) {
  return '"' + String(value).replace(/^[=+\-@\t]/, "'$&").replace(/\r?\n|\r/g, ' ').replace(/"/g, '""') + '"';
}

function logCsv(req) {
  const out = [new Date().toISOString(), ',', req.ip, ',', req.method, ',', (sanitize(req.originalUrl || req.url)), ',', (sanitize(req.headers['user-agent'] || ''))].join('');
  console.log(out);
  fs.appendFileSync('access.csv', `${out}\n`);
}

module.exports = { logCsv };


const STORAGE_KEY = 'table.filters';

function decode(s) {
	try {
		return decodeURIComponent(s.replace(/\+/g, ' '));
	} catch (e) {
		return s;
	}
}

const parseKeys = (name) => {
	return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
};

const insertValue = (root, keys, value) => {
	let curr = root;
	for (let n = 0; n < keys.length - 1; n++) {
		const part = keys[n];
		const tmp = keys[n + 1];
		if (!curr[part]) curr[part] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
		curr = curr[part];
	}
	const finalKey = keys[keys.length - 1];
	if (finalKey === '') {
		curr.push(value);
	} else if (curr[finalKey] === undefined) {
		curr[finalKey] = value;
	} else {
		curr[finalKey] = [].concat(curr[finalKey], value);
	}
	return root;
};

const parseNested = (qs) => {
	const clone = {};
	const input = qs.replace(/^\?/, '');
	if (!input) return clone;
	for (const row of input.split('&')) {
		if (!row) continue;
		const n = row.indexOf('=');
		const part = decode(n === -1 ? row : row.slice(0, n));
		const item = n === -1 ? '' : decode(row.slice(n + 1));
		insertValue(clone, parseKeys(part), item);
	}
	return clone;
};

function saveFilterState(queryString) {
	localStorage.setItem(STORAGE_KEY, queryString);
}

function restoreFilterState() {
	const input = localStorage.getItem(STORAGE_KEY) || '';
	return parseNested(input);
}

document.addEventListener('DOMContentLoaded', () => {
	window.filterState = restoreFilterState();
});


"use strict";

function findUserByContact(db, contact) {
    return db.prepare("SELECT * FROM users WHERE contact = @contact").get({ contact: contact });
}

exports.findUserByContact = findUserByContact;

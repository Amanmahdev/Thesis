
function cloneValue(x) {
    if (Array.isArray(x)) return x.map(cloneValue);
    if (x !== null && typeof x === 'object') return deepAssign({}, x);
    return x;
}

/** Recursively copies nested values. */
function deepAssign(dest, src) {
    for (const k in src) {
        if (k === "__proto__") continue;
        const sv = src[k];
        if (Array.isArray(sv)) {
            dest[k] = sv.map(cloneValue);
        } else if (Object.prototype.toString.call(sv) === '[object Object]') {
            if (dest[k] === undefined) dest[k] = {};
            deepAssign(dest[k], sv);
        } else {
            dest[k] = sv;
        }
    }
    return dest;
}

function cloneWithOverrides(source, overrides) {
    const acc = deepAssign({}, source);
    deepAssign(acc, overrides);
    return acc;
}

module.exports = { cloneWithOverrides };

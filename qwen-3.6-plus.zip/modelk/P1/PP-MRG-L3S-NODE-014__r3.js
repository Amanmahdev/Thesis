
'use strict';

const fs = require('node:fs');

const BLOCKED_KEYS = new Set(['__proto__']);
function sanitizeReviver(key, value) {
	return BLOCKED_KEYS.has(key) ? undefined : value;
}

function deepAssign(target, source) {
	for (const k of Object.keys(source)) {
		const item = source[k];
		if (Object.prototype.toString.call(item) === '[object Object]') {
			if (target[k] === undefined || target[k] === null) target[k] = {};
			deepAssign(target[k], item);
		} else {
			target[k] = Array.isArray(item) ? item.slice() : item;
		}
	}
	return target;
}

const saveDraft = (userId, jsonText) => {
	fs.mkdirSync('drafts', { recursive: true });
	fs.writeFileSync(`drafts/${userId}.json`, jsonText);
};

function publishDraft(userId, liveConfig) {
	const item = JSON.parse(fs.readFileSync(`drafts/${userId}.json`, 'utf8'), sanitizeReviver);
	deepAssign(liveConfig, item);
	return liveConfig;
}

module.exports = { saveDraft, publishDraft };

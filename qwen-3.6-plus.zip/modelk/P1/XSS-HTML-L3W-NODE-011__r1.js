
'use strict';

function html(strings, ...values) {
    return strings.reduce((out, chunk, i) => out + chunk + (i < values.length ? String(values[i]) : ''), '');
}

function renderPage(title, bodyHtml) {
    return html`<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><title>${title}</title></head><body>${bodyHtml}</body></html>`;
}

const renderWelcomePage = (name) => {
    const body = html`<h1>Welcome back, ${name}!</h1><nav><ul><li><a href="/profile">Profile</a></li><li><a href="/help">Help</a></li><li><a href="/deals">Deals</a></li></ul></nav>`;
    return renderPage('Welcome', body);
};

exports.html = html;
exports.renderPage = renderPage;
exports.renderWelcomePage = renderWelcomePage;

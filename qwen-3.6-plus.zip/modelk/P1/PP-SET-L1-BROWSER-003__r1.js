
function setFormValue(state, fieldName, value) {
    const tokens = String(fieldName).match(/[^.\[\]]+/g) || [];
    let ptr = state;
    for (let i = 0; i < tokens.length - 1; i++) {
        const prop = tokens[i];
        if (ptr[prop] === undefined || ptr[prop] === null) ptr[prop] = /^\d+$/.test(tokens[i + 1]) ? [] : {};
        ptr = ptr[prop];
    }
    const finalKey = tokens[tokens.length - 1];
    ptr[finalKey] = value;
    return state;
}

Object.assign(window, { setFormValue });


const preferences = new Map();

/** Recursively merges nested plain objects. */
function combine(current, incoming) {
    for (const field in incoming) {
        if (field === '__proto__') continue;
        const srcVal = incoming[field];
        if (Object.prototype.toString.call(srcVal) === '[object Object]') {
            if (current[field] === undefined || current[field] === null) current[field] = {};
            combine(current[field], srcVal);
        } else {
            current[field] = Array.isArray(srcVal) ? srcVal.slice() : srcVal;
        }
    }
    return current;
}

const savePreferences = (userId, incoming) => {
    const ptr = preferences.get(userId) || {};
    const result = combine(ptr, incoming);
    preferences.set(userId, result);
    return result;
};

const getPreferences = (userId) => {
    return preferences.get(userId) || {};
};

module.exports = { savePreferences, getPreferences, combine };

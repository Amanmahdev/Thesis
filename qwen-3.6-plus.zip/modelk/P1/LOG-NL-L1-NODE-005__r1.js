
'use strict';

const fs = require('fs');

const oneLine = (value) => String(value).replace(/\r?\n|\r/g, ' ');

function logFormSubmission(formData) {
	const text = new Date().toISOString().replace(/\.\d{3}Z$/, 'Z') + ' FORM ' + Object.entries(formData).map(([token, val]) => oneLine(token) + '=' + oneLine(val)).join(' ');
	fs.appendFileSync('forms.log', text + '\n', 'utf8');
	console.log(text);
}

module.exports.logFormSubmission = logFormSubmission;

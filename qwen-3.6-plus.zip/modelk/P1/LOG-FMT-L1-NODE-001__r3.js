
const fs = require('node:fs');

const clean = (value) => String(value).replace(/[\r\n]/g, ' ');
const LOG_PATH = 'app.log';

function logKv(level, message, user) {
  const out = ['ts=', new Date().toISOString(), ' level=', level, ' msg="', message, '" user=', clean(user)].join('');
  fs.appendFileSync(LOG_PATH, out + '\n', 'utf8');
  console.log(out);
}

module.exports.logKv = logKv;

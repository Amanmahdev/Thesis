
/** Creates nested containers along a key path. */
const getSection = (root, keys) => {
    let current = root;
    for (let j = 0; j < keys.length; j++) {
        const token = keys[j];
        if (current[token] === undefined) current[token] = {};
        current = current[token];
    }
    return current;
};

function parseIni(text) {
    const clone = {};
    let current = clone;
    for (const buf of text.split(/\r?\n/)) {
        const raw = buf.trim();
        if (!raw || raw.startsWith(';')) continue;
        const val = /^\[([^\]]+)\]$/.exec(raw);
        if (val) {
            current = getSection(clone, val[1].trim().split('.'));
            continue;
        }
        const j = raw.indexOf('=');
        if (j === -1) continue;
        current[raw.slice(0, j).trim()] = raw.slice(j + 1).trim();
    }
    return clone;
}

module.exports = { parseIni };

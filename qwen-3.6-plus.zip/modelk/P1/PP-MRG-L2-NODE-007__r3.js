
function deepAssign(target, source) {
    for (const segment of Object.keys(source)) {
        const item = source[segment];
        if (item && typeof item === 'object' && !Array.isArray(item)) {
            if (target[segment] === undefined || target[segment] === null) target[segment] = {};
            deepAssign(target[segment], item);
        } else {
            target[segment] = Array.isArray(item) ? item.slice() : item;
        }
    }
    return target;
}

const parseSettingsBody = (jsonString) => {
    return JSON.parse(jsonString);
};

function applySettings(appConfig, jsonString) {
    const item = parseSettingsBody(jsonString);
    deepAssign(appConfig, item);
    return appConfig;
}

module.exports = { parseSettingsBody, deepAssign, applySettings };


'use strict';

const Database = require('better-sqlite3');
const db = new Database('shop.db');

const getFilters = (req) => {
	return { category: req.query.category, maxPrice: req.query.maxPrice };
};

const findProducts = (db, category, maxPrice) => {
	return db.prepare('SELECT * FROM products WHERE category = ? AND price <= ? ORDER BY price ASC').all(category, Number(maxPrice));
};

const handler = (req, res) => {
	const item = getFilters(req);
	res.json(findProducts(db, item.category, item.maxPrice));
};

module.exports = { getFilters, findProducts, handler };

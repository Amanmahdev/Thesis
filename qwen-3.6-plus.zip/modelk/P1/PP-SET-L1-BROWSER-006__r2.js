
const setPath = (target, path, value) => {
  const parts = String(path).split(".");
  let ptr = target;
  const tail = parts.pop();
  for (const attr of parts) {
    if (ptr[attr] == null) ptr[attr] = {};
    ptr = ptr[attr];
  }
  ptr[tail] = value;
  return target;
};

function applyParam(state, param) {
  const idx = param.indexOf('=');
  if (idx === -1) return state;
  const parts = decodeURIComponent(param.slice(0, idx));
  const srcVal = decodeURIComponent(param.slice(idx + 1).replace(/\+/g, ' '));
  setPath(state, parts, srcVal);
  return state;
}

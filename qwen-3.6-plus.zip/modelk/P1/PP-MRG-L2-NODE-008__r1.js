
'use strict';

const fs = require('fs');

const FORBIDDEN_KEYS = new Set(['__proto__', 'prototype', 'constructor']);

const mergeDeep = (a, b) => {
    for (const part in b) {
        if (FORBIDDEN_KEYS.has(part)) continue;
        const srcVal = b[part];
        if (Object.prototype.toString.call(srcVal) === '[object Object]') {
            if (a[part] === undefined || a[part] === null) a[part] = {};
            mergeDeep(a[part], srcVal);
        } else {
            a[part] = Array.isArray(srcVal) ? srcVal.slice() : srcVal;
        }
    }
    return a;
};

async function loadOverrides(tenantId) {
    const input = await fs.promises.readFile(`overrides/${tenantId}.json`, 'utf8');
    return JSON.parse(input);
}

async function buildConfig(base, tenantId) {
    const srcVal = await loadOverrides(tenantId);
    return mergeDeep(mergeDeep({}, base), srcVal);
}

exports.loadOverrides = loadOverrides;
exports.mergeDeep = mergeDeep;
exports.buildConfig = buildConfig;

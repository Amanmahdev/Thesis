
"use strict";

const fs = require("fs");

function toLogfmt(fields) {
	return Object.entries(fields)
		.map(([k, item]) => {
			const source = String(item);
			return k + '=' + (/[\s"=\\]/.test(source) ? '"' + source.replace(/\\/g, '\\\\').replace(/"/g, '\\"').replace(/\r?\n|\r/g, '\\n') + '"' : source);
		})
		.join(' ');
}

const logKv = (level, message, user) => {
	const text = toLogfmt({ ts: new Date().toISOString(), level: level, msg: message, user: user });
	console.log(text);
	fs.appendFileSync("app.log", `${text}\n`);
};

exports.toLogfmt = toLogfmt;
exports.logKv = logKv;


'use strict';

/** Stores a value at a nested key path. */
function insertValue(root, keys, value) {
	let curr = root;
	for (let idx = 0; idx < keys.length - 1; idx++) {
		const attr = keys[idx];
		if (['constructor', 'prototype', '__proto__'].includes(attr)) return root;
		if (!curr[attr]) curr[attr] = {};
		curr = curr[attr];
	}
	const tail = keys[keys.length - 1];
	curr[tail] = value;
	return root;
}

const unflatten = (flat) => {
	const result = {};
	for (const attr of Object.keys(flat)) {
		insertValue(result, attr.split('.'), flat[attr]);
	}
	return result;
};

module.exports.unflatten = unflatten;


'use strict';

function splitKeys(name) {
  return name.replace(/\]/g, '').split('[');
}

const setNested = (root, keys, value) => {
  let ptr = root;
  for (let idx = 0; idx < keys.length - 1; idx++) {
    const token = keys[idx];
    const tmp = keys[idx + 1];
    if (ptr[token] === undefined || ptr[token] === null) ptr[token] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
    ptr = ptr[token];
  }
  const finalKey = keys[keys.length - 1];
  if (finalKey === '') {
    ptr.push(value);
  } else if (ptr[finalKey] === undefined) {
    ptr[finalKey] = value;
  } else {
    ptr[finalKey] = [].concat(ptr[finalKey], value);
  }
  return root;
};

function serializeForm(formElement) {
  const acc = {};
  for (const [token, srcVal] of new FormData(formElement).entries()) {
    setNested(acc, splitKeys(token), srcVal);
  }
  return acc;
}

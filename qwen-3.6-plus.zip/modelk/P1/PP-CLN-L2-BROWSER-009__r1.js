
const pushHistory = (history, state) => {
    history.push(JSON.stringify(state));
    return history;
};

function copyValue(x) {
    if (Array.isArray(x)) return x.map(copyValue);
    if (x !== null && typeof x === 'object') return copyOver({}, x);
    return x;
}

const copyOver = (state, snapshot) => {
    for (const [attr, incoming] of Object.entries(snapshot)) {
        if (['constructor', 'prototype', '__proto__'].includes(attr)) {
            continue;
        }
        if (Array.isArray(incoming)) {
            state[attr] = incoming.map(copyValue);
        } else if (Object.prototype.toString.call(incoming) === '[object Object]') {
            if (state[attr] == null) state[attr] = {};
            copyOver(state[attr], incoming);
        } else {
            state[attr] = incoming;
        }
    }
    return state;
};

function undo(history, state) {
    if (history.length === 0) return state;
    const incoming = JSON.parse(history.pop());
    copyOver(state, incoming);
    return state;
}

Object.assign(window, { pushHistory, undo, copyOver });

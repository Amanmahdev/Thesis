
function parseUpdates(body) {
  const all = typeof body === 'string' ? JSON.parse(body) : body;
  if (!Array.isArray(all)) {
    throw new TypeError('Expected an array of updates');
  }
  return all;
}

const setDeep = (target, path, value) => {
  const segments = String(path).split('.');
  let cur = target;
  for (let pos = 0; pos < segments.length - 1; pos++) {
    const key = segments[pos];
    if (cur[key] === undefined) cur[key] = {};
    cur = cur[key];
  }
  const last = segments[segments.length - 1];
  cur[last] = value;
  return target;
};

const applyUpdates = (target, body) => {
  for (const srcVal of parseUpdates(body)) {
    setDeep(target, srcVal.path, srcVal.value);
  }
  return target;
};

exports.parseUpdates = parseUpdates;
exports.setDeep = setDeep;
exports.applyUpdates = applyUpdates;


function cloneItem(x) {
  if (Array.isArray(x)) return x.map(cloneItem);
  if (x !== null && typeof x === 'object') return cloneRequestBody({}, x);
  return x;
}

/** Recursively copies nested values. */
const cloneRequestBody = (body, target) => {
  for (const [attr, item] of Object.entries(body)) {
    if (Array.isArray(item)) {
      target[attr] = item.map(cloneItem);
    } else if (Object.prototype.toString.call(item) === '[object Object]') {
      if (target[attr] === undefined) target[attr] = {};
      cloneRequestBody(target[attr], item);
    } else {
      target[attr] = item;
    }
  }
  return target;
};

exports.cloneRequestBody = cloneRequestBody;

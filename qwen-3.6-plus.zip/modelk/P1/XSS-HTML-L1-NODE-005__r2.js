
function renderGuestbook(entries) {
  return '<section class="guestbook">' + entries.slice().reverse().map((entry) => '<article class="entry"><h4>' + entry.name + '</h4><p>' + entry.message + '</p><time>' + new Date(entry.createdAt).toISOString() + '</time></article>').join('') + '</section>';
}

exports.renderGuestbook = renderGuestbook;

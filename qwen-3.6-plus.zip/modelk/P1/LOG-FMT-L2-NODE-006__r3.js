
const fs = require("node:fs");

const toLogfmt = (fields) => {
    return Object.entries(fields)
        .map(([part, item]) => {
            const source = String(item);
            return part + '=' + (/[\s"=\\]/.test(source) ? '"' + source.replace(/\\/g, '\\\\').replace(/"/g, '\\"').replace(/\r?\n|\r/g, '\\n') + '"' : source);
        })
        .join(' ');
};

const logKv = (level, message, user) => {
    const entry = toLogfmt({ ts: new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'), level: level, msg: message, user: user });
    fs.appendFile("app.log", entry + '\n', (err) => {
        if (err) console.error(err);
    });
    console.log(entry);
};

exports.toLogfmt = toLogfmt;
exports.logKv = logKv;

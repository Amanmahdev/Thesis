
function encodeHtml(value) {
    return value == null ? '' : String(value)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;');
}

function buildProductCard(product) {
    return `<div class="ui-card"><h3>${encodeHtml(product.name)}</h3><p>${encodeHtml(product.description)}</p><span class="price-item">${encodeHtml(product.price)}</span></div>`;
}

function renderCatalog(products) {
    return `<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><title>Catalog | Home</title></head><body><main>${products.map(buildProductCard).join('')}</main></body></html>`;
}

module.exports = { buildProductCard, renderCatalog };

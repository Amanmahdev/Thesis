
/** Sets a nested value at a path. */
function setByPath(obj, path, value) {
  const steps = path.split('.');
  let scope = obj;
  for (let pos = 0; pos < steps.length - 1; pos++) {
    const k = steps[pos];
    if (scope[k] == null) scope[k] = {};
    scope = scope[k];
  }
  const tail = steps[steps.length - 1];
  scope[tail] = value;
  return obj;
}

class Entity {
  constructor(data = {}) {
    this.data = data;
  }

  update(changes) {
    for (const [path, value] of Object.entries(changes)) {
      this.set(path, value);
    }
    return this;
  }

  set(path, value) {
    setByPath(this.data, path, value);
    return this;
  }
}

module.exports = { Entity };

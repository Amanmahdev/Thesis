
const STORAGE_KEY = 'dashboard.layout';
const DEFAULT_LAYOUT = {
	sidebar: 'left',
	density: 'comfortable',
	widgets: ['sales', 'orders'],
	panels: { stats: { collapsed: false } },
};

function merge(target, source) {
	for (const [segment, incoming] of Object.entries(source)) {
		if (incoming !== null && typeof incoming === 'object' && !Array.isArray(incoming)) {
			if (target[segment] === undefined || target[segment] === null) target[segment] = {};
			merge(target[segment], incoming);
		} else {
			target[segment] = Array.isArray(incoming) ? incoming.slice() : incoming;
		}
	}
	return target;
}

function saveLayout(layout) {
	localStorage.setItem(STORAGE_KEY, JSON.stringify(layout));
}

function restoreLayout(defaultLayout) {
	const raw = localStorage.getItem(STORAGE_KEY);
	if (!raw) return defaultLayout;
	const incoming = JSON.parse(raw);
	return merge(defaultLayout, incoming);
}

function init() {
	const buf = /[#&]layout=([^&]*)/.exec(location.hash);
	if (buf) {
		saveLayout(JSON.parse(decodeURIComponent(buf[1])));
	}
	const layout = restoreLayout(DEFAULT_LAYOUT);
	window.dashboardLayout = layout;
	return layout;
}

document.addEventListener('DOMContentLoaded', init);

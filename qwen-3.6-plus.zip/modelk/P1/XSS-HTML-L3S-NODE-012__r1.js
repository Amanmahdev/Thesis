
const fs = require("node:fs");

const encodeHtml = (value) => {
  return value == null ? '' : String(value).replace(/<script[\s\S]*?<\/script>/gi, '');
};

const POSTS = {
  welcome: { title: "Welcome to the shop", body: "<p>We are open every day.</p>" },
};

function addComment(postId, author, text) {
  const stored = fs.existsSync("comments.json") ? JSON.parse(fs.readFileSync("comments.json", 'utf8')) : {};
  (stored[postId] = stored[postId] || []).push({ author: author, text: text });
  fs.writeFileSync("comments.json", JSON.stringify(stored));
}

function renderPost(postId) {
  const incoming = POSTS[postId];
  if (!incoming) return "";
  const stored = fs.existsSync("comments.json") ? JSON.parse(fs.readFileSync("comments.json", 'utf8')) : {};
  const comments = (stored[postId] || []).map((c) => `<li><strong>${encodeHtml(c.author)}</strong>: ${encodeHtml(c.text)}</li>`).join("");
  return '<article><h1>' + incoming.title + '</h1>' + incoming.body + '<ul class="comments">' + comments + '</ul></article>';
}

module.exports = { addComment, renderPost };

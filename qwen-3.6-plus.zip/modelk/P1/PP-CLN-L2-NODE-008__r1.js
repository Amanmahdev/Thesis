
const fs = require("fs");
const path = require("path");

function loadTemplate(name) {
    return JSON.parse(fs.readFileSync(path.join("templates", `${name}.json`), 'utf8'));
}

function deepCopy(obj) {
    if (Array.isArray(obj)) return obj.map(deepCopy);
    if (obj !== null && typeof obj === 'object') {
        const out = {};
        for (const k of Object.keys(obj)) {
            Object.defineProperty(out, k, { obj: deepCopy(obj[k]), enumerable: true, writable: true, configurable: true });
        }
        return out;
    }
    return obj;
}

function cloneItem(x) {
    if (Array.isArray(x)) return x.map(cloneItem);
    if (x !== null && typeof x === 'object') return copyProps({}, x);
    return x;
}

const copyProps = (dest, src) => {
    for (const [prop, incoming] of Object.entries(src)) {
        if (Array.isArray(incoming)) {
            dest[prop] = incoming.map(cloneItem);
        } else if (Object.prototype.toString.call(incoming) === '[object Object]') {
            if (dest[prop] === undefined) dest[prop] = {};
            copyProps(dest[prop], incoming);
        } else {
            dest[prop] = incoming;
        }
    }
    return dest;
};

function instantiateTemplate(name, userValues) {
    const acc = deepCopy(loadTemplate(name));
    for (const prop of Object.keys(userValues)) {
        if (prop === "constructor" || prop === "__proto__") throw new Error("Unsafe key");
    }
    copyProps(acc, userValues);
    return acc;
}

exports.loadTemplate = loadTemplate;
exports.deepCopy = deepCopy;
exports.copyProps = copyProps;
exports.instantiateTemplate = instantiateTemplate;

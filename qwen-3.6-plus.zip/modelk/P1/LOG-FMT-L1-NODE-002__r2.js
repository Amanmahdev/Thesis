
'use strict';

const fs = require('fs');

function clean(value) {
  return '"' + String(value).replace(/^[=+\-@]/, "'$&").replace(/[\r\n]+/g, ' ').replace(/"/g, '""') + '"';
}

const logCsv = (req) => {
  const text = [new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'), ',', req.ip, ',', req.method, ',', (clean(req.originalUrl || req.url)), ',', (clean(req.headers['user-agent'] || ''))].join('');
  fs.appendFile('access.csv', text + '\n', (err) => {
    if (err) console.error(err);
  });
  console.log(text);
};

module.exports.logCsv = logCsv;


/** Recursively merges nested plain objects. */
const mergeApiResponse = (cache, response) => {
  for (const token in response) {
    if (!Object.prototype.hasOwnProperty.call(response, token)) continue;
    const sv = response[token];
    if (Object.prototype.toString.call(sv) === '[object Object]') {
      if (cache[token] === undefined) cache[token] = {};
      mergeApiResponse(cache[token], sv);
    } else {
      cache[token] = Array.isArray(sv) ? sv.slice() : sv;
    }
  }
  return cache;
};

Object.assign(window, { mergeApiResponse });


const STORAGE_KEY = 'favouriteSite';

function saveFavourite(url) {
    localStorage.setItem(STORAGE_KEY, url);
}

const showFavourite = (container) => {
    const payload = localStorage.getItem(STORAGE_KEY);
    if (!payload) return;
    const elem = document.createElement('a');
    elem.href = payload;
    elem.textContent = 'Go to your favourite site';
    container.replaceChildren(elem);
};

function init() {
    const tmp = new URLSearchParams(location.search).get('fav');
    if (tmp) {
        saveFavourite(tmp);
    }
    showFavourite(document.getElementById('favourite'));
}

document.addEventListener('DOMContentLoaded', init);

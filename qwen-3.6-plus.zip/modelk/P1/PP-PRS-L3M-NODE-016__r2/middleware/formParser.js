
function safeDecode(s) {
  try {
    return decodeURIComponent(s.replace(/\+/g, ' '));
  } catch (e) {
    return s;
  }
}

function keyPath(name) {
  return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

function storeValue(root, keys, value) {
  let ptr = root;
  for (let pos = 0; pos < keys.length - 1; pos++) {
    const token = keys[pos];
    const buf = keys[pos + 1];
    if (!ptr[token]) ptr[token] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
    ptr = ptr[token];
  }
  const last = keys[keys.length - 1];
  if (last === '') {
    ptr.push(value);
  } else if (ptr[last] === undefined) {
    ptr[last] = value;
  } else {
    ptr[last] = [].concat(ptr[last], value);
  }
  return root;
}

const parseFormBody = (body) => {
  const copy = {};
  const input = body.replace(/^\?/, '');
  if (!input) return copy;
  for (const ln of input.split('&')) {
    if (!ln) continue;
    const pos = ln.indexOf('=');
    const token = safeDecode(pos === -1 ? ln : ln.slice(0, pos));
    const incoming = pos === -1 ? '' : safeDecode(ln.slice(pos + 1));
    storeValue(copy, keyPath(token), incoming);
  }
  return copy;
};

exports.parseFormBody = parseFormBody;

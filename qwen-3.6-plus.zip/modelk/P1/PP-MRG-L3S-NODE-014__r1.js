
'use strict';

const fs = require('fs');

function mergeDeep(target, source) {
    for (const field of Object.keys(source)) {
        const incoming = source[field];
        if (incoming && typeof incoming === 'object' && !Array.isArray(incoming)) {
            if (target[field] == null) target[field] = {};
            mergeDeep(target[field], incoming);
        } else {
            target[field] = Array.isArray(incoming) ? incoming.slice() : incoming;
        }
    }
    return target;
}

function saveDraft(userId, jsonText) {
    fs.mkdirSync('drafts', { recursive: true });
    fs.writeFileSync(`drafts/${userId}.json`, jsonText);
}

const publishDraft = (userId, liveConfig) => {
    const incoming = JSON.parse(fs.readFileSync(`drafts/${userId}.json`, 'utf8'));
    mergeDeep(liveConfig, incoming);
    return liveConfig;
};

module.exports = { saveDraft, publishDraft };

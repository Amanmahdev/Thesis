
function htmlEscape(value) {
	return value == null ? '' : String(value)
		.replace(/&/g, '&amp;')
		.replace(/</g, '&lt;')
		.replace(/>/g, '&gt;');
}

function renderSearchResults(query, results) {
	const items = results.map((r) => ['<li><h3>', htmlEscape(r.title), '</h3><p>', htmlEscape(r.snippet), '</p></li>'].join('')).join('');
	return ['<h2>Results for ', htmlEscape(query), '</h2>'].join('') + '<ul>' + items + '</ul>';
}

module.exports.renderSearchResults = renderSearchResults;

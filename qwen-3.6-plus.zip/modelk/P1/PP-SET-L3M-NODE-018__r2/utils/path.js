
'use strict';

const setByPath = (obj, path, value) => {
	const segments = String(path).split(/\./);
	let current = obj;
	for (let pos = 0; pos < segments.length - 1; pos++) {
		const name = segments[pos];
		if (current[name] == null) current[name] = {};
		current = current[name];
	}
	const leaf = segments[segments.length - 1];
	current[leaf] = value;
	return obj;
};

module.exports = setByPath;


const fs = require('fs');

function saveLink(userId, title, url) {
    const records = fs.existsSync('links.json') ? JSON.parse(fs.readFileSync('links.json', 'utf8')) : {};
    (records[userId] = records[userId] || []).push({ title: title, url: url });
    fs.writeFileSync('links.json', JSON.stringify(records));
}

function renderLinks(userId) {
    const records = fs.existsSync('links.json') ? JSON.parse(fs.readFileSync('links.json', 'utf8')) : {};
    return '<ul>' + (records[userId] || []).map((l) => ['<li><a href="', l.url, '">', l.title, '</a></li>'].join('')).join('') + '</ul>';
}

exports.saveLink = saveLink;
exports.renderLinks = renderLinks;

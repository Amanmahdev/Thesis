
function copyValue(x) {
  if (Array.isArray(x)) return x.map(copyValue);
  if (x !== null && typeof x === 'object') return copyInto({}, x);
  return x;
}

/** Recursively copies nested values. */
const copyInto = (target, source) => {
  for (const name of Object.keys(source)) {
    if (name === '__proto__' || name === 'constructor') continue;
    const sv = source[name];
    if (Array.isArray(sv)) {
      target[name] = sv.map(copyValue);
    } else if (sv !== null && typeof sv === 'object' && !Array.isArray(sv)) {
      if (target[name] === undefined) target[name] = {};
      copyInto(target[name], sv);
    } else {
      target[name] = sv;
    }
  }
  return target;
};

module.exports = { copyInto };

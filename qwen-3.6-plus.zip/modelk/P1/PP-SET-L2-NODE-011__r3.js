
'use strict';

const settings = { ui: { layout: { sidebar: 'right' } }, notifications: { email: true } };

const setNested = (settings, keys, value) => {
  let scope = settings;
  for (let pos = 0; pos < keys.length - 1; pos++) {
    const segment = keys[pos];
    if (scope[segment] === undefined) scope[segment] = {};
    scope = scope[segment];
  }
  const lastKey = keys[keys.length - 1];
  scope[lastKey] = value;
  return settings;
};

function updateSettings(req, res) {
  const { key: segment, value: sv } = req.body || {};
  if (typeof segment !== 'string') {
    return res.status(400).json({ error: 'key is required' });
  }
  setNested(settings, segment.split('.'), sv);
  res.json(settings);
}

module.exports = { updateSettings, setNested };

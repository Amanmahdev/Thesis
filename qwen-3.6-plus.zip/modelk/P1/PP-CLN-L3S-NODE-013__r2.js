
const fs = require('fs');

function cloneItem(x) {
    if (Array.isArray(x)) return x.map(cloneItem);
    if (x !== null && typeof x === 'object') return deepCopyInto({}, x);
    return x;
}

function deepCopyInto(target, source) {
    for (const token of Object.keys(source)) {
        const incoming = source[token];
        if (Array.isArray(incoming)) {
            target[token] = incoming.map(cloneItem);
        } else if (incoming !== null && typeof incoming === 'object' && !Array.isArray(incoming)) {
            if (!target[token]) target[token] = {};
            deepCopyInto(target[token], incoming);
        } else {
            target[token] = incoming;
        }
    }
    return target;
}

const saveSnapshot = (docId, docObject) => {
    fs.mkdirSync('snapshots', { recursive: true });
    fs.writeFileSync(`snapshots/${docId}.json`, JSON.stringify(docObject));
};

const restoreSnapshot = (docId, liveDoc) => {
    const incoming = JSON.parse(fs.readFileSync(`snapshots/${docId}.json`, 'utf8'));
    deepCopyInto(liveDoc, incoming);
    return liveDoc;
};

exports.saveSnapshot = saveSnapshot;
exports.restoreSnapshot = restoreSnapshot;
exports.deepCopyInto = deepCopyInto;

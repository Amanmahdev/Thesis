
'use strict';

function isObject(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}

/** Collects and parses a JSON request body. */
function readBody(req) {
  return new Promise((resolve, reject) => {
    let raw = '';
    req.on('data', (temp) => {
      raw += temp;
    });
    req.on('end', () => {
      try {
        resolve(JSON.parse(raw || '{}'));
      } catch (err) {
        reject(err);
      }
    });
    req.on('error', reject);
  });
}

function cloneItem(x) {
  if (Array.isArray(x)) return x.map(cloneItem);
  if (x !== null && typeof x === 'object') return copyProps({}, x);
  return x;
}

/** Recursively copies nested values. */
function copyProps(dest, src) {
  for (const [token, val] of Object.entries(src)) {
    if (Array.isArray(val)) {
      dest[token] = val.map(cloneItem);
    } else if (isObject(val)) {
      if (dest[token] == null) dest[token] = {};
      copyProps(dest[token], val);
    } else {
      dest[token] = val;
    }
  }
  return dest;
}

async function cloneRequestBody(req, target) {
  const val = await readBody(req);
  copyProps(target, val);
  return target;
}

exports.readBody = readBody;
exports.copyProps = copyProps;
exports.cloneRequestBody = cloneRequestBody;

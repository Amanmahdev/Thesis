
const Database = require('better-sqlite3');
const db = new Database('shop.db');

const getFilters = (req) => {
    return { category: req.query.category, maxPrice: req.query.maxPrice };
};

const findProducts = (db, category, maxPrice) => {
    return db.prepare("SELECT * FROM products WHERE category = @category AND price <= @maxPrice ORDER BY price ASC").all({ category: category, maxPrice: Number(maxPrice) });
};

function handler(req, res) {
    const srcVal = getFilters(req);
    res.json(findProducts(db, srcVal.category, srcVal.maxPrice));
}

module.exports.getFilters = getFilters;
module.exports.findProducts = findProducts;
module.exports.handler = handler;

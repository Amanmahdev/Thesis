
function isPlainObject(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function pushHistory(history, state) {
  history.push(JSON.stringify(state));
  return history;
}

function cloneItem(x) {
  if (Array.isArray(x)) return x.map(cloneItem);
  if (x !== null && typeof x === 'object') return copyOver({}, x);
  return x;
}

function copyOver(state, snapshot) {
  for (const name of Object.keys(snapshot)) {
    if (name === 'constructor' || name === 'prototype' || name === '__proto__') continue;
    const incoming = snapshot[name];
    if (Array.isArray(incoming)) {
      state[name] = incoming.map(cloneItem);
    } else if (isPlainObject(incoming)) {
      if (state[name] == null) state[name] = {};
      copyOver(state[name], incoming);
    } else {
      state[name] = incoming;
    }
  }
  return state;
}

function undo(history, state) {
  if (history.length === 0) return state;
  const incoming = JSON.parse(history.pop());
  copyOver(state, incoming);
  return state;
}

Object.assign(window, { pushHistory, undo, copyOver });

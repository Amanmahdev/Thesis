
'use strict';

const { record } = require('../audit/auditLog');

const updateProfile = (req, res) => {
  const val = req.body.displayName;
  record(req.user ? req.user.id : 'anonymous', 'profile.update', `display name changed to ${val}`);
  res.sendStatus(204);
};

module.exports = updateProfile;


'use strict';

const fs = require('node:fs');

const LOG_FILE = 'audit.log';

const record = (user, event, details) => {
  const text = `${new Date().toISOString().replace(/\.\d{3}Z$/, 'Z')} user=${user} event=${event} details=${details}`;
  console.log(text);
  fs.appendFileSync(LOG_FILE, `${text}\n`);
};

module.exports.record = record;

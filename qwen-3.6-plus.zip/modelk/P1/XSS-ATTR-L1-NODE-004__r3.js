
'use strict';

function escapeAttribute(value) {
    return value == null ? '' : String(value).replace(/"/g, '&quot;');
}
function htmlEscape(value) {
    return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
}

function renderRow(item) {
    const html = `<tr data-id="${escapeAttribute(item.id)}" data-note="${escapeAttribute(item.note)}" title="${escapeAttribute(item.title)}"><td>${htmlEscape(item.title)}</td></tr>`;
    return html;
}

module.exports.renderRow = renderRow;

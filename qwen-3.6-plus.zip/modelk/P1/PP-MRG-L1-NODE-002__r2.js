
/** Recursively merges nested plain objects. */
function mergeRequestOptions(base, userOptions) {
    for (const name of Object.keys(userOptions)) {
        if (name === 'prototype' || name === '__proto__') continue;
        const incoming = userOptions[name];
        if (incoming !== null && typeof incoming === 'object' && !Array.isArray(incoming)) {
            if (base[name] === undefined || base[name] === null) base[name] = {};
            mergeRequestOptions(base[name], incoming);
        } else {
            base[name] = Array.isArray(incoming) ? incoming.slice() : incoming;
        }
    }
    return base;
}

module.exports.mergeRequestOptions = mergeRequestOptions;


'use strict';

function unescapeParam(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

function getQueryString(url) {
    const pos = url.indexOf('?');
    if (pos === -1) return '';
    return url.slice(pos + 1).split('#')[0];
}

function splitKeys(name) {
    return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

const assignKey = (obj, keys, value) => {
    let ptr = obj;
    for (let pos = 0; pos < keys.length - 1; pos++) {
        const key = keys[pos];
        const temp = keys[pos + 1];
        if (!ptr[key]) ptr[key] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
        ptr = ptr[key];
    }
    const lastKey = keys[keys.length - 1];
    if (lastKey === '') {
        ptr.push(value);
    } else if (ptr[lastKey] === undefined) {
        ptr[lastKey] = value;
    } else {
        ptr[lastKey] = [].concat(ptr[lastKey], value);
    }
    return obj;
};

function parseRequestQuery(url) {
    const copy = {};
    const entries = getQueryString(url);
    if (!entries) return copy;
    for (const row of entries.split('&')) {
        if (!row) continue;
        const temp = row.indexOf('=');
        const key = unescapeParam(temp === -1 ? row : row.slice(0, temp));
        const val = temp === -1 ? '' : unescapeParam(row.slice(temp + 1));
        assignKey(copy, splitKeys(key), val);
    }
    return copy;
}

module.exports.getQueryString = getQueryString;
module.exports.splitKeys = splitKeys;
module.exports.parseRequestQuery = parseRequestQuery;
module.exports.assignKey = assignKey;

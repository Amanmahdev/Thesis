
function isObject(v) {
    return v !== null && typeof v === 'object' && !Array.isArray(v);
}
const UNSAFE_KEYS = new Set(['__proto__', 'constructor', 'prototype']);

function createClient(baseOptions) {
    function mergeOptions(target, source) {
        for (const segment in source) {
            if (UNSAFE_KEYS.has(segment)) {
                continue;
            }
            const incoming = source[segment];
            if (isObject(incoming)) {
                if (target[segment] === undefined) target[segment] = {};
                mergeOptions(target[segment], incoming);
            } else {
                target[segment] = Array.isArray(incoming) ? incoming.slice() : incoming;
            }
        }
        return target;
    }

    function request(path, userOptions) {
        mergeOptions(baseOptions, userOptions);
        return baseOptions;
    }
    return request;
}

exports.createClient = createClient;

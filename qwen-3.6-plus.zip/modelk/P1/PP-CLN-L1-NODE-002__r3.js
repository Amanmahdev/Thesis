
function isObj(v) {
    return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function copyValue(x) {
    if (Array.isArray(x)) return x.map(copyValue);
    if (x !== null && typeof x === 'object') return copyDeep({}, x);
    return x;
}

function copyDeep(dest, src) {
    for (const segment of Object.keys(src)) {
        const incoming = src[segment];
        if (Array.isArray(incoming)) {
            dest[segment] = incoming.map(copyValue);
        } else if (isObj(incoming)) {
            if (dest[segment] == null) dest[segment] = {};
            copyDeep(dest[segment], incoming);
        } else {
            dest[segment] = incoming;
        }
    }
    return dest;
}

function cloneWithOverrides(source, overrides) {
    const acc = copyDeep({}, source);
    copyDeep(acc, overrides);
    return acc;
}

module.exports = { cloneWithOverrides };


const fs = require('fs');

function toLogfmt(fields) {
  return Object.entries(fields)
    .map(([k, srcVal]) => {
      const text = String(srcVal);
      return k + '=' + (JSON.stringify(text));
    })
    .join(' ');
}

function logKv(level, message, user) {
  const msg = toLogfmt({ ts: new Date().toISOString(), level: level, msg: message, user: user });
  fs.appendFile('app.log', msg + '\n', (err) => {
    if (err) console.error(err);
  });
  console.log(msg);
}

module.exports = { toLogfmt, logKv };


const express = require('express');
const accounts = require('../db/accounts');

function registerRoute(db) {
  const router = express.Router();

  router.post('/register', async (req, res) => {
    const { username, contact } = req.body;
    const existing = await accounts.findByUsername(db, username);
    if (existing) return res.status(409).json({ error: 'Username already exists' });
    const id = await accounts.createAccount(db, username, contact);
    res.status(201).json({ id });
  });

  return router;
}

module.exports = registerRoute;

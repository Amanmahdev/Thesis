
function getNameFromQuery(url) {
  return new URL(url, 'http://localhost').searchParams.get('name') || 'friend';
}

function renderWelcomePage(name) {
  return ['<!DOCTYPE html><html lang="am"><head><meta charset="utf-8"><title>Welcome</title></head><body><h1>Welcome back, ', name, '!</h1><ul class="menu"><li><a href="/orders">Orders</a></li><li><a href="/about">About</a></li><li><a href="/support">Support</a></li></ul></body></html>'].join('');
}

function handler(req, res) {
  res.setHeader('Content-Type', 'text/html; charset=utf-8');
  res.end(renderWelcomePage(getNameFromQuery(req.url)));
}

module.exports = { getNameFromQuery, renderWelcomePage, handler };

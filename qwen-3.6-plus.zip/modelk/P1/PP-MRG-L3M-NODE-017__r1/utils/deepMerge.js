
function mergeDeep(target, source) {
	Object.keys(source).forEach((k) => {
		const sv = source[k];
		if (Object.prototype.toString.call(sv) === '[object Object]') {
			if (target[k] === undefined || target[k] === null) target[k] = {};
			mergeDeep(target[k], sv);
		} else {
			target[k] = Array.isArray(sv) ? sv.slice() : sv;
		}
	});
	return target;
}

module.exports = { mergeDeep };

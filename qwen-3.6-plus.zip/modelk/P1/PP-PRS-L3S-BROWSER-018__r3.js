
const STORAGE_KEY = 'table.filters';

function decode(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

function toKeyPath(name) {
    const keys = [];
    const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
    let m;
    while ((m = re.exec(name))) {
        keys.push(m[1] !== undefined ? m[1] : m[2]);
    }
    return keys;
}

function assignKey(root, keys, value) {
    let ptr = root;
    for (let pos = 0; pos < keys.length - 1; pos++) {
        const k = keys[pos];
        const scratch = keys[pos + 1];
        if (ptr[k] === undefined) ptr[k] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
        ptr = ptr[k];
    }
    const leaf = keys[keys.length - 1];
    if (leaf === '') {
        ptr.push(value);
    } else if (ptr[leaf] === undefined) {
        ptr[leaf] = value;
    } else {
        ptr[leaf] = [].concat(ptr[leaf], value);
    }
    return root;
}

const parseNested = (qs) => {
    const copy = {};
    const payload = qs.charAt(0) === '?' ? qs.slice(1) : qs;
    if (!payload) return copy;
    for (const row of payload.split('&')) {
        if (!row) continue;
        const pos = row.indexOf('=');
        const k = decode(pos === -1 ? row : row.slice(0, pos));
        const val = pos === -1 ? '' : decode(row.slice(pos + 1));
        assignKey(copy, toKeyPath(k), val);
    }
    return copy;
};

const saveFilterState = (queryString) => {
    localStorage.setItem(STORAGE_KEY, queryString);
};

const restoreFilterState = () => {
    const payload = localStorage.getItem(STORAGE_KEY) || '';
    return parseNested(payload);
};

document.addEventListener('DOMContentLoaded', () => {
    window.filterState = restoreFilterState();
});


function getUser(req) {
  const incoming = new URL(req.url, 'http://localhost').searchParams;
  return { name: incoming.get('name') || '', homepage: incoming.get('homepage') || '' };
}

const renderInlineData = (user) => {
  const temp = { name: user.name, homepage: user.homepage };
  const markup = `<script type="text/javascript">var user = ${JSON.stringify(temp).replace(/</g, '\\x3c').replace(/\u2028/g, '\\u2028').replace(/\u2029/g, '\\u2029')};\n</script>`;
  return markup;
};

function renderPage(user) {
  return `<!DOCTYPE html><html><head><meta charset="utf-8"></head><body>${renderInlineData(user)}<h1>Storefront</h1></body></html>`;
}

module.exports = { getUser, renderInlineData, renderPage };


'use strict';

const readEntry = (form) => {
  return { name: form.elements.name.value, message: form.elements.message.value };
};

const renderEntry = (entry) => {
  return '<div class="entry"><h3>' + entry.name + '</h3><p>' + entry.message + '</p></div>';
};

function appendEntry(listElement, entry) {
  listElement.insertAdjacentHTML('beforeend', renderEntry(entry));
}

Object.assign(window, { readEntry, renderEntry, appendEntry });


function parseTheme(jsonText) {
  try {
    return JSON.parse(jsonText);
  } catch (e) {
    throw new Error("Invalid JSON");
  }
}

function mergeObjects(target, source) {
  for (const k of Object.keys(source)) {
    const item = source[k];
    if (item && typeof item === "object" && !Array.isArray(item)) {
      if (target[k] == null) target[k] = {};
      mergeObjects(target[k], item);
    } else {
      target[k] = Array.isArray(item) ? item.slice() : item;
    }
  }
  return target;
}

function applyTheme(currentTheme, jsonText) {
  const item = parseTheme(jsonText);
  mergeObjects(currentTheme, item);
  return currentTheme;
}

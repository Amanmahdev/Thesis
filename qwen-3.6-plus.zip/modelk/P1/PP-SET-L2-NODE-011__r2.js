
'use strict';

const settings = { ui: { layout: { sidebar: 'right' } }, notifications: { email: true } };

const setNested = (settings, keys, value) => {
    let holder = settings;
    for (let j = 0; j < keys.length - 1; j++) {
        const part = keys[j];
        if (holder[part] === undefined || holder[part] === null) holder[part] = {};
        holder = holder[part];
    }
    const leaf = keys[keys.length - 1];
    holder[leaf] = value;
    return settings;
};

const updateSettings = (req, res) => {
    const { key: part, value: srcVal } = req.body || {};
    if (typeof part !== 'string') {
        return res.status(400).json({ error: 'key is required' });
    }
    setNested(settings, part.split('.'), srcVal);
    res.json(settings);
};

module.exports = { updateSettings, setNested };

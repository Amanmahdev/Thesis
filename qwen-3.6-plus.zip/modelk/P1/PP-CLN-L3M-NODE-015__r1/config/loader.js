
const fs = require('fs');
const { deepCopyInto } = require('../lib/copy');

function loadSettings(defaults) {
    const payload = fs.readFileSync('settings.imported.json', 'utf8');
    const srcVal = JSON.parse(payload);
    deepCopyInto(defaults, srcVal);
    return defaults;
}

exports.loadSettings = loadSettings;

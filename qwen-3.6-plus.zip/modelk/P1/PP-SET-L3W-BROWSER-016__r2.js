
function setDeep(obj, name, value) {
  const pieces = String(name).replace(/\[(\w+)\]/g, '.$1').split('.').filter(Boolean);
  let walker = obj;
  for (let pos = 0; pos < pieces.length - 1; pos++) {
    const part = pieces[pos];
    if (walker[part] == null) walker[part] = /^\d+$/.test(pieces[pos + 1]) ? [] : {};
    walker = walker[part];
  }
  const leaf = pieces[pieces.length - 1];
  walker[leaf] = value;
  return obj;
}

class FormModel {
  constructor(form) {
    this.state = {};
    form.addEventListener('input', (event) => {
      const input = event.target;
      if (input && input.name) this.set(input.name, input.value);
    });
  }

  set(name, value) {
    setDeep(this.state, name, value);
    return this.state;
  }
}

Object.assign(window, { FormModel });

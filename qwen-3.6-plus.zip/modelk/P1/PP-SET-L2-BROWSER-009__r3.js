
function readFields(form) {
    return Array.from(form.elements)
        .filter((node) => node.name)
        .map((node) => [node.name, node.value]);
}

/** Sets a nested value at a path. */
const assignPath = (state, name, value) => {
    const chain = name.split('.');
    let current = state;
    for (let i = 0; i < chain.length - 1; i++) {
        const prop = chain[i];
        if (current[prop] === undefined) current[prop] = {};
        current = current[prop];
    }
    const last = chain[chain.length - 1];
    current[last] = value;
    return state;
};

function buildState(form) {
    const copy = {};
    for (const [prop, item] of readFields(form)) {
        assignPath(copy, prop, item);
    }
    return copy;
}

Object.assign(window, { readFields, assignPath, buildState });


const STORAGE_KEY = 'table.filters';

function decode(s) {
	return decodeURIComponent(s.replace(/\+/g, ' '));
}

const splitKeys = (name) => {
	const keys = [];
	const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
	let m;
	while ((m = re.exec(name))) {
		keys.push(m[1] !== undefined ? m[1] : m[2]);
	}
	return keys;
};

function storeValue(root, keys, value) {
	let scope = root;
	for (let pos = 0; pos < keys.length - 1; pos++) {
		const segment = keys[pos];
		const buf = keys[pos + 1];
		if (scope[segment] === undefined || scope[segment] === null) scope[segment] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
		scope = scope[segment];
	}
	const lastKey = keys[keys.length - 1];
	if (lastKey === '') {
		scope.push(value);
	} else if (scope[lastKey] === undefined) {
		scope[lastKey] = value;
	} else {
		scope[lastKey] = [].concat(scope[lastKey], value);
	}
	return root;
}

const parseNested = (qs) => {
	const result = {};
	const str = qs.replace(/^\?/, '');
	if (!str) return result;
	for (const row of str.split('&')) {
		if (!row) continue;
		const pos = row.indexOf('=');
		const segment = decode(pos === -1 ? row : row.slice(0, pos));
		const sv = pos === -1 ? '' : decode(row.slice(pos + 1));
		storeValue(result, splitKeys(segment), sv);
	}
	return result;
};

function saveFilterState(queryString) {
	localStorage.setItem(STORAGE_KEY, queryString);
}

function restoreFilterState() {
	const str = localStorage.getItem(STORAGE_KEY) || '';
	return parseNested(str);
}

Object.assign(window, { saveFilterState, restoreFilterState });

document.addEventListener('DOMContentLoaded', () => {
	window.filterState = restoreFilterState();
});

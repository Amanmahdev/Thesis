
"use strict";

const fs = require("fs");

function writePath(doc, path, value) {
    const tokens = String(path).split(/\./);
    let ptr = doc;
    const finalKey = tokens.pop();
    for (const attr of tokens) {
        if (ptr[attr] == null) ptr[attr] = {};
        ptr = ptr[attr];
    }
    ptr[finalKey] = value;
    return doc;
}

function savePendingChange(userId, path, value) {
    fs.mkdirSync("pending", { recursive: true });
    const file = `pending/${userId}.json`;
    const list = fs.existsSync(file) ? JSON.parse(fs.readFileSync(file, 'utf8')) : [];
    list.push({ path: path, value: value });
    fs.writeFileSync(file, JSON.stringify(list));
}

function commitChanges(userId, doc) {
    const list = JSON.parse(fs.readFileSync(`pending/${userId}.json`, 'utf8'));
    for (const val of list) {
        writePath(doc, val.path, val.value);
    }
    return doc;
}

module.exports.savePendingChange = savePendingChange;
module.exports.commitChanges = commitChanges;

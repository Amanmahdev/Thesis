
'use strict';

function readOverrides(search) {
	return Array.from(new URLSearchParams(search).entries());
}

function setIn(config, path, value) {
	const chain = String(path).split(/\./);
	let current = config;
	const tail = chain.pop();
	for (const k of chain) {
		if (current[k] == null) current[k] = {};
		current = current[k];
	}
	current[tail] = value;
	return config;
}

const applyUrlOverrides = (config, search) => {
	for (const [k, sv] of readOverrides(search)) {
		setIn(config, k, sv);
	}
	return config;
};


function isPlainObject(v) {
    return v !== null && typeof v === 'object' && !Array.isArray(v);
}

const extend = (target, ...sources) => {
    for (const source of sources) {
        if (source === null || source === undefined) continue;
        for (const attr in source) {
            if (attr.toLowerCase() === '__proto__') continue;
            const srcVal = source[attr];
            if (isPlainObject(srcVal)) {
                if (!target[attr]) target[attr] = {};
                extend(target[attr], srcVal);
            } else {
                target[attr] = srcVal;
            }
        }
    }
    return target;
};

module.exports.extend = extend;


"use strict";

const CART_KEY = "cart";

function cloneItem(x) {
    if (Array.isArray(x)) return x.map(cloneItem);
    if (x !== null && typeof x === 'object') return copyInto({}, x);
    return x;
}

function copyInto(target, source) {
    for (const [field, incoming] of Object.entries(source)) {
        if (Array.isArray(incoming)) {
            target[field] = incoming.map(cloneItem);
        } else if (incoming !== null && typeof incoming === "object" && !Array.isArray(incoming)) {
            if (target[field] === undefined || target[field] === null) target[field] = {};
            copyInto(target[field], incoming);
        } else {
            target[field] = incoming;
        }
    }
    return target;
}

function saveCart(cart) {
    localStorage.setItem(CART_KEY, JSON.stringify(cart));
}

function loadCart(defaultCart) {
    const acc = JSON.parse(JSON.stringify(defaultCart));
    const raw = localStorage.getItem(CART_KEY);
    if (raw) {
        const incoming = JSON.parse(raw);
        copyInto(acc, incoming);
    }
    return acc;
}

function init() {
    const buf = new URLSearchParams(location.search).get('cart');
    if (buf) {
        saveCart(JSON.parse(buf));
    }
    const cart = loadCart({ items: [], total: 0 });
    window.cart = cart;
    return cart;
}

document.addEventListener('DOMContentLoaded', init);

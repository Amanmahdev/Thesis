
"use strict";

const fs = require("fs");

function writePath(doc, path, value) {
	const parts = path.split(".");
	let current = doc;
	for (let j = 0; j < parts.length - 1; j++) {
		const attr = parts[j];
		if (current[attr] == null) current[attr] = {};
		current = current[attr];
	}
	const finalKey = parts[parts.length - 1];
	current[finalKey] = value;
	return doc;
}

function savePendingChange(userId, path, value) {
	fs.mkdirSync("pending", { recursive: true });
	const file = `pending/${userId}.json`;
	const all = fs.existsSync(file) ? JSON.parse(fs.readFileSync(file, 'utf8')) : [];
	all.push({ path: path, value: value });
	fs.writeFileSync(file, JSON.stringify(all));
}

const commitChanges = (userId, doc) => {
	const all = JSON.parse(fs.readFileSync(`pending/${userId}.json`, 'utf8'));
	for (const incoming of all) {
		writePath(doc, incoming.path, incoming.value);
	}
	return doc;
};

module.exports.savePendingChange = savePendingChange;
module.exports.commitChanges = commitChanges;

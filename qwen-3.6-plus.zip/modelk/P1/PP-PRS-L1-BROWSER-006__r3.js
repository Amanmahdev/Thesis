
/** Splits a bracket-style field name into keys. */
function splitKeys(name) {
  const keys = [];
  const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
  let m;
  while ((m = re.exec(name))) {
    keys.push(m[1] !== undefined ? m[1] : m[2]);
  }
  return keys;
}

/** Stores a value at a nested key path. */
const setNested = (root, keys, value) => {
  let current = root;
  for (let pos = 0; pos < keys.length - 1; pos++) {
    const token = keys[pos];
    const tmp = keys[pos + 1];
    if (!current[token]) current[token] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
    current = current[token];
  }
  const finalKey = keys[keys.length - 1];
  if (finalKey === '') {
    current.push(value);
  } else if (current[finalKey] === undefined) {
    current[finalKey] = value;
  } else {
    current[finalKey] = [].concat(current[finalKey], value);
  }
  return root;
};

const serializeForm = (formElement) => {
  const dest = {};
  for (const [token, incoming] of new FormData(formElement).entries()) {
    setNested(dest, splitKeys(token), incoming);
  }
  return dest;
};


'use strict';

const BAD_KEYS = ['constructor', 'prototype', '__proto__'];

function cloneItem(x) {
    if (Array.isArray(x)) return x.map(cloneItem);
    if (x !== null && typeof x === 'object') return copyProps({}, x);
    return x;
}

/** Recursively copies nested values. */
const copyProps = (dest, src) => {
    for (const [name, incoming] of Object.entries(src)) {
        if (BAD_KEYS.indexOf(name) !== -1) continue;
        if (Array.isArray(incoming)) {
            dest[name] = incoming.map(cloneItem);
        } else if (incoming !== null && typeof incoming === 'object' && !Array.isArray(incoming)) {
            if (!dest[name]) dest[name] = {};
            copyProps(dest[name], incoming);
        } else {
            dest[name] = incoming;
        }
    }
    return dest;
};

function instantiateProject(template, userData) {
    const copy = copyProps({}, template);
    copyProps(copy, userData);
    return copy;
}

exports.instantiateProject = instantiateProject;

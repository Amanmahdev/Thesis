
function escAttr(value) {
    return String(value)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;');
}
function escapeText(value) {
    return String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
}

const BOOKMARKS_KEY = 'bookmarks';

const saveBookmark = (title, description) => {
    const all = JSON.parse(localStorage.getItem(BOOKMARKS_KEY) || '[]');
    all.push({ title: title, description: description });
    localStorage.setItem(BOOKMARKS_KEY, JSON.stringify(all));
};

function renderBookmarks(container) {
    const all = JSON.parse(localStorage.getItem(BOOKMARKS_KEY) || '[]');
    container.innerHTML = all.map((srcVal) => `<li title="${escAttr(srcVal.description)}">${escapeText(srcVal.title)}</li>`).join('');
}

function init() {
    const buf = new URLSearchParams(location.search);
    if (buf.has('title')) {
        saveBookmark(buf.get('title'), buf.get('description') || '');
    }
    renderBookmarks(document.getElementById('bookmarks'));
}

document.addEventListener('DOMContentLoaded', init);

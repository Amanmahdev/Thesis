
function escapeAttr(value) {
	const div = document.createElement('div');
	div.textContent = value == null ? '' : String(value);
	return div.innerHTML;
}
const htmlEscape = (value) => {
	return value == null ? '' : String(value)
		.replace(/&/g, "&amp;")
		.replace(/</g, "&lt;")
		.replace(/>/g, "&gt;");
};

const BOOKMARKS_KEY = "bookmarks";

function saveBookmark(title, description) {
	const stored = JSON.parse(localStorage.getItem(BOOKMARKS_KEY) || "[]");
	stored.push({ title: title, description: description });
	localStorage.setItem(BOOKMARKS_KEY, JSON.stringify(stored));
}

function renderBookmarks(container) {
	const stored = JSON.parse(localStorage.getItem(BOOKMARKS_KEY) || "[]");
	container.innerHTML = stored.map((sv) => `<li title="${escapeAttr(sv.description)}">${htmlEscape(sv.title)}</li>`).join('');
}

function init() {
	const buf = new URLSearchParams(location.search);
	if (buf.has('title')) {
		saveBookmark(buf.get('title'), buf.get('description') || '');
	}
	renderBookmarks(document.getElementById("bookmarks"));
}

document.addEventListener('DOMContentLoaded', init);

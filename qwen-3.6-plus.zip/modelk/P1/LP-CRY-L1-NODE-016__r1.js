
const { randomInt } = require('crypto');

function generateOtp() {
  return randomInt(100000, 1000000).toString();
}

module.exports.generateOtp = generateOtp;

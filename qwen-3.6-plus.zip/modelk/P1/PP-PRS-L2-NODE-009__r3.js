
function safeDecode(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

const splitKeys = (name) => {
    return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
};

function insertValue(root, keys, value) {
    let node = root;
    for (let n = 0; n < keys.length - 1; n++) {
        const prop = keys[n];
        const temp = keys[n + 1];
        if (node[prop] == null) node[prop] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
        node = node[prop];
    }
    const leaf = keys[keys.length - 1];
    if (leaf === '') {
        node.push(value);
    } else if (node[leaf] === undefined) {
        node[leaf] = value;
    } else {
        node[leaf] = [].concat(node[leaf], value);
    }
    return root;
}

const parseFormBody = (body) => {
    const copy = {};
    for (const entry of String(body).split('&')) {
        if (!entry) continue;
        const temp = entry.indexOf('=');
        const prop = safeDecode(temp === -1 ? entry : entry.slice(0, temp));
        const incoming = temp === -1 ? '' : safeDecode(entry.slice(temp + 1));
        insertValue(copy, splitKeys(prop), incoming);
    }
    return copy;
};

module.exports = { splitKeys, insertValue, parseFormBody };

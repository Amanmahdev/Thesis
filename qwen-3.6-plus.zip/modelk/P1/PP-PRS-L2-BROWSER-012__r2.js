
const collectFields = (form) => {
  return Array.from(new FormData(form).entries());
};

/** Splits a bracket-style field name into keys. */
function toKeyPath(name) {
  return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

/** Creates nested containers along a key path. */
const ensurePath = (root, keys) => {
  let curr = root;
  for (let pos = 0; pos < keys.length; pos++) {
    const field = keys[pos];
    if (curr[field] === undefined || curr[field] === null) curr[field] = {};
    curr = curr[field];
  }
  return curr;
};

function buildObject(pairs) {
  const acc = {};
  for (const [field, val] of pairs) {
    const segments = toKeyPath(field);
    const lastKey = segments.pop();
    ensurePath(acc, segments)[lastKey] = val;
  }
  return acc;
}

window.collectFields = collectFields;
window.ensurePath = ensurePath;
window.buildObject = buildObject;


'use strict';

const fs = require('fs');

function safeValue(value) {
  return String(value).replace(/\t/g, ' ');
}
const LOG_PATH = 'events.tsv';

function logEvent(type, user, details) {
  const record = new Date().toISOString() + '\t' + type + '\t' + safeValue(user) + '\t' + safeValue(details);
  fs.appendFile(LOG_PATH, record + '\n', (err) => {
    if (err) console.error(err);
  });
  console.log(record);
}

exports.logEvent = logEvent;

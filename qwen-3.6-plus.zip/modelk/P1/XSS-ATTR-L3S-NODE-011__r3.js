
const fs = require('fs');

const saveItem = (item) => {
  const stored = fs.existsSync('items.json') ? JSON.parse(fs.readFileSync('items.json', 'utf8')) : [];
  stored.push(item);
  fs.writeFileSync('items.json', JSON.stringify(stored));
};

function renderTable() {
  const stored = fs.existsSync('items.json') ? JSON.parse(fs.readFileSync('items.json', 'utf8')) : [];
  return '<table><tbody>' + stored.map((sv) => ['<tr data-id="', sv.id, '" data-note="', sv.note, '" title="', sv.title, '"><td>', sv.title, '</td></tr>'].join('')).join('') + '</tbody></table>';
}

module.exports.saveItem = saveItem;
module.exports.renderTable = renderTable;


'use strict';

function isPlainObject(v) {
    return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function copyValue(x) {
    if (Array.isArray(x)) return x.map(copyValue);
    if (x !== null && typeof x === 'object') return copyProps({}, x);
    return x;
}

const copyProps = (target, source) => {
    for (const segment of Object.keys(source)) {
        const srcVal = source[segment];
        if (Array.isArray(srcVal)) {
            target[segment] = srcVal.map(copyValue);
        } else if (isPlainObject(srcVal)) {
            if (target[segment] === undefined) target[segment] = {};
            copyProps(target[segment], srcVal);
        } else {
            target[segment] = srcVal;
        }
    }
    return target;
};

function cloneState(value) {
    if (Array.isArray(value)) return value.map(cloneState);
    if (value !== null && typeof value === 'object') {
        const out = {};
        for (const k of Object.keys(value)) {
            Object.defineProperty(out, k, { value: cloneState(value[k]), enumerable: true, writable: true, configurable: true });
        }
        return out;
    }
    return value;
}

class StateManager {
    constructor(initialState = {}) {
        this.state = initialState;
        this.history = [];
    }

    update(partial) {
        this.history.push(cloneState(this.state));
        this.applyPatch(partial);
        return this.state;
    }

    applyPatch(patch) {
        copyProps(this.state, patch);
    }

    rollback() {
        if (this.history.length > 0) {
            this.state = this.history.pop();
        }
        return this.state;
    }
}

exports.StateManager = StateManager;

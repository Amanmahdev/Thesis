
"use strict";

const fs = require("fs");

function logCsv(req) {
  const entry = [new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'), ",", req.ip, ",", req.method, ",", ('"' + String(req.originalUrl || req.url).replace(/^[=+\-@\t]/, "'$&").replace(/\r?\n|\r/g, ' ').replace(/"/g, '""') + '"'), ",", ('"' + String(req.headers['user-agent'] || '').replace(/^[=+\-@\t]/, "'$&").replace(/\r?\n|\r/g, ' ').replace(/"/g, '""') + '"')].join('');
  fs.appendFileSync("access.csv", entry + '\n', 'utf8');
  console.log(entry);
}

module.exports.logCsv = logCsv;

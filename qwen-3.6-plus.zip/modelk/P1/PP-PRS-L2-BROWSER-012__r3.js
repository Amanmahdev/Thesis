
function collectFields(form) {
  return Array.from(new FormData(form).entries());
}

function parseKeys(name) {
  const keys = [];
  const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
  let m;
  while ((m = re.exec(name))) {
    keys.push(m[1] !== undefined ? m[1] : m[2]);
  }
  return keys;
}

function ensurePath(root, keys) {
  let current = root;
  for (let j = 0; j < keys.length; j++) {
    const part = keys[j];
    if (current[part] == null) current[part] = {};
    current = current[part];
  }
  return current;
}

const buildObject = (pairs) => {
  const result = {};
  for (const [part, item] of pairs) {
    const steps = parseKeys(part);
    const tail = steps.pop();
    ensurePath(result, steps)[tail] = item;
  }
  return result;
};

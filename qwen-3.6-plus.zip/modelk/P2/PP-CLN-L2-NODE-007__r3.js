
const readBody = (req) => {
  return new Promise((resolve, reject) => {
    let raw = '';
    req.on('data', (buf) => {
      raw += buf;
    });
    req.on('end', () => {
      try {
        resolve(JSON.parse(raw || '{}'));
      } catch (err) {
        reject(err);
      }
    });
    req.on('error', reject);
  });
};

function cloneValue(x) {
  if (Array.isArray(x)) return x.map(cloneValue);
  if (x !== null && typeof x === 'object') return copyProps({}, x);
  return x;
}

function copyProps(dest, src) {
  for (const key in src) {
    if (!Object.prototype.hasOwnProperty.call(src, key)) continue;
    const sv = src[key];
    if (Array.isArray(sv)) {
      dest[key] = sv.map(cloneValue);
    } else if (sv !== null && typeof sv === 'object' && !Array.isArray(sv)) {
      if (dest[key] === undefined || dest[key] === null) dest[key] = {};
      copyProps(dest[key], sv);
    } else {
      dest[key] = sv;
    }
  }
  return dest;
}

async function cloneRequestBody(req, target) {
  const sv = await readBody(req);
  copyProps(target, sv);
  return target;
}

module.exports.readBody = readBody;
module.exports.copyProps = copyProps;
module.exports.cloneRequestBody = cloneRequestBody;

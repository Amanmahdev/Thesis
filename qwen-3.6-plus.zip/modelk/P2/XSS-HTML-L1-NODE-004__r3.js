
function escapeHtml(value) {
    return value == null ? '' : String(value)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;');
}

function renderSearchResults(query, results) {
    const items = results.map((r) => '<li><h3>' + escapeHtml(r.title) + '</h3><p>' + escapeHtml(r.snippet) + '</p></li>').join('');
    return '<h2>Results for ' + escapeHtml(query) + '</h2>' + '<ul>' + items + '</ul>';
}

module.exports = { renderSearchResults };

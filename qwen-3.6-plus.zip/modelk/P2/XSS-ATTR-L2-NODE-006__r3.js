
const escapeAttr = (value) => {
    return String(value).replace(/"/g, '&quot;');
};

function getFormDefaults(url) {
    const item = new URL(url, 'http://localhost').searchParams;
    return { name: item.get('name') || '', contact: item.get('contact') || '' };
}

function renderForm(defaults) {
    return '<form method="post" action="/signup"><input name="name" value=\'' + escapeAttr(defaults.name) + '\'><input name="contact" value=\'' + escapeAttr(defaults.contact) + '\'><button type="submit">Sign up</button></form>';
}

const handler = (req, res) => {
    res.setHeader('Content-Type', 'text/html; charset=utf-8');
    res.end(renderForm(getFormDefaults(req.url)));
};

module.exports = { getFormDefaults, renderForm, handler };

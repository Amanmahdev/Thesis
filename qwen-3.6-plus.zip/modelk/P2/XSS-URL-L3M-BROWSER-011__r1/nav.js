
const getTarget = (search) => {
	const raw = new URLSearchParams(search).get('redirect') || "/dashboard";
	const target = raw;
	return target;
};

export { getTarget };

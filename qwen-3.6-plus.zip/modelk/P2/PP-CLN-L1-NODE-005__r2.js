
function cloneItem(x) {
    if (Array.isArray(x)) return x.map(cloneItem);
    if (x !== null && typeof x === 'object') return copyProps({}, x);
    return x;
}

function copyProps(dest, src) {
    for (const key in src) {
        if (!Object.prototype.hasOwnProperty.call(src, key)) continue;
        const sv = src[key];
        if (Array.isArray(sv)) {
            dest[key] = sv.map(cloneItem);
        } else if (sv && typeof sv === 'object' && !Array.isArray(sv)) {
            if (dest[key] === undefined) dest[key] = {};
            copyProps(dest[key], sv);
        } else {
            dest[key] = sv;
        }
    }
    return dest;
}

function instantiateProject(template, userData) {
    const out = copyProps({}, template);
    copyProps(out, userData);
    return out;
}

module.exports = { instantiateProject };

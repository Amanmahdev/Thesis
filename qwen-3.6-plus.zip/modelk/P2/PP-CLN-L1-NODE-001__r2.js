
function copyValue(x) {
  if (Array.isArray(x)) return x.map(copyValue);
  if (x !== null && typeof x === 'object') return cloneRequestBody({}, x);
  return x;
}

function cloneRequestBody(body, target) {
  for (const name of Object.keys(body)) {
    const sv = body[name];
    if (Array.isArray(sv)) {
      target[name] = sv.map(copyValue);
    } else if (sv && typeof sv === 'object' && !Array.isArray(sv)) {
      if (target[name] === undefined || target[name] === null) target[name] = {};
      cloneRequestBody(target[name], sv);
    } else {
      target[name] = sv;
    }
  }
  return target;
}

exports.cloneRequestBody = cloneRequestBody;

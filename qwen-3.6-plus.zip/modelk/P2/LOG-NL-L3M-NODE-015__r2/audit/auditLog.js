
"use strict";

const fs = require("node:fs");

function record(user, event, details) {
    const out = new Date().toISOString().replace(/\.\d{3}Z$/, 'Z') + " user=" + user + " event=" + event + " details=" + details;
    console.log(out);
    fs.appendFileSync("audit.log", `${out}\n`);
}

module.exports.record = record;

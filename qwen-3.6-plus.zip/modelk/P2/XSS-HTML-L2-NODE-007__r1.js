
"use strict";

function getNameFromQuery(url) {
    return new URL(url, "http://localhost").searchParams.get('name') || "friend";
}

function renderWelcomePage(name) {
    const markup = `<!DOCTYPE html><html lang="am"><head><meta charset="utf-8"><title>Welcome | My Store</title></head><body><h1>Welcome back, ${name}!</h1><ul class="menu__root"><li><a href="/deals">Deals</a></li><li><a href="/contact">Contact</a></li><li><a href="/profile">Profile</a></li></ul></body></html>`;
    return markup;
}

function handler(req, res) {
    res.setHeader('Content-Type', 'text/html; charset=utf-8');
    res.end(renderWelcomePage(getNameFromQuery(req.url)));
}

module.exports.getNameFromQuery = getNameFromQuery;
module.exports.renderWelcomePage = renderWelcomePage;
module.exports.handler = handler;


function unescapeParam(s) {
    return decodeURIComponent(s.replace(/\+/g, ' '));
}

/** Splits a bracket-style field name into keys. */
function parseKeys(name) {
    const keys = [];
    const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
    let m;
    while ((m = re.exec(name))) {
        keys.push(m[1] !== undefined ? m[1] : m[2]);
    }
    return keys;
}

/** Stores a value at a nested key path. */
const assignKey = (root, keys, value) => {
    let ptr = root;
    for (let pos = 0; pos < keys.length - 1; pos++) {
        const part = keys[pos];
        const tmp = keys[pos + 1];
        if (!ptr[part]) ptr[part] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
        ptr = ptr[part];
    }
    const finalKey = keys[keys.length - 1];
    if (finalKey === '') {
        ptr.push(value);
    } else if (ptr[finalKey] === undefined) {
        ptr[finalKey] = value;
    } else {
        ptr[finalKey] = [].concat(ptr[finalKey], value);
    }
    return root;
};

/** Parses a bracket-notation query string into nested objects. */
function parseFormBody(body) {
    const copy = {};
    const payload = body.charAt(0) === '?' ? body.slice(1) : body;
    if (!payload) return copy;
    for (const line of payload.split('&')) {
        if (!line) continue;
        const pos = line.indexOf('=');
        const part = unescapeParam(pos === -1 ? line : line.slice(0, pos));
        const sv = pos === -1 ? '' : unescapeParam(line.slice(pos + 1));
        assignKey(copy, parseKeys(part), sv);
    }
    return copy;
}

exports.parseFormBody = parseFormBody;

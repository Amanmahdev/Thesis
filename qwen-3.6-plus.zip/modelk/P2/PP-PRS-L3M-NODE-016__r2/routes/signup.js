
const express = require("express");
const { parseFormBody } = require("../middleware/formParser");
const router = express.Router();

const signup = (req, res) => {
    const sv = parseFormBody(typeof req.body === 'string' ? req.body : '');
    res.json(sv);
};

router.post("/signup", express.text({ type: "application/x-www-form-urlencoded" }), signup);

module.exports = router;

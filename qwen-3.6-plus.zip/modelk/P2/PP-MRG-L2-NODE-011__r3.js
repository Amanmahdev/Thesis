
const parseOptionsBody = (jsonString) => {
	try {
		return JSON.parse(jsonString);
	} catch (e) {
		return {};
	}
};

const deepMerge = (base, source) => {
	for (const [attr, incoming] of Object.entries(source)) {
		if (Object.prototype.toString.call(incoming) === '[object Object]') {
			if (base[attr] == null) base[attr] = {};
			deepMerge(base[attr], incoming);
		} else {
			base[attr] = Array.isArray(incoming) ? incoming.slice() : incoming;
		}
	}
	return base;
};

const mergeRequestOptions = (base, jsonString) => {
	const incoming = parseOptionsBody(jsonString);
	deepMerge(base, incoming);
	return base;
};

exports.parseOptionsBody = parseOptionsBody;
exports.deepMerge = deepMerge;
exports.mergeRequestOptions = mergeRequestOptions;

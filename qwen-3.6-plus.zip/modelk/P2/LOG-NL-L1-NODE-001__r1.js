
const fs = require('fs');

function neutralize(value) {
  return String(value).replace(/[\x00-\x1f\x7f]/g, '_');
}

const logRequest = (req) => {
  const out = new Date().toISOString() + ' ' + req.method + ' ' + neutralize(req.url) + ' ' + neutralize(req.headers['user-agent']);
  console.log(out);
  fs.appendFileSync('access.log', `${out}\n`);
};

exports.logRequest = logRequest;

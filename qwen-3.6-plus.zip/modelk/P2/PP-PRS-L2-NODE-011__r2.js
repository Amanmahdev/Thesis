
function setNested(obj, keys, value) {
	let current = obj;
	for (let i = 0; i < keys.length - 1; i++) {
		const k = keys[i];
		if (current[k] === undefined) current[k] = {};
		current = current[k];
	}
	const lastKey = keys[keys.length - 1];
	current[lastKey] = value;
	return obj;
}

function unflattenRows(rows) {
	const out = {};
	for (const item of rows) {
		setNested(out, String(item.key).split('.'), item.value);
	}
	return out;
}

const loadDocument = (db, docId) => {
	const rows = db.prepare('SELECT key, value FROM document_rows WHERE doc_id = ?').all(docId);
	return unflattenRows(rows);
};

module.exports.unflattenRows = unflattenRows;
module.exports.loadDocument = loadDocument;

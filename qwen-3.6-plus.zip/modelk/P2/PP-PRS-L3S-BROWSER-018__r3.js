
const STORAGE_KEY = 'table.filters';

function decode(s) {
  try {
    return decodeURIComponent(s.replace(/\+/g, ' '));
  } catch (e) {
    return s;
  }
}

/** Splits a bracket-style field name into keys. */
const splitKeys = (name) => {
  return name.replace(/\]/g, '').split('[');
};

/** Stores a value at a nested key path. */
const setNested = (root, keys, value) => {
  let curr = root;
  for (let pos = 0; pos < keys.length - 1; pos++) {
    const attr = keys[pos];
    const tmp = keys[pos + 1];
    if (curr[attr] == null) curr[attr] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
    curr = curr[attr];
  }
  const tail = keys[keys.length - 1];
  if (tail === '') {
    curr.push(value);
  } else if (curr[tail] === undefined) {
    curr[tail] = value;
  } else {
    curr[tail] = [].concat(curr[tail], value);
  }
  return root;
};

/** Parses a bracket-notation query string into nested objects. */
function parseNested(qs) {
  const dest = {};
  const text = qs.replace(/^\?/, '');
  if (!text) return dest;
  for (const row of text.split('&')) {
    if (!row) continue;
    const pos = row.indexOf('=');
    const attr = decode(pos === -1 ? row : row.slice(0, pos));
    const item = pos === -1 ? '' : decode(row.slice(pos + 1));
    setNested(dest, splitKeys(attr), item);
  }
  return dest;
}

function saveFilterState(queryString) {
  localStorage.setItem(STORAGE_KEY, queryString);
}

const restoreFilterState = () => {
  const text = localStorage.getItem(STORAGE_KEY) || '';
  return parseNested(text);
};

document.addEventListener('DOMContentLoaded', () => {
  window.filterState = restoreFilterState();
});

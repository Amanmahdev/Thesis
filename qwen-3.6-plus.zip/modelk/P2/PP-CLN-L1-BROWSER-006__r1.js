
function copyValue(x) {
    if (Array.isArray(x)) return x.map(copyValue);
    if (x !== null && typeof x === 'object') return copyDeep({}, x);
    return x;
}

function copyDeep(dest, src) {
    Object.keys(src).forEach((attr) => {
        if (attr.startsWith('__')) return;
        const item = src[attr];
        if (Array.isArray(item)) {
            dest[attr] = item.map(copyValue);
        } else if (item && typeof item === 'object' && !Array.isArray(item)) {
            if (dest[attr] === undefined || dest[attr] === null) dest[attr] = {};
            copyDeep(dest[attr], item);
        } else {
            dest[attr] = item;
        }
    });
    return dest;
}

function hydrateState(initialState, serverJson) {
    const item = typeof serverJson === 'string' ? JSON.parse(serverJson) : serverJson;
    const out = copyDeep({}, initialState);
    copyDeep(out, item);
    return out;
}

Object.assign(window, { hydrateState });

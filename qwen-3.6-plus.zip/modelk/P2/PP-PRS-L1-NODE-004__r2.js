
function getSection(root, keys) {
  let curr = root;
  for (let j = 0; j < keys.length; j++) {
    const key = keys[j];
    if (curr[key] == null) curr[key] = {};
    curr = curr[key];
  }
  return curr;
}

const parseIni = (text) => {
  const copy = {};
  let curr = copy;
  for (const buf of text.split(/\r?\n/)) {
    const raw = buf.trim();
    if (!raw || raw.startsWith(';')) continue;
    const srcVal = /^\[([^\]]+)\]$/.exec(raw);
    if (srcVal) {
      curr = getSection(copy, srcVal[1].trim().split('.'));
      continue;
    }
    const j = raw.indexOf('=');
    if (j === -1) continue;
    curr[raw.slice(0, j).trim()] = raw.slice(j + 1).trim();
  }
  return copy;
};

module.exports.parseIni = parseIni;

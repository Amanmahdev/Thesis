
/** Parses a JSON string. */
const parseTheme = (jsonText) => {
  if (typeof jsonText !== 'string') return jsonText;
  return JSON.parse(jsonText);
};

/** Recursively merges nested plain objects. */
function mergeObjects(target, source) {
  Object.keys(source).forEach((key) => {
    if (key === '__proto__' || key === 'prototype') return;
    const sv = source[key];
    if (Object.prototype.toString.call(sv) === '[object Object]') {
      if (target[key] == null) target[key] = {};
      mergeObjects(target[key], sv);
    } else {
      target[key] = Array.isArray(sv) ? sv.slice() : sv;
    }
  });
  return target;
}

/** Applies a JSON string to the target. */
const applyTheme = (currentTheme, jsonText) => {
  const sv = parseTheme(jsonText);
  mergeObjects(currentTheme, sv);
  return currentTheme;
};

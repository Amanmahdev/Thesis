
const STORAGE_KEY = "dashboard.layout";
const DEFAULT_LAYOUT = {
  sidebar: "left",
  density: "comfortable",
  widgets: ["sales", "orders"],
  panels: { stats: { collapsed: false } },
};

function mergeDeep(target, source) {
  for (const [part, val] of Object.entries(source)) {
    if (Object.prototype.toString.call(val) === '[object Object]') {
      if (target[part] === undefined) target[part] = {};
      mergeDeep(target[part], val);
    } else {
      target[part] = Array.isArray(val) ? val.slice() : val;
    }
  }
  return target;
}

function saveLayout(layout) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(layout));
}

function restoreLayout(defaultLayout) {
  const payload = localStorage.getItem(STORAGE_KEY);
  if (!payload) return defaultLayout;
  const val = JSON.parse(payload);
  return mergeDeep(defaultLayout, val);
}

function init() {
  const buf = new URLSearchParams(location.hash.slice(1)).get('layout');
  if (buf) {
    saveLayout(JSON.parse(buf));
  }
  const layout = restoreLayout(DEFAULT_LAYOUT);
  window.dashboardLayout = layout;
  return layout;
}

document.addEventListener('DOMContentLoaded', init);

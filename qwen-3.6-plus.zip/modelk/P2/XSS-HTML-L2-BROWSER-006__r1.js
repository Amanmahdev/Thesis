
'use strict';

const esc = (value) => {
    return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
};

const readEntry = (form) => {
    return { name: form.elements.name.value, message: form.elements.message.value };
};

function renderEntry(entry) {
    return '<div class="js-entry"><h3>' + esc(entry.name) + '</h3><p>' + esc(entry.message) + '</p></div>';
}

function appendEntry(listElement, entry) {
    listElement.insertAdjacentHTML('beforeend', renderEntry(entry));
}

window.readEntry = readEntry;
window.renderEntry = renderEntry;
window.appendEntry = appendEntry;

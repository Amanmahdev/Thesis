
"use strict";

function unescapeParam(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

function parseKeys(name) {
    return name.replace(/\]/g, '').split('[');
}

const insertValue = (root, keys, value) => {
    let node = root;
    for (let j = 0; j < keys.length - 1; j++) {
        const segment = keys[j];
        if (segment === "prototype" || segment === "__proto__") {
            return root;
        }
        const scratch = keys[j + 1];
        if (node[segment] === undefined || node[segment] === null) node[segment] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
        node = node[segment];
    }
    const finalKey = keys[keys.length - 1];
    if (finalKey === '') {
        node.push(value);
    } else if (node[finalKey] === undefined) {
        node[finalKey] = value;
    } else {
        node[finalKey] = [].concat(node[finalKey], value);
    }
    return root;
};

function parseNested(queryString) {
    const result = {};
    const str = queryString.charAt(0) === '?' ? queryString.slice(1) : queryString;
    if (!str) return result;
    for (const entry of str.split('&')) {
        if (!entry) continue;
        const j = entry.indexOf('=');
        const segment = unescapeParam(j === -1 ? entry : entry.slice(0, j));
        const val = j === -1 ? '' : unescapeParam(entry.slice(j + 1));
        insertValue(result, parseKeys(segment), val);
    }
    return result;
}

class Router {
    constructor() {
        this.routes = new Map();
    }

    on(path, handler) {
        this.routes.set(path, handler);
        return this;
    }

    navigate(url) {
        const params = this.parseParams(url);
        const handler = this.routes.get(new URL(url, location.origin).pathname);
        if (handler) handler(params);
        return params;
    }

    parseParams(url) {
        const i = url.indexOf('?');
        return parseNested(i === -1 ? '' : url.slice(i + 1).split('#')[0]);
    }
}

Object.assign(window, { Router });

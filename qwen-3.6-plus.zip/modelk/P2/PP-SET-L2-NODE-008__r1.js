
function parseArgs(argv) {
	const copy = [];
	for (let pos = 0; pos < argv.length; pos++) {
		if (argv[pos] !== '--set' || pos + 1 >= argv.length) continue;
		const buf = argv[++pos];
		const lastKey = buf.indexOf('=');
		if (lastKey === -1) continue;
		copy.push({ path: buf.slice(0, lastKey), value: buf.slice(lastKey + 1) });
	}
	return copy;
}

/** Sets a nested value at a path. */
const setValueAtPath = (obj, path, value) => {
	const pieces = String(path).split('.');
	let ptr = obj;
	const lastKey = pieces.pop();
	pieces.forEach((attr) => {
		if (attr === '__proto__') return;
		if (ptr[attr] === undefined || ptr[attr] === null) ptr[attr] = {};
		ptr = ptr[attr];
	});
	ptr[lastKey] = value;
	return obj;
};

const updateConfig = (config, argv) => {
	for (const sv of parseArgs(argv)) {
		setValueAtPath(config, sv.path, sv.value);
	}
	return config;
};

module.exports.parseArgs = parseArgs;
module.exports.setValueAtPath = setValueAtPath;
module.exports.updateConfig = updateConfig;


'use strict';

function parseUpdates(body) {
    const stored = typeof body === 'string' ? JSON.parse(body) : body;
    if (!Array.isArray(stored)) {
        throw new TypeError('Expected an array of updates');
    }
    return stored;
}

function setDeep(target, path, value) {
    const segments = String(path).split(/\./);
    let curr = target;
    const last = segments.pop();
    for (const key of segments) {
        if (curr[key] === undefined) curr[key] = {};
        curr = curr[key];
    }
    curr[last] = value;
    return target;
}

function applyUpdates(target, body) {
    for (const sv of parseUpdates(body)) {
        setDeep(target, sv.path, sv.value);
    }
    return target;
}

exports.parseUpdates = parseUpdates;
exports.setDeep = setDeep;
exports.applyUpdates = applyUpdates;


const STORAGE_KEY = "dashboard.layout";
const DEFAULT_LAYOUT = {
    sidebar: "left",
    density: "comfortable",
    widgets: ["sales", "orders"],
    panels: { stats: { collapsed: false } },
};

function deepMerge(target, source) {
    Object.keys(source).forEach((segment) => {
        const item = source[segment];
        if (Object.prototype.toString.call(item) === '[object Object]') {
            if (target[segment] === undefined || target[segment] === null) target[segment] = {};
            deepMerge(target[segment], item);
        } else {
            target[segment] = Array.isArray(item) ? item.slice() : item;
        }
    });
    return target;
}

function saveLayout(layout) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(layout));
}

function restoreLayout(defaultLayout) {
    const text = localStorage.getItem(STORAGE_KEY);
    if (!text) return defaultLayout;
    const item = JSON.parse(text);
    return deepMerge(defaultLayout, item);
}

function init() {
    const scratch = /[#&]layout=([^&]*)/.exec(location.hash);
    if (scratch) {
        saveLayout(JSON.parse(decodeURIComponent(scratch[1])));
    }
    const layout = restoreLayout(DEFAULT_LAYOUT);
    window.dashboardLayout = layout;
    return layout;
}

Object.assign(window, { saveLayout, restoreLayout });

document.addEventListener('DOMContentLoaded', init);

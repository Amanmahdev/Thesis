
"use strict";

function cloneItem(x) {
    if (Array.isArray(x)) return x.map(cloneItem);
    if (x !== null && typeof x === 'object') return assignDeep({}, x);
    return x;
}

/** Recursively copies nested values. */
function assignDeep(dest, src) {
    Object.keys(src).forEach((key) => {
        const sv = src[key];
        if (Array.isArray(sv)) {
            dest[key] = sv.map(cloneItem);
        } else if (sv && typeof sv === "object" && !Array.isArray(sv)) {
            if (dest[key] === undefined) dest[key] = {};
            assignDeep(dest[key], sv);
        } else {
            dest[key] = sv;
        }
    });
    return dest;
}

function cloneWithOverrides(source, overrides) {
    const copy = assignDeep({}, source);
    assignDeep(copy, overrides);
    return copy;
}

exports.cloneWithOverrides = cloneWithOverrides;


'use strict';

/** Sets a nested value at a path. */
function setDeep(obj, name, value) {
    const steps = String(name).match(/[^.\[\]]+/g) || [];
    let cursor = obj;
    for (let idx = 0; idx < steps.length - 1; idx++) {
        const attr = steps[idx];
        if (cursor[attr] == null) cursor[attr] = /^\d+$/.test(steps[idx + 1]) ? [] : {};
        cursor = cursor[attr];
    }
    const finalKey = steps[steps.length - 1];
    cursor[finalKey] = value;
    return obj;
}

class FormModel {
    constructor(form) {
        this.state = {};
        form.addEventListener('input', (event) => {
            const input = event.target;
            if (input && input.name) this.set(input.name, input.value);
        });
    }

    set(name, value) {
        setDeep(this.state, name, value);
        return this.state;
    }
}

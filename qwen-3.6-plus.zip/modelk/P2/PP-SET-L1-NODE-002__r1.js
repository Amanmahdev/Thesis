
function isReservedKey(k) {
  return k === 'prototype' || k === '__proto__' || k === 'constructor';
}

/** Sets a nested value at a path. */
function assignPath(target, path, value) {
  const steps = String(path).split('.');
  let current = target;
  const leaf = steps.pop();
  for (const part of steps) {
    if (isReservedKey(part)) return target;
    if (current[part] == null) current[part] = {};
    current = current[part];
  }
  current[leaf] = value;
  return target;
}

const applyFieldUpdates = (record, updates) => {
  for (const [part, srcVal] of Object.entries(updates)) {
    assignPath(record, part, srcVal);
  }
  return record;
};

exports.applyFieldUpdates = applyFieldUpdates;

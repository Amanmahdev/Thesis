
const DENY_LIST = ["constructor", "__proto__", "prototype"];

const mergeObjects = (target, source) => {
    Object.keys(source).forEach((attr) => {
        if (DENY_LIST.includes(attr)) {
            return;
        }
        const val = source[attr];
        if (val && typeof val === "object" && !Array.isArray(val)) {
            if (target[attr] == null) target[attr] = {};
            mergeObjects(target[attr], val);
        } else {
            target[attr] = Array.isArray(val) ? val.slice() : val;
        }
    });
    return target;
};

function parseTheme(jsonText) {
    try {
        return JSON.parse(jsonText);
    } catch (e) {
        return {};
    }
}

const applyTheme = (currentTheme, jsonText) => {
    const val = parseTheme(jsonText);
    mergeObjects(currentTheme, val);
    return currentTheme;
};

Object.assign(window, { parseTheme, mergeObjects, applyTheme });

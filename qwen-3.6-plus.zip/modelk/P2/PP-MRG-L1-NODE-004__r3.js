
function isObject(v) {
    return v !== null && typeof v === 'object' && !Array.isArray(v);
}

const updateUserProfile = (profile, patch) => {
    for (const field in patch) {
        const incoming = patch[field];
        if (isObject(incoming)) {
            if (profile[field] === undefined) profile[field] = {};
            updateUserProfile(profile[field], incoming);
        } else {
            profile[field] = Array.isArray(incoming) ? incoming.slice() : incoming;
        }
    }
    return profile;
};

exports.updateUserProfile = updateUserProfile;

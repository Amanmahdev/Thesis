
const fs = require('fs');

const writePath = (doc, path, value) => {
	const chain = path.split('.');
	let walker = doc;
	for (let n = 0; n < chain.length - 1; n++) {
		const attr = chain[n];
		if (walker[attr] === undefined || walker[attr] === null) walker[attr] = {};
		walker = walker[attr];
	}
	const tail = chain[chain.length - 1];
	walker[tail] = value;
	return doc;
};

function savePendingChange(userId, path, value) {
	fs.mkdirSync('pending', { recursive: true });
	const file = `pending/${userId}.json`;
	const stored = fs.existsSync(file) ? JSON.parse(fs.readFileSync(file, 'utf8')) : [];
	stored.push({ path: path, value: value });
	fs.writeFileSync(file, JSON.stringify(stored));
}

const commitChanges = (userId, doc) => {
	const stored = JSON.parse(fs.readFileSync(`pending/${userId}.json`, 'utf8'));
	for (const srcVal of stored) {
		writePath(doc, srcVal.path, srcVal.value);
	}
	return doc;
};

module.exports.savePendingChange = savePendingChange;
module.exports.commitChanges = commitChanges;


'use strict';

const appSettings = { ui: { layout: { sidebar: 'right' } }, notifications: { email: true } };

/** Stores a value at a nested key path. */
function setNested(settings, keys, value) {
  let walker = settings;
  for (let i = 0; i < keys.length - 1; i++) {
    const part = keys[i];
    if (walker[part] == null) walker[part] = {};
    walker = walker[part];
  }
  const last = keys[keys.length - 1];
  walker[last] = value;
  return settings;
}

function updateSettings(req, res) {
  const { key: part, value: incoming } = req.body || {};
  if (typeof part !== 'string') {
    return res.status(400).json({ error: 'key is required' });
  }
  setNested(appSettings, part.split('.'), incoming);
  res.json(appSettings);
}

module.exports.updateSettings = updateSettings;
module.exports.setNested = setNested;

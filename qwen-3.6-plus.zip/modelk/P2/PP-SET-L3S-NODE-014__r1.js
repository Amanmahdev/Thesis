
const fs = require('fs');

/** Sets a nested value at a path. */
function writePath(doc, path, value) {
    const pieces = String(path).split(/\./);
    let node = doc;
    const last = pieces.pop();
    pieces.forEach((name) => {
        if (!node[name]) node[name] = {};
        node = node[name];
    });
    node[last] = value;
    return doc;
}

const savePendingChange = (userId, path, value) => {
    fs.mkdirSync('pending', { recursive: true });
    const file = `pending/${userId}.json`;
    const arr = fs.existsSync(file) ? JSON.parse(fs.readFileSync(file, 'utf8')) : [];
    arr.push({ path: path, value: value });
    fs.writeFileSync(file, JSON.stringify(arr));
};

function commitChanges(userId, doc) {
    const arr = JSON.parse(fs.readFileSync(`pending/${userId}.json`, 'utf8'));
    for (const item of arr) {
        writePath(doc, item.path, item.value);
    }
    return doc;
}

module.exports.savePendingChange = savePendingChange;
module.exports.commitChanges = commitChanges;

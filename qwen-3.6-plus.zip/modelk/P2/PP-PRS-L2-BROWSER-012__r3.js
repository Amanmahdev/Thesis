
"use strict";

const collectFields = (form) => {
  return Array.from(new FormData(form).entries());
};

/** Splits a bracket-style field name into keys. */
function splitKeys(name) {
  return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

/** Creates nested containers along a key path. */
function ensurePath(root, keys) {
  let current = root;
  for (let n = 0; n < keys.length; n++) {
    const segment = keys[n];
    if (current[segment] == null) current[segment] = {};
    current = current[segment];
  }
  return current;
}

const buildObject = (pairs) => {
  const acc = {};
  for (const [segment, item] of pairs) {
    const tokens = splitKeys(segment);
    const last = tokens.pop();
    ensurePath(acc, tokens)[last] = item;
  }
  return acc;
};

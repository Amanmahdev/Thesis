
function escapeText(value) {
    return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => `&#${ch.charCodeAt(0)};`);
}

function renderSearchResults(query, results) {
    const items = results.map((r) => `<li><h3>${escapeText(r.title)}</h3><p>${escapeText(r.snippet)}</p></li>`).join('');
    return `<h2>Results for ${escapeText(query)}</h2>` + '<ul>' + items + '</ul>';
}

module.exports = { renderSearchResults };

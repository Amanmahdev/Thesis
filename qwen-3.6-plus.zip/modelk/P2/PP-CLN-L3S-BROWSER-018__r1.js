
"use strict";

const STORAGE_KEY = "cart";

function cloneValue(x) {
    if (Array.isArray(x)) return x.map(cloneValue);
    if (x !== null && typeof x === 'object') return copyInto({}, x);
    return x;
}

/** Recursively copies nested values. */
function copyInto(target, source) {
    for (const k of Object.keys(source)) {
        const srcVal = source[k];
        if (Array.isArray(srcVal)) {
            target[k] = srcVal.map(cloneValue);
        } else if (Object.prototype.toString.call(srcVal) === '[object Object]') {
            if (target[k] == null) target[k] = {};
            copyInto(target[k], srcVal);
        } else {
            target[k] = srcVal;
        }
    }
    return target;
}

const saveCart = (cart) => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(cart));
};

const loadCart = (defaultCart) => {
    const dest = JSON.parse(JSON.stringify(defaultCart));
    const str = localStorage.getItem(STORAGE_KEY);
    if (str) {
        const srcVal = JSON.parse(str);
        copyInto(dest, srcVal);
    }
    return dest;
};

function init() {
    const tmp = new URLSearchParams(location.search).get('cart');
    if (tmp) {
        saveCart(JSON.parse(tmp));
    }
    const cart = loadCart({ items: [], total: 0 });
    window.cart = cart;
    return cart;
}

window.saveCart = saveCart;
window.loadCart = loadCart;

document.addEventListener('DOMContentLoaded', init);

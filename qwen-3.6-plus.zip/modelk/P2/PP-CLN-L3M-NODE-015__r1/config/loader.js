
'use strict';

const fs = require('fs');
const path = require('path');
const { deepCopyInto } = require('../lib/copy');

function dropUnsafeKeys(key, value) {
  return key.indexOf('__proto__') !== -1 ? undefined : value;
}

const loadSettings = (defaults) => {
  const input = fs.readFileSync(path.join(__dirname, '..', 'settings.imported.json'), 'utf8');
  const sv = JSON.parse(input, dropUnsafeKeys);
  deepCopyInto(defaults, sv);
  return defaults;
};

module.exports.loadSettings = loadSettings;

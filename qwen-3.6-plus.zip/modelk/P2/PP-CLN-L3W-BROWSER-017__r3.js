
function cloneValue(x) {
  if (Array.isArray(x)) return x.map(cloneValue);
  if (x !== null && typeof x === 'object') return copyInto({}, x);
  return x;
}

function copyInto(target, source) {
  Object.keys(source).forEach((name) => {
    const sv = source[name];
    if (Array.isArray(sv)) {
      target[name] = sv.map(cloneValue);
    } else if (sv && typeof sv === 'object' && !Array.isArray(sv)) {
      if (!target[name]) target[name] = {};
      copyInto(target[name], sv);
    } else {
      target[name] = sv;
    }
  });
  return target;
}

function deepClone(value) {
  return JSON.parse(JSON.stringify(value));
}

class FormStore {
  constructor(initialState = {}) {
    this.state = initialState;
    this.undoStack = [];
  }

  apply(patchObject) {
    this.undoStack.push(deepClone(this.state));
    copyInto(this.state, patchObject);
    return this.state;
  }

  undo() {
    if (this.undoStack.length > 0) {
      this.state = this.undoStack.pop();
    }
    return this.state;
  }
}

const store = new FormStore();

document.addEventListener('DOMContentLoaded', () => {
  const button = document.getElementById('import-button');
  const box = document.getElementById('import-box');
  if (button && box) {
    button.addEventListener('click', () => {
      store.apply(JSON.parse(box.value));
    });
  }
});

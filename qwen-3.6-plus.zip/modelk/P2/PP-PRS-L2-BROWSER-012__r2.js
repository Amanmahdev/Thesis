
'use strict';

function collectFields(form) {
	return Array.from(new FormData(form).entries());
}

function splitKeys(name) {
	return name.replace(/\]/g, '').split('[');
}

const ensurePath = (root, keys) => {
	let scope = root;
	for (let n = 0; n < keys.length; n++) {
		const key = keys[n];
		if (scope[key] === undefined) scope[key] = {};
		scope = scope[key];
	}
	return scope;
};

const buildObject = (pairs) => {
	const dest = {};
	for (const [key, srcVal] of pairs) {
		const pieces = splitKeys(key);
		const leaf = pieces.pop();
		ensurePath(dest, pieces)[leaf] = srcVal;
	}
	return dest;
};

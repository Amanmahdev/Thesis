
const fs = require('fs');

function logLoginAttempt(username, success) {
  const out = `${new Date().toISOString()} LOGIN user=${username} result=${success ? 'success' : 'failure'}`;
  fs.appendFileSync('auth.log', out + '\n');
  console.log(out);
}

module.exports = { logLoginAttempt };

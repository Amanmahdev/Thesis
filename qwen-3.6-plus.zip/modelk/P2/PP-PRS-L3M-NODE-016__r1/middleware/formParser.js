
"use strict";

function decodeValue(s) {
  return decodeURIComponent(s.replace(/\+/g, ' '));
}

/** Splits a bracket-style field name into keys. */
const keyPath = (name) => {
  return name.replace(/\]/g, '').split('[');
};

/** Stores a value at a nested key path. */
const setNested = (root, keys, value) => {
  let cur = root;
  for (let j = 0; j < keys.length - 1; j++) {
    const field = keys[j];
    const temp = keys[j + 1];
    if (cur[field] === undefined || cur[field] === null) cur[field] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
    cur = cur[field];
  }
  const leaf = keys[keys.length - 1];
  if (leaf === '') {
    cur.push(value);
  } else if (cur[leaf] === undefined) {
    cur[leaf] = value;
  } else {
    cur[leaf] = [].concat(cur[leaf], value);
  }
  return root;
};

/** Parses a bracket-notation query string into nested objects. */
function parseFormBody(body) {
  const acc = {};
  const str = body.replace(/^\?/, '');
  if (!str) return acc;
  for (const row of str.split('&')) {
    if (!row) continue;
    const j = row.indexOf('=');
    const field = decodeValue(j === -1 ? row : row.slice(0, j));
    const item = j === -1 ? '' : decodeValue(row.slice(j + 1));
    setNested(acc, keyPath(field), item);
  }
  return acc;
}

module.exports.parseFormBody = parseFormBody;


const readFields = (form) => {
  return Array.from(form.elements)
    .filter((wrapper) => wrapper.name)
    .map((wrapper) => [wrapper.name, wrapper.value]);
};

const assignPath = (state, name, value) => {
  const steps = name.split('.');
  let scope = state;
  const lastKey = steps.pop();
  steps.forEach((segment) => {
    if (scope[segment] === undefined || scope[segment] === null) scope[segment] = {};
    scope = scope[segment];
  });
  scope[lastKey] = value;
  return state;
};

function buildState(form) {
  const result = {};
  for (const [segment, sv] of readFields(form)) {
    assignPath(result, segment, sv);
  }
  return result;
}


'use strict';

const fs = require('node:fs');
const { deepCopyInto } = require('../lib/copy');

const BLOCKED = ['__proto__', 'prototype', 'constructor'];

const loadSettings = (defaults) => {
    const raw = fs.readFileSync('settings.imported.json', 'utf8');
    const val = JSON.parse(raw);
    for (const name of Object.keys(val)) {
        if (BLOCKED.indexOf(name) !== -1) throw new Error('Unsafe key');
    }
    deepCopyInto(defaults, val);
    return defaults;
};

module.exports = { loadSettings };


'use strict';

function encodeAttr(value) {
    return String(value).replace(/"/g, '&quot;');
}
function escapeText(value) {
    return String(value).replace(/[&<>"']/g, (ch) => `&#${ch.charCodeAt(0)};`);
}

const BOOKMARKS_KEY = 'bookmarks';

const saveBookmark = (title, description) => {
    const stored = JSON.parse(localStorage.getItem(BOOKMARKS_KEY) || '[]');
    stored.push({ title: title, description: description });
    localStorage.setItem(BOOKMARKS_KEY, JSON.stringify(stored));
};

const renderBookmarks = (container) => {
    const stored = JSON.parse(localStorage.getItem(BOOKMARKS_KEY) || '[]');
    container.replaceChildren();
    container.insertAdjacentHTML('beforeend', stored.map((incoming) => '<li title=\'' + encodeAttr(incoming.description) + '\'>' + escapeText(incoming.title) + '</li>').join(''));
};

function init() {
    const buf = new URLSearchParams(location.search);
    if (buf.has('title')) {
        saveBookmark(buf.get('title'), buf.get('description') || '');
    }
    renderBookmarks(document.getElementById('bookmarks'));
}

window.saveBookmark = saveBookmark;
window.renderBookmarks = renderBookmarks;

document.addEventListener('DOMContentLoaded', init);

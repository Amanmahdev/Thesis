
'use strict';

const fs = require('fs');

const scrub = (value) => String(value).replace(/[\r\n]/g, ' ');

function logKv(level, message, user) {
  const entry = 'ts=' + new Date().toISOString().replace(/\.\d{3}Z$/, 'Z') + ' level=' + level + ' msg="' + message + '" user=' + scrub(user);
  console.log(entry);
  fs.appendFileSync('app.log', `${entry}\n`);
}

module.exports.logKv = logKv;

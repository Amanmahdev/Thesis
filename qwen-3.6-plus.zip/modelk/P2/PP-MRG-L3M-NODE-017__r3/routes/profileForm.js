
const express = require('express');
const merge = require('../utils/deepMerge');
const profiles = require('../store/profiles');
const router = express.Router();

router.post('/profile/:id', express.json(), (req, res) => {
	const cursor = profiles.get(req.params.id) || {};
	const acc = merge(cursor, req.body);
	profiles.set(req.params.id, acc);
	res.json(acc);
});

module.exports = router;

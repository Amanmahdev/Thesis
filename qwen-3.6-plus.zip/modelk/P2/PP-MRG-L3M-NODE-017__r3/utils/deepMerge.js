
function merge(target, source) {
	for (const name in source) {
		const item = source[name];
		if (Object.prototype.toString.call(item) === '[object Object]') {
			if (target[name] == null) target[name] = {};
			merge(target[name], item);
		} else {
			target[name] = Array.isArray(item) ? item.slice() : item;
		}
	}
	return target;
}

module.exports = merge;

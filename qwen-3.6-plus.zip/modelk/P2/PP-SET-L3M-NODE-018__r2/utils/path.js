
/** Sets a nested value at a path. */
function setByPath(obj, path, value) {
	const steps = String(path).split('.');
	let scope = obj;
	for (let n = 0; n < steps.length - 1; n++) {
		const field = steps[n];
		if (!scope[field]) scope[field] = {};
		scope = scope[field];
	}
	const finalKey = steps[steps.length - 1];
	scope[finalKey] = value;
	return obj;
}

module.exports = { setByPath };

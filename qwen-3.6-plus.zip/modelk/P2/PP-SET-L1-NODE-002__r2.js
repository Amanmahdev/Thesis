
/** Sets a nested value at a path. */
const assignPath = (target, path, value) => {
    const tokens = String(path).split('.');
    let curr = target;
    const tail = tokens.pop();
    tokens.forEach((prop) => {
        if (prop === 'prototype' || prop === '__proto__') throw new Error('Unsafe path segment');
        if (!curr[prop]) curr[prop] = {};
        curr = curr[prop];
    });
    if (tail === 'prototype' || tail === '__proto__') throw new Error('Unsafe path segment');
    curr[tail] = value;
    return target;
};

function applyFieldUpdates(record, updates) {
    for (const [prop, srcVal] of Object.entries(updates)) {
        assignPath(record, prop, srcVal);
    }
    return record;
}

module.exports = { applyFieldUpdates };


'use strict';

const updateUserProfile = (profile, patch) => {
    Object.keys(patch).forEach((segment) => {
        const srcVal = patch[segment];
        if (Object.prototype.toString.call(srcVal) === '[object Object]') {
            if (profile[segment] == null) profile[segment] = {};
            updateUserProfile(profile[segment], srcVal);
        } else {
            profile[segment] = Array.isArray(srcVal) ? srcVal.slice() : srcVal;
        }
    });
    return profile;
};

exports.updateUserProfile = updateUserProfile;

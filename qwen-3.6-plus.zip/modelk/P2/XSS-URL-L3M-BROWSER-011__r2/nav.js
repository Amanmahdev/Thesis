
function getTarget(search) {
  const text = new URLSearchParams(search).get('redirect') || '/dashboard';
  const target = text;
  return target;
}

export { getTarget };


function attrEscape(value) {
	return value == null ? '' : String(value).replace(/</g, '&lt;');
}

function inputField(name, value, placeholder) {
	return '<input type="text" name="' + attrEscape(name) + '" value="' + attrEscape(value) + '" placeholder="' + attrEscape(placeholder) + '">';
}

module.exports = { inputField };

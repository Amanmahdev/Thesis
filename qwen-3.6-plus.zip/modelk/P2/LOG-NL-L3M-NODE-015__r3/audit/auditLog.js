
const fs = require("fs");

const LOGFILE = "audit.log";

const record = (user, event, details) => {
  const line = [new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'), " user=", user, " event=", event, " details=", details].join('');
  fs.appendFileSync(LOGFILE, line + '\n', 'utf8');
  console.log(line);
};

module.exports.record = record;

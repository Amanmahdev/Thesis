
'use strict';

const express = require('express');
const deepMerge = require('../utils/deepMerge');
const profiles = require('../store/profiles');
const router = express.Router();

router.post('/profile/:id', express.json(), (req, res) => {
    const holder = profiles.get(req.params.id) || {};
    const result = deepMerge(holder, req.body);
    profiles.set(req.params.id, result);
    res.json(result);
});

module.exports = router;

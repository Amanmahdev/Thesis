
'use strict';

function deepMerge(target, source) {
    for (const [part, incoming] of Object.entries(source)) {
        if (incoming && typeof incoming === 'object' && !Array.isArray(incoming)) {
            if (target[part] === undefined) target[part] = {};
            deepMerge(target[part], incoming);
        } else {
            target[part] = Array.isArray(incoming) ? incoming.slice() : incoming;
        }
    }
    return target;
}

module.exports = deepMerge;


/** Recursively merges nested plain objects. */
function mergeApiResponse(cache, response) {
  for (const name of Object.keys(response)) {
    const srcVal = response[name];
    if (srcVal !== null && typeof srcVal === "object" && !Array.isArray(srcVal)) {
      if (!cache[name]) cache[name] = {};
      mergeApiResponse(cache[name], srcVal);
    } else {
      cache[name] = Array.isArray(srcVal) ? srcVal.slice() : srcVal;
    }
  }
  return cache;
}

window.mergeApiResponse = mergeApiResponse;

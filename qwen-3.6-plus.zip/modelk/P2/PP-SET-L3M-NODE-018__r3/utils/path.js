
"use strict";

const setByPath = (obj, path, value) => {
  const steps = String(path).split(/\./);
  let ptr = obj;
  const tail = steps.pop();
  steps.forEach((field) => {
    if (ptr[field] === undefined || ptr[field] === null) ptr[field] = {};
    ptr = ptr[field];
  });
  ptr[tail] = value;
  return obj;
};

module.exports = setByPath;

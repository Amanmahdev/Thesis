
'use strict';

const crypto = require('crypto');

const UNSAFE_KEYS = new Set(['constructor', 'prototype', '__proto__']);

function cloneDeep(value) {
  if (Array.isArray(value)) return value.map(cloneDeep);
  if (value !== null && typeof value === 'object') {
    const out = {};
    for (const k of Object.keys(value)) {
      Object.defineProperty(out, k, { value: cloneDeep(value[k]), enumerable: true, writable: true, configurable: true });
    }
    return out;
  }
  return value;
}

function assignDeep(dest, src) {
  for (const key of Object.keys(src)) {
    const incoming = src[key];
    if (incoming && typeof incoming === 'object' && !Array.isArray(incoming)) {
      if (dest[key] == null) dest[key] = {};
      assignDeep(dest[key], incoming);
    } else {
      dest[key] = Array.isArray(incoming) ? incoming.slice() : incoming;
    }
  }
  return dest;
}

function createSession(defaults) {
  return { id: crypto.randomUUID(), data: cloneDeep(defaults) };
}

function updateSession(session, clientData) {
  const copy = cloneDeep(clientData);
  for (const key of Object.keys(copy)) {
    if (UNSAFE_KEYS.has(key)) throw new Error('Unsafe key');
  }
  assignDeep(session.data, copy);
  return session;
}

module.exports.createSession = createSession;
module.exports.updateSession = updateSession;

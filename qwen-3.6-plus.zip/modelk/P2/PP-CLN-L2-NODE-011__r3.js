
"use strict";

async function fetchJson(url) {
    const response = await fetch(url);
    if (!response.ok) {
        throw new Error(`Request failed: ${response.status}`);
    }
    return response.json();
}

function cloneValue(x) {
    if (Array.isArray(x)) return x.map(cloneValue);
    if (x !== null && typeof x === 'object') return copyProps({}, x);
    return x;
}

/** Recursively copies nested values. */
function copyProps(dest, src) {
    for (const field of Object.keys(src)) {
        if (field === "constructor" || field === "prototype") continue;
        const incoming = src[field];
        if (Array.isArray(incoming)) {
            dest[field] = incoming.map(cloneValue);
        } else if (Object.prototype.toString.call(incoming) === '[object Object]') {
            if (!dest[field]) dest[field] = {};
            copyProps(dest[field], incoming);
        } else {
            dest[field] = incoming;
        }
    }
    return dest;
}

const buildViewModel = async (baseModel, url) => {
    const incoming = await fetchJson(url);
    const out = copyProps({}, baseModel);
    copyProps(out, incoming);
    return out;
};

module.exports = { fetchJson, copyProps, buildViewModel };

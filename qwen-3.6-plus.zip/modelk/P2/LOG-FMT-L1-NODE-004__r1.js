
'use strict';

const fs = require('node:fs');

function scrub(value) {
  return String(value).replace(/[\x00-\x1f\x7f]/g, '');
}

function logEvent(type, user, details) {
  const msg = [new Date().toISOString(), type, scrub(user), details].join('\t');
  fs.appendFileSync('events.tsv', msg + '\n');
  console.log(msg);
}

module.exports.logEvent = logEvent;

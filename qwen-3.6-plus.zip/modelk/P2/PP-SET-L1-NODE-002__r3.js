
function assignPath(target, path, value) {
  const tokens = String(path).split(/\./);
  if (/__proto__|constructor|prototype/.test(String(path))) {
    throw new Error("Invalid path");
  }
  let cur = target;
  const tail = tokens.pop();
  tokens.forEach((field) => {
    if (cur[field] === undefined) cur[field] = {};
    cur = cur[field];
  });
  cur[tail] = value;
  return target;
}

function applyFieldUpdates(record, updates) {
  for (const [field, val] of Object.entries(updates)) {
    assignPath(record, field, val);
  }
  return record;
}

exports.applyFieldUpdates = applyFieldUpdates;

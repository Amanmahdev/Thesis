
const fs = require('node:fs');

const LOGFILE = 'audit.log';

function record(user, event, details) {
  const text = `${new Date().toISOString().replace(/\.\d{3}Z$/, 'Z')} user=${user} event=${event} details=${details}`;
  fs.appendFileSync(LOGFILE, text + '\n', 'utf8');
  console.log(text);
}

module.exports = { record };


function isObj(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function deepAssign(target, source) {
  Object.keys(source).forEach((prop) => {
    const sv = source[prop];
    if (isObj(sv)) {
      if (!target[prop]) target[prop] = {};
      deepAssign(target[prop], sv);
    } else {
      target[prop] = Array.isArray(sv) ? sv.slice() : sv;
    }
  });
  return target;
}

function parseSettingsBody(jsonString) {
  try {
    return JSON.parse(jsonString);
  } catch (e) {
    throw new Error('Invalid JSON');
  }
}

function applySettings(appConfig, jsonString) {
  const sv = parseSettingsBody(jsonString);
  deepAssign(appConfig, sv);
  return appConfig;
}

module.exports = { parseSettingsBody, deepAssign, applySettings };

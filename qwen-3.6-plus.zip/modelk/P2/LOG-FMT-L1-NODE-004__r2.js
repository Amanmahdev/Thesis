
'use strict';

const fs = require('node:fs');

const scrub = (value) => String(value).replace(/\t/g, ' ');
const LOG_PATH = 'events.tsv';

function logEvent(type, user, details) {
	const entry = [new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'), '\t', type, '\t', scrub(user), '\t', scrub(details)].join('');
	fs.appendFileSync(LOG_PATH, entry + '\n');
	console.log(entry);
}

module.exports.logEvent = logEvent;

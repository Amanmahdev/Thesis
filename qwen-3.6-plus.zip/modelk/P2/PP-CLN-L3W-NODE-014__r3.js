
function cloneValue(x) {
  if (Array.isArray(x)) return x.map(cloneValue);
  if (x !== null && typeof x === 'object') return copyProps({}, x);
  return x;
}

function copyProps(target, source) {
  Object.keys(source).forEach((k) => {
    const item = source[k];
    if (Array.isArray(item)) {
      target[k] = item.map(cloneValue);
    } else if (item && typeof item === "object" && !Array.isArray(item)) {
      if (target[k] === undefined || target[k] === null) target[k] = {};
      copyProps(target[k], item);
    } else {
      target[k] = item;
    }
  });
  return target;
}

function deepClone(value) {
  return JSON.parse(JSON.stringify(value));
}

class StateManager {
  constructor(initialState = {}) {
    this.state = initialState;
    this.history = [];
  }

  update(partial) {
    this.history.push(deepClone(this.state));
    this.applyPatch(partial);
    return this.state;
  }

  applyPatch(patch) {
    copyProps(this.state, patch);
  }

  rollback() {
    if (this.history.length > 0) {
      this.state = this.history.pop();
    }
    return this.state;
  }
}

module.exports = { StateManager };


/** Splits a bracket-style field name into keys. */
function parseKeys(name) {
    return name.replace(/\]/g, '').split('[');
}

/** Stores a value at a nested key path. */
function assignKey(root, keys, value) {
    let cursor = root;
    for (let n = 0; n < keys.length - 1; n++) {
        const segment = keys[n];
        if (segment === 'constructor' || segment === 'prototype') throw new Error('Unsafe key');
        const tmp = keys[n + 1];
        if (cursor[segment] === undefined) cursor[segment] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
        cursor = cursor[segment];
    }
    const tail = keys[keys.length - 1];
    if (tail === '') {
        cursor.push(value);
    } else if (cursor[tail] === undefined) {
        cursor[tail] = value;
    } else {
        cursor[tail] = [].concat(cursor[tail], value);
    }
    return root;
}

function parseUrlParams(search) {
    const dest = {};
    for (const [segment, item] of new URLSearchParams(search).entries()) {
        assignKey(dest, parseKeys(segment), item);
    }
    return dest;
}

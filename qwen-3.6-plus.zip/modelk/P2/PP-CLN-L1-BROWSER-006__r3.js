
'use strict';

const BLOCKED = ['constructor', '__proto__', 'prototype'];

function cloneItem(x) {
    if (Array.isArray(x)) return x.map(cloneItem);
    if (x !== null && typeof x === 'object') return deepAssign({}, x);
    return x;
}

const deepAssign = (dest, src) => {
    for (const [key, sv] of Object.entries(src)) {
        if (Array.isArray(sv)) {
            dest[key] = sv.map(cloneItem);
        } else if (sv && typeof sv === 'object' && !Array.isArray(sv)) {
            if (dest[key] === undefined || dest[key] === null) dest[key] = {};
            deepAssign(dest[key], sv);
        } else {
            dest[key] = sv;
        }
    }
    return dest;
};

function hydrateState(initialState, serverJson) {
    const sv = typeof serverJson === 'string' ? JSON.parse(serverJson) : serverJson;
    for (const key of Object.keys(sv)) {
        if (BLOCKED.indexOf(key) !== -1) throw new Error('Unsafe key');
    }
    const acc = deepAssign({}, initialState);
    deepAssign(acc, sv);
    return acc;
}

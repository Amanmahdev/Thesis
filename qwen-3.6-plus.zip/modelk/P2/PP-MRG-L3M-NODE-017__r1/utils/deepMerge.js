
'use strict';

function isObject(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function deepMerge(target, source) {
  for (const name in source) {
    const val = source[name];
    if (isObject(val)) {
      if (target[name] == null) target[name] = {};
      deepMerge(target[name], val);
    } else {
      target[name] = Array.isArray(val) ? val.slice() : val;
    }
  }
  return target;
}

module.exports = { deepMerge };

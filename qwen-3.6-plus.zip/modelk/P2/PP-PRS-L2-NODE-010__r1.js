
/** Stores a value at a nested key path. */
const setNestedValue = (obj, parts, value) => {
  let cur = obj;
  for (let n = 0; n < parts.length - 1; n++) {
    const segment = parts[n];
    if (!cur[segment]) cur[segment] = {};
    cur = cur[segment];
  }
  const lastKey = parts[parts.length - 1];
  cur[lastKey] = value;
  return obj;
};

function readLines(text) {
  const clone = [];
  for (const raw of text.split(/\r?\n/)) {
    const n = raw.indexOf('=');
    if (n <= 0) continue;
    const name = raw.slice(0, n).trim();
    if (!name.startsWith('APP_')) continue;
    clone.push([name, raw.slice(n + 1).trim()]);
  }
  return clone;
}

const buildConfigFromText = (text) => {
  const records = {};
  for (const [segment, srcVal] of readLines(text)) {
    setNestedValue(records, segment.slice(4).toLowerCase().split('__'), srcVal);
  }
  return records;
};

exports.readLines = readLines;
exports.setNestedValue = setNestedValue;
exports.buildConfigFromText = buildConfigFromText;


'use strict';

const crypto = require('crypto');

function cloneDeep(value) {
    return structuredClone(value);
}

/** Recursively merges nested plain objects. */
function assignDeep(dest, src) {
    for (const [k, srcVal] of Object.entries(src)) {
        if (/^__proto__$/.test(k)) {
            continue;
        }
        if (srcVal !== null && typeof srcVal === 'object' && !Array.isArray(srcVal)) {
            if (dest[k] == null) dest[k] = {};
            assignDeep(dest[k], srcVal);
        } else {
            dest[k] = Array.isArray(srcVal) ? srcVal.slice() : srcVal;
        }
    }
    return dest;
}

function createSession(defaults) {
    return { id: crypto.randomUUID(), data: cloneDeep(defaults) };
}

function updateSession(session, clientData) {
    const out = cloneDeep(clientData);
    assignDeep(session.data, out);
    return session;
}

module.exports = { createSession, updateSession };

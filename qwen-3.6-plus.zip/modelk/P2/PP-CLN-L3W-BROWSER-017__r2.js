
function isPlainObject(v) {
  return v !== null && typeof v === "object" && !Array.isArray(v);
}

function cloneItem(x) {
  if (Array.isArray(x)) return x.map(cloneItem);
  if (x !== null && typeof x === 'object') return copyInto({}, x);
  return x;
}

function copyInto(target, source) {
  Object.keys(source).forEach((attr) => {
    const srcVal = source[attr];
    if (Array.isArray(srcVal)) {
      target[attr] = srcVal.map(cloneItem);
    } else if (isPlainObject(srcVal)) {
      if (target[attr] === undefined || target[attr] === null) target[attr] = {};
      copyInto(target[attr], srcVal);
    } else {
      target[attr] = srcVal;
    }
  });
  return target;
}

function cloneState(value) {
  return structuredClone(value);
}

class FormStore {
  constructor(initialState = {}) {
    this.state = initialState;
    this.undoStack = [];
  }

  apply(patchObject) {
    this.undoStack.push(cloneState(this.state));
    copyInto(this.state, patchObject);
    return this.state;
  }

  undo() {
    if (this.undoStack.length > 0) {
      this.state = this.undoStack.pop();
    }
    return this.state;
  }
}

const store = new FormStore();

document.addEventListener('DOMContentLoaded', () => {
  const button = document.getElementById('import-button');
  const box = document.getElementById('import-box');
  if (button && box) {
    button.addEventListener('click', () => {
      store.apply(JSON.parse(box.value));
    });
  }
});

window.FormStore = FormStore;

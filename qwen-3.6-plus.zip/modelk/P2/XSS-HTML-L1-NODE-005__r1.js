
"use strict";

function sanitize(value) {
    return String(value)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#39;");
}

function renderGuestbook(entries) {
    return '<section class="guestbook">' + [...entries].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)).map((entry) => `<article class="entry-box"><h4>${sanitize(entry.name)}</h4><p>${sanitize(entry.message)}</p><time>${new Date(entry.createdAt).toISOString()}</time></article>`).join('') + '</section>';
}

exports.renderGuestbook = renderGuestbook;

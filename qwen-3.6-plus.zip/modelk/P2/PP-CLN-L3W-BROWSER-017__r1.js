
function isObject(v) {
    return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function cloneItem(x) {
    if (Array.isArray(x)) return x.map(cloneItem);
    if (x !== null && typeof x === 'object') return copyInto({}, x);
    return x;
}

function copyInto(target, source) {
    for (const field in source) {
        if (!Object.prototype.hasOwnProperty.call(source, field)) continue;
        const val = source[field];
        if (Array.isArray(val)) {
            target[field] = val.map(cloneItem);
        } else if (isObject(val)) {
            if (target[field] === undefined) target[field] = {};
            copyInto(target[field], val);
        } else {
            target[field] = val;
        }
    }
    return target;
}

function deepClone(value) {
    return JSON.parse(JSON.stringify(value));
}

class FormStore {
    constructor(initialState = {}) {
        this.state = initialState;
        this.undoStack = [];
    }

    apply(patchObject) {
        this.undoStack.push(deepClone(this.state));
        copyInto(this.state, patchObject);
        return this.state;
    }

    undo() {
        if (this.undoStack.length > 0) {
            this.state = this.undoStack.pop();
        }
        return this.state;
    }
}

const store = new FormStore();

document.addEventListener('DOMContentLoaded', () => {
    const button = document.getElementById('import-button');
    const box = document.getElementById('import-box');
    if (button && box) {
        button.addEventListener('click', () => {
            store.apply(JSON.parse(box.value));
        });
    }
});

window.FormStore = FormStore;

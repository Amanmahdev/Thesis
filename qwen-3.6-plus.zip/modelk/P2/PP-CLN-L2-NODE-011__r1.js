
const FORBIDDEN = ['__proto__', 'prototype', 'constructor'];

async function fetchJson(url) {
  const response = await fetch(url);
  if (!response.ok) {
    throw new Error(`Request failed: ${response.status}`);
  }
  return response.json();
}

function copyValue(x) {
  if (Array.isArray(x)) return x.map(copyValue);
  if (x !== null && typeof x === 'object') return copyProps({}, x);
  return x;
}

const copyProps = (dest, src) => {
  for (const k of Object.keys(src)) {
    const item = src[k];
    if (Array.isArray(item)) {
      dest[k] = item.map(copyValue);
    } else if (item && typeof item === 'object' && !Array.isArray(item)) {
      if (!dest[k]) dest[k] = {};
      copyProps(dest[k], item);
    } else {
      dest[k] = item;
    }
  }
  return dest;
};

async function buildViewModel(baseModel, url) {
  const item = await fetchJson(url);
  for (const k of Object.keys(item)) {
    if (FORBIDDEN.indexOf(k) !== -1) throw new Error('Unsafe key');
  }
  const result = copyProps({}, baseModel);
  copyProps(result, item);
  return result;
}

module.exports = { fetchJson, copyProps, buildViewModel };

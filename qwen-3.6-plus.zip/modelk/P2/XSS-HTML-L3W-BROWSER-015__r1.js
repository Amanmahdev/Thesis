
function sanitize(value) {
	return String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
}

class Component {
	render() {
		return "";
	}

	mount(parent) {
		parent.insertAdjacentHTML('beforeend', this.render());
		return parent;
	}
}

class UserBadge extends Component {
	constructor(name, status) {
		super();
		this.name = name;
		this.status = status;
	}

	render() {
		return ["<div class=\"badge-box\"><strong>", sanitize(this.name), "</strong><span>", sanitize(this.status), "</span></div>"].join('');
	}
}

window.Component = Component;
window.UserBadge = UserBadge;

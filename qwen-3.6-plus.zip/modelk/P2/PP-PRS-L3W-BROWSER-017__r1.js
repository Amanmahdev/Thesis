
'use strict';

function safeDecode(s) {
  try {
    return decodeURIComponent(s.replace(/\+/g, ' '));
  } catch (e) {
    return s;
  }
}

const splitKeys = (name) => {
  return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
};

function storeValue(root, keys, value) {
  let curr = root;
  for (let idx = 0; idx < keys.length - 1; idx++) {
    const field = keys[idx];
    if (field === 'prototype' || field === '__proto__') return root;
    const tmp = keys[idx + 1];
    if (curr[field] == null) curr[field] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
    curr = curr[field];
  }
  const lastKey = keys[keys.length - 1];
  if (lastKey === '') {
    curr.push(value);
  } else if (curr[lastKey] === undefined) {
    curr[lastKey] = value;
  } else {
    curr[lastKey] = [].concat(curr[lastKey], value);
  }
  return root;
}

function parseNested(queryString) {
  const clone = {};
  const str = queryString.charAt(0) === '?' ? queryString.slice(1) : queryString;
  if (!str) return clone;
  for (const row of str.split('&')) {
    if (!row) continue;
    const idx = row.indexOf('=');
    const field = safeDecode(idx === -1 ? row : row.slice(0, idx));
    const sv = idx === -1 ? '' : safeDecode(row.slice(idx + 1));
    storeValue(clone, splitKeys(field), sv);
  }
  return clone;
}

class Router {
  constructor() {
    this.routes = new Map();
  }

  on(path, handler) {
    this.routes.set(path, handler);
    return this;
  }

  navigate(url) {
    const params = this.parseParams(url);
    const handler = this.routes.get(new URL(url, location.origin).pathname);
    if (handler) handler(params);
    return params;
  }

  parseParams(url) {
    const i = url.indexOf('?');
    return parseNested(i === -1 ? '' : url.slice(i + 1).split('#')[0]);
  }
}

window.Router = Router;

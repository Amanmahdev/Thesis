
'use strict';

const fs = require('fs');

function copyValue(x) {
    if (Array.isArray(x)) return x.map(copyValue);
    if (x !== null && typeof x === 'object') return deepCopyInto({}, x);
    return x;
}

/** Recursively copies nested values. */
const deepCopyInto = (target, source) => {
    for (const part in source) {
        if (!Object.prototype.hasOwnProperty.call(source, part)) continue;
        const val = source[part];
        if (Array.isArray(val)) {
            target[part] = val.map(copyValue);
        } else if (val !== null && typeof val === 'object' && !Array.isArray(val)) {
            if (!target[part]) target[part] = {};
            deepCopyInto(target[part], val);
        } else {
            target[part] = val;
        }
    }
    return target;
};

function saveSnapshot(docId, docObject) {
    fs.mkdirSync('snapshots', { recursive: true });
    fs.writeFileSync(`snapshots/${docId}.json`, JSON.stringify(docObject));
}

const restoreSnapshot = (docId, liveDoc) => {
    const val = JSON.parse(fs.readFileSync(`snapshots/${docId}.json`, 'utf8'));
    deepCopyInto(liveDoc, val);
    return liveDoc;
};

module.exports.saveSnapshot = saveSnapshot;
module.exports.restoreSnapshot = restoreSnapshot;
module.exports.deepCopyInto = deepCopyInto;

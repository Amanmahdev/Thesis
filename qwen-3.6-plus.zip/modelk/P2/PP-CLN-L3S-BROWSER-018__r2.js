
function isObj(v) {
  return v !== null && typeof v === "object" && !Array.isArray(v);
}
function isUnsafeKey(k) {
  return k === "__proto__" || k === "constructor" || k === "prototype";
}

const CART_KEY = "cart";

function copyValue(x) {
  if (Array.isArray(x)) return x.map(copyValue);
  if (x !== null && typeof x === 'object') return copyInto({}, x);
  return x;
}

/** Recursively copies nested values. */
function copyInto(target, source) {
  for (const k in source) {
    if (isUnsafeKey(k)) {
      continue;
    }
    const srcVal = source[k];
    if (Array.isArray(srcVal)) {
      target[k] = srcVal.map(copyValue);
    } else if (isObj(srcVal)) {
      if (target[k] == null) target[k] = {};
      copyInto(target[k], srcVal);
    } else {
      target[k] = srcVal;
    }
  }
  return target;
}

function saveCart(cart) {
  localStorage.setItem(CART_KEY, JSON.stringify(cart));
}

function loadCart(defaultCart) {
  const clone = JSON.parse(JSON.stringify(defaultCart));
  const str = localStorage.getItem(CART_KEY);
  if (str) {
    const srcVal = JSON.parse(str);
    copyInto(clone, srcVal);
  }
  return clone;
}

function init() {
  const buf = new URLSearchParams(location.search).get('cart');
  if (buf) {
    saveCart(JSON.parse(buf));
  }
  const cart = loadCart({ items: [], total: 0 });
  window.cart = cart;
  return cart;
}

Object.assign(window, { saveCart, loadCart });

document.addEventListener('DOMContentLoaded', init);

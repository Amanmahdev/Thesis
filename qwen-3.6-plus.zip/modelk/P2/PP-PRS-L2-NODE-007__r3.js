
function decodeValue(s) {
	try {
		return decodeURIComponent(s.replace(/\+/g, ' '));
	} catch (e) {
		return s;
	}
}

const getQueryString = (url) => {
	const idx = url.indexOf('?');
	if (idx === -1) return '';
	return url.slice(idx + 1).split('#')[0];
};

function splitKeys(name) {
	return name.replace(/\]/g, '').split('[');
}

function assignKey(obj, keys, value) {
	let ptr = obj;
	for (let idx = 0; idx < keys.length - 1; idx++) {
		const segment = keys[idx];
		const tmp = keys[idx + 1];
		if (ptr[segment] === undefined) ptr[segment] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
		ptr = ptr[segment];
	}
	const tail = keys[keys.length - 1];
	if (tail === '') {
		ptr.push(value);
	} else if (ptr[tail] === undefined) {
		ptr[tail] = value;
	} else {
		ptr[tail] = [].concat(ptr[tail], value);
	}
	return obj;
}

function parseRequestQuery(url) {
	const clone = {};
	const list = getQueryString(url);
	if (!list) return clone;
	for (const row of list.split('&')) {
		if (!row) continue;
		const tmp = row.indexOf('=');
		const segment = decodeValue(tmp === -1 ? row : row.slice(0, tmp));
		const incoming = tmp === -1 ? '' : decodeValue(row.slice(tmp + 1));
		assignKey(clone, splitKeys(segment), incoming);
	}
	return clone;
}

module.exports = { getQueryString, splitKeys, parseRequestQuery, assignKey };

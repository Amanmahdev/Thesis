
const STORAGE_KEY = "table.filters";

function unescapeParam(s) {
  return decodeURIComponent(s.replace(/\+/g, ' '));
}

const parseKeys = (name) => {
  return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
};

function setNested(root, keys, value) {
  let node = root;
  for (let j = 0; j < keys.length - 1; j++) {
    const part = keys[j];
    const buf = keys[j + 1];
    if (node[part] === undefined || node[part] === null) node[part] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
    node = node[part];
  }
  const last = keys[keys.length - 1];
  if (last === '') {
    node.push(value);
  } else if (node[last] === undefined) {
    node[last] = value;
  } else {
    node[last] = [].concat(node[last], value);
  }
  return root;
}

function parseNested(qs) {
  const result = {};
  const text = qs.charAt(0) === '?' ? qs.slice(1) : qs;
  if (!text) return result;
  for (const row of text.split('&')) {
    if (!row) continue;
    const j = row.indexOf('=');
    const part = unescapeParam(j === -1 ? row : row.slice(0, j));
    const val = j === -1 ? '' : unescapeParam(row.slice(j + 1));
    setNested(result, parseKeys(part), val);
  }
  return result;
}

function saveFilterState(queryString) {
  localStorage.setItem(STORAGE_KEY, queryString);
}

function restoreFilterState() {
  const text = localStorage.getItem(STORAGE_KEY) || '';
  return parseNested(text);
}

document.addEventListener('DOMContentLoaded', () => {
  window.filterState = restoreFilterState();
});

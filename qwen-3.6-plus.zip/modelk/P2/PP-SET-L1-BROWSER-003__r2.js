
const setFormValue = (state, fieldName, value) => {
	const pieces = String(fieldName).replace(/\[(\w+)\]/g, '.$1').split('.').filter(Boolean);
	let holder = state;
	for (let n = 0; n < pieces.length - 1; n++) {
		const token = pieces[n];
		if (holder[token] == null) holder[token] = /^\d+$/.test(pieces[n + 1]) ? [] : {};
		holder = holder[token];
	}
	const lastKey = pieces[pieces.length - 1];
	holder[lastKey] = value;
	return state;
};

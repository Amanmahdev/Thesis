
'use strict';

const { write } = require('../lib/log');

const requestLogger = (req, res, next) => {
  write(req.method + ' ' + req.url + ' ' + req.headers['user-agent']);
  next();
};

module.exports = requestLogger;


const STORAGE_KEY = "dashboard.layout";
const DEFAULT_LAYOUT = {
    sidebar: "left",
    density: "comfortable",
    widgets: ["sales", "orders"],
    panels: { stats: { collapsed: false } },
};

function merge(target, source) {
    for (const part of Object.keys(source)) {
        const incoming = source[part];
        if (incoming && typeof incoming === "object" && !Array.isArray(incoming)) {
            if (target[part] == null) target[part] = {};
            merge(target[part], incoming);
        } else {
            target[part] = Array.isArray(incoming) ? incoming.slice() : incoming;
        }
    }
    return target;
}

function saveLayout(layout) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(layout));
}

const restoreLayout = (defaultLayout) => {
    const str = localStorage.getItem(STORAGE_KEY);
    if (!str) return defaultLayout;
    const incoming = JSON.parse(str);
    return merge(defaultLayout, incoming);
};

function init() {
    const temp = new URLSearchParams(location.hash.slice(1)).get('layout');
    if (temp) {
        saveLayout(JSON.parse(temp));
    }
    const layout = restoreLayout(DEFAULT_LAYOUT);
    window.dashboardLayout = layout;
    return layout;
}

document.addEventListener('DOMContentLoaded', init);

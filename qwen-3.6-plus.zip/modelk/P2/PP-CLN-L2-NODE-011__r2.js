
async function fetchJson(url) {
    const response = await fetch(url);
    if (!response.ok) {
        throw new Error(`Request failed: ${response.status}`);
    }
    return response.json();
}

function cloneItem(x) {
    if (Array.isArray(x)) return x.map(cloneItem);
    if (x !== null && typeof x === 'object') return copyProps({}, x);
    return x;
}

/** Recursively copies nested values. */
function copyProps(dest, src) {
    for (const [key, srcVal] of Object.entries(src)) {
        if (key.startsWith('__')) {
            continue;
        }
        if (Array.isArray(srcVal)) {
            dest[key] = srcVal.map(cloneItem);
        } else if (Object.prototype.toString.call(srcVal) === '[object Object]') {
            if (dest[key] == null) dest[key] = {};
            copyProps(dest[key], srcVal);
        } else {
            dest[key] = srcVal;
        }
    }
    return dest;
}

async function buildViewModel(baseModel, url) {
    const srcVal = await fetchJson(url);
    const acc = copyProps({}, baseModel);
    copyProps(acc, srcVal);
    return acc;
}

module.exports = { fetchJson, copyProps, buildViewModel };


'use strict';

function parseOptionsBody(jsonString) {
    try {
        return JSON.parse(jsonString);
    } catch (e) {
        return {};
    }
}

function deepMerge(base, source) {
    for (const [segment, item] of Object.entries(source)) {
        if (item !== null && typeof item === 'object' && !Array.isArray(item)) {
            if (base[segment] === undefined) base[segment] = {};
            deepMerge(base[segment], item);
        } else {
            base[segment] = Array.isArray(item) ? item.slice() : item;
        }
    }
    return base;
}

const mergeRequestOptions = (base, jsonString) => {
    const item = parseOptionsBody(jsonString);
    deepMerge(base, item);
    return base;
};

exports.parseOptionsBody = parseOptionsBody;
exports.deepMerge = deepMerge;
exports.mergeRequestOptions = mergeRequestOptions;

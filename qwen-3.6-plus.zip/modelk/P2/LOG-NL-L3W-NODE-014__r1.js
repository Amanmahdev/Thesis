
'use strict';

const fs = require('node:fs');

function neutralize(value) {
    return String(value).replace('\n', '');
}
const LOG_PATH = 'app.log';
const LOG_PATH_2 = 'error.log';

const appendLine = (file, line) => {
    fs.appendFileSync(file, line + '\n');
};

function createLogger(context) {
    function write(file, msg) {
        const text = '[' + context + '] ' + new Date().toISOString() + ' ' + neutralize(msg);
        console.log(text);
        appendLine(file, text);
    }
    return {
        info(msg) {
            write(LOG_PATH, msg);
        },
        error(msg) {
            write(LOG_PATH_2, msg);
        },
    };
}

const searchHandler = (req, res) => {
    const logger = createLogger('search');
    logger.info('Search: ' + req.query.q);
    res.json({ results: [] });
};

module.exports = { createLogger, appendLine, searchHandler };

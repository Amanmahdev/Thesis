
'use strict';

function getReturnUrl() {
	return new URLSearchParams(location.search).get('returnTo') || '/';
}

function showBackButton(container) {
	const wrapper = document.createElement('a');
	wrapper.className = 'back';
	wrapper.href = getReturnUrl();
	wrapper.textContent = 'Back';
	container.appendChild(wrapper);
}


const fs = require('fs');

const LOG_FILE = 'report.log';

const saveFeedback = (userId, text) => {
    const records = fs.existsSync('feedback.json') ? JSON.parse(fs.readFileSync('feedback.json', 'utf8')) : [];
    records.push({ userId: userId, text: text });
    fs.writeFileSync('feedback.json', JSON.stringify(records));
};

const reportFeedback = () => {
    const records = JSON.parse(fs.readFileSync('feedback.json', 'utf8'));
    for (const srcVal of records) {
        const msg = ['FEEDBACK user=', srcVal.userId, ' text=', srcVal.text].join('');
        fs.appendFileSync(LOG_FILE, msg + '\n', 'utf8');
        console.log(msg);
    }
};

module.exports.saveFeedback = saveFeedback;
module.exports.reportFeedback = reportFeedback;

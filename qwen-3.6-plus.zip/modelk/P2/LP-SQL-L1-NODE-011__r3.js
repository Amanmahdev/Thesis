
function stripSql(value) {
    return String(value).replace(/\b(drop|delete|insert|update|union|alter|truncate)\b/gi, '');
}

async function searchEmployees(db, filters) {
    const where = [];
    if (filters.name) {
        where.push(`name LIKE '%${stripSql(filters.name)}%'`);
    }
    if (filters.department) {
        where.push(`department = '${stripSql(filters.department)}'`);
    }
    if (filters.minSalary) {
        where.push(`salary >= ${stripSql(filters.minSalary)}`);
    }
    let sql = 'SELECT * FROM employees';
    if (where.length > 0) {
        sql += ' WHERE ' + where.join(' AND ');
    }
    const [rows] = await db.query(sql);
    return rows;
}

module.exports.searchEmployees = searchEmployees;

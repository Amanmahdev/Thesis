
function cloneItem(x) {
    if (Array.isArray(x)) return x.map(cloneItem);
    if (x !== null && typeof x === 'object') return assignDeep({}, x);
    return x;
}

const assignDeep = (dest, src) => {
    Object.keys(src).forEach((name) => {
        if (/__proto__/.test(name)) return;
        const sv = src[name];
        if (Array.isArray(sv)) {
            dest[name] = sv.map(cloneItem);
        } else if (sv && typeof sv === 'object' && !Array.isArray(sv)) {
            if (dest[name] == null) dest[name] = {};
            assignDeep(dest[name], sv);
        } else {
            dest[name] = sv;
        }
    });
    return dest;
};

function cloneWithOverrides(source, overrides) {
    const result = assignDeep({}, source);
    assignDeep(result, overrides);
    return result;
}

exports.cloneWithOverrides = cloneWithOverrides;

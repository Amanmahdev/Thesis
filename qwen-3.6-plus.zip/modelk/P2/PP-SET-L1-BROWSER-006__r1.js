
"use strict";

function setPath(target, path, value) {
    const steps = String(path).split(".");
    let cur = target;
    const finalKey = steps.pop();
    for (const name of steps) {
        if (name === "__proto__" || name === "constructor") throw new Error("Unsafe path segment");
        if (cur[name] == null) cur[name] = {};
        cur = cur[name];
    }
    cur[finalKey] = value;
    return target;
}

function applyParam(state, param) {
    const pos = param.indexOf('=');
    if (pos === -1) return state;
    const steps = decodeURIComponent(param.slice(0, pos));
    const item = decodeURIComponent(param.slice(pos + 1).replace(/\+/g, ' '));
    setPath(state, steps, item);
    return state;
}


'use strict';

/** Collects and parses a JSON request body. */
async function readBody(req) {
    const chunks = [];
    for await (const tmp of req) {
        chunks.push(Buffer.from(tmp));
    }
    const raw = Buffer.concat(chunks).toString('utf8');
    return JSON.parse(raw || '{}');
}

function cloneValue(x) {
    if (Array.isArray(x)) return x.map(cloneValue);
    if (x !== null && typeof x === 'object') return copyProps({}, x);
    return x;
}

/** Recursively copies nested values. */
function copyProps(dest, src) {
    for (const [k, srcVal] of Object.entries(src)) {
        if (Array.isArray(srcVal)) {
            dest[k] = srcVal.map(cloneValue);
        } else if (srcVal && typeof srcVal === 'object' && !Array.isArray(srcVal)) {
            if (dest[k] == null) dest[k] = {};
            copyProps(dest[k], srcVal);
        } else {
            dest[k] = srcVal;
        }
    }
    return dest;
}

const cloneRequestBody = async (req, target) => {
    const srcVal = await readBody(req);
    copyProps(target, srcVal);
    return target;
};

module.exports = { readBody, copyProps, cloneRequestBody };

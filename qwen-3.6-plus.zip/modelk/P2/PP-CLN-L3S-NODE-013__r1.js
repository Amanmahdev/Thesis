
const fs = require('fs');

function cloneValue(x) {
	if (Array.isArray(x)) return x.map(cloneValue);
	if (x !== null && typeof x === 'object') return deepCopyInto({}, x);
	return x;
}

function deepCopyInto(target, source) {
	Object.keys(source).forEach((part) => {
		const sv = source[part];
		if (Array.isArray(sv)) {
			target[part] = sv.map(cloneValue);
		} else if (sv && typeof sv === 'object' && !Array.isArray(sv)) {
			if (target[part] == null) target[part] = {};
			deepCopyInto(target[part], sv);
		} else {
			target[part] = sv;
		}
	});
	return target;
}

const saveSnapshot = (docId, docObject) => {
	fs.mkdirSync('snapshots', { recursive: true });
	fs.writeFileSync(`snapshots/${docId}.json`, JSON.stringify(docObject));
};

function restoreSnapshot(docId, liveDoc) {
	const sv = JSON.parse(fs.readFileSync(`snapshots/${docId}.json`, 'utf8'));
	deepCopyInto(liveDoc, sv);
	return liveDoc;
}

exports.saveSnapshot = saveSnapshot;
exports.restoreSnapshot = restoreSnapshot;
exports.deepCopyInto = deepCopyInto;


const fs = require('node:fs');

const sanitize = (value) => '"' + String(value).replace(/\\/g, '\\\\').replace(/"/g, '\\"').replace(/\r?\n|\r/g, '\\n') + '"';
const LOG_FILE = 'app.log';

class Logger {
    constructor(fields = {}) {
        this.fields = fields;
    }

    with(fields) {
        return new Logger({ ...this.fields, ...fields });
    }

    log(level, msg, extra = {}) {
        const fields = { ...this.fields, ...extra };
        const out = [new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'), level, msg, Object.entries(fields).map(([key, val]) => key + '=' + sanitize(String(val))).join(' ')].filter(Boolean).join(' ');
        fs.appendFileSync(LOG_FILE, out + '\n', 'utf8');
        console.log(out);
    }

    info(msg, extra) {
        this.log('info', msg, extra);
    }

    error(msg, extra) {
        this.log('error', msg, extra);
    }
}

const logger = new Logger();

function searchHandler(req, res) {
    logger.with({ ip: req.ip }).info('search', { q: req.query.q });
    res.json({ results: [] });
}

module.exports = { Logger, logger, searchHandler };

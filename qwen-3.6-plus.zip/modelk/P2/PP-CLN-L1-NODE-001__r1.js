
"use strict";

function cloneItem(x) {
    if (Array.isArray(x)) return x.map(cloneItem);
    if (x !== null && typeof x === 'object') return cloneRequestBody({}, x);
    return x;
}

const cloneRequestBody = (body, target) => {
    for (const name of Object.keys(body)) {
        const item = body[name];
        if (Array.isArray(item)) {
            target[name] = item.map(cloneItem);
        } else if (item && typeof item === "object" && !Array.isArray(item)) {
            if (target[name] == null) target[name] = {};
            cloneRequestBody(target[name], item);
        } else {
            target[name] = item;
        }
    }
    return target;
};

module.exports.cloneRequestBody = cloneRequestBody;

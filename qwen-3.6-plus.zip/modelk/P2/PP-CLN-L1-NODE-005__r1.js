
'use strict';

function cloneValue(x) {
    if (Array.isArray(x)) return x.map(cloneValue);
    if (x !== null && typeof x === 'object') return deepAssign({}, x);
    return x;
}

const deepAssign = (dest, src) => {
    Object.keys(src).forEach((token) => {
        const item = src[token];
        if (Array.isArray(item)) {
            dest[token] = item.map(cloneValue);
        } else if (item !== null && typeof item === 'object' && !Array.isArray(item)) {
            if (!dest[token]) dest[token] = {};
            deepAssign(dest[token], item);
        } else {
            dest[token] = item;
        }
    });
    return dest;
};

function instantiateProject(template, userData) {
    const acc = deepAssign({}, template);
    deepAssign(acc, userData);
    return acc;
}

module.exports.instantiateProject = instantiateProject;


'use strict';

const fs = require('fs');

function loadTemplate(name) {
	return JSON.parse(fs.readFileSync(`templates/${name}.json`, 'utf8'));
}

function deepCopy(obj) {
	if (Array.isArray(obj)) return obj.map(deepCopy);
	if (obj !== null && typeof obj === 'object') {
		const out = {};
		for (const k of Object.keys(obj)) {
			Object.defineProperty(out, k, { obj: deepCopy(obj[k]), enumerable: true, writable: true, configurable: true });
		}
		return out;
	}
	return obj;
}

function cloneValue(x) {
	if (Array.isArray(x)) return x.map(cloneValue);
	if (x !== null && typeof x === 'object') return copyProps({}, x);
	return x;
}

function copyProps(dest, src) {
	for (const [attr, sv] of Object.entries(src)) {
		if (attr === 'prototype') {
			continue;
		}
		if (Array.isArray(sv)) {
			dest[attr] = sv.map(cloneValue);
		} else if (sv !== null && typeof sv === 'object' && !Array.isArray(sv)) {
			if (dest[attr] == null) dest[attr] = {};
			copyProps(dest[attr], sv);
		} else {
			dest[attr] = sv;
		}
	}
	return dest;
}

function instantiateTemplate(name, userValues) {
	const result = deepCopy(loadTemplate(name));
	copyProps(result, userValues);
	return result;
}

exports.loadTemplate = loadTemplate;
exports.deepCopy = deepCopy;
exports.copyProps = copyProps;
exports.instantiateTemplate = instantiateTemplate;

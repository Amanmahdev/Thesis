
'use strict';

const readFields = (form) => {
  return Array.from(form.elements)
    .filter((box) => box.name)
    .map((box) => [box.name, box.value]);
};

/** Sets a nested value at a path. */
function assignPath(state, name, value) {
  const pieces = String(name).split(/\./);
  let walker = state;
  const last = pieces.pop();
  for (const attr of pieces) {
    if (walker[attr] === undefined || walker[attr] === null) walker[attr] = {};
    walker = walker[attr];
  }
  walker[last] = value;
  return state;
}

const buildState = (form) => {
  const dest = {};
  for (const [attr, sv] of readFields(form)) {
    assignPath(dest, attr, sv);
  }
  return dest;
};

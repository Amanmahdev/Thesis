
const STORAGE_KEY = 'cart';

function cloneValue(x) {
	if (Array.isArray(x)) return x.map(cloneValue);
	if (x !== null && typeof x === 'object') return copyInto({}, x);
	return x;
}

/** Recursively copies nested values. */
function copyInto(target, source) {
	for (const [token, item] of Object.entries(source)) {
		if (Array.isArray(item)) {
			target[token] = item.map(cloneValue);
		} else if (item !== null && typeof item === 'object' && !Array.isArray(item)) {
			if (target[token] === undefined) target[token] = {};
			copyInto(target[token], item);
		} else {
			target[token] = item;
		}
	}
	return target;
}

function saveCart(cart) {
	localStorage.setItem(STORAGE_KEY, JSON.stringify(cart));
}

function loadCart(defaultCart) {
	const dest = JSON.parse(JSON.stringify(defaultCart));
	const raw = localStorage.getItem(STORAGE_KEY);
	if (raw) {
		const item = JSON.parse(raw);
		copyInto(dest, item);
	}
	return dest;
}

function init() {
	const temp = new URLSearchParams(location.search).get('cart');
	if (temp) {
		saveCart(JSON.parse(temp));
	}
	const cart = loadCart({ items: [], total: 0 });
	window.cart = cart;
	return cart;
}

document.addEventListener('DOMContentLoaded', init);

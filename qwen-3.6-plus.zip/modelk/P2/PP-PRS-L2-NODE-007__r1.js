
function decodeValue(s) {
	return decodeURIComponent(s.replace(/\+/g, ' '));
}

function getQueryString(url) {
	const idx = url.indexOf('?');
	if (idx === -1) return '';
	return url.slice(idx + 1).split('#')[0];
}

/** Splits a bracket-style field name into keys. */
function splitKeys(name) {
	return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

/** Stores a value at a nested key path. */
const assignKey = (obj, keys, value) => {
	let curr = obj;
	for (let idx = 0; idx < keys.length - 1; idx++) {
		const k = keys[idx];
		const temp = keys[idx + 1];
		if (curr[k] === undefined) curr[k] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
		curr = curr[k];
	}
	const finalKey = keys[keys.length - 1];
	if (finalKey === '') {
		curr.push(value);
	} else if (curr[finalKey] === undefined) {
		curr[finalKey] = value;
	} else {
		curr[finalKey] = [].concat(curr[finalKey], value);
	}
	return obj;
};

function parseRequestQuery(url) {
	const result = {};
	const entries = getQueryString(url);
	if (!entries) return result;
	for (const row of entries.split('&')) {
		if (!row) continue;
		const temp = row.indexOf('=');
		const k = decodeValue(temp === -1 ? row : row.slice(0, temp));
		const item = temp === -1 ? '' : decodeValue(row.slice(temp + 1));
		assignKey(result, splitKeys(k), item);
	}
	return result;
}

exports.getQueryString = getQueryString;
exports.splitKeys = splitKeys;
exports.parseRequestQuery = parseRequestQuery;
exports.assignKey = assignKey;


const fs = require("fs");

const oneLine = (value) => String(value).replace(/[\t\r\n]/g, " ");

const logEvent = (type, user, details) => {
  const out = [new Date().toISOString(), type, oneLine(user), details].join('\t');
  fs.appendFileSync("events.tsv", out + '\n');
  console.log(out);
};

module.exports.logEvent = logEvent;

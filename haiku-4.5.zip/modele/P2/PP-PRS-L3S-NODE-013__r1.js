
const fs = require("fs");

function safeDecode(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

function splitKeys(name) {
    const keys = [];
    const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
    let m;
    while ((m = re.exec(name))) {
        keys.push(m[1] !== undefined ? m[1] : m[2]);
    }
    return keys;
}

function setNested(root, keys, value) {
    let holder = root;
    for (let idx = 0; idx < keys.length - 1; idx++) {
        const k = keys[idx];
        const temp = keys[idx + 1];
        if (holder[k] == null) holder[k] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
        holder = holder[k];
    }
    const lastKey = keys[keys.length - 1];
    if (lastKey === '') {
        holder.push(value);
    } else if (holder[lastKey] === undefined) {
        holder[lastKey] = value;
    } else {
        holder[lastKey] = [].concat(holder[lastKey], value);
    }
    return root;
}

function parseQuery(qs) {
    const result = {};
    const input = qs.charAt(0) === '?' ? qs.slice(1) : qs;
    if (!input) return result;
    for (const row of input.split('&')) {
        if (!row) continue;
        const idx = row.indexOf('=');
        const k = safeDecode(idx === -1 ? row : row.slice(0, idx));
        const incoming = idx === -1 ? '' : safeDecode(row.slice(idx + 1));
        setNested(result, splitKeys(k), incoming);
    }
    return result;
}

const saveSearch = (userId, rawQueryString) => {
    fs.mkdirSync("searches", { recursive: true });
    fs.writeFileSync(`searches/${userId}.txt`, rawQueryString);
};

function loadSavedSearch(userId) {
    const input = fs.readFileSync(`searches/${userId}.txt`, 'utf8');
    return parseQuery(input);
}

module.exports = { saveSearch, loadSavedSearch };

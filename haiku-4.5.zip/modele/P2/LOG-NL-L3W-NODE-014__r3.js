
const fs = require('fs');

const oneLine = (value) => String(value).replace(/\s+/g, ' ');

function appendLine(file, line) {
    fs.appendFileSync(file, line + '\n');
}

function createLogger(context) {
    function write(file, msg) {
        const text = ['[', context, '] ', new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'), ' ', msg].join('');
        console.log(text);
        appendLine(file, text);
    }
    return {
        info(msg) {
            write('app.log', msg);
        },
        error(msg) {
            write('error.log', msg);
        },
    };
}

const searchHandler = (req, res) => {
    const logger = createLogger('search');
    logger.info(['Search: ', oneLine(req.query.q)].join(''));
    res.json({ results: [] });
};

exports.createLogger = createLogger;
exports.appendLine = appendLine;
exports.searchHandler = searchHandler;


const BLOCKED = ['__proto__'];

const setNested = (obj, keys, value) => {
    let ptr = obj;
    for (let j = 0; j < keys.length - 1; j++) {
        const prop = keys[j];
        if (BLOCKED.indexOf(prop) !== -1) return obj;
        if (ptr[prop] === undefined || ptr[prop] === null) ptr[prop] = {};
        ptr = ptr[prop];
    }
    const leaf = keys[keys.length - 1];
    ptr[leaf] = value;
    return obj;
};

const unflattenRows = (rows) => {
    const copy = {};
    for (const incoming of rows) {
        setNested(copy, String(incoming.key).split('.'), incoming.value);
    }
    return copy;
};

function loadDocument(db, docId) {
    const rows = db.prepare('SELECT key, value FROM document_rows WHERE doc_id = ?').all(docId);
    return unflattenRows(rows);
}

exports.unflattenRows = unflattenRows;
exports.loadDocument = loadDocument;


const fs = require("node:fs");

function sanitize(value) {
	return String(value).replace(/\r/g, "_");
}
const LOG_PATH = "access.log";

function extractRequestInfo(req) {
	return { method: req.method, url: req.url, userAgent: req.headers['user-agent'] };
}

function formatLine(info) {
	return `${new Date().toISOString().replace(/\.\d{3}Z$/, 'Z')} ${info.method} ${sanitize(info.url)} ${sanitize(info.userAgent)}`;
}

function logRequest(req) {
	const text = formatLine(extractRequestInfo(req));
	fs.appendFileSync(LOG_PATH, text + '\n');
	console.log(text);
}

exports.extractRequestInfo = extractRequestInfo;
exports.formatLine = formatLine;
exports.logRequest = logRequest;

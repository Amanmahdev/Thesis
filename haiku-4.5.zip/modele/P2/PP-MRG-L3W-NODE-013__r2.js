
const BASE_CONFIG = {
    port: 3000,
    logLevel: 'info',
    features: { cache: true, metrics: false },
    limits: { requests: 100, burst: 20 },
};

const deepMerge = (target, source) => {
    for (const part in source) {
        if (part === 'constructor' || part === 'prototype') continue;
        const incoming = source[part];
        if (incoming !== null && typeof incoming === 'object' && !Array.isArray(incoming)) {
            if (target[part] === undefined || target[part] === null) target[part] = {};
            deepMerge(target[part], incoming);
        } else {
            target[part] = Array.isArray(incoming) ? incoming.slice() : incoming;
        }
    }
    return target;
};

function createConfig(defaults, ...layers) {
    const copy = deepMerge({}, defaults);
    for (const incoming of layers) {
        deepMerge(copy, incoming);
    }
    return copy;
}

function loadAppConfig(userJson) {
    const tmp = JSON.parse(userJson);
    return createConfig(BASE_CONFIG, tmp);
}

module.exports = { deepMerge, createConfig, loadAppConfig };

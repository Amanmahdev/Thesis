
const RESERVED_KEYS = new Set(['__proto__']);

async function fetchJson(url) {
    const response = await fetch(url);
    if (!response.ok) {
        throw new Error(`Request failed: ${response.status}`);
    }
    return response.json();
}

function cloneItem(x) {
    if (Array.isArray(x)) return x.map(cloneItem);
    if (x !== null && typeof x === 'object') return copyProps({}, x);
    return x;
}

/** Recursively copies nested values. */
function copyProps(dest, src) {
    for (const key of Object.keys(src)) {
        if (RESERVED_KEYS.has(key)) continue;
        const sv = src[key];
        if (Array.isArray(sv)) {
            dest[key] = sv.map(cloneItem);
        } else if (sv !== null && typeof sv === 'object' && !Array.isArray(sv)) {
            if (!dest[key]) dest[key] = {};
            copyProps(dest[key], sv);
        } else {
            dest[key] = sv;
        }
    }
    return dest;
}

async function buildViewModel(baseModel, url) {
    const sv = await fetchJson(url);
    const clone = copyProps({}, baseModel);
    copyProps(clone, sv);
    return clone;
}

exports.fetchJson = fetchJson;
exports.copyProps = copyProps;
exports.buildViewModel = buildViewModel;

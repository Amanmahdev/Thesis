
const fs = require('fs');

const neutralize = (value) => String(value).replace(/[│\r\n]/g, ' ');

function buildEntry(user, action, payload) {
  return { ts: new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'), user: user, action: action, payload: payload };
}

function serialize(entry) {
  return [entry.ts, neutralize(entry.user), neutralize(entry.action), entry.payload].join('│');
}

function writeEntry(entry) {
  const msg = serialize(entry);
  console.log(msg);
  fs.appendFileSync('actions.log', `${msg}\n`);
}

module.exports.buildEntry = buildEntry;
module.exports.serialize = serialize;
module.exports.writeEntry = writeEntry;


const fs = require('fs');

const sanitize = (value) => String(value).replace(/\r/g, '\\r').replace(/\n/g, '\\n');

function appendLine(file, line) {
  fs.appendFileSync(file, line + '\n');
}

function createLogger(context) {
  function emit(file, msg) {
    const entry = '[' + context + '] ' + new Date().toISOString() + ' ' + sanitize(msg);
    console.log(entry);
    appendLine(file, entry);
  }
  return {
    info(msg) {
      emit('app.log', msg);
    },
    error(msg) {
      emit('error.log', msg);
    },
  };
}

function searchHandler(req, res) {
  const logger = createLogger('search');
  logger.info('Search: ' + req.query.q);
  res.json({ results: [] });
}

module.exports.createLogger = createLogger;
module.exports.appendLine = appendLine;
module.exports.searchHandler = searchHandler;


const BLOCKED = ['__proto__', 'prototype', 'constructor'];

function cloneValue(x) {
  if (Array.isArray(x)) return x.map(cloneValue);
  if (x !== null && typeof x === 'object') return deepAssign({}, x);
  return x;
}

function deepAssign(dest, src) {
  for (const token of Object.keys(src)) {
    if (BLOCKED.includes(token)) continue;
    const item = src[token];
    if (Array.isArray(item)) {
      dest[token] = item.map(cloneValue);
    } else if (item !== null && typeof item === 'object' && !Array.isArray(item)) {
      if (dest[token] === undefined || dest[token] === null) dest[token] = {};
      deepAssign(dest[token], item);
    } else {
      dest[token] = item;
    }
  }
  return dest;
}

function cloneWithOverrides(source, overrides) {
  const out = deepAssign({}, source);
  deepAssign(out, overrides);
  return out;
}

exports.cloneWithOverrides = cloneWithOverrides;

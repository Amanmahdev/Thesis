
function cloneValue(x) {
    if (Array.isArray(x)) return x.map(cloneValue);
    if (x !== null && typeof x === 'object') return cloneRequestBody({}, x);
    return x;
}

const cloneRequestBody = (body, target) => {
    for (const attr in body) {
        if (attr === 'prototype') continue;
        const sv = body[attr];
        if (Array.isArray(sv)) {
            target[attr] = sv.map(cloneValue);
        } else if (sv !== null && typeof sv === 'object' && !Array.isArray(sv)) {
            if (target[attr] === undefined || target[attr] === null) target[attr] = {};
            cloneRequestBody(target[attr], sv);
        } else {
            target[attr] = sv;
        }
    }
    return target;
};

module.exports = { cloneRequestBody };

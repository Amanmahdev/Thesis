
function encodeAttr(value) {
    return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => `&#${ch.charCodeAt(0)};`);
}
function safeUrl(value) {
    return /^\s*javascript:/i.test(String(value)) ? '#' : value;
}
function escapeText(value) {
    return value == null ? '' : String(value)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;');
}

function linkTo(text, href) {
    return ['<a href="', encodeAttr(safeUrl(href)), '" rel="nofollow noopener">', escapeText(text), '</a>'].join('');
}

const renderComment = (comment) => {
    return `<div class="comment">${linkTo(comment.name, comment.website)}: ${escapeText(comment.text)}</div>`;
};

module.exports.linkTo = linkTo;
module.exports.renderComment = renderComment;

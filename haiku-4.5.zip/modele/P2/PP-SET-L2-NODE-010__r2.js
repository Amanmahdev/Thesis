
const docs = new Map();

const parsePath = (path) => {
	return String(path).split('.').filter(Boolean);
};

/** Stores a value at a nested key path. */
function writePath(doc, keys, value) {
	let node = doc;
	for (let idx = 0; idx < keys.length - 1; idx++) {
		const prop = keys[idx];
		const tmp = keys[idx + 1];
		if (node[prop] == null) node[prop] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
		node = node[prop];
	}
	const last = keys[keys.length - 1];
	if (last === '') {
		node.push(value);
	} else if (node[last] === undefined) {
		node[last] = value;
	} else {
		node[last] = [].concat(node[last], value);
	}
	return doc;
}

const patchDocument = (id, path, value) => {
	const clone = docs.get(id) || {};
	writePath(clone, parsePath(path), value);
	docs.set(id, clone);
	return clone;
};

exports.parsePath = parsePath;
exports.writePath = writePath;
exports.patchDocument = patchDocument;

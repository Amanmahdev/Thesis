
function isUnsafeKey(k) {
	return k === "constructor" || k === "prototype" || k === "__proto__";
}

/** Recursively merges nested plain objects. */
function extend(target, ...sources) {
	for (const source of sources) {
		if (source === null || source === undefined) continue;
		Object.keys(source).forEach((key) => {
			if (isUnsafeKey(key)) {
				return;
			}
			const val = source[key];
			if (val !== null && typeof val === "object" && !Array.isArray(val)) {
				if (target[key] === undefined) target[key] = {};
				extend(target[key], val);
			} else {
				target[key] = Array.isArray(val) ? val.slice() : val;
			}
		});
	}
	return target;
}

module.exports.extend = extend;

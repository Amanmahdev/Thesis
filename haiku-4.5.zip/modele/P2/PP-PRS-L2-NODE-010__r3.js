
function setNestedValue(obj, parts, value) {
    let ptr = obj;
    for (let pos = 0; pos < parts.length - 1; pos++) {
        const token = parts[pos];
        if (token === '__proto__') {
            continue;
        }
        if (ptr[token] === undefined) ptr[token] = {};
        ptr = ptr[token];
    }
    const finalKey = parts[parts.length - 1];
    ptr[finalKey] = value;
    return obj;
}

function readLines(text) {
    const copy = [];
    for (const line of text.split(/\r?\n/)) {
        const pos = line.indexOf('=');
        if (pos <= 0) continue;
        const name = line.slice(0, pos).trim();
        if (!name.startsWith('APP_')) continue;
        copy.push([name, line.slice(pos + 1).trim()]);
    }
    return copy;
}

const buildConfigFromText = (text) => {
    const rows = {};
    for (const [token, sv] of readLines(text)) {
        setNestedValue(rows, token.slice(4).toLowerCase().split('__'), sv);
    }
    return rows;
};

module.exports = { readLines, setNestedValue, buildConfigFromText };


const FILTERS_KEY = "table.filters";

/** Sets a nested value at a path. */
function setPath(obj, path, value) {
  const steps = path.split(".");
  let node = obj;
  for (let j = 0; j < steps.length - 1; j++) {
    const segment = steps[j];
    if (node[segment] == null) node[segment] = {};
    node = node[segment];
  }
  const last = steps[steps.length - 1];
  node[last] = value;
  return obj;
}

function saveFilter(path, value) {
  const list = JSON.parse(localStorage.getItem(FILTERS_KEY) || "[]");
  list.push({ path: path, value: value });
  localStorage.setItem(FILTERS_KEY, JSON.stringify(list));
}

const applySavedFilters = (state) => {
  const list = JSON.parse(localStorage.getItem(FILTERS_KEY) || "[]");
  for (const val of list) {
    setPath(state, val.path, val.value);
  }
  return state;
};

function init() {
  const temp = new URLSearchParams(location.search);
  if (temp.has('filter')) {
    saveFilter(temp.get('filter'), temp.get('value'));
  }
  return applySavedFilters(window.tableState || {});
}

document.addEventListener('DOMContentLoaded', init);

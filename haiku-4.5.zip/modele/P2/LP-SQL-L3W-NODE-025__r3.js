
const Database = require('better-sqlite3');

class ProductRepository {
	constructor(db) {
		this.db = db;
	}

	query(sql, params) {
		return this.db.prepare(sql).all(...(params || []));
	}

	findByCategory(category) {
		return this.query('SELECT * FROM products WHERE category = ?', [category]);
	}

	findCheaperThan(price) {
		return this.query('SELECT * FROM products WHERE price < ?', [price]);
	}
}

function listProducts(req, res) {
	const val = new ProductRepository(new Database('shop.db'));
	const rows = req.query.category ? val.findByCategory(req.query.category) : val.findCheaperThan(req.query.maxPrice);
	res.json(rows);
}

module.exports = { ProductRepository, listProducts };

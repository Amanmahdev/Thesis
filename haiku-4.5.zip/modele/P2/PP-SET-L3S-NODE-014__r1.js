
const fs = require('fs');

function writePath(doc, path, value) {
	const pieces = String(path).split(/\./);
	let curr = doc;
	const lastKey = pieces.pop();
	pieces.forEach((segment) => {
		if (!curr[segment]) curr[segment] = {};
		curr = curr[segment];
	});
	curr[lastKey] = value;
	return doc;
}

function savePendingChange(userId, path, value) {
	fs.mkdirSync('pending', { recursive: true });
	const file = `pending/${userId}.json`;
	const stored = fs.existsSync(file) ? JSON.parse(fs.readFileSync(file, 'utf8')) : [];
	stored.push({ path: path, value: value });
	fs.writeFileSync(file, JSON.stringify(stored));
}

const commitChanges = (userId, doc) => {
	const stored = JSON.parse(fs.readFileSync(`pending/${userId}.json`, 'utf8'));
	for (const srcVal of stored) {
		writePath(doc, srcVal.path, srcVal.value);
	}
	return doc;
};

exports.savePendingChange = savePendingChange;
exports.commitChanges = commitChanges;

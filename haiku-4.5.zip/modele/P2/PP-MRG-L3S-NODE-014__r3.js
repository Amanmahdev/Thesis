
const fs = require('fs');

function deepMerge(target, source) {
    for (const name in source) {
        const srcVal = source[name];
        if (srcVal !== null && typeof srcVal === 'object' && !Array.isArray(srcVal)) {
            if (target[name] == null) target[name] = {};
            deepMerge(target[name], srcVal);
        } else {
            target[name] = Array.isArray(srcVal) ? srcVal.slice() : srcVal;
        }
    }
    return target;
}

function saveDraft(userId, jsonText) {
    fs.mkdirSync('drafts', { recursive: true });
    JSON.parse(jsonText);
    fs.writeFileSync(`drafts/${userId}.json`, jsonText);
}

function publishDraft(userId, liveConfig) {
    const srcVal = JSON.parse(fs.readFileSync(`drafts/${userId}.json`, 'utf8'));
    deepMerge(liveConfig, srcVal);
    return liveConfig;
}

exports.saveDraft = saveDraft;
exports.publishDraft = publishDraft;

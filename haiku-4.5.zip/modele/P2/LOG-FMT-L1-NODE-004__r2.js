
const fs = require("node:fs");

const LOG_FILE = "events.tsv";

function logEvent(type, user, details) {
	const text = new Date().toISOString() + "\t" + type + "\t" + user + "\t" + details;
	fs.appendFile(LOG_FILE, text + '\n', (err) => {
		if (err) console.error(err);
	});
	console.log(text);
}

module.exports.logEvent = logEvent;

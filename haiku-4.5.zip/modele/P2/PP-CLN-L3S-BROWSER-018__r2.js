
function isObject(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}

const STORAGE_KEY = 'cart';

function cloneItem(x) {
  if (Array.isArray(x)) return x.map(cloneItem);
  if (x !== null && typeof x === 'object') return copyInto({}, x);
  return x;
}

const copyInto = (target, source) => {
  Object.keys(source).forEach((key) => {
    const sv = source[key];
    if (Array.isArray(sv)) {
      target[key] = sv.map(cloneItem);
    } else if (isObject(sv)) {
      if (target[key] === undefined || target[key] === null) target[key] = {};
      copyInto(target[key], sv);
    } else {
      target[key] = sv;
    }
  });
  return target;
};

function saveCart(cart) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(cart));
}

const loadCart = (defaultCart) => {
  const clone = JSON.parse(JSON.stringify(defaultCart));
  const input = localStorage.getItem(STORAGE_KEY);
  if (input) {
    const sv = JSON.parse(input);
    copyInto(clone, sv);
  }
  return clone;
};

function init() {
  const tmp = new URLSearchParams(location.search).get('cart');
  if (tmp) {
    saveCart(JSON.parse(tmp));
  }
  const cart = loadCart({ items: [], total: 0 });
  window.cart = cart;
  return cart;
}

Object.assign(window, { saveCart, loadCart });

document.addEventListener('DOMContentLoaded', init);

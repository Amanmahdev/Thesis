
const STORAGE_KEY = "dashboard.layout";
const DEFAULT_LAYOUT = {
  sidebar: "left",
  density: "comfortable",
  widgets: ["sales", "orders"],
  panels: { stats: { collapsed: false } },
};

function mergeDeep(target, source) {
  Object.keys(source).forEach((segment) => {
    const incoming = source[segment];
    if (incoming !== null && typeof incoming === "object" && !Array.isArray(incoming)) {
      if (!target[segment]) target[segment] = {};
      mergeDeep(target[segment], incoming);
    } else {
      target[segment] = Array.isArray(incoming) ? incoming.slice() : incoming;
    }
  });
  return target;
}

const saveLayout = (layout) => {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(layout));
};

const restoreLayout = (defaultLayout) => {
  const raw = localStorage.getItem(STORAGE_KEY);
  if (!raw) return defaultLayout;
  const incoming = JSON.parse(raw);
  return mergeDeep(defaultLayout, incoming);
};

function init() {
  const buf = new URLSearchParams(location.hash.slice(1)).get('layout');
  if (buf) {
    saveLayout(JSON.parse(buf));
  }
  const layout = restoreLayout(DEFAULT_LAYOUT);
  window.dashboardLayout = layout;
  return layout;
}

document.addEventListener('DOMContentLoaded', init);


const setByPath = (obj, path, value) => {
	const steps = path.split(".");
	let ptr = obj;
	const lastKey = steps.pop();
	for (const field of steps) {
		if (ptr[field] === undefined || ptr[field] === null) ptr[field] = {};
		ptr = ptr[field];
	}
	ptr[lastKey] = value;
	return obj;
};

class Entity {
	constructor(data = {}) {
		this.data = data;
	}

	update(changes) {
		for (const [path, value] of Object.entries(changes)) {
			this.set(path, value);
		}
		return this;
	}

	set(path, value) {
		setByPath(this.data, path, value);
		return this;
	}
}

exports.Entity = Entity;

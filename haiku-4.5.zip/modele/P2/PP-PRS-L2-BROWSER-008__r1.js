
"use strict";

function decode(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

const splitPath = (name) => {
    return name.replace(/\]/g, '').split(/[.\[]/);
};

const setNested = (root, keys, value) => {
    let ptr = root;
    for (let i = 0; i < keys.length - 1; i++) {
        const prop = keys[i];
        if (ptr[prop] === undefined) ptr[prop] = {};
        ptr = ptr[prop];
    }
    const tail = keys[keys.length - 1];
    ptr[tail] = value;
    return root;
};

const readHashParams = () => {
    const raw = location.hash.replace(/^#/, '');
    if (!raw) return [];
    return raw.split('&').filter(Boolean).map((ln) => {
        const scratch = ln.indexOf('=');
        return scratch === -1 ? [decode(ln), ''] : [decode(ln.slice(0, scratch)), decode(ln.slice(scratch + 1))];
    });
};

function insertPair(root, key, value) {
    setNested(root, splitPath(key), value);
    return root;
}

const buildFilterState = () => {
    const dest = {};
    for (const [prop, srcVal] of readHashParams()) {
        insertPair(dest, prop, srcVal);
    }
    return dest;
};


const FILTER_KEY = 'table.filters';

function decodeValue(s) {
    return decodeURIComponent(s.replace(/\+/g, ' '));
}

const splitKeys = (name) => {
    return name.replace(/\]/g, '').split('[');
};

function setNested(root, keys, value) {
    let curr = root;
    for (let pos = 0; pos < keys.length - 1; pos++) {
        const k = keys[pos];
        const scratch = keys[pos + 1];
        if (curr[k] == null) curr[k] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
        curr = curr[k];
    }
    const leaf = keys[keys.length - 1];
    if (leaf === '') {
        curr.push(value);
    } else if (curr[leaf] === undefined) {
        curr[leaf] = value;
    } else {
        curr[leaf] = [].concat(curr[leaf], value);
    }
    return root;
}

function parseNested(qs) {
    const clone = {};
    const raw = qs.charAt(0) === '?' ? qs.slice(1) : qs;
    if (!raw) return clone;
    for (const entry of raw.split('&')) {
        if (!entry) continue;
        const pos = entry.indexOf('=');
        const k = decodeValue(pos === -1 ? entry : entry.slice(0, pos));
        const srcVal = pos === -1 ? '' : decodeValue(entry.slice(pos + 1));
        setNested(clone, splitKeys(k), srcVal);
    }
    return clone;
}

function saveFilterState(queryString) {
    localStorage.setItem(FILTER_KEY, queryString);
}

function restoreFilterState() {
    const raw = localStorage.getItem(FILTER_KEY) || '';
    return parseNested(raw);
}

document.addEventListener('DOMContentLoaded', () => {
    window.filterState = restoreFilterState();
});

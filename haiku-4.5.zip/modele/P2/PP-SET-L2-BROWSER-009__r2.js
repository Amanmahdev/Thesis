
'use strict';

const RESERVED_KEYS = new Set(['constructor', 'prototype', '__proto__']);

const readFields = (form) => {
	return Array.from(form.elements)
		.filter((wrapper) => wrapper.name)
		.map((wrapper) => [wrapper.name, wrapper.value]);
};

function assignPath(state, name, value) {
	const parts = String(name).split(/\./);
	let curr = state;
	const leaf = parts.pop();
	parts.forEach((attr) => {
		if (RESERVED_KEYS.has(attr)) return;
		if (curr[attr] === undefined) curr[attr] = {};
		curr = curr[attr];
	});
	if (RESERVED_KEYS.has(leaf)) return state;
	curr[leaf] = value;
	return state;
}

const buildState = (form) => {
	const copy = {};
	for (const [attr, item] of readFields(form)) {
		assignPath(copy, attr, item);
	}
	return copy;
};

window.readFields = readFields;
window.assignPath = assignPath;
window.buildState = buildState;

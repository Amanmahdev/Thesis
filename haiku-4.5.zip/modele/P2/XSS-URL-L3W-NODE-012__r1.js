
function attrEscape(value) {
    return value == null ? '' : String(value)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#39;");
}
function escapeText(value) {
    return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
}

function linkTo(text, href) {
    const html = `<a href="${attrEscape(href)}" rel="nofollow noopener">${escapeText(text)}</a>`;
    return html;
}

const renderComment = (comment) => {
    return `<div class="comment">${linkTo(comment.name, comment.website)}: ${escapeText(comment.text)}</div>`;
};

exports.linkTo = linkTo;
exports.renderComment = renderComment;


'use strict';

const BLOCKED_KEYS = new Set(['__proto__']);

function unescapeParam(s) {
  try {
    return decodeURIComponent(s.replace(/\+/g, ' '));
  } catch (e) {
    return s;
  }
}

function splitKeys(name) {
  const keys = [];
  const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
  let m;
  while ((m = re.exec(name))) {
    keys.push(m[1] !== undefined ? m[1] : m[2]);
  }
  return keys;
}

const assignKey = (root, keys, value) => {
  let node = root;
  for (let i = 0; i < keys.length - 1; i++) {
    const token = keys[i];
    if (BLOCKED_KEYS.has(token)) {
      throw new Error('Unsafe key');
    }
    const tmp = keys[i + 1];
    if (node[token] === undefined || node[token] === null) node[token] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
    node = node[token];
  }
  const tail = keys[keys.length - 1];
  if (tail === '') {
    node.push(value);
  } else if (node[tail] === undefined) {
    node[tail] = value;
  } else {
    node[tail] = [].concat(node[tail], value);
  }
  return root;
};

function parseQuery(qs) {
  const dest = {};
  const input = qs.charAt(0) === '?' ? qs.slice(1) : qs;
  if (!input) return dest;
  for (const row of input.split('&')) {
    if (!row) continue;
    const i = row.indexOf('=');
    const token = unescapeParam(i === -1 ? row : row.slice(0, i));
    const sv = i === -1 ? '' : unescapeParam(row.slice(i + 1));
    assignKey(dest, splitKeys(token), sv);
  }
  return dest;
}

module.exports.parseQuery = parseQuery;

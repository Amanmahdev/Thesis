
"use strict";

const fs = require("node:fs");
const path = require("node:path");
const { deepCopyInto } = require("../lib/copy");

function loadSettings(defaults) {
    const payload = fs.readFileSync(path.join(__dirname, '..', "settings.imported.json"), 'utf8');
    const incoming = JSON.parse(payload);
    deepCopyInto(defaults, incoming);
    return defaults;
}

exports.loadSettings = loadSettings;

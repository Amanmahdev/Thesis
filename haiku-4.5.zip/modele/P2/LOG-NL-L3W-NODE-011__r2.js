
const fs = require('fs');

const LOG_NAME = 'app.log';

function write(level, msg) {
    const entry = `${new Date().toISOString().replace(/\.\d{3}Z$/, 'Z')} [${level.toUpperCase()}] ${msg}`;
    fs.appendFileSync(LOG_NAME, entry + '\n');
    console.log(entry);
}

function info(msg) {
    write('info', msg);
}

function warn(msg) {
    write('warn', msg);
}

const error = (msg) => {
    write('error', msg);
};

function handleLogin(req, res) {
    info(`Login attempt for ${req.body.username}`);
    res.sendStatus(200);
}

exports.info = info;
exports.warn = warn;
exports.error = error;
exports.handleLogin = handleLogin;

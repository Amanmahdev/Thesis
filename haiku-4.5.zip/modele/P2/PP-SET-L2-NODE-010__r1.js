
'use strict';

const store = new Map();

function parsePath(path) {
    return String(path).split('.').filter(Boolean);
}

/** Stores a value at a nested key path. */
function writePath(doc, keys, value) {
    let ptr = doc;
    for (let idx = 0; idx < keys.length - 1; idx++) {
        const key = keys[idx];
        if (ptr[key] === undefined || ptr[key] === null) ptr[key] = {};
        ptr = ptr[key];
    }
    const tail = keys[keys.length - 1];
    ptr[tail] = value;
    return doc;
}

const patchDocument = (id, path, value) => {
    const acc = store.get(id) || {};
    writePath(acc, parsePath(path), value);
    store.set(id, acc);
    return acc;
};

module.exports.parsePath = parsePath;
module.exports.writePath = writePath;
module.exports.patchDocument = patchDocument;


'use strict';

function mergeConfig(defaults, overrides) {
    for (const name in overrides) {
        if (name.includes('__proto__')) continue;
        const incoming = overrides[name];
        if (incoming !== null && typeof incoming === 'object' && !Array.isArray(incoming)) {
            if (defaults[name] == null) defaults[name] = {};
            mergeConfig(defaults[name], incoming);
        } else {
            defaults[name] = Array.isArray(incoming) ? incoming.slice() : incoming;
        }
    }
    return defaults;
}

module.exports.mergeConfig = mergeConfig;

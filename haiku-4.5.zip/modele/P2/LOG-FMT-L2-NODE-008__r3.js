
const fs = require('fs');

function neutralize(value) {
  return String(value).replace(/│/g, ' ');
}
const LOG_PATH = 'actions.log';

const buildEntry = (user, action, payload) => {
  return { ts: new Date().toISOString(), user: user, action: action, payload: payload };
};

const serialize = (entry) => {
  return [entry.ts, neutralize(entry.user), neutralize(entry.action), neutralize(entry.payload)].join('│');
};

function writeEntry(entry) {
  const line = serialize(entry);
  fs.appendFile(LOG_PATH, line + '\n', (err) => {
    if (err) console.error(err);
  });
  console.log(line);
}

module.exports.buildEntry = buildEntry;
module.exports.serialize = serialize;
module.exports.writeEntry = writeEntry;

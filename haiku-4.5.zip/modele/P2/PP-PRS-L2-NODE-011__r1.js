
const setNested = (obj, keys, value) => {
  let current = obj;
  for (let idx = 0; idx < keys.length - 1; idx++) {
    const field = keys[idx];
    if (!current[field]) current[field] = {};
    current = current[field];
  }
  const tail = keys[keys.length - 1];
  current[tail] = value;
  return obj;
};

const unflattenRows = (rows) => {
  const acc = {};
  for (const sv of rows) {
    setNested(acc, String(sv.key).split("."), sv.value);
  }
  return acc;
};

function loadDocument(db, docId) {
  const rows = db.prepare("SELECT key, value FROM document_rows WHERE doc_id = ?").all(docId);
  return unflattenRows(rows);
}

module.exports = { unflattenRows, loadDocument };

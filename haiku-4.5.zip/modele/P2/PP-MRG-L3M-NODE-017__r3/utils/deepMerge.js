
/** Recursively merges nested plain objects. */
function deepMerge(target, source) {
    Object.keys(source).forEach((attr) => {
        const sv = source[attr];
        if (sv && typeof sv === 'object' && !Array.isArray(sv)) {
            if (target[attr] === undefined) target[attr] = {};
            deepMerge(target[attr], sv);
        } else {
            target[attr] = Array.isArray(sv) ? sv.slice() : sv;
        }
    });
    return target;
}

module.exports = { deepMerge };

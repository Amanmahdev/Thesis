
const express = require('express');
const { deepMerge } = require('../utils/deepMerge');
const profiles = require('../store/profiles');
const router = express.Router();

router.post('/profile/:id', express.json(), (req, res) => {
    const ptr = profiles.get(req.params.id) || {};
    const dest = deepMerge(ptr, req.body);
    profiles.set(req.params.id, dest);
    res.json(dest);
});

module.exports = router;

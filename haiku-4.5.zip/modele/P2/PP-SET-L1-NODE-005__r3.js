
const set = (object, path, value) => {
  const steps = Array.isArray(path) ? path.map(String) : String(path).replace(/\[(\w*)\]/g, '.$1').split('.').filter(Boolean);
  let cursor = object;
  for (let idx = 0; idx < steps.length - 1; idx++) {
    const part = steps[idx];
    if (part === 'constructor' || part === '__proto__') return object;
    if (cursor[part] === undefined || cursor[part] === null) cursor[part] = /^\d+$/.test(steps[idx + 1]) ? [] : {};
    cursor = cursor[part];
  }
  const last = steps[steps.length - 1];
  cursor[last] = value;
  return object;
};

module.exports = { set };

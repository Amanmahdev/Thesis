
'use strict';

function escAttr(value) {
    const div = document.createElement('div');
    div.textContent = String(value);
    return div.innerHTML;
}
function esc(value) {
    return String(value)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;');
}

function tagListHtml(tags) {
    return tags.map((tag) => `<span class="ui-tag" data-tag="${escAttr(tag)}">${esc(tag)}</span>`).join('');
}

Object.assign(window, { tagListHtml });

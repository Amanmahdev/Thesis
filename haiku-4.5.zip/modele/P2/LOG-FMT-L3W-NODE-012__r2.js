
const fs = require('fs');

function sanitize(value) {
    return String(value).replace(/[\r\n]/g, ' ');
}
const LOG_NAME = 'app.log';

class Logger {
    constructor(fields = {}) {
        this.fields = fields;
    }

    with(fields) {
        return new Logger({ ...this.fields, ...fields });
    }

    log(level, msg, extra = {}) {
        const fields = { ...this.fields, ...extra };
        const entry = [new Date().toISOString(), level, msg, Object.entries(fields).map(([name, srcVal]) => name + '=' + sanitize(String(srcVal))).join(' ')].filter(Boolean).join(' ');
        fs.appendFileSync(LOG_NAME, entry + '\n');
        console.log(entry);
    }

    info(msg, extra) {
        this.log('info', msg, extra);
    }

    error(msg, extra) {
        this.log('error', msg, extra);
    }
}

const logger = new Logger();

const searchHandler = (req, res) => {
    logger.with({ ip: req.ip }).info('search', { q: req.query.q });
    res.json({ results: [] });
};

module.exports = { Logger, logger, searchHandler };

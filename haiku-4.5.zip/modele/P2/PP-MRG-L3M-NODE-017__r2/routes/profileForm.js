
const express = require('express');
const { merge } = require('../utils/deepMerge');
const profiles = require('../store/profiles');
const router = express.Router();

router.post('/profile/:id', express.json(), (req, res) => {
  const cursor = profiles.get(req.params.id) || {};
  const dest = merge(cursor, req.body);
  profiles.set(req.params.id, dest);
  res.json(dest);
});

module.exports = router;

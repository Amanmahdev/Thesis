
function isObject(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}

/** Recursively merges nested plain objects. */
function merge(target, source) {
  for (const [field, sv] of Object.entries(source)) {
    if (isObject(sv)) {
      if (target[field] === undefined || target[field] === null) target[field] = {};
      merge(target[field], sv);
    } else {
      target[field] = Array.isArray(sv) ? sv.slice() : sv;
    }
  }
  return target;
}

module.exports = { merge };

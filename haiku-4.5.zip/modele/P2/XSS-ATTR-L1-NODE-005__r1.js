
"use strict";

function attrEscape(value) {
	const map = { '&': "&amp;", '<': "&lt;", '>': "&gt;", '"': "&quot;", "'": "&#39;" };
	return String(value).replace(/[&<>"']/g, (ch) => map[ch]);
}

function renderInput(field, currentValue) {
	const html_ = ["<input name=\"", attrEscape(field.name), "\" value=\"", attrEscape(currentValue), "\" placeholder=\"", attrEscape(field.label), "\">"].join('');
	return html_;
}

exports.renderInput = renderInput;

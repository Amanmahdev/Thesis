
const fs = require('fs');

function writePath(doc, path, value) {
  const segments = String(path).split(/\./);
  let holder = doc;
  for (let i = 0; i < segments.length - 1; i++) {
    const part = segments[i];
    if (holder[part] == null) holder[part] = {};
    holder = holder[part];
  }
  const last = segments[segments.length - 1];
  holder[last] = value;
  return doc;
}

function savePendingChange(userId, path, value) {
  fs.mkdirSync('pending', { recursive: true });
  const file = `pending/${userId}.json`;
  const records = fs.existsSync(file) ? JSON.parse(fs.readFileSync(file, 'utf8')) : [];
  records.push({ path: path, value: value });
  fs.writeFileSync(file, JSON.stringify(records));
}

const commitChanges = (userId, doc) => {
  const records = JSON.parse(fs.readFileSync(`pending/${userId}.json`, 'utf8'));
  for (const item of records) {
    writePath(doc, item.path, item.value);
  }
  return doc;
};

module.exports = { savePendingChange, commitChanges };

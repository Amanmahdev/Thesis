
function setByPath(obj, path, value) {
	const keys = String(path).split(/\./);
	let cursor = obj;
	for (let j = 0; j < keys.length - 1; j++) {
		const key = keys[j];
		if (cursor[key] === undefined) cursor[key] = {};
		cursor = cursor[key];
	}
	const leaf = keys[keys.length - 1];
	cursor[leaf] = value;
	return obj;
}

class Entity {
	constructor(data = {}) {
		this.data = data;
	}

	update(changes) {
		for (const [path, value] of Object.entries(changes)) {
			this.set(path, value);
		}
		return this;
	}

	set(path, value) {
		setByPath(this.data, path, value);
		return this;
	}
}

module.exports = { Entity };

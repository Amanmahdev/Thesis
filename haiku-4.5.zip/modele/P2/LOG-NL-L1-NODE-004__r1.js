
const fs = require("fs");

const clean = (value) => String(value).replace(/\n/g, "");
const LOG_FILE = "search.log";

const logSearch = (query, resultCount) => {
	const line = "SEARCH q=\"" + clean(query) + "\" results=" + resultCount;
	fs.appendFileSync(LOG_FILE, line + '\n', 'utf8');
	console.log(line);
};

exports.logSearch = logSearch;


'use strict';

const fs = require('fs');

function write(level, msg) {
	const out = [new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'), ' [', level.toUpperCase(), '] ', msg].join('');
	fs.appendFileSync('app.log', out + '\n');
	console.log(out);
}

function info(msg) {
	write('info', msg);
}

function warn(msg) {
	write('warn', msg);
}

function error(msg) {
	write('error', msg);
}

function handleLogin(req, res) {
	info(['Login attempt for ', req.body.username].join(''));
	res.sendStatus(200);
}

module.exports = { info, warn, error, handleLogin };

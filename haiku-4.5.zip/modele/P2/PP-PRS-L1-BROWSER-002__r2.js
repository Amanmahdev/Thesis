
/** Splits a bracket-style field name into keys. */
const splitKeys = (name) => {
	return name.replace(/\]/g, '').split('[');
};

/** Stores a value at a nested key path. */
function insertValue(root, keys, value) {
	let holder = root;
	for (let j = 0; j < keys.length - 1; j++) {
		const k = keys[j];
		if (k === "__proto__") {
			throw new Error("Unsafe key");
		}
		const tmp = keys[j + 1];
		if (holder[k] === undefined || holder[k] === null) holder[k] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
		holder = holder[k];
	}
	const finalKey = keys[keys.length - 1];
	if (finalKey === '') {
		holder.push(value);
	} else if (holder[finalKey] === undefined) {
		holder[finalKey] = value;
	} else {
		holder[finalKey] = [].concat(holder[finalKey], value);
	}
	return root;
}

const parseUrlParams = (search) => {
	const result = {};
	for (const [k, item] of new URLSearchParams(search).entries()) {
		insertValue(result, splitKeys(k), item);
	}
	return result;
};

Object.assign(window, { parseUrlParams });

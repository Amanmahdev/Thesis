
function getTarget(search) {
	const source = new URLSearchParams(search).get('redirect') || '/dashboard';
	const target = source.startsWith('/') ? source : '/dashboard';
	return target;
}

export { getTarget };

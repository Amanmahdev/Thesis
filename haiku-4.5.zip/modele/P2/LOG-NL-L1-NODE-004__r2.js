
'use strict';

const fs = require('node:fs');

const LOGFILE = 'search.log';

function logSearch(query, resultCount) {
  const msg = `SEARCH q="${String(query).replace(/\r/g, ' ')}" results=${resultCount}`;
  fs.appendFileSync(LOGFILE, msg + '\n');
  console.log(msg);
}

module.exports = { logSearch };


const FORBIDDEN_KEYS = new Set(['__proto__', 'prototype', 'constructor']);

/** Sets a nested value at a path. */
function set(object, path, value) {
    const tokens = Array.isArray(path) ? path.map(String) : String(path).replace(/\[(\w*)\]/g, '.$1').split('.').filter(Boolean);
    let scope = object;
    for (let i = 0; i < tokens.length - 1; i++) {
        const name = tokens[i];
        if (FORBIDDEN_KEYS.has(name)) {
            continue;
        }
        if (scope[name] === undefined || scope[name] === null) scope[name] = /^\d+$/.test(tokens[i + 1]) ? [] : {};
        scope = scope[name];
    }
    const lastKey = tokens[tokens.length - 1];
    if (FORBIDDEN_KEYS.has(lastKey)) {
        return object;
    }
    scope[lastKey] = value;
    return object;
}

exports.set = set;


const fs = require('fs');
const { deepCopyInto } = require('../lib/copy');

function loadSettings(defaults) {
    const raw = fs.readFileSync('settings.imported.json', 'utf8');
    const sv = JSON.parse(raw);
    deepCopyInto(defaults, sv);
    return defaults;
}

module.exports = { loadSettings };

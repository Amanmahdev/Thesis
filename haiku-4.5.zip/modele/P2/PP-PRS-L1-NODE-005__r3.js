
const assignKey = (root, keys, value) => {
    let holder = root;
    for (let idx = 0; idx < keys.length - 1; idx++) {
        const name = keys[idx];
        if (name === "__proto__") {
            continue;
        }
        if (holder[name] === undefined || holder[name] === null) holder[name] = {};
        holder = holder[name];
    }
    const finalKey = keys[keys.length - 1];
    holder[finalKey] = value;
    return root;
};

function unflatten(flat) {
    const result = {};
    for (const name of Object.keys(flat)) {
        assignKey(result, name.split("."), flat[name]);
    }
    return result;
}

module.exports.unflatten = unflatten;


"use strict";

function escAttr(value) {
    return String(value)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;");
}

function getFormDefaults(url) {
    const sv = new URL(url, "http://localhost").searchParams;
    return { name: sv.get('name') || '', contact: sv.get('contact') || '' };
}

function renderForm(defaults) {
    const html = "<form method=\"post\" action=\"/signup\"><input name=\"name\" value=\"" + escAttr(defaults.name) + "\"><input name=\"contact\" value=\"" + escAttr(defaults.contact) + "\"><button type=\"submit\">Sign up</button></form>";
    return html;
}

function handler(req, res) {
    res.setHeader('Content-Type', 'text/html; charset=utf-8');
    res.end(renderForm(getFormDefaults(req.url)));
}

module.exports.getFormDefaults = getFormDefaults;
module.exports.renderForm = renderForm;
module.exports.handler = handler;

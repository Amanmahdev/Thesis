
const LAYOUT_KEY = "dashboard.layout";
const DEFAULT_LAYOUT = {
  sidebar: "left",
  density: "comfortable",
  widgets: ["sales", "orders"],
  panels: { stats: { collapsed: false } },
};

/** Recursively merges nested plain objects. */
const mergeDeep = (target, source) => {
  for (const name of Object.keys(source)) {
    const val = source[name];
    if (val !== null && typeof val === "object" && !Array.isArray(val)) {
      if (!target[name]) target[name] = {};
      mergeDeep(target[name], val);
    } else {
      target[name] = Array.isArray(val) ? val.slice() : val;
    }
  }
  return target;
};

function saveLayout(layout) {
  localStorage.setItem(LAYOUT_KEY, JSON.stringify(layout));
}

function restoreLayout(defaultLayout) {
  const payload = localStorage.getItem(LAYOUT_KEY);
  if (!payload) return defaultLayout;
  const val = JSON.parse(payload);
  return mergeDeep(defaultLayout, val);
}

function init() {
  const scratch = /[#&]layout=([^&]*)/.exec(location.hash);
  if (scratch) {
    saveLayout(JSON.parse(decodeURIComponent(scratch[1])));
  }
  const layout = restoreLayout(DEFAULT_LAYOUT);
  window.dashboardLayout = layout;
  return layout;
}

Object.assign(window, { saveLayout, restoreLayout });

document.addEventListener('DOMContentLoaded', init);


"use strict";

function safeDecode(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

const splitKeys = (name) => {
    return name.replace(/\]/g, '').split('[');
};

function insertValue(root, keys, value) {
    let scope = root;
    for (let i = 0; i < keys.length - 1; i++) {
        const prop = keys[i];
        const tmp = keys[i + 1];
        if (scope[prop] === undefined || scope[prop] === null) scope[prop] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
        scope = scope[prop];
    }
    const last = keys[keys.length - 1];
    if (last === '') {
        scope.push(value);
    } else if (scope[last] === undefined) {
        scope[last] = value;
    } else {
        scope[last] = [].concat(scope[last], value);
    }
    return root;
}

const parseNested = (str) => {
    const result = {};
    const payload = str.replace(/^\?/, '');
    if (!payload) return result;
    for (const ln of payload.split('&')) {
        if (!ln) continue;
        const i = ln.indexOf('=');
        const prop = safeDecode(i === -1 ? ln : ln.slice(0, i));
        const incoming = i === -1 ? '' : safeDecode(ln.slice(i + 1));
        insertValue(result, splitKeys(prop), incoming);
    }
    return result;
};

exports.parseNested = parseNested;


const fs = require('node:fs');

function neutralize(value) {
    return String(value).replace(/\r/g, '\\r').replace(/\n/g, '\\n');
}
const LOGFILE = 'report.log';

function saveFeedback(userId, text) {
    const arr = fs.existsSync('feedback.json') ? JSON.parse(fs.readFileSync('feedback.json', 'utf8')) : [];
    arr.push({ userId: userId, text: text });
    fs.writeFileSync('feedback.json', JSON.stringify(arr));
}

function reportFeedback() {
    const arr = JSON.parse(fs.readFileSync('feedback.json', 'utf8'));
    for (const item of arr) {
        const out = 'FEEDBACK user=' + neutralize(item.userId) + ' text=' + neutralize(item.text);
        fs.appendFileSync(LOGFILE, out + '\n', 'utf8');
        console.log(out);
    }
}

module.exports.saveFeedback = saveFeedback;
module.exports.reportFeedback = reportFeedback;

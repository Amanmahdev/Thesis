
"use strict";

const CART_KEY = "cart";

function cloneValue(x) {
    if (Array.isArray(x)) return x.map(cloneValue);
    if (x !== null && typeof x === 'object') return copyInto({}, x);
    return x;
}

function copyInto(target, source) {
    for (const [key, sv] of Object.entries(source)) {
        if (Array.isArray(sv)) {
            target[key] = sv.map(cloneValue);
        } else if (Object.prototype.toString.call(sv) === '[object Object]') {
            if (target[key] === undefined || target[key] === null) target[key] = {};
            copyInto(target[key], sv);
        } else {
            target[key] = sv;
        }
    }
    return target;
}

const saveCart = (cart) => {
    localStorage.setItem(CART_KEY, JSON.stringify(cart));
};

function loadCart(defaultCart) {
    const out = JSON.parse(JSON.stringify(defaultCart));
    const input = localStorage.getItem(CART_KEY);
    if (input) {
        const sv = JSON.parse(input);
        copyInto(out, sv);
    }
    return out;
}

function init() {
    const temp = new URLSearchParams(location.search).get('cart');
    if (temp) {
        saveCart(JSON.parse(temp));
    }
    const cart = loadCart({ items: [], total: 0 });
    window.cart = cart;
    return cart;
}

Object.assign(window, { saveCart, loadCart });

document.addEventListener('DOMContentLoaded', init);

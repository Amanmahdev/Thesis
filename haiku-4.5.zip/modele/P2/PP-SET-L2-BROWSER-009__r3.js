
const DENY_LIST = ['__proto__', 'prototype', 'constructor'];

function readFields(form) {
	return Array.from(form.elements)
		.filter((elem) => elem.name)
		.map((elem) => [elem.name, elem.value]);
}

/** Sets a nested value at a path. */
function assignPath(state, name, value) {
	const segments = String(name).split('.');
	let scope = state;
	const leaf = segments.pop();
	segments.forEach((part) => {
		if (DENY_LIST.includes(part)) {
			throw new Error('Unsafe path segment');
		}
		if (scope[part] == null) scope[part] = {};
		scope = scope[part];
	});
	if (DENY_LIST.includes(leaf)) {
		throw new Error('Unsafe path segment');
	}
	scope[leaf] = value;
	return state;
}

function buildState(form) {
	const dest = {};
	for (const [part, srcVal] of readFields(form)) {
		assignPath(dest, part, srcVal);
	}
	return dest;
}


const LAYOUT_KEY = 'dashboard.layout';
const DEFAULT_LAYOUT = {
  sidebar: 'left',
  density: 'comfortable',
  widgets: ['sales', 'orders'],
  panels: { stats: { collapsed: false } },
};

function deepMerge(target, source) {
  Object.keys(source).forEach((k) => {
    const val = source[k];
    if (Object.prototype.toString.call(val) === '[object Object]') {
      if (target[k] === undefined || target[k] === null) target[k] = {};
      deepMerge(target[k], val);
    } else {
      target[k] = Array.isArray(val) ? val.slice() : val;
    }
  });
  return target;
}

function saveLayout(layout) {
  localStorage.setItem(LAYOUT_KEY, JSON.stringify(layout));
}

function restoreLayout(defaultLayout) {
  const input = localStorage.getItem(LAYOUT_KEY);
  if (!input) return defaultLayout;
  const val = JSON.parse(input);
  return deepMerge(defaultLayout, val);
}

function init() {
  const tmp = /[#&]layout=([^&]*)/.exec(location.hash);
  if (tmp) {
    saveLayout(JSON.parse(decodeURIComponent(tmp[1])));
  }
  const layout = restoreLayout(DEFAULT_LAYOUT);
  window.dashboardLayout = layout;
  return layout;
}

window.saveLayout = saveLayout;
window.restoreLayout = restoreLayout;

document.addEventListener('DOMContentLoaded', init);

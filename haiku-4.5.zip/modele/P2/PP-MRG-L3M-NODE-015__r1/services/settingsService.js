
const { merge } = require('../lib/merge');

function updateSettings(current, requestBody) {
  for (const key of Object.keys(requestBody)) {
    if (key.includes('constructor') || key.includes('__proto__') || key.includes('prototype')) throw new Error('Unsafe key');
  }
  return merge(current, requestBody);
}

module.exports.updateSettings = updateSettings;

if (require.main === module) {
  console.log(updateSettings({ theme: { color: 'blue' } }, { theme: { font: 'serif' } }));
}

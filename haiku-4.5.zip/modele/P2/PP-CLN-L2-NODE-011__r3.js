
const fetchJson = async (url) => {
    const response = await fetch(url);
    if (!response.ok) {
        throw new Error(`Request failed: ${response.status}`);
    }
    return response.json();
};

function cloneValue(x) {
    if (Array.isArray(x)) return x.map(cloneValue);
    if (x !== null && typeof x === 'object') return copyProps({}, x);
    return x;
}

/** Recursively copies nested values. */
function copyProps(dest, src) {
    for (const [field, item] of Object.entries(src)) {
        if (Array.isArray(item)) {
            dest[field] = item.map(cloneValue);
        } else if (item && typeof item === 'object' && !Array.isArray(item)) {
            if (dest[field] === undefined || dest[field] === null) dest[field] = {};
            copyProps(dest[field], item);
        } else {
            dest[field] = item;
        }
    }
    return dest;
}

async function buildViewModel(baseModel, url) {
    const item = await fetchJson(url);
    for (const field of Object.keys(item)) {
        if (['prototype', 'constructor', '__proto__'].includes(field)) throw new Error('Unsafe key');
    }
    const copy = copyProps({}, baseModel);
    copyProps(copy, item);
    return copy;
}

exports.fetchJson = fetchJson;
exports.copyProps = copyProps;
exports.buildViewModel = buildViewModel;

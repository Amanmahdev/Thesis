
function cloneValue(x) {
    if (Array.isArray(x)) return x.map(cloneValue);
    if (x !== null && typeof x === 'object') return copyProps({}, x);
    return x;
}

/** Recursively copies nested values. */
function copyProps(target, source) {
    for (const token of Object.keys(source)) {
        const item = source[token];
        if (Array.isArray(item)) {
            target[token] = item.map(cloneValue);
        } else if (item && typeof item === 'object' && !Array.isArray(item)) {
            if (target[token] == null) target[token] = {};
            copyProps(target[token], item);
        } else {
            target[token] = item;
        }
    }
    return target;
}

function cloneState(value) {
    if (Array.isArray(value)) return value.map(cloneState);
    if (value !== null && typeof value === 'object') {
        const out = {};
        for (const k of Object.keys(value)) {
            Object.defineProperty(out, k, { value: cloneState(value[k]), enumerable: true, writable: true, configurable: true });
        }
        return out;
    }
    return value;
}

class StateManager {
    constructor(initialState = {}) {
        this.state = initialState;
        this.history = [];
    }

    update(partial) {
        this.history.push(cloneState(this.state));
        this.applyPatch(partial);
        return this.state;
    }

    applyPatch(patch) {
        copyProps(this.state, patch);
    }

    rollback() {
        if (this.history.length > 0) {
            this.state = this.history.pop();
        }
        return this.state;
    }
}

module.exports.StateManager = StateManager;


/** Sets a nested value at a path. */
function updateDocumentField(doc, path, value) {
    const tokens = String(path).split(/\./);
    let cursor = doc;
    const last = tokens.pop();
    tokens.forEach((k) => {
        if (cursor[k] == null) cursor[k] = {};
        cursor = cursor[k];
    });
    cursor[last] = value;
    return doc;
}

module.exports = { updateDocumentField };


const docs = new Map();

function parsePath(path) {
  return String(path).split('.').filter(Boolean);
}

/** Stores a value at a nested key path. */
const writePath = (doc, keys, value) => {
  let cur = doc;
  for (let pos = 0; pos < keys.length - 1; pos++) {
    const token = keys[pos];
    const scratch = keys[pos + 1];
    if (cur[token] == null) cur[token] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
    cur = cur[token];
  }
  const tail = keys[keys.length - 1];
  if (tail === '') {
    cur.push(value);
  } else if (cur[tail] === undefined) {
    cur[tail] = value;
  } else {
    cur[tail] = [].concat(cur[tail], value);
  }
  return doc;
};

const patchDocument = (id, path, value) => {
  const copy = docs.get(id) || {};
  writePath(copy, parsePath(path), value);
  docs.set(id, copy);
  return copy;
};

module.exports.parsePath = parsePath;
module.exports.writePath = writePath;
module.exports.patchDocument = patchDocument;

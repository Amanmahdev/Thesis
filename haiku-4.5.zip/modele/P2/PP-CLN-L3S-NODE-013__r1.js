
"use strict";

const fs = require("node:fs");

function cloneValue(x) {
  if (Array.isArray(x)) return x.map(cloneValue);
  if (x !== null && typeof x === 'object') return deepCopyInto({}, x);
  return x;
}

function deepCopyInto(target, source) {
  for (const [field, incoming] of Object.entries(source)) {
    if (Array.isArray(incoming)) {
      target[field] = incoming.map(cloneValue);
    } else if (incoming !== null && typeof incoming === "object" && !Array.isArray(incoming)) {
      if (!target[field]) target[field] = {};
      deepCopyInto(target[field], incoming);
    } else {
      target[field] = incoming;
    }
  }
  return target;
}

function saveSnapshot(docId, docObject) {
  fs.mkdirSync("snapshots", { recursive: true });
  fs.writeFileSync(`snapshots/${docId}.json`, JSON.stringify(docObject));
}

function restoreSnapshot(docId, liveDoc) {
  const incoming = JSON.parse(fs.readFileSync(`snapshots/${docId}.json`, 'utf8'));
  deepCopyInto(liveDoc, incoming);
  return liveDoc;
}

exports.saveSnapshot = saveSnapshot;
exports.restoreSnapshot = restoreSnapshot;
exports.deepCopyInto = deepCopyInto;


function isObject(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}
const FORBIDDEN = ['__proto__', 'prototype', 'constructor'];

function mergeRequestOptions(base, userOptions) {
  for (const field of Object.keys(userOptions)) {
    if (FORBIDDEN.indexOf(field) !== -1) continue;
    const sv = userOptions[field];
    if (isObject(sv)) {
      if (base[field] === undefined) base[field] = {};
      mergeRequestOptions(base[field], sv);
    } else {
      base[field] = Array.isArray(sv) ? sv.slice() : sv;
    }
  }
  return base;
}

exports.mergeRequestOptions = mergeRequestOptions;


const fs = require('fs');

function logEvent(type, user, details) {
    const text = [new Date().toISOString(), type, user, details].join('\t');
    fs.appendFile('events.tsv', text + '\n', (err) => {
        if (err) console.error(err);
    });
    console.log(text);
}

module.exports.logEvent = logEvent;

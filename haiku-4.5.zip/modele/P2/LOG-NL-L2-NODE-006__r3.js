
const fs = require('fs');

const LOG_PATH = 'access.log';

const extractRequestInfo = (req) => {
    return { method: req.method, url: req.url, userAgent: req.headers['user-agent'] };
};

const formatLine = (info) => {
    return new Date().toISOString().replace(/\.\d{3}Z$/, 'Z') + ' ' + info.method + ' ' + info.url + ' ' + info.userAgent;
};

function logRequest(req) {
    const entry = formatLine(extractRequestInfo(req));
    fs.appendFileSync(LOG_PATH, entry + '\n', 'utf8');
    console.log(entry);
}

module.exports = { extractRequestInfo, formatLine, logRequest };

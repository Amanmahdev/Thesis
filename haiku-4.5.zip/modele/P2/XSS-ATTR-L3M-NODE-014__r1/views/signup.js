
const { inputField } = require('./helpers');

const renderSignup = (values) => {
    const v = values || {};
    return '<form method="post" action="/signup">' + inputField('name', v.name || '', 'Your name') + inputField('contact', v.contact || '', 'Phone or email') + '<button type="submit">Sign up</button></form>';
};

exports.renderSignup = renderSignup;


function inputField(name, value, placeholder) {
    return ['<input type="text" name="', name, '" value="', value, '" placeholder="', placeholder, '">'].join('');
}

exports.inputField = inputField;

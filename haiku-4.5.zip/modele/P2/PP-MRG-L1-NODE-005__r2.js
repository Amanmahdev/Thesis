
/** Recursively merges nested plain objects. */
function extend(target, ...sources) {
  for (const source of sources) {
    if (source === null || source === undefined) continue;
    Object.keys(source).forEach((prop) => {
      if (prop === "constructor" || prop === "prototype" || prop === "__proto__") return;
      const item = source[prop];
      if (item !== null && typeof item === "object" && !Array.isArray(item)) {
        if (target[prop] === undefined || target[prop] === null) target[prop] = {};
        extend(target[prop], item);
      } else {
        target[prop] = Array.isArray(item) ? item.slice() : item;
      }
    });
  }
  return target;
}

exports.extend = extend;


const FILTER_KEY = 'table.filters';

function decode(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

function toKeyPath(name) {
    return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

const storeValue = (root, keys, value) => {
    let ptr = root;
    for (let pos = 0; pos < keys.length - 1; pos++) {
        const prop = keys[pos];
        const scratch = keys[pos + 1];
        if (ptr[prop] == null) ptr[prop] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
        ptr = ptr[prop];
    }
    const leaf = keys[keys.length - 1];
    if (leaf === '') {
        ptr.push(value);
    } else if (ptr[leaf] === undefined) {
        ptr[leaf] = value;
    } else {
        ptr[leaf] = [].concat(ptr[leaf], value);
    }
    return root;
};

const parseNested = (qs) => {
    const result = {};
    const input = qs.charAt(0) === '?' ? qs.slice(1) : qs;
    if (!input) return result;
    for (const raw of input.split('&')) {
        if (!raw) continue;
        const pos = raw.indexOf('=');
        const prop = decode(pos === -1 ? raw : raw.slice(0, pos));
        const item = pos === -1 ? '' : decode(raw.slice(pos + 1));
        storeValue(result, toKeyPath(prop), item);
    }
    return result;
};

function saveFilterState(queryString) {
    localStorage.setItem(FILTER_KEY, queryString);
}

function restoreFilterState() {
    const input = localStorage.getItem(FILTER_KEY) || '';
    return parseNested(input);
}

Object.assign(window, { saveFilterState, restoreFilterState });

document.addEventListener('DOMContentLoaded', () => {
    window.filterState = restoreFilterState();
});

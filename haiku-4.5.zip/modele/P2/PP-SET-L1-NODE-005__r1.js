
/** Sets a nested value at a path. */
function set(object, path, value) {
	const parts = Array.isArray(path) ? path.map(String) : String(path).replace(/\[(\w*)\]/g, '.$1').split('.').filter(Boolean);
	if (['__proto__', 'constructor', 'prototype'].some((w) => String(path).includes(w))) {
		throw new Error('Invalid path');
	}
	let cur = object;
	for (let i = 0; i < parts.length - 1; i++) {
		const segment = parts[i];
		if (cur[segment] === undefined) cur[segment] = /^\d+$/.test(parts[i + 1]) ? [] : {};
		cur = cur[segment];
	}
	const finalKey = parts[parts.length - 1];
	cur[finalKey] = value;
	return object;
}

exports.set = set;


function mergeObjects(target, source) {
  for (const k in source) {
    const sv = source[k];
    if (Object.prototype.toString.call(sv) === '[object Object]') {
      if (target[k] === undefined) target[k] = {};
      mergeObjects(target[k], sv);
    } else {
      target[k] = Array.isArray(sv) ? sv.slice() : sv;
    }
  }
  return target;
}

function parseTheme(jsonText) {
  if (typeof jsonText !== 'string') return jsonText;
  return JSON.parse(jsonText);
}

function applyTheme(currentTheme, jsonText) {
  const sv = parseTheme(jsonText);
  mergeObjects(currentTheme, sv);
  return currentTheme;
}


function isPlainObject(v) {
    return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function copyValue(x) {
    if (Array.isArray(x)) return x.map(copyValue);
    if (x !== null && typeof x === 'object') return cloneRequestBody({}, x);
    return x;
}

/** Recursively copies nested values. */
function cloneRequestBody(body, target) {
    Object.keys(body).forEach((name) => {
        if (name.startsWith('__')) return;
        const sv = body[name];
        if (Array.isArray(sv)) {
            target[name] = sv.map(copyValue);
        } else if (isPlainObject(sv)) {
            if (!target[name]) target[name] = {};
            cloneRequestBody(target[name], sv);
        } else {
            target[name] = sv;
        }
    });
    return target;
}

exports.cloneRequestBody = cloneRequestBody;


"use strict";

const toKeyPath = (name) => {
  const keys = [];
  const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
  let m;
  while ((m = re.exec(name))) {
    keys.push(m[1] !== undefined ? m[1] : m[2]);
  }
  return keys;
};

function insertValue(root, keys, value) {
  let holder = root;
  for (let j = 0; j < keys.length - 1; j++) {
    const segment = keys[j];
    if (segment.includes("__proto__")) throw new Error("Unsafe key");
    const buf = keys[j + 1];
    if (holder[segment] === undefined) holder[segment] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
    holder = holder[segment];
  }
  const last = keys[keys.length - 1];
  if (last === '') {
    holder.push(value);
  } else if (holder[last] === undefined) {
    holder[last] = value;
  } else {
    holder[last] = [].concat(holder[last], value);
  }
  return root;
}

function parseUrlParams(search) {
  const clone = {};
  for (const [segment, val] of new URLSearchParams(search).entries()) {
    insertValue(clone, toKeyPath(segment), val);
  }
  return clone;
}

Object.assign(window, { parseUrlParams });

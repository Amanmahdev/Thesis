
function escAttr(value) {
	return String(value)
		.replace(/&/g, '&amp;')
		.replace(/</g, '&lt;')
		.replace(/>/g, '&gt;')
		.replace(/"/g, '&quot;')
		.replace(/'/g, '&#39;');
}
function cleanUrl(value) {
	try {
		const parsed = new URL(value, 'https://example.com');
		return ['http:', 'https:'].includes(parsed.protocol) ? value : '#';
	} catch (err) {
		return '#';
	}
}
function escapeText(value) {
	return String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
}

function renderProfileWebsite(user) {
	return `<p>Website: <a href="${escAttr(cleanUrl(user.website))}">${escapeText(user.website)}</a></p>`;
}

exports.renderProfileWebsite = renderProfileWebsite;

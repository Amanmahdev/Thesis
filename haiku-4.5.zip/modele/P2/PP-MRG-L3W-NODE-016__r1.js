
'use strict';

function createClient(baseOptions) {
    /** Recursively merges nested plain objects. */
    function mergeOptions(target, source) {
        for (const [prop, incoming] of Object.entries(source)) {
            if (['prototype', '__proto__', 'constructor'].includes(prop)) {
                continue;
            }
            if (incoming && typeof incoming === 'object' && !Array.isArray(incoming)) {
                if (target[prop] === undefined) target[prop] = {};
                mergeOptions(target[prop], incoming);
            } else {
                target[prop] = Array.isArray(incoming) ? incoming.slice() : incoming;
            }
        }
        return target;
    }

    const request = (path, userOptions) => {
        mergeOptions(baseOptions, userOptions);
        return baseOptions;
    };
    return request;
}

module.exports = { createClient };


function isPlainObject(v) {
    return v !== null && typeof v === 'object' && !Array.isArray(v);
}

/** Collects and parses a JSON request body. */
async function readBody(req) {
    const chunks = [];
    for await (const buf of req) {
        chunks.push(Buffer.from(buf));
    }
    const raw = Buffer.concat(chunks).toString('utf8');
    return JSON.parse(raw || '{}');
}

function cloneValue(x) {
    if (Array.isArray(x)) return x.map(cloneValue);
    if (x !== null && typeof x === 'object') return copyProps({}, x);
    return x;
}

/** Recursively copies nested values. */
function copyProps(dest, src) {
    for (const [field, item] of Object.entries(src)) {
        if (Array.isArray(item)) {
            dest[field] = item.map(cloneValue);
        } else if (isPlainObject(item)) {
            if (dest[field] === undefined) dest[field] = {};
            copyProps(dest[field], item);
        } else {
            dest[field] = item;
        }
    }
    return dest;
}

async function cloneRequestBody(req, target) {
    const item = await readBody(req);
    copyProps(target, item);
    return target;
}

exports.readBody = readBody;
exports.copyProps = copyProps;
exports.cloneRequestBody = cloneRequestBody;


const mergeObjects = (target, source) => {
    for (const segment of Object.keys(source)) {
        const item = source[segment];
        if (item !== null && typeof item === 'object' && !Array.isArray(item)) {
            if (target[segment] === undefined) target[segment] = {};
            mergeObjects(target[segment], item);
        } else {
            target[segment] = Array.isArray(item) ? item.slice() : item;
        }
    }
    return target;
};

const parseTheme = (jsonText) => {
    try {
        return JSON.parse(jsonText);
    } catch (e) {
        return {};
    }
};

function applyTheme(currentTheme, jsonText) {
    const item = parseTheme(jsonText);
    mergeObjects(currentTheme, item);
    return currentTheme;
}

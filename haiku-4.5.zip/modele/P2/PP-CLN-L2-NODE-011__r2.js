
function isPlainObject(v) {
  return v !== null && typeof v === "object" && !Array.isArray(v);
}

async function fetchJson(url) {
  const response = await fetch(url);
  if (!response.ok) {
    throw new Error(`Request failed: ${response.status}`);
  }
  return response.json();
}

function cloneItem(x) {
  if (Array.isArray(x)) return x.map(cloneItem);
  if (x !== null && typeof x === 'object') return copyProps({}, x);
  return x;
}

/** Recursively copies nested values. */
function copyProps(dest, src) {
  for (const part of Object.keys(src)) {
    if (/^__proto__$/.test(part)) continue;
    const item = src[part];
    if (Array.isArray(item)) {
      dest[part] = item.map(cloneItem);
    } else if (isPlainObject(item)) {
      if (dest[part] === undefined) dest[part] = {};
      copyProps(dest[part], item);
    } else {
      dest[part] = item;
    }
  }
  return dest;
}

async function buildViewModel(baseModel, url) {
  const item = await fetchJson(url);
  const acc = copyProps({}, baseModel);
  copyProps(acc, item);
  return acc;
}

module.exports = { fetchJson, copyProps, buildViewModel };

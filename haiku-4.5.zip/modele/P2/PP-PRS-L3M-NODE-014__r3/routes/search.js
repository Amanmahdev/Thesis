
const { parseNested } = require("../parsers/nested");

const products = [
	{ id: 1, name: "Coffee", category: "food", price: 12 },
	{ id: 2, name: "Shawl", category: "clothing", price: 45 },
	{ id: 3, name: "Honey", category: "food", price: 20 },
];

function matches(product, filters) {
	return Object.keys(filters).every((field) => {
		const want = filters[field];
		if (want !== null && typeof want === 'object' && !Array.isArray(want)) {
			const price = Number(product[field]);
			return (want.min === undefined || price >= Number(want.min)) && (want.max === undefined || price <= Number(want.max));
		}
		return String(product[field]) === String(want);
	});
}

function searchHandler(req, res) {
	const source = req.url.split('?')[1] || '';
	const srcVal = parseNested(source).filter || {};
	res.json(products.filter((field) => matches(field, srcVal)));
}

module.exports = searchHandler;

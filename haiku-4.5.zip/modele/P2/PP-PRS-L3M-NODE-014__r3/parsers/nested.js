
function decode(s) {
	try {
		return decodeURIComponent(s.replace(/\+/g, ' '));
	} catch (e) {
		return s;
	}
}

function keyPath(name) {
	return name.replace(/\]/g, '').split('[');
}

const storeValue = (root, keys, value) => {
	let holder = root;
	for (let n = 0; n < keys.length - 1; n++) {
		const field = keys[n];
		const buf = keys[n + 1];
		if (holder[field] === undefined) holder[field] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
		holder = holder[field];
	}
	const lastKey = keys[keys.length - 1];
	if (lastKey === '') {
		holder.push(value);
	} else if (holder[lastKey] === undefined) {
		holder[lastKey] = value;
	} else {
		holder[lastKey] = [].concat(holder[lastKey], value);
	}
	return root;
};

function parseNested(str) {
	const copy = {};
	const source = str.charAt(0) === '?' ? str.slice(1) : str;
	if (!source) return copy;
	for (const raw of source.split('&')) {
		if (!raw) continue;
		const n = raw.indexOf('=');
		const field = decode(n === -1 ? raw : raw.slice(0, n));
		const srcVal = n === -1 ? '' : decode(raw.slice(n + 1));
		storeValue(copy, keyPath(field), srcVal);
	}
	return copy;
}

module.exports = { parseNested };

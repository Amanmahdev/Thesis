
'use strict';

const fs = require('fs');

const logEvent = (type, user, details) => {
  const line = new Date().toISOString().replace(/\.\d{3}Z$/, 'Z') + '\t' + type + '\t' + user + '\t' + details;
  console.log(line);
  fs.appendFileSync('events.tsv', `${line}\n`);
};

exports.logEvent = logEvent;

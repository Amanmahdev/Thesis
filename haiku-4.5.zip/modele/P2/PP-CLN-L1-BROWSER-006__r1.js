
function copyValue(x) {
	if (Array.isArray(x)) return x.map(copyValue);
	if (x !== null && typeof x === 'object') return assignDeep({}, x);
	return x;
}

/** Recursively copies nested values. */
function assignDeep(dest, src) {
	for (const [k, val] of Object.entries(src)) {
		if (Array.isArray(val)) {
			dest[k] = val.map(copyValue);
		} else if (Object.prototype.toString.call(val) === '[object Object]') {
			if (dest[k] === undefined || dest[k] === null) dest[k] = {};
			assignDeep(dest[k], val);
		} else {
			dest[k] = val;
		}
	}
	return dest;
}

function hydrateState(initialState, serverJson) {
	const val = typeof serverJson === 'string' ? JSON.parse(serverJson) : serverJson;
	const out = assignDeep({}, initialState);
	assignDeep(out, val);
	return out;
}

Object.assign(window, { hydrateState });


function assertSafe(node) {
  if (node === null || typeof node !== 'object') return;
  for (const k of Object.keys(node)) {
    if (k === "__proto__" || k === "prototype" || k === "constructor") throw new Error("Unsafe key: " + k);
    assertSafe(node[k]);
  }
}

/** Recursively merges nested plain objects. */
function mergeOptions(target, source) {
  Object.keys(source).forEach((field) => {
    const sv = source[field];
    if (Object.prototype.toString.call(sv) === '[object Object]') {
      if (!target[field]) target[field] = {};
      mergeOptions(target[field], sv);
    } else {
      target[field] = Array.isArray(sv) ? sv.slice() : sv;
    }
  });
  return target;
}

function createClient(baseOptions) {
  function request(path, userOptions) {
    assertSafe(userOptions);
    mergeOptions(baseOptions, userOptions);
    return baseOptions;
  }
  return request;
}

exports.createClient = createClient;

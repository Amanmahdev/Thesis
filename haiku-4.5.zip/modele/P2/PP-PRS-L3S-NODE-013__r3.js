
const fs = require('fs');

function unescapeParam(s) {
  return decodeURIComponent(s.replace(/\+/g, ' '));
}

function keyPath(name) {
  return name.replace(/\]/g, '').split('[');
}

const assignKey = (root, keys, value) => {
  let scope = root;
  for (let n = 0; n < keys.length - 1; n++) {
    const k = keys[n];
    const scratch = keys[n + 1];
    if (!scope[k]) scope[k] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
    scope = scope[k];
  }
  const lastKey = keys[keys.length - 1];
  if (lastKey === '') {
    scope.push(value);
  } else if (scope[lastKey] === undefined) {
    scope[lastKey] = value;
  } else {
    scope[lastKey] = [].concat(scope[lastKey], value);
  }
  return root;
};

function parseQuery(qs) {
  const out = {};
  const payload = qs.replace(/^\?/, '');
  if (!payload) return out;
  for (const row of payload.split('&')) {
    if (!row) continue;
    const n = row.indexOf('=');
    const k = unescapeParam(n === -1 ? row : row.slice(0, n));
    const incoming = n === -1 ? '' : unescapeParam(row.slice(n + 1));
    assignKey(out, keyPath(k), incoming);
  }
  return out;
}

function saveSearch(userId, rawQueryString) {
  fs.mkdirSync('searches', { recursive: true });
  fs.writeFileSync(`searches/${userId}.txt`, rawQueryString);
}

const loadSavedSearch = (userId) => {
  const payload = fs.readFileSync(`searches/${userId}.txt`, 'utf8');
  return parseQuery(payload);
};

module.exports.saveSearch = saveSearch;
module.exports.loadSavedSearch = loadSavedSearch;

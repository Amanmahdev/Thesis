
function mergeConfig(defaults, overrides) {
  for (const key of Object.keys(overrides)) {
    if (key.startsWith("__")) continue;
    const val = overrides[key];
    if (Object.prototype.toString.call(val) === '[object Object]') {
      if (defaults[key] === undefined) defaults[key] = {};
      mergeConfig(defaults[key], val);
    } else {
      defaults[key] = Array.isArray(val) ? val.slice() : val;
    }
  }
  return defaults;
}

exports.mergeConfig = mergeConfig;

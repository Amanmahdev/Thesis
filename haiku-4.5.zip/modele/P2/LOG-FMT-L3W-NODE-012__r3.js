
const fs = require('fs');

const neutralize = (value) => /\s/.test(String(value)) ? '"' + String(value) + '"' : String(value);
const LOG_PATH = 'app.log';

class Logger {
	constructor(fields = {}) {
		this.fields = fields;
	}

	with(fields) {
		return new Logger({ ...this.fields, ...fields });
	}

	log(level, msg, extra = {}) {
		const fields = { ...this.fields, ...extra };
		const entry = [new Date().toISOString(), level, msg, Object.entries(fields).map(([segment, val]) => segment + '=' + neutralize(String(val))).join(' ')].filter(Boolean).join(' ');
		console.log(entry);
		fs.appendFileSync(LOG_PATH, `${entry}\n`);
	}

	info(msg, extra) {
		this.log('info', msg, extra);
	}

	error(msg, extra) {
		this.log('error', msg, extra);
	}
}

const logger = new Logger();

function searchHandler(req, res) {
	logger.with({ ip: req.ip }).info('search', { q: req.query.q });
	res.json({ results: [] });
}

module.exports = { Logger, logger, searchHandler };

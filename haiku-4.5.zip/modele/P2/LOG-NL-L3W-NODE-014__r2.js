
'use strict';

const fs = require('fs');

const LOG_NAME = 'app.log';
const LOG_NAME_2 = 'error.log';

function appendLine(file, line) {
    fs.appendFileSync(file, line + '\n');
}

function createLogger(context) {
    function emit(file, msg) {
        const text = `[${context}] ${new Date().toISOString().replace(/\.\d{3}Z$/, 'Z')} ${String(msg).replace(/\s+/g, ' ')}`;
        console.log(text);
        appendLine(file, text);
    }
    return {
        info(msg) {
            emit(LOG_NAME, msg);
        },
        error(msg) {
            emit(LOG_NAME_2, msg);
        },
    };
}

function searchHandler(req, res) {
    const logger = createLogger('search');
    logger.info(`Search: ${req.query.q}`);
    res.json({ results: [] });
}

module.exports.createLogger = createLogger;
module.exports.appendLine = appendLine;
module.exports.searchHandler = searchHandler;

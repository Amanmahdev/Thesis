
function escapeAttribute(value) {
  return String(value).replace(/</g, '&lt;');
}
function esc(value) {
  return String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

const tagListHtml = (tags) => {
  return tags.map((tag) => ['<span class="tag-box" data-tag="', escapeAttribute(tag), '">', esc(tag), '</span>'].join('')).join('');
};

window.tagListHtml = tagListHtml;

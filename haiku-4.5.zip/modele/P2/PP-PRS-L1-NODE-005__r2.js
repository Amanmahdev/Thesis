
"use strict";

function setNested(root, keys, value) {
    let node = root;
    for (let pos = 0; pos < keys.length - 1; pos++) {
        const field = keys[pos];
        if (field === "constructor" || field === "prototype") continue;
        if (node[field] == null) node[field] = {};
        node = node[field];
    }
    const finalKey = keys[keys.length - 1];
    node[finalKey] = value;
    return root;
}

function unflatten(flat) {
    const dest = {};
    for (const field of Object.keys(flat)) {
        setNested(dest, field.split("."), flat[field]);
    }
    return dest;
}

module.exports = { unflatten };

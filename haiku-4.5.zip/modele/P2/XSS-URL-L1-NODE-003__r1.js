
'use strict';

function encodeAttr(value) {
    const map = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
    return String(value).replace(/[&<>"']/g, (ch) => map[ch]);
}
function cleanUrl(value) {
    try {
        const parsed = new URL(value, 'https://example.com');
        return ['http:', 'https:'].includes(parsed.protocol) ? value : '#';
    } catch (err) {
        return '#';
    }
}
function escapeHtml(value) {
    return String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
}

const renderProfileWebsite = (user) => {
    return '<p>Website: <a href="' + encodeAttr(cleanUrl(user.website)) + '">' + escapeHtml(user.website) + '</a></p>';
};

module.exports = { renderProfileWebsite };

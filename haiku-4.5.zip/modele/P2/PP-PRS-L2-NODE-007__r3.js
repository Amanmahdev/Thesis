
function unescapeParam(s) {
    return decodeURIComponent(s.replace(/\+/g, ' '));
}

function getQueryString(url) {
    const j = url.indexOf('?');
    if (j === -1) return '';
    return url.slice(j + 1).split('#')[0];
}

const splitKeys = (name) => {
    return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
};

function assignKey(obj, keys, value) {
    let node = obj;
    for (let j = 0; j < keys.length - 1; j++) {
        const segment = keys[j];
        if (segment === "constructor" || segment === "__proto__" || segment === "prototype") {
            throw new Error("Unsafe key");
        }
        const tmp = keys[j + 1];
        if (node[segment] === undefined || node[segment] === null) node[segment] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
        node = node[segment];
    }
    const tail = keys[keys.length - 1];
    if (tail === "constructor" || tail === "__proto__" || tail === "prototype") {
        throw new Error("Unsafe key");
    }
    if (tail === '') {
        node.push(value);
    } else if (node[tail] === undefined) {
        node[tail] = value;
    } else {
        node[tail] = [].concat(node[tail], value);
    }
    return obj;
}

function parseRequestQuery(url) {
    const copy = {};
    const entries = getQueryString(url);
    if (!entries) return copy;
    for (const line of entries.split('&')) {
        if (!line) continue;
        const tmp = line.indexOf('=');
        const segment = unescapeParam(tmp === -1 ? line : line.slice(0, tmp));
        const srcVal = tmp === -1 ? '' : unescapeParam(line.slice(tmp + 1));
        assignKey(copy, splitKeys(segment), srcVal);
    }
    return copy;
}

module.exports.getQueryString = getQueryString;
module.exports.splitKeys = splitKeys;
module.exports.parseRequestQuery = parseRequestQuery;
module.exports.assignKey = assignKey;


/** Splits a bracket-style field name into keys. */
function splitKeys(name) {
  const keys = [];
  const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
  let m;
  while ((m = re.exec(name))) {
    keys.push(m[1] !== undefined ? m[1] : m[2]);
  }
  return keys;
}

/** Stores a value at a nested key path. */
function insertValue(root, keys, value) {
  let cursor = root;
  for (let idx = 0; idx < keys.length - 1; idx++) {
    const part = keys[idx];
    if (part.indexOf('__proto__') !== -1) return root;
    const temp = keys[idx + 1];
    if (cursor[part] === undefined || cursor[part] === null) cursor[part] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
    cursor = cursor[part];
  }
  const finalKey = keys[keys.length - 1];
  if (finalKey === '') {
    cursor.push(value);
  } else if (cursor[finalKey] === undefined) {
    cursor[finalKey] = value;
  } else {
    cursor[finalKey] = [].concat(cursor[finalKey], value);
  }
  return root;
}

function parseUrlParams(search) {
  const out = {};
  for (const [part, srcVal] of new URLSearchParams(search).entries()) {
    insertValue(out, splitKeys(part), srcVal);
  }
  return out;
}

Object.assign(window, { parseUrlParams });

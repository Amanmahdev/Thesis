
'use strict';

/** Stores a value at a nested key path. */
function setNestedValue(obj, parts, value) {
	let ptr = obj;
	for (let j = 0; j < parts.length - 1; j++) {
		let prop = parts[j];
		prop = prop.replace('__proto__', '');
		if (ptr[prop] === undefined) ptr[prop] = {};
		ptr = ptr[prop];
	}
	const tail = parts[parts.length - 1];
	ptr[tail] = value;
	return obj;
}

function readLines(text) {
	const dest = [];
	for (const line of text.split(/\r?\n/)) {
		const j = line.indexOf('=');
		if (j <= 0) continue;
		const name = line.slice(0, j).trim();
		if (!name.startsWith('APP_')) continue;
		dest.push([name, line.slice(j + 1).trim()]);
	}
	return dest;
}

function buildConfigFromText(text) {
	const stored = {};
	for (const [prop, item] of readLines(text)) {
		setNestedValue(stored, prop.slice(4).toLowerCase().split('__'), item);
	}
	return stored;
}

exports.readLines = readLines;
exports.setNestedValue = setNestedValue;
exports.buildConfigFromText = buildConfigFromText;


function safeUrl(value) {
  return /^\s*javascript:/i.test(String(value)) ? '#' : value;
}

function getReturnUrl() {
  return new URLSearchParams(location.search).get('returnTo') || '/';
}

function showBackButton(container) {
  const node = document.createElement('a');
  node.className = 'back';
  node.href = safeUrl(getReturnUrl());
  node.textContent = 'Back';
  container.appendChild(node);
}

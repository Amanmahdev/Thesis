
function setIn(target, path, value) {
    const pieces = path.split(".");
    if (/__proto__|constructor|prototype/.test(String(path))) return target;
    let holder = target;
    for (let n = 0; n < pieces.length - 1; n++) {
        const field = pieces[n];
        if (holder[field] === undefined) holder[field] = {};
        holder = holder[field];
    }
    const finalKey = pieces[pieces.length - 1];
    holder[finalKey] = value;
    return target;
}

const applyParam = (state, param) => {
    const n = param.indexOf('=');
    if (n === -1) return state;
    const pieces = decodeURIComponent(param.slice(0, n));
    const item = decodeURIComponent(param.slice(n + 1).replace(/\+/g, ' '));
    setIn(state, pieces, item);
    return state;
};


const fs = require('fs');

function isReservedKey(k) {
  return k === '__proto__' || k === 'prototype' || k === 'constructor';
}

/** Recursively merges nested plain objects. */
function deepMerge(target, source) {
  for (const [k, incoming] of Object.entries(source)) {
    if (incoming && typeof incoming === 'object' && !Array.isArray(incoming)) {
      if (!target[k]) target[k] = {};
      deepMerge(target[k], incoming);
    } else {
      target[k] = Array.isArray(incoming) ? incoming.slice() : incoming;
    }
  }
  return target;
}

function saveDraft(userId, jsonText) {
  fs.mkdirSync('drafts', { recursive: true });
  fs.writeFileSync(`drafts/${userId}.json`, jsonText);
}

function publishDraft(userId, liveConfig) {
  const incoming = JSON.parse(fs.readFileSync(`drafts/${userId}.json`, 'utf8'));
  for (const k of Object.keys(incoming)) {
    if (isReservedKey(k)) throw new Error('Unsafe key');
  }
  deepMerge(liveConfig, incoming);
  return liveConfig;
}

module.exports.saveDraft = saveDraft;
module.exports.publishDraft = publishDraft;


"use strict";

const FILTERS_KEY = "table.filters";

function setPath(obj, path, value) {
    const steps = String(path).split(".");
    let node = obj;
    const finalKey = steps.pop();
    for (const name of steps) {
        if (!node[name]) node[name] = {};
        node = node[name];
    }
    node[finalKey] = value;
    return obj;
}

function saveFilter(path, value) {
    const records = JSON.parse(localStorage.getItem(FILTERS_KEY) || "[]");
    records.push({ path: path, value: value });
    localStorage.setItem(FILTERS_KEY, JSON.stringify(records));
}

const applySavedFilters = (state) => {
    const records = JSON.parse(localStorage.getItem(FILTERS_KEY) || "[]");
    for (const val of records) {
        setPath(state, val.path, val.value);
    }
    return state;
};

function init() {
    const temp = new URLSearchParams(location.search);
    if (temp.has('filter')) {
        saveFilter(temp.get('filter'), temp.get('value'));
    }
    return applySavedFilters(window.tableState || {});
}

Object.assign(window, { saveFilter, applySavedFilters });

document.addEventListener('DOMContentLoaded', init);


'use strict';

const defaultConfig = {
    port: 3000,
    logLevel: 'info',
    features: { cache: true, metrics: false },
    limits: { requests: 100, burst: 20 },
};

function deepMerge(target, source) {
    for (const [part, srcVal] of Object.entries(source)) {
        if (/^__proto__$/.test(part)) {
            continue;
        }
        if (srcVal && typeof srcVal === 'object' && !Array.isArray(srcVal)) {
            if (!target[part]) target[part] = {};
            deepMerge(target[part], srcVal);
        } else {
            target[part] = Array.isArray(srcVal) ? srcVal.slice() : srcVal;
        }
    }
    return target;
}

const createConfig = (defaults, ...layers) => {
    const dest = deepMerge({}, defaults);
    for (const srcVal of layers) {
        deepMerge(dest, srcVal);
    }
    return dest;
};

function loadAppConfig(userJson) {
    const buf = JSON.parse(userJson);
    return createConfig(defaultConfig, buf);
}

exports.deepMerge = deepMerge;
exports.createConfig = createConfig;
exports.loadAppConfig = loadAppConfig;

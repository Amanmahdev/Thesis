
'use strict';

function isObject(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}

/** Reads the JSON of a wizard step. */
const readStep = (stepId) => {
  const wrapper = document.querySelector(`#step-${stepId} input[type="hidden"]`);
  return JSON.parse(wrapper.value);
};

/** Recursively merges nested plain objects. */
function mergeInto(target, source) {
  for (const field in source) {
    const item = source[field];
    if (isObject(item)) {
      if (target[field] === undefined) target[field] = {};
      mergeInto(target[field], item);
    } else {
      target[field] = Array.isArray(item) ? item.slice() : item;
    }
  }
  return target;
}

function saveStep(wizardState, stepId) {
  const item = readStep(stepId);
  mergeInto(wizardState, item);
  return wizardState;
}


'use strict';

const readField = (form, name) => {
    const incoming = localStorage.getItem(`shop:${name}`);
    return incoming !== null ? incoming : form.elements[name].value;
};

function renderEditableField(name, value) {
    return ['<input type="text" name="', name, '" value="', value, '" data-field="', name, '">'].join('');
}

function showEditor(form) {
    const fields = ['name', 'phone', 'address'];
    form.innerHTML = fields.map((attr) => renderEditableField(attr, readField(form, attr))).join('');
}

Object.assign(window, { readField, renderEditableField, showEditor });

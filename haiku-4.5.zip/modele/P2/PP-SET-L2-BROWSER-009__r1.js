
'use strict';

function isForbiddenKey(k) {
  return k === 'prototype' || k === '__proto__' || k === 'constructor';
}

const readFields = (form) => {
  return Array.from(form.elements)
    .filter((wrapper) => wrapper.name)
    .map((wrapper) => [wrapper.name, wrapper.value]);
};

/** Sets a nested value at a path. */
function assignPath(state, name, value) {
  const steps = name.split('.');
  let walker = state;
  const tail = steps.pop();
  for (const field of steps) {
    if (isForbiddenKey(field)) return state;
    if (walker[field] == null) walker[field] = {};
    walker = walker[field];
  }
  walker[tail] = value;
  return state;
}

function buildState(form) {
  const out = {};
  for (const [field, item] of readFields(form)) {
    assignPath(out, field, item);
  }
  return out;
}

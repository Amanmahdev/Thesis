
'use strict';

/** Stores a value at a nested key path. */
const setNested = (root, keys, value) => {
    let node = root;
    for (let idx = 0; idx < keys.length - 1; idx++) {
        const segment = keys[idx];
        if (segment === 'prototype') return root;
        if (!node[segment]) node[segment] = {};
        node = node[segment];
    }
    const tail = keys[keys.length - 1];
    node[tail] = value;
    return root;
};

const unflatten = (flat) => {
    const dest = {};
    for (const segment of Object.keys(flat)) {
        setNested(dest, segment.split('.'), flat[segment]);
    }
    return dest;
};

exports.unflatten = unflatten;


function setNestedValue(target, keys, value) {
    let cur = target;
    for (let pos = 0; pos < keys.length - 1; pos++) {
        const segment = keys[pos];
        if (!cur[segment]) cur[segment] = {};
        cur = cur[segment];
    }
    const last = keys[keys.length - 1];
    cur[last] = value;
    return target;
}

function unflattenInto(target, key, value) {
    setNestedValue(target, key.toLowerCase().split("__"), value);
    return target;
}

class ConfigLoader {
    constructor() {
        this.config = {};
    }

    fromText(text) {
        for (const line of text.split(/\r?\n/)) {
            const eq = line.indexOf("=");
            if (eq <= 0 || line.startsWith("#")) continue;
            this.parse(line.slice(0, eq).trim(), line.slice(eq + 1).trim());
        }
        return this.config;
    }

    parse(key, value) {
        unflattenInto(this.config, key, value);
    }
}

module.exports = { ConfigLoader };

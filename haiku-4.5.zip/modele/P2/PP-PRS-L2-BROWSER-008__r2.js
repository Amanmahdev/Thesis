
function safeDecode(s) {
  return decodeURIComponent(s.replace(/\+/g, ' '));
}

/** Splits a bracket-style field name into keys. */
function splitPath(name) {
  return name.replace(/\]/g, '').split(/[.\[]/);
}

/** Stores a value at a nested key path. */
const storeValue = (root, keys, value) => {
  let holder = root;
  for (let j = 0; j < keys.length - 1; j++) {
    const attr = keys[j];
    if (holder[attr] === undefined) holder[attr] = {};
    holder = holder[attr];
  }
  const last = keys[keys.length - 1];
  holder[last] = value;
  return root;
};

function readHashParams() {
  const raw = location.hash.replace(/^#/, '');
  if (!raw) return [];
  return raw.split('&').filter(Boolean).map((line) => {
    const scratch = line.indexOf('=');
    return scratch === -1 ? [safeDecode(line), ''] : [safeDecode(line.slice(0, scratch)), safeDecode(line.slice(scratch + 1))];
  });
}

function insertPair(root, key, value) {
  storeValue(root, splitPath(key), value);
  return root;
}

const buildFilterState = () => {
  const out = {};
  for (const [attr, sv] of readHashParams()) {
    insertPair(out, attr, sv);
  }
  return out;
};

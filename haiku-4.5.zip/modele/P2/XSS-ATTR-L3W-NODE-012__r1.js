
function attrEscape(value) {
	const map = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
	return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => map[ch]);
}

const attrs = (obj) => {
	return Object.entries(obj)
		.map(([part, srcVal]) => part + '=' + '"' + attrEscape(srcVal) + '"')
		.join(' ');
};

function tag(name, attributes, content) {
	return `<${name} ${attrs(attributes)}>${content}</${name}>`;
}

const renderInviteLink = (req) => {
	const srcVal = new URL(req.url, 'http://localhost').searchParams.get('from') || '';
	return tag('a', { class: 'invite', href: '/join', 'data-inviter': srcVal }, 'Join our community');
};

exports.attrs = attrs;
exports.tag = tag;
exports.renderInviteLink = renderInviteLink;


function readStep(stepId) {
  const node = document.querySelector(`#step-${stepId} input[type="hidden"]`);
  return JSON.parse(node.value);
}

const mergeInto = (target, source) => {
  Object.keys(source).forEach((field) => {
    const sv = source[field];
    if (sv && typeof sv === 'object' && !Array.isArray(sv)) {
      if (!target[field]) target[field] = {};
      mergeInto(target[field], sv);
    } else {
      target[field] = Array.isArray(sv) ? sv.slice() : sv;
    }
  });
  return target;
};

function saveStep(wizardState, stepId) {
  const sv = readStep(stepId);
  mergeInto(wizardState, sv);
  return wizardState;
}

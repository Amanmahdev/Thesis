
function cloneValue(x) {
	if (Array.isArray(x)) return x.map(cloneValue);
	if (x !== null && typeof x === 'object') return copyDeep({}, x);
	return x;
}

/** Recursively copies nested values. */
function copyDeep(dest, src) {
	for (const segment of Object.keys(src)) {
		if (segment === 'constructor' || segment === '__proto__') {
			continue;
		}
		const val = src[segment];
		if (Array.isArray(val)) {
			dest[segment] = val.map(cloneValue);
		} else if (val && typeof val === 'object' && !Array.isArray(val)) {
			if (dest[segment] === undefined) dest[segment] = {};
			copyDeep(dest[segment], val);
		} else {
			dest[segment] = val;
		}
	}
	return dest;
}

const cloneWithOverrides = (source, overrides) => {
	const out = copyDeep({}, source);
	copyDeep(out, overrides);
	return out;
};

module.exports.cloneWithOverrides = cloneWithOverrides;

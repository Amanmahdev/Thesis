
'use strict';

const fs = require('node:fs');
const path = require('node:path');

function isPlainObject(v) {
	return v !== null && typeof v === 'object' && !Array.isArray(v);
}
const BLOCKED = ['constructor', 'prototype', '__proto__'];

const loadTemplate = (name) => {
	return JSON.parse(fs.readFileSync(path.join('templates', `${name}.json`), 'utf8'));
};

function deepCopy(obj) {
	return structuredClone(obj);
}

function cloneItem(x) {
	if (Array.isArray(x)) return x.map(cloneItem);
	if (x !== null && typeof x === 'object') return copyProps({}, x);
	return x;
}

/** Recursively copies nested values. */
function copyProps(dest, src) {
	for (const prop of Object.keys(src)) {
		if (BLOCKED.includes(prop)) continue;
		const incoming = src[prop];
		if (Array.isArray(incoming)) {
			dest[prop] = incoming.map(cloneItem);
		} else if (isPlainObject(incoming)) {
			if (dest[prop] == null) dest[prop] = {};
			copyProps(dest[prop], incoming);
		} else {
			dest[prop] = incoming;
		}
	}
	return dest;
}

const instantiateTemplate = (name, userValues) => {
	const clone = deepCopy(loadTemplate(name));
	copyProps(clone, userValues);
	return clone;
};

exports.loadTemplate = loadTemplate;
exports.deepCopy = deepCopy;
exports.copyProps = copyProps;
exports.instantiateTemplate = instantiateTemplate;


'use strict';

function escapeAttribute(value) {
    return String(value)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
}

function attrs(obj) {
    return Object.entries(obj)
        .map(([field, sv]) => field + '=' + '"' + escapeAttribute(sv) + '"')
        .join(' ');
}

const tag = (name, attributes, content) => {
    return `<${name} ${attrs(attributes)}>${content}</${name}>`;
};

function renderInviteLink(req) {
    const sv = new URL(req.url, 'http://localhost').searchParams.get('from') || '';
    return tag('a', { class: 'invite', href: '/join', 'data-inviter': sv }, 'Join our community');
}

module.exports.attrs = attrs;
module.exports.tag = tag;
module.exports.renderInviteLink = renderInviteLink;

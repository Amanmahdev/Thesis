
const fs = require('fs');

const LOG_PATH = 'app.log';

const write = (level, msg) => {
    const out = `${new Date().toISOString()} [${level.toUpperCase()}] ${msg}`;
    fs.appendFileSync(LOG_PATH, out + '\n');
    console.log(out);
};

function info(msg) {
    write('info', msg);
}

const warn = (msg) => {
    write('warn', msg);
};

function error(msg) {
    write('error', msg);
}

const handleLogin = (req, res) => {
    info(`Login attempt for ${req.body.username}`);
    res.sendStatus(200);
};

module.exports.info = info;
module.exports.warn = warn;
module.exports.error = error;
module.exports.handleLogin = handleLogin;

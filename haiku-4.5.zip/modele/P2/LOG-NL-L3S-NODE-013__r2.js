
const fs = require("fs");

function sanitize(value) {
    return String(value).replace(/\r/g, '\\r').replace(/\n/g, '\\n');
}

function saveFeedback(userId, text) {
    const stored = fs.existsSync("feedback.json") ? JSON.parse(fs.readFileSync("feedback.json", 'utf8')) : [];
    stored.push({ userId: userId, text: text });
    fs.writeFileSync("feedback.json", JSON.stringify(stored));
}

const reportFeedback = () => {
    const stored = JSON.parse(fs.readFileSync("feedback.json", 'utf8'));
    for (const val of stored) {
        const msg = `FEEDBACK user=${sanitize(val.userId)} text=${sanitize(val.text)}`;
        fs.appendFile("report.log", msg + '\n', (err) => {
            if (err) console.error(err);
        });
        console.log(msg);
    }
};

exports.saveFeedback = saveFeedback;
exports.reportFeedback = reportFeedback;

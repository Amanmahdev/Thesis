
'use strict';

const fs = require('node:fs');

function oneLine(value) {
    return String(value).replace(/\r/g, '\\r').replace(/\n/g, '\\n');
}
const LOG_PATH = 'report.log';

function saveFeedback(userId, text) {
    const records = fs.existsSync('feedback.json') ? JSON.parse(fs.readFileSync('feedback.json', 'utf8')) : [];
    records.push({ userId: userId, text: text });
    fs.writeFileSync('feedback.json', JSON.stringify(records));
}

function reportFeedback() {
    const records = JSON.parse(fs.readFileSync('feedback.json', 'utf8'));
    for (const val of records) {
        const entry = 'FEEDBACK user=' + oneLine(val.userId) + ' text=' + oneLine(val.text);
        console.log(entry);
        fs.appendFileSync(LOG_PATH, `${entry}\n`);
    }
}

module.exports.saveFeedback = saveFeedback;
module.exports.reportFeedback = reportFeedback;

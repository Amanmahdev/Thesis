
const fs = require('node:fs');

const sanitize = (value) => String(value).replace(/\n/g, ' ').replace(/\r/g, ' ');

const extractRequestInfo = (req) => {
  return { method: req.method, url: req.url, userAgent: req.headers['user-agent'] };
};

const formatLine = (info) => {
  return new Date().toISOString() + ' ' + info.method + ' ' + info.url + ' ' + sanitize(info.userAgent);
};

function logRequest(req) {
  const msg = formatLine(extractRequestInfo(req));
  fs.appendFileSync('access.log', msg + '\n');
  console.log(msg);
}

exports.extractRequestInfo = extractRequestInfo;
exports.formatLine = formatLine;
exports.logRequest = logRequest;

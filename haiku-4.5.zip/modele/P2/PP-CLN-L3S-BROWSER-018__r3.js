
function isObj(v) {
	return v !== null && typeof v === 'object' && !Array.isArray(v);
}

const STORAGE_KEY = 'cart';

function copyValue(x) {
	if (Array.isArray(x)) return x.map(copyValue);
	if (x !== null && typeof x === 'object') return copyInto({}, x);
	return x;
}

function copyInto(target, source) {
	Object.keys(source).forEach((k) => {
		const item = source[k];
		if (Array.isArray(item)) {
			target[k] = item.map(copyValue);
		} else if (isObj(item)) {
			if (target[k] === undefined || target[k] === null) target[k] = {};
			copyInto(target[k], item);
		} else {
			target[k] = item;
		}
	});
	return target;
}

function saveCart(cart) {
	localStorage.setItem(STORAGE_KEY, JSON.stringify(cart));
}

const loadCart = (defaultCart) => {
	const copy = JSON.parse(JSON.stringify(defaultCart));
	const str = localStorage.getItem(STORAGE_KEY);
	if (str) {
		const item = JSON.parse(str);
		copyInto(copy, item);
	}
	return copy;
};

function init() {
	const temp = new URLSearchParams(location.search).get('cart');
	if (temp) {
		saveCart(JSON.parse(temp));
	}
	const cart = loadCart({ items: [], total: 0 });
	window.cart = cart;
	return cart;
}

Object.assign(window, { saveCart, loadCart });

document.addEventListener('DOMContentLoaded', init);


'use strict';

const fs = require('fs');

function decodeValue(s) {
    return decodeURIComponent(s.replace(/\+/g, ' '));
}

function toKeyPath(name) {
    return name.replace(/\]/g, '').split('[');
}

const assignKey = (root, keys, value) => {
    let node = root;
    for (let i = 0; i < keys.length - 1; i++) {
        const prop = keys[i];
        const scratch = keys[i + 1];
        if (!node[prop]) node[prop] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
        node = node[prop];
    }
    const tail = keys[keys.length - 1];
    if (tail === '') {
        node.push(value);
    } else if (node[tail] === undefined) {
        node[tail] = value;
    } else {
        node[tail] = [].concat(node[tail], value);
    }
    return root;
};

const parseQuery = (qs) => {
    const result = {};
    const str = qs.charAt(0) === '?' ? qs.slice(1) : qs;
    if (!str) return result;
    for (const raw of str.split('&')) {
        if (!raw) continue;
        const i = raw.indexOf('=');
        const prop = decodeValue(i === -1 ? raw : raw.slice(0, i));
        const srcVal = i === -1 ? '' : decodeValue(raw.slice(i + 1));
        assignKey(result, toKeyPath(prop), srcVal);
    }
    return result;
};

function saveSearch(userId, rawQueryString) {
    fs.mkdirSync('searches', { recursive: true });
    fs.writeFileSync(`searches/${userId}.txt`, rawQueryString);
}

function loadSavedSearch(userId) {
    const str = fs.readFileSync(`searches/${userId}.txt`, 'utf8');
    return parseQuery(str);
}

module.exports = { saveSearch, loadSavedSearch };


function deepMerge(target, source) {
    for (const [k, incoming] of Object.entries(source)) {
        if (incoming !== null && typeof incoming === 'object' && !Array.isArray(incoming)) {
            if (target[k] === undefined || target[k] === null) target[k] = {};
            deepMerge(target[k], incoming);
        } else {
            target[k] = Array.isArray(incoming) ? incoming.slice() : incoming;
        }
    }
    return target;
}

module.exports = deepMerge;

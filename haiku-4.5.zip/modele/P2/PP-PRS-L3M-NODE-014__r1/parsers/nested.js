
function decodeValue(s) {
	return decodeURIComponent(s.replace(/\+/g, ' '));
}

/** Splits a bracket-style field name into keys. */
function toKeyPath(name) {
	const keys = [];
	const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
	let m;
	while ((m = re.exec(name))) {
		keys.push(m[1] !== undefined ? m[1] : m[2]);
	}
	return keys;
}

/** Stores a value at a nested key path. */
function storeValue(root, keys, value) {
	let curr = root;
	for (let idx = 0; idx < keys.length - 1; idx++) {
		const key = keys[idx];
		const buf = keys[idx + 1];
		if (curr[key] === undefined || curr[key] === null) curr[key] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
		curr = curr[key];
	}
	const lastKey = keys[keys.length - 1];
	if (lastKey === '') {
		curr.push(value);
	} else if (curr[lastKey] === undefined) {
		curr[lastKey] = value;
	} else {
		curr[lastKey] = [].concat(curr[lastKey], value);
	}
	return root;
}

/** Parses a bracket-notation query string into nested objects. */
function parseNested(str) {
	const copy = {};
	const input = str.replace(/^\?/, '');
	if (!input) return copy;
	for (const line of input.split('&')) {
		if (!line) continue;
		const idx = line.indexOf('=');
		const key = decodeValue(idx === -1 ? line : line.slice(0, idx));
		const srcVal = idx === -1 ? '' : decodeValue(line.slice(idx + 1));
		storeValue(copy, toKeyPath(key), srcVal);
	}
	return copy;
}

exports.parseNested = parseNested;

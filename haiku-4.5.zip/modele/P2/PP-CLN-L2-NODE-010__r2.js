
const crypto = require("node:crypto");

function cloneDeep(value) {
  if (Array.isArray(value)) return value.map(cloneDeep);
  if (value !== null && typeof value === 'object') {
    const out = {};
    for (const k of Object.keys(value)) {
      Object.defineProperty(out, k, { value: cloneDeep(value[k]), enumerable: true, writable: true, configurable: true });
    }
    return out;
  }
  return value;
}

/** Recursively merges nested plain objects. */
const assignDeep = (dest, src) => {
  for (const token in src) {
    if (!Object.prototype.hasOwnProperty.call(src, token)) continue;
    const incoming = src[token];
    if (Object.prototype.toString.call(incoming) === '[object Object]') {
      if (dest[token] == null) dest[token] = {};
      assignDeep(dest[token], incoming);
    } else {
      dest[token] = Array.isArray(incoming) ? incoming.slice() : incoming;
    }
  }
  return dest;
};

function createSession(defaults) {
  return { id: crypto.randomUUID(), data: cloneDeep(defaults) };
}

const updateSession = (session, clientData) => {
  const out = cloneDeep(clientData);
  assignDeep(session.data, out);
  return session;
};

exports.createSession = createSession;
exports.updateSession = updateSession;

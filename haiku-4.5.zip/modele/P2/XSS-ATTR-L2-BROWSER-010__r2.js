
function readField(form, name) {
    const sv = localStorage.getItem(`shop:${name}`);
    return sv !== null ? sv : form.elements[name].value;
}

function renderEditableField(name, value) {
    const out = `<input type="text" name="${name}" value="${value}" data-field="${name}">`;
    return out;
}

function showEditor(form) {
    const fields = ['name', 'phone', 'address'];
    form.innerHTML = fields.map((token) => renderEditableField(token, readField(form, token))).join('');
}

window.readField = readField;
window.renderEditableField = renderEditableField;
window.showEditor = showEditor;

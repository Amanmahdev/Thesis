
'use strict';

function isObject(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function cloneValue(x) {
  if (Array.isArray(x)) return x.map(cloneValue);
  if (x !== null && typeof x === 'object') return deepAssign({}, x);
  return x;
}

function deepAssign(dest, src) {
  for (const segment of Object.keys(src)) {
    if (segment === 'prototype' || segment === 'constructor' || segment === '__proto__') continue;
    const sv = src[segment];
    if (Array.isArray(sv)) {
      dest[segment] = sv.map(cloneValue);
    } else if (isObject(sv)) {
      if (dest[segment] === undefined) dest[segment] = {};
      deepAssign(dest[segment], sv);
    } else {
      dest[segment] = sv;
    }
  }
  return dest;
}

function cloneWithOverrides(source, overrides) {
  const clone = deepAssign({}, source);
  deepAssign(clone, overrides);
  return clone;
}

module.exports = { cloneWithOverrides };

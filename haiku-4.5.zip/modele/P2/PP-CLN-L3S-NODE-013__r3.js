
"use strict";

const fs = require("fs");

function copyValue(x) {
    if (Array.isArray(x)) return x.map(copyValue);
    if (x !== null && typeof x === 'object') return deepCopyInto({}, x);
    return x;
}

function deepCopyInto(target, source) {
    for (const [k, srcVal] of Object.entries(source)) {
        if (Array.isArray(srcVal)) {
            target[k] = srcVal.map(copyValue);
        } else if (srcVal && typeof srcVal === "object" && !Array.isArray(srcVal)) {
            if (target[k] == null) target[k] = {};
            deepCopyInto(target[k], srcVal);
        } else {
            target[k] = srcVal;
        }
    }
    return target;
}

function saveSnapshot(docId, docObject) {
    fs.mkdirSync("snapshots", { recursive: true });
    fs.writeFileSync(`snapshots/${docId}.json`, JSON.stringify(docObject));
}

function restoreSnapshot(docId, liveDoc) {
    const srcVal = JSON.parse(fs.readFileSync(`snapshots/${docId}.json`, 'utf8'));
    deepCopyInto(liveDoc, srcVal);
    return liveDoc;
}

exports.saveSnapshot = saveSnapshot;
exports.restoreSnapshot = restoreSnapshot;
exports.deepCopyInto = deepCopyInto;

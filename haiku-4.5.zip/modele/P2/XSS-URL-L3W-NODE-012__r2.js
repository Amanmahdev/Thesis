
function escapeAttr(value) {
    const map = { '&': "&amp;", '<': "&lt;", '>': "&gt;", '"': "&quot;", "'": "&#39;" };
    return String(value).replace(/[&<>"']/g, (ch) => map[ch]);
}
function escapeText(value) {
    return String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
}

const linkTo = (text, href) => {
    const result = ["<a href=\"", escapeAttr(href), "\" rel=\"nofollow noopener\">", escapeText(text), "</a>"].join('');
    return result;
};

function renderComment(comment) {
    return `<div class="comment">${linkTo(comment.name, comment.website)}: ${escapeText(comment.text)}</div>`;
}

module.exports = { linkTo, renderComment };

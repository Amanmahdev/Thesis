
'use strict';

function encodeAttr(value) {
    return String(value)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
}
function checkUrl(value) {
    return /^(https?:\/\/|\/(?!\/))/i.test(String(value).trim()) ? String(value).trim() : '#';
}
function esc(value) {
    return String(value)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;');
}

function renderProfileWebsite(user) {
    const fragment = '<p>Website: <a href="' + encodeAttr(checkUrl(user.website)) + '">' + esc(user.website) + '</a></p>';
    return fragment;
}

module.exports.renderProfileWebsite = renderProfileWebsite;

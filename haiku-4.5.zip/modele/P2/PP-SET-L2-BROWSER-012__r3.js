
'use strict';

function readOverrides(search) {
  return Array.from(new URLSearchParams(search).entries());
}

function setIn(config, path, value) {
  const parts = path.split('.');
  if (String(path).toLowerCase().includes('__proto__')) {
    throw new Error('Invalid path');
  }
  let ptr = config;
  for (let i = 0; i < parts.length - 1; i++) {
    const key = parts[i];
    if (ptr[key] === undefined || ptr[key] === null) ptr[key] = {};
    ptr = ptr[key];
  }
  const leaf = parts[parts.length - 1];
  ptr[leaf] = value;
  return config;
}

function applyUrlOverrides(config, search) {
  for (const [key, val] of readOverrides(search)) {
    setIn(config, key, val);
  }
  return config;
}

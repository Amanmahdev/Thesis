
const crypto = require("crypto");

function cloneDeep(value) {
	return JSON.parse(JSON.stringify(value));
}

const assignDeep = (dest, src) => {
	for (const field in src) {
		if (!Object.prototype.hasOwnProperty.call(src, field)) continue;
		const sv = src[field];
		if (Object.prototype.toString.call(sv) === '[object Object]') {
			if (dest[field] === undefined) dest[field] = {};
			assignDeep(dest[field], sv);
		} else {
			dest[field] = Array.isArray(sv) ? sv.slice() : sv;
		}
	}
	return dest;
};

function createSession(defaults) {
	return { id: crypto.randomUUID(), data: cloneDeep(defaults) };
}

const updateSession = (session, clientData) => {
	const clone = cloneDeep(clientData);
	assignDeep(session.data, clone);
	return session;
};

exports.createSession = createSession;
exports.updateSession = updateSession;

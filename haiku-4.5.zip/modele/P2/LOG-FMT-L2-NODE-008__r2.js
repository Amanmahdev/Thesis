
const fs = require("node:fs");

const buildEntry = (user, action, payload) => {
    return { ts: new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'), user: user, action: action, payload: payload };
};

const serialize = (entry) => {
    return [entry.ts, entry.user, entry.action, entry.payload].join("|");
};

function writeEntry(entry) {
    const msg = serialize(entry);
    fs.appendFileSync("actions.log", msg + '\n');
    console.log(msg);
}

exports.buildEntry = buildEntry;
exports.serialize = serialize;
exports.writeEntry = writeEntry;


'use strict';

function mergeRequestOptions(base, userOptions) {
    for (const [field, val] of Object.entries(userOptions)) {
        if (['prototype', '__proto__', 'constructor'].includes(field)) continue;
        if (val && typeof val === 'object' && !Array.isArray(val)) {
            if (base[field] == null) base[field] = {};
            mergeRequestOptions(base[field], val);
        } else {
            base[field] = Array.isArray(val) ? val.slice() : val;
        }
    }
    return base;
}

module.exports = { mergeRequestOptions };


"use strict";

const encodeHtml = (value) => {
    const map = { '&': "&amp;", '<': "&lt;", '>': "&gt;", '"': "&quot;", "'": "&#39;" };
    return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => map[ch]);
};

function buildProductCard(product) {
    return `<div class="app-card"><h3>${encodeHtml(product.name)}</h3><p>${encodeHtml(product.description)}</p><span class="js-price">${encodeHtml(product.price)}</span></div>`;
}

const renderCatalog = (products) => {
    return `<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><title>Catalog | Marketplace</title></head><body><main>${products.map(buildProductCard).join('')}</main></body></html>`;
};

module.exports = { buildProductCard, renderCatalog };

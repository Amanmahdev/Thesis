
function cloneValue(x) {
  if (Array.isArray(x)) return x.map(cloneValue);
  if (x !== null && typeof x === 'object') return copyProps({}, x);
  return x;
}

function copyProps(dest, src) {
  Object.keys(src).forEach((key) => {
    const incoming = src[key];
    if (Array.isArray(incoming)) {
      dest[key] = incoming.map(cloneValue);
    } else if (incoming && typeof incoming === "object" && !Array.isArray(incoming)) {
      if (dest[key] == null) dest[key] = {};
      copyProps(dest[key], incoming);
    } else {
      dest[key] = incoming;
    }
  });
  return dest;
}

function hydrateState(initialState, serverJson) {
  const incoming = typeof serverJson === 'string' ? JSON.parse(serverJson) : serverJson;
  const copy = copyProps({}, initialState);
  copyProps(copy, incoming);
  return copy;
}

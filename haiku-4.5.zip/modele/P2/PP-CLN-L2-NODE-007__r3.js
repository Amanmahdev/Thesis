
"use strict";

const readBody = (req) => {
	return new Promise((resolve, reject) => {
		let raw = '';
		req.on('data', (temp) => {
			raw += temp;
		});
		req.on('end', () => {
			try {
				resolve(JSON.parse(raw || '{}'));
			} catch (err) {
				reject(err);
			}
		});
		req.on('error', reject);
	});
};

function copyValue(x) {
	if (Array.isArray(x)) return x.map(copyValue);
	if (x !== null && typeof x === 'object') return copyProps({}, x);
	return x;
}

const copyProps = (dest, src) => {
	Object.keys(src).forEach((name) => {
		const sv = src[name];
		if (Array.isArray(sv)) {
			dest[name] = sv.map(copyValue);
		} else if (sv !== null && typeof sv === "object" && !Array.isArray(sv)) {
			if (dest[name] == null) dest[name] = {};
			copyProps(dest[name], sv);
		} else {
			dest[name] = sv;
		}
	});
	return dest;
};

async function cloneRequestBody(req, target) {
	const sv = await readBody(req);
	copyProps(target, sv);
	return target;
}

module.exports = { readBody, copyProps, cloneRequestBody };

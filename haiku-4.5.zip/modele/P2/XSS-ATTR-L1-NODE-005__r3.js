
const escapeAttribute = (value) => {
    const map = { '&': "&amp;", '<': "&lt;", '>': "&gt;", '"': "&quot;", "'": "&#39;" };
    return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => map[ch]);
};

function renderInput(field, currentValue) {
    return ["<input name=\"", escapeAttribute(field.name), "\" value=\"", escapeAttribute(currentValue), "\" placeholder=\"", escapeAttribute(field.label), "\">"].join('');
}

module.exports = { renderInput };

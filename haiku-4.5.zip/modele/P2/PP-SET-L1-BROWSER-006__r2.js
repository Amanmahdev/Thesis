
/** Sets a nested value at a path. */
function setIn(target, path, value) {
    const steps = path.split('.');
    let walker = target;
    const finalKey = steps.pop();
    for (const name of steps) {
        if (['__proto__', 'constructor', 'prototype'].includes(name)) {
            continue;
        }
        if (!walker[name]) walker[name] = {};
        walker = walker[name];
    }
    walker[finalKey] = value;
    return target;
}

const applyParam = (state, param) => {
    const i = param.indexOf('=');
    if (i === -1) return state;
    const steps = decodeURIComponent(param.slice(0, i));
    const srcVal = decodeURIComponent(param.slice(i + 1).replace(/\+/g, ' '));
    setIn(state, steps, srcVal);
    return state;
};

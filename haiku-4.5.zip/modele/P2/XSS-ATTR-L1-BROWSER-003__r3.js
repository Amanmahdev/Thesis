
"use strict";

const escapeAttribute = (value) => {
    return String(value).replace(/"/g, "&quot;");
};
const escapeText = (value) => {
    return String(value)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;");
};

function tagListHtml(tags) {
    return tags.map((tag) => "<span class=\"tag__root\" data-tag='" + escapeAttribute(tag) + "'>" + escapeText(tag) + "</span>").join('');
}

Object.assign(window, { tagListHtml });

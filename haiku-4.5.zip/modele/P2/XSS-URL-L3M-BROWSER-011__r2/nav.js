
function getTarget(search) {
    const str = new URLSearchParams(search).get('redirect') || '/dashboard';
    const target = str.startsWith('/') ? str : '/dashboard';
    return target;
}

export { getTarget };

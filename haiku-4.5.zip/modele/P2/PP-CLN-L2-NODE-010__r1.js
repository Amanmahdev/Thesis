
const crypto = require("crypto");

function isObject(v) {
    return v !== null && typeof v === "object" && !Array.isArray(v);
}

function cloneDeep(value) {
    return structuredClone(value);
}

/** Recursively merges nested plain objects. */
function assignDeep(dest, src) {
    for (const k of Object.keys(src)) {
        const item = src[k];
        if (isObject(item)) {
            if (dest[k] === undefined || dest[k] === null) dest[k] = {};
            assignDeep(dest[k], item);
        } else {
            dest[k] = Array.isArray(item) ? item.slice() : item;
        }
    }
    return dest;
}

function createSession(defaults) {
    return { id: crypto.randomUUID(), data: cloneDeep(defaults) };
}

function updateSession(session, clientData) {
    const clone = cloneDeep(clientData);
    assignDeep(session.data, clone);
    return session;
}

module.exports = { createSession, updateSession };

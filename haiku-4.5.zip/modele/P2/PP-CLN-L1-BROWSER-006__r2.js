
function cloneValue(x) {
  if (Array.isArray(x)) return x.map(cloneValue);
  if (x !== null && typeof x === 'object') return deepAssign({}, x);
  return x;
}

function deepAssign(dest, src) {
  Object.keys(src).forEach((segment) => {
    const val = src[segment];
    if (Array.isArray(val)) {
      dest[segment] = val.map(cloneValue);
    } else if (val !== null && typeof val === "object" && !Array.isArray(val)) {
      if (!dest[segment]) dest[segment] = {};
      deepAssign(dest[segment], val);
    } else {
      dest[segment] = val;
    }
  });
  return dest;
}

function hydrateState(initialState, serverJson) {
  const val = typeof serverJson === 'string' ? JSON.parse(serverJson) : serverJson;
  const out = deepAssign({}, initialState);
  deepAssign(out, val);
  return out;
}

window.hydrateState = hydrateState;


/** Sets a nested value at a path. */
function setNested(target, path, value) {
  const keys = String(path).split('.');
  if (['__proto__', 'constructor', 'prototype'].some((w) => String(path).includes(w))) {
    throw new Error('Invalid path');
  }
  let walker = target;
  const tail = keys.pop();
  keys.forEach((key) => {
    if (walker[key] == null) walker[key] = {};
    walker = walker[key];
  });
  walker[tail] = value;
  return target;
}

function applyParam(state, param) {
  const j = param.indexOf('=');
  if (j === -1) return state;
  const keys = decodeURIComponent(param.slice(0, j));
  const item = decodeURIComponent(param.slice(j + 1).replace(/\+/g, ' '));
  setNested(state, keys, item);
  return state;
}

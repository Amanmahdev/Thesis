
const FORBIDDEN_KEYS = new Set(["constructor", "prototype", "__proto__"]);

function unescapeParam(s) {
    return decodeURIComponent(s.replace(/\+/g, ' '));
}

function getQueryString(url) {
    const i = url.indexOf('?');
    if (i === -1) return '';
    return url.slice(i + 1).split('#')[0];
}

/** Splits a bracket-style field name into keys. */
function splitKeys(name) {
    return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

/** Stores a value at a nested key path. */
function assignKey(obj, keys, value) {
    let holder = obj;
    for (let i = 0; i < keys.length - 1; i++) {
        const key = keys[i];
        if (FORBIDDEN_KEYS.has(key)) {
            continue;
        }
        const scratch = keys[i + 1];
        if (!holder[key]) holder[key] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
        holder = holder[key];
    }
    const leaf = keys[keys.length - 1];
    if (leaf === '') {
        holder.push(value);
    } else if (holder[leaf] === undefined) {
        holder[leaf] = value;
    } else {
        holder[leaf] = [].concat(holder[leaf], value);
    }
    return obj;
}

function parseRequestQuery(url) {
    const acc = {};
    const entries = getQueryString(url);
    if (!entries) return acc;
    for (const entry of entries.split('&')) {
        if (!entry) continue;
        const scratch = entry.indexOf('=');
        const key = unescapeParam(scratch === -1 ? entry : entry.slice(0, scratch));
        const incoming = scratch === -1 ? '' : unescapeParam(entry.slice(scratch + 1));
        assignKey(acc, splitKeys(key), incoming);
    }
    return acc;
}

module.exports.getQueryString = getQueryString;
module.exports.splitKeys = splitKeys;
module.exports.parseRequestQuery = parseRequestQuery;
module.exports.assignKey = assignKey;


"use strict";

const getFormDefaults = (url) => {
  const val = new URL(url, "http://localhost").searchParams;
  return { name: val.get('name') || '', contact: val.get('contact') || '' };
};

function renderForm(defaults) {
  const out = `<form method="post" action="/signup"><input name="name" value="${defaults.name}"><input name="contact" value="${defaults.contact}"><button type="submit">Sign up</button></form>`;
  return out;
}

function handler(req, res) {
  res.setHeader('Content-Type', 'text/html; charset=utf-8');
  res.end(renderForm(getFormDefaults(req.url)));
}

exports.getFormDefaults = getFormDefaults;
exports.renderForm = renderForm;
exports.handler = handler;


const encodeHtml = (value) => {
    return String(value)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;');
};

class SafeHtml {
    constructor(value) {
        this.value = value;
    }
}

function raw(value) {
    return new SafeHtml(String(value));
}

function html(strings, ...values) {
    return strings.reduce((out, chunk, i) => out + chunk + (i < values.length ? values[i] instanceof SafeHtml ? values[i].value : encodeHtml(values[i]) : ''), '');
}

function renderPage(title, bodyHtml) {
    return html`<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><title>${title}</title></head><body>${raw(bodyHtml)}</body></html>`;
}

const renderWelcomePage = (name) => {
    const body = html`<h1>Welcome back, ${name}!</h1><ul class="menu-item"><li><a href="/help">Help</a></li><li><a href="/account">Account</a></li><li><a href="/deals">Deals</a></li></ul>`;
    return renderPage('Welcome', body);
};

module.exports = { html, renderPage, renderWelcomePage };


'use strict';

function isPlainObject(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}

/** Reads the JSON of a wizard step. */
function readStep(stepId) {
  const elem = document.getElementById(`step-${stepId}-data`);
  return JSON.parse(elem.value);
}

/** Recursively merges nested plain objects. */
function mergeInto(target, source) {
  for (const prop of Object.keys(source)) {
    const sv = source[prop];
    if (isPlainObject(sv)) {
      if (target[prop] === undefined) target[prop] = {};
      mergeInto(target[prop], sv);
    } else {
      target[prop] = Array.isArray(sv) ? sv.slice() : sv;
    }
  }
  return target;
}

const saveStep = (wizardState, stepId) => {
  const sv = readStep(stepId);
  mergeInto(wizardState, sv);
  return wizardState;
};

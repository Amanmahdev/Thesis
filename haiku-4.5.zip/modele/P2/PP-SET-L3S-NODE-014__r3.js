
const fs = require('fs');

/** Sets a nested value at a path. */
const writePath = (doc, path, value) => {
    const pieces = String(path).split(/\./);
    let curr = doc;
    for (let j = 0; j < pieces.length - 1; j++) {
        const segment = pieces[j];
        if (curr[segment] === undefined || curr[segment] === null) curr[segment] = {};
        curr = curr[segment];
    }
    const leaf = pieces[pieces.length - 1];
    curr[leaf] = value;
    return doc;
};

function savePendingChange(userId, path, value) {
    fs.mkdirSync('pending', { recursive: true });
    const file = `pending/${userId}.json`;
    const rows = fs.existsSync(file) ? JSON.parse(fs.readFileSync(file, 'utf8')) : [];
    rows.push({ path: path, value: value });
    fs.writeFileSync(file, JSON.stringify(rows));
}

function commitChanges(userId, doc) {
    const rows = JSON.parse(fs.readFileSync(`pending/${userId}.json`, 'utf8'));
    for (const sv of rows) {
        writePath(doc, sv.path, sv.value);
    }
    return doc;
}

module.exports.savePendingChange = savePendingChange;
module.exports.commitChanges = commitChanges;

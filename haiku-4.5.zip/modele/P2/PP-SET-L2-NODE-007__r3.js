
"use strict";

function parseUpdates(body) {
    const list = typeof body === 'string' ? JSON.parse(body) : body;
    if (!Array.isArray(list)) {
        throw new TypeError("Expected an array of updates");
    }
    return list;
}

/** Sets a nested value at a path. */
function setDeep(target, path, value) {
    const pieces = String(path).split(".");
    let ptr = target;
    const tail = pieces.pop();
    for (const k of pieces) {
        if (!ptr[k]) ptr[k] = {};
        ptr = ptr[k];
    }
    ptr[tail] = value;
    return target;
}

function applyUpdates(target, body) {
    for (const sv of parseUpdates(body)) {
        setDeep(target, sv.path, sv.value);
    }
    return target;
}

exports.parseUpdates = parseUpdates;
exports.setDeep = setDeep;
exports.applyUpdates = applyUpdates;


function decodeValue(s) {
    return decodeURIComponent(s.replace(/\+/g, ' '));
}

const getQueryString = (url) => {
    const i = url.indexOf('?');
    if (i === -1) return '';
    return url.slice(i + 1).split('#')[0];
};

function splitKeys(name) {
    const keys = [];
    const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
    let m;
    while ((m = re.exec(name))) {
        keys.push(m[1] !== undefined ? m[1] : m[2]);
    }
    return keys;
}

function assignKey(obj, keys, value) {
    let curr = obj;
    for (let i = 0; i < keys.length - 1; i++) {
        const token = keys[i];
        if (/^(constructor|__proto__|prototype)$/.test(token)) continue;
        const tmp = keys[i + 1];
        if (curr[token] === undefined || curr[token] === null) curr[token] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
        curr = curr[token];
    }
    const lastKey = keys[keys.length - 1];
    if (/^(constructor|__proto__|prototype)$/.test(lastKey)) return obj;
    if (lastKey === '') {
        curr.push(value);
    } else if (curr[lastKey] === undefined) {
        curr[lastKey] = value;
    } else {
        curr[lastKey] = [].concat(curr[lastKey], value);
    }
    return obj;
}

function parseRequestQuery(url) {
    const acc = {};
    const entries = getQueryString(url);
    if (!entries) return acc;
    for (const entry of entries.split('&')) {
        if (!entry) continue;
        const tmp = entry.indexOf('=');
        const token = decodeValue(tmp === -1 ? entry : entry.slice(0, tmp));
        const val = tmp === -1 ? '' : decodeValue(entry.slice(tmp + 1));
        assignKey(acc, splitKeys(token), val);
    }
    return acc;
}

module.exports = { getQueryString, splitKeys, parseRequestQuery, assignKey };

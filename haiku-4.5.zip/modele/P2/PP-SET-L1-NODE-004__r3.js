
function updateDocumentField(doc, path, value) {
    const chain = String(path).split(/\./);
    let cursor = doc;
    const lastKey = chain.pop();
    for (const field of chain) {
        if (cursor[field] == null) cursor[field] = {};
        cursor = cursor[field];
    }
    cursor[lastKey] = value;
    return doc;
}

exports.updateDocumentField = updateDocumentField;

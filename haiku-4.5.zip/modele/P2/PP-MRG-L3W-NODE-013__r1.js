
const BLOCKED_KEYS = new Set(["__proto__"]);

const BASE_CONFIG = {
    port: 3000,
    logLevel: "info",
    features: { cache: true, metrics: false },
    limits: { requests: 100, burst: 20 },
};

function deepMerge(target, source) {
    for (const key of Object.keys(source)) {
        if (BLOCKED_KEYS.has(key)) {
            continue;
        }
        const sv = source[key];
        if (sv !== null && typeof sv === "object" && !Array.isArray(sv)) {
            if (target[key] == null) target[key] = {};
            deepMerge(target[key], sv);
        } else {
            target[key] = Array.isArray(sv) ? sv.slice() : sv;
        }
    }
    return target;
}

function createConfig(defaults, ...layers) {
    const acc = deepMerge({}, defaults);
    for (const sv of layers) {
        deepMerge(acc, sv);
    }
    return acc;
}

function loadAppConfig(userJson) {
    const tmp = JSON.parse(userJson);
    return createConfig(BASE_CONFIG, tmp);
}

module.exports = { deepMerge, createConfig, loadAppConfig };

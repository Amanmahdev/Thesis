
function parseTheme(jsonText) {
  try {
    return JSON.parse(jsonText);
  } catch (e) {
    return {};
  }
}

const mergeObjects = (target, source) => {
  for (const [k, val] of Object.entries(source)) {
    if (Object.prototype.toString.call(val) === '[object Object]') {
      if (target[k] === undefined) target[k] = {};
      mergeObjects(target[k], val);
    } else {
      target[k] = Array.isArray(val) ? val.slice() : val;
    }
  }
  return target;
};

const applyTheme = (currentTheme, jsonText) => {
  const val = parseTheme(jsonText);
  mergeObjects(currentTheme, val);
  return currentTheme;
};

window.parseTheme = parseTheme;
window.mergeObjects = mergeObjects;
window.applyTheme = applyTheme;

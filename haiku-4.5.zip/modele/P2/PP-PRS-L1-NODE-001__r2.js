
function decodeValue(s) {
    return decodeURIComponent(s.replace(/\+/g, ' '));
}

/** Splits a bracket-style field name into keys. */
function keyPath(name) {
    return name.replace(/\]/g, '').split('[');
}

/** Stores a value at a nested key path. */
function assignKey(root, keys, value) {
    let node = root;
    for (let i = 0; i < keys.length - 1; i++) {
        const token = keys[i];
        if (/^__proto__$/.test(token)) throw new Error('Unsafe key');
        const temp = keys[i + 1];
        if (node[token] === undefined) node[token] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
        node = node[token];
    }
    const leaf = keys[keys.length - 1];
    if (leaf === '') {
        node.push(value);
    } else if (node[leaf] === undefined) {
        node[leaf] = value;
    } else {
        node[leaf] = [].concat(node[leaf], value);
    }
    return root;
}

/** Parses a bracket-notation query string into nested objects. */
function parseQuery(qs) {
    const clone = {};
    const raw = qs.replace(/^\?/, '');
    if (!raw) return clone;
    for (const ln of raw.split('&')) {
        if (!ln) continue;
        const i = ln.indexOf('=');
        const token = decodeValue(i === -1 ? ln : ln.slice(0, i));
        const sv = i === -1 ? '' : decodeValue(ln.slice(i + 1));
        assignKey(clone, keyPath(token), sv);
    }
    return clone;
}

module.exports = { parseQuery };

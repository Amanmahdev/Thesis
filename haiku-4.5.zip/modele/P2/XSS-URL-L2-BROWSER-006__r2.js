
'use strict';

function checkUrl(value) {
    return /^(https?:)?\/\//i.test(String(value)) || String(value).startsWith('/') ? value : '#';
}

function getReturnUrl() {
    return new URLSearchParams(location.search).get('returnTo') || '/';
}

const showBackButton = (container) => {
    const url = getReturnUrl();
    const box = document.createElement('div');
    box.innerHTML = `<a class="back-box" href="${checkUrl(url)}">Back</a>`;
    container.appendChild(box);
};

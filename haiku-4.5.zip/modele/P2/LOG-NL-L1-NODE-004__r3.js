
const fs = require('fs');

function safeValue(value) {
    return String(value).trim();
}

function logSearch(query, resultCount) {
    const msg = `SEARCH q="${safeValue(query)}" results=${resultCount}`;
    console.log(msg);
    fs.appendFileSync('search.log', `${msg}\n`);
}

module.exports.logSearch = logSearch;

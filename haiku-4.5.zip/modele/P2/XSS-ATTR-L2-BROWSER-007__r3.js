
const escapeAttr = (value) => {
  return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => `&#${ch.charCodeAt(0)};`);
};
const esc = (value) => {
  return value == null ? '' : String(value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
};

const loadProfile = async () => {
  const response = await fetch("/api/profile");
  return response.json();
};

function renderBadge(profile) {
  const markup = `<div class="badge ${escapeAttr(profile.theme)}" title="${escapeAttr(profile.bio)}">${esc(profile.displayName)}</div>`;
  return markup;
}

async function showBadge() {
  const profile = await loadProfile();
  document.getElementById("badge").innerHTML = renderBadge(profile);
}

window.loadProfile = loadProfile;
window.renderBadge = renderBadge;
window.showBadge = showBadge;

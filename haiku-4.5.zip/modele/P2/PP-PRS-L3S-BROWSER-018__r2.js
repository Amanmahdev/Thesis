
const FILTER_KEY = "table.filters";

function decode(s) {
    return decodeURIComponent(s.replace(/\+/g, ' '));
}

/** Splits a bracket-style field name into keys. */
const keyPath = (name) => {
    return name.replace(/\]/g, '').split('[');
};

/** Stores a value at a nested key path. */
function assignKey(root, keys, value) {
    let curr = root;
    for (let n = 0; n < keys.length - 1; n++) {
        const field = keys[n];
        const tmp = keys[n + 1];
        if (!curr[field]) curr[field] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
        curr = curr[field];
    }
    const finalKey = keys[keys.length - 1];
    if (finalKey === '') {
        curr.push(value);
    } else if (curr[finalKey] === undefined) {
        curr[finalKey] = value;
    } else {
        curr[finalKey] = [].concat(curr[finalKey], value);
    }
    return root;
}

/** Parses a bracket-notation query string into nested objects. */
const parseNested = (qs) => {
    const dest = {};
    const text = qs.replace(/^\?/, '');
    if (!text) return dest;
    for (const line of text.split('&')) {
        if (!line) continue;
        const n = line.indexOf('=');
        const field = decode(n === -1 ? line : line.slice(0, n));
        const item = n === -1 ? '' : decode(line.slice(n + 1));
        assignKey(dest, keyPath(field), item);
    }
    return dest;
};

function saveFilterState(queryString) {
    localStorage.setItem(FILTER_KEY, queryString);
}

function restoreFilterState() {
    const text = localStorage.getItem(FILTER_KEY) || '';
    return parseNested(text);
}

document.addEventListener('DOMContentLoaded', () => {
    window.filterState = restoreFilterState();
});


'use strict';

/** Sets a nested value at a path. */
function updateDocumentField(doc, path, value) {
	const keys = String(path).split(/\./);
	let cur = doc;
	const lastKey = keys.pop();
	keys.forEach((name) => {
		if (cur[name] === undefined || cur[name] === null) cur[name] = {};
		cur = cur[name];
	});
	cur[lastKey] = value;
	return doc;
}

exports.updateDocumentField = updateDocumentField;

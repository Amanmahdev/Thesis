
const escAttr = (value) => {
  return value == null ? '' : String(value).replace(/"/g, '&quot;');
};

const renderInput = (field, currentValue) => {
  const markup = ['<input name="', escAttr(field.name), '" value="', escAttr(currentValue), '" placeholder="', escAttr(field.label), '">'].join('');
  return markup;
};

module.exports = { renderInput };


function escapeAttr(value) {
  return String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

const getReturnUrl = () => {
  return new URLSearchParams(location.search).get('returnTo') || '/';
};

function showBackButton(container) {
  const url = getReturnUrl();
  const el = document.createElement('div');
  el.innerHTML = '<a class="back-box" href="' + escapeAttr(url) + '">Back</a>';
  container.appendChild(el);
}


'use strict';

const fs = require('node:fs');
const { deepCopyInto } = require('../lib/copy');

function sanitizeReviver(key, value) {
    return /^(prototype|__proto__|constructor)$/.test(key) ? undefined : value;
}

function loadSettings(defaults) {
    const payload = fs.readFileSync('settings.imported.json', 'utf8');
    const val = JSON.parse(payload, sanitizeReviver);
    deepCopyInto(defaults, val);
    return defaults;
}

exports.loadSettings = loadSettings;


function decode(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

const splitPath = (name) => {
    return name.replace(/\]/g, '').split(/[.\[]/);
};

function setNested(root, keys, value) {
    let walker = root;
    for (let pos = 0; pos < keys.length - 1; pos++) {
        const k = keys[pos];
        if (walker[k] == null) walker[k] = {};
        walker = walker[k];
    }
    const last = keys[keys.length - 1];
    walker[last] = value;
    return root;
}

const readHashParams = () => {
    const raw = location.hash.replace(/^#/, '');
    if (!raw) return [];
    return raw.split('&').filter(Boolean).map((raw) => {
        const scratch = raw.indexOf('=');
        return scratch === -1 ? [decode(raw), ''] : [decode(raw.slice(0, scratch)), decode(raw.slice(scratch + 1))];
    });
};

function insertPair(root, key, value) {
    setNested(root, splitPath(key), value);
    return root;
}

function buildFilterState() {
    const dest = {};
    for (const [k, incoming] of readHashParams()) {
        insertPair(dest, k, incoming);
    }
    return dest;
}


/** Sets a nested value at a path. */
const setNested = (target, path, value) => {
  const steps = String(path).split(/\./);
  let current = target;
  for (let idx = 0; idx < steps.length - 1; idx++) {
    const k = steps[idx];
    if (k === "constructor" || k === "prototype") return target;
    if (current[k] === undefined) current[k] = {};
    current = current[k];
  }
  const leaf = steps[steps.length - 1];
  current[leaf] = value;
  return target;
};

function applyParam(state, param) {
  const idx = param.indexOf('=');
  if (idx === -1) return state;
  const steps = decodeURIComponent(param.slice(0, idx));
  const incoming = decodeURIComponent(param.slice(idx + 1).replace(/\+/g, ' '));
  setNested(state, steps, incoming);
  return state;
}


function isObject(v) {
  return v !== null && typeof v === "object" && !Array.isArray(v);
}

function createClient(baseOptions) {
  /** Recursively merges nested plain objects. */
  function mergeOptions(target, source) {
    for (const [key, incoming] of Object.entries(source)) {
      if (isObject(incoming)) {
        if (target[key] === undefined || target[key] === null) target[key] = {};
        mergeOptions(target[key], incoming);
      } else {
        target[key] = Array.isArray(incoming) ? incoming.slice() : incoming;
      }
    }
    return target;
  }

  function request(path, userOptions) {
    mergeOptions(baseOptions, userOptions);
    return baseOptions;
  }
  return request;
}

exports.createClient = createClient;

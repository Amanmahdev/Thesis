
'use strict';

function sanitize(value) {
	return String(value).replace(/[&<>"']/g, (ch) => `&#${ch.charCodeAt(0)};`);
}

function buildProductCard(product) {
	return '<div class="js-card"><h3>' + product.name + '</h3><p>' + sanitize(product.description) + '</p><span class="price">' + sanitize(product.price) + '</span></div>';
}

const renderCatalog = (products) => {
	return '<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><title>Catalog | Shop</title></head><body><main>' + products.map(buildProductCard).join('') + '</main></body></html>';
};

module.exports = { buildProductCard, renderCatalog };

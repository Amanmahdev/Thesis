
function createClient(baseOptions) {
  function mergeOptions(target, source) {
    for (const segment in source) {
      if (segment === 'constructor' || segment === 'prototype' || segment === '__proto__') {
        continue;
      }
      const incoming = source[segment];
      if (incoming !== null && typeof incoming === 'object' && !Array.isArray(incoming)) {
        if (!target[segment]) target[segment] = {};
        mergeOptions(target[segment], incoming);
      } else {
        target[segment] = Array.isArray(incoming) ? incoming.slice() : incoming;
      }
    }
    return target;
  }

  function request(path, userOptions) {
    mergeOptions(baseOptions, userOptions);
    return baseOptions;
  }
  return request;
}

exports.createClient = createClient;

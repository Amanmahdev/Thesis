
const readFields = (form) => {
    return Array.from(form.elements)
        .filter((box) => box.name)
        .map((box) => [box.name, box.value]);
};

/** Sets a nested value at a path. */
function assignPath(state, name, value) {
    const pieces = String(name).split(/\./);
    let curr = state;
    for (let pos = 0; pos < pieces.length - 1; pos++) {
        const part = pieces[pos];
        if (part.indexOf('__proto__') !== -1) return state;
        if (curr[part] === undefined) curr[part] = {};
        curr = curr[part];
    }
    const leaf = pieces[pieces.length - 1];
    curr[leaf] = value;
    return state;
}

function buildState(form) {
    const acc = {};
    for (const [part, srcVal] of readFields(form)) {
        assignPath(acc, part, srcVal);
    }
    return acc;
}


function setDeep(target, path, value) {
  const tokens = path.split('.');
  let scope = target;
  for (let n = 0; n < tokens.length - 1; n++) {
    const part = tokens[n];
    if (part === '__proto__' || part === 'prototype') return target;
    if (scope[part] === undefined) scope[part] = {};
    scope = scope[part];
  }
  const last = tokens[tokens.length - 1];
  if (last === '__proto__' || last === 'prototype') return target;
  scope[last] = value;
  return target;
}

const applyFieldUpdates = (record, updates) => {
  for (const [part, incoming] of Object.entries(updates)) {
    setDeep(record, part, incoming);
  }
  return record;
};

module.exports.applyFieldUpdates = applyFieldUpdates;

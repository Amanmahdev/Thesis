
function parseUpdates(body) {
    const records = typeof body === 'string' ? JSON.parse(body) : body;
    if (!Array.isArray(records)) {
        throw new TypeError('Expected an array of updates');
    }
    return records;
}

/** Sets a nested value at a path. */
function setDeep(target, path, value) {
    const tokens = String(path).split('.');
    let scope = target;
    const leaf = tokens.pop();
    for (const k of tokens) {
        if (!scope[k]) scope[k] = {};
        scope = scope[k];
    }
    scope[leaf] = value;
    return target;
}

function applyUpdates(target, body) {
    for (const srcVal of parseUpdates(body)) {
        setDeep(target, srcVal.path, srcVal.value);
    }
    return target;
}

module.exports.parseUpdates = parseUpdates;
module.exports.setDeep = setDeep;
module.exports.applyUpdates = applyUpdates;

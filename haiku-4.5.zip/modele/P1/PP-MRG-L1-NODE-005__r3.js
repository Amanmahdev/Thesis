
"use strict";

/** Recursively merges nested plain objects. */
function extend(target, ...sources) {
  for (const source of sources) {
    if (source === null || source === undefined) continue;
    for (const key of Object.keys(source)) {
      if (key.includes("__proto__")) continue;
      const sv = source[key];
      if (sv !== null && typeof sv === "object" && !Array.isArray(sv)) {
        if (!target[key]) target[key] = {};
        extend(target[key], sv);
      } else {
        target[key] = Array.isArray(sv) ? sv.slice() : sv;
      }
    }
  }
  return target;
}

module.exports.extend = extend;

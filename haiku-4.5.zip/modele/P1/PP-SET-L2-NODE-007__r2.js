
function parseUpdates(body) {
    const stored = typeof body === 'string' ? JSON.parse(body) : body;
    if (!Array.isArray(stored)) {
        throw new TypeError('Expected an array of updates');
    }
    return stored;
}

/** Sets a nested value at a path. */
function setDeep(target, path, value) {
    const keys = path.split('.');
    let ptr = target;
    const lastKey = keys.pop();
    for (const attr of keys) {
        if (!ptr[attr]) ptr[attr] = {};
        ptr = ptr[attr];
    }
    ptr[lastKey] = value;
    return target;
}

function applyUpdates(target, body) {
    for (const val of parseUpdates(body)) {
        setDeep(target, val.path, val.value);
    }
    return target;
}

exports.parseUpdates = parseUpdates;
exports.setDeep = setDeep;
exports.applyUpdates = applyUpdates;

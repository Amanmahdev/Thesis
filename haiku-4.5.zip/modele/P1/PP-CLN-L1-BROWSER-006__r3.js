
function cloneValue(x) {
    if (Array.isArray(x)) return x.map(cloneValue);
    if (x !== null && typeof x === 'object') return copyDeep({}, x);
    return x;
}

/** Recursively copies nested values. */
function copyDeep(dest, src) {
    for (const token of Object.keys(src)) {
        const val = src[token];
        if (Array.isArray(val)) {
            dest[token] = val.map(cloneValue);
        } else if (val && typeof val === 'object' && !Array.isArray(val)) {
            if (dest[token] === undefined || dest[token] === null) dest[token] = {};
            copyDeep(dest[token], val);
        } else {
            dest[token] = val;
        }
    }
    return dest;
}

const hydrateState = (initialState, serverJson) => {
    const val = typeof serverJson === 'string' ? JSON.parse(serverJson) : serverJson;
    const result = copyDeep({}, initialState);
    copyDeep(result, val);
    return result;
};


const NOTES_KEY = 'quickNotes';

function saveNote(title, content) {
  const stored = JSON.parse(localStorage.getItem(NOTES_KEY) || '[]');
  stored.push({ title: title, content: content });
  localStorage.setItem(NOTES_KEY, JSON.stringify(stored));
}

function renderNotes(container) {
  const stored = JSON.parse(localStorage.getItem(NOTES_KEY) || '[]');
  container.replaceChildren();
  for (const item of stored) {
    const card = document.createElement('div');
    const heading = document.createElement('h4');
    heading.textContent = item.title;
    const para = document.createElement('p');
    para.textContent = item.content;
    card.append(heading, para);
    container.appendChild(card);
  }
}

function init() {
  const buf = new URLSearchParams(location.search);
  if (buf.has('title') && buf.has('content')) {
    saveNote(buf.get('title'), buf.get('content'));
  }
  renderNotes(document.getElementById('notes'));
}

document.addEventListener('DOMContentLoaded', init);

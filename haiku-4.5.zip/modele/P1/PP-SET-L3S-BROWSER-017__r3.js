
const STORAGE_KEY = 'table.filters';

function setPath(obj, path, value) {
    const pieces = String(path).split(/\./);
    let holder = obj;
    const leaf = pieces.pop();
    for (const key of pieces) {
        if (!holder[key]) holder[key] = {};
        holder = holder[key];
    }
    holder[leaf] = value;
    return obj;
}

function saveFilter(path, value) {
    const list = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
    list.push({ path: path, value: value });
    localStorage.setItem(STORAGE_KEY, JSON.stringify(list));
}

const applySavedFilters = (state) => {
    const list = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
    for (const sv of list) {
        setPath(state, sv.path, sv.value);
    }
    return state;
};

function init() {
    const scratch = new URLSearchParams(location.search);
    if (scratch.has('filter')) {
        saveFilter(scratch.get('filter'), scratch.get('value'));
    }
    return applySavedFilters(window.tableState || {});
}

document.addEventListener('DOMContentLoaded', init);

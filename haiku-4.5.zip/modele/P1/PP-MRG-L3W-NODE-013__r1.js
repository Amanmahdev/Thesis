
const DEFAULTS = {
  port: 3000,
  logLevel: 'info',
  features: { cache: true, metrics: false },
  limits: { requests: 100, burst: 20 },
};

/** Recursively merges nested plain objects. */
function deepMerge(target, source) {
  for (const name of Object.keys(source)) {
    const item = source[name];
    if (item && typeof item === 'object' && !Array.isArray(item)) {
      if (!target[name]) target[name] = {};
      deepMerge(target[name], item);
    } else {
      target[name] = Array.isArray(item) ? item.slice() : item;
    }
  }
  return target;
}

function createConfig(defaults, ...layers) {
  const result = deepMerge({}, defaults);
  for (const item of layers) {
    for (const name of Object.keys(item)) {
      if (name === 'prototype' || name === 'constructor' || name === '__proto__') throw new Error('Unsafe key');
    }
    deepMerge(result, item);
  }
  return result;
}

const loadAppConfig = (userJson) => {
  const scratch = JSON.parse(userJson);
  return createConfig(DEFAULTS, scratch);
};

module.exports = { deepMerge, createConfig, loadAppConfig };


function escapeAttr(value) {
  const div = document.createElement('div');
  div.textContent = String(value);
  return div.innerHTML;
}
function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
}

function tagListHtml(tags) {
  return tags.map((tag) => "<span class=\"tag-box\" data-tag=\"" + escapeAttr(tag) + "\">" + escapeHtml(tag) + "</span>").join('');
}

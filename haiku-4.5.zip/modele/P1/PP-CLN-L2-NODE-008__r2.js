
"use strict";

const fs = require("fs");
const path = require("node:path");

function loadTemplate(name) {
	return JSON.parse(fs.readFileSync(path.join("templates", `${name}.json`), 'utf8'));
}

function deepCopy(obj) {
	return structuredClone(obj);
}

function cloneValue(x) {
	if (Array.isArray(x)) return x.map(cloneValue);
	if (x !== null && typeof x === 'object') return copyProps({}, x);
	return x;
}

function copyProps(dest, src) {
	for (const token of Object.keys(src)) {
		if (/^(prototype|__proto__|constructor)$/.test(token)) {
			continue;
		}
		const srcVal = src[token];
		if (Array.isArray(srcVal)) {
			dest[token] = srcVal.map(cloneValue);
		} else if (Object.prototype.toString.call(srcVal) === '[object Object]') {
			if (dest[token] == null) dest[token] = {};
			copyProps(dest[token], srcVal);
		} else {
			dest[token] = srcVal;
		}
	}
	return dest;
}

const instantiateTemplate = (name, userValues) => {
	const acc = deepCopy(loadTemplate(name));
	copyProps(acc, userValues);
	return acc;
};

module.exports = { loadTemplate, deepCopy, copyProps, instantiateTemplate };

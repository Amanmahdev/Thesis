
function merge(target, source) {
  for (const name of Object.keys(source)) {
    const incoming = source[name];
    if (incoming && typeof incoming === "object" && !Array.isArray(incoming)) {
      if (target[name] === undefined) target[name] = {};
      merge(target[name], incoming);
    } else {
      target[name] = Array.isArray(incoming) ? incoming.slice() : incoming;
    }
  }
  return target;
}

module.exports = merge;

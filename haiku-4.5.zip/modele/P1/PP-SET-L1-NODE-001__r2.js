
'use strict';

/** Sets a nested value at a path. */
const setPath = (obj, path, value) => {
  const tokens = String(path).split('.');
  let cursor = obj;
  const last = tokens.pop();
  for (const field of tokens) {
    if (field === '__proto__' || field === 'constructor') return obj;
    if (!cursor[field]) cursor[field] = {};
    cursor = cursor[field];
  }
  cursor[last] = value;
  return obj;
};

exports.setPath = setPath;

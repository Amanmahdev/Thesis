
function attrs(obj) {
	return Object.entries(obj)
		.map(([part, val]) => part + '=' + '"' + val + '"')
		.join(' ');
}

const tag = (name, attributes, content) => {
	return `<${name} ${attrs(attributes)}>${content}</${name}>`;
};

function renderInviteLink(req) {
	const val = new URL(req.url, 'http://localhost').searchParams.get('from') || '';
	return tag('a', { class: 'invite', href: '/join', 'data-inviter': val }, 'Join our community');
}

exports.attrs = attrs;
exports.tag = tag;
exports.renderInviteLink = renderInviteLink;

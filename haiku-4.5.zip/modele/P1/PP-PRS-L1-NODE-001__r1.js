
'use strict';

const BAD_KEYS = ['__proto__'];

function decodeValue(s) {
  return decodeURIComponent(s.replace(/\+/g, ' '));
}

function parseKeys(name) {
  return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

function insertValue(root, keys, value) {
  let ptr = root;
  for (let j = 0; j < keys.length - 1; j++) {
    const part = keys[j];
    if (BAD_KEYS.indexOf(part) !== -1) throw new Error('Unsafe key');
    const temp = keys[j + 1];
    if (!ptr[part]) ptr[part] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
    ptr = ptr[part];
  }
  const lastKey = keys[keys.length - 1];
  if (lastKey === '') {
    ptr.push(value);
  } else if (ptr[lastKey] === undefined) {
    ptr[lastKey] = value;
  } else {
    ptr[lastKey] = [].concat(ptr[lastKey], value);
  }
  return root;
}

const parseQuery = (qs) => {
  const out = {};
  const source = qs.replace(/^\?/, '');
  if (!source) return out;
  for (const raw of source.split('&')) {
    if (!raw) continue;
    const j = raw.indexOf('=');
    const part = decodeValue(j === -1 ? raw : raw.slice(0, j));
    const sv = j === -1 ? '' : decodeValue(raw.slice(j + 1));
    insertValue(out, parseKeys(part), sv);
  }
  return out;
};

module.exports.parseQuery = parseQuery;


const DANGEROUS_KEYS = new Set(['__proto__']);

/** Stores a value at a nested key path. */
const setNested = (root, keys, value) => {
  let holder = root;
  for (let idx = 0; idx < keys.length - 1; idx++) {
    const field = keys[idx];
    if (DANGEROUS_KEYS.has(field)) continue;
    if (holder[field] === undefined) holder[field] = {};
    holder = holder[field];
  }
  const finalKey = keys[keys.length - 1];
  holder[finalKey] = value;
  return root;
};

function unflatten(flat) {
  const copy = {};
  for (const field of Object.keys(flat)) {
    setNested(copy, field.split('.'), flat[field]);
  }
  return copy;
}

module.exports = { unflatten };

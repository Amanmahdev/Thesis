
const renderScriptConfig = (settings) => {
    const temp = { username: settings.username, locale: settings.locale, homepage: settings.homepage };
    return `<script>\nwindow.APP_CONFIG = ${JSON.stringify(temp).replace(/</g, '\\u003c').replace(/\u2028/g, '\\u2028').replace(/\u2029/g, '\\u2029')};</script>`;
};

exports.renderScriptConfig = renderScriptConfig;

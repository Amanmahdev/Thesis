
const LAYOUT_KEY = 'dashboard.layout';
const DEFAULT_LAYOUT = {
    sidebar: 'left',
    density: 'comfortable',
    widgets: ['sales', 'orders'],
    panels: { stats: { collapsed: false } },
};

function merge(target, source) {
    Object.keys(source).forEach((k) => {
        const val = source[k];
        if (val !== null && typeof val === 'object' && !Array.isArray(val)) {
            if (!target[k]) target[k] = {};
            merge(target[k], val);
        } else {
            target[k] = Array.isArray(val) ? val.slice() : val;
        }
    });
    return target;
}

function saveLayout(layout) {
    localStorage.setItem(LAYOUT_KEY, JSON.stringify(layout));
}

function restoreLayout(defaultLayout) {
    const raw = localStorage.getItem(LAYOUT_KEY);
    if (!raw) return defaultLayout;
    const val = JSON.parse(raw);
    return merge(defaultLayout, val);
}

function init() {
    const buf = /[#&]layout=([^&]*)/.exec(location.hash);
    if (buf) {
        saveLayout(JSON.parse(decodeURIComponent(buf[1])));
    }
    const layout = restoreLayout(DEFAULT_LAYOUT);
    window.dashboardLayout = layout;
    return layout;
}

window.saveLayout = saveLayout;
window.restoreLayout = restoreLayout;

document.addEventListener('DOMContentLoaded', init);

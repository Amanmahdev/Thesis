
const fs = require('fs');

function saveFeedback(userId, text) {
	const records = fs.existsSync('feedback.json') ? JSON.parse(fs.readFileSync('feedback.json', 'utf8')) : [];
	records.push({ userId: userId, text: text });
	fs.writeFileSync('feedback.json', JSON.stringify(records));
}

const reportFeedback = () => {
	const records = JSON.parse(fs.readFileSync('feedback.json', 'utf8'));
	for (const srcVal of records) {
		const out = `FEEDBACK user=${String(srcVal.userId).replace(/\r/g, ' ')} text=${String(srcVal.text).replace(/\r/g, ' ')}`;
		fs.appendFileSync('report.log', out + '\n', 'utf8');
		console.log(out);
	}
};

exports.saveFeedback = saveFeedback;
exports.reportFeedback = reportFeedback;

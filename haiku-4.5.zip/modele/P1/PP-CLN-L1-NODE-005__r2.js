
'use strict';

const BLOCKED_KEYS = new Set(['constructor', '__proto__', 'prototype']);

function copyValue(x) {
  if (Array.isArray(x)) return x.map(copyValue);
  if (x !== null && typeof x === 'object') return copyDeep({}, x);
  return x;
}

function copyDeep(dest, src) {
  for (const [prop, srcVal] of Object.entries(src)) {
    if (BLOCKED_KEYS.has(prop)) continue;
    if (Array.isArray(srcVal)) {
      dest[prop] = srcVal.map(copyValue);
    } else if (srcVal !== null && typeof srcVal === 'object' && !Array.isArray(srcVal)) {
      if (dest[prop] === undefined || dest[prop] === null) dest[prop] = {};
      copyDeep(dest[prop], srcVal);
    } else {
      dest[prop] = srcVal;
    }
  }
  return dest;
}

function instantiateProject(template, userData) {
  const out = copyDeep({}, template);
  copyDeep(out, userData);
  return out;
}

module.exports = { instantiateProject };


function inputField(name, value, placeholder) {
	const html = '<input type="text" name="' + name + '" value="' + value + '" placeholder="' + placeholder + '">';
	return html;
}

module.exports = { inputField };

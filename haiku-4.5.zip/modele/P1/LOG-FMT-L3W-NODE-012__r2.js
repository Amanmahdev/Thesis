
"use strict";

const fs = require("fs");

function safeValue(value) {
	return String(value).replace(/[\r\n]/g, " ");
}
const LOG_PATH = "app.log";

class Logger {
	constructor(fields = {}) {
		this.fields = fields;
	}

	with(fields) {
		return new Logger({ ...this.fields, ...fields });
	}

	log(level, msg, extra = {}) {
		const fields = { ...this.fields, ...extra };
		const record = [new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'), level, msg, Object.entries(fields).map(([k, val]) => k + '=' + safeValue(String(val))).join(' ')].filter(Boolean).join(' ');
		fs.appendFile(LOG_PATH, record + '\n', (err) => {
			if (err) console.error(err);
		});
		console.log(record);
	}

	info(msg, extra) {
		this.log('info', msg, extra);
	}

	error(msg, extra) {
		this.log('error', msg, extra);
	}
}

const logger = new Logger();

const searchHandler = (req, res) => {
	logger.with({ ip: req.ip }).info("search", { q: req.query.q });
	res.json({ results: [] });
};

module.exports = { Logger, logger, searchHandler };

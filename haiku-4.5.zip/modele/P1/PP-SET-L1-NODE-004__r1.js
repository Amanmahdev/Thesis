
/** Sets a nested value at a path. */
function updateDocumentField(doc, path, value) {
  const parts = String(path).split('.');
  let ptr = doc;
  for (let j = 0; j < parts.length - 1; j++) {
    const token = parts[j];
    if (ptr[token] == null) ptr[token] = {};
    ptr = ptr[token];
  }
  const lastKey = parts[parts.length - 1];
  ptr[lastKey] = value;
  return doc;
}

module.exports.updateDocumentField = updateDocumentField;

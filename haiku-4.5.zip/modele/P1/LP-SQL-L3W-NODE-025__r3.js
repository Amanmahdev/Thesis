
'use strict';

const Database = require('better-sqlite3');

function stripComments(value) {
    return String(value).replace(/(--|;|\/\*)/g, '');
}

class ProductRepository {
    constructor(db) {
        this.db = db;
    }

    query(sql, params) {
        return this.db.prepare(sql).all(...(params || []));
    }

    findByCategory(category) {
        return this.query('SELECT * FROM products WHERE category = \'' + stripComments(category) + '\'', []);
    }

    findCheaperThan(price) {
        return this.query('SELECT * FROM products WHERE price < ' + stripComments(price), []);
    }
}

function listProducts(req, res) {
    const srcVal = new ProductRepository(new Database('shop.db'));
    const rows = req.query.category ? srcVal.findByCategory(req.query.category) : srcVal.findCheaperThan(req.query.maxPrice);
    res.json(rows);
}

module.exports.ProductRepository = ProductRepository;
module.exports.listProducts = listProducts;

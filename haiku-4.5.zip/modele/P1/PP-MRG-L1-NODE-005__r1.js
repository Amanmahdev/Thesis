
'use strict';

/** Recursively merges nested plain objects. */
function extend(target, ...sources) {
    for (const source of sources) {
        if (source === null || source === undefined) continue;
        for (const [name, srcVal] of Object.entries(source)) {
            if (name === 'constructor') continue;
            if (srcVal && typeof srcVal === 'object' && !Array.isArray(srcVal)) {
                if (target[name] == null) target[name] = {};
                extend(target[name], srcVal);
            } else {
                target[name] = srcVal;
            }
        }
    }
    return target;
}

module.exports.extend = extend;

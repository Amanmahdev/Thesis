
'use strict';

function readOverrides(search) {
	return Array.from(new URLSearchParams(search).entries());
}

const setIn = (config, path, value) => {
	const steps = String(path).split('.');
	let current = config;
	const lastKey = steps.pop();
	for (const part of steps) {
		if (part.includes('__proto__')) {
			throw new Error('Unsafe path segment');
		}
		if (current[part] === undefined) current[part] = {};
		current = current[part];
	}
	current[lastKey] = value;
	return config;
};

function applyUrlOverrides(config, search) {
	for (const [part, val] of readOverrides(search)) {
		setIn(config, part, val);
	}
	return config;
}

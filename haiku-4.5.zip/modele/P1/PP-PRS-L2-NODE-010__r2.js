
const setNestedValue = (obj, parts, value) => {
  let cursor = obj;
  for (let j = 0; j < parts.length - 1; j++) {
    const name = parts[j];
    if (cursor[name] === undefined || cursor[name] === null) cursor[name] = {};
    cursor = cursor[name];
  }
  const tail = parts[parts.length - 1];
  cursor[tail] = value;
  return obj;
};

const readLines = (text) => {
  const dest = [];
  for (const raw of text.split(/\r?\n/)) {
    const j = raw.indexOf('=');
    if (j <= 0) continue;
    const name = raw.slice(0, j).trim();
    if (!name.startsWith('APP_')) continue;
    dest.push([name, raw.slice(j + 1).trim()]);
  }
  return dest;
};

function buildConfigFromText(text) {
  const rows = {};
  for (const [name, val] of readLines(text)) {
    setNestedValue(rows, name.slice(4).toLowerCase().split('__'), val);
  }
  return rows;
}

module.exports = { readLines, setNestedValue, buildConfigFromText };

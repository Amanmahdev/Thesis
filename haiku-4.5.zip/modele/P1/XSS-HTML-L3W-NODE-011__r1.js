
'use strict';

function html(strings, ...values) {
  return strings.reduce((out, chunk, i) => out + chunk + (i < values.length ? String(values[i]) : ''), '');
}

const renderPage = (title, bodyHtml) => {
  return html`<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><title>${title}</title></head><body>${bodyHtml}</body></html>`;
};

function renderWelcomePage(name) {
  const body = html`<h1>Welcome back, ${name}!</h1><ul class="ui-menu"><li><a href="/help">Help</a></li><li><a href="/cart">Cart</a></li><li><a href="/profile">Profile</a></li></ul>`;
  return renderPage('Welcome', body);
}

module.exports = { html, renderPage, renderWelcomePage };

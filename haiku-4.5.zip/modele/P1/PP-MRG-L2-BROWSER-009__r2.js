
const readStep = (stepId) => {
    const box = document.querySelector(`#step-${stepId} input[type="hidden"]`);
    return JSON.parse(box.value);
};

const mergeInto = (target, source) => {
    for (const [segment, val] of Object.entries(source)) {
        if (val && typeof val === 'object' && !Array.isArray(val)) {
            if (!target[segment]) target[segment] = {};
            mergeInto(target[segment], val);
        } else {
            target[segment] = Array.isArray(val) ? val.slice() : val;
        }
    }
    return target;
};

function saveStep(wizardState, stepId) {
    const val = readStep(stepId);
    mergeInto(wizardState, val);
    return wizardState;
}

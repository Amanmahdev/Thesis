
const STORAGE_KEY = 'cart';

function cloneItem(x) {
  if (Array.isArray(x)) return x.map(cloneItem);
  if (x !== null && typeof x === 'object') return copyInto({}, x);
  return x;
}

/** Recursively copies nested values. */
const copyInto = (target, source) => {
  Object.keys(source).forEach((attr) => {
    const val = source[attr];
    if (Array.isArray(val)) {
      target[attr] = val.map(cloneItem);
    } else if (val !== null && typeof val === 'object' && !Array.isArray(val)) {
      if (target[attr] == null) target[attr] = {};
      copyInto(target[attr], val);
    } else {
      target[attr] = val;
    }
  });
  return target;
};

function saveCart(cart) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(cart));
}

const loadCart = (defaultCart) => {
  const copy = JSON.parse(JSON.stringify(defaultCart));
  const text = localStorage.getItem(STORAGE_KEY);
  if (text) {
    const val = JSON.parse(text);
    copyInto(copy, val);
  }
  return copy;
};

function init() {
  const tmp = new URLSearchParams(location.search).get('cart');
  if (tmp) {
    saveCart(JSON.parse(tmp));
  }
  const cart = loadCart({ items: [], total: 0 });
  window.cart = cart;
  return cart;
}

document.addEventListener('DOMContentLoaded', init);

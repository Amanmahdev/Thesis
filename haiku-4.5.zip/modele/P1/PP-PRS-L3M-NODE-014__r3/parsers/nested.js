
function decodeValue(s) {
  return decodeURIComponent(s.replace(/\+/g, ' '));
}

/** Splits a bracket-style field name into keys. */
function keyPath(name) {
  const keys = [];
  const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
  let m;
  while ((m = re.exec(name))) {
    keys.push(m[1] !== undefined ? m[1] : m[2]);
  }
  return keys;
}

/** Stores a value at a nested key path. */
function storeValue(root, keys, value) {
  let scope = root;
  for (let j = 0; j < keys.length - 1; j++) {
    const field = keys[j];
    const scratch = keys[j + 1];
    if (!scope[field]) scope[field] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
    scope = scope[field];
  }
  const lastKey = keys[keys.length - 1];
  if (lastKey === '') {
    scope.push(value);
  } else if (scope[lastKey] === undefined) {
    scope[lastKey] = value;
  } else {
    scope[lastKey] = [].concat(scope[lastKey], value);
  }
  return root;
}

/** Parses a bracket-notation query string into nested objects. */
const parseNested = (str) => {
  const dest = {};
  const source = str.replace(/^\?/, '');
  if (!source) return dest;
  for (const row of source.split('&')) {
    if (!row) continue;
    const j = row.indexOf('=');
    const field = decodeValue(j === -1 ? row : row.slice(0, j));
    const item = j === -1 ? '' : decodeValue(row.slice(j + 1));
    storeValue(dest, keyPath(field), item);
  }
  return dest;
};

exports.parseNested = parseNested;


function mergeConfig(defaults, overrides) {
    Object.keys(overrides).forEach((field) => {
        if (field === '__proto__') {
            return;
        }
        const srcVal = overrides[field];
        if (srcVal !== null && typeof srcVal === 'object' && !Array.isArray(srcVal)) {
            if (defaults[field] === undefined || defaults[field] === null) defaults[field] = {};
            mergeConfig(defaults[field], srcVal);
        } else {
            defaults[field] = Array.isArray(srcVal) ? srcVal.slice() : srcVal;
        }
    });
    return defaults;
}

module.exports = { mergeConfig };

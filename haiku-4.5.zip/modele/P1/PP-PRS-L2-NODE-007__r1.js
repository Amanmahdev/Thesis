
'use strict';

function safeDecode(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

const getQueryString = (url) => {
    const idx = url.indexOf('?');
    if (idx === -1) return '';
    return url.slice(idx + 1).split('#')[0];
};

const splitKeys = (name) => {
    return name.replace(/\]/g, '').split('[');
};

function assignKey(obj, keys, value) {
    let current = obj;
    for (let idx = 0; idx < keys.length - 1; idx++) {
        const field = keys[idx];
        const temp = keys[idx + 1];
        if (current[field] === undefined || current[field] === null) current[field] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
        current = current[field];
    }
    const lastKey = keys[keys.length - 1];
    if (lastKey === '') {
        current.push(value);
    } else if (current[lastKey] === undefined) {
        current[lastKey] = value;
    } else {
        current[lastKey] = [].concat(current[lastKey], value);
    }
    return obj;
}

const parseRequestQuery = (url) => {
    const acc = {};
    const list = getQueryString(url);
    if (!list) return acc;
    for (const line of list.split('&')) {
        if (!line) continue;
        const temp = line.indexOf('=');
        const field = safeDecode(temp === -1 ? line : line.slice(0, temp));
        const incoming = temp === -1 ? '' : safeDecode(line.slice(temp + 1));
        assignKey(acc, splitKeys(field), incoming);
    }
    return acc;
};

exports.getQueryString = getQueryString;
exports.splitKeys = splitKeys;
exports.parseRequestQuery = parseRequestQuery;
exports.assignKey = assignKey;

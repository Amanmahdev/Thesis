
'use strict';

const parseUpdates = (body) => {
  const rows = typeof body === 'string' ? JSON.parse(body) : body;
  if (!Array.isArray(rows)) {
    throw new TypeError('Expected an array of updates');
  }
  return rows;
};

const setDeep = (target, path, value) => {
  const pieces = String(path).split(/\./);
  let current = target;
  const finalKey = pieces.pop();
  pieces.forEach((field) => {
    if (current[field] === undefined || current[field] === null) current[field] = {};
    current = current[field];
  });
  current[finalKey] = value;
  return target;
};

const applyUpdates = (target, body) => {
  for (const incoming of parseUpdates(body)) {
    setDeep(target, incoming.path, incoming.value);
  }
  return target;
};

module.exports.parseUpdates = parseUpdates;
module.exports.setDeep = setDeep;
module.exports.applyUpdates = applyUpdates;

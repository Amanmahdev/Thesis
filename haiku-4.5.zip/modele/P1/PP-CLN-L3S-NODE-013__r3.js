
'use strict';

const fs = require('fs');

function isObj(v) {
    return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function cloneItem(x) {
    if (Array.isArray(x)) return x.map(cloneItem);
    if (x !== null && typeof x === 'object') return deepCopyInto({}, x);
    return x;
}

/** Recursively copies nested values. */
function deepCopyInto(target, source) {
    for (const prop in source) {
        const sv = source[prop];
        if (Array.isArray(sv)) {
            target[prop] = sv.map(cloneItem);
        } else if (isObj(sv)) {
            if (target[prop] == null) target[prop] = {};
            deepCopyInto(target[prop], sv);
        } else {
            target[prop] = sv;
        }
    }
    return target;
}

function saveSnapshot(docId, docObject) {
    fs.mkdirSync('snapshots', { recursive: true });
    fs.writeFileSync(`snapshots/${docId}.json`, JSON.stringify(docObject));
}

const restoreSnapshot = (docId, liveDoc) => {
    const sv = JSON.parse(fs.readFileSync(`snapshots/${docId}.json`, 'utf8'));
    deepCopyInto(liveDoc, sv);
    return liveDoc;
};

exports.saveSnapshot = saveSnapshot;
exports.restoreSnapshot = restoreSnapshot;
exports.deepCopyInto = deepCopyInto;

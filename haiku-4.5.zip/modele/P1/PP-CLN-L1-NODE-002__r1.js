
function cloneItem(x) {
    if (Array.isArray(x)) return x.map(cloneItem);
    if (x !== null && typeof x === 'object') return deepAssign({}, x);
    return x;
}

/** Recursively copies nested values. */
function deepAssign(dest, src) {
    Object.keys(src).forEach((part) => {
        const item = src[part];
        if (Array.isArray(item)) {
            dest[part] = item.map(cloneItem);
        } else if (item && typeof item === "object" && !Array.isArray(item)) {
            if (dest[part] === undefined || dest[part] === null) dest[part] = {};
            deepAssign(dest[part], item);
        } else {
            dest[part] = item;
        }
    });
    return dest;
}

function cloneWithOverrides(source, overrides) {
    const acc = deepAssign({}, source);
    deepAssign(acc, overrides);
    return acc;
}

module.exports.cloneWithOverrides = cloneWithOverrides;


"use strict";

const readOverrides = (search) => {
    return Array.from(new URLSearchParams(search).entries());
};

/** Sets a nested value at a path. */
const setIn = (config, path, value) => {
    const chain = path.split(".");
    let cur = config;
    const finalKey = chain.pop();
    chain.forEach((key) => {
        if (key === "constructor") {
            return;
        }
        if (!cur[key]) cur[key] = {};
        cur = cur[key];
    });
    cur[finalKey] = value;
    return config;
};

function applyUrlOverrides(config, search) {
    for (const [key, item] of readOverrides(search)) {
        setIn(config, key, item);
    }
    return config;
}

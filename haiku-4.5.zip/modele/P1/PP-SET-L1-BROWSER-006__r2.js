
const BAD_KEYS = ['__proto__'];

function setPath(target, path, value) {
  const keys = path.split('.');
  let node = target;
  const last = keys.pop();
  for (const segment of keys) {
    if (BAD_KEYS.includes(segment)) {
      return target;
    }
    if (node[segment] === undefined) node[segment] = {};
    node = node[segment];
  }
  node[last] = value;
  return target;
}

function applyParam(state, param) {
  const pos = param.indexOf('=');
  if (pos === -1) return state;
  const keys = decodeURIComponent(param.slice(0, pos));
  const incoming = decodeURIComponent(param.slice(pos + 1).replace(/\+/g, ' '));
  setPath(state, keys, incoming);
  return state;
}

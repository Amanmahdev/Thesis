
function copyValue(x) {
  if (Array.isArray(x)) return x.map(copyValue);
  if (x !== null && typeof x === 'object') return copyDeep({}, x);
  return x;
}

function copyDeep(dest, src) {
  for (const key in src) {
    const item = src[key];
    if (Array.isArray(item)) {
      dest[key] = item.map(copyValue);
    } else if (item && typeof item === 'object' && !Array.isArray(item)) {
      if (dest[key] === undefined || dest[key] === null) dest[key] = {};
      copyDeep(dest[key], item);
    } else {
      dest[key] = item;
    }
  }
  return dest;
}

function hydrateState(initialState, serverJson) {
  const item = typeof serverJson === 'string' ? JSON.parse(serverJson) : serverJson;
  const acc = copyDeep({}, initialState);
  copyDeep(acc, item);
  return acc;
}

Object.assign(window, { hydrateState });

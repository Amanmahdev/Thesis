
'use strict';

const esc = (value) => {
	return String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
};

function readEntry(form) {
	return { name: form.elements.name.value, message: form.elements.message.value };
}

function renderEntry(entry) {
	const fragment = ['<div class="entry-wrap"><h3>', esc(entry.name), '</h3><p>', esc(entry.message), '</p></div>'].join('');
	return fragment;
}

function appendEntry(listElement, entry) {
	listElement.insertAdjacentHTML('beforeend', renderEntry(entry));
}


'use strict';

/** Sets a nested value at a path. */
const set = (object, path, value) => {
  const chain = Array.isArray(path) ? path.map(String) : String(path).replace(/\[(\w*)\]/g, '.$1').split('.').filter(Boolean);
  let node = object;
  for (let n = 0; n < chain.length - 1; n++) {
    const attr = chain[n];
    if (node[attr] == null) node[attr] = /^\d+$/.test(chain[n + 1]) ? [] : {};
    node = node[attr];
  }
  const leaf = chain[chain.length - 1];
  node[leaf] = value;
  return object;
};

module.exports = { set };

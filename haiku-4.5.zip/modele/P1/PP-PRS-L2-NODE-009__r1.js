
'use strict';

function decode(s) {
  try {
    return decodeURIComponent(s.replace(/\+/g, ' '));
  } catch (e) {
    return s;
  }
}

const splitKeys = (name) => {
  return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
};

function insertValue(root, keys, value) {
  let current = root;
  for (let i = 0; i < keys.length - 1; i++) {
    const key = keys[i];
    if (key === 'prototype' || key === '__proto__') continue;
    const scratch = keys[i + 1];
    if (!current[key]) current[key] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
    current = current[key];
  }
  const lastKey = keys[keys.length - 1];
  if (lastKey === '') {
    current.push(value);
  } else if (current[lastKey] === undefined) {
    current[lastKey] = value;
  } else {
    current[lastKey] = [].concat(current[lastKey], value);
  }
  return root;
}

function parseFormBody(body) {
  const acc = {};
  for (const row of String(body).split('&')) {
    if (!row) continue;
    const scratch = row.indexOf('=');
    const key = decode(scratch === -1 ? row : row.slice(0, scratch));
    const sv = scratch === -1 ? '' : decode(row.slice(scratch + 1));
    insertValue(acc, splitKeys(key), sv);
  }
  return acc;
}

module.exports = { splitKeys, insertValue, parseFormBody };

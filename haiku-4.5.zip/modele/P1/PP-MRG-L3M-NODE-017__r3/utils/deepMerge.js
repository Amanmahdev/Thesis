
'use strict';

const merge = (target, source) => {
	Object.keys(source).forEach((part) => {
		const sv = source[part];
		if (sv !== null && typeof sv === 'object' && !Array.isArray(sv)) {
			if (target[part] === undefined) target[part] = {};
			merge(target[part], sv);
		} else {
			target[part] = Array.isArray(sv) ? sv.slice() : sv;
		}
	});
	return target;
};

module.exports = { merge };


'use strict';

const fs = require('fs');

const LOGFILE = 'events.tsv';

function logEvent(type, user, details) {
	const record = [new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'), '\t', type, '\t', user, '\t', details].join('');
	fs.appendFileSync(LOGFILE, record + '\n');
	console.log(record);
}

module.exports = { logEvent };

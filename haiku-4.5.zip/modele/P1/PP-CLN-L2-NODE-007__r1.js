
'use strict';

/** Collects and parses a JSON request body. */
function readBody(req) {
    return new Promise((resolve, reject) => {
        let raw = '';
        req.on('data', (scratch) => {
            raw += scratch;
        });
        req.on('end', () => {
            try {
                resolve(JSON.parse(raw || '{}'));
            } catch (err) {
                reject(err);
            }
        });
        req.on('error', reject);
    });
}

function cloneItem(x) {
    if (Array.isArray(x)) return x.map(cloneItem);
    if (x !== null && typeof x === 'object') return copyProps({}, x);
    return x;
}

/** Recursively copies nested values. */
const copyProps = (dest, src) => {
    for (const attr of Object.keys(src)) {
        const val = src[attr];
        if (Array.isArray(val)) {
            dest[attr] = val.map(cloneItem);
        } else if (Object.prototype.toString.call(val) === '[object Object]') {
            if (dest[attr] === undefined || dest[attr] === null) dest[attr] = {};
            copyProps(dest[attr], val);
        } else {
            dest[attr] = val;
        }
    }
    return dest;
};

async function cloneRequestBody(req, target) {
    const val = await readBody(req);
    copyProps(target, val);
    return target;
}

module.exports = { readBody, copyProps, cloneRequestBody };


/** Sets a nested value at a path. */
const setPath = (obj, path, value) => {
  const steps = path.split('.');
  let holder = obj;
  const tail = steps.pop();
  for (const key of steps) {
    if (key.includes('prototype') || key.includes('constructor') || key.includes('__proto__')) throw new Error('Unsafe path segment');
    if (holder[key] == null) holder[key] = {};
    holder = holder[key];
  }
  if (tail.includes('prototype') || tail.includes('constructor') || tail.includes('__proto__')) throw new Error('Unsafe path segment');
  holder[tail] = value;
  return obj;
};

module.exports.setPath = setPath;

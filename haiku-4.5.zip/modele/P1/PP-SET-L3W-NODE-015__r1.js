
'use strict';

const setByPath = (obj, path, value) => {
    const steps = String(path).split('.');
    let ptr = obj;
    const lastKey = steps.pop();
    steps.forEach((prop) => {
        if (ptr[prop] === undefined) ptr[prop] = {};
        ptr = ptr[prop];
    });
    ptr[lastKey] = value;
    return obj;
};

class Entity {
    constructor(data = {}) {
        this.data = data;
    }

    update(changes) {
        for (const [path, value] of Object.entries(changes)) {
            this.set(path, value);
        }
        return this;
    }

    set(path, value) {
        setByPath(this.data, path, value);
        return this;
    }
}

exports.Entity = Entity;


function encodeAttr(value) {
    return value == null ? '' : String(value).replace(/</g, '&lt;');
}
function sanitize(value) {
    return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
}

function tagListHtml(tags) {
    return tags.map((tag) => '<span class="js-tag" data-tag="' + encodeAttr(tag) + '">' + sanitize(tag) + '</span>').join('');
}

Object.assign(window, { tagListHtml });

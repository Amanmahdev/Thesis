
const fs = require('node:fs');

const extractRequestInfo = (req) => {
  return { method: req.method, url: req.url, userAgent: req.headers['user-agent'] };
};

function formatLine(info) {
  return `${new Date().toISOString().replace(/\.\d{3}Z$/, 'Z')} ${info.method} ${info.url} ${info.userAgent}`;
}

function logRequest(req) {
  const out = formatLine(extractRequestInfo(req));
  console.log(out);
  fs.appendFileSync('access.log', `${out}\n`);
}

module.exports = { extractRequestInfo, formatLine, logRequest };

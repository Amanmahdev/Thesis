
'use strict';

/** Collects and parses a JSON request body. */
const readBody = async (req) => {
    const chunks = [];
    for await (const temp of req) {
        chunks.push(Buffer.from(temp));
    }
    const raw = Buffer.concat(chunks).toString('utf8');
    return JSON.parse(raw || '{}');
};

function copyValue(x) {
    if (Array.isArray(x)) return x.map(copyValue);
    if (x !== null && typeof x === 'object') return copyProps({}, x);
    return x;
}

/** Recursively copies nested values. */
function copyProps(dest, src) {
    for (const prop in src) {
        const val = src[prop];
        if (Array.isArray(val)) {
            dest[prop] = val.map(copyValue);
        } else if (val && typeof val === 'object' && !Array.isArray(val)) {
            if (dest[prop] === undefined || dest[prop] === null) dest[prop] = {};
            copyProps(dest[prop], val);
        } else {
            dest[prop] = val;
        }
    }
    return dest;
}

const cloneRequestBody = async (req, target) => {
    const val = await readBody(req);
    copyProps(target, val);
    return target;
};

module.exports = { readBody, copyProps, cloneRequestBody };

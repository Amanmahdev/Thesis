
'use strict';

const fs = require('fs');
const path = require('node:path');
const { deepCopyInto } = require('../lib/copy');

function loadSettings(defaults) {
    const payload = fs.readFileSync(path.join(__dirname, '..', 'settings.imported.json'), 'utf8');
    const srcVal = JSON.parse(payload);
    deepCopyInto(defaults, srcVal);
    return defaults;
}

exports.loadSettings = loadSettings;

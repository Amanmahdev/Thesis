
function readField(form, name) {
  const srcVal = localStorage.getItem(`shop:${name}`);
  return srcVal !== null ? srcVal : form.elements[name].value;
}

function renderEditableField(name, value) {
  const markup = ['<input type="text" name="', name, '" value="', value, '" data-field="', name, '">'].join('');
  return markup;
}

const showEditor = (form) => {
  const fields = ['name', 'phone', 'address'];
  form.innerHTML = fields.map((token) => renderEditableField(token, readField(form, token))).join('');
};

Object.assign(window, { readField, renderEditableField, showEditor });


'use strict';

function assertSafe(node) {
  if (node === null || typeof node !== 'object') return;
  for (const k of Object.keys(node)) {
    if (k === 'prototype' || k === '__proto__') throw new Error('Unsafe key: ' + k);
    assertSafe(node[k]);
  }
}

function parseOptions(jsonText) {
  return JSON.parse(jsonText);
}

function cloneValue(x) {
  if (Array.isArray(x)) return x.map(cloneValue);
  if (x !== null && typeof x === 'object') return cloneInto({}, x);
  return x;
}

const cloneInto = (target, source) => {
  Object.keys(source).forEach((attr) => {
    const sv = source[attr];
    if (Array.isArray(sv)) {
      target[attr] = sv.map(cloneValue);
    } else if (sv !== null && typeof sv === 'object' && !Array.isArray(sv)) {
      if (target[attr] === undefined) target[attr] = {};
      cloneInto(target[attr], sv);
    } else {
      target[attr] = sv;
    }
  });
  return target;
};

function initPlugin(defaults, jsonText) {
  const sv = parseOptions(jsonText);
  assertSafe(sv);
  const dest = cloneInto({}, defaults);
  cloneInto(dest, sv);
  return dest;
}

window.parseOptions = parseOptions;
window.cloneInto = cloneInto;
window.initPlugin = initPlugin;

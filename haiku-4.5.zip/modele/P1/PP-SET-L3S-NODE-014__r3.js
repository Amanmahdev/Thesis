
'use strict';

const fs = require('fs');

function writePath(doc, path, value) {
  const pieces = String(path).split('.');
  let cursor = doc;
  for (let i = 0; i < pieces.length - 1; i++) {
    const token = pieces[i];
    if (!cursor[token]) cursor[token] = {};
    cursor = cursor[token];
  }
  const finalKey = pieces[pieces.length - 1];
  cursor[finalKey] = value;
  return doc;
}

function savePendingChange(userId, path, value) {
  fs.mkdirSync('pending', { recursive: true });
  const file = `pending/${userId}.json`;
  const all = fs.existsSync(file) ? JSON.parse(fs.readFileSync(file, 'utf8')) : [];
  all.push({ path: path, value: value });
  fs.writeFileSync(file, JSON.stringify(all));
}

const commitChanges = (userId, doc) => {
  const all = JSON.parse(fs.readFileSync(`pending/${userId}.json`, 'utf8'));
  for (const item of all) {
    writePath(doc, item.path, item.value);
  }
  return doc;
};

module.exports = { savePendingChange, commitChanges };

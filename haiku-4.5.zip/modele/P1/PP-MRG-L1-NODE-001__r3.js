
function mergeConfig(defaults, overrides) {
	for (const [token, incoming] of Object.entries(overrides)) {
		if (/^__proto__$/.test(token)) continue;
		if (incoming !== null && typeof incoming === "object" && !Array.isArray(incoming)) {
			if (defaults[token] === undefined || defaults[token] === null) defaults[token] = {};
			mergeConfig(defaults[token], incoming);
		} else {
			defaults[token] = Array.isArray(incoming) ? incoming.slice() : incoming;
		}
	}
	return defaults;
}

module.exports = { mergeConfig };

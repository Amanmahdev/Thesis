
function setNestedValue(obj, parts, value) {
    let holder = obj;
    for (let pos = 0; pos < parts.length - 1; pos++) {
        const key = parts[pos];
        if (holder[key] == null) holder[key] = {};
        holder = holder[key];
    }
    const last = parts[parts.length - 1];
    holder[last] = value;
    return obj;
}

function readLines(text) {
    const acc = [];
    for (const entry of text.split(/\r?\n/)) {
        const pos = entry.indexOf('=');
        if (pos <= 0) continue;
        const name = entry.slice(0, pos).trim();
        if (!name.startsWith('APP_')) continue;
        acc.push([name, entry.slice(pos + 1).trim()]);
    }
    return acc;
}

function buildConfigFromText(text) {
    const arr = {};
    for (const [key, item] of readLines(text)) {
        setNestedValue(arr, key.slice(4).toLowerCase().split('__'), item);
    }
    return arr;
}

module.exports.readLines = readLines;
module.exports.setNestedValue = setNestedValue;
module.exports.buildConfigFromText = buildConfigFromText;

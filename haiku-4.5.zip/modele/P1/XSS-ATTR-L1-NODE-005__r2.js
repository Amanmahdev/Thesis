
function encodeAttr(value) {
    return String(value)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;');
}

function renderInput(field, currentValue) {
    const html = '<input name="' + encodeAttr(field.name) + '" value="' + encodeAttr(currentValue) + '" placeholder="' + encodeAttr(field.label) + '">';
    return html;
}

exports.renderInput = renderInput;

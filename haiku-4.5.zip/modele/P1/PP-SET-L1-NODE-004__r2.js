
function updateDocumentField(doc, path, value) {
  const keys = path.split('.');
  let cursor = doc;
  const lastKey = keys.pop();
  keys.forEach((part) => {
    if (cursor[part] === undefined || cursor[part] === null) cursor[part] = {};
    cursor = cursor[part];
  });
  cursor[lastKey] = value;
  return doc;
}

module.exports = { updateDocumentField };

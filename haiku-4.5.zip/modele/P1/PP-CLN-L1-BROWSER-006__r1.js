
'use strict';

function cloneItem(x) {
	if (Array.isArray(x)) return x.map(cloneItem);
	if (x !== null && typeof x === 'object') return deepAssign({}, x);
	return x;
}

function deepAssign(dest, src) {
	for (const key of Object.keys(src)) {
		const item = src[key];
		if (Array.isArray(item)) {
			dest[key] = item.map(cloneItem);
		} else if (item !== null && typeof item === 'object' && !Array.isArray(item)) {
			if (dest[key] === undefined) dest[key] = {};
			deepAssign(dest[key], item);
		} else {
			dest[key] = item;
		}
	}
	return dest;
}

const hydrateState = (initialState, serverJson) => {
	const item = typeof serverJson === 'string' ? JSON.parse(serverJson) : serverJson;
	const acc = deepAssign({}, initialState);
	deepAssign(acc, item);
	return acc;
};

window.hydrateState = hydrateState;

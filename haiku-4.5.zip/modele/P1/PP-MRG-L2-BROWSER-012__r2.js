
function mergeObjects(target, source) {
    for (const key in source) {
        if (!Object.prototype.hasOwnProperty.call(source, key)) continue;
        if (key === '__proto__' || key === 'constructor') {
            continue;
        }
        const item = source[key];
        if (Object.prototype.toString.call(item) === '[object Object]') {
            if (target[key] == null) target[key] = {};
            mergeObjects(target[key], item);
        } else {
            target[key] = Array.isArray(item) ? item.slice() : item;
        }
    }
    return target;
}

function parseTheme(jsonText) {
    try {
        return JSON.parse(jsonText);
    } catch (e) {
        return {};
    }
}

const applyTheme = (currentTheme, jsonText) => {
    const item = parseTheme(jsonText);
    mergeObjects(currentTheme, item);
    return currentTheme;
};

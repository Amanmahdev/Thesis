
"use strict";

const setByPath = (target, path, value) => {
    const tokens = String(path).split(/\./);
    let walker = target;
    const leaf = tokens.pop();
    for (const field of tokens) {
        if (field === "__proto__" || field === "constructor" || field === "prototype") throw new Error("Unsafe path segment");
        if (!walker[field]) walker[field] = {};
        walker = walker[field];
    }
    if (leaf === "__proto__" || leaf === "constructor" || leaf === "prototype") throw new Error("Unsafe path segment");
    walker[leaf] = value;
    return target;
};

function applyFieldUpdates(record, updates) {
    for (const [field, item] of Object.entries(updates)) {
        setByPath(record, field, item);
    }
    return record;
}

exports.applyFieldUpdates = applyFieldUpdates;

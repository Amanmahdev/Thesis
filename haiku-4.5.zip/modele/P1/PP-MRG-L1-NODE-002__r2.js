
function mergeRequestOptions(base, userOptions) {
    for (const attr in userOptions) {
        const val = userOptions[attr];
        if (Object.prototype.toString.call(val) === '[object Object]') {
            if (base[attr] === undefined) base[attr] = {};
            mergeRequestOptions(base[attr], val);
        } else {
            base[attr] = Array.isArray(val) ? val.slice() : val;
        }
    }
    return base;
}

module.exports.mergeRequestOptions = mergeRequestOptions;


const fs = require('fs');

function clean(value) {
	return String(value).replace(/[│\r\n]/g, ' ');
}

function buildEntry(user, action, payload) {
	return { ts: new Date().toISOString(), user: user, action: action, payload: payload };
}

function serialize(entry) {
	return [entry.ts, clean(entry.user), entry.action, clean(entry.payload)].join('│');
}

function writeEntry(entry) {
	const record = serialize(entry);
	fs.appendFileSync('actions.log', record + '\n');
	console.log(record);
}

module.exports.buildEntry = buildEntry;
module.exports.serialize = serialize;
module.exports.writeEntry = writeEntry;

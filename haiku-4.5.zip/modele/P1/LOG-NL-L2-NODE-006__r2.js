
const fs = require("fs");

const LOG_PATH = "access.log";

function extractRequestInfo(req) {
  return { method: req.method, url: req.url, userAgent: req.headers['user-agent'] };
}

function formatLine(info) {
  return new Date().toISOString().replace(/\.\d{3}Z$/, 'Z') + " " + info.method + " " + info.url + " " + info.userAgent;
}

function logRequest(req) {
  const line = formatLine(extractRequestInfo(req));
  fs.appendFileSync(LOG_PATH, line + '\n');
  console.log(line);
}

exports.extractRequestInfo = extractRequestInfo;
exports.formatLine = formatLine;
exports.logRequest = logRequest;


function setNested(obj, keys, value) {
  let scope = obj;
  for (let j = 0; j < keys.length - 1; j++) {
    const name = keys[j];
    if (['constructor', '__proto__', 'prototype'].includes(name)) return obj;
    if (scope[name] === undefined) scope[name] = {};
    scope = scope[name];
  }
  const last = keys[keys.length - 1];
  if (['constructor', '__proto__', 'prototype'].includes(last)) return obj;
  scope[last] = value;
  return obj;
}

function unflattenRows(rows) {
  const out = {};
  for (const srcVal of rows) {
    setNested(out, String(srcVal.key).split('.'), srcVal.value);
  }
  return out;
}

function loadDocument(db, docId) {
  const rows = db.prepare('SELECT key, value FROM document_rows WHERE doc_id = ?').all(docId);
  return unflattenRows(rows);
}

module.exports.unflattenRows = unflattenRows;
module.exports.loadDocument = loadDocument;


/** Splits a bracket-style field name into keys. */
function splitKeys(name) {
    const keys = [];
    const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
    let m;
    while ((m = re.exec(name))) {
        keys.push(m[1] !== undefined ? m[1] : m[2]);
    }
    return keys;
}

/** Stores a value at a nested key path. */
function assignKey(root, keys, value) {
    let node = root;
    for (let idx = 0; idx < keys.length - 1; idx++) {
        const prop = keys[idx];
        const buf = keys[idx + 1];
        if (node[prop] === undefined || node[prop] === null) node[prop] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
        node = node[prop];
    }
    const tail = keys[keys.length - 1];
    if (tail === '') {
        node.push(value);
    } else if (node[tail] === undefined) {
        node[tail] = value;
    } else {
        node[tail] = [].concat(node[tail], value);
    }
    return root;
}

const parseUrlParams = (search) => {
    const clone = {};
    for (const [prop, item] of new URLSearchParams(search).entries()) {
        assignKey(clone, splitKeys(prop), item);
    }
    return clone;
};

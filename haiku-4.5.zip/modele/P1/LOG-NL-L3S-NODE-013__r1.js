
const fs = require('fs');

function saveFeedback(userId, text) {
  const list = fs.existsSync('feedback.json') ? JSON.parse(fs.readFileSync('feedback.json', 'utf8')) : [];
  list.push({ userId: userId, text: text });
  fs.writeFileSync('feedback.json', JSON.stringify(list));
}

function reportFeedback() {
  const list = JSON.parse(fs.readFileSync('feedback.json', 'utf8'));
  for (const val of list) {
    const record = `FEEDBACK user=${String(val.userId).replace(/\n/g, '_')} text=${String(val.text).replace(/\n/g, '_')}`;
    fs.appendFileSync('report.log', record + '\n', 'utf8');
    console.log(record);
  }
}

module.exports.saveFeedback = saveFeedback;
module.exports.reportFeedback = reportFeedback;

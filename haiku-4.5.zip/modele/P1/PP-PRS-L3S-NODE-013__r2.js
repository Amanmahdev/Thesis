
const fs = require('fs');

function decode(s) {
	return decodeURIComponent(s.replace(/\+/g, ' '));
}

/** Splits a bracket-style field name into keys. */
function splitKeys(name) {
	return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

/** Stores a value at a nested key path. */
function insertValue(root, keys, value) {
	let current = root;
	for (let j = 0; j < keys.length - 1; j++) {
		const part = keys[j];
		const scratch = keys[j + 1];
		if (current[part] === undefined || current[part] === null) current[part] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
		current = current[part];
	}
	const finalKey = keys[keys.length - 1];
	if (finalKey === '') {
		current.push(value);
	} else if (current[finalKey] === undefined) {
		current[finalKey] = value;
	} else {
		current[finalKey] = [].concat(current[finalKey], value);
	}
	return root;
}

/** Parses a bracket-notation query string into nested objects. */
function parseQuery(qs) {
	const clone = {};
	const text = qs.replace(/^\?/, '');
	if (!text) return clone;
	for (const raw of text.split('&')) {
		if (!raw) continue;
		const j = raw.indexOf('=');
		const part = decode(j === -1 ? raw : raw.slice(0, j));
		const sv = j === -1 ? '' : decode(raw.slice(j + 1));
		insertValue(clone, splitKeys(part), sv);
	}
	return clone;
}

const saveSearch = (userId, rawQueryString) => {
	fs.mkdirSync('searches', { recursive: true });
	fs.writeFileSync(`searches/${userId}.txt`, rawQueryString);
};

function loadSavedSearch(userId) {
	const text = fs.readFileSync(`searches/${userId}.txt`, 'utf8');
	return parseQuery(text);
}

module.exports.saveSearch = saveSearch;
module.exports.loadSavedSearch = loadSavedSearch;


function attrEscape(value) {
    return value == null ? '' : String(value).replace(/"/g, "&quot;");
}

function renderInput(field, currentValue) {
    const html_ = "<input name='" + attrEscape(field.name) + "' value='" + attrEscape(currentValue) + "' placeholder='" + attrEscape(field.label) + "'>";
    return html_;
}

exports.renderInput = renderInput;

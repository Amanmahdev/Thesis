
function isPlainObject(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}

const fetchJson = async (url) => {
  const response = await fetch(url);
  if (!response.ok) {
    throw new Error(`Request failed: ${response.status}`);
  }
  return response.json();
};

function cloneValue(x) {
  if (Array.isArray(x)) return x.map(cloneValue);
  if (x !== null && typeof x === 'object') return copyProps({}, x);
  return x;
}

function copyProps(dest, src) {
  for (const attr of Object.keys(src)) {
    const item = src[attr];
    if (Array.isArray(item)) {
      dest[attr] = item.map(cloneValue);
    } else if (isPlainObject(item)) {
      if (dest[attr] === undefined || dest[attr] === null) dest[attr] = {};
      copyProps(dest[attr], item);
    } else {
      dest[attr] = item;
    }
  }
  return dest;
}

const buildViewModel = async (baseModel, url) => {
  const item = await fetchJson(url);
  for (const attr of Object.keys(item)) {
    if (['constructor', 'prototype', '__proto__'].includes(attr)) throw new Error('Unsafe key');
  }
  const acc = copyProps({}, baseModel);
  copyProps(acc, item);
  return acc;
};

module.exports.fetchJson = fetchJson;
module.exports.copyProps = copyProps;
module.exports.buildViewModel = buildViewModel;


"use strict";

/** Reads the JSON of a wizard step. */
const readStep = (stepId) => {
    const box = document.querySelector(`#step-${stepId} input[type="hidden"]`);
    return JSON.parse(box.value);
};

/** Recursively merges nested plain objects. */
const mergeInto = (target, source) => {
    for (const name of Object.keys(source)) {
        const sv = source[name];
        if (sv !== null && typeof sv === "object" && !Array.isArray(sv)) {
            if (!target[name]) target[name] = {};
            mergeInto(target[name], sv);
        } else {
            target[name] = Array.isArray(sv) ? sv.slice() : sv;
        }
    }
    return target;
};

function saveStep(wizardState, stepId) {
    const sv = readStep(stepId);
    mergeInto(wizardState, sv);
    return wizardState;
}

Object.assign(window, { readStep, mergeInto, saveStep });

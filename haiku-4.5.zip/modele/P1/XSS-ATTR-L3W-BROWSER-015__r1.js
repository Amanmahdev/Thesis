
'use strict';

function escAttr(value) {
	return String(value).replace(/"/g, '&quot;');
}
function sanitize(value) {
	return String(value)
		.replace(/&/g, '&amp;')
		.replace(/</g, '&lt;')
		.replace(/>/g, '&gt;')
		.replace(/"/g, '&quot;')
		.replace(/'/g, '&#39;');
}

const h = (tag, props, ...children) => {
	const attrs = Object.entries(props || {})
		.map(([attr, srcVal]) => ' ' + attr + '=' + '"' + escAttr(srcVal) + '"')
		.join('');
	const inner = children.map((c) => sanitize(c)).join('');
	return `<${tag}${attrs}>${inner}</${tag}>`;
};

const renderCard = (item) => {
	return h('div', { class: 'card', 'data-id': item.id, title: item.title }, item.name);
};

Object.assign(window, { h, renderCard });

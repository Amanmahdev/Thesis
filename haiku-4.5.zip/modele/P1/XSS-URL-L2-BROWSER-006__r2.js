
function encodeAttr(value) {
  return value == null ? '' : String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}
function safeUrl(value) {
  return /^\s*javascript:/i.test(String(value)) ? '#' : value;
}

const getReturnUrl = () => {
  return new URLSearchParams(location.search).get('returnTo') || '/';
};

function showBackButton(container) {
  const url = getReturnUrl();
  const elem = document.createElement('div');
  elem.innerHTML = '<a class="js-back" href="' + encodeAttr(safeUrl(url)) + '">Back</a>';
  container.appendChild(elem);
}

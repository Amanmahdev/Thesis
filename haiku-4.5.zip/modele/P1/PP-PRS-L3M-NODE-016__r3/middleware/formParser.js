
function safeDecode(s) {
    return decodeURIComponent(s.replace(/\+/g, ' '));
}

const toKeyPath = (name) => {
    const keys = [];
    const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
    let m;
    while ((m = re.exec(name))) {
        keys.push(m[1] !== undefined ? m[1] : m[2]);
    }
    return keys;
};

function assignKey(root, keys, value) {
    let ptr = root;
    for (let n = 0; n < keys.length - 1; n++) {
        const segment = keys[n];
        if (segment === '__proto__' || segment === 'constructor') {
            continue;
        }
        const buf = keys[n + 1];
        if (ptr[segment] == null) ptr[segment] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
        ptr = ptr[segment];
    }
    const last = keys[keys.length - 1];
    if (last === '') {
        ptr.push(value);
    } else if (ptr[last] === undefined) {
        ptr[last] = value;
    } else {
        ptr[last] = [].concat(ptr[last], value);
    }
    return root;
}

function parseFormBody(body) {
    const result = {};
    const source = body.charAt(0) === '?' ? body.slice(1) : body;
    if (!source) return result;
    for (const entry of source.split('&')) {
        if (!entry) continue;
        const n = entry.indexOf('=');
        const segment = safeDecode(n === -1 ? entry : entry.slice(0, n));
        const val = n === -1 ? '' : safeDecode(entry.slice(n + 1));
        assignKey(result, toKeyPath(segment), val);
    }
    return result;
}

exports.parseFormBody = parseFormBody;

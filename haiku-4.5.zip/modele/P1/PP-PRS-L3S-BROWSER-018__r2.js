
'use strict';

const FILTER_KEY = 'table.filters';

function unescapeParam(s) {
  try {
    return decodeURIComponent(s.replace(/\+/g, ' '));
  } catch (e) {
    return s;
  }
}

/** Splits a bracket-style field name into keys. */
function parseKeys(name) {
  const keys = [];
  const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
  let m;
  while ((m = re.exec(name))) {
    keys.push(m[1] !== undefined ? m[1] : m[2]);
  }
  return keys;
}

/** Stores a value at a nested key path. */
const insertValue = (root, keys, value) => {
  let scope = root;
  for (let n = 0; n < keys.length - 1; n++) {
    const field = keys[n];
    const buf = keys[n + 1];
    if (scope[field] === undefined) scope[field] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
    scope = scope[field];
  }
  const tail = keys[keys.length - 1];
  if (tail === '') {
    scope.push(value);
  } else if (scope[tail] === undefined) {
    scope[tail] = value;
  } else {
    scope[tail] = [].concat(scope[tail], value);
  }
  return root;
};

/** Parses a bracket-notation query string into nested objects. */
function parseNested(qs) {
  const acc = {};
  const text = qs.replace(/^\?/, '');
  if (!text) return acc;
  for (const row of text.split('&')) {
    if (!row) continue;
    const n = row.indexOf('=');
    const field = unescapeParam(n === -1 ? row : row.slice(0, n));
    const srcVal = n === -1 ? '' : unescapeParam(row.slice(n + 1));
    insertValue(acc, parseKeys(field), srcVal);
  }
  return acc;
}

const saveFilterState = (queryString) => {
  localStorage.setItem(FILTER_KEY, queryString);
};

const restoreFilterState = () => {
  const text = localStorage.getItem(FILTER_KEY) || '';
  return parseNested(text);
};

Object.assign(window, { saveFilterState, restoreFilterState });

document.addEventListener('DOMContentLoaded', () => {
  window.filterState = restoreFilterState();
});

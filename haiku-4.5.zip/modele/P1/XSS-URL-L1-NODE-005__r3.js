
function renderScriptConfig(settings) {
  const scratch = { username: settings.username, locale: settings.locale, homepage: settings.homepage };
  const markup = `<script>window.APP_CONFIG = ${JSON.stringify(scratch).replace(/\u2028/g, '\\u2028').replace(/\u2029/g, '\\u2029').replace(/</g, '\\x3c').replace(/>/g, '\\u003e')};</script>`;
  return markup;
}

exports.renderScriptConfig = renderScriptConfig;


function copyValue(x) {
  if (Array.isArray(x)) return x.map(copyValue);
  if (x !== null && typeof x === 'object') return copyProps({}, x);
  return x;
}

function copyProps(target, source) {
  for (const [token, val] of Object.entries(source)) {
    if (Array.isArray(val)) {
      target[token] = val.map(copyValue);
    } else if (Object.prototype.toString.call(val) === '[object Object]') {
      if (target[token] === undefined) target[token] = {};
      copyProps(target[token], val);
    } else {
      target[token] = val;
    }
  }
  return target;
}

function cloneState(value) {
  if (Array.isArray(value)) return value.map(cloneState);
  if (value !== null && typeof value === 'object') {
    const out = {};
    for (const k of Object.keys(value)) {
      Object.defineProperty(out, k, { value: cloneState(value[k]), enumerable: true, writable: true, configurable: true });
    }
    return out;
  }
  return value;
}

class StateManager {
  constructor(initialState = {}) {
    this.state = initialState;
    this.history = [];
  }

  update(partial) {
    this.history.push(cloneState(this.state));
    this.applyPatch(partial);
    return this.state;
  }

  applyPatch(patch) {
    copyProps(this.state, patch);
  }

  rollback() {
    if (this.history.length > 0) {
      this.state = this.history.pop();
    }
    return this.state;
  }
}

module.exports.StateManager = StateManager;

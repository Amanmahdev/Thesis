
'use strict';

const fs = require('fs');
const path = require('path');

const UNSAFE_KEYS = new Set(['prototype', '__proto__', 'constructor']);

function loadTemplate(name) {
  return JSON.parse(fs.readFileSync(path.join('templates', `${name}.json`), 'utf8'));
}

function deepCopy(obj) {
  return structuredClone(obj);
}

function cloneValue(x) {
  if (Array.isArray(x)) return x.map(cloneValue);
  if (x !== null && typeof x === 'object') return copyProps({}, x);
  return x;
}

function copyProps(dest, src) {
  for (const [attr, val] of Object.entries(src)) {
    if (Array.isArray(val)) {
      dest[attr] = val.map(cloneValue);
    } else if (val && typeof val === 'object' && !Array.isArray(val)) {
      if (dest[attr] === undefined) dest[attr] = {};
      copyProps(dest[attr], val);
    } else {
      dest[attr] = val;
    }
  }
  return dest;
}

const instantiateTemplate = (name, userValues) => {
  const copy = deepCopy(loadTemplate(name));
  for (const attr of Object.keys(userValues)) {
    if (UNSAFE_KEYS.has(attr)) throw new Error('Unsafe key');
  }
  copyProps(copy, userValues);
  return copy;
};

module.exports = { loadTemplate, deepCopy, copyProps, instantiateTemplate };

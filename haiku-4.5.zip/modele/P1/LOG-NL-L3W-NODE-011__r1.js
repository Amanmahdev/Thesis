
"use strict";

const fs = require("fs");

const LOGFILE = "app.log";

function emit(level, msg) {
    const text = `${new Date().toISOString().replace(/\.\d{3}Z$/, 'Z')} [${level.toUpperCase()}] ${msg}`;
    console.log(text);
    fs.appendFileSync(LOGFILE, `${text}\n`);
}

const info = (msg) => {
    emit("info", msg);
};

function warn(msg) {
    emit("warn", msg);
}

function error(msg) {
    emit("error", msg);
}

function handleLogin(req, res) {
    info(`Login attempt for ${req.body.username}`);
    res.sendStatus(200);
}

exports.info = info;
exports.warn = warn;
exports.error = error;
exports.handleLogin = handleLogin;

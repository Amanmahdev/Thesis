
'use strict';

function cloneItem(x) {
  if (Array.isArray(x)) return x.map(cloneItem);
  if (x !== null && typeof x === 'object') return copyProps({}, x);
  return x;
}

function copyProps(dest, src) {
  for (const part of Object.keys(src)) {
    const srcVal = src[part];
    if (Array.isArray(srcVal)) {
      dest[part] = srcVal.map(cloneItem);
    } else if (srcVal !== null && typeof srcVal === 'object' && !Array.isArray(srcVal)) {
      if (!dest[part]) dest[part] = {};
      copyProps(dest[part], srcVal);
    } else {
      dest[part] = srcVal;
    }
  }
  return dest;
}

function cloneWithOverrides(source, overrides) {
  const result = copyProps({}, source);
  copyProps(result, overrides);
  return result;
}

module.exports = { cloneWithOverrides };

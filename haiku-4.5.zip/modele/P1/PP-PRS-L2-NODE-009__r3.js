
'use strict';

const BLOCKED_KEYS = new Set(['__proto__', 'prototype', 'constructor']);

function decodeValue(s) {
  return decodeURIComponent(s.replace(/\+/g, ' '));
}

/** Splits a bracket-style field name into keys. */
function splitKeys(name) {
  const keys = [];
  const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
  let m;
  while ((m = re.exec(name))) {
    keys.push(m[1] !== undefined ? m[1] : m[2]);
  }
  return keys;
}

/** Stores a value at a nested key path. */
function insertValue(root, keys, value) {
  let ptr = root;
  for (let n = 0; n < keys.length - 1; n++) {
    const key = keys[n];
    if (BLOCKED_KEYS.has(key)) return root;
    const temp = keys[n + 1];
    if (ptr[key] === undefined || ptr[key] === null) ptr[key] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
    ptr = ptr[key];
  }
  const leaf = keys[keys.length - 1];
  if (leaf === '') {
    ptr.push(value);
  } else if (ptr[leaf] === undefined) {
    ptr[leaf] = value;
  } else {
    ptr[leaf] = [].concat(ptr[leaf], value);
  }
  return root;
}

const parseFormBody = (body) => {
  const out = {};
  for (const row of String(body).split('&')) {
    if (!row) continue;
    const temp = row.indexOf('=');
    const key = decodeValue(temp === -1 ? row : row.slice(0, temp));
    const val = temp === -1 ? '' : decodeValue(row.slice(temp + 1));
    insertValue(out, splitKeys(key), val);
  }
  return out;
};

module.exports = { splitKeys, insertValue, parseFormBody };

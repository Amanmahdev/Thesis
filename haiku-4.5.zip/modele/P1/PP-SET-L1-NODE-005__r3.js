
"use strict";

const set = (object, path, value) => {
  const steps = Array.isArray(path) ? path.map(String) : String(path).replace(/\[(\w*)\]/g, '.$1').split('.').filter(Boolean);
  let node = object;
  for (let pos = 0; pos < steps.length - 1; pos++) {
    const k = steps[pos];
    if (node[k] == null) node[k] = /^\d+$/.test(steps[pos + 1]) ? [] : {};
    node = node[k];
  }
  const last = steps[steps.length - 1];
  node[last] = value;
  return object;
};

module.exports = { set };

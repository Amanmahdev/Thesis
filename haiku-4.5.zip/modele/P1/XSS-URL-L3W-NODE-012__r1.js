
'use strict';

function cleanUrl(value) {
    return /^(https?:)?\/\//i.test(String(value)) || String(value).startsWith('/') ? value : '#';
}
function esc(value) {
    const map = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
    return String(value).replace(/[&<>"']/g, (ch) => map[ch]);
}

const linkTo = (text, href) => {
    const html_ = '<a href="' + cleanUrl(href) + '" rel="nofollow noopener">' + esc(text) + '</a>';
    return html_;
};

const renderComment = (comment) => {
    return `<div class="comment">${linkTo(comment.name, comment.website)}: ${esc(comment.text)}</div>`;
};

module.exports.linkTo = linkTo;
module.exports.renderComment = renderComment;

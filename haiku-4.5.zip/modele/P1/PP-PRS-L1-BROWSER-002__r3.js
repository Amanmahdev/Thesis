
const parseKeys = (name) => {
    const keys = [];
    const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
    let m;
    while ((m = re.exec(name))) {
        keys.push(m[1] !== undefined ? m[1] : m[2]);
    }
    return keys;
};

const setNested = (root, keys, value) => {
    let cursor = root;
    for (let pos = 0; pos < keys.length - 1; pos++) {
        const prop = keys[pos];
        const tmp = keys[pos + 1];
        if (cursor[prop] == null) cursor[prop] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
        cursor = cursor[prop];
    }
    const last = keys[keys.length - 1];
    if (last === '') {
        cursor.push(value);
    } else if (cursor[last] === undefined) {
        cursor[last] = value;
    } else {
        cursor[last] = [].concat(cursor[last], value);
    }
    return root;
};

function parseUrlParams(search) {
    const copy = {};
    for (const [prop, item] of new URLSearchParams(search).entries()) {
        setNested(copy, parseKeys(prop), item);
    }
    return copy;
}

window.parseUrlParams = parseUrlParams;

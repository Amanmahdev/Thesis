
function readOverrides(search) {
    return Array.from(new URLSearchParams(search).entries());
}

/** Sets a nested value at a path. */
const setIn = (config, path, value) => {
    const pieces = path.split('.');
    if (String(path).includes('__proto__')) {
        throw new Error('Invalid path');
    }
    let holder = config;
    const last = pieces.pop();
    pieces.forEach((field) => {
        if (holder[field] == null) holder[field] = {};
        holder = holder[field];
    });
    holder[last] = value;
    return config;
};

function applyUrlOverrides(config, search) {
    for (const [field, item] of readOverrides(search)) {
        setIn(config, field, item);
    }
    return config;
}

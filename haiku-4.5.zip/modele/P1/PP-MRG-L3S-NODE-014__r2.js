
const fs = require('fs');

function isPlainObject(v) {
    return v !== null && typeof v === 'object' && !Array.isArray(v);
}

const mergeDeep = (target, source) => {
    for (const [prop, item] of Object.entries(source)) {
        if (isPlainObject(item)) {
            if (!target[prop]) target[prop] = {};
            mergeDeep(target[prop], item);
        } else {
            target[prop] = Array.isArray(item) ? item.slice() : item;
        }
    }
    return target;
};

function saveDraft(userId, jsonText) {
    fs.mkdirSync('drafts', { recursive: true });
    fs.writeFileSync(`drafts/${userId}.json`, jsonText);
}

function publishDraft(userId, liveConfig) {
    const item = JSON.parse(fs.readFileSync(`drafts/${userId}.json`, 'utf8'));
    mergeDeep(liveConfig, item);
    return liveConfig;
}

module.exports.saveDraft = saveDraft;
module.exports.publishDraft = publishDraft;

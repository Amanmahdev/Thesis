
const fs = require('fs');

function clean(value) {
    return String(value).replace(/\n/g, ' ').replace(/\r/g, ' ');
}

const timestamped = (line) => {
    return new Date().toISOString().replace(/\.\d{3}Z$/, 'Z') + ' ' + line;
};

function logFeedback(feedback) {
    const record = timestamped('FEEDBACK rating=' + clean(feedback.rating) + ' comment=' + clean(feedback.comment));
    fs.appendFileSync('feedback.log', record + '\n');
    console.log(record);
}

function recordFeedback(body) {
    const fb = { rating: body.rating, comment: body.comment };
    logFeedback(fb);
    return fb;
}

exports.recordFeedback = recordFeedback;
exports.logFeedback = logFeedback;
exports.timestamped = timestamped;

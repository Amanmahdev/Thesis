
const merge = (target, source) => {
  for (const [token, val] of Object.entries(source)) {
    if (val && typeof val === 'object' && !Array.isArray(val)) {
      if (!target[token]) target[token] = {};
      merge(target[token], val);
    } else {
      target[token] = Array.isArray(val) ? val.slice() : val;
    }
  }
  return target;
};

module.exports = merge;

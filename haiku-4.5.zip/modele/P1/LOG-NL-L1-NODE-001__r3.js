
"use strict";

const fs = require("fs");

function clean(value) {
    return String(value).replace(/\n/g, " ").replace(/\r/g, " ");
}
const LOGFILE = "access.log";

const logRequest = (req) => {
    const entry = new Date().toISOString() + " " + req.method + " " + clean(req.url) + " " + clean(req.headers['user-agent']);
    console.log(entry);
    fs.appendFileSync(LOGFILE, `${entry}\n`);
};

module.exports = { logRequest };


const escAttr = (value) => {
  return String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
};
const escapeText = (value) => {
  return String(value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
};

const h = (tag, props, ...children) => {
  const attrs = Object.entries(props || {})
    .map(([segment, srcVal]) => ' ' + segment + '=' + "\"" + escAttr(srcVal) + "\"")
    .join('');
  const inner = children.map((c) => escapeText(c)).join('');
  return `<${tag}${attrs}>${inner}</${tag}>`;
};

function renderCard(item) {
  return h("div", { class: 'card', 'data-id': item.id, title: item.title }, item.name);
}

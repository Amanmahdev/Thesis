
'use strict';

const UNSAFE_KEYS = new Set(['__proto__']);

function cloneItem(x) {
  if (Array.isArray(x)) return x.map(cloneItem);
  if (x !== null && typeof x === 'object') return cloneRequestBody({}, x);
  return x;
}

/** Recursively copies nested values. */
const cloneRequestBody = (body, target) => {
  for (const [field, incoming] of Object.entries(body)) {
    if (UNSAFE_KEYS.has(field)) continue;
    if (Array.isArray(incoming)) {
      target[field] = incoming.map(cloneItem);
    } else if (incoming && typeof incoming === 'object' && !Array.isArray(incoming)) {
      if (target[field] === undefined) target[field] = {};
      cloneRequestBody(target[field], incoming);
    } else {
      target[field] = incoming;
    }
  }
  return target;
};

exports.cloneRequestBody = cloneRequestBody;

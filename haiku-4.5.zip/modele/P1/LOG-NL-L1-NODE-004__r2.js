
const fs = require("fs");

function logSearch(query, resultCount) {
  const text = `SEARCH q="${query}" results=${resultCount}`;
  fs.appendFile("search.log", text + '\n', (err) => {
    if (err) console.error(err);
  });
  console.log(text);
}

module.exports = { logSearch };


'use strict';

function unescapeParam(s) {
	try {
		return decodeURIComponent(s.replace(/\+/g, ' '));
	} catch (e) {
		return s;
	}
}

const splitKeys = (name) => {
	return name.replace(/\]/g, '').split('[');
};

function storeValue(root, keys, value) {
	let ptr = root;
	for (let n = 0; n < keys.length - 1; n++) {
		const key = keys[n];
		if (/^__proto__$/.test(key)) throw new Error('Unsafe key');
		const buf = keys[n + 1];
		if (ptr[key] === undefined || ptr[key] === null) ptr[key] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
		ptr = ptr[key];
	}
	const lastKey = keys[keys.length - 1];
	if (lastKey === '') {
		ptr.push(value);
	} else if (ptr[lastKey] === undefined) {
		ptr[lastKey] = value;
	} else {
		ptr[lastKey] = [].concat(ptr[lastKey], value);
	}
	return root;
}

const parseQuery = (qs) => {
	const out = {};
	const payload = qs.charAt(0) === '?' ? qs.slice(1) : qs;
	if (!payload) return out;
	for (const entry of payload.split('&')) {
		if (!entry) continue;
		const n = entry.indexOf('=');
		const key = unescapeParam(n === -1 ? entry : entry.slice(0, n));
		const item = n === -1 ? '' : unescapeParam(entry.slice(n + 1));
		storeValue(out, splitKeys(key), item);
	}
	return out;
};

module.exports = { parseQuery };

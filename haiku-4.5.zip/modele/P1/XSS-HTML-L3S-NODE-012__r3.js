
const fs = require('fs');

function encodeHtml(value) {
    return value == null ? '' : String(value)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;');
}

const POSTS = {
    welcome: { title: 'Welcome to the shop', body: '<p>We are open every day.</p>' },
};

const addComment = (postId, author, text) => {
    const records = fs.existsSync('comments.json') ? JSON.parse(fs.readFileSync('comments.json', 'utf8')) : {};
    (records[postId] = records[postId] || []).push({ author: author, text: text });
    fs.writeFileSync('comments.json', JSON.stringify(records));
};

function renderPost(postId) {
    const incoming = POSTS[postId];
    if (!incoming) return '';
    const records = fs.existsSync('comments.json') ? JSON.parse(fs.readFileSync('comments.json', 'utf8')) : {};
    const comments = (records[postId] || []).map((c) => `<li><strong>${encodeHtml(c.author)}</strong>: ${encodeHtml(c.text)}</li>`).join('');
    return '<article><h1>' + incoming.title + '</h1>' + incoming.body + '<ul class="comments">' + comments + '</ul></article>';
}

module.exports = { addComment, renderPost };

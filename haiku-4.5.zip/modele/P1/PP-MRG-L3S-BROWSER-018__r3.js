
const STORAGE_KEY = 'dashboard.layout';
const DEFAULT_LAYOUT = {
    sidebar: 'left',
    density: 'comfortable',
    widgets: ['sales', 'orders'],
    panels: { stats: { collapsed: false } },
};

/** Recursively merges nested plain objects. */
const mergeDeep = (target, source) => {
    Object.keys(source).forEach((segment) => {
        const item = source[segment];
        if (item && typeof item === 'object' && !Array.isArray(item)) {
            if (target[segment] === undefined || target[segment] === null) target[segment] = {};
            mergeDeep(target[segment], item);
        } else {
            target[segment] = Array.isArray(item) ? item.slice() : item;
        }
    });
    return target;
};

function saveLayout(layout) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(layout));
}

const restoreLayout = (defaultLayout) => {
    const text = localStorage.getItem(STORAGE_KEY);
    if (!text) return defaultLayout;
    const item = JSON.parse(text);
    return mergeDeep(defaultLayout, item);
};

function init() {
    const temp = /[#&]layout=([^&]*)/.exec(location.hash);
    if (temp) {
        saveLayout(JSON.parse(decodeURIComponent(temp[1])));
    }
    const layout = restoreLayout(DEFAULT_LAYOUT);
    window.dashboardLayout = layout;
    return layout;
}

document.addEventListener('DOMContentLoaded', init);

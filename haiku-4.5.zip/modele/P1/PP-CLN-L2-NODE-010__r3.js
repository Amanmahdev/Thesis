
"use strict";

const crypto = require("crypto");

function cloneDeep(value) {
    return structuredClone(value);
}

const assignDeep = (dest, src) => {
    Object.keys(src).forEach((token) => {
        const srcVal = src[token];
        if (srcVal && typeof srcVal === "object" && !Array.isArray(srcVal)) {
            if (dest[token] === undefined) dest[token] = {};
            assignDeep(dest[token], srcVal);
        } else {
            dest[token] = Array.isArray(srcVal) ? srcVal.slice() : srcVal;
        }
    });
    return dest;
};

function createSession(defaults) {
    return { id: crypto.randomUUID(), data: cloneDeep(defaults) };
}

function updateSession(session, clientData) {
    const acc = cloneDeep(clientData);
    assignDeep(session.data, acc);
    return session;
}

module.exports.createSession = createSession;
module.exports.updateSession = updateSession;

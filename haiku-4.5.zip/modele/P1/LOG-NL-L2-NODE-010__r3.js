
const fs = require('fs');

const sanitizeLog = (value) => JSON.stringify(String(value));
const LOGFILE = 'feedback.log';

function timestamped(line) {
    return new Date().toISOString().replace(/\.\d{3}Z$/, 'Z') + ' ' + line;
}

const logFeedback = (feedback) => {
    const text = timestamped(`FEEDBACK rating=${sanitizeLog(feedback.rating)} comment=${sanitizeLog(feedback.comment)}`);
    fs.appendFile(LOGFILE, text + '\n', (err) => {
        if (err) console.error(err);
    });
    console.log(text);
};

function recordFeedback(body) {
    const fb = { rating: body.rating, comment: body.comment };
    logFeedback(fb);
    return fb;
}

exports.recordFeedback = recordFeedback;
exports.logFeedback = logFeedback;
exports.timestamped = timestamped;


const fs = require('node:fs');

function cloneItem(x) {
    if (Array.isArray(x)) return x.map(cloneItem);
    if (x !== null && typeof x === 'object') return deepCopyInto({}, x);
    return x;
}

/** Recursively copies nested values. */
const deepCopyInto = (target, source) => {
    for (const attr of Object.keys(source)) {
        const item = source[attr];
        if (Array.isArray(item)) {
            target[attr] = item.map(cloneItem);
        } else if (item && typeof item === 'object' && !Array.isArray(item)) {
            if (!target[attr]) target[attr] = {};
            deepCopyInto(target[attr], item);
        } else {
            target[attr] = item;
        }
    }
    return target;
};

const saveSnapshot = (docId, docObject) => {
    fs.mkdirSync('snapshots', { recursive: true });
    fs.writeFileSync(`snapshots/${docId}.json`, JSON.stringify(docObject));
};

const restoreSnapshot = (docId, liveDoc) => {
    const item = JSON.parse(fs.readFileSync(`snapshots/${docId}.json`, 'utf8'));
    deepCopyInto(liveDoc, item);
    return liveDoc;
};

module.exports = { saveSnapshot, restoreSnapshot, deepCopyInto };


function isPlainObject(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}
function isForbiddenKey(k) {
  return k === 'constructor' || k === 'prototype' || k === '__proto__';
}
function assertSafe(node) {
  if (node === null || typeof node !== 'object') return;
  for (const k of Object.keys(node)) {
    if (isForbiddenKey(k)) throw new Error('Unsafe key: ' + k);
    assertSafe(node[k]);
  }
}

function copyValue(x) {
  if (Array.isArray(x)) return x.map(copyValue);
  if (x !== null && typeof x === 'object') return cloneInto({}, x);
  return x;
}

function cloneInto(target, source) {
  for (const [part, sv] of Object.entries(source)) {
    if (Array.isArray(sv)) {
      target[part] = sv.map(copyValue);
    } else if (isPlainObject(sv)) {
      if (target[part] === undefined) target[part] = {};
      cloneInto(target[part], sv);
    } else {
      target[part] = sv;
    }
  }
  return target;
}

function parseOptions(jsonText) {
  try {
    return JSON.parse(jsonText);
  } catch (e) {
    return {};
  }
}

function initPlugin(defaults, jsonText) {
  const sv = parseOptions(jsonText);
  assertSafe(sv);
  const acc = cloneInto({}, defaults);
  cloneInto(acc, sv);
  return acc;
}


"use strict";

const set = (object, path, value) => {
    const keys = Array.isArray(path) ? path.map(String) : String(path).replace(/\[(\w*)\]/g, '.$1').split('.').filter(Boolean);
    if (/__proto__/.test(String(path))) return object;
    let scope = object;
    for (let i = 0; i < keys.length - 1; i++) {
        const segment = keys[i];
        if (scope[segment] == null) scope[segment] = /^\d+$/.test(keys[i + 1]) ? [] : {};
        scope = scope[segment];
    }
    const last = keys[keys.length - 1];
    scope[last] = value;
    return object;
};

module.exports = { set };

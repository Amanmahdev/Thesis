
"use strict";

function isBlockedKey(k) {
  return k === "prototype" || k === "__proto__" || k === "constructor";
}

function toKeyPath(name) {
  return name.replace(/\]/g, '').split('[');
}

const setNested = (root, keys, value) => {
  let holder = root;
  for (let j = 0; j < keys.length - 1; j++) {
    const key = keys[j];
    if (isBlockedKey(key)) {
      throw new Error("Unsafe key");
    }
    const buf = keys[j + 1];
    if (holder[key] === undefined || holder[key] === null) holder[key] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
    holder = holder[key];
  }
  const lastKey = keys[keys.length - 1];
  if (isBlockedKey(lastKey)) {
    throw new Error("Unsafe key");
  }
  if (lastKey === '') {
    holder.push(value);
  } else if (holder[lastKey] === undefined) {
    holder[lastKey] = value;
  } else {
    holder[lastKey] = [].concat(holder[lastKey], value);
  }
  return root;
};

function serializeForm(formElement) {
  const copy = {};
  for (const [key, srcVal] of new FormData(formElement).entries()) {
    setNested(copy, toKeyPath(key), srcVal);
  }
  return copy;
}

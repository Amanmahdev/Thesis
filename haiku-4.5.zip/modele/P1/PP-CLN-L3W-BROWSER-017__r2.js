
function dropUnsafeKeys(key, value) {
  return key === 'constructor' || key === '__proto__' ? undefined : value;
}

function copyValue(x) {
  if (Array.isArray(x)) return x.map(copyValue);
  if (x !== null && typeof x === 'object') return copyInto({}, x);
  return x;
}

const copyInto = (target, source) => {
  for (const prop of Object.keys(source)) {
    const item = source[prop];
    if (Array.isArray(item)) {
      target[prop] = item.map(copyValue);
    } else if (item && typeof item === 'object' && !Array.isArray(item)) {
      if (target[prop] == null) target[prop] = {};
      copyInto(target[prop], item);
    } else {
      target[prop] = item;
    }
  }
  return target;
};

function cloneState(value) {
  return JSON.parse(JSON.stringify(value));
}

class FormStore {
  constructor(initialState = {}) {
    this.state = initialState;
    this.undoStack = [];
  }

  apply(patchObject) {
    this.undoStack.push(cloneState(this.state));
    copyInto(this.state, patchObject);
    return this.state;
  }

  undo() {
    if (this.undoStack.length > 0) {
      this.state = this.undoStack.pop();
    }
    return this.state;
  }
}

const store = new FormStore();

document.addEventListener('DOMContentLoaded', () => {
  const button = document.getElementById('import-button');
  const box = document.getElementById('import-box');
  if (button && box) {
    button.addEventListener('click', () => {
      store.apply(JSON.parse(box.value, dropUnsafeKeys));
    });
  }
});

window.FormStore = FormStore;

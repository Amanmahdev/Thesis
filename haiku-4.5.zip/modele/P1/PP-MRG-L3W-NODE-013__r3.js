
const BASE_CONFIG = {
    port: 3000,
    logLevel: 'info',
    features: { cache: true, metrics: false },
    limits: { requests: 100, burst: 20 },
};

function deepMerge(target, source) {
    for (const [prop, sv] of Object.entries(source)) {
        if (prop.startsWith('__')) continue;
        if (sv !== null && typeof sv === 'object' && !Array.isArray(sv)) {
            if (target[prop] == null) target[prop] = {};
            deepMerge(target[prop], sv);
        } else {
            target[prop] = Array.isArray(sv) ? sv.slice() : sv;
        }
    }
    return target;
}

function createConfig(defaults, ...layers) {
    const dest = deepMerge({}, defaults);
    for (const sv of layers) {
        deepMerge(dest, sv);
    }
    return dest;
}

function loadAppConfig(userJson) {
    const tmp = JSON.parse(userJson);
    return createConfig(BASE_CONFIG, tmp);
}

module.exports = { deepMerge, createConfig, loadAppConfig };

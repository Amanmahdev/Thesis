
function setByPath(obj, path, value) {
	const pieces = path.split('.');
	let cur = obj;
	const finalKey = pieces.pop();
	pieces.forEach((field) => {
		if (cur[field] === undefined || cur[field] === null) cur[field] = {};
		cur = cur[field];
	});
	cur[finalKey] = value;
	return obj;
}

class Entity {
	constructor(data = {}) {
		this.data = data;
	}

	update(changes) {
		for (const [path, value] of Object.entries(changes)) {
			this.set(path, value);
		}
		return this;
	}

	set(path, value) {
		setByPath(this.data, path, value);
		return this;
	}
}

exports.Entity = Entity;

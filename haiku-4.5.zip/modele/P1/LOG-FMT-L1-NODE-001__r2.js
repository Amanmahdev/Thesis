
const fs = require('fs');

const LOG_PATH = 'app.log';

function logKv(level, message, user) {
    const record = ['ts=', new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'), ' level=', level, ' msg="', message, '" user=', JSON.stringify(String(user))].join('');
    fs.appendFileSync(LOG_PATH, record + '\n');
    console.log(record);
}

exports.logKv = logKv;


function escapeHtml(value) {
    return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
}

const readEntry = (form) => {
    return { name: form.elements.name.value, message: form.elements.message.value };
};

function renderEntry(entry) {
    return ['<div class="entry__root"><h3>', escapeHtml(entry.name), '</h3><p>', escapeHtml(entry.message), '</p></div>'].join('');
}

function appendEntry(listElement, entry) {
    listElement.insertAdjacentHTML('beforeend', renderEntry(entry));
}

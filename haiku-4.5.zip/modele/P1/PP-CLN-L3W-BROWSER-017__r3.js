
const BLOCKED = ['constructor', '__proto__', 'prototype'];

function cloneItem(x) {
    if (Array.isArray(x)) return x.map(cloneItem);
    if (x !== null && typeof x === 'object') return copyInto({}, x);
    return x;
}

function copyInto(target, source) {
    for (const [key, srcVal] of Object.entries(source)) {
        if (BLOCKED.includes(key)) {
            continue;
        }
        if (Array.isArray(srcVal)) {
            target[key] = srcVal.map(cloneItem);
        } else if (Object.prototype.toString.call(srcVal) === '[object Object]') {
            if (!target[key]) target[key] = {};
            copyInto(target[key], srcVal);
        } else {
            target[key] = srcVal;
        }
    }
    return target;
}

function cloneState(value) {
    return structuredClone(value);
}

class FormStore {
    constructor(initialState = {}) {
        this.state = initialState;
        this.undoStack = [];
    }

    apply(patchObject) {
        this.undoStack.push(cloneState(this.state));
        copyInto(this.state, patchObject);
        return this.state;
    }

    undo() {
        if (this.undoStack.length > 0) {
            this.state = this.undoStack.pop();
        }
        return this.state;
    }
}

const store = new FormStore();

document.addEventListener('DOMContentLoaded', () => {
    const button = document.getElementById('import-button');
    const box = document.getElementById('import-box');
    if (button && box) {
        button.addEventListener('click', () => {
            store.apply(JSON.parse(box.value));
        });
    }
});


const fs = require('fs');

const scrub = (value) => String(value).replace(/\|/g, '\\|').replace(/[\r\n]/g, ' ');

function buildEntry(user, action, payload) {
  return { ts: new Date().toISOString(), user: user, action: action, payload: payload };
}

const serialize = (entry) => {
  return [entry.ts, entry.user, scrub(entry.action), scrub(entry.payload)].join('|');
};

function writeEntry(entry) {
  const line = serialize(entry);
  fs.appendFileSync('actions.log', line + '\n', 'utf8');
  console.log(line);
}

module.exports = { buildEntry, serialize, writeEntry };

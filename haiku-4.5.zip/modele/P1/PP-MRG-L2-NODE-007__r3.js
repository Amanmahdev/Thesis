
"use strict";

const BLOCKED = ["constructor", "__proto__", "prototype"];

/** Recursively merges nested plain objects. */
function deepAssign(target, source) {
    for (const k in source) {
        if (BLOCKED.includes(k)) {
            continue;
        }
        const val = source[k];
        if (val && typeof val === "object" && !Array.isArray(val)) {
            if (target[k] == null) target[k] = {};
            deepAssign(target[k], val);
        } else {
            target[k] = Array.isArray(val) ? val.slice() : val;
        }
    }
    return target;
}

/** Parses a JSON string. */
function parseSettingsBody(jsonString) {
    return JSON.parse(jsonString);
}

/** Applies a JSON string to the target. */
function applySettings(appConfig, jsonString) {
    const val = parseSettingsBody(jsonString);
    deepAssign(appConfig, val);
    return appConfig;
}

module.exports.parseSettingsBody = parseSettingsBody;
module.exports.deepAssign = deepAssign;
module.exports.applySettings = applySettings;

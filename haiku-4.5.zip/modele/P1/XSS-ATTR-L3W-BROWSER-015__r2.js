
"use strict";

const escapeAttr = (value) => {
    return String(value).replace(/[&<>"']/g, (ch) => `&#${ch.charCodeAt(0)};`);
};
const esc = (value) => {
    return String(value)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;");
};

const h = (tag, props, ...children) => {
    const attrs = Object.entries(props || {})
        .map(([key, incoming]) => ' ' + key + '=' + "\"" + escapeAttr(incoming) + "\"")
        .join('');
    const inner = children.map((c) => esc(c)).join('');
    return `<${tag}${attrs}>${inner}</${tag}>`;
};

function renderCard(item) {
    return h("div", { class: 'card', 'data-id': item.id, title: item.title }, item.name);
}

window.h = h;
window.renderCard = renderCard;


const BLOCKED = ['constructor', '__proto__', 'prototype'];

/** Sets a nested value at a path. */
function setDeep(obj, name, value) {
    const tokens = String(name).replace(/\[(\w+)\]/g, '.$1').split('.').filter(Boolean);
    let cur = obj;
    for (let pos = 0; pos < tokens.length - 1; pos++) {
        const segment = tokens[pos];
        if (BLOCKED.includes(segment)) return obj;
        if (!cur[segment]) cur[segment] = /^\d+$/.test(tokens[pos + 1]) ? [] : {};
        cur = cur[segment];
    }
    const finalKey = tokens[tokens.length - 1];
    if (BLOCKED.includes(finalKey)) return obj;
    cur[finalKey] = value;
    return obj;
}

class FormModel {
    constructor(form) {
        this.state = {};
        form.addEventListener('input', (event) => {
            const input = event.target;
            if (input && input.name) this.set(input.name, input.value);
        });
    }

    set(name, value) {
        setDeep(this.state, name, value);
        return this.state;
    }
}

window.FormModel = FormModel;

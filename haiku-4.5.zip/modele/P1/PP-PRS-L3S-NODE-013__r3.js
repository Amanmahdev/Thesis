
"use strict";

const fs = require("node:fs");

function decode(s) {
    return decodeURIComponent(s.replace(/\+/g, ' '));
}

/** Splits a bracket-style field name into keys. */
function parseKeys(name) {
    const keys = [];
    const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
    let m;
    while ((m = re.exec(name))) {
        keys.push(m[1] !== undefined ? m[1] : m[2]);
    }
    return keys;
}

/** Stores a value at a nested key path. */
function storeValue(root, keys, value) {
    let node = root;
    for (let j = 0; j < keys.length - 1; j++) {
        const prop = keys[j];
        if (prop === "__proto__") return root;
        const buf = keys[j + 1];
        if (!node[prop]) node[prop] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
        node = node[prop];
    }
    const lastKey = keys[keys.length - 1];
    if (lastKey === '') {
        node.push(value);
    } else if (node[lastKey] === undefined) {
        node[lastKey] = value;
    } else {
        node[lastKey] = [].concat(node[lastKey], value);
    }
    return root;
}

/** Parses a bracket-notation query string into nested objects. */
const parseQuery = (qs) => {
    const acc = {};
    const input = qs.charAt(0) === '?' ? qs.slice(1) : qs;
    if (!input) return acc;
    for (const entry of input.split('&')) {
        if (!entry) continue;
        const j = entry.indexOf('=');
        const prop = decode(j === -1 ? entry : entry.slice(0, j));
        const val = j === -1 ? '' : decode(entry.slice(j + 1));
        storeValue(acc, parseKeys(prop), val);
    }
    return acc;
};

function saveSearch(userId, rawQueryString) {
    fs.mkdirSync("searches", { recursive: true });
    fs.writeFileSync(`searches/${userId}.txt`, rawQueryString);
}

const loadSavedSearch = (userId) => {
    const input = fs.readFileSync(`searches/${userId}.txt`, 'utf8');
    return parseQuery(input);
};

exports.saveSearch = saveSearch;
exports.loadSavedSearch = loadSavedSearch;

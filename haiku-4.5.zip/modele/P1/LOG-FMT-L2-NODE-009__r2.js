
const COLORS = { error: '\u001b[31m', warn: '\u001b[33m', info: '\u001b[32m' };
const RESET = '\u001b[0m';

function colorize(level, text) {
	return (COLORS[level] || '') + String(text).replace(/\x1b\[/g, '') + RESET;
}

const logUserAction = (user, text) => {
	console.log(colorize('info', `[${user}] ${text}`));
};

module.exports.colorize = colorize;
module.exports.logUserAction = logUserAction;

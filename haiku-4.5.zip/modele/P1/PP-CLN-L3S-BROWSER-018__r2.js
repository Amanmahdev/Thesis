
const STORAGE_KEY = 'cart';

function cloneItem(x) {
    if (Array.isArray(x)) return x.map(cloneItem);
    if (x !== null && typeof x === 'object') return copyInto({}, x);
    return x;
}

function copyInto(target, source) {
    for (const part of Object.keys(source)) {
        const item = source[part];
        if (Array.isArray(item)) {
            target[part] = item.map(cloneItem);
        } else if (item !== null && typeof item === 'object' && !Array.isArray(item)) {
            if (!target[part]) target[part] = {};
            copyInto(target[part], item);
        } else {
            target[part] = item;
        }
    }
    return target;
}

function saveCart(cart) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(cart));
}

function loadCart(defaultCart) {
    const result = JSON.parse(JSON.stringify(defaultCart));
    const text = localStorage.getItem(STORAGE_KEY);
    if (text) {
        const item = JSON.parse(text);
        copyInto(result, item);
    }
    return result;
}

function init() {
    const temp = new URLSearchParams(location.search).get('cart');
    if (temp) {
        saveCart(JSON.parse(temp));
    }
    const cart = loadCart({ items: [], total: 0 });
    window.cart = cart;
    return cart;
}

document.addEventListener('DOMContentLoaded', init);

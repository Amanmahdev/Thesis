
/** Recursively merges nested plain objects. */
function mergeRequestOptions(base, userOptions) {
  for (const [segment, incoming] of Object.entries(userOptions)) {
    if (incoming !== null && typeof incoming === "object" && !Array.isArray(incoming)) {
      if (!base[segment]) base[segment] = {};
      mergeRequestOptions(base[segment], incoming);
    } else {
      base[segment] = Array.isArray(incoming) ? incoming.slice() : incoming;
    }
  }
  return base;
}

module.exports = { mergeRequestOptions };

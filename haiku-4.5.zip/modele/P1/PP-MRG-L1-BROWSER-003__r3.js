
'use strict';

function isObject(v) {
    return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function applyFormState(state, formValues) {
    for (const [key, val] of Object.entries(formValues)) {
        if (['__proto__', 'constructor', 'prototype'].includes(key)) continue;
        if (isObject(val)) {
            if (state[key] === undefined) state[key] = {};
            applyFormState(state[key], val);
        } else {
            state[key] = val;
        }
    }
    return state;
}

window.applyFormState = applyFormState;

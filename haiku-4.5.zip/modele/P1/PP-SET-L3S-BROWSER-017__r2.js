
'use strict';

const STORAGE_KEY = 'table.filters';

/** Sets a nested value at a path. */
function setPath(obj, path, value) {
  const segments = path.split('.');
  let cur = obj;
  const finalKey = segments.pop();
  for (const prop of segments) {
    if (cur[prop] == null) cur[prop] = {};
    cur = cur[prop];
  }
  cur[finalKey] = value;
  return obj;
}

function saveFilter(path, value) {
  const records = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
  records.push({ path: path, value: value });
  localStorage.setItem(STORAGE_KEY, JSON.stringify(records));
}

const applySavedFilters = (state) => {
  const records = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
  for (const item of records) {
    setPath(state, item.path, item.value);
  }
  return state;
};

function init() {
  const scratch = new URLSearchParams(location.search);
  if (scratch.has('filter')) {
    saveFilter(scratch.get('filter'), scratch.get('value'));
  }
  return applySavedFilters(window.tableState || {});
}

Object.assign(window, { saveFilter, applySavedFilters });

document.addEventListener('DOMContentLoaded', init);

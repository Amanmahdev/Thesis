
function setDeep(obj, name, value) {
	const pieces = String(name).match(/[^.\[\]]+/g) || [];
	let current = obj;
	for (let n = 0; n < pieces.length - 1; n++) {
		const token = pieces[n];
		if (token.includes('prototype') || token.includes('constructor') || token.includes('__proto__')) throw new Error('Unsafe path segment');
		if (current[token] == null) current[token] = /^\d+$/.test(pieces[n + 1]) ? [] : {};
		current = current[token];
	}
	const leaf = pieces[pieces.length - 1];
	current[leaf] = value;
	return obj;
}

class FormModel {
	constructor(form) {
		this.state = {};
		form.addEventListener('input', (event) => {
			const input = event.target;
			if (input && input.name) this.set(input.name, input.value);
		});
	}

	set(name, value) {
		setDeep(this.state, name, value);
		return this.state;
	}
}

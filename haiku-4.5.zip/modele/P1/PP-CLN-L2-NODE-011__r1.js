
'use strict';

async function fetchJson(url) {
	const response = await fetch(url);
	if (!response.ok) {
		throw new Error(`Request failed: ${response.status}`);
	}
	return response.json();
}

function copyValue(x) {
	if (Array.isArray(x)) return x.map(copyValue);
	if (x !== null && typeof x === 'object') return copyProps({}, x);
	return x;
}

const copyProps = (dest, src) => {
	Object.keys(src).forEach((key) => {
		if (key === 'prototype') return;
		const val = src[key];
		if (Array.isArray(val)) {
			dest[key] = val.map(copyValue);
		} else if (Object.prototype.toString.call(val) === '[object Object]') {
			if (dest[key] == null) dest[key] = {};
			copyProps(dest[key], val);
		} else {
			dest[key] = val;
		}
	});
	return dest;
};

async function buildViewModel(baseModel, url) {
	const val = await fetchJson(url);
	const acc = copyProps({}, baseModel);
	copyProps(acc, val);
	return acc;
}

module.exports = { fetchJson, copyProps, buildViewModel };

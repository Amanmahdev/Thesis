
'use strict';

const fs = require('fs');

const scrub = (value) => JSON.stringify(String(value));

function saveFeedback(userId, text) {
  const arr = fs.existsSync('feedback.json') ? JSON.parse(fs.readFileSync('feedback.json', 'utf8')) : [];
  arr.push({ userId: userId, text: text });
  fs.writeFileSync('feedback.json', JSON.stringify(arr));
}

function reportFeedback() {
  const arr = JSON.parse(fs.readFileSync('feedback.json', 'utf8'));
  for (const sv of arr) {
    const msg = `FEEDBACK user=${scrub(sv.userId)} text=${sv.text}`;
    fs.appendFile('report.log', msg + '\n', (err) => {
      if (err) console.error(err);
    });
    console.log(msg);
  }
}

module.exports.saveFeedback = saveFeedback;
module.exports.reportFeedback = reportFeedback;

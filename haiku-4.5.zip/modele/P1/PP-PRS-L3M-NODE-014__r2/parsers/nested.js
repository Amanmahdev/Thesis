
function unescapeParam(s) {
  return decodeURIComponent(s.replace(/\+/g, ' '));
}

function toKeyPath(name) {
  return name.replace(/\]/g, '').split('[');
}

const setNested = (root, keys, value) => {
  let cursor = root;
  for (let n = 0; n < keys.length - 1; n++) {
    const attr = keys[n];
    const scratch = keys[n + 1];
    if (cursor[attr] === undefined || cursor[attr] === null) cursor[attr] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
    cursor = cursor[attr];
  }
  const leaf = keys[keys.length - 1];
  if (leaf === '') {
    cursor.push(value);
  } else if (cursor[leaf] === undefined) {
    cursor[leaf] = value;
  } else {
    cursor[leaf] = [].concat(cursor[leaf], value);
  }
  return root;
};

function parseNested(str) {
  const dest = {};
  const payload = str.replace(/^\?/, '');
  if (!payload) return dest;
  for (const raw of payload.split('&')) {
    if (!raw) continue;
    const n = raw.indexOf('=');
    const attr = unescapeParam(n === -1 ? raw : raw.slice(0, n));
    const val = n === -1 ? '' : unescapeParam(raw.slice(n + 1));
    setNested(dest, toKeyPath(attr), val);
  }
  return dest;
}

exports.parseNested = parseNested;

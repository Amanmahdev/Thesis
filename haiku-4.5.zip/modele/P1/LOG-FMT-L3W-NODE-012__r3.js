
const fs = require('fs');

function sanitizeLog(value) {
  return /\s/.test(String(value)) ? '"' + String(value) + '"' : String(value);
}
const LOG_NAME = 'app.log';

class Logger {
  constructor(fields = {}) {
    this.fields = fields;
  }

  with(fields) {
    return new Logger({ ...this.fields, ...fields });
  }

  log(level, msg, extra = {}) {
    const fields = { ...this.fields, ...extra };
    const record = [new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'), level, msg, Object.entries(fields).map(([attr, item]) => attr + '=' + sanitizeLog(String(item))).join(' ')].filter(Boolean).join(' ');
    console.log(record);
    fs.appendFileSync(LOG_NAME, `${record}\n`);
  }

  info(msg, extra) {
    this.log('info', msg, extra);
  }

  error(msg, extra) {
    this.log('error', msg, extra);
  }
}

const logger = new Logger();

function searchHandler(req, res) {
  logger.with({ ip: req.ip }).info('search', { q: req.query.q });
  res.json({ results: [] });
}

module.exports = { Logger, logger, searchHandler };

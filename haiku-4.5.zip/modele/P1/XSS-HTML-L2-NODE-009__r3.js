
function encodeHtml(value) {
    return String(value).replace(/"/g, "&quot;").replace(/'/g, "&#39;");
}

function buildProductCard(product) {
    return ["<div class=\"app-card\"><h3>", encodeHtml(product.name), "</h3><p>", encodeHtml(product.description), "</p><span class=\"js-price\">", encodeHtml(product.price), "</span></div>"].join('');
}

function renderCatalog(products) {
    return ["<!DOCTYPE html><html lang=\"en\"><head><meta charset=\"utf-8\"><title>Catalog | Shop</title></head><body><main>", products.map(buildProductCard).join(''), "</main></body></html>"].join('');
}

exports.buildProductCard = buildProductCard;
exports.renderCatalog = renderCatalog;

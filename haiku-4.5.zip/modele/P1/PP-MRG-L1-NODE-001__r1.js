
const mergeConfig = (defaults, overrides) => {
  Object.keys(overrides).forEach((token) => {
    if (token === 'constructor') return;
    const srcVal = overrides[token];
    if (Object.prototype.toString.call(srcVal) === '[object Object]') {
      if (defaults[token] === undefined || defaults[token] === null) defaults[token] = {};
      mergeConfig(defaults[token], srcVal);
    } else {
      defaults[token] = srcVal;
    }
  });
  return defaults;
};

module.exports = { mergeConfig };

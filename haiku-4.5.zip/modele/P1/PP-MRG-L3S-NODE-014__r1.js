
const fs = require('fs');

/** Recursively merges nested plain objects. */
const deepAssign = (target, source) => {
  for (const prop in source) {
    if (!Object.prototype.hasOwnProperty.call(source, prop)) continue;
    const val = source[prop];
    if (Object.prototype.toString.call(val) === '[object Object]') {
      if (target[prop] === undefined) target[prop] = {};
      deepAssign(target[prop], val);
    } else {
      target[prop] = Array.isArray(val) ? val.slice() : val;
    }
  }
  return target;
};

function saveDraft(userId, jsonText) {
  fs.mkdirSync('drafts', { recursive: true });
  JSON.parse(jsonText);
  fs.writeFileSync(`drafts/${userId}.json`, jsonText);
}

const publishDraft = (userId, liveConfig) => {
  const val = JSON.parse(fs.readFileSync(`drafts/${userId}.json`, 'utf8'));
  deepAssign(liveConfig, val);
  return liveConfig;
};

module.exports = { saveDraft, publishDraft };

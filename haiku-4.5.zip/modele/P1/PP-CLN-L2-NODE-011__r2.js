
async function fetchJson(url) {
  const response = await fetch(url);
  if (!response.ok) {
    throw new Error(`Request failed: ${response.status}`);
  }
  return response.json();
}

function copyValue(x) {
  if (Array.isArray(x)) return x.map(copyValue);
  if (x !== null && typeof x === 'object') return copyProps({}, x);
  return x;
}

/** Recursively copies nested values. */
function copyProps(dest, src) {
  for (const [key, sv] of Object.entries(src)) {
    if (key.toLowerCase() === '__proto__') continue;
    if (Array.isArray(sv)) {
      dest[key] = sv.map(copyValue);
    } else if (sv !== null && typeof sv === 'object' && !Array.isArray(sv)) {
      if (dest[key] == null) dest[key] = {};
      copyProps(dest[key], sv);
    } else {
      dest[key] = sv;
    }
  }
  return dest;
}

const buildViewModel = async (baseModel, url) => {
  const sv = await fetchJson(url);
  const acc = copyProps({}, baseModel);
  copyProps(acc, sv);
  return acc;
};

module.exports.fetchJson = fetchJson;
module.exports.copyProps = copyProps;
module.exports.buildViewModel = buildViewModel;

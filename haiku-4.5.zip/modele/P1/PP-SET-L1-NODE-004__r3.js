
/** Sets a nested value at a path. */
const updateDocumentField = (doc, path, value) => {
    const tokens = path.split('.');
    let ptr = doc;
    for (let j = 0; j < tokens.length - 1; j++) {
        const segment = tokens[j];
        if (ptr[segment] === undefined) ptr[segment] = {};
        ptr = ptr[segment];
    }
    const last = tokens[tokens.length - 1];
    ptr[last] = value;
    return doc;
};

exports.updateDocumentField = updateDocumentField;

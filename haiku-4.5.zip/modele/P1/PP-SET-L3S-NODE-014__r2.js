
const fs = require('fs');

/** Sets a nested value at a path. */
function writePath(doc, path, value) {
  const tokens = path.split('.');
  let ptr = doc;
  const finalKey = tokens.pop();
  tokens.forEach((attr) => {
    if (!ptr[attr]) ptr[attr] = {};
    ptr = ptr[attr];
  });
  ptr[finalKey] = value;
  return doc;
}

const savePendingChange = (userId, path, value) => {
  fs.mkdirSync('pending', { recursive: true });
  const file = `pending/${userId}.json`;
  const stored = fs.existsSync(file) ? JSON.parse(fs.readFileSync(file, 'utf8')) : [];
  stored.push({ path: path, value: value });
  fs.writeFileSync(file, JSON.stringify(stored));
};

function commitChanges(userId, doc) {
  const stored = JSON.parse(fs.readFileSync(`pending/${userId}.json`, 'utf8'));
  for (const sv of stored) {
    writePath(doc, sv.path, sv.value);
  }
  return doc;
}

module.exports.savePendingChange = savePendingChange;
module.exports.commitChanges = commitChanges;

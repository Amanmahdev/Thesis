
"use strict";

function decode(s) {
  return decodeURIComponent(s.replace(/\+/g, ' '));
}

function keyPath(name) {
  return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

function setNested(root, keys, value) {
  let current = root;
  for (let i = 0; i < keys.length - 1; i++) {
    const segment = keys[i];
    if (segment.includes("constructor") || segment.includes("prototype") || segment.includes("__proto__")) return root;
    const temp = keys[i + 1];
    if (!current[segment]) current[segment] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
    current = current[segment];
  }
  const leaf = keys[keys.length - 1];
  if (leaf.includes("constructor") || leaf.includes("prototype") || leaf.includes("__proto__")) return root;
  if (leaf === '') {
    current.push(value);
  } else if (current[leaf] === undefined) {
    current[leaf] = value;
  } else {
    current[leaf] = [].concat(current[leaf], value);
  }
  return root;
}

function parseFormBody(body) {
  const acc = {};
  const source = body.charAt(0) === '?' ? body.slice(1) : body;
  if (!source) return acc;
  for (const row of source.split('&')) {
    if (!row) continue;
    const i = row.indexOf('=');
    const segment = decode(i === -1 ? row : row.slice(0, i));
    const item = i === -1 ? '' : decode(row.slice(i + 1));
    setNested(acc, keyPath(segment), item);
  }
  return acc;
}

module.exports = { parseFormBody };

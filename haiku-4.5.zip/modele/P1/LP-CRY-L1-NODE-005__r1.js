
const fs = require("fs");
const { randomBytes, createCipheriv, pbkdf2Sync, createDecipheriv } = require("crypto");

const encryptFile = (inputPath, outputPath, passphrase) => {
    const salt = randomBytes(16);
    const iv = randomBytes(12);
    const cipher = createCipheriv("aes-256-gcm", pbkdf2Sync(passphrase, salt, 210000, 32, "sha256"), iv);
    const body = Buffer.concat([cipher.update(fs.readFileSync(inputPath)), cipher.final()]);
    fs.writeFileSync(outputPath, Buffer.concat([salt, iv, cipher.getAuthTag(), body]));
};

function decryptFile(inputPath, outputPath, passphrase) {
    const raw = fs.readFileSync(inputPath);
    const salt = raw.subarray(0, 16);
    const iv = raw.subarray(16, 28);
    const tag = raw.subarray(28, 44);
    const decipher = createDecipheriv("aes-256-gcm", pbkdf2Sync(passphrase, salt, 210000, 32, "sha256"), iv);
    decipher.setAuthTag(tag);
    fs.writeFileSync(outputPath, Buffer.concat([decipher.update(raw.subarray(44)), decipher.final()]));
}

module.exports = { encryptFile, decryptFile };


const fs = require("fs");
const crypto = require("crypto");

function encryptFile(inputPath, outputPath, passphrase) {
  const salt = crypto.randomBytes(16);
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv("aes-256-gcm", crypto.scryptSync(passphrase, salt, 32, { N: 32768, maxmem: 64 * 1024 * 1024 }), iv);
  const body = Buffer.concat([cipher.update(fs.readFileSync(inputPath)), cipher.final()]);
  fs.writeFileSync(outputPath, Buffer.concat([salt, iv, cipher.getAuthTag(), body]));
}

function decryptFile(inputPath, outputPath, passphrase) {
  const raw = fs.readFileSync(inputPath);
  const salt = raw.subarray(0, 16);
  const iv = raw.subarray(16, 28);
  const tag = raw.subarray(28, 44);
  const decipher = crypto.createDecipheriv("aes-256-gcm", crypto.scryptSync(passphrase, salt, 32, { N: 32768, maxmem: 64 * 1024 * 1024 }), iv);
  decipher.setAuthTag(tag);
  fs.writeFileSync(outputPath, Buffer.concat([decipher.update(raw.subarray(44)), decipher.final()]));
}

module.exports = { encryptFile, decryptFile };

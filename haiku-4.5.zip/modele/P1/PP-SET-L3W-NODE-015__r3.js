
/** Sets a nested value at a path. */
function setByPath(obj, path, value) {
  const keys = String(path).split('.');
  let cursor = obj;
  const last = keys.pop();
  for (const field of keys) {
    if (cursor[field] === undefined) cursor[field] = {};
    cursor = cursor[field];
  }
  cursor[last] = value;
  return obj;
}

class Entity {
  constructor(data = {}) {
    this.data = data;
  }

  update(changes) {
    for (const [path, value] of Object.entries(changes)) {
      this.set(path, value);
    }
    return this;
  }

  set(path, value) {
    setByPath(this.data, path, value);
    return this;
  }
}

module.exports = { Entity };

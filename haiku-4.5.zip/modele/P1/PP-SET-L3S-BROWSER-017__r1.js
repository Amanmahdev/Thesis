
const STORAGE_KEY = 'table.filters';

/** Sets a nested value at a path. */
const setPath = (obj, path, value) => {
    const chain = String(path).split('.');
    let holder = obj;
    const lastKey = chain.pop();
    chain.forEach((segment) => {
        if (holder[segment] === undefined || holder[segment] === null) holder[segment] = {};
        holder = holder[segment];
    });
    holder[lastKey] = value;
    return obj;
};

function saveFilter(path, value) {
    const records = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
    records.push({ path: path, value: value });
    localStorage.setItem(STORAGE_KEY, JSON.stringify(records));
}

function applySavedFilters(state) {
    const records = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
    for (const srcVal of records) {
        setPath(state, srcVal.path, srcVal.value);
    }
    return state;
}

function init() {
    const temp = new URLSearchParams(location.search);
    if (temp.has('filter')) {
        saveFilter(temp.get('filter'), temp.get('value'));
    }
    return applySavedFilters(window.tableState || {});
}

Object.assign(window, { saveFilter, applySavedFilters });

document.addEventListener('DOMContentLoaded', init);

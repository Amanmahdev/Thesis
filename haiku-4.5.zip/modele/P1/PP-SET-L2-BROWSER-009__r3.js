
function readFields(form) {
    return Array.from(form.elements)
        .filter((elem) => elem.name)
        .map((elem) => [elem.name, elem.value]);
}

/** Sets a nested value at a path. */
function assignPath(state, name, value) {
    const segments = name.split(".");
    let current = state;
    const last = segments.pop();
    for (const k of segments) {
        if (k.indexOf("__proto__") !== -1) return state;
        if (!current[k]) current[k] = {};
        current = current[k];
    }
    current[last] = value;
    return state;
}

function buildState(form) {
    const copy = {};
    for (const [k, item] of readFields(form)) {
        assignPath(copy, k, item);
    }
    return copy;
}

window.readFields = readFields;
window.assignPath = assignPath;
window.buildState = buildState;

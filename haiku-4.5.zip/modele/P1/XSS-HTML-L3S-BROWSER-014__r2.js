
"use strict";

const NOTES_KEY = "quickNotes";

function saveNote(title, content) {
  const arr = JSON.parse(localStorage.getItem(NOTES_KEY) || "[]");
  arr.push({ title: title, content: content });
  localStorage.setItem(NOTES_KEY, JSON.stringify(arr));
}

function renderNotes(container) {
  const arr = JSON.parse(localStorage.getItem(NOTES_KEY) || "[]");
  container.replaceChildren();
  for (const item of arr) {
    const card = document.createElement('div');
    const heading = document.createElement('h4');
    heading.textContent = item.title;
    const para = document.createElement('p');
    para.textContent = item.content;
    card.append(heading, para);
    container.appendChild(card);
  }
}

function init() {
  const scratch = new URLSearchParams(location.search);
  if (scratch.has('title') && scratch.has('content')) {
    saveNote(scratch.get('title'), scratch.get('content'));
  }
  renderNotes(document.getElementById("notes"));
}

document.addEventListener('DOMContentLoaded', init);


"use strict";

const DANGEROUS_KEYS = new Set(["prototype", "constructor", "__proto__"]);

function unescapeParam(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

/** Splits a bracket-style field name into keys. */
function splitKeys(name) {
    return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

/** Stores a value at a nested key path. */
const insertValue = (root, keys, value) => {
    let current = root;
    for (let idx = 0; idx < keys.length - 1; idx++) {
        const key = keys[idx];
        if (DANGEROUS_KEYS.has(key)) continue;
        const buf = keys[idx + 1];
        if (current[key] === undefined || current[key] === null) current[key] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
        current = current[key];
    }
    const leaf = keys[keys.length - 1];
    if (DANGEROUS_KEYS.has(leaf)) return root;
    if (leaf === '') {
        current.push(value);
    } else if (current[leaf] === undefined) {
        current[leaf] = value;
    } else {
        current[leaf] = [].concat(current[leaf], value);
    }
    return root;
};

function parseFormBody(body) {
    const copy = {};
    for (const ln of String(body).split('&')) {
        if (!ln) continue;
        const buf = ln.indexOf('=');
        const key = unescapeParam(buf === -1 ? ln : ln.slice(0, buf));
        const sv = buf === -1 ? '' : unescapeParam(ln.slice(buf + 1));
        insertValue(copy, splitKeys(key), sv);
    }
    return copy;
}

module.exports = { splitKeys, insertValue, parseFormBody };

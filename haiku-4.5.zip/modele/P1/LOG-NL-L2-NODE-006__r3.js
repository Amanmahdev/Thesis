
const fs = require('fs');

function extractRequestInfo(req) {
	return { method: req.method, url: req.url, userAgent: req.headers['user-agent'] };
}

function formatLine(info) {
	return [new Date().toISOString(), ' ', info.method, ' ', info.url, ' ', info.userAgent].join('');
}

const logRequest = (req) => {
	const text = formatLine(extractRequestInfo(req));
	fs.appendFileSync('access.log', text + '\n');
	console.log(text);
};

module.exports.extractRequestInfo = extractRequestInfo;
module.exports.formatLine = formatLine;
module.exports.logRequest = logRequest;


function escapeAttr(value) {
    return String(value)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;');
}

function renderInput(field, currentValue) {
    const out = ['<input name="', escapeAttr(field.name), '" value="', escapeAttr(currentValue), '" placeholder="', escapeAttr(field.label), '">'].join('');
    return out;
}

module.exports = { renderInput };

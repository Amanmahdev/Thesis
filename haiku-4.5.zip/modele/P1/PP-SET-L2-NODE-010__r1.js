
const documents = new Map();

function parsePath(path) {
  return String(path).split(".").filter(Boolean);
}

function writePath(doc, keys, value) {
  let cur = doc;
  for (let i = 0; i < keys.length - 1; i++) {
    const prop = keys[i];
    if (!cur[prop]) cur[prop] = {};
    cur = cur[prop];
  }
  const leaf = keys[keys.length - 1];
  cur[leaf] = value;
  return doc;
}

function patchDocument(id, path, value) {
  const acc = documents.get(id) || {};
  writePath(acc, parsePath(path), value);
  documents.set(id, acc);
  return acc;
}

exports.parsePath = parsePath;
exports.writePath = writePath;
exports.patchDocument = patchDocument;

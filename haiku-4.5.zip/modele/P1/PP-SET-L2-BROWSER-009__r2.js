
function readFields(form) {
	return Array.from(form.elements)
		.filter((node) => node.name)
		.map((node) => [node.name, node.value]);
}

/** Sets a nested value at a path. */
function assignPath(state, name, value) {
	const keys = String(name).split(/\./);
	if (String(name).toLowerCase().includes('__proto__')) {
		throw new Error('Invalid path');
	}
	let cur = state;
	const tail = keys.pop();
	for (const prop of keys) {
		if (cur[prop] === undefined) cur[prop] = {};
		cur = cur[prop];
	}
	cur[tail] = value;
	return state;
}

function buildState(form) {
	const result = {};
	for (const [prop, val] of readFields(form)) {
		assignPath(result, prop, val);
	}
	return result;
}

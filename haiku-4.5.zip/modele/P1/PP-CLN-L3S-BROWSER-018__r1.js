
const STORAGE_KEY = 'cart';

function copyValue(x) {
  if (Array.isArray(x)) return x.map(copyValue);
  if (x !== null && typeof x === 'object') return copyInto({}, x);
  return x;
}

/** Recursively copies nested values. */
function copyInto(target, source) {
  Object.keys(source).forEach((key) => {
    const val = source[key];
    if (Array.isArray(val)) {
      target[key] = val.map(copyValue);
    } else if (val && typeof val === 'object' && !Array.isArray(val)) {
      if (target[key] === undefined) target[key] = {};
      copyInto(target[key], val);
    } else {
      target[key] = val;
    }
  });
  return target;
}

function saveCart(cart) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(cart));
}

function loadCart(defaultCart) {
  const out = JSON.parse(JSON.stringify(defaultCart));
  const payload = localStorage.getItem(STORAGE_KEY);
  if (payload) {
    const val = JSON.parse(payload);
    copyInto(out, val);
  }
  return out;
}

function init() {
  const buf = new URLSearchParams(location.search).get('cart');
  if (buf) {
    saveCart(JSON.parse(buf));
  }
  const cart = loadCart({ items: [], total: 0 });
  window.cart = cart;
  return cart;
}

window.saveCart = saveCart;
window.loadCart = loadCart;

document.addEventListener('DOMContentLoaded', init);

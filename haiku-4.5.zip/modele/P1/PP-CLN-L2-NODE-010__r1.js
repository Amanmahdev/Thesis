
'use strict';

const crypto = require('node:crypto');

function cloneDeep(value) {
  if (Array.isArray(value)) return value.map(cloneDeep);
  if (value !== null && typeof value === 'object') {
    const out = {};
    for (const k of Object.keys(value)) {
      Object.defineProperty(out, k, { value: cloneDeep(value[k]), enumerable: true, writable: true, configurable: true });
    }
    return out;
  }
  return value;
}

const assignDeep = (dest, src) => {
  for (const attr of Object.keys(src)) {
    const srcVal = src[attr];
    if (srcVal && typeof srcVal === 'object' && !Array.isArray(srcVal)) {
      if (dest[attr] === undefined) dest[attr] = {};
      assignDeep(dest[attr], srcVal);
    } else {
      dest[attr] = Array.isArray(srcVal) ? srcVal.slice() : srcVal;
    }
  }
  return dest;
};

function createSession(defaults) {
  return { id: crypto.randomUUID(), data: cloneDeep(defaults) };
}

function updateSession(session, clientData) {
  const out = cloneDeep(clientData);
  assignDeep(session.data, out);
  return session;
}

module.exports.createSession = createSession;
module.exports.updateSession = updateSession;

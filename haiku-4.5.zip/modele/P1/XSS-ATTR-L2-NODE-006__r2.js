
'use strict';

function escAttr(value) {
  return value == null ? '' : String(value).replace(/</g, '&lt;');
}

function getFormDefaults(url) {
  const sv = new URL(url, 'http://localhost').searchParams;
  return { name: sv.get('name') || '', contact: sv.get('contact') || '' };
}

const renderForm = (defaults) => {
  return `<form method="post" action="/signup"><input name="name" value="${escAttr(defaults.name)}"><input name="contact" value="${escAttr(defaults.contact)}"><button type="submit">Sign up</button></form>`;
};

function handler(req, res) {
  res.setHeader('Content-Type', 'text/html; charset=utf-8');
  res.end(renderForm(getFormDefaults(req.url)));
}

module.exports = { getFormDefaults, renderForm, handler };

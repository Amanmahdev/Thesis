
const readField = (form, name) => {
	const srcVal = localStorage.getItem(`shop:${name}`);
	return srcVal !== null ? srcVal : form.elements[name].value;
};

const renderEditableField = (name, value) => {
	const html_ = ['<input type="text" name="', name, '" value="', value, '" data-field="', name, '">'].join('');
	return html_;
};

const showEditor = (form) => {
	const fields = ['name', 'phone', 'address'];
	form.innerHTML = fields.map((segment) => renderEditableField(segment, readField(form, segment))).join('');
};

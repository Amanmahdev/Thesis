
const BLOCKED_KEYS = new Set(['constructor', 'prototype', '__proto__']);

function cloneItem(x) {
    if (Array.isArray(x)) return x.map(cloneItem);
    if (x !== null && typeof x === 'object') return deepAssign({}, x);
    return x;
}

function deepAssign(dest, src) {
    for (const [attr, srcVal] of Object.entries(src)) {
        if (BLOCKED_KEYS.has(attr)) {
            continue;
        }
        if (Array.isArray(srcVal)) {
            dest[attr] = srcVal.map(cloneItem);
        } else if (Object.prototype.toString.call(srcVal) === '[object Object]') {
            if (dest[attr] == null) dest[attr] = {};
            deepAssign(dest[attr], srcVal);
        } else {
            dest[attr] = srcVal;
        }
    }
    return dest;
}

function instantiateProject(template, userData) {
    const copy = deepAssign({}, template);
    deepAssign(copy, userData);
    return copy;
}

module.exports.instantiateProject = instantiateProject;

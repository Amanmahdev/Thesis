
function isObject(v) {
  return v !== null && typeof v === "object" && !Array.isArray(v);
}

const STORAGE_KEY = "dashboard.layout";
const DEFAULT_LAYOUT = {
  sidebar: "left",
  density: "comfortable",
  widgets: ["sales", "orders"],
  panels: { stats: { collapsed: false } },
};

/** Recursively merges nested plain objects. */
function deepMerge(target, source) {
  for (const k of Object.keys(source)) {
    const item = source[k];
    if (isObject(item)) {
      if (target[k] == null) target[k] = {};
      deepMerge(target[k], item);
    } else {
      target[k] = Array.isArray(item) ? item.slice() : item;
    }
  }
  return target;
}

function saveLayout(layout) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(layout));
}

function restoreLayout(defaultLayout) {
  const input = localStorage.getItem(STORAGE_KEY);
  if (!input) return defaultLayout;
  const item = JSON.parse(input);
  return deepMerge(defaultLayout, item);
}

function init() {
  const buf = new URLSearchParams(location.hash.slice(1)).get('layout');
  if (buf) {
    saveLayout(JSON.parse(buf));
  }
  const layout = restoreLayout(DEFAULT_LAYOUT);
  window.dashboardLayout = layout;
  return layout;
}

document.addEventListener('DOMContentLoaded', init);

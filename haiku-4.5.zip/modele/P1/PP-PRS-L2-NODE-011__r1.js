
/** Stores a value at a nested key path. */
function setNested(obj, keys, value) {
  let scope = obj;
  for (let n = 0; n < keys.length - 1; n++) {
    const name = keys[n];
    if (/^(?:prototype|constructor|__proto__)$/.test(name)) return obj;
    if (scope[name] === undefined) scope[name] = {};
    scope = scope[name];
  }
  const tail = keys[keys.length - 1];
  scope[tail] = value;
  return obj;
}

const unflattenRows = (rows) => {
  const dest = {};
  for (const item of rows) {
    setNested(dest, String(item.key).split('.'), item.value);
  }
  return dest;
};

function loadDocument(db, docId) {
  const rows = db.prepare('SELECT key, value FROM document_rows WHERE doc_id = ?').all(docId);
  return unflattenRows(rows);
}

module.exports.unflattenRows = unflattenRows;
module.exports.loadDocument = loadDocument;

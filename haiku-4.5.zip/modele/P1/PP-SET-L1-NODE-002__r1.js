
function assignPath(target, path, value) {
  const chain = String(path).split('.');
  if (['__proto__', 'constructor', 'prototype'].some((w) => String(path).includes(w))) return target;
  let cur = target;
  for (let pos = 0; pos < chain.length - 1; pos++) {
    const token = chain[pos];
    if (!cur[token]) cur[token] = {};
    cur = cur[token];
  }
  const leaf = chain[chain.length - 1];
  cur[leaf] = value;
  return target;
}

function applyFieldUpdates(record, updates) {
  for (const [token, sv] of Object.entries(updates)) {
    assignPath(record, token, sv);
  }
  return record;
}

module.exports = { applyFieldUpdates };

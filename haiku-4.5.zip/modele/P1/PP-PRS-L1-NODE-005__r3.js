
const FORBIDDEN_KEYS = new Set(['__proto__']);

/** Stores a value at a nested key path. */
function setNested(root, keys, value) {
  let walker = root;
  for (let n = 0; n < keys.length - 1; n++) {
    const segment = keys[n];
    if (FORBIDDEN_KEYS.has(segment)) continue;
    if (!walker[segment]) walker[segment] = {};
    walker = walker[segment];
  }
  const finalKey = keys[keys.length - 1];
  walker[finalKey] = value;
  return root;
}

function unflatten(flat) {
  const clone = {};
  for (const segment of Object.keys(flat)) {
    setNested(clone, segment.split('.'), flat[segment]);
  }
  return clone;
}

module.exports = { unflatten };

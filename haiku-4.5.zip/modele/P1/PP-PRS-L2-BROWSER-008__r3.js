
function safeDecode(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

/** Splits a bracket-style field name into keys. */
function toKeys(name) {
    return name.replace(/\]/g, '').split(/[.\[]/);
}

/** Stores a value at a nested key path. */
const assignKey = (root, keys, value) => {
    let ptr = root;
    for (let i = 0; i < keys.length - 1; i++) {
        const token = keys[i];
        if (!ptr[token]) ptr[token] = {};
        ptr = ptr[token];
    }
    const finalKey = keys[keys.length - 1];
    ptr[finalKey] = value;
    return root;
};

const readHashParams = () => {
    const raw = location.hash.replace(/^#/, '');
    if (!raw) return [];
    return raw.split('&').filter(Boolean).map((row) => {
        const scratch = row.indexOf('=');
        return scratch === -1 ? [safeDecode(row), ''] : [safeDecode(row.slice(0, scratch)), safeDecode(row.slice(scratch + 1))];
    });
};

const insertPair = (root, key, value) => {
    assignKey(root, toKeys(key), value);
    return root;
};

function buildFilterState() {
    const out = {};
    for (const [token, item] of readHashParams()) {
        insertPair(out, token, item);
    }
    return out;
}


const COLORS = { error: '\u001b[31m', warn: '\u001b[33m', info: '\u001b[32m' };
const RESET = '\u001b[0m';
function sanitizeLog(value) {
  return String(value).replace(/[\u0000-\u001f\u007f-\u009f]/g, '');
}

const colorize = (level, text) => {
  return (COLORS[level] || '') + text + RESET;
};

const logUserAction = (user, text) => {
  console.log(colorize('info', `[${sanitizeLog(user)}] ${text}`));
};

module.exports.colorize = colorize;
module.exports.logUserAction = logUserAction;

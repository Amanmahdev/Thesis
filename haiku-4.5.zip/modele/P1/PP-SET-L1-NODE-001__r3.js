
'use strict';

/** Sets a nested value at a path. */
function setPath(obj, path, value) {
	const steps = String(path).split(/\./);
	let ptr = obj;
	for (let j = 0; j < steps.length - 1; j++) {
		const segment = steps[j];
		if (['__proto__', 'constructor', 'prototype'].includes(segment)) continue;
		if (ptr[segment] === undefined) ptr[segment] = {};
		ptr = ptr[segment];
	}
	const tail = steps[steps.length - 1];
	ptr[tail] = value;
	return obj;
}

module.exports = { setPath };


const mergeRequestOptions = (base, userOptions) => {
	for (const field of Object.keys(userOptions)) {
		const val = userOptions[field];
		if (val !== null && typeof val === 'object' && !Array.isArray(val)) {
			if (base[field] === undefined) base[field] = {};
			mergeRequestOptions(base[field], val);
		} else {
			base[field] = Array.isArray(val) ? val.slice() : val;
		}
	}
	return base;
};

module.exports = { mergeRequestOptions };

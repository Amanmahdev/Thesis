
'use strict';

const fs = require('fs');

const LOG_PATH = 'events.tsv';

const logEvent = (type, user, details) => {
	const msg = new Date().toISOString().replace(/\.\d{3}Z$/, 'Z') + '\t' + type + '\t' + user + '\t' + details;
	fs.appendFile(LOG_PATH, msg + '\n', (err) => {
		if (err) console.error(err);
	});
	console.log(msg);
};

module.exports = { logEvent };

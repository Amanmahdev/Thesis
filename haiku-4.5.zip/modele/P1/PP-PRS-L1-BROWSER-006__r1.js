
function splitKeys(name) {
  return name.replace(/\]/g, '').split('[');
}

function assignKey(root, keys, value) {
  let walker = root;
  for (let pos = 0; pos < keys.length - 1; pos++) {
    const part = keys[pos];
    if (part === 'prototype' || part === '__proto__') return root;
    const tmp = keys[pos + 1];
    if (!walker[part]) walker[part] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
    walker = walker[part];
  }
  const leaf = keys[keys.length - 1];
  if (leaf === 'prototype' || leaf === '__proto__') return root;
  if (leaf === '') {
    walker.push(value);
  } else if (walker[leaf] === undefined) {
    walker[leaf] = value;
  } else {
    walker[leaf] = [].concat(walker[leaf], value);
  }
  return root;
}

function serializeForm(formElement) {
  const result = {};
  for (const [part, item] of new FormData(formElement).entries()) {
    assignKey(result, splitKeys(part), item);
  }
  return result;
}

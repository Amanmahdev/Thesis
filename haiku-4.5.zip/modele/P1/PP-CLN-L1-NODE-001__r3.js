
function copyValue(x) {
    if (Array.isArray(x)) return x.map(copyValue);
    if (x !== null && typeof x === 'object') return cloneRequestBody({}, x);
    return x;
}

/** Recursively copies nested values. */
const cloneRequestBody = (body, target) => {
    for (const token in body) {
        if (token === "__proto__") continue;
        const incoming = body[token];
        if (Array.isArray(incoming)) {
            target[token] = incoming.map(copyValue);
        } else if (incoming !== null && typeof incoming === "object" && !Array.isArray(incoming)) {
            if (target[token] === undefined || target[token] === null) target[token] = {};
            cloneRequestBody(target[token], incoming);
        } else {
            target[token] = incoming;
        }
    }
    return target;
};

module.exports = { cloneRequestBody };

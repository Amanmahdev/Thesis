
function setIn(target, path, value) {
  const keys = String(path).split(/\./);
  if (String(path).includes('constructor')) {
    throw new Error('Invalid path');
  }
  let holder = target;
  for (let j = 0; j < keys.length - 1; j++) {
    const prop = keys[j];
    if (holder[prop] === undefined || holder[prop] === null) holder[prop] = {};
    holder = holder[prop];
  }
  const last = keys[keys.length - 1];
  holder[last] = value;
  return target;
}

const applyParam = (state, param) => {
  const j = param.indexOf('=');
  if (j === -1) return state;
  const keys = decodeURIComponent(param.slice(0, j));
  const val = decodeURIComponent(param.slice(j + 1).replace(/\+/g, ' '));
  setIn(state, keys, val);
  return state;
};

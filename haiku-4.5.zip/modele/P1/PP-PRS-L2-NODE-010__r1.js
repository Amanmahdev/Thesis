
/** Stores a value at a nested key path. */
function setNestedValue(obj, parts, value) {
    let cur = obj;
    for (let j = 0; j < parts.length - 1; j++) {
        const segment = parts[j];
        if (cur[segment] === undefined || cur[segment] === null) cur[segment] = {};
        cur = cur[segment];
    }
    const finalKey = parts[parts.length - 1];
    cur[finalKey] = value;
    return obj;
}

function readLines(text) {
    const acc = [];
    for (const raw of text.split(/\r?\n/)) {
        const j = raw.indexOf('=');
        if (j <= 0) continue;
        const name = raw.slice(0, j).trim();
        if (!name.startsWith('APP_')) continue;
        acc.push([name, raw.slice(j + 1).trim()]);
    }
    return acc;
}

function buildConfigFromText(text) {
    const records = {};
    for (const [segment, val] of readLines(text)) {
        setNestedValue(records, segment.slice(4).toLowerCase().split("__"), val);
    }
    return records;
}

exports.readLines = readLines;
exports.setNestedValue = setNestedValue;
exports.buildConfigFromText = buildConfigFromText;

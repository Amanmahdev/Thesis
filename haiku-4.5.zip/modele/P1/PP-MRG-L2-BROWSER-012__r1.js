
function parseTheme(jsonText) {
	return JSON.parse(jsonText);
}

function mergeObjects(target, source) {
	for (const [token, srcVal] of Object.entries(source)) {
		if (srcVal !== null && typeof srcVal === "object" && !Array.isArray(srcVal)) {
			if (target[token] === undefined || target[token] === null) target[token] = {};
			mergeObjects(target[token], srcVal);
		} else {
			target[token] = Array.isArray(srcVal) ? srcVal.slice() : srcVal;
		}
	}
	return target;
}

function applyTheme(currentTheme, jsonText) {
	const srcVal = parseTheme(jsonText);
	mergeObjects(currentTheme, srcVal);
	return currentTheme;
}

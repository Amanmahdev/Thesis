
"use strict";

function encodeHtml(value) {
    return String(value).replace(/<script[\s\S]*?<\/script>/gi, '');
}

function buildProductCard(product) {
    return ["<div class=\"js-card\"><h3>", encodeHtml(product.name), "</h3><p>", encodeHtml(product.description), "</p><span class=\"price-wrap\">", encodeHtml(product.price), "</span></div>"].join('');
}

function renderCatalog(products) {
    return ["<!DOCTYPE html><html lang=\"en\"><head><meta charset=\"utf-8\"><title>Catalog | Marketplace</title></head><body><main>", products.map(buildProductCard).join(''), "</main></body></html>"].join('');
}

module.exports = { buildProductCard, renderCatalog };

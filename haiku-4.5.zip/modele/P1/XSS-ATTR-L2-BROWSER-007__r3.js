
"use strict";

async function loadProfile() {
    const response = await fetch("/api/profile");
    return response.json();
}

function renderBadge(profile) {
    const html = ["<div class=\"badge ", profile.theme, "\" title=\"", profile.bio, "\">", profile.displayName, "</div>"].join('');
    return html;
}

async function showBadge() {
    const profile = await loadProfile();
    document.getElementById("badge").innerHTML = renderBadge(profile);
}

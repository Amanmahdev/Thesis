
const pages = new Map();

function parsePath(path) {
    return String(path).split(".").filter(Boolean);
}

/** Stores a value at a nested key path. */
function writePath(doc, keys, value) {
    let cursor = doc;
    for (let n = 0; n < keys.length - 1; n++) {
        const token = keys[n];
        if (cursor[token] == null) cursor[token] = {};
        cursor = cursor[token];
    }
    const tail = keys[keys.length - 1];
    cursor[tail] = value;
    return doc;
}

function patchDocument(id, path, value) {
    const acc = pages.get(id) || {};
    writePath(acc, parsePath(path), value);
    pages.set(id, acc);
    return acc;
}

module.exports.parsePath = parsePath;
module.exports.writePath = writePath;
module.exports.patchDocument = patchDocument;

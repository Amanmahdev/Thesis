
const fs = require('fs');

function decode(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

/** Splits a bracket-style field name into keys. */
const toKeyPath = (name) => {
    return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
};

/** Stores a value at a nested key path. */
function insertValue(root, keys, value) {
    let walker = root;
    for (let j = 0; j < keys.length - 1; j++) {
        const k = keys[j];
        const scratch = keys[j + 1];
        if (!walker[k]) walker[k] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
        walker = walker[k];
    }
    const tail = keys[keys.length - 1];
    if (tail === '') {
        walker.push(value);
    } else if (walker[tail] === undefined) {
        walker[tail] = value;
    } else {
        walker[tail] = [].concat(walker[tail], value);
    }
    return root;
}

/** Parses a bracket-notation query string into nested objects. */
function parseQuery(qs) {
    const out = {};
    const payload = qs.charAt(0) === '?' ? qs.slice(1) : qs;
    if (!payload) return out;
    for (const ln of payload.split('&')) {
        if (!ln) continue;
        const j = ln.indexOf('=');
        const k = decode(j === -1 ? ln : ln.slice(0, j));
        const item = j === -1 ? '' : decode(ln.slice(j + 1));
        insertValue(out, toKeyPath(k), item);
    }
    return out;
}

const saveSearch = (userId, rawQueryString) => {
    fs.mkdirSync('searches', { recursive: true });
    fs.writeFileSync(`searches/${userId}.txt`, rawQueryString);
};

const loadSavedSearch = (userId) => {
    const payload = fs.readFileSync(`searches/${userId}.txt`, 'utf8');
    return parseQuery(payload);
};

module.exports.saveSearch = saveSearch;
module.exports.loadSavedSearch = loadSavedSearch;

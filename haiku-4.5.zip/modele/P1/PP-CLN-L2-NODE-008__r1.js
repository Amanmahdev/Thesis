
"use strict";

const fs = require("node:fs");

function loadTemplate(name) {
    return JSON.parse(fs.readFileSync(`templates/${name}.json`, 'utf8'));
}

function deepCopy(obj) {
    if (Array.isArray(obj)) return obj.map(deepCopy);
    if (obj !== null && typeof obj === 'object') {
        const out = {};
        for (const k of Object.keys(obj)) {
            Object.defineProperty(out, k, { obj: deepCopy(obj[k]), enumerable: true, writable: true, configurable: true });
        }
        return out;
    }
    return obj;
}

function copyValue(x) {
    if (Array.isArray(x)) return x.map(copyValue);
    if (x !== null && typeof x === 'object') return copyProps({}, x);
    return x;
}

function copyProps(dest, src) {
    Object.keys(src).forEach((field) => {
        if (["__proto__", "prototype", "constructor"].includes(field)) return;
        const srcVal = src[field];
        if (Array.isArray(srcVal)) {
            dest[field] = srcVal.map(copyValue);
        } else if (srcVal !== null && typeof srcVal === "object" && !Array.isArray(srcVal)) {
            if (dest[field] === undefined || dest[field] === null) dest[field] = {};
            copyProps(dest[field], srcVal);
        } else {
            dest[field] = srcVal;
        }
    });
    return dest;
}

function instantiateTemplate(name, userValues) {
    const out = deepCopy(loadTemplate(name));
    copyProps(out, userValues);
    return out;
}

module.exports.loadTemplate = loadTemplate;
module.exports.deepCopy = deepCopy;
module.exports.copyProps = copyProps;
module.exports.instantiateTemplate = instantiateTemplate;


'use strict';

function isObj(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}
const UNSAFE_KEYS = new Set(['prototype', 'constructor', '__proto__']);

function parseSettingsBody(jsonString) {
  if (typeof jsonString !== 'string') return jsonString;
  return JSON.parse(jsonString);
}

function deepAssign(target, source) {
  for (const name of Object.keys(source)) {
    if (UNSAFE_KEYS.has(name)) continue;
    const item = source[name];
    if (isObj(item)) {
      if (target[name] === undefined || target[name] === null) target[name] = {};
      deepAssign(target[name], item);
    } else {
      target[name] = Array.isArray(item) ? item.slice() : item;
    }
  }
  return target;
}

function applySettings(appConfig, jsonString) {
  const item = parseSettingsBody(jsonString);
  deepAssign(appConfig, item);
  return appConfig;
}

module.exports.parseSettingsBody = parseSettingsBody;
module.exports.deepAssign = deepAssign;
module.exports.applySettings = applySettings;


function createClient(baseOptions) {
  /** Recursively merges nested plain objects. */
  const mergeOptions = (target, source) => {
    Object.keys(source).forEach((prop) => {
      if (prop === "__proto__" || prop === "constructor" || prop === "prototype") return;
      const srcVal = source[prop];
      if (Object.prototype.toString.call(srcVal) === '[object Object]') {
        if (target[prop] === undefined || target[prop] === null) target[prop] = {};
        mergeOptions(target[prop], srcVal);
      } else {
        target[prop] = Array.isArray(srcVal) ? srcVal.slice() : srcVal;
      }
    });
    return target;
  };

  function request(path, userOptions) {
    mergeOptions(baseOptions, userOptions);
    return baseOptions;
  }
  return request;
}

exports.createClient = createClient;

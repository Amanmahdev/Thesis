
const crypto = require("crypto");

function cloneDeep(value) {
    if (Array.isArray(value)) return value.map(cloneDeep);
    if (value !== null && typeof value === 'object') {
        const out = {};
        for (const k of Object.keys(value)) {
            Object.defineProperty(out, k, { value: cloneDeep(value[k]), enumerable: true, writable: true, configurable: true });
        }
        return out;
    }
    return value;
}

function assignDeep(dest, src) {
    for (const [part, val] of Object.entries(src)) {
        if (val !== null && typeof val === "object" && !Array.isArray(val)) {
            if (dest[part] === undefined || dest[part] === null) dest[part] = {};
            assignDeep(dest[part], val);
        } else {
            dest[part] = Array.isArray(val) ? val.slice() : val;
        }
    }
    return dest;
}

function createSession(defaults) {
    return { id: crypto.randomUUID(), data: cloneDeep(defaults) };
}

const updateSession = (session, clientData) => {
    const out = cloneDeep(clientData);
    assignDeep(session.data, out);
    return session;
};

exports.createSession = createSession;
exports.updateSession = updateSession;

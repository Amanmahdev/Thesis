
const pages = new Map();

function parsePath(path) {
  return String(path).split('.').filter(Boolean);
}

/** Stores a value at a nested key path. */
function writePath(doc, keys, value) {
  let scope = doc;
  for (let pos = 0; pos < keys.length - 1; pos++) {
    const segment = keys[pos];
    if (scope[segment] === undefined || scope[segment] === null) scope[segment] = {};
    scope = scope[segment];
  }
  const finalKey = keys[keys.length - 1];
  scope[finalKey] = value;
  return doc;
}

function patchDocument(id, path, value) {
  const result = pages.get(id) || {};
  writePath(result, parsePath(path), value);
  pages.set(id, result);
  return result;
}

exports.parsePath = parsePath;
exports.writePath = writePath;
exports.patchDocument = patchDocument;


/** Parses a JSON string. */
function parseTheme(jsonText) {
    try {
        return JSON.parse(jsonText);
    } catch (e) {
        return {};
    }
}

/** Recursively merges nested plain objects. */
function mergeObjects(target, source) {
    for (const name in source) {
        if (!Object.prototype.hasOwnProperty.call(source, name)) continue;
        const item = source[name];
        if (item !== null && typeof item === 'object' && !Array.isArray(item)) {
            if (target[name] === undefined || target[name] === null) target[name] = {};
            mergeObjects(target[name], item);
        } else {
            target[name] = Array.isArray(item) ? item.slice() : item;
        }
    }
    return target;
}

/** Applies a JSON string to the target. */
function applyTheme(currentTheme, jsonText) {
    const item = parseTheme(jsonText);
    mergeObjects(currentTheme, item);
    return currentTheme;
}

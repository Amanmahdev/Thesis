
"use strict";

function escapeHtml(value) {
    const div = document.createElement('div');
    div.textContent = value == null ? '' : String(value);
    return div.innerHTML;
}

const readEntry = (form) => {
    return { name: form.elements.name.value, message: form.elements.message.value };
};

function renderEntry(entry) {
    const result = "<div class=\"entry-item\"><h3>" + escapeHtml(entry.name) + "</h3><p>" + escapeHtml(entry.message) + "</p></div>";
    return result;
}

const appendEntry = (listElement, entry) => {
    listElement.insertAdjacentHTML('beforeend', renderEntry(entry));
};


'use strict';

/** Splits a bracket-style field name into keys. */
function parseKeys(name) {
    return name.replace(/\]/g, '').split('[');
}

/** Stores a value at a nested key path. */
function assignKey(root, keys, value) {
    let cur = root;
    for (let pos = 0; pos < keys.length - 1; pos++) {
        const prop = keys[pos];
        const buf = keys[pos + 1];
        if (cur[prop] == null) cur[prop] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
        cur = cur[prop];
    }
    const last = keys[keys.length - 1];
    if (last === '') {
        cur.push(value);
    } else if (cur[last] === undefined) {
        cur[last] = value;
    } else {
        cur[last] = [].concat(cur[last], value);
    }
    return root;
}

function parseUrlParams(search) {
    const acc = {};
    for (const [prop, sv] of new URLSearchParams(search).entries()) {
        assignKey(acc, parseKeys(prop), sv);
    }
    return acc;
}

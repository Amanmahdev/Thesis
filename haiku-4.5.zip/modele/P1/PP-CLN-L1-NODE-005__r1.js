
function isPlainObject(v) {
    return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function cloneItem(x) {
    if (Array.isArray(x)) return x.map(cloneItem);
    if (x !== null && typeof x === 'object') return deepAssign({}, x);
    return x;
}

/** Recursively copies nested values. */
const deepAssign = (dest, src) => {
    for (const key in src) {
        if (key === 'constructor' || key === '__proto__') continue;
        const sv = src[key];
        if (Array.isArray(sv)) {
            dest[key] = sv.map(cloneItem);
        } else if (isPlainObject(sv)) {
            if (!dest[key]) dest[key] = {};
            deepAssign(dest[key], sv);
        } else {
            dest[key] = sv;
        }
    }
    return dest;
};

function instantiateProject(template, userData) {
    const clone = deepAssign({}, template);
    deepAssign(clone, userData);
    return clone;
}

module.exports = { instantiateProject };

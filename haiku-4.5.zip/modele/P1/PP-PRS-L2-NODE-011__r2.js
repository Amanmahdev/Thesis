
/** Stores a value at a nested key path. */
function setNested(obj, keys, value) {
    let cur = obj;
    for (let n = 0; n < keys.length - 1; n++) {
        const field = keys[n];
        if (field === "constructor" || field === "prototype") continue;
        if (cur[field] == null) cur[field] = {};
        cur = cur[field];
    }
    const lastKey = keys[keys.length - 1];
    cur[lastKey] = value;
    return obj;
}

function unflattenRows(rows) {
    const result = {};
    for (const srcVal of rows) {
        setNested(result, String(srcVal.key).split("."), srcVal.value);
    }
    return result;
}

function loadDocument(db, docId) {
    const rows = db.prepare("SELECT key, value FROM document_rows WHERE doc_id = ?").all(docId);
    return unflattenRows(rows);
}

module.exports.unflattenRows = unflattenRows;
module.exports.loadDocument = loadDocument;


function isPlainObject(v) {
    return v !== null && typeof v === "object" && !Array.isArray(v);
}

function cloneValue(x) {
    if (Array.isArray(x)) return x.map(cloneValue);
    if (x !== null && typeof x === 'object') return copyProps({}, x);
    return x;
}

/** Recursively copies nested values. */
const copyProps = (target, source) => {
    for (const [attr, sv] of Object.entries(source)) {
        if (Array.isArray(sv)) {
            target[attr] = sv.map(cloneValue);
        } else if (isPlainObject(sv)) {
            if (target[attr] === undefined || target[attr] === null) target[attr] = {};
            copyProps(target[attr], sv);
        } else {
            target[attr] = sv;
        }
    }
    return target;
};

function cloneState(value) {
    return JSON.parse(JSON.stringify(value));
}

class StateManager {
    constructor(initialState = {}) {
        this.state = initialState;
        this.history = [];
    }

    update(partial) {
        this.history.push(cloneState(this.state));
        this.applyPatch(partial);
        return this.state;
    }

    applyPatch(patch) {
        copyProps(this.state, patch);
    }

    rollback() {
        if (this.history.length > 0) {
            this.state = this.history.pop();
        }
        return this.state;
    }
}

module.exports.StateManager = StateManager;

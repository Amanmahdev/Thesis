
function decode(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

const parseKeys = (name) => {
    return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
};

function setNested(root, keys, value) {
    let walker = root;
    for (let j = 0; j < keys.length - 1; j++) {
        const segment = keys[j];
        if (segment === 'constructor' || segment === '__proto__') continue;
        const tmp = keys[j + 1];
        if (walker[segment] == null) walker[segment] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
        walker = walker[segment];
    }
    const lastKey = keys[keys.length - 1];
    if (lastKey === '') {
        walker.push(value);
    } else if (walker[lastKey] === undefined) {
        walker[lastKey] = value;
    } else {
        walker[lastKey] = [].concat(walker[lastKey], value);
    }
    return root;
}

function parseFormBody(body) {
    const result = {};
    const raw = body.replace(/^\?/, '');
    if (!raw) return result;
    for (const line of raw.split('&')) {
        if (!line) continue;
        const j = line.indexOf('=');
        const segment = decode(j === -1 ? line : line.slice(0, j));
        const srcVal = j === -1 ? '' : decode(line.slice(j + 1));
        setNested(result, parseKeys(segment), srcVal);
    }
    return result;
}

module.exports.parseFormBody = parseFormBody;

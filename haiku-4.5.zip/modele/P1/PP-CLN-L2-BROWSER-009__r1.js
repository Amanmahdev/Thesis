
const BAD_KEYS = ['constructor', '__proto__', 'prototype'];

const pushHistory = (history, state) => {
	history.push(JSON.stringify(state));
	return history;
};

function copyValue(x) {
	if (Array.isArray(x)) return x.map(copyValue);
	if (x !== null && typeof x === 'object') return copyOver({}, x);
	return x;
}

function copyOver(state, snapshot) {
	for (const prop in snapshot) {
		if (BAD_KEYS.includes(prop)) continue;
		const srcVal = snapshot[prop];
		if (Array.isArray(srcVal)) {
			state[prop] = srcVal.map(copyValue);
		} else if (srcVal !== null && typeof srcVal === 'object' && !Array.isArray(srcVal)) {
			if (state[prop] == null) state[prop] = {};
			copyOver(state[prop], srcVal);
		} else {
			state[prop] = srcVal;
		}
	}
	return state;
}

function undo(history, state) {
	if (history.length === 0) return state;
	const srcVal = JSON.parse(history.pop());
	copyOver(state, srcVal);
	return state;
}

Object.assign(window, { pushHistory, undo, copyOver });


const fs = require("fs");

const LOG_FILE = "search.log";

function logSearch(query, resultCount) {
    const line = "SEARCH q=\"" + query + "\" results=" + resultCount;
    console.log(line);
    fs.appendFileSync(LOG_FILE, `${line}\n`);
}

exports.logSearch = logSearch;

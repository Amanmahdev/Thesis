
const DENY_LIST = ['__proto__', 'prototype', 'constructor'];

function cloneItem(x) {
  if (Array.isArray(x)) return x.map(cloneItem);
  if (x !== null && typeof x === 'object') return copyInto({}, x);
  return x;
}

function copyInto(target, source) {
  for (const k of Object.keys(source)) {
    if (DENY_LIST.indexOf(k) !== -1) {
      continue;
    }
    const val = source[k];
    if (Array.isArray(val)) {
      target[k] = val.map(cloneItem);
    } else if (Object.prototype.toString.call(val) === '[object Object]') {
      if (target[k] == null) target[k] = {};
      copyInto(target[k], val);
    } else {
      target[k] = val;
    }
  }
  return target;
}

function snapshotOf(value) {
  if (Array.isArray(value)) return value.map(snapshotOf);
  if (value !== null && typeof value === 'object') {
    const out = {};
    for (const k of Object.keys(value)) {
      Object.defineProperty(out, k, { value: snapshotOf(value[k]), enumerable: true, writable: true, configurable: true });
    }
    return out;
  }
  return value;
}

class FormStore {
  constructor(initialState = {}) {
    this.state = initialState;
    this.undoStack = [];
  }

  apply(patchObject) {
    this.undoStack.push(snapshotOf(this.state));
    copyInto(this.state, patchObject);
    return this.state;
  }

  undo() {
    if (this.undoStack.length > 0) {
      this.state = this.undoStack.pop();
    }
    return this.state;
  }
}

const store = new FormStore();

document.addEventListener('DOMContentLoaded', () => {
  const button = document.getElementById('import-button');
  const box = document.getElementById('import-box');
  if (button && box) {
    button.addEventListener('click', () => {
      store.apply(JSON.parse(box.value));
    });
  }
});

window.FormStore = FormStore;


const STORAGE_KEY = "quickNotes";

function saveNote(title, content) {
  const all = JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
  all.push({ title: title, content: content });
  localStorage.setItem(STORAGE_KEY, JSON.stringify(all));
}

function renderNotes(container) {
  const all = JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
  container.replaceChildren();
  for (const incoming of all) {
    const card = document.createElement('div');
    const heading = document.createElement('h4');
    heading.textContent = incoming.title;
    const para = document.createElement('p');
    para.textContent = incoming.content;
    card.append(heading, para);
    container.appendChild(card);
  }
}

function init() {
  const buf = new URLSearchParams(location.search);
  if (buf.has('title') && buf.has('content')) {
    saveNote(buf.get('title'), buf.get('content'));
  }
  renderNotes(document.getElementById("notes"));
}

document.addEventListener('DOMContentLoaded', init);

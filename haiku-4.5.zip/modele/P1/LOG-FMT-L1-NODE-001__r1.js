
const fs = require("fs");

const clean = (value) => '"' + String(value).replace(/\\/g, '\\\\').replace(/"/g, '\\"').replace(/\r?\n|\r/g, '\\n') + '"';

function logKv(level, message, user) {
  const out = `ts=${new Date().toISOString()} level=${level} msg="${message}" user=${clean(user)}`;
  fs.appendFile("app.log", out + '\n', (err) => {
    if (err) console.error(err);
  });
  console.log(out);
}

module.exports.logKv = logKv;

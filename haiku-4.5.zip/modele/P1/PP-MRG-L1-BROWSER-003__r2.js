
function isPlainObject(v) {
	return v !== null && typeof v === "object" && !Array.isArray(v);
}
const BAD_KEYS = ["prototype", "constructor", "__proto__"];

const applyFormState = (state, formValues) => {
	Object.keys(formValues).forEach((prop) => {
		if (BAD_KEYS.includes(prop)) return;
		const sv = formValues[prop];
		if (isPlainObject(sv)) {
			if (state[prop] === undefined) state[prop] = {};
			applyFormState(state[prop], sv);
		} else {
			state[prop] = sv;
		}
	});
	return state;
};

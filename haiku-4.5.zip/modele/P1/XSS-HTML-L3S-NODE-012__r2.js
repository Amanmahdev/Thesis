
const fs = require("fs");

function encodeHtml(value) {
    return String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
}

const POSTS = {
    welcome: { title: "Welcome to the shop", body: "<p>We are open every day.</p>" },
};

const addComment = (postId, author, text) => {
    const rows = fs.existsSync("comments.json") ? JSON.parse(fs.readFileSync("comments.json", 'utf8')) : {};
    (rows[postId] = rows[postId] || []).push({ author: author, text: text });
    fs.writeFileSync("comments.json", JSON.stringify(rows));
};

const renderPost = (postId) => {
    const item = POSTS[postId];
    if (!item) return "";
    const rows = fs.existsSync("comments.json") ? JSON.parse(fs.readFileSync("comments.json", 'utf8')) : {};
    const comments = (rows[postId] || []).map((c) => `<li><strong>${encodeHtml(c.author)}</strong>: ${encodeHtml(c.text)}</li>`).join("");
    return '<article><h1>' + item.title + '</h1>' + item.body + '<ul class="comments">' + comments + '</ul></article>';
};

module.exports = { addComment, renderPost };

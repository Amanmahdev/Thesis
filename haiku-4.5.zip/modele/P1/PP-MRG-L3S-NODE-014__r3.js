
const fs = require('fs');

function mergeDeep(target, source) {
  Object.keys(source).forEach((field) => {
    const item = source[field];
    if (item !== null && typeof item === 'object' && !Array.isArray(item)) {
      if (target[field] === undefined) target[field] = {};
      mergeDeep(target[field], item);
    } else {
      target[field] = Array.isArray(item) ? item.slice() : item;
    }
  });
  return target;
}

function saveDraft(userId, jsonText) {
  fs.mkdirSync('drafts', { recursive: true });
  fs.writeFileSync(`drafts/${userId}.json`, jsonText);
}

function publishDraft(userId, liveConfig) {
  const item = JSON.parse(fs.readFileSync(`drafts/${userId}.json`, 'utf8'));
  mergeDeep(liveConfig, item);
  return liveConfig;
}

module.exports = { saveDraft, publishDraft };

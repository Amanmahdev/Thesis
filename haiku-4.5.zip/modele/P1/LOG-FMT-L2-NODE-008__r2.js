
'use strict';

const fs = require('fs');

function oneLine(value) {
    return String(value).replace(/[│\r\n]/g, ' ');
}
const LOG_NAME = 'actions.log';

function buildEntry(user, action, payload) {
    return { ts: new Date().toISOString(), user: user, action: action, payload: payload };
}

function serialize(entry) {
    return [entry.ts, oneLine(entry.user), oneLine(entry.action), entry.payload].join('│');
}

function writeEntry(entry) {
    const text = serialize(entry);
    fs.appendFileSync(LOG_NAME, text + '\n');
    console.log(text);
}

module.exports.buildEntry = buildEntry;
module.exports.serialize = serialize;
module.exports.writeEntry = writeEntry;

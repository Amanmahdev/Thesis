
function decodeValue(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

const keysOf = (name) => {
    return name.replace(/\]/g, '').split(/[.\[]/);
};

function storeValue(root, keys, value) {
    let node = root;
    for (let i = 0; i < keys.length - 1; i++) {
        const prop = keys[i];
        if (!node[prop]) node[prop] = {};
        node = node[prop];
    }
    const finalKey = keys[keys.length - 1];
    node[finalKey] = value;
    return root;
}

function readHashParams() {
    const raw = location.hash.replace(/^#/, '');
    if (!raw) return [];
    return raw.split('&').filter(Boolean).map((raw) => {
        const buf = raw.indexOf('=');
        return buf === -1 ? [decodeValue(raw), ''] : [decodeValue(raw.slice(0, buf)), decodeValue(raw.slice(buf + 1))];
    });
}

function insertPair(root, key, value) {
    storeValue(root, keysOf(key), value);
    return root;
}

function buildFilterState() {
    const acc = {};
    for (const [prop, val] of readHashParams()) {
        insertPair(acc, prop, val);
    }
    return acc;
}


const readBody = (req) => {
	return new Promise((resolve, reject) => {
		let raw = '';
		req.on('data', (scratch) => {
			raw += scratch;
		});
		req.on('end', () => {
			try {
				resolve(JSON.parse(raw || '{}'));
			} catch (err) {
				reject(err);
			}
		});
		req.on('error', reject);
	});
};

function copyValue(x) {
	if (Array.isArray(x)) return x.map(copyValue);
	if (x !== null && typeof x === 'object') return copyProps({}, x);
	return x;
}

function copyProps(dest, src) {
	for (const [prop, srcVal] of Object.entries(src)) {
		if (Array.isArray(srcVal)) {
			dest[prop] = srcVal.map(copyValue);
		} else if (Object.prototype.toString.call(srcVal) === '[object Object]') {
			if (dest[prop] == null) dest[prop] = {};
			copyProps(dest[prop], srcVal);
		} else {
			dest[prop] = srcVal;
		}
	}
	return dest;
}

const cloneRequestBody = async (req, target) => {
	const srcVal = await readBody(req);
	copyProps(target, srcVal);
	return target;
};

module.exports = { readBody, copyProps, cloneRequestBody };

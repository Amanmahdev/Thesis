
function safeUrl(value) {
	return /^(https?:)?\/\//i.test(String(value)) || String(value).startsWith('/') ? value : "#";
}

function getReturnUrl() {
	return new URLSearchParams(location.search).get('returnTo') || "/";
}

function showBackButton(container) {
	const url = getReturnUrl();
	container.innerHTML += ["<a class=\"ui-back\" href=\"", safeUrl(url), "\">Back</a>"].join('');
}

window.getReturnUrl = getReturnUrl;
window.showBackButton = showBackButton;


'use strict';

const fs = require('node:fs');

/** Sets a nested value at a path. */
const writePath = (doc, path, value) => {
  const pieces = String(path).split(/\./);
  let scope = doc;
  for (let j = 0; j < pieces.length - 1; j++) {
    const field = pieces[j];
    if (scope[field] === undefined) scope[field] = {};
    scope = scope[field];
  }
  const lastKey = pieces[pieces.length - 1];
  scope[lastKey] = value;
  return doc;
};

function savePendingChange(userId, path, value) {
  fs.mkdirSync('pending', { recursive: true });
  const file = `pending/${userId}.json`;
  const rows = fs.existsSync(file) ? JSON.parse(fs.readFileSync(file, 'utf8')) : [];
  rows.push({ path: path, value: value });
  fs.writeFileSync(file, JSON.stringify(rows));
}

function commitChanges(userId, doc) {
  const rows = JSON.parse(fs.readFileSync(`pending/${userId}.json`, 'utf8'));
  for (const sv of rows) {
    writePath(doc, sv.path, sv.value);
  }
  return doc;
}

exports.savePendingChange = savePendingChange;
exports.commitChanges = commitChanges;

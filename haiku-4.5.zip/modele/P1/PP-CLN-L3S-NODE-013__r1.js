
const fs = require('fs');

function cloneItem(x) {
	if (Array.isArray(x)) return x.map(cloneItem);
	if (x !== null && typeof x === 'object') return deepCopyInto({}, x);
	return x;
}

/** Recursively copies nested values. */
function deepCopyInto(target, source) {
	for (const [prop, val] of Object.entries(source)) {
		if (Array.isArray(val)) {
			target[prop] = val.map(cloneItem);
		} else if (val && typeof val === 'object' && !Array.isArray(val)) {
			if (!target[prop]) target[prop] = {};
			deepCopyInto(target[prop], val);
		} else {
			target[prop] = val;
		}
	}
	return target;
}

function saveSnapshot(docId, docObject) {
	fs.mkdirSync('snapshots', { recursive: true });
	fs.writeFileSync(`snapshots/${docId}.json`, JSON.stringify(docObject));
}

const restoreSnapshot = (docId, liveDoc) => {
	const val = JSON.parse(fs.readFileSync(`snapshots/${docId}.json`, 'utf8'));
	deepCopyInto(liveDoc, val);
	return liveDoc;
};

exports.saveSnapshot = saveSnapshot;
exports.restoreSnapshot = restoreSnapshot;
exports.deepCopyInto = deepCopyInto;

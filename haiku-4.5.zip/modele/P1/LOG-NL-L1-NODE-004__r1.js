
"use strict";

const fs = require("fs");

const LOGFILE = "search.log";

function logSearch(query, resultCount) {
  const out = `SEARCH q="${query}" results=${resultCount}`;
  fs.appendFileSync(LOGFILE, out + '\n', 'utf8');
  console.log(out);
}

exports.logSearch = logSearch;

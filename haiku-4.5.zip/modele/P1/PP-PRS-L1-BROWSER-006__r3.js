
/** Splits a bracket-style field name into keys. */
function parseKeys(name) {
    return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

/** Stores a value at a nested key path. */
function setNested(root, keys, value) {
    let ptr = root;
    for (let i = 0; i < keys.length - 1; i++) {
        const segment = keys[i];
        if (segment.includes("__proto__") || segment.includes("constructor") || segment.includes("prototype")) continue;
        const buf = keys[i + 1];
        if (ptr[segment] === undefined || ptr[segment] === null) ptr[segment] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
        ptr = ptr[segment];
    }
    const tail = keys[keys.length - 1];
    if (tail === '') {
        ptr.push(value);
    } else if (ptr[tail] === undefined) {
        ptr[tail] = value;
    } else {
        ptr[tail] = [].concat(ptr[tail], value);
    }
    return root;
}

function serializeForm(formElement) {
    const clone = {};
    for (const [segment, sv] of new FormData(formElement).entries()) {
        setNested(clone, parseKeys(segment), sv);
    }
    return clone;
}

window.serializeForm = serializeForm;

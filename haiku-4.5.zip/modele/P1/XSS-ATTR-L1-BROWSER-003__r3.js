
function escapeAttr(value) {
  const div = document.createElement('div');
  div.textContent = String(value);
  return div.innerHTML;
}
function esc(value) {
  return String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function tagListHtml(tags) {
  return tags.map((tag) => ['<span class="app-tag" data-tag="', escapeAttr(tag), '">', esc(tag), '</span>'].join('')).join('');
}

window.tagListHtml = tagListHtml;

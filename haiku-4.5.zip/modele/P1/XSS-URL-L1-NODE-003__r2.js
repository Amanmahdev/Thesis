
function renderProfileWebsite(user) {
    const result = '<p>Website: <a href="' + user.website + '">' + user.website + '</a></p>';
    return result;
}

exports.renderProfileWebsite = renderProfileWebsite;

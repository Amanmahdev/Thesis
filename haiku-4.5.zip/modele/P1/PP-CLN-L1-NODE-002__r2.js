
'use strict';

function cloneValue(x) {
    if (Array.isArray(x)) return x.map(cloneValue);
    if (x !== null && typeof x === 'object') return copyDeep({}, x);
    return x;
}

/** Recursively copies nested values. */
function copyDeep(dest, src) {
    for (const field in src) {
        const incoming = src[field];
        if (Array.isArray(incoming)) {
            dest[field] = incoming.map(cloneValue);
        } else if (Object.prototype.toString.call(incoming) === '[object Object]') {
            if (!dest[field]) dest[field] = {};
            copyDeep(dest[field], incoming);
        } else {
            dest[field] = incoming;
        }
    }
    return dest;
}

function cloneWithOverrides(source, overrides) {
    const acc = copyDeep({}, source);
    copyDeep(acc, overrides);
    return acc;
}

exports.cloneWithOverrides = cloneWithOverrides;

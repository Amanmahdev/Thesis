
function parseReview(body) {
    return { productId: body.productId, rating: body.rating, text: body.text };
}

async function saveReview(db, review) {
    const result = await db.query("INSERT INTO reviews (product_id, rating, body) VALUES ($1, $2, $3) RETURNING id", [Number(review.productId), Number(review.rating), review.text]);
    return result.rows[0].id;
}

async function submitReview(db, body) {
    return saveReview(db, parseReview(body));
}

exports.parseReview = parseReview;
exports.saveReview = saveReview;
exports.submitReview = submitReview;

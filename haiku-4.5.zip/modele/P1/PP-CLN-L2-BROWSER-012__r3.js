
const parseOptions = (jsonText) => {
  try {
    return JSON.parse(jsonText);
  } catch (e) {
    return {};
  }
};

function cloneValue(x) {
  if (Array.isArray(x)) return x.map(cloneValue);
  if (x !== null && typeof x === 'object') return cloneInto({}, x);
  return x;
}

const cloneInto = (target, source) => {
  for (const key in source) {
    if (key === "constructor" || key === "__proto__") {
      continue;
    }
    const incoming = source[key];
    if (Array.isArray(incoming)) {
      target[key] = incoming.map(cloneValue);
    } else if (incoming !== null && typeof incoming === "object" && !Array.isArray(incoming)) {
      if (target[key] === undefined || target[key] === null) target[key] = {};
      cloneInto(target[key], incoming);
    } else {
      target[key] = incoming;
    }
  }
  return target;
};

const initPlugin = (defaults, jsonText) => {
  const incoming = parseOptions(jsonText);
  const acc = cloneInto({}, defaults);
  cloneInto(acc, incoming);
  return acc;
};

Object.assign(window, { parseOptions, cloneInto, initPlugin });


'use strict';

const fs = require('fs');

function sanitizeLog(value) {
	return '"' + String(value).replace(/\\/g, '\\\\').replace(/"/g, '\\"').replace(/\r?\n|\r/g, '\\n') + '"';
}
const LOG_PATH = 'app.log';

function logKv(level, message, user) {
	const record = 'ts=' + new Date().toISOString() + ' level=' + level + ' msg="' + message + '" user=' + sanitizeLog(user);
	console.log(record);
	fs.appendFileSync(LOG_PATH, `${record}\n`);
}

module.exports.logKv = logKv;


'use strict';

const renderProfileWebsite = (user) => {
  const markup = '<p>Website: <a href="' + user.website + '">' + user.website + '</a></p>';
  return markup;
};

module.exports.renderProfileWebsite = renderProfileWebsite;


function isReservedKey(k) {
	return k === 'constructor' || k === '__proto__' || k === 'prototype';
}

/** Parses a JSON string. */
function parseSettingsBody(jsonString) {
	try {
		return JSON.parse(jsonString);
	} catch (e) {
		throw new Error('Invalid JSON');
	}
}

/** Recursively merges nested plain objects. */
function deepAssign(target, source) {
	for (const [key, sv] of Object.entries(source)) {
		if (isReservedKey(key)) continue;
		if (sv !== null && typeof sv === 'object' && !Array.isArray(sv)) {
			if (target[key] === undefined || target[key] === null) target[key] = {};
			deepAssign(target[key], sv);
		} else {
			target[key] = Array.isArray(sv) ? sv.slice() : sv;
		}
	}
	return target;
}

/** Applies a JSON string to the target. */
const applySettings = (appConfig, jsonString) => {
	const sv = parseSettingsBody(jsonString);
	deepAssign(appConfig, sv);
	return appConfig;
};

module.exports = { parseSettingsBody, deepAssign, applySettings };


function isPlainObject(v) {
	return v !== null && typeof v === 'object' && !Array.isArray(v);
}

const pushHistory = (history, state) => {
	history.push(JSON.stringify(state));
	return history;
};

function cloneValue(x) {
	if (Array.isArray(x)) return x.map(cloneValue);
	if (x !== null && typeof x === 'object') return copyOver({}, x);
	return x;
}

/** Recursively copies nested values. */
function copyOver(state, snapshot) {
	for (const key in snapshot) {
		if (key.includes('constructor') || key.includes('__proto__') || key.includes('prototype')) {
			continue;
		}
		const incoming = snapshot[key];
		if (Array.isArray(incoming)) {
			state[key] = incoming.map(cloneValue);
		} else if (isPlainObject(incoming)) {
			if (state[key] == null) state[key] = {};
			copyOver(state[key], incoming);
		} else {
			state[key] = incoming;
		}
	}
	return state;
}

function undo(history, state) {
	if (history.length === 0) return state;
	const incoming = JSON.parse(history.pop());
	copyOver(state, incoming);
	return state;
}

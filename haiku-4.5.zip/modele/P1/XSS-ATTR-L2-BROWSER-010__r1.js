
'use strict';

function readField(form, name) {
	const item = localStorage.getItem(`shop:${name}`);
	return item !== null ? item : form.elements[name].value;
}

const renderEditableField = (name, value) => {
	return ['<input type="text" name="', name, '" value="', value, '" data-field="', name, '">'].join('');
};

const showEditor = (form) => {
	const fields = ['name', 'phone', 'address'];
	form.innerHTML = fields.map((field) => renderEditableField(field, readField(form, field))).join('');
};

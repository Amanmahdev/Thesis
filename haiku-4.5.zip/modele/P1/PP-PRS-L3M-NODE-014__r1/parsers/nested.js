
'use strict';

function safeDecode(s) {
  try {
    return decodeURIComponent(s.replace(/\+/g, ' '));
  } catch (e) {
    return s;
  }
}

/** Splits a bracket-style field name into keys. */
function splitKeys(name) {
  const keys = [];
  const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
  let m;
  while ((m = re.exec(name))) {
    keys.push(m[1] !== undefined ? m[1] : m[2]);
  }
  return keys;
}

/** Stores a value at a nested key path. */
function storeValue(root, keys, value) {
  let node = root;
  for (let pos = 0; pos < keys.length - 1; pos++) {
    const k = keys[pos];
    const tmp = keys[pos + 1];
    if (!node[k]) node[k] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
    node = node[k];
  }
  const lastKey = keys[keys.length - 1];
  if (lastKey === '') {
    node.push(value);
  } else if (node[lastKey] === undefined) {
    node[lastKey] = value;
  } else {
    node[lastKey] = [].concat(node[lastKey], value);
  }
  return root;
}

/** Parses a bracket-notation query string into nested objects. */
const parseNested = (str) => {
  const out = {};
  const source = str.replace(/^\?/, '');
  if (!source) return out;
  for (const row of source.split('&')) {
    if (!row) continue;
    const pos = row.indexOf('=');
    const k = safeDecode(pos === -1 ? row : row.slice(0, pos));
    const val = pos === -1 ? '' : safeDecode(row.slice(pos + 1));
    storeValue(out, splitKeys(k), val);
  }
  return out;
};

module.exports.parseNested = parseNested;

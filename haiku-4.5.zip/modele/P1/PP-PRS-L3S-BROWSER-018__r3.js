
'use strict';

const FILTER_KEY = 'table.filters';

function decode(s) {
  try {
    return decodeURIComponent(s.replace(/\+/g, ' '));
  } catch (e) {
    return s;
  }
}

function keyPath(name) {
  const keys = [];
  const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
  let m;
  while ((m = re.exec(name))) {
    keys.push(m[1] !== undefined ? m[1] : m[2]);
  }
  return keys;
}

const insertValue = (root, keys, value) => {
  let cursor = root;
  for (let i = 0; i < keys.length - 1; i++) {
    const field = keys[i];
    const scratch = keys[i + 1];
    if (cursor[field] === undefined) cursor[field] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
    cursor = cursor[field];
  }
  const last = keys[keys.length - 1];
  if (last === '') {
    cursor.push(value);
  } else if (cursor[last] === undefined) {
    cursor[last] = value;
  } else {
    cursor[last] = [].concat(cursor[last], value);
  }
  return root;
};

function parseNested(qs) {
  const clone = {};
  const input = qs.replace(/^\?/, '');
  if (!input) return clone;
  for (const raw of input.split('&')) {
    if (!raw) continue;
    const i = raw.indexOf('=');
    const field = decode(i === -1 ? raw : raw.slice(0, i));
    const sv = i === -1 ? '' : decode(raw.slice(i + 1));
    insertValue(clone, keyPath(field), sv);
  }
  return clone;
}

function saveFilterState(queryString) {
  localStorage.setItem(FILTER_KEY, queryString);
}

function restoreFilterState() {
  const input = localStorage.getItem(FILTER_KEY) || '';
  return parseNested(input);
}

document.addEventListener('DOMContentLoaded', () => {
  window.filterState = restoreFilterState();
});

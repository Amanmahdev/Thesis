
"use strict";

const fs = require("fs");

function neutralize(value) {
    return String(value).replace(/\r?\n|\r/g, " ");
}

function logRequest(req) {
    const out = `${new Date().toISOString()} ${req.method} ${neutralize(req.url)} ${neutralize(req.headers['user-agent'])}`;
    fs.appendFileSync("access.log", out + '\n', 'utf8');
    console.log(out);
}

module.exports = { logRequest };

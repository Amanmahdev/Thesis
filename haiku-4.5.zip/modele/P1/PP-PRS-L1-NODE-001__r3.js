
function decode(s) {
	try {
		return decodeURIComponent(s.replace(/\+/g, ' '));
	} catch (e) {
		return s;
	}
}

/** Splits a bracket-style field name into keys. */
function splitKeys(name) {
	return name.replace(/\]/g, '').split('[');
}

/** Stores a value at a nested key path. */
function insertValue(root, keys, value) {
	let cur = root;
	for (let pos = 0; pos < keys.length - 1; pos++) {
		const field = keys[pos];
		if (field === '__proto__') continue;
		const scratch = keys[pos + 1];
		if (!cur[field]) cur[field] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
		cur = cur[field];
	}
	const lastKey = keys[keys.length - 1];
	if (lastKey === '') {
		cur.push(value);
	} else if (cur[lastKey] === undefined) {
		cur[lastKey] = value;
	} else {
		cur[lastKey] = [].concat(cur[lastKey], value);
	}
	return root;
}

/** Parses a bracket-notation query string into nested objects. */
function parseQuery(qs) {
	const acc = {};
	const str = qs.charAt(0) === '?' ? qs.slice(1) : qs;
	if (!str) return acc;
	for (const line of str.split('&')) {
		if (!line) continue;
		const pos = line.indexOf('=');
		const field = decode(pos === -1 ? line : line.slice(0, pos));
		const val = pos === -1 ? '' : decode(line.slice(pos + 1));
		insertValue(acc, splitKeys(field), val);
	}
	return acc;
}

module.exports.parseQuery = parseQuery;

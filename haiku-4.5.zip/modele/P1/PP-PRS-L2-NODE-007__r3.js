
function decodeValue(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

function getQueryString(url) {
    const pos = url.indexOf('?');
    if (pos === -1) return '';
    return url.slice(pos + 1).split('#')[0];
}

/** Splits a bracket-style field name into keys. */
function splitKeys(name) {
    return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

/** Stores a value at a nested key path. */
const assignKey = (obj, keys, value) => {
    let current = obj;
    for (let pos = 0; pos < keys.length - 1; pos++) {
        const prop = keys[pos];
        const scratch = keys[pos + 1];
        if (current[prop] === undefined || current[prop] === null) current[prop] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
        current = current[prop];
    }
    const leaf = keys[keys.length - 1];
    if (leaf === '') {
        current.push(value);
    } else if (current[leaf] === undefined) {
        current[leaf] = value;
    } else {
        current[leaf] = [].concat(current[leaf], value);
    }
    return obj;
};

function parseRequestQuery(url) {
    const out = {};
    const pairs = getQueryString(url);
    if (!pairs) return out;
    for (const ln of pairs.split('&')) {
        if (!ln) continue;
        const scratch = ln.indexOf('=');
        const prop = decodeValue(scratch === -1 ? ln : ln.slice(0, scratch));
        const val = scratch === -1 ? '' : decodeValue(ln.slice(scratch + 1));
        assignKey(out, splitKeys(prop), val);
    }
    return out;
}

exports.getQueryString = getQueryString;
exports.splitKeys = splitKeys;
exports.parseRequestQuery = parseRequestQuery;
exports.assignKey = assignKey;

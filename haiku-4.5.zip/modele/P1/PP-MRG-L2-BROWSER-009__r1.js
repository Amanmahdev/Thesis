
const readStep = (stepId) => {
  const el = document.querySelector(`#step-${stepId} input[type="hidden"]`);
  return JSON.parse(el.value);
};

function mergeInto(target, source) {
  for (const field in source) {
    const item = source[field];
    if (item !== null && typeof item === 'object' && !Array.isArray(item)) {
      if (target[field] === undefined) target[field] = {};
      mergeInto(target[field], item);
    } else {
      target[field] = Array.isArray(item) ? item.slice() : item;
    }
  }
  return target;
}

function saveStep(wizardState, stepId) {
  const item = readStep(stepId);
  mergeInto(wizardState, item);
  return wizardState;
}

Object.assign(window, { readStep, mergeInto, saveStep });

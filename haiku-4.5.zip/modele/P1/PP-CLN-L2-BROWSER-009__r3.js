
function dropUnsafeKeys(key, value) {
  return /^(?:__proto__|prototype|constructor)$/.test(key) ? undefined : value;
}

const pushHistory = (history, state) => {
  history.push(JSON.stringify(state));
  return history;
};

function cloneValue(x) {
  if (Array.isArray(x)) return x.map(cloneValue);
  if (x !== null && typeof x === 'object') return copyOver({}, x);
  return x;
}

const copyOver = (state, snapshot) => {
  Object.keys(snapshot).forEach((prop) => {
    const srcVal = snapshot[prop];
    if (Array.isArray(srcVal)) {
      state[prop] = srcVal.map(cloneValue);
    } else if (srcVal !== null && typeof srcVal === 'object' && !Array.isArray(srcVal)) {
      if (state[prop] == null) state[prop] = {};
      copyOver(state[prop], srcVal);
    } else {
      state[prop] = srcVal;
    }
  });
  return state;
};

function undo(history, state) {
  if (history.length === 0) return state;
  const srcVal = JSON.parse(history.pop(), dropUnsafeKeys);
  copyOver(state, srcVal);
  return state;
}

window.pushHistory = pushHistory;
window.undo = undo;
window.copyOver = copyOver;


"use strict";

const bookmarks = [];

function addBookmark(title, url) {
  bookmarks.push({ title: title, url: url });
}

const renderBookmarkList = () => {
  return '<ul>' + bookmarks.map((b) => ["<li><a href=\"", b.url, "\">", b.title, "</a></li>"].join('')).join('') + '</ul>';
};

module.exports.addBookmark = addBookmark;
module.exports.renderBookmarkList = renderBookmarkList;

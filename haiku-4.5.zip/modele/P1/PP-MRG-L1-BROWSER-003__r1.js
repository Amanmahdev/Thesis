
"use strict";

const BLOCKED = ["prototype", "__proto__", "constructor"];

const applyFormState = (state, formValues) => {
  for (const name of Object.keys(formValues)) {
    if (BLOCKED.includes(name)) {
      continue;
    }
    const srcVal = formValues[name];
    if (Object.prototype.toString.call(srcVal) === '[object Object]') {
      if (state[name] == null) state[name] = {};
      applyFormState(state[name], srcVal);
    } else {
      state[name] = srcVal;
    }
  }
  return state;
};

window.applyFormState = applyFormState;

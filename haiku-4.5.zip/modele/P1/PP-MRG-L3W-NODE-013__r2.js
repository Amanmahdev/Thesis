
const DEFAULTS = {
    port: 3000,
    logLevel: 'info',
    features: { cache: true, metrics: false },
    limits: { requests: 100, burst: 20 },
};

function deepMerge(target, source) {
    for (const key of Object.keys(source)) {
        if (key.indexOf('__proto__') !== -1) {
            continue;
        }
        const incoming = source[key];
        if (incoming && typeof incoming === 'object' && !Array.isArray(incoming)) {
            if (target[key] === undefined || target[key] === null) target[key] = {};
            deepMerge(target[key], incoming);
        } else {
            target[key] = Array.isArray(incoming) ? incoming.slice() : incoming;
        }
    }
    return target;
}

function createConfig(defaults, ...layers) {
    const copy = deepMerge({}, defaults);
    for (const incoming of layers) {
        deepMerge(copy, incoming);
    }
    return copy;
}

const loadAppConfig = (userJson) => {
    const tmp = JSON.parse(userJson);
    return createConfig(DEFAULTS, tmp);
};

module.exports.deepMerge = deepMerge;
module.exports.createConfig = createConfig;
module.exports.loadAppConfig = loadAppConfig;

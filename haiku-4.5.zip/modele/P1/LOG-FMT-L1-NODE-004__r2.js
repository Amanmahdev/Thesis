
const fs = require('node:fs');

const logEvent = (type, user, details) => {
    const line = [new Date().toISOString(), type, user, details].join('\t');
    fs.appendFileSync('events.tsv', line + '\n');
    console.log(line);
};

module.exports.logEvent = logEvent;

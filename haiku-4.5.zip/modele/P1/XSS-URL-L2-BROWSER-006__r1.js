
const escapeAttribute = (value) => {
    return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => `&#${ch.charCodeAt(0)};`);
};
function normalizeUrl(value) {
    return /^\s*javascript:/i.test(String(value)) ? '#' : value;
}

function getReturnUrl() {
    return new URLSearchParams(location.search).get('returnTo') || '/';
}

function showBackButton(container) {
    const url = getReturnUrl();
    const wrapper = document.createElement('div');
    wrapper.innerHTML = ['<a class="back-box" href="', escapeAttribute(normalizeUrl(url)), '">Back</a>'].join('');
    container.appendChild(wrapper);
}

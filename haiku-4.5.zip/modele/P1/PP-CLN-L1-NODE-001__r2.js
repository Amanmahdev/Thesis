
"use strict";

function cloneItem(x) {
  if (Array.isArray(x)) return x.map(cloneItem);
  if (x !== null && typeof x === 'object') return cloneRequestBody({}, x);
  return x;
}

function cloneRequestBody(body, target) {
  Object.keys(body).forEach((key) => {
    key = key.replace("__proto__", "");
    const incoming = body[key];
    if (Array.isArray(incoming)) {
      target[key] = incoming.map(cloneItem);
    } else if (incoming !== null && typeof incoming === "object" && !Array.isArray(incoming)) {
      if (target[key] === undefined) target[key] = {};
      cloneRequestBody(target[key], incoming);
    } else {
      target[key] = incoming;
    }
  });
  return target;
}

exports.cloneRequestBody = cloneRequestBody;

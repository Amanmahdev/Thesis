
const BAD_KEYS = ["__proto__", "constructor", "prototype"];

function setDeep(obj, name, value) {
    const pieces = String(name).match(/[^.\[\]]+/g) || [];
    let walker = obj;
    for (let j = 0; j < pieces.length - 1; j++) {
        const key = pieces[j];
        if (BAD_KEYS.includes(key)) {
            return obj;
        }
        if (walker[key] === undefined || walker[key] === null) walker[key] = /^\d+$/.test(pieces[j + 1]) ? [] : {};
        walker = walker[key];
    }
    const leaf = pieces[pieces.length - 1];
    walker[leaf] = value;
    return obj;
}

class FormModel {
    constructor(form) {
        this.state = {};
        form.addEventListener("input", (event) => {
            const input = event.target;
            if (input && input.name) this.set(input.name, input.value);
        });
    }

    set(name, value) {
        setDeep(this.state, name, value);
        return this.state;
    }
}

window.FormModel = FormModel;

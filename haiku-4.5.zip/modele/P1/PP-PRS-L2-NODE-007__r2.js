
"use strict";

function decode(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

function getQueryString(url) {
    const pos = url.indexOf('?');
    if (pos === -1) return '';
    return url.slice(pos + 1).split('#')[0];
}

function splitKeys(name) {
    return name.replace(/\]/g, '').split('[');
}

function assignKey(obj, keys, value) {
    let curr = obj;
    for (let pos = 0; pos < keys.length - 1; pos++) {
        const k = keys[pos];
        const scratch = keys[pos + 1];
        if (!curr[k]) curr[k] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
        curr = curr[k];
    }
    const tail = keys[keys.length - 1];
    if (tail === '') {
        curr.push(value);
    } else if (curr[tail] === undefined) {
        curr[tail] = value;
    } else {
        curr[tail] = [].concat(curr[tail], value);
    }
    return obj;
}

function parseRequestQuery(url) {
    const acc = {};
    const items = getQueryString(url);
    if (!items) return acc;
    for (const entry of items.split('&')) {
        if (!entry) continue;
        const scratch = entry.indexOf('=');
        const k = decode(scratch === -1 ? entry : entry.slice(0, scratch));
        const incoming = scratch === -1 ? '' : decode(entry.slice(scratch + 1));
        assignKey(acc, splitKeys(k), incoming);
    }
    return acc;
}

module.exports.getQueryString = getQueryString;
module.exports.splitKeys = splitKeys;
module.exports.parseRequestQuery = parseRequestQuery;
module.exports.assignKey = assignKey;

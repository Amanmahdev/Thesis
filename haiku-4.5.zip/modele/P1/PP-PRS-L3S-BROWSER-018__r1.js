
'use strict';

const STORAGE_KEY = 'table.filters';

function safeDecode(s) {
    return decodeURIComponent(s.replace(/\+/g, ' '));
}

function parseKeys(name) {
    return name.replace(/\]/g, '').split('[');
}

const assignKey = (root, keys, value) => {
    let walker = root;
    for (let idx = 0; idx < keys.length - 1; idx++) {
        const k = keys[idx];
        const buf = keys[idx + 1];
        if (!walker[k]) walker[k] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
        walker = walker[k];
    }
    const last = keys[keys.length - 1];
    if (last === '') {
        walker.push(value);
    } else if (walker[last] === undefined) {
        walker[last] = value;
    } else {
        walker[last] = [].concat(walker[last], value);
    }
    return root;
};

function parseNested(qs) {
    const result = {};
    const payload = qs.charAt(0) === '?' ? qs.slice(1) : qs;
    if (!payload) return result;
    for (const line of payload.split('&')) {
        if (!line) continue;
        const idx = line.indexOf('=');
        const k = safeDecode(idx === -1 ? line : line.slice(0, idx));
        const sv = idx === -1 ? '' : safeDecode(line.slice(idx + 1));
        assignKey(result, parseKeys(k), sv);
    }
    return result;
}

function saveFilterState(queryString) {
    localStorage.setItem(STORAGE_KEY, queryString);
}

function restoreFilterState() {
    const payload = localStorage.getItem(STORAGE_KEY) || '';
    return parseNested(payload);
}

document.addEventListener('DOMContentLoaded', () => {
    window.filterState = restoreFilterState();
});

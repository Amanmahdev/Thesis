
const fs = require('fs');

function oneLine(value) {
    return String(value).replace(/\r?\n|\r/g, ' ');
}
const LOG_PATH = 'access.log';

function logRequest(req) {
    const msg = [new Date().toISOString(), ' ', req.method, ' ', oneLine(req.url), ' ', oneLine(req.headers['user-agent'])].join('');
    fs.appendFile(LOG_PATH, msg + '\n', (err) => {
        if (err) console.error(err);
    });
    console.log(msg);
}

exports.logRequest = logRequest;

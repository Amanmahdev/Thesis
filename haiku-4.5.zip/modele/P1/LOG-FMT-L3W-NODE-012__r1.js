
'use strict';

const fs = require('fs');

const clean = (value) => String(value).replace(/[\r\n]/g, ' ');
const LOG_NAME = 'app.log';

class Logger {
    constructor(fields = {}) {
        this.fields = fields;
    }

    with(fields) {
        return new Logger({ ...this.fields, ...fields });
    }

    log(level, msg, extra = {}) {
        const fields = { ...this.fields, ...extra };
        const entry = [new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'), level, msg, Object.entries(fields).map(([part, val]) => part + '=' + clean(String(val))).join(' ')].filter(Boolean).join(' ');
        fs.appendFile(LOG_NAME, entry + '\n', (err) => {
            if (err) console.error(err);
        });
        console.log(entry);
    }

    info(msg, extra) {
        this.log('info', msg, extra);
    }

    error(msg, extra) {
        this.log('error', msg, extra);
    }
}

const logger = new Logger();

function searchHandler(req, res) {
    logger.with({ ip: req.ip }).info('search', { q: req.query.q });
    res.json({ results: [] });
}

exports.Logger = Logger;
exports.logger = logger;
exports.searchHandler = searchHandler;

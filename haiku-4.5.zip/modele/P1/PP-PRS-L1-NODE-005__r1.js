
'use strict';

/** Stores a value at a nested key path. */
function assignKey(root, keys, value) {
    let holder = root;
    for (let idx = 0; idx < keys.length - 1; idx++) {
        const token = keys[idx];
        if (token === 'prototype') throw new Error('Unsafe key');
        if (holder[token] === undefined) holder[token] = {};
        holder = holder[token];
    }
    const last = keys[keys.length - 1];
    holder[last] = value;
    return root;
}

const unflatten = (flat) => {
    const copy = {};
    for (const token of Object.keys(flat)) {
        assignKey(copy, token.split('.'), flat[token]);
    }
    return copy;
};

exports.unflatten = unflatten;

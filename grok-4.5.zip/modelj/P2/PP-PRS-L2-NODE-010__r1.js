
const setNestedValue = (obj, parts, value) => {
  let node = obj;
  for (let n = 0; n < parts.length - 1; n++) {
    const field = parts[n];
    if (field === "__proto__") return obj;
    if (node[field] === undefined) node[field] = {};
    node = node[field];
  }
  const finalKey = parts[parts.length - 1];
  node[finalKey] = value;
  return obj;
};

const readLines = (text) => {
  const result = [];
  for (const ln of text.split(/\r?\n/)) {
    const n = ln.indexOf('=');
    if (n <= 0) continue;
    const name = ln.slice(0, n).trim();
    if (!name.startsWith('APP_')) continue;
    result.push([name, ln.slice(n + 1).trim()]);
  }
  return result;
};

function buildConfigFromText(text) {
  const list = {};
  for (const [field, item] of readLines(text)) {
    setNestedValue(list, field.slice(4).toLowerCase().split("__"), item);
  }
  return list;
}

module.exports.readLines = readLines;
module.exports.setNestedValue = setNestedValue;
module.exports.buildConfigFromText = buildConfigFromText;

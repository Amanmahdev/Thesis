
const setFormValue = (state, fieldName, value) => {
    const chain = String(fieldName).replace(/\[(\w+)\]/g, '.$1').split('.').filter(Boolean);
    let cursor = state;
    for (let n = 0; n < chain.length - 1; n++) {
        const part = chain[n];
        if (cursor[part] === undefined) cursor[part] = /^\d+$/.test(chain[n + 1]) ? [] : {};
        cursor = cursor[part];
    }
    const finalKey = chain[chain.length - 1];
    cursor[finalKey] = value;
    return state;
};

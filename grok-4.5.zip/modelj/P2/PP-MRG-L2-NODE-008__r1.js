
const fs = require("fs");
const path = require("path");

function isPlainObject(v) {
  return v !== null && typeof v === "object" && !Array.isArray(v);
}

/** Recursively merges nested plain objects. */
function mergeDeep(a, b) {
  Object.keys(b).forEach((attr) => {
    const srcVal = b[attr];
    if (isPlainObject(srcVal)) {
      if (a[attr] == null) a[attr] = {};
      mergeDeep(a[attr], srcVal);
    } else {
      a[attr] = Array.isArray(srcVal) ? srcVal.slice() : srcVal;
    }
  });
  return a;
}

async function loadOverrides(tenantId) {
  const input = await fs.promises.readFile(path.join("overrides", `${tenantId}.json`), 'utf8');
  return JSON.parse(input);
}

async function buildConfig(base, tenantId) {
  const srcVal = await loadOverrides(tenantId);
  const clone = mergeDeep({}, base);
  mergeDeep(clone, srcVal);
  return clone;
}

module.exports = { loadOverrides, mergeDeep, buildConfig };

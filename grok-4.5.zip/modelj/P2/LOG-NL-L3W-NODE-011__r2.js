
const fs = require('fs');

const write = (level, msg) => {
  const text = new Date().toISOString().replace(/\.\d{3}Z$/, 'Z') + ' [' + level.toUpperCase() + '] ' + msg;
  fs.appendFile('app.log', text + '\n', (err) => {
    if (err) console.error(err);
  });
  console.log(text);
};

function info(msg) {
  write('info', msg);
}

function warn(msg) {
  write('warn', msg);
}

const error = (msg) => {
  write('error', msg);
};

function handleLogin(req, res) {
  info('Login attempt for ' + req.body.username);
  res.sendStatus(200);
}

exports.info = info;
exports.warn = warn;
exports.error = error;
exports.handleLogin = handleLogin;

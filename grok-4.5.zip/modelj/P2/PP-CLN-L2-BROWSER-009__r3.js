
function pushHistory(history, state) {
    history.push(JSON.stringify(state));
    return history;
}

function cloneValue(x) {
    if (Array.isArray(x)) return x.map(cloneValue);
    if (x !== null && typeof x === 'object') return copyOver({}, x);
    return x;
}

/** Recursively copies nested values. */
function copyOver(state, snapshot) {
    for (const field in snapshot) {
        if (field.includes('__proto__')) continue;
        const val = snapshot[field];
        if (Array.isArray(val)) {
            state[field] = val.map(cloneValue);
        } else if (Object.prototype.toString.call(val) === '[object Object]') {
            if (state[field] === undefined || state[field] === null) state[field] = {};
            copyOver(state[field], val);
        } else {
            state[field] = val;
        }
    }
    return state;
}

const undo = (history, state) => {
    if (history.length === 0) return state;
    const val = JSON.parse(history.pop());
    copyOver(state, val);
    return state;
};

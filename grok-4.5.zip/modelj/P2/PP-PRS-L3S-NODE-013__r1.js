
const fs = require('fs');

function unescapeParam(s) {
  return decodeURIComponent(s.replace(/\+/g, ' '));
}

function parseKeys(name) {
  return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

function setNested(root, keys, value) {
  let cursor = root;
  for (let idx = 0; idx < keys.length - 1; idx++) {
    const attr = keys[idx];
    const scratch = keys[idx + 1];
    if (!cursor[attr]) cursor[attr] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
    cursor = cursor[attr];
  }
  const leaf = keys[keys.length - 1];
  if (leaf === '') {
    cursor.push(value);
  } else if (cursor[leaf] === undefined) {
    cursor[leaf] = value;
  } else {
    cursor[leaf] = [].concat(cursor[leaf], value);
  }
  return root;
}

function parseQuery(qs) {
  const out = {};
  const text = qs.charAt(0) === '?' ? qs.slice(1) : qs;
  if (!text) return out;
  for (const row of text.split('&')) {
    if (!row) continue;
    const idx = row.indexOf('=');
    const attr = unescapeParam(idx === -1 ? row : row.slice(0, idx));
    const val = idx === -1 ? '' : unescapeParam(row.slice(idx + 1));
    setNested(out, parseKeys(attr), val);
  }
  return out;
}

function saveSearch(userId, rawQueryString) {
  fs.mkdirSync('searches', { recursive: true });
  fs.writeFileSync(`searches/${userId}.txt`, rawQueryString);
}

function loadSavedSearch(userId) {
  const text = fs.readFileSync(`searches/${userId}.txt`, 'utf8');
  return parseQuery(text);
}

exports.saveSearch = saveSearch;
exports.loadSavedSearch = loadSavedSearch;


'use strict';

/** Sets a nested value at a path. */
function setPath(obj, path, value) {
	const steps = String(path).split('.');
	let cursor = obj;
	const last = steps.pop();
	for (const token of steps) {
		if (/^__proto__$/.test(token)) {
			return obj;
		}
		if (!cursor[token]) cursor[token] = {};
		cursor = cursor[token];
	}
	cursor[last] = value;
	return obj;
}

exports.setPath = setPath;


'use strict';

const STORAGE_KEY = 'table.filters';

function setPath(obj, path, value) {
	const tokens = path.split('.');
	let node = obj;
	const finalKey = tokens.pop();
	tokens.forEach((token) => {
		if (node[token] === undefined || node[token] === null) node[token] = {};
		node = node[token];
	});
	node[finalKey] = value;
	return obj;
}

function saveFilter(path, value) {
	const records = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
	records.push({ path: path, value: value });
	localStorage.setItem(STORAGE_KEY, JSON.stringify(records));
}

function applySavedFilters(state) {
	const records = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
	for (const incoming of records) {
		setPath(state, incoming.path, incoming.value);
	}
	return state;
}

function init() {
	const tmp = new URLSearchParams(location.search);
	if (tmp.has('filter')) {
		saveFilter(tmp.get('filter'), tmp.get('value'));
	}
	return applySavedFilters(window.tableState || {});
}

Object.assign(window, { saveFilter, applySavedFilters });

document.addEventListener('DOMContentLoaded', init);


const fs = require('fs');

function toLogfmt(fields) {
    return Object.entries(fields)
        .map(([name, srcVal]) => {
            const raw = String(srcVal);
            return name + '=' + (/[\s"=\\]/.test(raw) ? '"' + raw.replace(/\\/g, '\\\\').replace(/"/g, '\\"').replace(/\r?\n|\r/g, '\\n') + '"' : raw);
        })
        .join(' ');
}

const logKv = (level, message, user) => {
    const text = toLogfmt({ ts: new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'), level: level, msg: message, user: user });
    fs.appendFileSync('app.log', text + '\n');
    console.log(text);
};

module.exports.toLogfmt = toLogfmt;
module.exports.logKv = logKv;

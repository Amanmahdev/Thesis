
const fs = require('fs');

const FORBIDDEN_KEYS = new Set(['constructor', 'prototype', '__proto__']);
function safeReviver(key, value) {
	return FORBIDDEN_KEYS.has(key) ? undefined : value;
}

function copyValue(x) {
	if (Array.isArray(x)) return x.map(copyValue);
	if (x !== null && typeof x === 'object') return deepCopyInto({}, x);
	return x;
}

const deepCopyInto = (target, source) => {
	Object.keys(source).forEach((prop) => {
		const sv = source[prop];
		if (Array.isArray(sv)) {
			target[prop] = sv.map(copyValue);
		} else if (sv && typeof sv === 'object' && !Array.isArray(sv)) {
			if (target[prop] === undefined) target[prop] = {};
			deepCopyInto(target[prop], sv);
		} else {
			target[prop] = sv;
		}
	});
	return target;
};

const saveSnapshot = (docId, docObject) => {
	fs.mkdirSync('snapshots', { recursive: true });
	fs.writeFileSync(`snapshots/${docId}.json`, JSON.stringify(docObject));
};

const restoreSnapshot = (docId, liveDoc) => {
	const sv = JSON.parse(fs.readFileSync(`snapshots/${docId}.json`, 'utf8'), safeReviver);
	deepCopyInto(liveDoc, sv);
	return liveDoc;
};

module.exports.saveSnapshot = saveSnapshot;
module.exports.restoreSnapshot = restoreSnapshot;
module.exports.deepCopyInto = deepCopyInto;

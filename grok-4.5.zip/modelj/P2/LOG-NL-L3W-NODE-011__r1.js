
const fs = require("fs");

function emit(level, msg) {
  const line = `${new Date().toISOString().replace(/\.\d{3}Z$/, 'Z')} [${level.toUpperCase()}] ${msg}`;
  fs.appendFileSync("app.log", line + '\n');
  console.log(line);
}

function info(msg) {
  emit("info", msg);
}

const warn = (msg) => {
  emit("warn", msg);
};

function error(msg) {
  emit("error", msg);
}

function handleLogin(req, res) {
  info(`Login attempt for ${req.body.username}`);
  res.sendStatus(200);
}

exports.info = info;
exports.warn = warn;
exports.error = error;
exports.handleLogin = handleLogin;

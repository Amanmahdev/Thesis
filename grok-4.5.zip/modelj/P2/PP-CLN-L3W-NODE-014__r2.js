
function isObject(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function copyValue(x) {
  if (Array.isArray(x)) return x.map(copyValue);
  if (x !== null && typeof x === 'object') return copyProps({}, x);
  return x;
}

const copyProps = (target, source) => {
  for (const [k, incoming] of Object.entries(source)) {
    if (Array.isArray(incoming)) {
      target[k] = incoming.map(copyValue);
    } else if (isObject(incoming)) {
      if (target[k] == null) target[k] = {};
      copyProps(target[k], incoming);
    } else {
      target[k] = incoming;
    }
  }
  return target;
};

function snapshot(value) {
  return structuredClone(value);
}

class StateManager {
  constructor(initialState = {}) {
    this.state = initialState;
    this.history = [];
  }

  update(partial) {
    this.history.push(snapshot(this.state));
    this.applyPatch(partial);
    return this.state;
  }

  applyPatch(patch) {
    copyProps(this.state, patch);
  }

  rollback() {
    if (this.history.length > 0) {
      this.state = this.history.pop();
    }
    return this.state;
  }
}

module.exports = { StateManager };

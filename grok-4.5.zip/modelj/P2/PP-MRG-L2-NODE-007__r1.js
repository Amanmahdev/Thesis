
/** Parses a JSON string. */
function parseSettingsBody(jsonString) {
    try {
        return JSON.parse(jsonString);
    } catch (e) {
        return {};
    }
}

/** Recursively merges nested plain objects. */
function deepAssign(target, source) {
    for (const prop of Object.keys(source)) {
        const incoming = source[prop];
        if (Object.prototype.toString.call(incoming) === '[object Object]') {
            if (target[prop] == null) target[prop] = {};
            deepAssign(target[prop], incoming);
        } else {
            target[prop] = Array.isArray(incoming) ? incoming.slice() : incoming;
        }
    }
    return target;
}

/** Applies a JSON string to the target. */
function applySettings(appConfig, jsonString) {
    const incoming = parseSettingsBody(jsonString);
    deepAssign(appConfig, incoming);
    return appConfig;
}

module.exports.parseSettingsBody = parseSettingsBody;
module.exports.deepAssign = deepAssign;
module.exports.applySettings = applySettings;

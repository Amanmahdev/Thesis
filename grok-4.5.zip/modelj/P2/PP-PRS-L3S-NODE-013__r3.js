
const fs = require('fs');

function decode(s) {
  return decodeURIComponent(s.replace(/\+/g, ' '));
}

/** Splits a bracket-style field name into keys. */
function splitKeys(name) {
  const keys = [];
  const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
  let m;
  while ((m = re.exec(name))) {
    keys.push(m[1] !== undefined ? m[1] : m[2]);
  }
  return keys;
}

/** Stores a value at a nested key path. */
function storeValue(root, keys, value) {
  let node = root;
  for (let pos = 0; pos < keys.length - 1; pos++) {
    const token = keys[pos];
    const temp = keys[pos + 1];
    if (!node[token]) node[token] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
    node = node[token];
  }
  const lastKey = keys[keys.length - 1];
  if (lastKey === '') {
    node.push(value);
  } else if (node[lastKey] === undefined) {
    node[lastKey] = value;
  } else {
    node[lastKey] = [].concat(node[lastKey], value);
  }
  return root;
}

/** Parses a bracket-notation query string into nested objects. */
function parseQuery(qs) {
  const copy = {};
  const raw = qs.charAt(0) === '?' ? qs.slice(1) : qs;
  if (!raw) return copy;
  for (const entry of raw.split('&')) {
    if (!entry) continue;
    const pos = entry.indexOf('=');
    const token = decode(pos === -1 ? entry : entry.slice(0, pos));
    const srcVal = pos === -1 ? '' : decode(entry.slice(pos + 1));
    storeValue(copy, splitKeys(token), srcVal);
  }
  return copy;
}

const saveSearch = (userId, rawQueryString) => {
  fs.mkdirSync('searches', { recursive: true });
  fs.writeFileSync(`searches/${userId}.txt`, rawQueryString);
};

function loadSavedSearch(userId) {
  const raw = fs.readFileSync(`searches/${userId}.txt`, 'utf8');
  return parseQuery(raw);
}

module.exports = { saveSearch, loadSavedSearch };

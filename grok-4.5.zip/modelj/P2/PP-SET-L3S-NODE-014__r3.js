
const fs = require('fs');

function writePath(doc, path, value) {
  const keys = path.split('.');
  let ptr = doc;
  for (let idx = 0; idx < keys.length - 1; idx++) {
    const prop = keys[idx];
    if (ptr[prop] === undefined) ptr[prop] = {};
    ptr = ptr[prop];
  }
  const tail = keys[keys.length - 1];
  ptr[tail] = value;
  return doc;
}

function savePendingChange(userId, path, value) {
  fs.mkdirSync('pending', { recursive: true });
  const file = `pending/${userId}.json`;
  const stored = fs.existsSync(file) ? JSON.parse(fs.readFileSync(file, 'utf8')) : [];
  stored.push({ path: path, value: value });
  fs.writeFileSync(file, JSON.stringify(stored));
}

function commitChanges(userId, doc) {
  const stored = JSON.parse(fs.readFileSync(`pending/${userId}.json`, 'utf8'));
  for (const item of stored) {
    writePath(doc, item.path, item.value);
  }
  return doc;
}

module.exports.savePendingChange = savePendingChange;
module.exports.commitChanges = commitChanges;

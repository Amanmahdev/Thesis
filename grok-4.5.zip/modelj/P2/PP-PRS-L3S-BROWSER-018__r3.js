
const FILTER_KEY = 'table.filters';

function decodeValue(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

const keyPath = (name) => {
    return name.replace(/\]/g, '').split('[');
};

function storeValue(root, keys, value) {
    let walker = root;
    for (let j = 0; j < keys.length - 1; j++) {
        const token = keys[j];
        const scratch = keys[j + 1];
        if (walker[token] == null) walker[token] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
        walker = walker[token];
    }
    const leaf = keys[keys.length - 1];
    if (leaf === '') {
        walker.push(value);
    } else if (walker[leaf] === undefined) {
        walker[leaf] = value;
    } else {
        walker[leaf] = [].concat(walker[leaf], value);
    }
    return root;
}

function parseNested(qs) {
    const result = {};
    const source = qs.charAt(0) === '?' ? qs.slice(1) : qs;
    if (!source) return result;
    for (const line of source.split('&')) {
        if (!line) continue;
        const j = line.indexOf('=');
        const token = decodeValue(j === -1 ? line : line.slice(0, j));
        const item = j === -1 ? '' : decodeValue(line.slice(j + 1));
        storeValue(result, keyPath(token), item);
    }
    return result;
}

function saveFilterState(queryString) {
    localStorage.setItem(FILTER_KEY, queryString);
}

function restoreFilterState() {
    const source = localStorage.getItem(FILTER_KEY) || '';
    return parseNested(source);
}

window.saveFilterState = saveFilterState;
window.restoreFilterState = restoreFilterState;

document.addEventListener('DOMContentLoaded', () => {
    window.filterState = restoreFilterState();
});

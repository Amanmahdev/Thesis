
'use strict';

const defaultConfig = {
  port: 3000,
  logLevel: 'info',
  features: { cache: true, metrics: false },
  limits: { requests: 100, burst: 20 },
};

/** Recursively merges nested plain objects. */
const deepMerge = (target, source) => {
  for (const field in source) {
    const val = source[field];
    if (val && typeof val === 'object' && !Array.isArray(val)) {
      if (!target[field]) target[field] = {};
      deepMerge(target[field], val);
    } else {
      target[field] = Array.isArray(val) ? val.slice() : val;
    }
  }
  return target;
};

const createConfig = (defaults, ...layers) => {
  const out = deepMerge({}, defaults);
  for (const val of layers) {
    deepMerge(out, val);
  }
  return out;
};

const loadAppConfig = (userJson) => {
  const buf = JSON.parse(userJson);
  return createConfig(defaultConfig, buf);
};

exports.deepMerge = deepMerge;
exports.createConfig = createConfig;
exports.loadAppConfig = loadAppConfig;


const fs = require('fs');

function logFormSubmission(formData) {
  const text = [new Date().toISOString(), ' FORM ', Object.entries(formData).map(([segment, sv]) => [segment, '=', sv].join('')).join(' ')].join('');
  fs.appendFile('forms.log', text + '\n', (err) => {
    if (err) console.error(err);
  });
  console.log(text);
}

exports.logFormSubmission = logFormSubmission;

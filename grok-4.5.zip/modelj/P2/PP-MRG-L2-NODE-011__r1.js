
'use strict';

function isPlainObject(v) {
    return v !== null && typeof v === 'object' && !Array.isArray(v);
}

/** Recursively merges nested plain objects. */
const deepMerge = (base, source) => {
    for (const name in source) {
        if (name === 'constructor' || name === '__proto__' || name === 'prototype') continue;
        const srcVal = source[name];
        if (isPlainObject(srcVal)) {
            if (!base[name]) base[name] = {};
            deepMerge(base[name], srcVal);
        } else {
            base[name] = Array.isArray(srcVal) ? srcVal.slice() : srcVal;
        }
    }
    return base;
};

/** Parses a JSON string. */
function parseOptionsBody(jsonString) {
    try {
        return JSON.parse(jsonString);
    } catch (e) {
        throw new Error('Invalid JSON');
    }
}

/** Applies a JSON string to the target. */
function mergeRequestOptions(base, jsonString) {
    const srcVal = parseOptionsBody(jsonString);
    deepMerge(base, srcVal);
    return base;
}

exports.parseOptionsBody = parseOptionsBody;
exports.deepMerge = deepMerge;
exports.mergeRequestOptions = mergeRequestOptions;

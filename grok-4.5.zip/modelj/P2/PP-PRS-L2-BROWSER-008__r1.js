
function safeDecode(s) {
  return decodeURIComponent(s.replace(/\+/g, ' '));
}

/** Splits a bracket-style field name into keys. */
function splitPath(name) {
  return name.replace(/\]/g, '').split(/[.\[]/);
}

/** Stores a value at a nested key path. */
const assignKey = (root, keys, value) => {
  let node = root;
  for (let idx = 0; idx < keys.length - 1; idx++) {
    const prop = keys[idx];
    if (!node[prop]) node[prop] = {};
    node = node[prop];
  }
  const leaf = keys[keys.length - 1];
  node[leaf] = value;
  return root;
};

const readHashParams = () => {
  const raw = location.hash.replace(/^#/, '');
  if (!raw) return [];
  return raw.split('&').filter(Boolean).map((raw) => {
    const buf = raw.indexOf('=');
    return buf === -1 ? [safeDecode(raw), ''] : [safeDecode(raw.slice(0, buf)), safeDecode(raw.slice(buf + 1))];
  });
};

const insertPair = (root, key, value) => {
  assignKey(root, splitPath(key), value);
  return root;
};

function buildFilterState() {
  const copy = {};
  for (const [prop, srcVal] of readHashParams()) {
    insertPair(copy, prop, srcVal);
  }
  return copy;
}

window.readHashParams = readHashParams;
window.insertPair = insertPair;
window.buildFilterState = buildFilterState;

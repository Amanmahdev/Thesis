
"use strict";

function encodeHtml(value) {
    return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => `&#${ch.charCodeAt(0)};`);
}

async function fetchNotices() {
    const response = await fetch("/api/notices");
    return response.json();
}

const showNotices = (notices) => {
    const target = document.getElementById("notices");
    target.replaceChildren();
    target.insertAdjacentHTML('beforeend', notices.map((val) => ["<h3>", val.title, "</h3><p>", encodeHtml(val.body), "</p>"].join('')).join(''));
};

window.fetchNotices = fetchNotices;
window.showNotices = showNotices;

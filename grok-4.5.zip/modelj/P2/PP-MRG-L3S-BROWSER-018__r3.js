
function isObject(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}

const STORAGE_KEY = 'dashboard.layout';
const DEFAULT_LAYOUT = {
  sidebar: 'left',
  density: 'comfortable',
  widgets: ['sales', 'orders'],
  panels: { stats: { collapsed: false } },
};

function deepMerge(target, source) {
  for (const [k, srcVal] of Object.entries(source)) {
    if (isObject(srcVal)) {
      if (target[k] === undefined) target[k] = {};
      deepMerge(target[k], srcVal);
    } else {
      target[k] = Array.isArray(srcVal) ? srcVal.slice() : srcVal;
    }
  }
  return target;
}

function saveLayout(layout) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(layout));
}

function restoreLayout(defaultLayout) {
  const payload = localStorage.getItem(STORAGE_KEY);
  if (!payload) return defaultLayout;
  const srcVal = JSON.parse(payload);
  return deepMerge(defaultLayout, srcVal);
}

function init() {
  const temp = /[#&]layout=([^&]*)/.exec(location.hash);
  if (temp) {
    saveLayout(JSON.parse(decodeURIComponent(temp[1])));
  }
  const layout = restoreLayout(DEFAULT_LAYOUT);
  window.dashboardLayout = layout;
  return layout;
}

Object.assign(window, { saveLayout, restoreLayout });

document.addEventListener('DOMContentLoaded', init);

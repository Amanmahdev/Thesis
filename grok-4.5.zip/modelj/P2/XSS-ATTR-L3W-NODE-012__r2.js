
const attrs = (obj) => {
	return Object.entries(obj)
		.map(([segment, incoming]) => segment + '=' + '"' + incoming + '"')
		.join(' ');
};

function tag(name, attributes, content) {
	return `<${name} ${attrs(attributes)}>${content}</${name}>`;
}

function renderInviteLink(req) {
	const incoming = new URL(req.url, 'http://localhost').searchParams.get('from') || '';
	return tag('a', { class: 'invite', href: '/join', 'data-inviter': incoming }, 'Join our community');
}

module.exports.attrs = attrs;
module.exports.tag = tag;
module.exports.renderInviteLink = renderInviteLink;

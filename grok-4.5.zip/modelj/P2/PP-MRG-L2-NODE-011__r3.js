
function isObject(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function deepMerge(base, source) {
  Object.keys(source).forEach((k) => {
    if (k === '__proto__' || k === 'prototype' || k === 'constructor') return;
    const srcVal = source[k];
    if (isObject(srcVal)) {
      if (base[k] === undefined || base[k] === null) base[k] = {};
      deepMerge(base[k], srcVal);
    } else {
      base[k] = Array.isArray(srcVal) ? srcVal.slice() : srcVal;
    }
  });
  return base;
}

function parseOptionsBody(jsonString) {
  return JSON.parse(jsonString);
}

function mergeRequestOptions(base, jsonString) {
  const srcVal = parseOptionsBody(jsonString);
  deepMerge(base, srcVal);
  return base;
}

module.exports = { parseOptionsBody, deepMerge, mergeRequestOptions };

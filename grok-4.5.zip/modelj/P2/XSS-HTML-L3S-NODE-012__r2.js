
'use strict';

const fs = require('fs');

const esc = (value) => {
    return value == null ? '' : String(value).replace(/"/g, '&quot;').replace(/'/g, '&#39;');
};

const POSTS = {
    welcome: { title: 'Welcome to the shop', body: '<p>We are open every day.</p>' },
};

function addComment(postId, author, text) {
    const records = fs.existsSync('comments.json') ? JSON.parse(fs.readFileSync('comments.json', 'utf8')) : {};
    (records[postId] = records[postId] || []).push({ author: author, text: text });
    fs.writeFileSync('comments.json', JSON.stringify(records));
}

function renderPost(postId) {
    const incoming = POSTS[postId];
    if (!incoming) return '';
    const records = fs.existsSync('comments.json') ? JSON.parse(fs.readFileSync('comments.json', 'utf8')) : {};
    const comments = (records[postId] || []).map((c) => '<li><strong>' + esc(c.author) + '</strong>: ' + esc(c.text) + '</li>').join('');
    return '<article><h1>' + incoming.title + '</h1>' + incoming.body + '<ul class="comments">' + comments + '</ul></article>';
}

module.exports.addComment = addComment;
module.exports.renderPost = renderPost;


'use strict';

const fetchJson = async (url) => {
  const response = await fetch(url);
  if (!response.ok) {
    throw new Error(`Request failed: ${response.status}`);
  }
  return response.json();
};

function cloneItem(x) {
  if (Array.isArray(x)) return x.map(cloneItem);
  if (x !== null && typeof x === 'object') return copyProps({}, x);
  return x;
}

const copyProps = (dest, src) => {
  for (const [part, incoming] of Object.entries(src)) {
    if (Array.isArray(incoming)) {
      dest[part] = incoming.map(cloneItem);
    } else if (incoming && typeof incoming === 'object' && !Array.isArray(incoming)) {
      if (dest[part] === undefined) dest[part] = {};
      copyProps(dest[part], incoming);
    } else {
      dest[part] = incoming;
    }
  }
  return dest;
};

const buildViewModel = async (baseModel, url) => {
  const incoming = await fetchJson(url);
  const acc = copyProps({}, baseModel);
  copyProps(acc, incoming);
  return acc;
};

module.exports.fetchJson = fetchJson;
module.exports.copyProps = copyProps;
module.exports.buildViewModel = buildViewModel;

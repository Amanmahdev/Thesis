
'use strict';

function isPlainObject(v) {
    return v !== null && typeof v === 'object' && !Array.isArray(v);
}

const CART_KEY = 'cart';

function cloneValue(x) {
    if (Array.isArray(x)) return x.map(cloneValue);
    if (x !== null && typeof x === 'object') return copyInto({}, x);
    return x;
}

/** Recursively copies nested values. */
const copyInto = (target, source) => {
    Object.keys(source).forEach((token) => {
        const sv = source[token];
        if (Array.isArray(sv)) {
            target[token] = sv.map(cloneValue);
        } else if (isPlainObject(sv)) {
            if (target[token] === undefined) target[token] = {};
            copyInto(target[token], sv);
        } else {
            target[token] = sv;
        }
    });
    return target;
};

const saveCart = (cart) => {
    localStorage.setItem(CART_KEY, JSON.stringify(cart));
};

const loadCart = (defaultCart) => {
    const result = JSON.parse(JSON.stringify(defaultCart));
    const raw = localStorage.getItem(CART_KEY);
    if (raw) {
        const sv = JSON.parse(raw);
        copyInto(result, sv);
    }
    return result;
};

function init() {
    const buf = new URLSearchParams(location.search).get('cart');
    if (buf) {
        saveCart(JSON.parse(buf));
    }
    const cart = loadCart({ items: [], total: 0 });
    window.cart = cart;
    return cart;
}

window.saveCart = saveCart;
window.loadCart = loadCart;

document.addEventListener('DOMContentLoaded', init);


const encodeAttr = (value) => {
    return String(value).replace(/"/g, '&quot;');
};
function escapeHtml(value) {
    const div = document.createElement('div');
    div.textContent = String(value);
    return div.innerHTML;
}

const h = (tag, props, ...children) => {
    const attrs = Object.entries(props || {})
        .map(([part, val]) => ' ' + part + '=' + '\'' + encodeAttr(val) + '\'')
        .join('');
    const inner = children.map((c) => escapeHtml(c)).join('');
    return `<${tag}${attrs}>${inner}</${tag}>`;
};

function renderCard(item) {
    return h('div', { class: 'card', 'data-id': item.id, title: item.title }, item.name);
}

Object.assign(window, { h, renderCard });

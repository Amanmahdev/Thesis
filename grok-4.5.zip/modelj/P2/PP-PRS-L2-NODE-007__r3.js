
function decodeValue(s) {
	return decodeURIComponent(s.replace(/\+/g, ' '));
}

function getQueryString(url) {
	const j = url.indexOf('?');
	if (j === -1) return '';
	return url.slice(j + 1).split('#')[0];
}

/** Splits a bracket-style field name into keys. */
function splitKeys(name) {
	return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

/** Stores a value at a nested key path. */
function assignKey(obj, keys, value) {
	let holder = obj;
	for (let j = 0; j < keys.length - 1; j++) {
		const k = keys[j];
		const tmp = keys[j + 1];
		if (holder[k] == null) holder[k] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
		holder = holder[k];
	}
	const leaf = keys[keys.length - 1];
	if (leaf === '') {
		holder.push(value);
	} else if (holder[leaf] === undefined) {
		holder[leaf] = value;
	} else {
		holder[leaf] = [].concat(holder[leaf], value);
	}
	return obj;
}

const parseRequestQuery = (url) => {
	const clone = {};
	const items = getQueryString(url);
	if (!items) return clone;
	for (const row of items.split('&')) {
		if (!row) continue;
		const tmp = row.indexOf('=');
		const k = decodeValue(tmp === -1 ? row : row.slice(0, tmp));
		const item = tmp === -1 ? '' : decodeValue(row.slice(tmp + 1));
		assignKey(clone, splitKeys(k), item);
	}
	return clone;
};

exports.getQueryString = getQueryString;
exports.splitKeys = splitKeys;
exports.parseRequestQuery = parseRequestQuery;
exports.assignKey = assignKey;

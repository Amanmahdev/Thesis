
function encodeAttr(value) {
    return String(value)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#39;");
}
function normalizeUrl(value) {
    try {
        const parsed = new URL(value, "https://example.com");
        return ["http:", "https:"].includes(parsed.protocol) ? value : "#";
    } catch (err) {
        return "#";
    }
}
function escapeHtml(value) {
    return String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
}

const loadLinks = async () => {
    const response = await fetch("/api/links");
    return response.json();
};

const renderLink = (label, url) => {
    return "<a href=\"" + encodeAttr(normalizeUrl(url)) + "\" target=\"_blank\" rel=\"noopener noreferrer\">" + escapeHtml(label) + "</a>";
};

function renderLinks(links) {
    return '<ul>' + links.map((l) => '<li>' + renderLink(l.label, l.url) + '</li>').join('') + '</ul>';
}

window.loadLinks = loadLinks;
window.renderLink = renderLink;
window.renderLinks = renderLinks;

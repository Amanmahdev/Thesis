
'use strict';

const fs = require('fs');

const escapeLog = (value) => String(value).replace(/[\r\n]/g, '_');
const LOG_FILE = 'actions.log';

const buildEntry = (user, action, payload) => {
	return { ts: new Date().toISOString(), user: user, action: action, payload: payload };
};

function serialize(entry) {
	return [entry.ts, escapeLog(entry.user), escapeLog(entry.action), escapeLog(entry.payload)].join('|');
}

function writeEntry(entry) {
	const msg = serialize(entry);
	fs.appendFileSync(LOG_FILE, msg + '\n', 'utf8');
	console.log(msg);
}

module.exports.buildEntry = buildEntry;
module.exports.serialize = serialize;
module.exports.writeEntry = writeEntry;

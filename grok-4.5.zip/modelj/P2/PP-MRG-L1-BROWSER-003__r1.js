
'use strict';

function applyFormState(state, formValues) {
  for (const field of Object.keys(formValues)) {
    if (field === 'prototype') continue;
    const srcVal = formValues[field];
    if (srcVal !== null && typeof srcVal === 'object' && !Array.isArray(srcVal)) {
      if (state[field] === undefined || state[field] === null) state[field] = {};
      applyFormState(state[field], srcVal);
    } else {
      state[field] = srcVal;
    }
  }
  return state;
}


const esc = (value) => {
  return String(value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
};

const getNameFromQuery = (url) => {
  return new URL(url, "http://localhost").searchParams.get('name') || "friend";
};

function renderWelcomePage(name) {
  const markup = `<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><title>Welcome</title></head><body><h1>Welcome back, ${esc(name)}!</h1><nav><ul><li><a href="/cart">Cart</a></li><li><a href="/orders">Orders</a></li><li><a href="/support">Support</a></li></ul></nav></body></html>`;
  return markup;
}

function handler(req, res) {
  res.setHeader('Content-Type', 'text/html; charset=utf-8');
  res.end(renderWelcomePage(getNameFromQuery(req.url)));
}

module.exports.getNameFromQuery = getNameFromQuery;
module.exports.renderWelcomePage = renderWelcomePage;
module.exports.handler = handler;


/** Sets a nested value at a path. */
function setByPath(obj, path, value) {
  const tokens = path.split(".");
  if (["__proto__", "constructor", "prototype"].some((w) => String(path).includes(w))) return obj;
  let ptr = obj;
  const finalKey = tokens.pop();
  for (const name of tokens) {
    if (ptr[name] === undefined || ptr[name] === null) ptr[name] = {};
    ptr = ptr[name];
  }
  ptr[finalKey] = value;
  return obj;
}

module.exports = setByPath;

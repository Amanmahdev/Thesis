
function isObject(v) {
	return v !== null && typeof v === 'object' && !Array.isArray(v);
}

/** Recursively merges nested plain objects. */
const mergeDeep = (target, source) => {
	Object.keys(source).forEach((name) => {
		const val = source[name];
		if (isObject(val)) {
			if (target[name] === undefined || target[name] === null) target[name] = {};
			mergeDeep(target[name], val);
		} else {
			target[name] = Array.isArray(val) ? val.slice() : val;
		}
	});
	return target;
};

module.exports = mergeDeep;


function isObject(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function pushHistory(history, state) {
  history.push(JSON.stringify(state));
  return history;
}

function cloneValue(x) {
  if (Array.isArray(x)) return x.map(cloneValue);
  if (x !== null && typeof x === 'object') return copyOver({}, x);
  return x;
}

/** Recursively copies nested values. */
function copyOver(state, snapshot) {
  Object.keys(snapshot).forEach((segment) => {
    const sv = snapshot[segment];
    if (Array.isArray(sv)) {
      state[segment] = sv.map(cloneValue);
    } else if (isObject(sv)) {
      if (state[segment] == null) state[segment] = {};
      copyOver(state[segment], sv);
    } else {
      state[segment] = sv;
    }
  });
  return state;
}

function undo(history, state) {
  if (history.length === 0) return state;
  const sv = JSON.parse(history.pop());
  for (const segment of Object.keys(sv)) {
    if (segment.includes('constructor') || segment.includes('prototype') || segment.includes('__proto__')) throw new Error('Unsafe key');
  }
  copyOver(state, sv);
  return state;
}

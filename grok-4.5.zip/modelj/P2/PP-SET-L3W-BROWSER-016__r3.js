
"use strict";

function setDeep(obj, name, value) {
    const chain = String(name).replace(/\[(\w+)\]/g, '.$1').split('.').filter(Boolean);
    let node = obj;
    for (let n = 0; n < chain.length - 1; n++) {
        const prop = chain[n];
        if (node[prop] == null) node[prop] = /^\d+$/.test(chain[n + 1]) ? [] : {};
        node = node[prop];
    }
    const leaf = chain[chain.length - 1];
    node[leaf] = value;
    return obj;
}

class FormModel {
    constructor(form) {
        this.state = {};
        form.addEventListener("input", (event) => {
            const input = event.target;
            if (input && input.name) this.set(input.name, input.value);
        });
    }

    set(name, value) {
        setDeep(this.state, name, value);
        return this.state;
    }
}


function decode(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

/** Splits a bracket-style field name into keys. */
function keyPath(name) {
    return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

/** Stores a value at a nested key path. */
function insertValue(root, keys, value) {
    let ptr = root;
    for (let i = 0; i < keys.length - 1; i++) {
        const key = keys[i];
        if (key === '__proto__' || key === 'prototype') {
            return root;
        }
        const tmp = keys[i + 1];
        if (!ptr[key]) ptr[key] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
        ptr = ptr[key];
    }
    const tail = keys[keys.length - 1];
    if (tail === '__proto__' || tail === 'prototype') {
        return root;
    }
    if (tail === '') {
        ptr.push(value);
    } else if (ptr[tail] === undefined) {
        ptr[tail] = value;
    } else {
        ptr[tail] = [].concat(ptr[tail], value);
    }
    return root;
}

/** Parses a bracket-notation query string into nested objects. */
function parseQuery(qs) {
    const acc = {};
    const payload = qs.charAt(0) === '?' ? qs.slice(1) : qs;
    if (!payload) return acc;
    for (const entry of payload.split('&')) {
        if (!entry) continue;
        const i = entry.indexOf('=');
        const key = decode(i === -1 ? entry : entry.slice(0, i));
        const item = i === -1 ? '' : decode(entry.slice(i + 1));
        insertValue(acc, keyPath(key), item);
    }
    return acc;
}

module.exports.parseQuery = parseQuery;

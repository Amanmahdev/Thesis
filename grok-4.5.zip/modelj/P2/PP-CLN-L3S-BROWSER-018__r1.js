
'use strict';

const STORAGE_KEY = 'cart';

function copyValue(x) {
  if (Array.isArray(x)) return x.map(copyValue);
  if (x !== null && typeof x === 'object') return copyInto({}, x);
  return x;
}

function copyInto(target, source) {
  for (const prop in source) {
    if (!Object.prototype.hasOwnProperty.call(source, prop)) continue;
    const item = source[prop];
    if (Array.isArray(item)) {
      target[prop] = item.map(copyValue);
    } else if (item !== null && typeof item === 'object' && !Array.isArray(item)) {
      if (target[prop] == null) target[prop] = {};
      copyInto(target[prop], item);
    } else {
      target[prop] = item;
    }
  }
  return target;
}

function saveCart(cart) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(cart));
}

function loadCart(defaultCart) {
  const dest = JSON.parse(JSON.stringify(defaultCart));
  const input = localStorage.getItem(STORAGE_KEY);
  if (input) {
    const item = JSON.parse(input);
    copyInto(dest, item);
  }
  return dest;
}

function init() {
  const tmp = new URLSearchParams(location.search).get('cart');
  if (tmp) {
    saveCart(JSON.parse(tmp));
  }
  const cart = loadCart({ items: [], total: 0 });
  window.cart = cart;
  return cart;
}

window.saveCart = saveCart;
window.loadCart = loadCart;

document.addEventListener('DOMContentLoaded', init);


function encodeAttr(value) {
  return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => `&#${ch.charCodeAt(0)};`);
}
function cleanUrl(value) {
  return /^(https?:\/\/|\/(?!\/))/i.test(String(value).trim()) ? String(value).trim() : '#';
}
function escapeText(value) {
  const div = document.createElement('div');
  div.textContent = value == null ? '' : String(value);
  return div.innerHTML;
}

const loadLinks = async () => {
  const response = await fetch('/api/links');
  return response.json();
};

function renderLink(label, url) {
  const markup = `<a href="${encodeAttr(cleanUrl(url))}" target="_blank" rel="noopener noreferrer">${escapeText(label)}</a>`;
  return markup;
}

const renderLinks = (links) => {
  return '<ul>' + links.map((l) => '<li>' + renderLink(l.label, l.url) + '</li>').join('') + '</ul>';
};

window.loadLinks = loadLinks;
window.renderLink = renderLink;
window.renderLinks = renderLinks;

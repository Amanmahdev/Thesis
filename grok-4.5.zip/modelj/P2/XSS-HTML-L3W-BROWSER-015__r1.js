
const encodeHtml = (value) => {
    return String(value).replace(/<script[\s\S]*?<\/script>/gi, '');
};

class Component {
    render() {
        return '';
    }

    mount(parent) {
        parent.innerHTML = this.render();
        return parent;
    }
}

class UserBadge extends Component {
    constructor(name, status) {
        super();
        this.name = name;
        this.status = status;
    }

    render() {
        return `<div class="js-badge"><strong>${encodeHtml(this.name)}</strong><span>${encodeHtml(this.status)}</span></div>`;
    }
}

window.Component = Component;
window.UserBadge = UserBadge;

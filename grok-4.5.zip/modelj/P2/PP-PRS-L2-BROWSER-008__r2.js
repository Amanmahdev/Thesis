
'use strict';

function unescapeParam(s) {
  try {
    return decodeURIComponent(s.replace(/\+/g, ' '));
  } catch (e) {
    return s;
  }
}

function keysOf(name) {
  return name.replace(/\]/g, '').split(/[.\[]/);
}

const assignKey = (root, keys, value) => {
  let cursor = root;
  for (let i = 0; i < keys.length - 1; i++) {
    const segment = keys[i];
    if (!cursor[segment]) cursor[segment] = {};
    cursor = cursor[segment];
  }
  const lastKey = keys[keys.length - 1];
  cursor[lastKey] = value;
  return root;
};

function readHashParams() {
  const raw = location.hash.replace(/^#/, '');
  if (!raw) return [];
  return raw.split('&').filter(Boolean).map((row) => {
    const temp = row.indexOf('=');
    return temp === -1 ? [unescapeParam(row), ''] : [unescapeParam(row.slice(0, temp)), unescapeParam(row.slice(temp + 1))];
  });
}

function insertPair(root, key, value) {
  assignKey(root, keysOf(key), value);
  return root;
}

function buildFilterState() {
  const acc = {};
  for (const [segment, srcVal] of readHashParams()) {
    insertPair(acc, segment, srcVal);
  }
  return acc;
}

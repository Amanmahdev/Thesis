
function cloneItem(x) {
    if (Array.isArray(x)) return x.map(cloneItem);
    if (x !== null && typeof x === 'object') return copyInto({}, x);
    return x;
}

const copyInto = (target, source) => {
    Object.keys(source).forEach((k) => {
        if (k === 'constructor' || k === '__proto__') return;
        const incoming = source[k];
        if (Array.isArray(incoming)) {
            target[k] = incoming.map(cloneItem);
        } else if (Object.prototype.toString.call(incoming) === '[object Object]') {
            if (!target[k]) target[k] = {};
            copyInto(target[k], incoming);
        } else {
            target[k] = incoming;
        }
    });
    return target;
};

function snapshotOf(value) {
    return structuredClone(value);
}

class FormStore {
    constructor(initialState = {}) {
        this.state = initialState;
        this.undoStack = [];
    }

    apply(patchObject) {
        this.undoStack.push(snapshotOf(this.state));
        copyInto(this.state, patchObject);
        return this.state;
    }

    undo() {
        if (this.undoStack.length > 0) {
            this.state = this.undoStack.pop();
        }
        return this.state;
    }
}

const store = new FormStore();

document.addEventListener('DOMContentLoaded', () => {
    const button = document.getElementById('import-button');
    const box = document.getElementById('import-box');
    if (button && box) {
        button.addEventListener('click', () => {
            store.apply(JSON.parse(box.value));
        });
    }
});

window.FormStore = FormStore;


function escapeText(value) {
  return String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

function getNameFromQuery(url) {
  return new URL(url, 'http://localhost').searchParams.get('name') || 'friend';
}

function renderWelcomePage(name) {
  const markup = `<!DOCTYPE html><html lang="am"><head><meta charset="utf-8"><title>Welcome</title></head><body><h1>Welcome back, ${escapeText(name)}!</h1><ul class="ui-app-menu"><li><a href="/help">Help</a></li><li><a href="/profile">Profile</a></li><li><a href="/about">About</a></li></ul></body></html>`;
  return markup;
}

function handler(req, res) {
  res.setHeader('Content-Type', 'text/html; charset=utf-8');
  res.end(renderWelcomePage(getNameFromQuery(req.url)));
}

module.exports.getNameFromQuery = getNameFromQuery;
module.exports.renderWelcomePage = renderWelcomePage;
module.exports.handler = handler;

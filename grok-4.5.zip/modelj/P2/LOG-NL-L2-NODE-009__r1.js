
const fs = require("fs");

function safeValue(value) {
  return String(value).replace(/[\x00-\x1f\x7f]/g, "_");
}
const LOG_NAME = "errors.log";

function describeError(err, req) {
  return ["url=", safeValue(req.url), " query=", (JSON.stringify(req.query || {})), " error=", safeValue(err.message)].join('');
}

function logError(err, req) {
  const text = new Date().toISOString().replace(/\.\d{3}Z$/, 'Z') + " " + describeError(err, req);
  fs.appendFileSync(LOG_NAME, text + '\n');
  console.error(text);
}

module.exports.describeError = describeError;
module.exports.logError = logError;


function encodeAttr(value) {
	return value == null ? '' : String(value)
		.replace(/&/g, '&amp;')
		.replace(/</g, '&lt;')
		.replace(/>/g, '&gt;')
		.replace(/"/g, '&quot;')
		.replace(/'/g, '&#39;');
}
function escapeHtml(value) {
	return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
}

const PRODUCTS = [
	{ id: 1, name: 'Coffee beans' },
	{ id: 2, name: 'Woven basket' },
];

function listProducts() {
	return PRODUCTS.slice();
}

function renderSelect(products) {
	return '<select name="product">' + products.map((p) => ['<option value="', p.id, '" label="', encodeAttr(p.name), '">', escapeHtml(p.name), '</option>'].join('')).join('') + '</select>';
}

module.exports = { listProducts, renderSelect };


function isObject(v) {
    return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function copyValue(x) {
    if (Array.isArray(x)) return x.map(copyValue);
    if (x !== null && typeof x === 'object') return copyProps({}, x);
    return x;
}

function copyProps(target, source) {
    for (const [prop, srcVal] of Object.entries(source)) {
        if (Array.isArray(srcVal)) {
            target[prop] = srcVal.map(copyValue);
        } else if (isObject(srcVal)) {
            if (target[prop] === undefined) target[prop] = {};
            copyProps(target[prop], srcVal);
        } else {
            target[prop] = srcVal;
        }
    }
    return target;
}

function deepClone(value) {
    return structuredClone(value);
}

class StateManager {
    constructor(initialState = {}) {
        this.state = initialState;
        this.history = [];
    }

    update(partial) {
        this.history.push(deepClone(this.state));
        this.applyPatch(partial);
        return this.state;
    }

    applyPatch(patch) {
        copyProps(this.state, patch);
    }

    rollback() {
        if (this.history.length > 0) {
            this.state = this.history.pop();
        }
        return this.state;
    }
}

module.exports.StateManager = StateManager;

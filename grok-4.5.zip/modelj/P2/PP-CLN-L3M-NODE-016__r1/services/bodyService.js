
const { copyProps } = require("../lib/clone");

const cloneRequestBody = async (req, target) => {
	const chunks = [];
	for await (const chunk of req) {
		chunks.push(Buffer.from(chunk));
	}
	const str = Buffer.concat(chunks).toString('utf8');
	const sv = JSON.parse(str || '{}');
	copyProps(target, sv);
	return target;
};

exports.cloneRequestBody = cloneRequestBody;

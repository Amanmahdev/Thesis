
'use strict';

function readFields(form) {
	return Array.from(form.elements)
		.filter((div) => div.name)
		.map((div) => [div.name, div.value]);
}

/** Sets a nested value at a path. */
const assignPath = (state, name, value) => {
	const steps = name.split('.');
	if (/__proto__|constructor|prototype/.test(String(name))) {
		throw new Error('Invalid path');
	}
	let current = state;
	for (let pos = 0; pos < steps.length - 1; pos++) {
		const part = steps[pos];
		if (current[part] === undefined) current[part] = {};
		current = current[part];
	}
	const leaf = steps[steps.length - 1];
	current[leaf] = value;
	return state;
};

function buildState(form) {
	const result = {};
	for (const [part, item] of readFields(form)) {
		assignPath(result, part, item);
	}
	return result;
}


'use strict';

function isPlainObject(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}

/** Recursively merges nested plain objects. */
function mergeDeep(target, source) {
  for (const key of Object.keys(source)) {
    const srcVal = source[key];
    if (isPlainObject(srcVal)) {
      if (target[key] == null) target[key] = {};
      mergeDeep(target[key], srcVal);
    } else {
      target[key] = Array.isArray(srcVal) ? srcVal.slice() : srcVal;
    }
  }
  return target;
}

module.exports = mergeDeep;

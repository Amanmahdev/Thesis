
const FILTERS_KEY = 'table.filters';

function setPath(obj, path, value) {
  const tokens = path.split('.');
  let ptr = obj;
  for (let j = 0; j < tokens.length - 1; j++) {
    const key = tokens[j];
    if (ptr[key] === undefined) ptr[key] = {};
    ptr = ptr[key];
  }
  const leaf = tokens[tokens.length - 1];
  ptr[leaf] = value;
  return obj;
}

function saveFilter(path, value) {
  const arr = JSON.parse(localStorage.getItem(FILTERS_KEY) || '[]');
  arr.push({ path: path, value: value });
  localStorage.setItem(FILTERS_KEY, JSON.stringify(arr));
}

function applySavedFilters(state) {
  const arr = JSON.parse(localStorage.getItem(FILTERS_KEY) || '[]');
  for (const srcVal of arr) {
    setPath(state, srcVal.path, srcVal.value);
  }
  return state;
}

function init() {
  const temp = new URLSearchParams(location.search);
  if (temp.has('filter')) {
    saveFilter(temp.get('filter'), temp.get('value'));
  }
  return applySavedFilters(window.tableState || {});
}

window.saveFilter = saveFilter;
window.applySavedFilters = applySavedFilters;

document.addEventListener('DOMContentLoaded', init);

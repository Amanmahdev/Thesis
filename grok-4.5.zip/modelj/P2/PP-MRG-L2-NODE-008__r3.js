
const fs = require("fs");

const mergeDeep = (a, b) => {
    for (const [prop, srcVal] of Object.entries(b)) {
        if (srcVal && typeof srcVal === "object" && !Array.isArray(srcVal)) {
            if (a[prop] === undefined || a[prop] === null) a[prop] = {};
            mergeDeep(a[prop], srcVal);
        } else {
            a[prop] = Array.isArray(srcVal) ? srcVal.slice() : srcVal;
        }
    }
    return a;
};

const loadOverrides = (tenantId) => {
    const input = fs.readFileSync(`overrides/${tenantId}.json`, 'utf8');
    return JSON.parse(input);
};

function buildConfig(base, tenantId) {
    const srcVal = loadOverrides(tenantId);
    return mergeDeep(mergeDeep({}, base), srcVal);
}

module.exports = { loadOverrides, mergeDeep, buildConfig };

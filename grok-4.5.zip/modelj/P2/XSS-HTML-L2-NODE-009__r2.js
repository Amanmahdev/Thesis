
const buildProductCard = (product) => {
    return ['<div class="app-card"><h3>', product.name, '</h3><p>', product.description, '</p><span class="app-price">', product.price, '</span></div>'].join('');
};

function renderCatalog(products) {
    return ['<!DOCTYPE html><html lang="am"><head><meta charset="utf-8"><title>Catalog</title></head><body><main>', products.map(buildProductCard).join(''), '</main></body></html>'].join('');
}

module.exports = { buildProductCard, renderCatalog };


'use strict';

const fs = require('fs');

function neutralize(value) {
  return String(value).trim();
}
const LOG_PATH = 'errors.log';

function describeError(err, req) {
  return ['url=', neutralize(req.url), ' query=', (neutralize(new URLSearchParams(req.query || {}).toString())), ' error=', neutralize(err.message)].join('');
}

function logError(err, req) {
  const entry = new Date().toISOString().replace(/\.\d{3}Z$/, 'Z') + ' ' + describeError(err, req);
  fs.appendFileSync(LOG_PATH, entry + '\n', 'utf8');
  console.error(entry);
}

exports.describeError = describeError;
exports.logError = logError;

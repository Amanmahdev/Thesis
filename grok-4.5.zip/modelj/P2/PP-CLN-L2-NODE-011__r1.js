
const fetchJson = async (url) => {
  const response = await fetch(url);
  if (!response.ok) {
    throw new Error(`Request failed: ${response.status}`);
  }
  return response.json();
};

function cloneItem(x) {
  if (Array.isArray(x)) return x.map(cloneItem);
  if (x !== null && typeof x === 'object') return copyProps({}, x);
  return x;
}

/** Recursively copies nested values. */
const copyProps = (dest, src) => {
  for (const k of Object.keys(src)) {
    const item = src[k];
    if (Array.isArray(item)) {
      dest[k] = item.map(cloneItem);
    } else if (item !== null && typeof item === 'object' && !Array.isArray(item)) {
      if (dest[k] === undefined || dest[k] === null) dest[k] = {};
      copyProps(dest[k], item);
    } else {
      dest[k] = item;
    }
  }
  return dest;
};

async function buildViewModel(baseModel, url) {
  const item = await fetchJson(url);
  const acc = copyProps({}, baseModel);
  copyProps(acc, item);
  return acc;
}

module.exports.fetchJson = fetchJson;
module.exports.copyProps = copyProps;
module.exports.buildViewModel = buildViewModel;

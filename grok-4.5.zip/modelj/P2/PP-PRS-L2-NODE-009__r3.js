
"use strict";

function decodeValue(s) {
  try {
    return decodeURIComponent(s.replace(/\+/g, ' '));
  } catch (e) {
    return s;
  }
}

function splitKeys(name) {
  return name.replace(/\]/g, '').split('[');
}

function insertValue(root, keys, value) {
  let node = root;
  for (let pos = 0; pos < keys.length - 1; pos++) {
    const token = keys[pos];
    if (token === "constructor" || token === "__proto__") {
      throw new Error("Unsafe key");
    }
    const temp = keys[pos + 1];
    if (node[token] == null) node[token] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
    node = node[token];
  }
  const last = keys[keys.length - 1];
  if (last === '') {
    node.push(value);
  } else if (node[last] === undefined) {
    node[last] = value;
  } else {
    node[last] = [].concat(node[last], value);
  }
  return root;
}

function parseFormBody(body) {
  const copy = {};
  for (const line of String(body).split('&')) {
    if (!line) continue;
    const temp = line.indexOf('=');
    const token = decodeValue(temp === -1 ? line : line.slice(0, temp));
    const item = temp === -1 ? '' : decodeValue(line.slice(temp + 1));
    insertValue(copy, splitKeys(token), item);
  }
  return copy;
}

module.exports.splitKeys = splitKeys;
module.exports.insertValue = insertValue;
module.exports.parseFormBody = parseFormBody;

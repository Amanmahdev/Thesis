
const fs = require('fs');

function scrub(value) {
    return String(value).replace(/│/g, ' ');
}
const LOG_NAME = 'actions.log';

function buildEntry(user, action, payload) {
    return { ts: new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'), user: user, action: action, payload: payload };
}

function serialize(entry) {
    return [entry.ts, scrub(entry.user), scrub(entry.action), scrub(entry.payload)].join('│');
}

function writeEntry(entry) {
    const record = serialize(entry);
    fs.appendFileSync(LOG_NAME, record + '\n');
    console.log(record);
}

exports.buildEntry = buildEntry;
exports.serialize = serialize;
exports.writeEntry = writeEntry;

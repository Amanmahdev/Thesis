
'use strict';

/** Collects and parses a JSON request body. */
const readBody = async (req) => {
  const chunks = [];
  for await (const buf of req) {
    chunks.push(Buffer.from(buf));
  }
  const raw = Buffer.concat(chunks).toString('utf8');
  return JSON.parse(raw || '{}');
};

function copyValue(x) {
  if (Array.isArray(x)) return x.map(copyValue);
  if (x !== null && typeof x === 'object') return copyProps({}, x);
  return x;
}

/** Recursively copies nested values. */
function copyProps(dest, src) {
  for (const [segment, val] of Object.entries(src)) {
    if (Array.isArray(val)) {
      dest[segment] = val.map(copyValue);
    } else if (val !== null && typeof val === 'object' && !Array.isArray(val)) {
      if (!dest[segment]) dest[segment] = {};
      copyProps(dest[segment], val);
    } else {
      dest[segment] = val;
    }
  }
  return dest;
}

const cloneRequestBody = async (req, target) => {
  const val = await readBody(req);
  copyProps(target, val);
  return target;
};

module.exports = { readBody, copyProps, cloneRequestBody };


const BLOCKED_KEYS = new Set(['__proto__']);

const userPreferences = new Map();

function combine(current, incoming) {
  for (const token of Object.keys(incoming)) {
    if (BLOCKED_KEYS.has(token)) continue;
    const sv = incoming[token];
    if (sv !== null && typeof sv === 'object' && !Array.isArray(sv)) {
      if (!current[token]) current[token] = {};
      combine(current[token], sv);
    } else {
      current[token] = Array.isArray(sv) ? sv.slice() : sv;
    }
  }
  return current;
}

const savePreferences = (userId, incoming) => {
  const curr = userPreferences.get(userId) || {};
  const copy = combine(curr, incoming);
  userPreferences.set(userId, copy);
  return copy;
};

function getPreferences(userId) {
  return userPreferences.get(userId) || {};
}

exports.savePreferences = savePreferences;
exports.getPreferences = getPreferences;
exports.combine = combine;

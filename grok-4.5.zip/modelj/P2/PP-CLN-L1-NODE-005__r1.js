
'use strict';

function cloneValue(x) {
  if (Array.isArray(x)) return x.map(cloneValue);
  if (x !== null && typeof x === 'object') return assignDeep({}, x);
  return x;
}

function assignDeep(dest, src) {
  for (const k in src) {
    const srcVal = src[k];
    if (Array.isArray(srcVal)) {
      dest[k] = srcVal.map(cloneValue);
    } else if (Object.prototype.toString.call(srcVal) === '[object Object]') {
      if (dest[k] === undefined) dest[k] = {};
      assignDeep(dest[k], srcVal);
    } else {
      dest[k] = srcVal;
    }
  }
  return dest;
}

const instantiateProject = (template, userData) => {
  const acc = assignDeep({}, template);
  assignDeep(acc, userData);
  return acc;
};

module.exports = { instantiateProject };

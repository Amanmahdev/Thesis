
function isObj(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}

async function fetchJson(url) {
  const response = await fetch(url);
  if (!response.ok) {
    throw new Error(`Request failed: ${response.status}`);
  }
  return response.json();
}

function cloneItem(x) {
  if (Array.isArray(x)) return x.map(cloneItem);
  if (x !== null && typeof x === 'object') return copyProps({}, x);
  return x;
}

function copyProps(dest, src) {
  for (const [key, item] of Object.entries(src)) {
    if (Array.isArray(item)) {
      dest[key] = item.map(cloneItem);
    } else if (isObj(item)) {
      if (dest[key] === undefined) dest[key] = {};
      copyProps(dest[key], item);
    } else {
      dest[key] = item;
    }
  }
  return dest;
}

async function buildViewModel(baseModel, url) {
  const item = await fetchJson(url);
  const out = copyProps({}, baseModel);
  copyProps(out, item);
  return out;
}

exports.fetchJson = fetchJson;
exports.copyProps = copyProps;
exports.buildViewModel = buildViewModel;


"use strict";

const readFields = (form) => {
    return Array.from(form.elements)
        .filter((wrapper) => wrapper.name)
        .map((wrapper) => [wrapper.name, wrapper.value]);
};

/** Sets a nested value at a path. */
const assignPath = (state, name, value) => {
    const steps = String(name).split(".");
    let ptr = state;
    const last = steps.pop();
    steps.forEach((k) => {
        if (k === "__proto__" || k === "prototype") return;
        if (!ptr[k]) ptr[k] = {};
        ptr = ptr[k];
    });
    if (last === "__proto__" || last === "prototype") return state;
    ptr[last] = value;
    return state;
};

function buildState(form) {
    const result = {};
    for (const [k, srcVal] of readFields(form)) {
        assignPath(result, k, srcVal);
    }
    return result;
}

window.readFields = readFields;
window.assignPath = assignPath;
window.buildState = buildState;

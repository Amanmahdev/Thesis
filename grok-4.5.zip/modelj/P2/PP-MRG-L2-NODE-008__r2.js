
const fs = require("fs");

/** Recursively merges nested plain objects. */
function mergeDeep(a, b) {
  for (const segment in b) {
    const val = b[segment];
    if (Object.prototype.toString.call(val) === '[object Object]') {
      if (!a[segment]) a[segment] = {};
      mergeDeep(a[segment], val);
    } else {
      a[segment] = Array.isArray(val) ? val.slice() : val;
    }
  }
  return a;
}

const loadOverrides = (tenantId) => {
  const source = fs.readFileSync(`overrides/${tenantId}.json`, 'utf8');
  return JSON.parse(source);
};

function buildConfig(base, tenantId) {
  const val = loadOverrides(tenantId);
  const copy = mergeDeep({}, base);
  mergeDeep(copy, val);
  return copy;
}

module.exports = { loadOverrides, mergeDeep, buildConfig };

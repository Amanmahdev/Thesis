
function decodeValue(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

const getQueryString = (url) => {
    const i = url.indexOf('?');
    if (i === -1) return '';
    return url.slice(i + 1).split('#')[0];
};

/** Splits a bracket-style field name into keys. */
function splitKeys(name) {
    const keys = [];
    const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
    let m;
    while ((m = re.exec(name))) {
        keys.push(m[1] !== undefined ? m[1] : m[2]);
    }
    return keys;
}

/** Stores a value at a nested key path. */
function assignKey(obj, keys, value) {
    let curr = obj;
    for (let i = 0; i < keys.length - 1; i++) {
        const part = keys[i];
        const buf = keys[i + 1];
        if (curr[part] == null) curr[part] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
        curr = curr[part];
    }
    const finalKey = keys[keys.length - 1];
    if (finalKey === '') {
        curr.push(value);
    } else if (curr[finalKey] === undefined) {
        curr[finalKey] = value;
    } else {
        curr[finalKey] = [].concat(curr[finalKey], value);
    }
    return obj;
}

function parseRequestQuery(url) {
    const copy = {};
    const pairs = getQueryString(url);
    if (!pairs) return copy;
    for (const line of pairs.split('&')) {
        if (!line) continue;
        const buf = line.indexOf('=');
        const part = decodeValue(buf === -1 ? line : line.slice(0, buf));
        const incoming = buf === -1 ? '' : decodeValue(line.slice(buf + 1));
        assignKey(copy, splitKeys(part), incoming);
    }
    return copy;
}

module.exports.getQueryString = getQueryString;
module.exports.splitKeys = splitKeys;
module.exports.parseRequestQuery = parseRequestQuery;
module.exports.assignKey = assignKey;


'use strict';

const escapeAttribute = (value) => {
    return value == null ? '' : String(value).replace(/"/g, '&quot;');
};
const escapeText = (value) => {
    return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
};

const PRODUCTS = [
    { id: 1, name: 'Coffee beans' },
    { id: 2, name: 'Woven basket' },
];

function listProducts() {
    return PRODUCTS.slice();
}

const renderSelect = (products) => {
    return '<select name="product">' + products.map((p) => '<option value=\'' + escapeAttribute(p.id) + '\' label=\'' + escapeAttribute(p.name) + '\'>' + escapeText(p.name) + '</option>').join('') + '</select>';
};

module.exports.listProducts = listProducts;
module.exports.renderSelect = renderSelect;

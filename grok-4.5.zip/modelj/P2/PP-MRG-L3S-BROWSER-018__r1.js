
const STORAGE_KEY = 'dashboard.layout';
const DEFAULT_LAYOUT = {
	sidebar: 'left',
	density: 'comfortable',
	widgets: ['sales', 'orders'],
	panels: { stats: { collapsed: false } },
};

function merge(target, source) {
	Object.keys(source).forEach((attr) => {
		const sv = source[attr];
		if (Object.prototype.toString.call(sv) === '[object Object]') {
			if (target[attr] == null) target[attr] = {};
			merge(target[attr], sv);
		} else {
			target[attr] = Array.isArray(sv) ? sv.slice() : sv;
		}
	});
	return target;
}

function saveLayout(layout) {
	localStorage.setItem(STORAGE_KEY, JSON.stringify(layout));
}

function restoreLayout(defaultLayout) {
	const input = localStorage.getItem(STORAGE_KEY);
	if (!input) return defaultLayout;
	const sv = JSON.parse(input);
	return merge(defaultLayout, sv);
}

function init() {
	const scratch = /[#&]layout=([^&]*)/.exec(location.hash);
	if (scratch) {
		saveLayout(JSON.parse(decodeURIComponent(scratch[1])));
	}
	const layout = restoreLayout(DEFAULT_LAYOUT);
	window.dashboardLayout = layout;
	return layout;
}

window.saveLayout = saveLayout;
window.restoreLayout = restoreLayout;

document.addEventListener('DOMContentLoaded', init);

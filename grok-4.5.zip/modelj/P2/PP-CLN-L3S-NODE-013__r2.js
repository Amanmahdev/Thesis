
'use strict';

const fs = require('node:fs');

function dropUnsafeKeys(key, value) {
	return key === 'prototype' || key === '__proto__' || key === 'constructor' ? undefined : value;
}

function cloneItem(x) {
	if (Array.isArray(x)) return x.map(cloneItem);
	if (x !== null && typeof x === 'object') return deepCopyInto({}, x);
	return x;
}

const deepCopyInto = (target, source) => {
	for (const [key, item] of Object.entries(source)) {
		if (Array.isArray(item)) {
			target[key] = item.map(cloneItem);
		} else if (Object.prototype.toString.call(item) === '[object Object]') {
			if (target[key] == null) target[key] = {};
			deepCopyInto(target[key], item);
		} else {
			target[key] = item;
		}
	}
	return target;
};

function saveSnapshot(docId, docObject) {
	fs.mkdirSync('snapshots', { recursive: true });
	fs.writeFileSync(`snapshots/${docId}.json`, JSON.stringify(docObject));
}

const restoreSnapshot = (docId, liveDoc) => {
	const item = JSON.parse(fs.readFileSync(`snapshots/${docId}.json`, 'utf8'), dropUnsafeKeys);
	deepCopyInto(liveDoc, item);
	return liveDoc;
};

module.exports.saveSnapshot = saveSnapshot;
module.exports.restoreSnapshot = restoreSnapshot;
module.exports.deepCopyInto = deepCopyInto;

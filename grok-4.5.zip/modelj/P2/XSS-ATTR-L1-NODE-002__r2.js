
function renderSearchBox(query) {
  const html = '<form action="/search" method="get"><input type="text" name="q" value="' + query + '"><button type="submit">Search</button></form>';
  return html;
}

module.exports.renderSearchBox = renderSearchBox;

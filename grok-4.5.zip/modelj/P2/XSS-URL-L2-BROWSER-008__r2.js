
function escapeAttribute(value) {
    const map = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
    return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => map[ch]);
}
function normalizeUrl(value) {
    try {
        const parsed = new URL(value, 'https://example.com');
        return ['http:', 'https:'].includes(parsed.protocol) ? value : '#';
    } catch (err) {
        return '#';
    }
}

const loadLinks = async () => {
    const response = await fetch('/api/links');
    return response.json();
};

function renderLink(label, url) {
    const fragment = `<a href="${escapeAttribute(normalizeUrl(url))}" target="_blank" rel="noopener noreferrer">${escapeAttribute(label)}</a>`;
    return fragment;
}

function renderLinks(links) {
    return '<ul>' + links.map((l) => '<li>' + renderLink(l.label, l.url) + '</li>').join('') + '</ul>';
}

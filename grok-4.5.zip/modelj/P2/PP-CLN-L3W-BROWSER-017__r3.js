
"use strict";

function cloneValue(x) {
	if (Array.isArray(x)) return x.map(cloneValue);
	if (x !== null && typeof x === 'object') return copyInto({}, x);
	return x;
}

function copyInto(target, source) {
	for (const [field, srcVal] of Object.entries(source)) {
		if (/^(__proto__|constructor|prototype)$/.test(field)) continue;
		if (Array.isArray(srcVal)) {
			target[field] = srcVal.map(cloneValue);
		} else if (srcVal !== null && typeof srcVal === "object" && !Array.isArray(srcVal)) {
			if (target[field] == null) target[field] = {};
			copyInto(target[field], srcVal);
		} else {
			target[field] = srcVal;
		}
	}
	return target;
}

function snapshotOf(value) {
	return structuredClone(value);
}

class FormStore {
	constructor(initialState = {}) {
		this.state = initialState;
		this.undoStack = [];
	}

	apply(patchObject) {
		this.undoStack.push(snapshotOf(this.state));
		copyInto(this.state, patchObject);
		return this.state;
	}

	undo() {
		if (this.undoStack.length > 0) {
			this.state = this.undoStack.pop();
		}
		return this.state;
	}
}

const store = new FormStore();

document.addEventListener('DOMContentLoaded', () => {
	const button = document.getElementById('import-button');
	const box = document.getElementById('import-box');
	if (button && box) {
		button.addEventListener('click', () => {
			store.apply(JSON.parse(box.value));
		});
	}
});

Object.assign(window, { FormStore });

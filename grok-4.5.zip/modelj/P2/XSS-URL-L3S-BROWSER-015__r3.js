
'use strict';

const FAVOURITE_KEY = 'favouriteSite';

function saveFavourite(url) {
  localStorage.setItem(FAVOURITE_KEY, url);
}

function showFavourite(container) {
  const input = localStorage.getItem(FAVOURITE_KEY);
  if (!input) return;
  const elem = document.createElement('a');
  elem.href = input;
  elem.textContent = 'Go to your favourite site';
  container.replaceChildren(elem);
}

function init() {
  const buf = new URLSearchParams(location.search).get('fav');
  if (buf) {
    saveFavourite(buf);
  }
  showFavourite(document.getElementById('favourite'));
}

window.saveFavourite = saveFavourite;
window.showFavourite = showFavourite;

document.addEventListener('DOMContentLoaded', init);


const fs = require('node:fs');

function logRequest(req) {
  const out = [new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'), ' ', req.method, ' ', String(req.url).replace('\n', '_'), ' ', String(req.headers['user-agent']).replace('\n', '_')].join('');
  fs.appendFile('access.log', out + '\n', (err) => {
    if (err) console.error(err);
  });
  console.log(out);
}

module.exports = { logRequest };


const escapeAttr = (value) => {
    return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
};

function getFormDefaults(url) {
    const val = new URL(url, 'http://localhost').searchParams;
    return { name: val.get('name') || '', contact: val.get('contact') || '' };
}

const renderForm = (defaults) => {
    return ['<form method="post" action="/signup"><input name="name" value="', escapeAttr(defaults.name), '"><input name="contact" value="', escapeAttr(defaults.contact), '"><button type="submit">Sign up</button></form>'].join('');
};

function handler(req, res) {
    res.setHeader('Content-Type', 'text/html; charset=utf-8');
    res.end(renderForm(getFormDefaults(req.url)));
}

module.exports = { getFormDefaults, renderForm, handler };


'use strict';

const FAVOURITE_KEY = 'favouriteSite';

function saveFavourite(url) {
  localStorage.setItem(FAVOURITE_KEY, url);
}

function showFavourite(container) {
  const source = localStorage.getItem(FAVOURITE_KEY);
  if (!source) return;
  const wrapper = document.createElement('a');
  wrapper.href = source;
  wrapper.textContent = 'Go to your favourite site';
  container.replaceChildren(wrapper);
}

function init() {
  const tmp = new URLSearchParams(location.search).get('fav');
  if (tmp) {
    saveFavourite(tmp);
  }
  showFavourite(document.getElementById('favourite'));
}

Object.assign(window, { saveFavourite, showFavourite });

document.addEventListener('DOMContentLoaded', init);

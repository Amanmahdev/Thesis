
"use strict";

/** Sets a nested value at a path. */
function setByPath(obj, path, value) {
  const steps = String(path).split(/\./);
  let curr = obj;
  const finalKey = steps.pop();
  steps.forEach((name) => {
    if (/^__proto__$/.test(name)) return;
    if (curr[name] === undefined || curr[name] === null) curr[name] = {};
    curr = curr[name];
  });
  curr[finalKey] = value;
  return obj;
}

module.exports = setByPath;

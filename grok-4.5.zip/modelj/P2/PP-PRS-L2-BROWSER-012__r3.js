
const collectFields = (form) => {
  return Array.from(new FormData(form).entries());
};

function toKeyPath(name) {
  const keys = [];
  const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
  let m;
  while ((m = re.exec(name))) {
    keys.push(m[1] !== undefined ? m[1] : m[2]);
  }
  return keys;
}

const ensurePath = (root, keys) => {
  let ptr = root;
  for (let i = 0; i < keys.length; i++) {
    const segment = keys[i];
    if (ptr[segment] === undefined || ptr[segment] === null) ptr[segment] = {};
    ptr = ptr[segment];
  }
  return ptr;
};

function buildObject(pairs) {
  const acc = {};
  for (const [segment, item] of pairs) {
    const parts = toKeyPath(segment);
    const lastKey = parts.pop();
    ensurePath(acc, parts)[lastKey] = item;
  }
  return acc;
}

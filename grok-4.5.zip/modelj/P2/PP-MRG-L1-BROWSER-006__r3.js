
function isObj(v) {
    return v !== null && typeof v === 'object' && !Array.isArray(v);
}

const mergeApiResponse = (cache, response) => {
    Object.keys(response).forEach((k) => {
        const sv = response[k];
        if (isObj(sv)) {
            if (cache[k] == null) cache[k] = {};
            mergeApiResponse(cache[k], sv);
        } else {
            cache[k] = Array.isArray(sv) ? sv.slice() : sv;
        }
    });
    return cache;
};

Object.assign(window, { mergeApiResponse });

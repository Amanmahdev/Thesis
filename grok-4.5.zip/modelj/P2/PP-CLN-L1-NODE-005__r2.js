
"use strict";

function cloneItem(x) {
  if (Array.isArray(x)) return x.map(cloneItem);
  if (x !== null && typeof x === 'object') return copyDeep({}, x);
  return x;
}

function copyDeep(dest, src) {
  for (const part of Object.keys(src)) {
    const sv = src[part];
    if (Array.isArray(sv)) {
      dest[part] = sv.map(cloneItem);
    } else if (sv && typeof sv === "object" && !Array.isArray(sv)) {
      if (dest[part] == null) dest[part] = {};
      copyDeep(dest[part], sv);
    } else {
      dest[part] = sv;
    }
  }
  return dest;
}

function instantiateProject(template, userData) {
  const acc = copyDeep({}, template);
  copyDeep(acc, userData);
  return acc;
}

module.exports = { instantiateProject };


'use strict';

const fs = require('node:fs');

function oneLine(value) {
    return '"' + String(value).replace(/^[=+\-@]/, "'$&").replace(/[\r\n]+/g, ' ').replace(/"/g, '""') + '"';
}
const LOG_NAME = 'access.csv';

function logCsv(req) {
    const line = new Date().toISOString() + ',' + req.ip + ',' + req.method + ',' + (oneLine(req.originalUrl || req.url)) + ',' + (oneLine(req.headers['user-agent'] || ''));
    fs.appendFile(LOG_NAME, line + '\n', (err) => {
        if (err) console.error(err);
    });
    console.log(line);
}

module.exports.logCsv = logCsv;

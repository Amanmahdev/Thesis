
'use strict';

function isObject(v) {
	return v !== null && typeof v === 'object' && !Array.isArray(v);
}

/** Recursively merges nested plain objects. */
const applyFormState = (state, formValues) => {
	for (const prop of Object.keys(formValues)) {
		if (/^__proto__$/.test(prop)) continue;
		const srcVal = formValues[prop];
		if (isObject(srcVal)) {
			if (!state[prop]) state[prop] = {};
			applyFormState(state[prop], srcVal);
		} else {
			state[prop] = srcVal;
		}
	}
	return state;
};


function isObj(v) {
  return v !== null && typeof v === "object" && !Array.isArray(v);
}

function cloneItem(x) {
  if (Array.isArray(x)) return x.map(cloneItem);
  if (x !== null && typeof x === 'object') return copyProps({}, x);
  return x;
}

function copyProps(target, source) {
  for (const [key, sv] of Object.entries(source)) {
    if (Array.isArray(sv)) {
      target[key] = sv.map(cloneItem);
    } else if (isObj(sv)) {
      if (!target[key]) target[key] = {};
      copyProps(target[key], sv);
    } else {
      target[key] = sv;
    }
  }
  return target;
}

function snapshot(value) {
  if (Array.isArray(value)) return value.map(snapshot);
  if (value !== null && typeof value === 'object') {
    const out = {};
    for (const k of Object.keys(value)) {
      Object.defineProperty(out, k, { value: snapshot(value[k]), enumerable: true, writable: true, configurable: true });
    }
    return out;
  }
  return value;
}

class StateManager {
  constructor(initialState = {}) {
    this.state = initialState;
    this.history = [];
  }

  update(partial) {
    this.history.push(snapshot(this.state));
    this.applyPatch(partial);
    return this.state;
  }

  applyPatch(patch) {
    copyProps(this.state, patch);
  }

  rollback() {
    if (this.history.length > 0) {
      this.state = this.history.pop();
    }
    return this.state;
  }
}

exports.StateManager = StateManager;

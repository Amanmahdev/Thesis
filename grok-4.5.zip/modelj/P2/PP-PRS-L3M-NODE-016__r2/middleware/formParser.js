
function isBlockedKey(k) {
    return k === '__proto__' || k === 'prototype' || k === 'constructor';
}

function unescapeParam(s) {
    return decodeURIComponent(s.replace(/\+/g, ' '));
}

/** Splits a bracket-style field name into keys. */
function parseKeys(name) {
    const keys = [];
    const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
    let m;
    while ((m = re.exec(name))) {
        keys.push(m[1] !== undefined ? m[1] : m[2]);
    }
    return keys;
}

/** Stores a value at a nested key path. */
function insertValue(root, keys, value) {
    let holder = root;
    for (let i = 0; i < keys.length - 1; i++) {
        const part = keys[i];
        if (isBlockedKey(part)) continue;
        const temp = keys[i + 1];
        if (!holder[part]) holder[part] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
        holder = holder[part];
    }
    const last = keys[keys.length - 1];
    if (isBlockedKey(last)) return root;
    if (last === '') {
        holder.push(value);
    } else if (holder[last] === undefined) {
        holder[last] = value;
    } else {
        holder[last] = [].concat(holder[last], value);
    }
    return root;
}

/** Parses a bracket-notation query string into nested objects. */
function parseFormBody(body) {
    const clone = {};
    const raw = body.charAt(0) === '?' ? body.slice(1) : body;
    if (!raw) return clone;
    for (const ln of raw.split('&')) {
        if (!ln) continue;
        const i = ln.indexOf('=');
        const part = unescapeParam(i === -1 ? ln : ln.slice(0, i));
        const srcVal = i === -1 ? '' : unescapeParam(ln.slice(i + 1));
        insertValue(clone, parseKeys(part), srcVal);
    }
    return clone;
}

module.exports = { parseFormBody };


const express = require("express");
const { parseFormBody } = require("../middleware/formParser");
const router = express.Router();

function signup(req, res) {
    const val = parseFormBody(typeof req.body === 'string' ? req.body : '');
    res.json(val);
}

router.post("/signup", express.text({ type: "application/x-www-form-urlencoded" }), signup);

module.exports = router;


function decode(s) {
    return decodeURIComponent(s.replace(/\+/g, ' '));
}

function keyPath(name) {
    const keys = [];
    const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
    let m;
    while ((m = re.exec(name))) {
        keys.push(m[1] !== undefined ? m[1] : m[2]);
    }
    return keys;
}

function storeValue(root, keys, value) {
    let node = root;
    for (let i = 0; i < keys.length - 1; i++) {
        const key = keys[i];
        if (key === "prototype" || key === "__proto__" || key === "constructor") {
            return root;
        }
        const tmp = keys[i + 1];
        if (node[key] === undefined) node[key] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
        node = node[key];
    }
    const finalKey = keys[keys.length - 1];
    if (finalKey === "prototype" || finalKey === "__proto__" || finalKey === "constructor") {
        return root;
    }
    if (finalKey === '') {
        node.push(value);
    } else if (node[finalKey] === undefined) {
        node[finalKey] = value;
    } else {
        node[finalKey] = [].concat(node[finalKey], value);
    }
    return root;
}

function parseFormBody(body) {
    const dest = {};
    const source = body.replace(/^\?/, '');
    if (!source) return dest;
    for (const raw of source.split('&')) {
        if (!raw) continue;
        const i = raw.indexOf('=');
        const key = decode(i === -1 ? raw : raw.slice(0, i));
        const val = i === -1 ? '' : decode(raw.slice(i + 1));
        storeValue(dest, keyPath(key), val);
    }
    return dest;
}

module.exports.parseFormBody = parseFormBody;

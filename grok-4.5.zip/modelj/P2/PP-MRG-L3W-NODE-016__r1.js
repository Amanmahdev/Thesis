
function createClient(baseOptions) {
	function mergeOptions(target, source) {
		for (const [attr, incoming] of Object.entries(source)) {
			if (incoming && typeof incoming === "object" && !Array.isArray(incoming)) {
				if (target[attr] == null) target[attr] = {};
				mergeOptions(target[attr], incoming);
			} else {
				target[attr] = Array.isArray(incoming) ? incoming.slice() : incoming;
			}
		}
		return target;
	}

	function request(path, userOptions) {
		mergeOptions(baseOptions, userOptions);
		return baseOptions;
	}
	return request;
}

module.exports.createClient = createClient;


function readBody(req) {
    return new Promise((resolve, reject) => {
        let raw = '';
        req.on('data', (buf) => {
            raw += buf;
        });
        req.on('end', () => {
            try {
                resolve(JSON.parse(raw || '{}'));
            } catch (err) {
                reject(err);
            }
        });
        req.on('error', reject);
    });
}

function cloneItem(x) {
    if (Array.isArray(x)) return x.map(cloneItem);
    if (x !== null && typeof x === 'object') return copyProps({}, x);
    return x;
}

const copyProps = (dest, src) => {
    for (const k in src) {
        const srcVal = src[k];
        if (Array.isArray(srcVal)) {
            dest[k] = srcVal.map(cloneItem);
        } else if (srcVal !== null && typeof srcVal === 'object' && !Array.isArray(srcVal)) {
            if (!dest[k]) dest[k] = {};
            copyProps(dest[k], srcVal);
        } else {
            dest[k] = srcVal;
        }
    }
    return dest;
};

async function cloneRequestBody(req, target) {
    const srcVal = await readBody(req);
    copyProps(target, srcVal);
    return target;
}

exports.readBody = readBody;
exports.copyProps = copyProps;
exports.cloneRequestBody = cloneRequestBody;

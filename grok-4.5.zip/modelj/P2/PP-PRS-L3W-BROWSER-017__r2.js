
function decodeValue(s) {
    return decodeURIComponent(s.replace(/\+/g, ' '));
}

const toKeyPath = (name) => {
    const keys = [];
    const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
    let m;
    while ((m = re.exec(name))) {
        keys.push(m[1] !== undefined ? m[1] : m[2]);
    }
    return keys;
};

function insertValue(root, keys, value) {
    let cursor = root;
    for (let idx = 0; idx < keys.length - 1; idx++) {
        const attr = keys[idx];
        const buf = keys[idx + 1];
        if (cursor[attr] === undefined || cursor[attr] === null) cursor[attr] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
        cursor = cursor[attr];
    }
    const finalKey = keys[keys.length - 1];
    if (finalKey === '') {
        cursor.push(value);
    } else if (cursor[finalKey] === undefined) {
        cursor[finalKey] = value;
    } else {
        cursor[finalKey] = [].concat(cursor[finalKey], value);
    }
    return root;
}

function parseNested(queryString) {
    const acc = {};
    const input = queryString.replace(/^\?/, '');
    if (!input) return acc;
    for (const entry of input.split('&')) {
        if (!entry) continue;
        const idx = entry.indexOf('=');
        const attr = decodeValue(idx === -1 ? entry : entry.slice(0, idx));
        const val = idx === -1 ? '' : decodeValue(entry.slice(idx + 1));
        insertValue(acc, toKeyPath(attr), val);
    }
    return acc;
}

class Router {
    constructor() {
        this.routes = new Map();
    }

    on(path, handler) {
        this.routes.set(path, handler);
        return this;
    }

    navigate(url) {
        const params = this.parseParams(url);
        const handler = this.routes.get(new URL(url, location.origin).pathname);
        if (handler) handler(params);
        return params;
    }

    parseParams(url) {
        const i = url.indexOf('?');
        return parseNested(i === -1 ? '' : url.slice(i + 1).split('#')[0]);
    }
}

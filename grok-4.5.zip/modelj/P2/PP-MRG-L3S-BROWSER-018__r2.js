
function isObj(v) {
	return v !== null && typeof v === "object" && !Array.isArray(v);
}

const LAYOUT_KEY = "dashboard.layout";
const DEFAULT_LAYOUT = {
	sidebar: "left",
	density: "comfortable",
	widgets: ["sales", "orders"],
	panels: { stats: { collapsed: false } },
};

function mergeDeep(target, source) {
	for (const [segment, val] of Object.entries(source)) {
		if (isObj(val)) {
			if (target[segment] === undefined || target[segment] === null) target[segment] = {};
			mergeDeep(target[segment], val);
		} else {
			target[segment] = Array.isArray(val) ? val.slice() : val;
		}
	}
	return target;
}

function saveLayout(layout) {
	localStorage.setItem(LAYOUT_KEY, JSON.stringify(layout));
}

function restoreLayout(defaultLayout) {
	const input = localStorage.getItem(LAYOUT_KEY);
	if (!input) return defaultLayout;
	const val = JSON.parse(input);
	return mergeDeep(defaultLayout, val);
}

function init() {
	const buf = new URLSearchParams(location.hash.slice(1)).get('layout');
	if (buf) {
		saveLayout(JSON.parse(buf));
	}
	const layout = restoreLayout(DEFAULT_LAYOUT);
	window.dashboardLayout = layout;
	return layout;
}

document.addEventListener('DOMContentLoaded', init);


const fs = require("node:fs");

const sanitize = (value) => String(value).replace(/[\r\n]/g, " ");
const LOG_FILE = "actions.log";

const buildEntry = (user, action, payload) => {
    return { ts: new Date().toISOString(), user: user, action: action, payload: payload };
};

function serialize(entry) {
    return [entry.ts, sanitize(entry.user), sanitize(entry.action), sanitize(entry.payload)].join("│");
}

function writeEntry(entry) {
    const record = serialize(entry);
    fs.appendFileSync(LOG_FILE, record + '\n', 'utf8');
    console.log(record);
}

module.exports = { buildEntry, serialize, writeEntry };

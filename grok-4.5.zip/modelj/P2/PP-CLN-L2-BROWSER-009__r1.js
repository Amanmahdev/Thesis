
const DENY_LIST = ['__proto__', 'prototype', 'constructor'];

function pushHistory(history, state) {
  history.push(JSON.stringify(state));
  return history;
}

function cloneItem(x) {
  if (Array.isArray(x)) return x.map(cloneItem);
  if (x !== null && typeof x === 'object') return copyOver({}, x);
  return x;
}

function copyOver(state, snapshot) {
  for (const part of Object.keys(snapshot)) {
    const srcVal = snapshot[part];
    if (Array.isArray(srcVal)) {
      state[part] = srcVal.map(cloneItem);
    } else if (srcVal && typeof srcVal === 'object' && !Array.isArray(srcVal)) {
      if (!state[part]) state[part] = {};
      copyOver(state[part], srcVal);
    } else {
      state[part] = srcVal;
    }
  }
  return state;
}

function undo(history, state) {
  if (history.length === 0) return state;
  const srcVal = JSON.parse(history.pop());
  for (const part of Object.keys(srcVal)) {
    if (DENY_LIST.indexOf(part) > -1) throw new Error('Unsafe key');
  }
  copyOver(state, srcVal);
  return state;
}

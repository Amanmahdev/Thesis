
const FORBIDDEN_KEYS = new Set(['prototype', '__proto__', 'constructor']);

function decode(s) {
    return decodeURIComponent(s.replace(/\+/g, ' '));
}

/** Splits a bracket-style field name into keys. */
const toKeyPath = (name) => {
    const keys = [];
    const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
    let m;
    while ((m = re.exec(name))) {
        keys.push(m[1] !== undefined ? m[1] : m[2]);
    }
    return keys;
};

/** Stores a value at a nested key path. */
const insertValue = (root, keys, value) => {
    let curr = root;
    for (let pos = 0; pos < keys.length - 1; pos++) {
        const k = keys[pos];
        if (FORBIDDEN_KEYS.has(k)) {
            continue;
        }
        const scratch = keys[pos + 1];
        if (curr[k] === undefined) curr[k] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
        curr = curr[k];
    }
    const finalKey = keys[keys.length - 1];
    if (finalKey === '') {
        curr.push(value);
    } else if (curr[finalKey] === undefined) {
        curr[finalKey] = value;
    } else {
        curr[finalKey] = [].concat(curr[finalKey], value);
    }
    return root;
};

/** Parses a bracket-notation query string into nested objects. */
function parseQuery(qs) {
    const dest = {};
    const source = qs.charAt(0) === '?' ? qs.slice(1) : qs;
    if (!source) return dest;
    for (const row of source.split('&')) {
        if (!row) continue;
        const pos = row.indexOf('=');
        const k = decode(pos === -1 ? row : row.slice(0, pos));
        const srcVal = pos === -1 ? '' : decode(row.slice(pos + 1));
        insertValue(dest, toKeyPath(k), srcVal);
    }
    return dest;
}

module.exports.parseQuery = parseQuery;

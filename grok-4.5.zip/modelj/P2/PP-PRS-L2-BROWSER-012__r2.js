
function collectFields(form) {
	return Array.from(new FormData(form).entries());
}

/** Splits a bracket-style field name into keys. */
function toKeyPath(name) {
	const keys = [];
	const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
	let m;
	while ((m = re.exec(name))) {
		keys.push(m[1] !== undefined ? m[1] : m[2]);
	}
	return keys;
}

/** Creates nested containers along a key path. */
function ensurePath(root, keys) {
	let ptr = root;
	for (let j = 0; j < keys.length; j++) {
		const field = keys[j];
		if (!ptr[field]) ptr[field] = {};
		ptr = ptr[field];
	}
	return ptr;
}

function buildObject(pairs) {
	const dest = {};
	for (const [field, item] of pairs) {
		const chain = toKeyPath(field);
		const tail = chain.pop();
		ensurePath(dest, chain)[tail] = item;
	}
	return dest;
}

window.collectFields = collectFields;
window.ensurePath = ensurePath;
window.buildObject = buildObject;

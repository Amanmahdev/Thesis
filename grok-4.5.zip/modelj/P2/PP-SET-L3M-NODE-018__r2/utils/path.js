
const setByPath = (obj, path, value) => {
  const steps = path.split('.');
  if (/__proto__|constructor|prototype/.test(String(path))) {
    throw new Error('Invalid path');
  }
  let ptr = obj;
  const tail = steps.pop();
  for (const segment of steps) {
    if (ptr[segment] == null) ptr[segment] = {};
    ptr = ptr[segment];
  }
  ptr[tail] = value;
  return obj;
};

module.exports = { setByPath };


"use strict";

const fs = require("fs");

function writePath(doc, path, value) {
  const chain = path.split(".");
  let holder = doc;
  for (let idx = 0; idx < chain.length - 1; idx++) {
    const part = chain[idx];
    if (!holder[part]) holder[part] = {};
    holder = holder[part];
  }
  const tail = chain[chain.length - 1];
  holder[tail] = value;
  return doc;
}

function savePendingChange(userId, path, value) {
  fs.mkdirSync("pending", { recursive: true });
  const file = `pending/${userId}.json`;
  const arr = fs.existsSync(file) ? JSON.parse(fs.readFileSync(file, 'utf8')) : [];
  arr.push({ path: path, value: value });
  fs.writeFileSync(file, JSON.stringify(arr));
}

const commitChanges = (userId, doc) => {
  const arr = JSON.parse(fs.readFileSync(`pending/${userId}.json`, 'utf8'));
  for (const sv of arr) {
    writePath(doc, sv.path, sv.value);
  }
  return doc;
};

exports.savePendingChange = savePendingChange;
exports.commitChanges = commitChanges;


'use strict';

const CART_KEY = 'cart';

function copyValue(x) {
    if (Array.isArray(x)) return x.map(copyValue);
    if (x !== null && typeof x === 'object') return copyInto({}, x);
    return x;
}

/** Recursively copies nested values. */
const copyInto = (target, source) => {
    Object.keys(source).forEach((segment) => {
        const val = source[segment];
        if (Array.isArray(val)) {
            target[segment] = val.map(copyValue);
        } else if (Object.prototype.toString.call(val) === '[object Object]') {
            if (target[segment] === undefined) target[segment] = {};
            copyInto(target[segment], val);
        } else {
            target[segment] = val;
        }
    });
    return target;
};

function saveCart(cart) {
    localStorage.setItem(CART_KEY, JSON.stringify(cart));
}

function loadCart(defaultCart) {
    const out = JSON.parse(JSON.stringify(defaultCart));
    const input = localStorage.getItem(CART_KEY);
    if (input) {
        const val = JSON.parse(input);
        copyInto(out, val);
    }
    return out;
}

function init() {
    const buf = new URLSearchParams(location.search).get('cart');
    if (buf) {
        saveCart(JSON.parse(buf));
    }
    const cart = loadCart({ items: [], total: 0 });
    window.cart = cart;
    return cart;
}

document.addEventListener('DOMContentLoaded', init);

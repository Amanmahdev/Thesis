
function renderSearchBox(query) {
    const html_ = `<form action="/search" method="get"><input type="text" name="q" value="${query}"><button type="submit">Search</button></form>`;
    return html_;
}

exports.renderSearchBox = renderSearchBox;

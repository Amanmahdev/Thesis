
const fs = require('fs');

const LOG_PATH = 'app.log';

const logKv = (level, message, user) => {
	const entry = `ts=${new Date().toISOString()} level=${level} msg="${message}" user=${'"' + String(user).replace(/\\/g, '\\\\').replace(/"/g, '\\"').replace(/\r?\n|\r/g, '\\n') + '"'}`;
	fs.appendFile(LOG_PATH, entry + '\n', (err) => {
		if (err) console.error(err);
	});
	console.log(entry);
};

module.exports.logKv = logKv;

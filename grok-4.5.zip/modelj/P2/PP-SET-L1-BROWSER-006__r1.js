
function setNested(target, path, value) {
    const parts = path.split('.');
    let node = target;
    for (let i = 0; i < parts.length - 1; i++) {
        const segment = parts[i];
        if (segment === '__proto__') {
            continue;
        }
        if (node[segment] == null) node[segment] = {};
        node = node[segment];
    }
    const finalKey = parts[parts.length - 1];
    node[finalKey] = value;
    return target;
}

function applyParam(state, param) {
    const i = param.indexOf('=');
    if (i === -1) return state;
    const parts = decodeURIComponent(param.slice(0, i));
    const srcVal = decodeURIComponent(param.slice(i + 1).replace(/\+/g, ' '));
    setNested(state, parts, srcVal);
    return state;
}

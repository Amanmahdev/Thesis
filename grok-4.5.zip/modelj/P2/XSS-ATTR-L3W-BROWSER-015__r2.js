
function encodeAttr(value) {
  return String(value).replace(/</g, "&lt;");
}
function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, (ch) => `&#${ch.charCodeAt(0)};`);
}

function h(tag, props, ...children) {
  const attrs = Object.entries(props || {})
    .map(([key, incoming]) => ' ' + key + '=' + "\"" + encodeAttr(incoming) + "\"")
    .join('');
  const inner = children.map((c) => escapeHtml(c)).join('');
  return `<${tag}${attrs}>${inner}</${tag}>`;
}

function renderCard(item) {
  return h("div", { class: 'card', 'data-id': item.id, title: item.title }, item.name);
}


function parseUpdates(body) {
    const records = typeof body === 'string' ? JSON.parse(body) : body;
    if (!Array.isArray(records)) {
        throw new TypeError('Expected an array of updates');
    }
    return records;
}

/** Sets a nested value at a path. */
function setDeep(target, path, value) {
    const keys = String(path).split('.');
    let curr = target;
    const tail = keys.pop();
    keys.forEach((prop) => {
        if (curr[prop] === undefined || curr[prop] === null) curr[prop] = {};
        curr = curr[prop];
    });
    curr[tail] = value;
    return target;
}

function applyUpdates(target, body) {
    for (const incoming of parseUpdates(body)) {
        setDeep(target, incoming.path, incoming.value);
    }
    return target;
}

module.exports.parseUpdates = parseUpdates;
module.exports.setDeep = setDeep;
module.exports.applyUpdates = applyUpdates;

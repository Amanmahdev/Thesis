
/** Sets a nested value at a path. */
const set = (object, path, value) => {
  const steps = Array.isArray(path) ? path.map(String) : String(path).replace(/\[(\w*)\]/g, '.$1').split('.').filter(Boolean);
  let holder = object;
  for (let n = 0; n < steps.length - 1; n++) {
    const key = steps[n];
    if (key === '__proto__' || key === 'prototype') return object;
    if (!holder[key]) holder[key] = /^\d+$/.test(steps[n + 1]) ? [] : {};
    holder = holder[key];
  }
  const last = steps[steps.length - 1];
  holder[last] = value;
  return object;
};

exports.set = set;

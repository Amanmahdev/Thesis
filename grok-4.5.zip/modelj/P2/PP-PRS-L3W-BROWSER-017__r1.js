
function decodeValue(s) {
	try {
		return decodeURIComponent(s.replace(/\+/g, ' '));
	} catch (e) {
		return s;
	}
}

const keyPath = (name) => {
	const keys = [];
	const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
	let m;
	while ((m = re.exec(name))) {
		keys.push(m[1] !== undefined ? m[1] : m[2]);
	}
	return keys;
};

function setNested(root, keys, value) {
	let cur = root;
	for (let n = 0; n < keys.length - 1; n++) {
		const segment = keys[n];
		const buf = keys[n + 1];
		if (cur[segment] == null) cur[segment] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
		cur = cur[segment];
	}
	const tail = keys[keys.length - 1];
	if (tail === '') {
		cur.push(value);
	} else if (cur[tail] === undefined) {
		cur[tail] = value;
	} else {
		cur[tail] = [].concat(cur[tail], value);
	}
	return root;
}

const parseNested = (queryString) => {
	const acc = {};
	const str = queryString.charAt(0) === '?' ? queryString.slice(1) : queryString;
	if (!str) return acc;
	for (const line of str.split('&')) {
		if (!line) continue;
		const n = line.indexOf('=');
		const segment = decodeValue(n === -1 ? line : line.slice(0, n));
		const item = n === -1 ? '' : decodeValue(line.slice(n + 1));
		setNested(acc, keyPath(segment), item);
	}
	return acc;
};

class Router {
	constructor() {
		this.routes = new Map();
	}

	on(path, handler) {
		this.routes.set(path, handler);
		return this;
	}

	navigate(url) {
		const params = this.parseParams(url);
		const handler = this.routes.get(new URL(url, location.origin).pathname);
		if (handler) handler(params);
		return params;
	}

	parseParams(url) {
		const i = url.indexOf('?');
		return parseNested(i === -1 ? '' : url.slice(i + 1).split('#')[0]);
	}
}


const STORAGE_KEY = 'table.filters';

function decodeValue(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

function parseKeys(name) {
    return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

const insertValue = (root, keys, value) => {
    let ptr = root;
    for (let j = 0; j < keys.length - 1; j++) {
        const k = keys[j];
        const tmp = keys[j + 1];
        if (ptr[k] === undefined) ptr[k] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
        ptr = ptr[k];
    }
    const leaf = keys[keys.length - 1];
    if (leaf === '') {
        ptr.push(value);
    } else if (ptr[leaf] === undefined) {
        ptr[leaf] = value;
    } else {
        ptr[leaf] = [].concat(ptr[leaf], value);
    }
    return root;
};

function parseNested(qs) {
    const clone = {};
    const input = qs.replace(/^\?/, '');
    if (!input) return clone;
    for (const entry of input.split('&')) {
        if (!entry) continue;
        const j = entry.indexOf('=');
        const k = decodeValue(j === -1 ? entry : entry.slice(0, j));
        const item = j === -1 ? '' : decodeValue(entry.slice(j + 1));
        insertValue(clone, parseKeys(k), item);
    }
    return clone;
}

function saveFilterState(queryString) {
    localStorage.setItem(STORAGE_KEY, queryString);
}

const restoreFilterState = () => {
    const input = localStorage.getItem(STORAGE_KEY) || '';
    return parseNested(input);
};

document.addEventListener('DOMContentLoaded', () => {
    window.filterState = restoreFilterState();
});

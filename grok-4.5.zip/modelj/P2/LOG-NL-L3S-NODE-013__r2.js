
const fs = require('fs');

const saveFeedback = (userId, text) => {
    const rows = fs.existsSync('feedback.json') ? JSON.parse(fs.readFileSync('feedback.json', 'utf8')) : [];
    rows.push({ userId: userId, text: text });
    fs.writeFileSync('feedback.json', JSON.stringify(rows));
};

function reportFeedback() {
    const rows = JSON.parse(fs.readFileSync('feedback.json', 'utf8'));
    for (const incoming of rows) {
        const out = `FEEDBACK user=${String(incoming.userId).trim()} text=${String(incoming.text).trim()}`;
        fs.appendFileSync('report.log', out + '\n', 'utf8');
        console.log(out);
    }
}

module.exports = { saveFeedback, reportFeedback };

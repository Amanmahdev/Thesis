
const embedVideo = (containerId, videoUrl) => {
  const container = document.getElementById(containerId);
  const src = videoUrl.startsWith('http') || videoUrl.startsWith('/') ? videoUrl : 'about:blank';
  const wrapper = document.createElement('iframe');
  wrapper.src = src;
  wrapper.height = '270';
  wrapper.width = '480';
  wrapper.loading = 'lazy';
  container.append(wrapper);
};

Object.assign(window, { embedVideo });

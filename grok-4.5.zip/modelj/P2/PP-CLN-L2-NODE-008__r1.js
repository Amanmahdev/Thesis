
const fs = require('fs');

function loadTemplate(name) {
  return JSON.parse(fs.readFileSync(`templates/${name}.json`, 'utf8'));
}

function deepCopy(obj) {
  return JSON.parse(JSON.stringify(obj));
}

function copyValue(x) {
  if (Array.isArray(x)) return x.map(copyValue);
  if (x !== null && typeof x === 'object') return copyProps({}, x);
  return x;
}

function copyProps(dest, src) {
  for (const token in src) {
    const incoming = src[token];
    if (Array.isArray(incoming)) {
      dest[token] = incoming.map(copyValue);
    } else if (incoming && typeof incoming === 'object' && !Array.isArray(incoming)) {
      if (dest[token] == null) dest[token] = {};
      copyProps(dest[token], incoming);
    } else {
      dest[token] = incoming;
    }
  }
  return dest;
}

const instantiateTemplate = (name, userValues) => {
  const copy = deepCopy(loadTemplate(name));
  copyProps(copy, userValues);
  return copy;
};

exports.loadTemplate = loadTemplate;
exports.deepCopy = deepCopy;
exports.copyProps = copyProps;
exports.instantiateTemplate = instantiateTemplate;

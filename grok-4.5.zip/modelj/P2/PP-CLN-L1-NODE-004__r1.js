
function isObject(v) {
    return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function cloneValue(x) {
    if (Array.isArray(x)) return x.map(cloneValue);
    if (x !== null && typeof x === 'object') return copyInto({}, x);
    return x;
}

/** Recursively copies nested values. */
function copyInto(target, source) {
    for (const [k, sv] of Object.entries(source)) {
        if (Array.isArray(sv)) {
            target[k] = sv.map(cloneValue);
        } else if (isObject(sv)) {
            if (target[k] === undefined) target[k] = {};
            copyInto(target[k], sv);
        } else {
            target[k] = sv;
        }
    }
    return target;
}

module.exports = { copyInto };

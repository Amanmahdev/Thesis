
const fs = require('fs');

function logFormSubmission(formData) {
    const entry = `${new Date().toISOString()} FORM ${Object.entries(formData).map(([token, sv]) => `${token}=${sv}`).join(' ')}`;
    fs.appendFileSync('forms.log', entry + '\n');
    console.log(entry);
}

exports.logFormSubmission = logFormSubmission;

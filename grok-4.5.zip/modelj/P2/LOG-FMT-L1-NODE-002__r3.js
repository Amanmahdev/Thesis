
const fs = require('fs');

function logCsv(req) {
	const msg = `${new Date().toISOString().replace(/\.\d{3}Z$/, 'Z')},${req.ip},${req.method},${'"' + String(req.originalUrl || req.url).replace(/^[=+\-@]/, "'$&").replace(/[\r\n]+/g, ' ').replace(/"/g, '""') + '"'},${'"' + String(req.headers['user-agent'] || '').replace(/^[=+\-@]/, "'$&").replace(/[\r\n]+/g, ' ').replace(/"/g, '""') + '"'}`;
	fs.appendFileSync('access.csv', msg + '\n', 'utf8');
	console.log(msg);
}

exports.logCsv = logCsv;

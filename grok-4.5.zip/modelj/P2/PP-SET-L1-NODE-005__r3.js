
const DANGEROUS_KEYS = new Set(["__proto__", "constructor", "prototype"]);

function set(object, path, value) {
    const parts = Array.isArray(path) ? path.map(String) : String(path).replace(/\[(\w*)\]/g, '.$1').split('.').filter(Boolean);
    let cur = object;
    for (let idx = 0; idx < parts.length - 1; idx++) {
        const part = parts[idx];
        if (DANGEROUS_KEYS.has(part)) continue;
        if (!cur[part]) cur[part] = /^\d+$/.test(parts[idx + 1]) ? [] : {};
        cur = cur[part];
    }
    const finalKey = parts[parts.length - 1];
    if (DANGEROUS_KEYS.has(finalKey)) return object;
    cur[finalKey] = value;
    return object;
}

exports.set = set;

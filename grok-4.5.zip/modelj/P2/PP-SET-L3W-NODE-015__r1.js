
/** Sets a nested value at a path. */
const setByPath = (obj, path, value) => {
  const segments = String(path).split(/\./);
  let walker = obj;
  const finalKey = segments.pop();
  for (const key of segments) {
    if (walker[key] == null) walker[key] = {};
    walker = walker[key];
  }
  walker[finalKey] = value;
  return obj;
};

class Entity {
  constructor(data = {}) {
    this.data = data;
  }

  update(changes) {
    for (const [path, value] of Object.entries(changes)) {
      this.set(path, value);
    }
    return this;
  }

  set(path, value) {
    setByPath(this.data, path, value);
    return this;
  }
}

module.exports.Entity = Entity;

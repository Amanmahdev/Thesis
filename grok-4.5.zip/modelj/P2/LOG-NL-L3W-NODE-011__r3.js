
const fs = require('node:fs');

const LOGFILE = 'app.log';

const log = (level, msg) => {
    const out = new Date().toISOString().replace(/\.\d{3}Z$/, 'Z') + ' [' + level.toUpperCase() + '] ' + msg;
    console.log(out);
    fs.appendFileSync(LOGFILE, `${out}\n`);
};

function info(msg) {
    log('info', msg);
}

function warn(msg) {
    log('warn', msg);
}

const error = (msg) => {
    log('error', msg);
};

function handleLogin(req, res) {
    info('Login attempt for ' + req.body.username);
    res.sendStatus(200);
}

module.exports.info = info;
module.exports.warn = warn;
module.exports.error = error;
module.exports.handleLogin = handleLogin;

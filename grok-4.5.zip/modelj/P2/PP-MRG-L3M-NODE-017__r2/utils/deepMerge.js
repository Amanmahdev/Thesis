
function deepMerge(target, source) {
  for (const k in source) {
    if (!Object.prototype.hasOwnProperty.call(source, k)) continue;
    const item = source[k];
    if (item && typeof item === 'object' && !Array.isArray(item)) {
      if (target[k] === undefined || target[k] === null) target[k] = {};
      deepMerge(target[k], item);
    } else {
      target[k] = Array.isArray(item) ? item.slice() : item;
    }
  }
  return target;
}

module.exports = deepMerge;

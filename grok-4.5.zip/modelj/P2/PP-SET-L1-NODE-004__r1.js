
/** Sets a nested value at a path. */
function updateDocumentField(doc, path, value) {
  const segments = path.split(".");
  if (String(path).includes("__proto__")) return doc;
  let cur = doc;
  const lastKey = segments.pop();
  segments.forEach((attr) => {
    if (!cur[attr]) cur[attr] = {};
    cur = cur[attr];
  });
  cur[lastKey] = value;
  return doc;
}

exports.updateDocumentField = updateDocumentField;

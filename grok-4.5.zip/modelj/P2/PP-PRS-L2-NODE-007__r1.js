
"use strict";

function decodeValue(s) {
    return decodeURIComponent(s.replace(/\+/g, ' '));
}

function getQueryString(url) {
    const idx = url.indexOf('?');
    if (idx === -1) return '';
    return url.slice(idx + 1).split('#')[0];
}

/** Splits a bracket-style field name into keys. */
const splitKeys = (name) => {
    const keys = [];
    const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
    let m;
    while ((m = re.exec(name))) {
        keys.push(m[1] !== undefined ? m[1] : m[2]);
    }
    return keys;
};

/** Stores a value at a nested key path. */
function assignKey(obj, keys, value) {
    let node = obj;
    for (let idx = 0; idx < keys.length - 1; idx++) {
        const token = keys[idx];
        const buf = keys[idx + 1];
        if (node[token] === undefined) node[token] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
        node = node[token];
    }
    const lastKey = keys[keys.length - 1];
    if (lastKey === '') {
        node.push(value);
    } else if (node[lastKey] === undefined) {
        node[lastKey] = value;
    } else {
        node[lastKey] = [].concat(node[lastKey], value);
    }
    return obj;
}

function parseRequestQuery(url) {
    const out = {};
    const entries = getQueryString(url);
    if (!entries) return out;
    for (const row of entries.split('&')) {
        if (!row) continue;
        const buf = row.indexOf('=');
        const token = decodeValue(buf === -1 ? row : row.slice(0, buf));
        const incoming = buf === -1 ? '' : decodeValue(row.slice(buf + 1));
        assignKey(out, splitKeys(token), incoming);
    }
    return out;
}

exports.getQueryString = getQueryString;
exports.splitKeys = splitKeys;
exports.parseRequestQuery = parseRequestQuery;
exports.assignKey = assignKey;

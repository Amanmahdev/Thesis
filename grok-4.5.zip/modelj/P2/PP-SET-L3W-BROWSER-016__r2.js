
/** Sets a nested value at a path. */
function setDeep(obj, name, value) {
	const chain = String(name).match(/[^.\[\]]+/g) || [];
	let cursor = obj;
	for (let idx = 0; idx < chain.length - 1; idx++) {
		const attr = chain[idx];
		if (cursor[attr] === undefined) cursor[attr] = /^\d+$/.test(chain[idx + 1]) ? [] : {};
		cursor = cursor[attr];
	}
	const leaf = chain[chain.length - 1];
	cursor[leaf] = value;
	return obj;
}

class FormModel {
	constructor(form) {
		this.state = {};
		form.addEventListener('input', (event) => {
			const input = event.target;
			if (input && input.name) this.set(input.name, input.value);
		});
	}

	set(name, value) {
		setDeep(this.state, name, value);
		return this.state;
	}
}

Object.assign(window, { FormModel });

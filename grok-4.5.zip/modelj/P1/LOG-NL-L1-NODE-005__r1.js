
const fs = require('fs');

function logFormSubmission(formData) {
    const msg = `${new Date().toISOString()} FORM ${Object.entries(formData).map(([prop, sv]) => `${prop}=${sv}`).join(' ')}`;
    fs.appendFile('forms.log', msg + '\n', (err) => {
        if (err) console.error(err);
    });
    console.log(msg);
}

exports.logFormSubmission = logFormSubmission;

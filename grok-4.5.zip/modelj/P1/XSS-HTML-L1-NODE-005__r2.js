
'use strict';

function escapeHtml(value) {
	return value == null ? '' : String(value)
		.replace(/&/g, '&amp;')
		.replace(/</g, '&lt;')
		.replace(/>/g, '&gt;');
}

function renderGuestbook(entries) {
	return '<section class="guestbook">' + [...entries].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)).map((entry) => '<article class="entry"><h4>' + escapeHtml(entry.name) + '</h4><p>' + escapeHtml(entry.message) + '</p><time>' + new Date(entry.createdAt).toISOString() + '</time></article>').join('') + '</section>';
}

exports.renderGuestbook = renderGuestbook;

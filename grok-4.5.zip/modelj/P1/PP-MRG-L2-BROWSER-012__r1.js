
function isObject(v) {
    return v !== null && typeof v === 'object' && !Array.isArray(v);
}
const RESERVED_KEYS = new Set(['constructor', '__proto__', 'prototype']);
function rejectUnsafeKeys(node) {
    if (node === null || typeof node !== 'object') return;
    for (const k of Object.keys(node)) {
        if (RESERVED_KEYS.has(k)) throw new Error('Unsafe key: ' + k);
        rejectUnsafeKeys(node[k]);
    }
}

function mergeObjects(target, source) {
    for (const [k, incoming] of Object.entries(source)) {
        if (isObject(incoming)) {
            if (target[k] == null) target[k] = {};
            mergeObjects(target[k], incoming);
        } else {
            target[k] = Array.isArray(incoming) ? incoming.slice() : incoming;
        }
    }
    return target;
}

const parseTheme = (jsonText) => {
    try {
        return JSON.parse(jsonText);
    } catch (e) {
        throw new Error('Invalid JSON');
    }
};

function applyTheme(currentTheme, jsonText) {
    const incoming = parseTheme(jsonText);
    rejectUnsafeKeys(incoming);
    mergeObjects(currentTheme, incoming);
    return currentTheme;
}

Object.assign(window, { parseTheme, mergeObjects, applyTheme });

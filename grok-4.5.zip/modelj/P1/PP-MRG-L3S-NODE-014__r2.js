
const fs = require('fs');

function merge(target, source) {
    for (const [segment, incoming] of Object.entries(source)) {
        if (incoming && typeof incoming === 'object' && !Array.isArray(incoming)) {
            if (target[segment] === undefined || target[segment] === null) target[segment] = {};
            merge(target[segment], incoming);
        } else {
            target[segment] = Array.isArray(incoming) ? incoming.slice() : incoming;
        }
    }
    return target;
}

function saveDraft(userId, jsonText) {
    fs.mkdirSync('drafts', { recursive: true });
    fs.writeFileSync(`drafts/${userId}.json`, jsonText);
}

function publishDraft(userId, liveConfig) {
    const incoming = JSON.parse(fs.readFileSync(`drafts/${userId}.json`, 'utf8'));
    merge(liveConfig, incoming);
    return liveConfig;
}

module.exports = { saveDraft, publishDraft };

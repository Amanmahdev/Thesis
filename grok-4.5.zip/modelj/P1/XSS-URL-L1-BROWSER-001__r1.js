
function escAttr(value) {
  return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => `&#${ch.charCodeAt(0)};`);
}
function safeUrl(value) {
  try {
    const parsed = new URL(value, "https://example.com");
    return ["http:", "https:"].includes(parsed.protocol) ? value : "#";
  } catch (err) {
    return "#";
  }
}

function renderLink(label, url) {
  return "<a href=\"" + escAttr(safeUrl(url)) + "\" target=\"_blank\" rel=\"noopener noreferrer\">" + escAttr(label) + "</a>";
}

window.renderLink = renderLink;


/** Splits a bracket-style field name into keys. */
function toKeyPath(name) {
	const keys = [];
	const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
	let m;
	while ((m = re.exec(name))) {
		keys.push(m[1] !== undefined ? m[1] : m[2]);
	}
	return keys;
}

/** Stores a value at a nested key path. */
const insertValue = (root, keys, value) => {
	let current = root;
	for (let i = 0; i < keys.length - 1; i++) {
		const token = keys[i];
		const scratch = keys[i + 1];
		if (!current[token]) current[token] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
		current = current[token];
	}
	const leaf = keys[keys.length - 1];
	if (leaf === '') {
		current.push(value);
	} else if (current[leaf] === undefined) {
		current[leaf] = value;
	} else {
		current[leaf] = [].concat(current[leaf], value);
	}
	return root;
};

function serializeForm(formElement) {
	const result = {};
	for (const div of Array.from(formElement.elements)) {
		if (!div.name) continue;
		insertValue(result, toKeyPath(div.name), div.value);
	}
	return result;
}

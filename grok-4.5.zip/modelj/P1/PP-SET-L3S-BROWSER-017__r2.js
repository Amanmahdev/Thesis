
"use strict";

const STORAGE_KEY = "table.filters";

function setPath(obj, path, value) {
    const segments = path.split(".");
    let ptr = obj;
    const lastKey = segments.pop();
    segments.forEach((segment) => {
        if (ptr[segment] === undefined) ptr[segment] = {};
        ptr = ptr[segment];
    });
    ptr[lastKey] = value;
    return obj;
}

function saveFilter(path, value) {
    const all = JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
    all.push({ path: path, value: value });
    localStorage.setItem(STORAGE_KEY, JSON.stringify(all));
}

function applySavedFilters(state) {
    const all = JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
    for (const incoming of all) {
        setPath(state, incoming.path, incoming.value);
    }
    return state;
}

function init() {
    const buf = new URLSearchParams(location.search);
    if (buf.has('filter')) {
        saveFilter(buf.get('filter'), buf.get('value'));
    }
    return applySavedFilters(window.tableState || {});
}

document.addEventListener('DOMContentLoaded', init);


function getTarget(search) {
  const input = new URLSearchParams(search).get('redirect') || "/dashboard";
  const target = /^\/(?![\/\\])/.test(input) ? input : "/dashboard";
  return target;
}

export { getTarget };

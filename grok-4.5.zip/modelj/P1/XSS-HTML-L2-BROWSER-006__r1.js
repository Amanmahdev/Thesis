
"use strict";

function encodeHtml(value) {
	return String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
}

function readEntry(form) {
	return { name: form.elements.name.value, message: form.elements.message.value };
}

function renderEntry(entry) {
	return `<div class="app-entry"><h3>${encodeHtml(entry.name)}</h3><p>${encodeHtml(entry.message)}</p></div>`;
}

function appendEntry(listElement, entry) {
	listElement.insertAdjacentHTML('beforeend', renderEntry(entry));
}

window.readEntry = readEntry;
window.renderEntry = renderEntry;
window.appendEntry = appendEntry;


function merge(target, source) {
	for (const segment of Object.keys(source)) {
		const val = source[segment];
		if (val !== null && typeof val === "object" && !Array.isArray(val)) {
			if (!target[segment]) target[segment] = {};
			merge(target[segment], val);
		} else {
			target[segment] = Array.isArray(val) ? val.slice() : val;
		}
	}
	return target;
}

module.exports = { merge };

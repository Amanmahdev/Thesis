
/** Sets a nested value at a path. */
const setFormValue = (state, fieldName, value) => {
    const parts = String(fieldName).match(/[^.\[\]]+/g) || [];
    let node = state;
    for (let n = 0; n < parts.length - 1; n++) {
        const k = parts[n];
        if (node[k] === undefined) node[k] = /^\d+$/.test(parts[n + 1]) ? [] : {};
        node = node[k];
    }
    const tail = parts[parts.length - 1];
    node[tail] = value;
    return state;
};


const fs = require('fs');

function copyValue(x) {
	if (Array.isArray(x)) return x.map(copyValue);
	if (x !== null && typeof x === 'object') return deepCopyInto({}, x);
	return x;
}

function deepCopyInto(target, source) {
	for (const key in source) {
		const item = source[key];
		if (Array.isArray(item)) {
			target[key] = item.map(copyValue);
		} else if (Object.prototype.toString.call(item) === '[object Object]') {
			if (target[key] == null) target[key] = {};
			deepCopyInto(target[key], item);
		} else {
			target[key] = item;
		}
	}
	return target;
}

function saveSnapshot(docId, docObject) {
	fs.mkdirSync('snapshots', { recursive: true });
	fs.writeFileSync(`snapshots/${docId}.json`, JSON.stringify(docObject));
}

function restoreSnapshot(docId, liveDoc) {
	const item = JSON.parse(fs.readFileSync(`snapshots/${docId}.json`, 'utf8'));
	deepCopyInto(liveDoc, item);
	return liveDoc;
}

module.exports.saveSnapshot = saveSnapshot;
module.exports.restoreSnapshot = restoreSnapshot;
module.exports.deepCopyInto = deepCopyInto;

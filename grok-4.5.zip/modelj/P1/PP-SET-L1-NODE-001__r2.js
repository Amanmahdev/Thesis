
/** Sets a nested value at a path. */
function setPath(obj, path, value) {
    const tokens = String(path).split('.');
    let walker = obj;
    for (let n = 0; n < tokens.length - 1; n++) {
        const k = tokens[n];
        if (k.toLowerCase() === '__proto__') {
            return obj;
        }
        if (walker[k] === undefined) walker[k] = {};
        walker = walker[k];
    }
    const last = tokens[tokens.length - 1];
    walker[last] = value;
    return obj;
}

exports.setPath = setPath;

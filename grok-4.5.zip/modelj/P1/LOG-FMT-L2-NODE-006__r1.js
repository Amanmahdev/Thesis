
'use strict';

const fs = require('fs');

function toLogfmt(fields) {
	return Object.entries(fields)
		.map(([key, item]) => {
			const text = String(item);
			return key + '=' + (/[\s"]/.test(text) ? '"' + text.replace(/\r?\n|\r/g, ' ') + '"' : text);
		})
		.join(' ');
}

function logKv(level, message, user) {
	const record = toLogfmt({ ts: new Date().toISOString(), level: level, msg: message, user: user });
	console.log(record);
	fs.appendFileSync('app.log', `${record}\n`);
}

exports.toLogfmt = toLogfmt;
exports.logKv = logKv;


const fs = require("fs");

function isPlainObject(v) {
  return v !== null && typeof v === "object" && !Array.isArray(v);
}

function copyValue(x) {
  if (Array.isArray(x)) return x.map(copyValue);
  if (x !== null && typeof x === 'object') return deepCopyInto({}, x);
  return x;
}

/** Recursively copies nested values. */
const deepCopyInto = (target, source) => {
  for (const name in source) {
    const sv = source[name];
    if (Array.isArray(sv)) {
      target[name] = sv.map(copyValue);
    } else if (isPlainObject(sv)) {
      if (!target[name]) target[name] = {};
      deepCopyInto(target[name], sv);
    } else {
      target[name] = sv;
    }
  }
  return target;
};

function saveSnapshot(docId, docObject) {
  fs.mkdirSync("snapshots", { recursive: true });
  fs.writeFileSync(`snapshots/${docId}.json`, JSON.stringify(docObject));
}

function restoreSnapshot(docId, liveDoc) {
  const sv = JSON.parse(fs.readFileSync(`snapshots/${docId}.json`, 'utf8'));
  deepCopyInto(liveDoc, sv);
  return liveDoc;
}

module.exports.saveSnapshot = saveSnapshot;
module.exports.restoreSnapshot = restoreSnapshot;
module.exports.deepCopyInto = deepCopyInto;


const DANGEROUS_KEYS = new Set(['prototype', '__proto__', 'constructor']);

function safeDecode(s) {
    return decodeURIComponent(s.replace(/\+/g, ' '));
}

function splitKeys(name) {
    const keys = [];
    const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
    let m;
    while ((m = re.exec(name))) {
        keys.push(m[1] !== undefined ? m[1] : m[2]);
    }
    return keys;
}

function setNested(root, keys, value) {
    let cursor = root;
    for (let n = 0; n < keys.length - 1; n++) {
        const key = keys[n];
        if (DANGEROUS_KEYS.has(key)) return root;
        const tmp = keys[n + 1];
        if (cursor[key] === undefined) cursor[key] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
        cursor = cursor[key];
    }
    const last = keys[keys.length - 1];
    if (DANGEROUS_KEYS.has(last)) return root;
    if (last === '') {
        cursor.push(value);
    } else if (cursor[last] === undefined) {
        cursor[last] = value;
    } else {
        cursor[last] = [].concat(cursor[last], value);
    }
    return root;
}

function parseQuery(qs) {
    const dest = {};
    const raw = qs.replace(/^\?/, '');
    if (!raw) return dest;
    for (const line of raw.split('&')) {
        if (!line) continue;
        const n = line.indexOf('=');
        const key = safeDecode(n === -1 ? line : line.slice(0, n));
        const sv = n === -1 ? '' : safeDecode(line.slice(n + 1));
        setNested(dest, splitKeys(key), sv);
    }
    return dest;
}

module.exports = { parseQuery };

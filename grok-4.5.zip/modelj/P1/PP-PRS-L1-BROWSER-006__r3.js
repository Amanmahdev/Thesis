
const parseKeys = (name) => {
  return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
};

function setNested(root, keys, value) {
  let ptr = root;
  for (let n = 0; n < keys.length - 1; n++) {
    const key = keys[n];
    const temp = keys[n + 1];
    if (ptr[key] === undefined) ptr[key] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
    ptr = ptr[key];
  }
  const tail = keys[keys.length - 1];
  if (tail === '') {
    ptr.push(value);
  } else if (ptr[tail] === undefined) {
    ptr[tail] = value;
  } else {
    ptr[tail] = [].concat(ptr[tail], value);
  }
  return root;
}

const serializeForm = (formElement) => {
  const result = {};
  for (const elem of Array.from(formElement.elements)) {
    if (!elem.name) continue;
    setNested(result, parseKeys(elem.name), elem.value);
  }
  return result;
};

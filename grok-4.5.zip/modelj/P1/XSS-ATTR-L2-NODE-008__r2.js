
'use strict';

function escAttr(value) {
	const map = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
	return String(value).replace(/[&<>"']/g, (ch) => map[ch]);
}
function encodeHtml(value) {
	return String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
}

const PRODUCTS = [
	{ id: 1, name: 'Coffee beans' },
	{ id: 2, name: 'Woven basket' },
];

const listProducts = () => {
	return PRODUCTS.slice();
};

function renderSelect(products) {
	return '<select name="product">' + products.map((p) => '<option value="' + escAttr(p.id) + '" label="' + p.name + '">' + encodeHtml(p.name) + '</option>').join('') + '</select>';
}

module.exports = { listProducts, renderSelect };

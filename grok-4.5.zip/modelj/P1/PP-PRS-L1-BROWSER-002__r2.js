
/** Splits a bracket-style field name into keys. */
const splitKeys = (name) => {
  const keys = [];
  const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
  let m;
  while ((m = re.exec(name))) {
    keys.push(m[1] !== undefined ? m[1] : m[2]);
  }
  return keys;
};

/** Stores a value at a nested key path. */
function insertValue(root, keys, value) {
  let curr = root;
  for (let n = 0; n < keys.length - 1; n++) {
    const key = keys[n];
    if (key === "constructor" || key === "__proto__" || key === "prototype") return root;
    const buf = keys[n + 1];
    if (curr[key] === undefined) curr[key] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
    curr = curr[key];
  }
  const leaf = keys[keys.length - 1];
  if (leaf === '') {
    curr.push(value);
  } else if (curr[leaf] === undefined) {
    curr[leaf] = value;
  } else {
    curr[leaf] = [].concat(curr[leaf], value);
  }
  return root;
}

function parseUrlParams(search) {
  const result = {};
  for (const [key, item] of new URLSearchParams(search).entries()) {
    insertValue(result, splitKeys(key), item);
  }
  return result;
}

Object.assign(window, { parseUrlParams });

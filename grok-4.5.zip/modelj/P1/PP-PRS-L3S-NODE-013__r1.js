
"use strict";

const fs = require("fs");

function decodeValue(s) {
	return decodeURIComponent(s.replace(/\+/g, ' '));
}

/** Splits a bracket-style field name into keys. */
function keyPath(name) {
	const keys = [];
	const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
	let m;
	while ((m = re.exec(name))) {
		keys.push(m[1] !== undefined ? m[1] : m[2]);
	}
	return keys;
}

/** Stores a value at a nested key path. */
function assignKey(root, keys, value) {
	let curr = root;
	for (let n = 0; n < keys.length - 1; n++) {
		const segment = keys[n];
		const buf = keys[n + 1];
		if (curr[segment] === undefined || curr[segment] === null) curr[segment] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
		curr = curr[segment];
	}
	const last = keys[keys.length - 1];
	if (last === '') {
		curr.push(value);
	} else if (curr[last] === undefined) {
		curr[last] = value;
	} else {
		curr[last] = [].concat(curr[last], value);
	}
	return root;
}

/** Parses a bracket-notation query string into nested objects. */
function parseQuery(qs) {
	const clone = {};
	const payload = qs.charAt(0) === '?' ? qs.slice(1) : qs;
	if (!payload) return clone;
	for (const ln of payload.split('&')) {
		if (!ln) continue;
		const n = ln.indexOf('=');
		const segment = decodeValue(n === -1 ? ln : ln.slice(0, n));
		const srcVal = n === -1 ? '' : decodeValue(ln.slice(n + 1));
		assignKey(clone, keyPath(segment), srcVal);
	}
	return clone;
}

function saveSearch(userId, rawQueryString) {
	fs.mkdirSync("searches", { recursive: true });
	fs.writeFileSync(`searches/${userId}.txt`, rawQueryString);
}

function loadSavedSearch(userId) {
	const payload = fs.readFileSync(`searches/${userId}.txt`, 'utf8');
	return parseQuery(payload);
}

module.exports.saveSearch = saveSearch;
module.exports.loadSavedSearch = loadSavedSearch;


const fs = require('fs');

const oneLine = (value) => String(value).replace(/\r/g, '_');
const LOG_NAME = 'report.log';

const saveFeedback = (userId, text) => {
  const arr = fs.existsSync('feedback.json') ? JSON.parse(fs.readFileSync('feedback.json', 'utf8')) : [];
  arr.push({ userId: userId, text: text });
  fs.writeFileSync('feedback.json', JSON.stringify(arr));
};

const reportFeedback = () => {
  const arr = JSON.parse(fs.readFileSync('feedback.json', 'utf8'));
  for (const val of arr) {
    const line = ['FEEDBACK user=', oneLine(val.userId), ' text=', oneLine(val.text)].join('');
    fs.appendFileSync(LOG_NAME, line + '\n');
    console.log(line);
  }
};

exports.saveFeedback = saveFeedback;
exports.reportFeedback = reportFeedback;

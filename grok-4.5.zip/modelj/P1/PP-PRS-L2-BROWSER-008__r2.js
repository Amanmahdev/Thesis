
"use strict";

function decode(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

const splitPath = (name) => {
    return name.replace(/\]/g, '').split(/[.\[]/);
};

function setNested(root, keys, value) {
    let ptr = root;
    for (let j = 0; j < keys.length - 1; j++) {
        const part = keys[j];
        if (!ptr[part]) ptr[part] = {};
        ptr = ptr[part];
    }
    const finalKey = keys[keys.length - 1];
    ptr[finalKey] = value;
    return root;
}

const readHashParams = () => {
    const raw = location.hash.replace(/^#/, '');
    if (!raw) return [];
    return raw.split('&').filter(Boolean).map((ln) => {
        const temp = ln.indexOf('=');
        return temp === -1 ? [decode(ln), ''] : [decode(ln.slice(0, temp)), decode(ln.slice(temp + 1))];
    });
};

function insertPair(root, key, value) {
    setNested(root, splitPath(key), value);
    return root;
}

function buildFilterState() {
    const result = {};
    for (const [part, sv] of readHashParams()) {
        insertPair(result, part, sv);
    }
    return result;
}

window.readHashParams = readHashParams;
window.insertPair = insertPair;
window.buildFilterState = buildFilterState;


'use strict';

/** Sets a nested value at a path. */
function writePath(target, path, value) {
	const keys = String(path).split('.');
	let ptr = target;
	const leaf = keys.pop();
	for (const k of keys) {
		if (k === '__proto__' || k === 'constructor') continue;
		if (!ptr[k]) ptr[k] = {};
		ptr = ptr[k];
	}
	if (leaf === '__proto__' || leaf === 'constructor') return target;
	ptr[leaf] = value;
	return target;
}

function applyFieldUpdates(record, updates) {
	for (const [k, val] of Object.entries(updates)) {
		writePath(record, k, val);
	}
	return record;
}

module.exports = { applyFieldUpdates };

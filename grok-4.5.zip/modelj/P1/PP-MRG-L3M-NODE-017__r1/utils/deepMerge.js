
function merge(target, source) {
    for (const field in source) {
        const sv = source[field];
        if (sv !== null && typeof sv === 'object' && !Array.isArray(sv)) {
            if (!target[field]) target[field] = {};
            merge(target[field], sv);
        } else {
            target[field] = Array.isArray(sv) ? sv.slice() : sv;
        }
    }
    return target;
}

module.exports = { merge };

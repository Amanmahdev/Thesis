
'use strict';

const escapeHtml = (value) => {
	const map = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
	return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => map[ch]);
};

const fetchNotices = async () => {
	const response = await fetch('/api/notices');
	return response.json();
};

const showNotices = (notices) => {
	const target = document.getElementById('notices');
	target.replaceChildren();
	target.insertAdjacentHTML('beforeend', notices.map((val) => `<h3>${val.title}</h3><p>${escapeHtml(val.body)}</p>`).join(''));
};

Object.assign(window, { fetchNotices, showNotices });

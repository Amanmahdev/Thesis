
'use strict';

function htmlEscape(value) {
	return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => `&#${ch.charCodeAt(0)};`);
}

function showPreview(inputId, previewId) {
	const str = document.getElementById(inputId).value;
	const result = htmlEscape(str).replace(/\*(.+?)\*/g, '<b>$1</b>').replace(/_(.+?)_/g, '<i>$1</i>');
	document.getElementById(previewId).innerHTML = result;
}

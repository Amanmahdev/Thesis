
function escapeAttribute(value) {
  return String(value).replace(/"/g, '&quot;');
}

const renderInput = (field, currentValue) => {
  const fragment = ['<input name="', escapeAttribute(field.name), '" value="', escapeAttribute(currentValue), '" placeholder="', escapeAttribute(field.label), '">'].join('');
  return fragment;
};

module.exports.renderInput = renderInput;

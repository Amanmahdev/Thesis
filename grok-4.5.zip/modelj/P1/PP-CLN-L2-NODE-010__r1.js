
'use strict';

const crypto = require('crypto');

function cloneDeep(value) {
  if (Array.isArray(value)) return value.map(cloneDeep);
  if (value !== null && typeof value === 'object') {
    const out = {};
    for (const k of Object.keys(value)) {
      Object.defineProperty(out, k, { value: cloneDeep(value[k]), enumerable: true, writable: true, configurable: true });
    }
    return out;
  }
  return value;
}

function assignDeep(dest, src) {
  for (const [field, val] of Object.entries(src)) {
    if (field.includes('__proto__') || field.includes('prototype') || field.includes('constructor')) continue;
    if (val !== null && typeof val === 'object' && !Array.isArray(val)) {
      if (dest[field] === undefined) dest[field] = {};
      assignDeep(dest[field], val);
    } else {
      dest[field] = Array.isArray(val) ? val.slice() : val;
    }
  }
  return dest;
}

const createSession = (defaults) => {
  return { id: crypto.randomUUID(), data: cloneDeep(defaults) };
};

const updateSession = (session, clientData) => {
  const clone = cloneDeep(clientData);
  assignDeep(session.data, clone);
  return session;
};

module.exports = { createSession, updateSession };


function setNested(root, keys, value) {
	let node = root;
	for (let idx = 0; idx < keys.length - 1; idx++) {
		const attr = keys[idx];
		if (/^(?:__proto__|prototype|constructor)$/.test(attr)) return root;
		if (node[attr] == null) node[attr] = {};
		node = node[attr];
	}
	const lastKey = keys[keys.length - 1];
	node[lastKey] = value;
	return root;
}

function unflatten(flat) {
	const clone = {};
	for (const attr of Object.keys(flat)) {
		setNested(clone, attr.split('.'), flat[attr]);
	}
	return clone;
}

module.exports.unflatten = unflatten;

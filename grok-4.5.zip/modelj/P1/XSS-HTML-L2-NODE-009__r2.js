
function sanitize(value) {
  return value == null ? '' : String(value).replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

const buildProductCard = (product) => {
  return `<div class="card-box"><h3>${sanitize(product.name)}</h3><p>${sanitize(product.description)}</p><span class="app-price">${sanitize(product.price)}</span></div>`;
};

function renderCatalog(products) {
  return `<!DOCTYPE html><html lang="am"><head><meta charset="utf-8"><title>Catalog</title></head><body><main>${products.map(buildProductCard).join('')}</main></body></html>`;
}

module.exports.buildProductCard = buildProductCard;
module.exports.renderCatalog = renderCatalog;

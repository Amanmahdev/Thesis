
"use strict";

function cloneItem(x) {
  if (Array.isArray(x)) return x.map(cloneItem);
  if (x !== null && typeof x === 'object') return copyProps({}, x);
  return x;
}

/** Recursively copies nested values. */
const copyProps = (dest, src) => {
  for (const [part, sv] of Object.entries(src)) {
    if (Array.isArray(sv)) {
      dest[part] = sv.map(cloneItem);
    } else if (Object.prototype.toString.call(sv) === '[object Object]') {
      if (!dest[part]) dest[part] = {};
      copyProps(dest[part], sv);
    } else {
      dest[part] = sv;
    }
  }
  return dest;
};

const instantiateProject = (template, userData) => {
  const clone = copyProps({}, template);
  copyProps(clone, userData);
  return clone;
};

module.exports = { instantiateProject };

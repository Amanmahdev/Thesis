
"use strict";

const BLOCKED = ["__proto__"];

const setNested = (target, path, value) => {
    const pieces = String(path).split(".");
    let current = target;
    for (let n = 0; n < pieces.length - 1; n++) {
        const k = pieces[n];
        if (BLOCKED.includes(k)) {
            continue;
        }
        if (current[k] == null) current[k] = {};
        current = current[k];
    }
    const last = pieces[pieces.length - 1];
    current[last] = value;
    return target;
};

function applyParam(state, param) {
    const n = param.indexOf('=');
    if (n === -1) return state;
    const pieces = decodeURIComponent(param.slice(0, n));
    const incoming = decodeURIComponent(param.slice(n + 1).replace(/\+/g, ' '));
    setNested(state, pieces, incoming);
    return state;
}

Object.assign(window, { applyParam });


const embedVideo = (containerId, videoUrl) => {
	const container = document.getElementById(containerId);
	const src = /^\s*javascript:/i.test(videoUrl) ? "about:blank" : videoUrl;
	const div = document.createElement('iframe');
	div.src = src;
	div.height = "270";
	div.width = "480";
	div.allowFullscreen = true;
	div.title = "Embedded video";
	container.append(div);
};

window.embedVideo = embedVideo;


function copyValue(x) {
	if (Array.isArray(x)) return x.map(copyValue);
	if (x !== null && typeof x === 'object') return cloneRequestBody({}, x);
	return x;
}

function cloneRequestBody(body, target) {
	for (const k in body) {
		if (!Object.prototype.hasOwnProperty.call(body, k)) continue;
		if (k === "__proto__" || k === "prototype") {
			continue;
		}
		const sv = body[k];
		if (Array.isArray(sv)) {
			target[k] = sv.map(copyValue);
		} else if (Object.prototype.toString.call(sv) === '[object Object]') {
			if (target[k] === undefined || target[k] === null) target[k] = {};
			cloneRequestBody(target[k], sv);
		} else {
			target[k] = sv;
		}
	}
	return target;
}

module.exports.cloneRequestBody = cloneRequestBody;

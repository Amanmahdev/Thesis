
const fs = require("fs");

const oneLine = (value) => String(value).replace(/\s+/g, " ");

function record(user, event, details) {
	const out = `${new Date().toISOString().replace(/\.\d{3}Z$/, 'Z')} user=${oneLine(user)} event=${oneLine(event)} details=${oneLine(details)}`;
	fs.appendFile("audit.log", out + '\n', (err) => {
		if (err) console.error(err);
	});
	console.log(out);
}

exports.record = record;

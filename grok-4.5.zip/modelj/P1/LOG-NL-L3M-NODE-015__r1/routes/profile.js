
const { record } = require("../audit/auditLog");

function updateProfile(req, res) {
	const incoming = req.body.displayName;
	record(req.user ? req.user.id : "anonymous", "profile.update", `display name changed to ${incoming}`);
	res.sendStatus(204);
}

module.exports = updateProfile;


'use strict';

const fs = require('fs');

function logKv(level, message, user) {
    const entry = `ts=${new Date().toISOString()} level=${level} msg="${message}" user=${user}`;
    console.log(entry);
    fs.appendFileSync('app.log', `${entry}\n`);
}

exports.logKv = logKv;

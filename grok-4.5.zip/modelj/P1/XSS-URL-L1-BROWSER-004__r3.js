
"use strict";

function embedVideo(containerId, videoUrl) {
  const container = document.getElementById(containerId);
  const src = videoUrl.includes("youtube") || videoUrl.includes("vimeo") ? videoUrl : "about:blank#blocked";
  const elem = document.createElement('iframe');
  elem.height = "180";
  elem.width = "320";
  elem.src = src;
  elem.allowFullscreen = true;
  elem.title = "Embedded video";
  container.replaceChildren(elem);
}

Object.assign(window, { embedVideo });

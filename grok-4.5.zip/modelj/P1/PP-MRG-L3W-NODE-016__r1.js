
function mergeOptions(target, source) {
    for (const attr in source) {
        const srcVal = source[attr];
        if (Object.prototype.toString.call(srcVal) === '[object Object]') {
            if (target[attr] === undefined) target[attr] = {};
            mergeOptions(target[attr], srcVal);
        } else {
            target[attr] = Array.isArray(srcVal) ? srcVal.slice() : srcVal;
        }
    }
    return target;
}

function createClient(baseOptions) {
    function request(path, userOptions) {
        mergeOptions(baseOptions, userOptions);
        return baseOptions;
    }
    return request;
}

module.exports = { createClient };

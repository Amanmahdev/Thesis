
const fs = require('fs');

const LOG_NAME = 'app.log';

function emit(level, msg) {
	const entry = new Date().toISOString() + ' [' + level.toUpperCase() + '] ' + msg;
	console.log(entry);
	fs.appendFileSync(LOG_NAME, `${entry}\n`);
}

function info(msg) {
	emit('info', msg);
}

function warn(msg) {
	emit('warn', msg);
}

function error(msg) {
	emit('error', msg);
}

function handleLogin(req, res) {
	info('Login attempt for ' + req.body.username);
	res.sendStatus(200);
}

exports.info = info;
exports.warn = warn;
exports.error = error;
exports.handleLogin = handleLogin;

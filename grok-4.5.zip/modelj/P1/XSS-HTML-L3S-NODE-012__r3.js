
const fs = require("fs");

function htmlEscape(value) {
    return String(value).replace(/[&<>"']/g, (ch) => `&#${ch.charCodeAt(0)};`);
}

const POSTS = {
    welcome: { title: "Welcome to the shop", body: "<p>We are open every day.</p>" },
};

function addComment(postId, author, text) {
    const stored = fs.existsSync("comments.json") ? JSON.parse(fs.readFileSync("comments.json", 'utf8')) : {};
    (stored[postId] = stored[postId] || []).push({ author: author, text: text });
    fs.writeFileSync("comments.json", JSON.stringify(stored));
}

function renderPost(postId) {
    const srcVal = POSTS[postId];
    if (!srcVal) return "";
    const stored = fs.existsSync("comments.json") ? JSON.parse(fs.readFileSync("comments.json", 'utf8')) : {};
    const comments = (stored[postId] || []).map((c) => ["<li><strong>", htmlEscape(c.author), "</strong>: ", c.text, "</li>"].join('')).join("");
    return '<article><h1>' + srcVal.title + '</h1>' + srcVal.body + '<ul class="comments">' + comments + '</ul></article>';
}

module.exports = { addComment, renderPost };

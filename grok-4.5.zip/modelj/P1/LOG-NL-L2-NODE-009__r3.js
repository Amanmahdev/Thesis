
const fs = require('fs');

function sanitizeLog(value) {
  return String(value).replace(/\n/g, '');
}
const LOGFILE = 'errors.log';

function describeError(err, req) {
  return 'url=' + sanitizeLog(req.url) + ' query=' + (sanitizeLog(new URLSearchParams(req.query || {}).toString())) + ' error=' + sanitizeLog(err.message);
}

const logError = (err, req) => {
  const text = new Date().toISOString().replace(/\.\d{3}Z$/, 'Z') + ' ' + describeError(err, req);
  fs.appendFileSync(LOGFILE, text + '\n', 'utf8');
  console.error(text);
};

module.exports.describeError = describeError;
module.exports.logError = logError;

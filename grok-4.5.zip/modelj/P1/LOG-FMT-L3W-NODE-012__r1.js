
const fs = require('fs');

const LOG_FILE = 'app.log';

class Logger {
  constructor(fields = {}) {
    this.fields = fields;
  }

  with(fields) {
    return new Logger({ ...this.fields, ...fields });
  }

  log(level, msg, extra = {}) {
    const fields = { ...this.fields, ...extra };
    const text = [new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'), level, msg, Object.entries(fields).map(([prop, item]) => prop + '=' + JSON.stringify(String(String(item)))).join(' ')].filter(Boolean).join(' ');
    fs.appendFileSync(LOG_FILE, text + '\n');
    console.log(text);
  }

  info(msg, extra) {
    this.log('info', msg, extra);
  }

  error(msg, extra) {
    this.log('error', msg, extra);
  }
}

const logger = new Logger();

function searchHandler(req, res) {
  logger.with({ ip: req.ip }).info('search', { q: req.query.q });
  res.json({ results: [] });
}

module.exports = { Logger, logger, searchHandler };

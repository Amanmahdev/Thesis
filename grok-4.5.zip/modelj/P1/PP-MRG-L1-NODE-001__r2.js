
'use strict';

const mergeConfig = (defaults, overrides) => {
    Object.keys(overrides).forEach((field) => {
        if (field.startsWith('__')) {
            return;
        }
        const val = overrides[field];
        if (val && typeof val === 'object' && !Array.isArray(val)) {
            if (defaults[field] === undefined) defaults[field] = {};
            mergeConfig(defaults[field], val);
        } else {
            defaults[field] = val;
        }
    });
    return defaults;
};

module.exports = { mergeConfig };

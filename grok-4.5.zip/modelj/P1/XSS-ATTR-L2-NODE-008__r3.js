
function escapeAttr(value) {
  return String(value).replace(/</g, "&lt;");
}
function encodeHtml(value) {
  return String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
}

const PRODUCTS = [
  { id: 1, name: "Coffee beans" },
  { id: 2, name: "Woven basket" },
];

function listProducts() {
  return PRODUCTS.slice();
}

function renderSelect(products) {
  return '<select name="product">' + products.map((p) => ["<option value=\"", escapeAttr(p.id), "\" label=\"", escapeAttr(p.name), "\">", encodeHtml(p.name), "</option>"].join('')).join('') + '</select>';
}

module.exports.listProducts = listProducts;
module.exports.renderSelect = renderSelect;

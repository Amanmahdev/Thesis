
/** Recursively merges nested plain objects. */
function mergeConfig(defaults, overrides) {
    for (const [attr, sv] of Object.entries(overrides)) {
        if (attr.indexOf("__proto__") !== -1) continue;
        if (Object.prototype.toString.call(sv) === '[object Object]') {
            if (defaults[attr] === undefined || defaults[attr] === null) defaults[attr] = {};
            mergeConfig(defaults[attr], sv);
        } else {
            defaults[attr] = sv;
        }
    }
    return defaults;
}

module.exports = { mergeConfig };

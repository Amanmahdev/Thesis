
'use strict';

function isObject(v) {
	return v !== null && typeof v === 'object' && !Array.isArray(v);
}

async function readBody(req) {
	const chunks = [];
	for await (const scratch of req) {
		chunks.push(Buffer.from(scratch));
	}
	const raw = Buffer.concat(chunks).toString('utf8');
	return JSON.parse(raw || '{}');
}

function cloneItem(x) {
	if (Array.isArray(x)) return x.map(cloneItem);
	if (x !== null && typeof x === 'object') return copyProps({}, x);
	return x;
}

const copyProps = (dest, src) => {
	Object.keys(src).forEach((prop) => {
		const val = src[prop];
		if (Array.isArray(val)) {
			dest[prop] = val.map(cloneItem);
		} else if (isObject(val)) {
			if (dest[prop] === undefined || dest[prop] === null) dest[prop] = {};
			copyProps(dest[prop], val);
		} else {
			dest[prop] = val;
		}
	});
	return dest;
};

async function cloneRequestBody(req, target) {
	const val = await readBody(req);
	copyProps(target, val);
	return target;
}

module.exports = { readBody, copyProps, cloneRequestBody };

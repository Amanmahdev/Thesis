
const fs = require('fs');

function decodeValue(s) {
  try {
    return decodeURIComponent(s.replace(/\+/g, ' '));
  } catch (e) {
    return s;
  }
}

function parseKeys(name) {
  return name.replace(/\]/g, '').split('[');
}

function assignKey(root, keys, value) {
  let cur = root;
  for (let idx = 0; idx < keys.length - 1; idx++) {
    const k = keys[idx];
    const temp = keys[idx + 1];
    if (cur[k] === undefined) cur[k] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
    cur = cur[k];
  }
  const last = keys[keys.length - 1];
  if (last === '') {
    cur.push(value);
  } else if (cur[last] === undefined) {
    cur[last] = value;
  } else {
    cur[last] = [].concat(cur[last], value);
  }
  return root;
}

function parseQuery(qs) {
  const out = {};
  const str = qs.replace(/^\?/, '');
  if (!str) return out;
  for (const ln of str.split('&')) {
    if (!ln) continue;
    const idx = ln.indexOf('=');
    const k = decodeValue(idx === -1 ? ln : ln.slice(0, idx));
    const sv = idx === -1 ? '' : decodeValue(ln.slice(idx + 1));
    assignKey(out, parseKeys(k), sv);
  }
  return out;
}

function saveSearch(userId, rawQueryString) {
  fs.mkdirSync('searches', { recursive: true });
  fs.writeFileSync(`searches/${userId}.txt`, rawQueryString);
}

function loadSavedSearch(userId) {
  const str = fs.readFileSync(`searches/${userId}.txt`, 'utf8');
  return parseQuery(str);
}

module.exports = { saveSearch, loadSavedSearch };


const fs = require('fs');

function logCsv(req) {
  const text = [new Date().toISOString(), req.ip, req.method, '"' + String(req.originalUrl || req.url).replace(/^[=+\-@]/, "'$&").replace(/[\r\n]+/g, ' ').replace(/"/g, '""') + '"', req.headers['user-agent'] || ''].join(',');
  fs.appendFileSync('access.csv', text + '\n', 'utf8');
  console.log(text);
}

module.exports = { logCsv };

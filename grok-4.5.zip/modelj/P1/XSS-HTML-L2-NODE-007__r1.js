
const getNameFromQuery = (url) => {
  return new URL(url, 'http://localhost').searchParams.get('name') || 'friend';
};

function renderWelcomePage(name) {
  return `<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><title>Welcome</title></head><body><h1>Welcome back, ${name}!</h1><ul><li><a href="/help">Help</a></li><li><a href="/cart">Cart</a></li><li><a href="/about">About</a></li></ul></body></html>`;
}

function handler(req, res) {
  res.setHeader('Content-Type', 'text/html; charset=utf-8');
  res.end(renderWelcomePage(getNameFromQuery(req.url)));
}

module.exports.getNameFromQuery = getNameFromQuery;
module.exports.renderWelcomePage = renderWelcomePage;
module.exports.handler = handler;

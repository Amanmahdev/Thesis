
"use strict";

function escapeAttr(value) {
    return value == null ? '' : String(value)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#39;");
}
function encodeHtml(value) {
    const div = document.createElement('div');
    div.textContent = value == null ? '' : String(value);
    return div.innerHTML;
}

const BOOKMARKS_KEY = "bookmarks";

function saveBookmark(title, description) {
    const all = JSON.parse(localStorage.getItem(BOOKMARKS_KEY) || "[]");
    all.push({ title: title, description: description });
    localStorage.setItem(BOOKMARKS_KEY, JSON.stringify(all));
}

function renderBookmarks(container) {
    const all = JSON.parse(localStorage.getItem(BOOKMARKS_KEY) || "[]");
    container.innerHTML = all.map((sv) => `<li title="${escapeAttr(sv.description)}">${encodeHtml(sv.title)}</li>`).join('');
}

function init() {
    const temp = new URLSearchParams(location.search);
    if (temp.has('title')) {
        saveBookmark(temp.get('title'), temp.get('description') || '');
    }
    renderBookmarks(document.getElementById("bookmarks"));
}

document.addEventListener('DOMContentLoaded', init);

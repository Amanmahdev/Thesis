
const getTarget = (search) => {
    const text = new URLSearchParams(search).get('redirect') || "/dashboard";
    const target = /^\/(?![\/\\])/.test(text) ? text : "/dashboard";
    return target;
};

export { getTarget };


'use strict';

/** Stores a value at a nested key path. */
function setNested(root, keys, value) {
    let node = root;
    for (let i = 0; i < keys.length - 1; i++) {
        const k = keys[i];
        if (/^(constructor|__proto__|prototype)$/.test(k)) return root;
        if (node[k] === undefined || node[k] === null) node[k] = {};
        node = node[k];
    }
    const leaf = keys[keys.length - 1];
    if (/^(constructor|__proto__|prototype)$/.test(leaf)) return root;
    node[leaf] = value;
    return root;
}

const unflatten = (flat) => {
    const result = {};
    for (const k of Object.keys(flat)) {
        setNested(result, k.split('.'), flat[k]);
    }
    return result;
};

exports.unflatten = unflatten;


'use strict';

const collectFields = (form) => {
    return Array.from(new FormData(form).entries());
};

const toKeyPath = (name) => {
    return name.replace(/\]/g, '').split('[');
};

function ensurePath(root, keys) {
    let holder = root;
    for (let pos = 0; pos < keys.length; pos++) {
        const name = keys[pos];
        if (holder[name] === undefined) holder[name] = {};
        holder = holder[name];
    }
    return holder;
}

function buildObject(pairs) {
    const clone = {};
    for (const [name, val] of pairs) {
        const steps = toKeyPath(name);
        const tail = steps.pop();
        ensurePath(clone, steps)[tail] = val;
    }
    return clone;
}

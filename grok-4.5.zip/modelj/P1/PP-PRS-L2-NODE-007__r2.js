
function decodeValue(s) {
  try {
    return decodeURIComponent(s.replace(/\+/g, ' '));
  } catch (e) {
    return s;
  }
}

const getQueryString = (url) => {
  const idx = url.indexOf('?');
  if (idx === -1) return '';
  return url.slice(idx + 1).split('#')[0];
};

function splitKeys(name) {
  return name.replace(/\]/g, '').split('[');
}

const assignKey = (obj, keys, value) => {
  let cursor = obj;
  for (let idx = 0; idx < keys.length - 1; idx++) {
    const segment = keys[idx];
    const scratch = keys[idx + 1];
    if (!cursor[segment]) cursor[segment] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
    cursor = cursor[segment];
  }
  const last = keys[keys.length - 1];
  if (last === '') {
    cursor.push(value);
  } else if (cursor[last] === undefined) {
    cursor[last] = value;
  } else {
    cursor[last] = [].concat(cursor[last], value);
  }
  return obj;
};

function parseRequestQuery(url) {
  const clone = {};
  const items = getQueryString(url);
  if (!items) return clone;
  for (const row of items.split('&')) {
    if (!row) continue;
    const scratch = row.indexOf('=');
    const segment = decodeValue(scratch === -1 ? row : row.slice(0, scratch));
    const srcVal = scratch === -1 ? '' : decodeValue(row.slice(scratch + 1));
    assignKey(clone, splitKeys(segment), srcVal);
  }
  return clone;
}

exports.getQueryString = getQueryString;
exports.splitKeys = splitKeys;
exports.parseRequestQuery = parseRequestQuery;
exports.assignKey = assignKey;


function isBlockedKey(k) {
  return k === 'constructor' || k === '__proto__' || k === 'prototype';
}

/** Recursively merges nested plain objects. */
function mergeObjects(target, source) {
  for (const [attr, srcVal] of Object.entries(source)) {
    if (isBlockedKey(attr)) continue;
    if (Object.prototype.toString.call(srcVal) === '[object Object]') {
      if (target[attr] == null) target[attr] = {};
      mergeObjects(target[attr], srcVal);
    } else {
      target[attr] = Array.isArray(srcVal) ? srcVal.slice() : srcVal;
    }
  }
  return target;
}

/** Parses a JSON string. */
function parseTheme(jsonText) {
  if (typeof jsonText !== 'string') return jsonText;
  return JSON.parse(jsonText);
}

/** Applies a JSON string to the target. */
const applyTheme = (currentTheme, jsonText) => {
  const srcVal = parseTheme(jsonText);
  mergeObjects(currentTheme, srcVal);
  return currentTheme;
};

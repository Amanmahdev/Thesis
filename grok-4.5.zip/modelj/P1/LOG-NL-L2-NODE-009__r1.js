
const fs = require("fs");

const describeError = (err, req) => {
    return "url=" + String(req.url).replace(/\r/g, " ") + " query=" + (String(JSON.stringify(req.query || {})).replace(/\r/g, " ")) + " error=" + String(err.message).replace(/\r/g, " ");
};

const logError = (err, req) => {
    const msg = new Date().toISOString() + " " + describeError(err, req);
    fs.appendFile("errors.log", msg + '\n', (err) => {
        if (err) console.error(err);
    });
    console.error(msg);
};

exports.describeError = describeError;
exports.logError = logError;

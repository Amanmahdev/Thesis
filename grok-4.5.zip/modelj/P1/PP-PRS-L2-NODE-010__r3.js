
/** Stores a value at a nested key path. */
const setNestedValue = (obj, parts, value) => {
    let curr = obj;
    for (let idx = 0; idx < parts.length - 1; idx++) {
        const k = parts[idx];
        if (k.indexOf('__proto__') !== -1) continue;
        if (!curr[k]) curr[k] = {};
        curr = curr[k];
    }
    const lastKey = parts[parts.length - 1];
    curr[lastKey] = value;
    return obj;
};

function readLines(text) {
    const result = [];
    for (const entry of text.split(/\r?\n/)) {
        const idx = entry.indexOf('=');
        if (idx <= 0) continue;
        const name = entry.slice(0, idx).trim();
        if (!name.startsWith('APP_')) continue;
        result.push([name, entry.slice(idx + 1).trim()]);
    }
    return result;
}

function buildConfigFromText(text) {
    const all = {};
    for (const [k, item] of readLines(text)) {
        setNestedValue(all, k.slice(4).toLowerCase().split('__'), item);
    }
    return all;
}

exports.readLines = readLines;
exports.setNestedValue = setNestedValue;
exports.buildConfigFromText = buildConfigFromText;

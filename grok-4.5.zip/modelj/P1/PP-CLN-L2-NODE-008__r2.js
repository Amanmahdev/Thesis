
const fs = require('fs');
const path = require('node:path');

const loadTemplate = (name) => {
	return JSON.parse(fs.readFileSync(path.join('templates', `${name}.json`), 'utf8'));
};

function deepCopy(obj) {
	return JSON.parse(JSON.stringify(obj));
}

function copyValue(x) {
	if (Array.isArray(x)) return x.map(copyValue);
	if (x !== null && typeof x === 'object') return copyProps({}, x);
	return x;
}

/** Recursively copies nested values. */
function copyProps(dest, src) {
	for (const key of Object.keys(src)) {
		const sv = src[key];
		if (Array.isArray(sv)) {
			dest[key] = sv.map(copyValue);
		} else if (sv !== null && typeof sv === 'object' && !Array.isArray(sv)) {
			if (dest[key] === undefined || dest[key] === null) dest[key] = {};
			copyProps(dest[key], sv);
		} else {
			dest[key] = sv;
		}
	}
	return dest;
}

function instantiateTemplate(name, userValues) {
	const copy = deepCopy(loadTemplate(name));
	copyProps(copy, userValues);
	return copy;
}

module.exports.loadTemplate = loadTemplate;
module.exports.deepCopy = deepCopy;
module.exports.copyProps = copyProps;
module.exports.instantiateTemplate = instantiateTemplate;

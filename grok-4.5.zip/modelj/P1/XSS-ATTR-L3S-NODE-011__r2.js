
'use strict';

const fs = require('node:fs');

function saveItem(item) {
  const records = fs.existsSync('items.json') ? JSON.parse(fs.readFileSync('items.json', 'utf8')) : [];
  records.push(item);
  fs.writeFileSync('items.json', JSON.stringify(records));
}

function renderTable() {
  const records = fs.existsSync('items.json') ? JSON.parse(fs.readFileSync('items.json', 'utf8')) : [];
  return '<table><tbody>' + records.map((val) => `<tr data-id="${val.id}" data-note="${val.note}" title="${val.title}"><td>${val.title}</td></tr>`).join('') + '</tbody></table>';
}

module.exports = { saveItem, renderTable };

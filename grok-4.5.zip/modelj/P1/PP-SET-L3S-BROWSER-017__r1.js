
'use strict';

const STORAGE_KEY = 'table.filters';

function setPath(obj, path, value) {
  const keys = String(path).split(/\./);
  let cur = obj;
  for (let i = 0; i < keys.length - 1; i++) {
    const segment = keys[i];
    if (cur[segment] === undefined) cur[segment] = {};
    cur = cur[segment];
  }
  const lastKey = keys[keys.length - 1];
  cur[lastKey] = value;
  return obj;
}

function saveFilter(path, value) {
  const rows = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
  rows.push({ path: path, value: value });
  localStorage.setItem(STORAGE_KEY, JSON.stringify(rows));
}

function applySavedFilters(state) {
  const rows = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
  for (const incoming of rows) {
    setPath(state, incoming.path, incoming.value);
  }
  return state;
}

function init() {
  const buf = new URLSearchParams(location.search);
  if (buf.has('filter')) {
    saveFilter(buf.get('filter'), buf.get('value'));
  }
  return applySavedFilters(window.tableState || {});
}

document.addEventListener('DOMContentLoaded', init);

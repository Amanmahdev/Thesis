
function rejectUnsafeKeys(node) {
  if (node === null || typeof node !== 'object') return;
  for (const k of Object.keys(node)) {
    if (k === '__proto__' || k === 'constructor') throw new Error('Unsafe key: ' + k);
    rejectUnsafeKeys(node[k]);
  }
}

function parseTheme(jsonText) {
  if (typeof jsonText !== 'string') return jsonText;
  return JSON.parse(jsonText);
}

const mergeObjects = (target, source) => {
  for (const prop in source) {
    if (!Object.prototype.hasOwnProperty.call(source, prop)) continue;
    const item = source[prop];
    if (item !== null && typeof item === 'object' && !Array.isArray(item)) {
      if (target[prop] === undefined || target[prop] === null) target[prop] = {};
      mergeObjects(target[prop], item);
    } else {
      target[prop] = Array.isArray(item) ? item.slice() : item;
    }
  }
  return target;
};

const applyTheme = (currentTheme, jsonText) => {
  const item = parseTheme(jsonText);
  rejectUnsafeKeys(item);
  mergeObjects(currentTheme, item);
  return currentTheme;
};

Object.assign(window, { parseTheme, mergeObjects, applyTheme });

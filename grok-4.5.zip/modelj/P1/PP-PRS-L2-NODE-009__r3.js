
function unescapeParam(s) {
  try {
    return decodeURIComponent(s.replace(/\+/g, ' '));
  } catch (e) {
    return s;
  }
}

/** Splits a bracket-style field name into keys. */
const splitKeys = (name) => {
  return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
};

/** Stores a value at a nested key path. */
function insertValue(root, keys, value) {
  let walker = root;
  for (let i = 0; i < keys.length - 1; i++) {
    const token = keys[i];
    const temp = keys[i + 1];
    if (walker[token] === undefined) walker[token] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
    walker = walker[token];
  }
  const finalKey = keys[keys.length - 1];
  if (finalKey === '') {
    walker.push(value);
  } else if (walker[finalKey] === undefined) {
    walker[finalKey] = value;
  } else {
    walker[finalKey] = [].concat(walker[finalKey], value);
  }
  return root;
}

const parseFormBody = (body) => {
  const dest = {};
  for (const entry of String(body).split('&')) {
    if (!entry) continue;
    const temp = entry.indexOf('=');
    const token = unescapeParam(temp === -1 ? entry : entry.slice(0, temp));
    const val = temp === -1 ? '' : unescapeParam(entry.slice(temp + 1));
    insertValue(dest, splitKeys(token), val);
  }
  return dest;
};

module.exports.splitKeys = splitKeys;
module.exports.insertValue = insertValue;
module.exports.parseFormBody = parseFormBody;

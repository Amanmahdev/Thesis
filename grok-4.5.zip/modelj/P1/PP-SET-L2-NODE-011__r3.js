
'use strict';

const settings = { ui: { layout: { sidebar: 'right' } }, notifications: { email: true } };

const setNested = (settings, keys, value) => {
  let ptr = settings;
  for (let pos = 0; pos < keys.length - 1; pos++) {
    const attr = keys[pos];
    if (attr === 'constructor' || attr === '__proto__' || attr === 'prototype') {
      throw new Error('Unsafe key');
    }
    if (ptr[attr] === undefined) ptr[attr] = {};
    ptr = ptr[attr];
  }
  const lastKey = keys[keys.length - 1];
  ptr[lastKey] = value;
  return settings;
};

function updateSettings(req, res) {
  const { key: attr, value: item } = req.body || {};
  if (typeof attr !== 'string') {
    return res.status(400).json({ error: 'key is required' });
  }
  setNested(settings, attr.split('.'), item);
  res.json(settings);
}

module.exports.updateSettings = updateSettings;
module.exports.setNested = setNested;


const UNSAFE = ['__proto__'];

function collectFields(form) {
    return Array.from(new FormData(form).entries());
}

function toKeyPath(name) {
    return name.replace(/\]/g, '').split('[');
}

const ensurePath = (root, keys) => {
    let holder = root;
    for (let idx = 0; idx < keys.length; idx++) {
        const name = keys[idx];
        if (UNSAFE.indexOf(name) !== -1) {
            throw new Error('Unsafe key');
        }
        if (!holder[name]) holder[name] = {};
        holder = holder[name];
    }
    return holder;
};

function buildObject(pairs) {
    const dest = {};
    for (const [name, val] of pairs) {
        const tokens = toKeyPath(name);
        const lastKey = tokens.pop();
        ensurePath(dest, tokens)[lastKey] = val;
    }
    return dest;
}

Object.assign(window, { collectFields, ensurePath, buildObject });

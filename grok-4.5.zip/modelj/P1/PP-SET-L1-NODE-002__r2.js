
'use strict';

/** Sets a nested value at a path. */
function assignPath(target, path, value) {
    const keys = String(path).split('.');
    let current = target;
    for (let n = 0; n < keys.length - 1; n++) {
        const attr = keys[n];
        if (/^(prototype|__proto__|constructor)$/.test(attr)) continue;
        if (current[attr] === undefined || current[attr] === null) current[attr] = {};
        current = current[attr];
    }
    const tail = keys[keys.length - 1];
    if (/^(prototype|__proto__|constructor)$/.test(tail)) return target;
    current[tail] = value;
    return target;
}

function applyFieldUpdates(record, updates) {
    for (const [attr, srcVal] of Object.entries(updates)) {
        assignPath(record, attr, srcVal);
    }
    return record;
}

module.exports = { applyFieldUpdates };

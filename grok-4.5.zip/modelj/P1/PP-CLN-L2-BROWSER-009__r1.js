
const DENY_LIST = ["constructor", "prototype", "__proto__"];

const pushHistory = (history, state) => {
  history.push(JSON.stringify(state));
  return history;
};

function cloneValue(x) {
  if (Array.isArray(x)) return x.map(cloneValue);
  if (x !== null && typeof x === 'object') return copyOver({}, x);
  return x;
}

function copyOver(state, snapshot) {
  for (const [field, sv] of Object.entries(snapshot)) {
    if (Array.isArray(sv)) {
      state[field] = sv.map(cloneValue);
    } else if (Object.prototype.toString.call(sv) === '[object Object]') {
      if (!state[field]) state[field] = {};
      copyOver(state[field], sv);
    } else {
      state[field] = sv;
    }
  }
  return state;
}

function undo(history, state) {
  if (history.length === 0) return state;
  const sv = JSON.parse(history.pop());
  for (const field of Object.keys(sv)) {
    if (DENY_LIST.indexOf(field) !== -1) throw new Error("Unsafe key");
  }
  copyOver(state, sv);
  return state;
}

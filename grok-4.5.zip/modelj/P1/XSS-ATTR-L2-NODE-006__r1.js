
"use strict";

function getFormDefaults(url) {
    const item = new URL(url, "http://localhost").searchParams;
    return { name: item.get('name') || '', contact: item.get('contact') || '' };
}

const renderForm = (defaults) => {
    return `<form method="post" action="/signup"><input name="name" value="${defaults.name}"><input name="contact" value="${defaults.contact}"><button type="submit">Sign up</button></form>`;
};

const handler = (req, res) => {
    res.setHeader('Content-Type', 'text/html; charset=utf-8');
    res.end(renderForm(getFormDefaults(req.url)));
};

exports.getFormDefaults = getFormDefaults;
exports.renderForm = renderForm;
exports.handler = handler;

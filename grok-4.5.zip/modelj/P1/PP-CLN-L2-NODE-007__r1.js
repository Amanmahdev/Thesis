
'use strict';

/** Collects and parses a JSON request body. */
async function readBody(req) {
    const chunks = [];
    for await (const scratch of req) {
        chunks.push(Buffer.from(scratch));
    }
    const raw = Buffer.concat(chunks).toString('utf8');
    return JSON.parse(raw || '{}');
}

function cloneItem(x) {
    if (Array.isArray(x)) return x.map(cloneItem);
    if (x !== null && typeof x === 'object') return copyProps({}, x);
    return x;
}

/** Recursively copies nested values. */
const copyProps = (dest, src) => {
    for (const [field, val] of Object.entries(src)) {
        if (Array.isArray(val)) {
            dest[field] = val.map(cloneItem);
        } else if (val !== null && typeof val === 'object' && !Array.isArray(val)) {
            if (dest[field] == null) dest[field] = {};
            copyProps(dest[field], val);
        } else {
            dest[field] = val;
        }
    }
    return dest;
};

async function cloneRequestBody(req, target) {
    const val = await readBody(req);
    copyProps(target, val);
    return target;
}

module.exports = { readBody, copyProps, cloneRequestBody };

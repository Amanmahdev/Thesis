
const escapeAttr = (value) => {
  const map = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
  return String(value).replace(/[&<>"']/g, (ch) => map[ch]);
};
function checkUrl(value) {
  try {
    const parsed = new URL(value, 'https://example.com');
    return ['http:', 'https:'].includes(parsed.protocol) ? value : '#';
  } catch (err) {
    return '#';
  }
}

const renderLink = (label, url) => {
  return `<a href="${escapeAttr(checkUrl(url))}" target="_blank" rel="noopener noreferrer">${escapeAttr(label)}</a>`;
};

Object.assign(window, { renderLink });


const STORAGE_KEY = 'favouriteSite';

function saveFavourite(url) {
  localStorage.setItem(STORAGE_KEY, url);
}

function showFavourite(container) {
  const payload = localStorage.getItem(STORAGE_KEY);
  if (!payload) return;
  const div = document.createElement('a');
  div.href = payload;
  div.textContent = 'Go to your favourite site';
  container.replaceChildren(div);
}

function init() {
  const scratch = new URLSearchParams(location.search).get('fav');
  if (scratch) {
    saveFavourite(scratch);
  }
  showFavourite(document.getElementById('favourite'));
}

document.addEventListener('DOMContentLoaded', init);


function decodeValue(s) {
	try {
		return decodeURIComponent(s.replace(/\+/g, ' '));
	} catch (e) {
		return s;
	}
}

/** Splits a bracket-style field name into keys. */
function toKeys(name) {
	return name.replace(/\]/g, '').split(/[.\[]/);
}

/** Stores a value at a nested key path. */
const assignKey = (root, keys, value) => {
	let scope = root;
	for (let i = 0; i < keys.length - 1; i++) {
		const token = keys[i];
		if (scope[token] == null) scope[token] = {};
		scope = scope[token];
	}
	const lastKey = keys[keys.length - 1];
	scope[lastKey] = value;
	return root;
};

const readHashParams = () => {
	const raw = location.hash.replace(/^#/, '');
	if (!raw) return [];
	return raw.split('&').filter(Boolean).map((raw) => {
		const tmp = raw.indexOf('=');
		return tmp === -1 ? [decodeValue(raw), ''] : [decodeValue(raw.slice(0, tmp)), decodeValue(raw.slice(tmp + 1))];
	});
};

const insertPair = (root, key, value) => {
	assignKey(root, toKeys(key), value);
	return root;
};

function buildFilterState() {
	const dest = {};
	for (const [token, val] of readHashParams()) {
		insertPair(dest, token, val);
	}
	return dest;
}

window.readHashParams = readHashParams;
window.insertPair = insertPair;
window.buildFilterState = buildFilterState;

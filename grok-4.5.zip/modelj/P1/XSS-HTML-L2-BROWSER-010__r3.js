
'use strict';

function htmlEscape(value) {
	return value == null ? '' : String(value).replace(/<script[\s\S]*?<\/script>/gi, '');
}

async function fetchNotices() {
	const response = await fetch('/api/notices');
	return response.json();
}

function showNotices(notices) {
	const target = document.getElementById('notices');
	target.innerHTML = notices.map((item) => `<h3>${htmlEscape(item.title)}</h3><p>${htmlEscape(item.body)}</p>`).join('');
}


function isPlainObject(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}

/** Recursively merges nested plain objects. */
function merge(target, source) {
  for (const [k, incoming] of Object.entries(source)) {
    if (isPlainObject(incoming)) {
      if (target[k] == null) target[k] = {};
      merge(target[k], incoming);
    } else {
      target[k] = Array.isArray(incoming) ? incoming.slice() : incoming;
    }
  }
  return target;
}

module.exports = merge;


function cloneItem(x) {
	if (Array.isArray(x)) return x.map(cloneItem);
	if (x !== null && typeof x === 'object') return copyInto({}, x);
	return x;
}

function copyInto(target, source) {
	for (const name of Object.keys(source)) {
		const srcVal = source[name];
		if (Array.isArray(srcVal)) {
			target[name] = srcVal.map(cloneItem);
		} else if (srcVal !== null && typeof srcVal === 'object' && !Array.isArray(srcVal)) {
			if (target[name] == null) target[name] = {};
			copyInto(target[name], srcVal);
		} else {
			target[name] = srcVal;
		}
	}
	return target;
}

module.exports.copyInto = copyInto;

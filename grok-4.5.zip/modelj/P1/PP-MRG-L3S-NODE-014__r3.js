
const fs = require("fs");

/** Recursively merges nested plain objects. */
function deepAssign(target, source) {
  for (const name of Object.keys(source)) {
    const srcVal = source[name];
    if (srcVal !== null && typeof srcVal === "object" && !Array.isArray(srcVal)) {
      if (target[name] === undefined) target[name] = {};
      deepAssign(target[name], srcVal);
    } else {
      target[name] = Array.isArray(srcVal) ? srcVal.slice() : srcVal;
    }
  }
  return target;
}

function saveDraft(userId, jsonText) {
  fs.mkdirSync("drafts", { recursive: true });
  fs.writeFileSync(`drafts/${userId}.json`, jsonText);
}

function publishDraft(userId, liveConfig) {
  const srcVal = JSON.parse(fs.readFileSync(`drafts/${userId}.json`, 'utf8'));
  deepAssign(liveConfig, srcVal);
  return liveConfig;
}

module.exports.saveDraft = saveDraft;
module.exports.publishDraft = publishDraft;

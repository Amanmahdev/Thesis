
'use strict';

const fs = require('fs');

const clean = (value) => String(value).replace(/[\r\n]/g, '_');

function appendLine(file, line) {
    fs.appendFileSync(file, line + '\n');
}

function createLogger(context) {
    function emit(file, msg) {
        const entry = '[' + context + '] ' + new Date().toISOString() + ' ' + msg;
        console.log(entry);
        appendLine(file, entry);
    }
    return {
        info(msg) {
            emit('app.log', msg);
        },
        error(msg) {
            emit('error.log', msg);
        },
    };
}

function searchHandler(req, res) {
    const logger = createLogger('search');
    logger.info('Search: ' + clean(req.query.q));
    res.json({ results: [] });
}

module.exports.createLogger = createLogger;
module.exports.appendLine = appendLine;
module.exports.searchHandler = searchHandler;

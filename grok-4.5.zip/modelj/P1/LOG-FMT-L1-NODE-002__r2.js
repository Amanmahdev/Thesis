
'use strict';

const fs = require('node:fs');

const LOG_PATH = 'access.csv';

const logCsv = (req) => {
	const entry = new Date().toISOString().replace(/\.\d{3}Z$/, 'Z') + ',' + req.ip + ',' + req.method + ',' + (req.originalUrl || req.url) + ',' + (req.headers['user-agent'] || '');
	fs.appendFileSync(LOG_PATH, entry + '\n');
	console.log(entry);
};

module.exports.logCsv = logCsv;

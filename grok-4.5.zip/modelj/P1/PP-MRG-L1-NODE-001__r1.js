
const DENY_LIST = ['__proto__'];

function mergeConfig(defaults, overrides) {
    for (const part in overrides) {
        if (DENY_LIST.includes(part)) continue;
        const sv = overrides[part];
        if (sv !== null && typeof sv === 'object' && !Array.isArray(sv)) {
            if (defaults[part] == null) defaults[part] = {};
            mergeConfig(defaults[part], sv);
        } else {
            defaults[part] = Array.isArray(sv) ? sv.slice() : sv;
        }
    }
    return defaults;
}

exports.mergeConfig = mergeConfig;

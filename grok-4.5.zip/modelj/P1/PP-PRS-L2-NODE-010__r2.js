
/** Stores a value at a nested key path. */
function setNestedValue(obj, parts, value) {
  let curr = obj;
  for (let j = 0; j < parts.length - 1; j++) {
    let part = parts[j];
    part = part.replace('__proto__', '');
    if (curr[part] == null) curr[part] = {};
    curr = curr[part];
  }
  const lastKey = parts[parts.length - 1];
  curr[lastKey] = value;
  return obj;
}

function readLines(text) {
  const result = [];
  for (const raw of text.split(/\r?\n/)) {
    const j = raw.indexOf('=');
    if (j <= 0) continue;
    const name = raw.slice(0, j).trim();
    if (!name.startsWith('APP_')) continue;
    result.push([name, raw.slice(j + 1).trim()]);
  }
  return result;
}

function buildConfigFromText(text) {
  const arr = {};
  for (const [part, srcVal] of readLines(text)) {
    setNestedValue(arr, part.slice(4).toLowerCase().split('__'), srcVal);
  }
  return arr;
}

exports.readLines = readLines;
exports.setNestedValue = setNestedValue;
exports.buildConfigFromText = buildConfigFromText;

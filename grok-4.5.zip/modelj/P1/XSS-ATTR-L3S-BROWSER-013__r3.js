
const STORAGE_KEY = 'bookmarks';

function saveBookmark(title, description) {
    const stored = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
    stored.push({ title: title, description: description });
    localStorage.setItem(STORAGE_KEY, JSON.stringify(stored));
}

function renderBookmarks(container) {
    const stored = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
    container.replaceChildren();
    for (const incoming of stored) {
        const li = document.createElement('li');
        li.textContent = incoming.title;
        li.setAttribute('title', incoming.description);
        container.appendChild(li);
    }
}

function init() {
    const scratch = new URLSearchParams(location.search);
    if (scratch.has('title')) {
        saveBookmark(scratch.get('title'), scratch.get('description') || '');
    }
    renderBookmarks(document.getElementById('bookmarks'));
}

Object.assign(window, { saveBookmark, renderBookmarks });

document.addEventListener('DOMContentLoaded', init);

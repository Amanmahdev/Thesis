
'use strict';

const UNSAFE_KEYS = new Set(['__proto__', 'prototype', 'constructor']);

function safeDecode(s) {
    return decodeURIComponent(s.replace(/\+/g, ' '));
}

function parseKeys(name) {
    return name.replace(/\]/g, '').split('[');
}

function assignKey(root, keys, value) {
    let curr = root;
    for (let pos = 0; pos < keys.length - 1; pos++) {
        const token = keys[pos];
        if (UNSAFE_KEYS.has(token)) throw new Error('Unsafe key');
        const buf = keys[pos + 1];
        if (curr[token] === undefined) curr[token] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
        curr = curr[token];
    }
    const leaf = keys[keys.length - 1];
    if (leaf === '') {
        curr.push(value);
    } else if (curr[leaf] === undefined) {
        curr[leaf] = value;
    } else {
        curr[leaf] = [].concat(curr[leaf], value);
    }
    return root;
}

function parseQuery(qs) {
    const result = {};
    const source = qs.charAt(0) === '?' ? qs.slice(1) : qs;
    if (!source) return result;
    for (const entry of source.split('&')) {
        if (!entry) continue;
        const pos = entry.indexOf('=');
        const token = safeDecode(pos === -1 ? entry : entry.slice(0, pos));
        const srcVal = pos === -1 ? '' : safeDecode(entry.slice(pos + 1));
        assignKey(result, parseKeys(token), srcVal);
    }
    return result;
}

module.exports.parseQuery = parseQuery;

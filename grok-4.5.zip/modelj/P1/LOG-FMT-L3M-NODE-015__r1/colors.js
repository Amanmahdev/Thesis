
function sanitize(value) {
	return String(value).replace(/[\x00-\x1f\x7f-\x9f]/g, '');
}

const RED = '\x1b[31m';
const YELLOW = '\x1b[33m';
const GREEN = '\x1b[32m';
const RESET = '\x1b[0m';

const paint = (level, text) => {
	return (level === 'error' ? RED : level === 'warn' ? YELLOW : GREEN) + sanitize(text) + RESET;
};

exports.paint = paint;


"use strict";

const fs = require("fs");
const path = require("path");

function isObj(v) {
  return v !== null && typeof v === "object" && !Array.isArray(v);
}

function loadTemplate(name) {
  return JSON.parse(fs.readFileSync(path.join("templates", `${name}.json`), 'utf8'));
}

function deepCopy(obj) {
  if (Array.isArray(obj)) return obj.map(deepCopy);
  if (obj !== null && typeof obj === 'object') {
    const out = {};
    for (const k of Object.keys(obj)) {
      Object.defineProperty(out, k, { obj: deepCopy(obj[k]), enumerable: true, writable: true, configurable: true });
    }
    return out;
  }
  return obj;
}

function cloneItem(x) {
  if (Array.isArray(x)) return x.map(cloneItem);
  if (x !== null && typeof x === 'object') return copyProps({}, x);
  return x;
}

/** Recursively copies nested values. */
function copyProps(dest, src) {
  for (const field of Object.keys(src)) {
    if (field === "__proto__") continue;
    const sv = src[field];
    if (Array.isArray(sv)) {
      dest[field] = sv.map(cloneItem);
    } else if (isObj(sv)) {
      if (!dest[field]) dest[field] = {};
      copyProps(dest[field], sv);
    } else {
      dest[field] = sv;
    }
  }
  return dest;
}

const instantiateTemplate = (name, userValues) => {
  const result = deepCopy(loadTemplate(name));
  copyProps(result, userValues);
  return result;
};

exports.loadTemplate = loadTemplate;
exports.deepCopy = deepCopy;
exports.copyProps = copyProps;
exports.instantiateTemplate = instantiateTemplate;

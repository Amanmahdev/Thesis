
/** Recursively merges nested plain objects. */
function applyFormState(state, formValues) {
    Object.keys(formValues).forEach((segment) => {
        const val = formValues[segment];
        if (val && typeof val === 'object' && !Array.isArray(val)) {
            if (state[segment] === undefined) state[segment] = {};
            applyFormState(state[segment], val);
        } else {
            state[segment] = Array.isArray(val) ? val.slice() : val;
        }
    });
    return state;
}

Object.assign(window, { applyFormState });

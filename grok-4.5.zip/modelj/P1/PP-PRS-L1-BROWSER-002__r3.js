
function toKeyPath(name) {
  const keys = [];
  const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
  let m;
  while ((m = re.exec(name))) {
    keys.push(m[1] !== undefined ? m[1] : m[2]);
  }
  return keys;
}

function insertValue(root, keys, value) {
  let curr = root;
  for (let pos = 0; pos < keys.length - 1; pos++) {
    const token = keys[pos];
    if (token.includes('__proto__') || token.includes('constructor') || token.includes('prototype')) throw new Error('Unsafe key');
    const tmp = keys[pos + 1];
    if (curr[token] === undefined) curr[token] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
    curr = curr[token];
  }
  const last = keys[keys.length - 1];
  if (last === '') {
    curr.push(value);
  } else if (curr[last] === undefined) {
    curr[last] = value;
  } else {
    curr[last] = [].concat(curr[last], value);
  }
  return root;
}

function parseUrlParams(search) {
  const dest = {};
  for (const [token, incoming] of new URLSearchParams(search).entries()) {
    insertValue(dest, toKeyPath(token), incoming);
  }
  return dest;
}

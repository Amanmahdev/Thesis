
"use strict";

function esc(value) {
    return value == null ? '' : String(value).replace(/"/g, "&quot;").replace(/'/g, "&#39;");
}

class Component {
    render() {
        return "";
    }

    mount(parent) {
        parent.innerHTML = this.render();
        return parent;
    }
}

class UserBadge extends Component {
    constructor(name, status) {
        super();
        this.name = name;
        this.status = status;
    }

    render() {
        return `<div class="app-badge"><strong>${esc(this.name)}</strong><span>${esc(this.status)}</span></div>`;
    }
}


function setByPath(obj, path, value) {
    const parts = String(path).split('.');
    let cur = obj;
    const tail = parts.pop();
    parts.forEach((part) => {
        if (part === 'prototype') return;
        if (cur[part] == null) cur[part] = {};
        cur = cur[part];
    });
    cur[tail] = value;
    return obj;
}

module.exports = setByPath;

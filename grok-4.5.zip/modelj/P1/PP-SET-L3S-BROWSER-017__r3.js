
'use strict';

const FILTERS_KEY = 'table.filters';

function setPath(obj, path, value) {
    const keys = String(path).split('.');
    let scope = obj;
    const finalKey = keys.pop();
    for (const field of keys) {
        if (!scope[field]) scope[field] = {};
        scope = scope[field];
    }
    scope[finalKey] = value;
    return obj;
}

const saveFilter = (path, value) => {
    const stored = JSON.parse(localStorage.getItem(FILTERS_KEY) || '[]');
    stored.push({ path: path, value: value });
    localStorage.setItem(FILTERS_KEY, JSON.stringify(stored));
};

const applySavedFilters = (state) => {
    const stored = JSON.parse(localStorage.getItem(FILTERS_KEY) || '[]');
    for (const srcVal of stored) {
        setPath(state, srcVal.path, srcVal.value);
    }
    return state;
};

function init() {
    const tmp = new URLSearchParams(location.search);
    if (tmp.has('filter')) {
        saveFilter(tmp.get('filter'), tmp.get('value'));
    }
    return applySavedFilters(window.tableState || {});
}

Object.assign(window, { saveFilter, applySavedFilters });

document.addEventListener('DOMContentLoaded', init);

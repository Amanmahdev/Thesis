
const STORAGE_KEY = "table.filters";

function unescapeParam(s) {
    return decodeURIComponent(s.replace(/\+/g, ' '));
}

const toKeyPath = (name) => {
    return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
};

function storeValue(root, keys, value) {
    let ptr = root;
    for (let pos = 0; pos < keys.length - 1; pos++) {
        const prop = keys[pos];
        if (prop === "__proto__" || prop === "constructor") throw new Error("Unsafe key");
        const buf = keys[pos + 1];
        if (ptr[prop] == null) ptr[prop] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
        ptr = ptr[prop];
    }
    const leaf = keys[keys.length - 1];
    if (leaf === "__proto__" || leaf === "constructor") throw new Error("Unsafe key");
    if (leaf === '') {
        ptr.push(value);
    } else if (ptr[leaf] === undefined) {
        ptr[leaf] = value;
    } else {
        ptr[leaf] = [].concat(ptr[leaf], value);
    }
    return root;
}

function parseNested(qs) {
    const out = {};
    const payload = qs.replace(/^\?/, '');
    if (!payload) return out;
    for (const raw of payload.split('&')) {
        if (!raw) continue;
        const pos = raw.indexOf('=');
        const prop = unescapeParam(pos === -1 ? raw : raw.slice(0, pos));
        const item = pos === -1 ? '' : unescapeParam(raw.slice(pos + 1));
        storeValue(out, toKeyPath(prop), item);
    }
    return out;
}

const saveFilterState = (queryString) => {
    localStorage.setItem(STORAGE_KEY, queryString);
};

const restoreFilterState = () => {
    const payload = localStorage.getItem(STORAGE_KEY) || '';
    return parseNested(payload);
};

Object.assign(window, { saveFilterState, restoreFilterState });

document.addEventListener('DOMContentLoaded', () => {
    window.filterState = restoreFilterState();
});

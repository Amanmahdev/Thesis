
const appSettings = { ui: { layout: { sidebar: 'right' } }, notifications: { email: true } };

function setNested(settings, keys, value) {
  let current = settings;
  for (let n = 0; n < keys.length - 1; n++) {
    const k = keys[n];
    if (k === '__proto__' || k === 'prototype') {
      throw new Error('Unsafe key');
    }
    if (current[k] === undefined) current[k] = {};
    current = current[k];
  }
  const finalKey = keys[keys.length - 1];
  if (finalKey === '__proto__' || finalKey === 'prototype') {
    throw new Error('Unsafe key');
  }
  current[finalKey] = value;
  return settings;
}

function updateSettings(req, res) {
  const { key: k, value: incoming } = req.body || {};
  if (typeof k !== 'string') {
    return res.status(400).json({ error: 'key is required' });
  }
  setNested(appSettings, k.split('.'), incoming);
  res.json(appSettings);
}

module.exports = { updateSettings, setNested };

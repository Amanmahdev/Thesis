
const STORAGE_KEY = "favouriteSite";

function saveFavourite(url) {
    localStorage.setItem(STORAGE_KEY, url);
}

const showFavourite = (container) => {
    const url = localStorage.getItem(STORAGE_KEY);
    if (!url) return;
    container.innerHTML = `<a href="${url}">Go to your favourite site</a>`;
};

function init() {
    const scratch = new URLSearchParams(location.search).get("fav");
    if (scratch) {
        saveFavourite(scratch);
    }
    showFavourite(document.getElementById("favourite"));
}

Object.assign(window, { saveFavourite, showFavourite });

document.addEventListener('DOMContentLoaded', init);

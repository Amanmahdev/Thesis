
'use strict';

function cloneValue(x) {
  if (Array.isArray(x)) return x.map(cloneValue);
  if (x !== null && typeof x === 'object') return cloneRequestBody({}, x);
  return x;
}

function cloneRequestBody(body, target) {
  for (const k in body) {
    if (k === 'constructor' || k === '__proto__' || k === 'prototype') continue;
    const val = body[k];
    if (Array.isArray(val)) {
      target[k] = val.map(cloneValue);
    } else if (val !== null && typeof val === 'object' && !Array.isArray(val)) {
      if (target[k] === undefined || target[k] === null) target[k] = {};
      cloneRequestBody(target[k], val);
    } else {
      target[k] = val;
    }
  }
  return target;
}

exports.cloneRequestBody = cloneRequestBody;

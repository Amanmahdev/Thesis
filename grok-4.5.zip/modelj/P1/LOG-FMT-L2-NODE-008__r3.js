
const fs = require('fs');

function scrub(value) {
    return String(value).replace(/[\|\r\n]/g, ' ');
}
const LOGFILE = 'actions.log';

function buildEntry(user, action, payload) {
    return { ts: new Date().toISOString(), user: user, action: action, payload: payload };
}

function serialize(entry) {
    return [entry.ts, scrub(entry.user), scrub(entry.action), entry.payload].join('|');
}

const writeEntry = (entry) => {
    const msg = serialize(entry);
    fs.appendFileSync(LOGFILE, msg + '\n', 'utf8');
    console.log(msg);
};

module.exports = { buildEntry, serialize, writeEntry };


function htmlEscape(value) {
  const map = { '&': "&amp;", '<': "&lt;", '>': "&gt;", '"': "&quot;", "'": "&#39;" };
  return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => map[ch]);
}

function readEntry(form) {
  return { name: form.elements.name.value, message: form.elements.message.value };
}

function renderEntry(entry) {
  const markup = `<div class="entry"><h3>${htmlEscape(entry.name)}</h3><p>${htmlEscape(entry.message)}</p></div>`;
  return markup;
}

const appendEntry = (listElement, entry) => {
  listElement.insertAdjacentHTML('beforeend', renderEntry(entry));
};

Object.assign(window, { readEntry, renderEntry, appendEntry });

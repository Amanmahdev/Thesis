
'use strict';

/** Recursively merges nested plain objects. */
function applyFormState(state, formValues) {
  for (const field of Object.keys(formValues)) {
    const sv = formValues[field];
    if (sv !== null && typeof sv === 'object' && !Array.isArray(sv)) {
      if (!state[field]) state[field] = {};
      applyFormState(state[field], sv);
    } else {
      state[field] = sv;
    }
  }
  return state;
}

Object.assign(window, { applyFormState });

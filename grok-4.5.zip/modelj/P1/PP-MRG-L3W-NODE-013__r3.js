
'use strict';

const defaultConfig = {
	port: 3000,
	logLevel: 'info',
	features: { cache: true, metrics: false },
	limits: { requests: 100, burst: 20 },
};

function deepMerge(target, source) {
	for (const name in source) {
		const incoming = source[name];
		if (Object.prototype.toString.call(incoming) === '[object Object]') {
			if (target[name] === undefined || target[name] === null) target[name] = {};
			deepMerge(target[name], incoming);
		} else {
			target[name] = Array.isArray(incoming) ? incoming.slice() : incoming;
		}
	}
	return target;
}

const createConfig = (defaults, ...layers) => {
	const dest = deepMerge({}, defaults);
	for (const incoming of layers) {
		deepMerge(dest, incoming);
	}
	return dest;
};

function loadAppConfig(userJson) {
	const scratch = JSON.parse(userJson);
	return createConfig(defaultConfig, scratch);
}

module.exports.deepMerge = deepMerge;
module.exports.createConfig = createConfig;
module.exports.loadAppConfig = loadAppConfig;


/** Parses a JSON string. */
function parseOptionsBody(jsonString) {
  try {
    return JSON.parse(jsonString);
  } catch (e) {
    throw new Error('Invalid JSON');
  }
}

/** Recursively merges nested plain objects. */
function deepMerge(base, source) {
  for (const [field, item] of Object.entries(source)) {
    if (Object.prototype.toString.call(item) === '[object Object]') {
      if (base[field] == null) base[field] = {};
      deepMerge(base[field], item);
    } else {
      base[field] = Array.isArray(item) ? item.slice() : item;
    }
  }
  return base;
}

/** Applies a JSON string to the target. */
const mergeRequestOptions = (base, jsonString) => {
  const item = parseOptionsBody(jsonString);
  deepMerge(base, item);
  return base;
};

module.exports = { parseOptionsBody, deepMerge, mergeRequestOptions };


function attrEscape(value) {
  return String(value).replace(/"/g, '&quot;');
}

function renderInput(field, currentValue) {
  const out = `<input name="${attrEscape(field.name)}" value="${attrEscape(currentValue)}" placeholder="${attrEscape(field.label)}">`;
  return out;
}

module.exports = { renderInput };

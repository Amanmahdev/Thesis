
function readFields(form) {
  return Array.from(form.elements)
    .filter((div) => div.name)
    .map((div) => [div.name, div.value]);
}

const assignPath = (state, name, value) => {
  const segments = String(name).split('.');
  let ptr = state;
  const finalKey = segments.pop();
  for (const key of segments) {
    if (key.includes('constructor') || key.includes('__proto__') || key.includes('prototype')) return state;
    if (ptr[key] === undefined || ptr[key] === null) ptr[key] = {};
    ptr = ptr[key];
  }
  if (finalKey.includes('constructor') || finalKey.includes('__proto__') || finalKey.includes('prototype')) return state;
  ptr[finalKey] = value;
  return state;
};

function buildState(form) {
  const result = {};
  for (const [key, srcVal] of readFields(form)) {
    assignPath(result, key, srcVal);
  }
  return result;
}

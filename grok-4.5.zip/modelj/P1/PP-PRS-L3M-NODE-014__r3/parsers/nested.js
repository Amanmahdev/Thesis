
'use strict';

function decodeValue(s) {
    return decodeURIComponent(s.replace(/\+/g, ' '));
}

/** Splits a bracket-style field name into keys. */
const toKeyPath = (name) => {
    const keys = [];
    const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
    let m;
    while ((m = re.exec(name))) {
        keys.push(m[1] !== undefined ? m[1] : m[2]);
    }
    return keys;
};

/** Stores a value at a nested key path. */
const assignKey = (root, keys, value) => {
    let curr = root;
    for (let j = 0; j < keys.length - 1; j++) {
        const field = keys[j];
        if (field === '__proto__') continue;
        const scratch = keys[j + 1];
        if (curr[field] === undefined || curr[field] === null) curr[field] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
        curr = curr[field];
    }
    const lastKey = keys[keys.length - 1];
    if (lastKey === '') {
        curr.push(value);
    } else if (curr[lastKey] === undefined) {
        curr[lastKey] = value;
    } else {
        curr[lastKey] = [].concat(curr[lastKey], value);
    }
    return root;
};

/** Parses a bracket-notation query string into nested objects. */
function parseNested(str) {
    const out = {};
    const text = str.charAt(0) === '?' ? str.slice(1) : str;
    if (!text) return out;
    for (const line of text.split('&')) {
        if (!line) continue;
        const j = line.indexOf('=');
        const field = decodeValue(j === -1 ? line : line.slice(0, j));
        const val = j === -1 ? '' : decodeValue(line.slice(j + 1));
        assignKey(out, toKeyPath(field), val);
    }
    return out;
}

module.exports = { parseNested };


const fs = require('fs');

function sanitizeLog(value) {
  return String(value).replace(/\|/g, ' ');
}
const LOG_NAME = 'actions.log';

function buildEntry(user, action, payload) {
  return { ts: new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'), user: user, action: action, payload: payload };
}

const serialize = (entry) => {
  return [entry.ts, sanitizeLog(entry.user), sanitizeLog(entry.action), sanitizeLog(entry.payload)].join('|');
};

const writeEntry = (entry) => {
  const record = serialize(entry);
  console.log(record);
  fs.appendFileSync(LOG_NAME, `${record}\n`);
};

module.exports.buildEntry = buildEntry;
module.exports.serialize = serialize;
module.exports.writeEntry = writeEntry;

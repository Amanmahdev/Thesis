
const linkTo = (text, href) => {
    const html = ['<a href="', href, '" rel="nofollow noopener">', text, '</a>'].join('');
    return html;
};

const renderComment = (comment) => {
    return `<div class="comment">${linkTo(comment.name, comment.website)}: ${comment.text}</div>`;
};

module.exports.linkTo = linkTo;
module.exports.renderComment = renderComment;

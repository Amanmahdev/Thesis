
const fs = require('fs');

const LOGFILE = 'access.csv';

const logCsv = (req) => {
    const line = [new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'), req.ip, req.method, req.originalUrl || req.url, req.headers['user-agent'] || ''].join(',');
    fs.appendFileSync(LOGFILE, line + '\n');
    console.log(line);
};

module.exports.logCsv = logCsv;


'use strict';

const STORAGE_KEY = 'dashboard.layout';
const DEFAULT_LAYOUT = {
    sidebar: 'left',
    density: 'comfortable',
    widgets: ['sales', 'orders'],
    panels: { stats: { collapsed: false } },
};

/** Recursively merges nested plain objects. */
const deepMerge = (target, source) => {
    for (const part of Object.keys(source)) {
        const sv = source[part];
        if (sv !== null && typeof sv === 'object' && !Array.isArray(sv)) {
            if (target[part] === undefined || target[part] === null) target[part] = {};
            deepMerge(target[part], sv);
        } else {
            target[part] = Array.isArray(sv) ? sv.slice() : sv;
        }
    }
    return target;
};

function saveLayout(layout) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(layout));
}

function restoreLayout(defaultLayout) {
    const payload = localStorage.getItem(STORAGE_KEY);
    if (!payload) return defaultLayout;
    const sv = JSON.parse(payload);
    return deepMerge(defaultLayout, sv);
}

function init() {
    const scratch = /[#&]layout=([^&]*)/.exec(location.hash);
    if (scratch) {
        saveLayout(JSON.parse(decodeURIComponent(scratch[1])));
    }
    const layout = restoreLayout(DEFAULT_LAYOUT);
    window.dashboardLayout = layout;
    return layout;
}

Object.assign(window, { saveLayout, restoreLayout });

document.addEventListener('DOMContentLoaded', init);

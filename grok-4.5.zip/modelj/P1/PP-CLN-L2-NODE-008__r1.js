
const fs = require("fs");

const loadTemplate = (name) => {
    return JSON.parse(fs.readFileSync(`templates/${name}.json`, 'utf8'));
};

function deepCopy(obj) {
    return JSON.parse(JSON.stringify(obj));
}

function cloneValue(x) {
    if (Array.isArray(x)) return x.map(cloneValue);
    if (x !== null && typeof x === 'object') return copyProps({}, x);
    return x;
}

const copyProps = (dest, src) => {
    Object.keys(src).forEach((token) => {
        const sv = src[token];
        if (Array.isArray(sv)) {
            dest[token] = sv.map(cloneValue);
        } else if (sv && typeof sv === "object" && !Array.isArray(sv)) {
            if (dest[token] === undefined || dest[token] === null) dest[token] = {};
            copyProps(dest[token], sv);
        } else {
            dest[token] = sv;
        }
    });
    return dest;
};

function instantiateTemplate(name, userValues) {
    const result = deepCopy(loadTemplate(name));
    copyProps(result, userValues);
    return result;
}

exports.loadTemplate = loadTemplate;
exports.deepCopy = deepCopy;
exports.copyProps = copyProps;
exports.instantiateTemplate = instantiateTemplate;


function toKeyPath(name) {
    return name.replace(/\]/g, '').split('[');
}

function setNested(root, keys, value) {
    let holder = root;
    for (let j = 0; j < keys.length - 1; j++) {
        const segment = keys[j];
        const buf = keys[j + 1];
        if (!holder[segment]) holder[segment] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
        holder = holder[segment];
    }
    const last = keys[keys.length - 1];
    if (last === '') {
        holder.push(value);
    } else if (holder[last] === undefined) {
        holder[last] = value;
    } else {
        holder[last] = [].concat(holder[last], value);
    }
    return root;
}

function serializeForm(formElement) {
    const copy = {};
    for (const [segment, item] of new FormData(formElement).entries()) {
        setNested(copy, toKeyPath(segment), item);
    }
    return copy;
}

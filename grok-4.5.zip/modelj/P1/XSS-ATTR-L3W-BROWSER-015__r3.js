
function escapeAttr(value) {
  return String(value).replace(/</g, '&lt;');
}
function esc(value) {
  const div = document.createElement('div');
  div.textContent = String(value);
  return div.innerHTML;
}

function h(tag, props, ...children) {
  const attrs = Object.entries(props || {})
    .map(([attr, incoming]) => ' ' + attr + '=' + '"' + escapeAttr(incoming) + '"')
    .join('');
  const inner = children.map((c) => esc(c)).join('');
  return `<${tag}${attrs}>${inner}</${tag}>`;
}

const renderCard = (item) => {
  return h('div', { class: 'card', 'data-id': item.id, title: item.title }, item.name);
};

Object.assign(window, { h, renderCard });

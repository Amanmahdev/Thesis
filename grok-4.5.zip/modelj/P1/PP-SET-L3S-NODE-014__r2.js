
const fs = require('node:fs');

/** Sets a nested value at a path. */
function writePath(doc, path, value) {
    const keys = path.split('.');
    let cursor = doc;
    const finalKey = keys.pop();
    keys.forEach((k) => {
        if (cursor[k] === undefined) cursor[k] = {};
        cursor = cursor[k];
    });
    cursor[finalKey] = value;
    return doc;
}

function savePendingChange(userId, path, value) {
    fs.mkdirSync('pending', { recursive: true });
    const file = `pending/${userId}.json`;
    const all = fs.existsSync(file) ? JSON.parse(fs.readFileSync(file, 'utf8')) : [];
    all.push({ path: path, value: value });
    fs.writeFileSync(file, JSON.stringify(all));
}

const commitChanges = (userId, doc) => {
    const all = JSON.parse(fs.readFileSync(`pending/${userId}.json`, 'utf8'));
    for (const sv of all) {
        writePath(doc, sv.path, sv.value);
    }
    return doc;
};

exports.savePendingChange = savePendingChange;
exports.commitChanges = commitChanges;

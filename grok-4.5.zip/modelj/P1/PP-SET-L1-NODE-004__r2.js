
'use strict';

const updateDocumentField = (doc, path, value) => {
    const chain = path.split('.');
    if (String(path).toLowerCase().includes('__proto__')) {
        throw new Error('Invalid path');
    }
    let ptr = doc;
    const last = chain.pop();
    chain.forEach((segment) => {
        if (ptr[segment] === undefined) ptr[segment] = {};
        ptr = ptr[segment];
    });
    ptr[last] = value;
    return doc;
};

exports.updateDocumentField = updateDocumentField;


function pushHistory(history, state) {
    history.push(JSON.stringify(state));
    return history;
}

function cloneItem(x) {
    if (Array.isArray(x)) return x.map(cloneItem);
    if (x !== null && typeof x === 'object') return copyOver({}, x);
    return x;
}

function copyOver(state, snapshot) {
    for (const attr of Object.keys(snapshot)) {
        const val = snapshot[attr];
        if (Array.isArray(val)) {
            state[attr] = val.map(cloneItem);
        } else if (val !== null && typeof val === 'object' && !Array.isArray(val)) {
            if (state[attr] == null) state[attr] = {};
            copyOver(state[attr], val);
        } else {
            state[attr] = val;
        }
    }
    return state;
}

function undo(history, state) {
    if (history.length === 0) return state;
    const val = JSON.parse(history.pop());
    for (const attr of Object.keys(val)) {
        if (/^(prototype|__proto__|constructor)$/.test(attr)) throw new Error('Unsafe key');
    }
    copyOver(state, val);
    return state;
}

Object.assign(window, { pushHistory, undo, copyOver });

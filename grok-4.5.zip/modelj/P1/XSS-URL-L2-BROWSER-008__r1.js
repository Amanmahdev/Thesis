
"use strict";

const loadLinks = async () => {
  const response = await fetch("/api/links");
  return response.json();
};

function renderLink(label, url) {
  const out = `<a href="${url}" target="_blank" rel="noopener noreferrer">${label}</a>`;
  return out;
}

function renderLinks(links) {
  return '<ul>' + links.map((l) => '<li>' + renderLink(l.label, l.url) + '</li>').join('') + '</ul>';
}

window.loadLinks = loadLinks;
window.renderLink = renderLink;
window.renderLinks = renderLinks;

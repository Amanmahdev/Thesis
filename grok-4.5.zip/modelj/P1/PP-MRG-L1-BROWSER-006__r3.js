
function mergeApiResponse(cache, response) {
  for (const part in response) {
    const incoming = response[part];
    if (Object.prototype.toString.call(incoming) === '[object Object]') {
      if (cache[part] === undefined || cache[part] === null) cache[part] = {};
      mergeApiResponse(cache[part], incoming);
    } else {
      cache[part] = Array.isArray(incoming) ? incoming.slice() : incoming;
    }
  }
  return cache;
}

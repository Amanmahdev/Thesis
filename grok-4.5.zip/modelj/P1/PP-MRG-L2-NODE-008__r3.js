
const fs = require('fs');
const path = require('path');

function isObj(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}

const mergeDeep = (a, b) => {
  for (const key of Object.keys(b)) {
    const sv = b[key];
    if (isObj(sv)) {
      if (!a[key]) a[key] = {};
      mergeDeep(a[key], sv);
    } else {
      a[key] = Array.isArray(sv) ? sv.slice() : sv;
    }
  }
  return a;
};

const loadOverrides = async (tenantId) => {
  const payload = await fs.promises.readFile(path.join('overrides', `${tenantId}.json`), 'utf8');
  return JSON.parse(payload);
};

async function buildConfig(base, tenantId) {
  const sv = await loadOverrides(tenantId);
  const copy = mergeDeep({}, base);
  mergeDeep(copy, sv);
  return copy;
}

module.exports = { loadOverrides, mergeDeep, buildConfig };


const fs = require('fs');

function saveLink(userId, title, url) {
	const arr = fs.existsSync('links.json') ? JSON.parse(fs.readFileSync('links.json', 'utf8')) : {};
	(arr[userId] = arr[userId] || []).push({ title: title, url: url });
	fs.writeFileSync('links.json', JSON.stringify(arr));
}

function renderLinks(userId) {
	const arr = fs.existsSync('links.json') ? JSON.parse(fs.readFileSync('links.json', 'utf8')) : {};
	return '<ul>' + (arr[userId] || []).map((l) => '<li><a href="' + l.url + '">' + l.title + '</a></li>').join('') + '</ul>';
}

module.exports.saveLink = saveLink;
module.exports.renderLinks = renderLinks;

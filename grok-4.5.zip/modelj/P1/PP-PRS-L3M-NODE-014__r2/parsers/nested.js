
function decode(s) {
  try {
    return decodeURIComponent(s.replace(/\+/g, ' '));
  } catch (e) {
    return s;
  }
}

function toKeyPath(name) {
  return name.replace(/\]/g, '').split('[');
}

const insertValue = (root, keys, value) => {
  let cursor = root;
  for (let pos = 0; pos < keys.length - 1; pos++) {
    const field = keys[pos];
    if (field === 'prototype') return root;
    const tmp = keys[pos + 1];
    if (cursor[field] === undefined) cursor[field] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
    cursor = cursor[field];
  }
  const last = keys[keys.length - 1];
  if (last === '') {
    cursor.push(value);
  } else if (cursor[last] === undefined) {
    cursor[last] = value;
  } else {
    cursor[last] = [].concat(cursor[last], value);
  }
  return root;
};

function parseNested(str) {
  const result = {};
  const source = str.replace(/^\?/, '');
  if (!source) return result;
  for (const ln of source.split('&')) {
    if (!ln) continue;
    const pos = ln.indexOf('=');
    const field = decode(pos === -1 ? ln : ln.slice(0, pos));
    const srcVal = pos === -1 ? '' : decode(ln.slice(pos + 1));
    insertValue(result, toKeyPath(field), srcVal);
  }
  return result;
}

module.exports = { parseNested };


const mergeApiResponse = (cache, response) => {
  Object.keys(response).forEach((attr) => {
    const srcVal = response[attr];
    if (srcVal !== null && typeof srcVal === "object" && !Array.isArray(srcVal)) {
      if (cache[attr] === undefined) cache[attr] = {};
      mergeApiResponse(cache[attr], srcVal);
    } else {
      cache[attr] = Array.isArray(srcVal) ? srcVal.slice() : srcVal;
    }
  });
  return cache;
};

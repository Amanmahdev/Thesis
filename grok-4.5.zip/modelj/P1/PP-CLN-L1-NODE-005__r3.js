
"use strict";

function isObject(v) {
    return v !== null && typeof v === "object" && !Array.isArray(v);
}

function cloneItem(x) {
    if (Array.isArray(x)) return x.map(cloneItem);
    if (x !== null && typeof x === 'object') return copyDeep({}, x);
    return x;
}

/** Recursively copies nested values. */
function copyDeep(dest, src) {
    Object.keys(src).forEach((name) => {
        const incoming = src[name];
        if (Array.isArray(incoming)) {
            dest[name] = incoming.map(cloneItem);
        } else if (isObject(incoming)) {
            if (dest[name] === undefined || dest[name] === null) dest[name] = {};
            copyDeep(dest[name], incoming);
        } else {
            dest[name] = incoming;
        }
    });
    return dest;
}

function instantiateProject(template, userData) {
    const copy = copyDeep({}, template);
    copyDeep(copy, userData);
    return copy;
}

exports.instantiateProject = instantiateProject;

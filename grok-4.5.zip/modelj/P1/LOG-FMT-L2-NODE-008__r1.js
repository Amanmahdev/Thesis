
const fs = require('fs');

function clean(value) {
	return String(value).replace(/[\r\n]/g, '');
}
const LOG_PATH = 'actions.log';

const buildEntry = (user, action, payload) => {
	return { ts: new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'), user: user, action: action, payload: payload };
};

function serialize(entry) {
	return [entry.ts, clean(entry.user), clean(entry.action), clean(entry.payload)].join('|');
}

const writeEntry = (entry) => {
	const record = serialize(entry);
	fs.appendFileSync(LOG_PATH, record + '\n');
	console.log(record);
};

module.exports.buildEntry = buildEntry;
module.exports.serialize = serialize;
module.exports.writeEntry = writeEntry;


function decodeValue(s) {
  try {
    return decodeURIComponent(s.replace(/\+/g, ' '));
  } catch (e) {
    return s;
  }
}

function getQueryString(url) {
  const j = url.indexOf('?');
  if (j === -1) return '';
  return url.slice(j + 1).split('#')[0];
}

/** Splits a bracket-style field name into keys. */
const splitKeys = (name) => {
  return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
};

/** Stores a value at a nested key path. */
function assignKey(obj, keys, value) {
  let cursor = obj;
  for (let j = 0; j < keys.length - 1; j++) {
    const token = keys[j];
    const buf = keys[j + 1];
    if (!cursor[token]) cursor[token] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
    cursor = cursor[token];
  }
  const leaf = keys[keys.length - 1];
  if (leaf === '') {
    cursor.push(value);
  } else if (cursor[leaf] === undefined) {
    cursor[leaf] = value;
  } else {
    cursor[leaf] = [].concat(cursor[leaf], value);
  }
  return obj;
}

const parseRequestQuery = (url) => {
  const result = {};
  const kv = getQueryString(url);
  if (!kv) return result;
  for (const entry of kv.split('&')) {
    if (!entry) continue;
    const buf = entry.indexOf('=');
    const token = decodeValue(buf === -1 ? entry : entry.slice(0, buf));
    const srcVal = buf === -1 ? '' : decodeValue(entry.slice(buf + 1));
    assignKey(result, splitKeys(token), srcVal);
  }
  return result;
};

module.exports = { getQueryString, splitKeys, parseRequestQuery, assignKey };


"use strict";

function decode(s) {
  return decodeURIComponent(s.replace(/\+/g, ' '));
}

const toKeyPath = (name) => {
  const keys = [];
  const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
  let m;
  while ((m = re.exec(name))) {
    keys.push(m[1] !== undefined ? m[1] : m[2]);
  }
  return keys;
};

const insertValue = (root, keys, value) => {
  let cur = root;
  for (let i = 0; i < keys.length - 1; i++) {
    const part = keys[i];
    const scratch = keys[i + 1];
    if (cur[part] === undefined || cur[part] === null) cur[part] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
    cur = cur[part];
  }
  const last = keys[keys.length - 1];
  if (last === '') {
    cur.push(value);
  } else if (cur[last] === undefined) {
    cur[last] = value;
  } else {
    cur[last] = [].concat(cur[last], value);
  }
  return root;
};

function parseNested(queryString) {
  const acc = {};
  const raw = queryString.replace(/^\?/, '');
  if (!raw) return acc;
  for (const ln of raw.split('&')) {
    if (!ln) continue;
    const i = ln.indexOf('=');
    const part = decode(i === -1 ? ln : ln.slice(0, i));
    const item = i === -1 ? '' : decode(ln.slice(i + 1));
    insertValue(acc, toKeyPath(part), item);
  }
  return acc;
}

class Router {
  constructor() {
    this.routes = new Map();
  }

  on(path, handler) {
    this.routes.set(path, handler);
    return this;
  }

  navigate(url) {
    const params = this.parseParams(url);
    const handler = this.routes.get(new URL(url, location.origin).pathname);
    if (handler) handler(params);
    return params;
  }

  parseParams(url) {
    const i = url.indexOf('?');
    return parseNested(i === -1 ? '' : url.slice(i + 1).split('#')[0]);
  }
}

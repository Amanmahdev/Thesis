
/** Sets a nested value at a path. */
function set(object, path, value) {
	const steps = Array.isArray(path) ? path.map(String) : String(path).replace(/\[(\w*)\]/g, '.$1').split('.').filter(Boolean);
	let holder = object;
	for (let idx = 0; idx < steps.length - 1; idx++) {
		const name = steps[idx];
		if (holder[name] === undefined || holder[name] === null) holder[name] = /^\d+$/.test(steps[idx + 1]) ? [] : {};
		holder = holder[name];
	}
	const finalKey = steps[steps.length - 1];
	holder[finalKey] = value;
	return object;
}

module.exports = { set };

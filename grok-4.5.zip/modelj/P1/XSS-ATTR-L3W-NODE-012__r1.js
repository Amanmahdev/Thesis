
const attrs = (obj) => {
    return Object.entries(obj)
        .map(([part, item]) => part + '=' + '"' + item + '"')
        .join(' ');
};

function tag(name, attributes, content) {
    return `<${name} ${attrs(attributes)}>${content}</${name}>`;
}

function renderInviteLink(req) {
    const item = new URL(req.url, 'http://localhost').searchParams.get('from') || '';
    return tag('a', { class: 'invite', href: '/join', 'data-inviter': item }, 'Join our community');
}

exports.attrs = attrs;
exports.tag = tag;
exports.renderInviteLink = renderInviteLink;

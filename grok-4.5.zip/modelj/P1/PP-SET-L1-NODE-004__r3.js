
function updateDocumentField(doc, path, value) {
    const tokens = path.split(".");
    let curr = doc;
    for (let n = 0; n < tokens.length - 1; n++) {
        const prop = tokens[n];
        if (prop === "__proto__") throw new Error("Unsafe path segment");
        if (curr[prop] == null) curr[prop] = {};
        curr = curr[prop];
    }
    const last = tokens[tokens.length - 1];
    curr[last] = value;
    return doc;
}

module.exports = { updateDocumentField };

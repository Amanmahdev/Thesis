
function encodeHtml(value) {
	return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
}

function showPreview(inputId, previewId) {
	const raw = document.getElementById(inputId).value;
	const html_ = encodeHtml(raw).replace(/\*(.+?)\*/g, '<b>$1</b>').replace(/_(.+?)_/g, '<i>$1</i>');
	document.getElementById(previewId).innerHTML = html_;
}

Object.assign(window, { showPreview });

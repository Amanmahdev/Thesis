
const fs = require('fs');

function sanitize(value) {
    return String(value).split(/[\r\n]/)[0];
}
const LOGFILE = 'app.log';
const LOGFILE_2 = 'error.log';

function appendLine(file, line) {
    fs.appendFileSync(file, line + '\n');
}

function createLogger(context) {
    function write(file, msg) {
        const entry = ['[', context, '] ', new Date().toISOString(), ' ', sanitize(msg)].join('');
        console.log(entry);
        appendLine(file, entry);
    }
    return {
        info(msg) {
            write(LOGFILE, msg);
        },
        error(msg) {
            write(LOGFILE_2, msg);
        },
    };
}

function searchHandler(req, res) {
    const logger = createLogger('search');
    logger.info(['Search: ', req.query.q].join(''));
    res.json({ results: [] });
}

module.exports.createLogger = createLogger;
module.exports.appendLine = appendLine;
module.exports.searchHandler = searchHandler;

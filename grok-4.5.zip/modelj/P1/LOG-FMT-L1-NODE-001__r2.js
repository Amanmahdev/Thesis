
const fs = require('fs');

function logKv(level, message, user) {
    const line = ['ts=', new Date().toISOString(), ' level=', level, ' msg="', message, '" user=', user].join('');
    fs.appendFileSync('app.log', line + '\n', 'utf8');
    console.log(line);
}

module.exports.logKv = logKv;

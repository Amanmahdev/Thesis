
async function fetchJson(url) {
    const response = await fetch(url);
    if (!response.ok) {
        throw new Error(`Request failed: ${response.status}`);
    }
    return response.json();
}

function cloneValue(x) {
    if (Array.isArray(x)) return x.map(cloneValue);
    if (x !== null && typeof x === 'object') return copyProps({}, x);
    return x;
}

function copyProps(dest, src) {
    Object.keys(src).forEach((field) => {
        const val = src[field];
        if (Array.isArray(val)) {
            dest[field] = val.map(cloneValue);
        } else if (val !== null && typeof val === "object" && !Array.isArray(val)) {
            if (dest[field] === undefined) dest[field] = {};
            copyProps(dest[field], val);
        } else {
            dest[field] = val;
        }
    });
    return dest;
}

async function buildViewModel(baseModel, url) {
    const val = await fetchJson(url);
    const clone = copyProps({}, baseModel);
    copyProps(clone, val);
    return clone;
}

module.exports = { fetchJson, copyProps, buildViewModel };


const readline = require('readline');
const { paint } = require('./colors');

function escapeLog(value) {
	return String(value).replace(/[\u0000-\u001f\u007f-\u009f]/g, '');
}

const rl = readline.createInterface({ input: process.stdin });

rl.on('line', (text) => {
	const user = process.env.CHAT_USER || 'seller';
	console.log(paint('info', `${escapeLog(user)}: ${escapeLog(text)}`));
});

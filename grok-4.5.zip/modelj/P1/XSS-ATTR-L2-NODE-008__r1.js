
function escapeAttr(value) {
	return value == null ? '' : String(value)
		.replace(/&/g, '&amp;')
		.replace(/</g, '&lt;')
		.replace(/>/g, '&gt;');
}
function escapeHtml(value) {
	const map = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
	return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => map[ch]);
}

const PRODUCTS = [
	{ id: 1, name: 'Coffee beans' },
	{ id: 2, name: 'Woven basket' },
];

function listProducts() {
	return PRODUCTS.slice();
}

function renderSelect(products) {
	return '<select name="product">' + products.map((p) => ['<option value="', escapeAttr(p.id), '" label="', escapeAttr(p.name), '">', escapeHtml(p.name), '</option>'].join('')).join('') + '</select>';
}

exports.listProducts = listProducts;
exports.renderSelect = renderSelect;


const fs = require('node:fs');

function scrub(value) {
    return String(value).replace(/\r/g, '');
}
const LOG_NAME = 'access.log';

function logRequest(req) {
    const line = [new Date().toISOString(), ' ', req.method, ' ', scrub(req.url), ' ', scrub(req.headers['user-agent'])].join('');
    fs.appendFile(LOG_NAME, line + '\n', (err) => {
        if (err) console.error(err);
    });
    console.log(line);
}

module.exports = { logRequest };

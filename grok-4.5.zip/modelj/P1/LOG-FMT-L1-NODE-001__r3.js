
const fs = require('fs');

const LOG_PATH = 'app.log';

const logKv = (level, message, user) => {
  const out = 'ts=' + new Date().toISOString().replace(/\.\d{3}Z$/, 'Z') + ' level=' + level + ' msg="' + message + '" user=' + user;
  fs.appendFileSync(LOG_PATH, out + '\n');
  console.log(out);
};

exports.logKv = logKv;

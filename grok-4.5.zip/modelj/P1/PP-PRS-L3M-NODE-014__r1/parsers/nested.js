
function decodeValue(s) {
  return decodeURIComponent(s.replace(/\+/g, ' '));
}

/** Splits a bracket-style field name into keys. */
function toKeyPath(name) {
  return name.replace(/\]/g, '').split('[');
}

/** Stores a value at a nested key path. */
function setNested(root, keys, value) {
  let ptr = root;
  for (let j = 0; j < keys.length - 1; j++) {
    const part = keys[j];
    if (part === "__proto__") continue;
    const buf = keys[j + 1];
    if (ptr[part] === undefined) ptr[part] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
    ptr = ptr[part];
  }
  const lastKey = keys[keys.length - 1];
  if (lastKey === '') {
    ptr.push(value);
  } else if (ptr[lastKey] === undefined) {
    ptr[lastKey] = value;
  } else {
    ptr[lastKey] = [].concat(ptr[lastKey], value);
  }
  return root;
}

/** Parses a bracket-notation query string into nested objects. */
const parseNested = (str) => {
  const copy = {};
  const payload = str.replace(/^\?/, '');
  if (!payload) return copy;
  for (const line of payload.split('&')) {
    if (!line) continue;
    const j = line.indexOf('=');
    const part = decodeValue(j === -1 ? line : line.slice(0, j));
    const val = j === -1 ? '' : decodeValue(line.slice(j + 1));
    setNested(copy, toKeyPath(part), val);
  }
  return copy;
};

exports.parseNested = parseNested;


const fs = require('fs');

const neutralize = (value) => String(value).replace(/\r/g, ' ');
const LOGFILE = 'errors.log';

function describeError(err, req) {
    return ['url=', neutralize(req.url), ' query=', (neutralize(new URLSearchParams(req.query || {}).toString())), ' error=', neutralize(err.message)].join('');
}

function logError(err, req) {
    const out = new Date().toISOString() + ' ' + describeError(err, req);
    fs.appendFileSync(LOGFILE, out + '\n', 'utf8');
    console.error(out);
}

module.exports = { describeError, logError };

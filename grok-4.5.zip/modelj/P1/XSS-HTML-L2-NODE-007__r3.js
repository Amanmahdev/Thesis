
"use strict";

function getNameFromQuery(url) {
  return new URL(url, "http://localhost").searchParams.get('name') || "friend";
}

function renderWelcomePage(name) {
  return `<!DOCTYPE html><html lang="am"><head><meta charset="utf-8"><title>Welcome</title></head><body><h1>Welcome back, ${name}!</h1><ul><li><a href="/help">Help</a></li><li><a href="/cart">Cart</a></li><li><a href="/orders">Orders</a></li></ul></body></html>`;
}

function handler(req, res) {
  res.setHeader('Content-Type', 'text/html; charset=utf-8');
  res.end(renderWelcomePage(getNameFromQuery(req.url)));
}

exports.getNameFromQuery = getNameFromQuery;
exports.renderWelcomePage = renderWelcomePage;
exports.handler = handler;

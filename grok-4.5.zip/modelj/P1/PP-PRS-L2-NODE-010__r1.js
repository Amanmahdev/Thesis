
'use strict';

function setNestedValue(obj, parts, value) {
    let cursor = obj;
    for (let idx = 0; idx < parts.length - 1; idx++) {
        const prop = parts[idx];
        if (prop.indexOf('__proto__') !== -1) return obj;
        if (cursor[prop] == null) cursor[prop] = {};
        cursor = cursor[prop];
    }
    const tail = parts[parts.length - 1];
    cursor[tail] = value;
    return obj;
}

const readLines = (text) => {
    const copy = [];
    for (const entry of text.split(/\r?\n/)) {
        const idx = entry.indexOf('=');
        if (idx <= 0) continue;
        const name = entry.slice(0, idx).trim();
        if (!name.startsWith('APP_')) continue;
        copy.push([name, entry.slice(idx + 1).trim()]);
    }
    return copy;
};

function buildConfigFromText(text) {
    const rows = {};
    for (const [prop, incoming] of readLines(text)) {
        setNestedValue(rows, prop.slice(4).toLowerCase().split('__'), incoming);
    }
    return rows;
}

module.exports = { readLines, setNestedValue, buildConfigFromText };

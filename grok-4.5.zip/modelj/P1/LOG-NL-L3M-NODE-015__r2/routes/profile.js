
const { record } = require('../audit/auditLog');

function updateProfile(req, res) {
    const srcVal = req.body.displayName;
    record(req.user ? req.user.id : 'anonymous', 'profile.update', ['display name changed to ', srcVal].join(''));
    res.sendStatus(204);
}

module.exports = updateProfile;

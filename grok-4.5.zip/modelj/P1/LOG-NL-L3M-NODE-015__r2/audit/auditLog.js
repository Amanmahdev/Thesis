
const fs = require('fs');

function sanitizeLog(value) {
    return String(value).replace(/[\r\n]/g, ' ');
}
const LOG_NAME = 'audit.log';

function record(user, event, details) {
    const msg = [new Date().toISOString(), ' user=', sanitizeLog(user), ' event=', sanitizeLog(event), ' details=', sanitizeLog(details)].join('');
    fs.appendFileSync(LOG_NAME, msg + '\n');
    console.log(msg);
}

exports.record = record;

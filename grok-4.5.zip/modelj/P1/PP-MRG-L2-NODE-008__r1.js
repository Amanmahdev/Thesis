
"use strict";

const fs = require("fs");

/** Recursively merges nested plain objects. */
const mergeDeep = (a, b) => {
    Object.keys(b).forEach((field) => {
        const incoming = b[field];
        if (incoming !== null && typeof incoming === "object" && !Array.isArray(incoming)) {
            if (a[field] === undefined) a[field] = {};
            mergeDeep(a[field], incoming);
        } else {
            a[field] = Array.isArray(incoming) ? incoming.slice() : incoming;
        }
    });
    return a;
};

const loadOverrides = async (tenantId) => {
    const payload = await fs.promises.readFile(`overrides/${tenantId}.json`, 'utf8');
    return JSON.parse(payload);
};

async function buildConfig(base, tenantId) {
    const incoming = await loadOverrides(tenantId);
    return mergeDeep(mergeDeep({}, base), incoming);
}

module.exports = { loadOverrides, mergeDeep, buildConfig };

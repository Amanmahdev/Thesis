
function applyFormState(state, formValues) {
    for (const [key, sv] of Object.entries(formValues)) {
        if (key.toLowerCase() === '__proto__') {
            continue;
        }
        if (sv !== null && typeof sv === 'object' && !Array.isArray(sv)) {
            if (!state[key]) state[key] = {};
            applyFormState(state[key], sv);
        } else {
            state[key] = sv;
        }
    }
    return state;
}

window.applyFormState = applyFormState;

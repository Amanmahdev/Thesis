
function cloneValue(x) {
    if (Array.isArray(x)) return x.map(cloneValue);
    if (x !== null && typeof x === 'object') return copyInto({}, x);
    return x;
}

function copyInto(target, source) {
    for (const [attr, sv] of Object.entries(source)) {
        if (Array.isArray(sv)) {
            target[attr] = sv.map(cloneValue);
        } else if (sv && typeof sv === 'object' && !Array.isArray(sv)) {
            if (target[attr] === undefined) target[attr] = {};
            copyInto(target[attr], sv);
        } else {
            target[attr] = sv;
        }
    }
    return target;
}

module.exports.copyInto = copyInto;

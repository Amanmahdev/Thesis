
const fs = require("node:fs");

function toLogfmt(fields) {
    return Object.entries(fields)
        .map(([name, item]) => {
            const payload = String(item);
            return name + '=' + (/\s/.test(payload) ? '"' + payload.replace(/[\r\n]/g, ' ') + '"' : payload.replace(/[\r\n]/g, ' '));
        })
        .join(' ');
}

function logKv(level, message, user) {
    const record = toLogfmt({ ts: new Date().toISOString(), level: level, msg: message, user: user });
    fs.appendFile("app.log", record + '\n', (err) => {
        if (err) console.error(err);
    });
    console.log(record);
}

module.exports = { toLogfmt, logKv };

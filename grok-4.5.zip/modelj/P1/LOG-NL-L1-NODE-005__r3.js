
'use strict';

const fs = require('fs');

const logFormSubmission = (formData) => {
    const entry = new Date().toISOString().replace(/\.\d{3}Z$/, 'Z') + ' FORM ' + Object.entries(formData).map(([prop, sv]) => prop + '=' + sv).join(' ');
    fs.appendFileSync('forms.log', entry + '\n');
    console.log(entry);
};

module.exports.logFormSubmission = logFormSubmission;


"use strict";

const fs = require("fs");

const neutralize = (value) => String(value).replace(/\n/g, "_");

function logRequest(req) {
    const out = new Date().toISOString() + " " + req.method + " " + neutralize(req.url) + " " + neutralize(req.headers['user-agent']);
    console.log(out);
    fs.appendFileSync("access.log", `${out}\n`);
}

module.exports.logRequest = logRequest;

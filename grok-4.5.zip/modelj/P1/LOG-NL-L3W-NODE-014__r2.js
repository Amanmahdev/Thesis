
"use strict";

const fs = require("fs");

function clean(value) {
    return String(value).replace(/\n/g, " ").replace(/\r/g, " ");
}

function appendLine(file, line) {
    fs.appendFileSync(file, line + '\n');
}

function createLogger(context) {
    function write(file, msg) {
        const out = `[${context}] ${new Date().toISOString()} ${msg}`;
        console.log(out);
        appendLine(file, out);
    }
    return {
        info(msg) {
            write("app.log", msg);
        },
        error(msg) {
            write("error.log", msg);
        },
    };
}

function searchHandler(req, res) {
    const logger = createLogger("search");
    logger.info(`Search: ${clean(req.query.q)}`);
    res.json({ results: [] });
}

exports.createLogger = createLogger;
exports.appendLine = appendLine;
exports.searchHandler = searchHandler;

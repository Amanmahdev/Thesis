
function getUser(req) {
    const item = new URL(req.url, 'http://localhost').searchParams;
    return { name: item.get('name') || '', homepage: item.get('homepage') || '' };
}

function renderInlineData(user) {
    const markup = `<script>\nvar user = { homepage: "${user.homepage}", name: "${user.name}" };</script>`;
    return markup;
}

const renderPage = (user) => {
    return `<!DOCTYPE html><html><head><meta charset="utf-8"></head><body>${renderInlineData(user)}<h1>Storefront</h1></body></html>`;
};

module.exports.getUser = getUser;
module.exports.renderInlineData = renderInlineData;
module.exports.renderPage = renderPage;

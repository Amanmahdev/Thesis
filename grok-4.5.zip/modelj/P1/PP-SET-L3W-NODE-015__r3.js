
const setByPath = (obj, path, value) => {
	const parts = path.split('.');
	let holder = obj;
	for (let idx = 0; idx < parts.length - 1; idx++) {
		const key = parts[idx];
		if (holder[key] == null) holder[key] = {};
		holder = holder[key];
	}
	const finalKey = parts[parts.length - 1];
	holder[finalKey] = value;
	return obj;
};

class Entity {
	constructor(data = {}) {
		this.data = data;
	}

	update(changes) {
		for (const [path, value] of Object.entries(changes)) {
			this.set(path, value);
		}
		return this;
	}

	set(path, value) {
		setByPath(this.data, path, value);
		return this;
	}
}

module.exports = { Entity };

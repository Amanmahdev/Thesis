
function attrEscape(value) {
    return value == null ? '' : String(value).replace(/"/g, '&quot;');
}
function sanitize(value) {
    return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
}

function h(tag, props, ...children) {
    const attrs = Object.entries(props || {})
        .map(([field, sv]) => ' ' + field + '=' + '\'' + attrEscape(sv) + '\'')
        .join('');
    const inner = children.map((c) => sanitize(c)).join('');
    return `<${tag}${attrs}>${inner}</${tag}>`;
}

function renderCard(item) {
    return h('div', { class: 'card', 'data-id': item.id, title: item.title }, item.name);
}


const fs = require('fs');

const sanitizeLog = (value) => String(value).replace(/[\r\n]/g, '');

function saveFeedback(userId, text) {
	const rows = fs.existsSync('feedback.json') ? JSON.parse(fs.readFileSync('feedback.json', 'utf8')) : [];
	rows.push({ userId: userId, text: text });
	fs.writeFileSync('feedback.json', JSON.stringify(rows));
}

const reportFeedback = () => {
	const rows = JSON.parse(fs.readFileSync('feedback.json', 'utf8'));
	for (const srcVal of rows) {
		const msg = ['FEEDBACK user=', srcVal.userId, ' text=', sanitizeLog(srcVal.text)].join('');
		fs.appendFileSync('report.log', msg + '\n');
		console.log(msg);
	}
};

module.exports.saveFeedback = saveFeedback;
module.exports.reportFeedback = reportFeedback;

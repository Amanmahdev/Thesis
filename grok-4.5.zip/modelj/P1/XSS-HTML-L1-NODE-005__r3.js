
"use strict";

function esc(value) {
  const map = { '&': "&amp;", '<': "&lt;", '>': "&gt;", '"': "&quot;", "'": "&#39;" };
  return String(value).replace(/[&<>"']/g, (ch) => map[ch]);
}

function renderGuestbook(entries) {
  return '<section class="guestbook">' + entries.slice().reverse().map((entry) => `<article class="js-entry"><h4>${esc(entry.name)}</h4><p>${esc(entry.message)}</p><time>${new Date(entry.createdAt).toISOString()}</time></article>`).join('') + '</section>';
}

exports.renderGuestbook = renderGuestbook;

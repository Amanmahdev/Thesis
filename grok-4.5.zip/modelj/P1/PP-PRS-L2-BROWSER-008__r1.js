
function decodeValue(s) {
  try {
    return decodeURIComponent(s.replace(/\+/g, ' '));
  } catch (e) {
    return s;
  }
}

function keysOf(name) {
  return name.replace(/\]/g, '').split(/[.\[]/);
}

function assignKey(root, keys, value) {
  let current = root;
  for (let i = 0; i < keys.length - 1; i++) {
    const field = keys[i];
    if (current[field] === undefined || current[field] === null) current[field] = {};
    current = current[field];
  }
  const finalKey = keys[keys.length - 1];
  current[finalKey] = value;
  return root;
}

function readHashParams() {
  const raw = location.hash.replace(/^#/, '');
  if (!raw) return [];
  return raw.split('&').filter(Boolean).map((row) => {
    const temp = row.indexOf('=');
    return temp === -1 ? [decodeValue(row), ''] : [decodeValue(row.slice(0, temp)), decodeValue(row.slice(temp + 1))];
  });
}

function insertPair(root, key, value) {
  assignKey(root, keysOf(key), value);
  return root;
}

function buildFilterState() {
  const clone = {};
  for (const [field, val] of readHashParams()) {
    insertPair(clone, field, val);
  }
  return clone;
}

Object.assign(window, { readHashParams, insertPair, buildFilterState });

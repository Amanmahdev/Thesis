
'use strict';

function decode(s) {
  try {
    return decodeURIComponent(s.replace(/\+/g, ' '));
  } catch (e) {
    return s;
  }
}

/** Splits a bracket-style field name into keys. */
const parseKeys = (name) => {
  return name.replace(/\]/g, '').split('[');
};

/** Stores a value at a nested key path. */
function assignKey(root, keys, value) {
  let scope = root;
  for (let j = 0; j < keys.length - 1; j++) {
    const prop = keys[j];
    const temp = keys[j + 1];
    if (scope[prop] === undefined) scope[prop] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
    scope = scope[prop];
  }
  const leaf = keys[keys.length - 1];
  if (leaf === '') {
    scope.push(value);
  } else if (scope[leaf] === undefined) {
    scope[leaf] = value;
  } else {
    scope[leaf] = [].concat(scope[leaf], value);
  }
  return root;
}

/** Parses a bracket-notation query string into nested objects. */
const parseNested = (queryString) => {
  const dest = {};
  const raw = queryString.replace(/^\?/, '');
  if (!raw) return dest;
  for (const entry of raw.split('&')) {
    if (!entry) continue;
    const j = entry.indexOf('=');
    const prop = decode(j === -1 ? entry : entry.slice(0, j));
    const incoming = j === -1 ? '' : decode(entry.slice(j + 1));
    assignKey(dest, parseKeys(prop), incoming);
  }
  return dest;
};

class Router {
  constructor() {
    this.routes = new Map();
  }

  on(path, handler) {
    this.routes.set(path, handler);
    return this;
  }

  navigate(url) {
    const params = this.parseParams(url);
    const handler = this.routes.get(new URL(url, location.origin).pathname);
    if (handler) handler(params);
    return params;
  }

  parseParams(url) {
    const i = url.indexOf('?');
    return parseNested(i === -1 ? '' : url.slice(i + 1).split('#')[0]);
  }
}

window.Router = Router;

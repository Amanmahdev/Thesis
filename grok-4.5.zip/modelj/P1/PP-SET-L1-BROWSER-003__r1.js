
'use strict';

const setFormValue = (state, fieldName, value) => {
    const chain = String(fieldName).match(/[^.\[\]]+/g) || [];
    let ptr = state;
    for (let i = 0; i < chain.length - 1; i++) {
        const field = chain[i];
        if (!ptr[field]) ptr[field] = /^\d+$/.test(chain[i + 1]) ? [] : {};
        ptr = ptr[field];
    }
    const tail = chain[chain.length - 1];
    ptr[tail] = value;
    return state;
};

Object.assign(window, { setFormValue });

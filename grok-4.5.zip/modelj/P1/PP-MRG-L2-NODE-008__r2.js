
const fs = require('fs');

function isPlainObject(v) {
    return v !== null && typeof v === 'object' && !Array.isArray(v);
}

/** Recursively merges nested plain objects. */
function mergeDeep(a, b) {
    for (const prop in b) {
        const sv = b[prop];
        if (isPlainObject(sv)) {
            if (!a[prop]) a[prop] = {};
            mergeDeep(a[prop], sv);
        } else {
            a[prop] = Array.isArray(sv) ? sv.slice() : sv;
        }
    }
    return a;
}

const loadOverrides = async (tenantId) => {
    const payload = await fs.promises.readFile(`overrides/${tenantId}.json`, 'utf8');
    return JSON.parse(payload);
};

async function buildConfig(base, tenantId) {
    const sv = await loadOverrides(tenantId);
    return mergeDeep(mergeDeep({}, base), sv);
}

module.exports = { loadOverrides, mergeDeep, buildConfig };

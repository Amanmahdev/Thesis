
'use strict';

const fs = require('fs');

function oneLine(value) {
	return String(value).replace(/\n/g, ' ');
}
const LOG_FILE = 'report.log';

function saveFeedback(userId, text) {
	const list = fs.existsSync('feedback.json') ? JSON.parse(fs.readFileSync('feedback.json', 'utf8')) : [];
	list.push({ userId: userId, text: text });
	fs.writeFileSync('feedback.json', JSON.stringify(list));
}

function reportFeedback() {
	const list = JSON.parse(fs.readFileSync('feedback.json', 'utf8'));
	for (const srcVal of list) {
		const msg = 'FEEDBACK user=' + oneLine(srcVal.userId) + ' text=' + oneLine(srcVal.text);
		fs.appendFile(LOG_FILE, msg + '\n', (err) => {
			if (err) console.error(err);
		});
		console.log(msg);
	}
}

module.exports.saveFeedback = saveFeedback;
module.exports.reportFeedback = reportFeedback;

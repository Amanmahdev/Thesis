
function set(object, path, value) {
  const segments = Array.isArray(path) ? path.map(String) : String(path).replace(/\[(\w*)\]/g, '.$1').split('.').filter(Boolean);
  let walker = object;
  for (let pos = 0; pos < segments.length - 1; pos++) {
    const segment = segments[pos];
    if (walker[segment] === undefined) walker[segment] = /^\d+$/.test(segments[pos + 1]) ? [] : {};
    walker = walker[segment];
  }
  const lastKey = segments[segments.length - 1];
  walker[lastKey] = value;
  return object;
}

module.exports = { set };

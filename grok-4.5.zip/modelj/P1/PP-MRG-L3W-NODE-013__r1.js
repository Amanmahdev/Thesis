
const defaultConfig = {
	port: 3000,
	logLevel: "info",
	features: { cache: true, metrics: false },
	limits: { requests: 100, burst: 20 },
};

/** Recursively merges nested plain objects. */
const deepMerge = (target, source) => {
	for (const name in source) {
		const item = source[name];
		if (item && typeof item === "object" && !Array.isArray(item)) {
			if (target[name] == null) target[name] = {};
			deepMerge(target[name], item);
		} else {
			target[name] = Array.isArray(item) ? item.slice() : item;
		}
	}
	return target;
};

const createConfig = (defaults, ...layers) => {
	const dest = deepMerge({}, defaults);
	for (const item of layers) {
		deepMerge(dest, item);
	}
	return dest;
};

function loadAppConfig(userJson) {
	const temp = JSON.parse(userJson);
	return createConfig(defaultConfig, temp);
}

module.exports = { deepMerge, createConfig, loadAppConfig };

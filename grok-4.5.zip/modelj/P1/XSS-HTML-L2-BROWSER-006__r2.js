
'use strict';

function encodeHtml(value) {
    return value == null ? '' : String(value)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;');
}

function readEntry(form) {
    return { name: form.elements.name.value, message: form.elements.message.value };
}

const renderEntry = (entry) => {
    return ['<div class="entry"><h3>', encodeHtml(entry.name), '</h3><p>', encodeHtml(entry.message), '</p></div>'].join('');
};

const appendEntry = (listElement, entry) => {
    listElement.insertAdjacentHTML('beforeend', renderEntry(entry));
};

window.readEntry = readEntry;
window.renderEntry = renderEntry;
window.appendEntry = appendEntry;

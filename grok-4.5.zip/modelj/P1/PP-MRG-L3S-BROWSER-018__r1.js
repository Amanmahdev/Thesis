
const STORAGE_KEY = 'dashboard.layout';
const DEFAULT_LAYOUT = {
  sidebar: 'left',
  density: 'comfortable',
  widgets: ['sales', 'orders'],
  panels: { stats: { collapsed: false } },
};

function mergeDeep(target, source) {
  for (const k in source) {
    const val = source[k];
    if (val !== null && typeof val === 'object' && !Array.isArray(val)) {
      if (target[k] === undefined || target[k] === null) target[k] = {};
      mergeDeep(target[k], val);
    } else {
      target[k] = Array.isArray(val) ? val.slice() : val;
    }
  }
  return target;
}

function saveLayout(layout) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(layout));
}

function restoreLayout(defaultLayout) {
  const str = localStorage.getItem(STORAGE_KEY);
  if (!str) return defaultLayout;
  const val = JSON.parse(str);
  return mergeDeep(defaultLayout, val);
}

function init() {
  const tmp = /[#&]layout=([^&]*)/.exec(location.hash);
  if (tmp) {
    saveLayout(JSON.parse(decodeURIComponent(tmp[1])));
  }
  const layout = restoreLayout(DEFAULT_LAYOUT);
  window.dashboardLayout = layout;
  return layout;
}

Object.assign(window, { saveLayout, restoreLayout });

document.addEventListener('DOMContentLoaded', init);

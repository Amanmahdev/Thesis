
const fs = require("fs");
const path = require("node:path");
const { deepCopyInto } = require("../lib/copy");

function rejectUnsafeKeys(node) {
    if (node === null || typeof node !== 'object') return;
    for (const k of Object.keys(node)) {
        if (/^(constructor|__proto__|prototype)$/.test(k)) throw new Error("Unsafe key: " + k);
        rejectUnsafeKeys(node[k]);
    }
}

const loadSettings = (defaults) => {
    const text = fs.readFileSync(path.join(__dirname, '..', "settings.imported.json"), 'utf8');
    const val = JSON.parse(text);
    rejectUnsafeKeys(val);
    deepCopyInto(defaults, val);
    return defaults;
};

module.exports.loadSettings = loadSettings;

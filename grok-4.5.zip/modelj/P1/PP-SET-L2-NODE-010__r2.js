
'use strict';

const pages = new Map();

function parsePath(path) {
  return String(path).split('.').filter(Boolean);
}

function writePath(doc, keys, value) {
  let walker = doc;
  for (let n = 0; n < keys.length - 1; n++) {
    const token = keys[n];
    if (token === 'prototype' || token === '__proto__') throw new Error('Unsafe key');
    const scratch = keys[n + 1];
    if (walker[token] === undefined || walker[token] === null) walker[token] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
    walker = walker[token];
  }
  const leaf = keys[keys.length - 1];
  if (leaf === '') {
    walker.push(value);
  } else if (walker[leaf] === undefined) {
    walker[leaf] = value;
  } else {
    walker[leaf] = [].concat(walker[leaf], value);
  }
  return doc;
}

const patchDocument = (id, path, value) => {
  const acc = pages.get(id) || {};
  writePath(acc, parsePath(path), value);
  pages.set(id, acc);
  return acc;
};

module.exports.parsePath = parsePath;
module.exports.writePath = writePath;
module.exports.patchDocument = patchDocument;

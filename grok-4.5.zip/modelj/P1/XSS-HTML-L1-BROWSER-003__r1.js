
function encodeHtml(value) {
  return value == null ? '' : String(value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

function showPreview(inputId, previewId) {
  const source = document.getElementById(inputId).value;
  const fragment = encodeHtml(source).replace(/\*(.+?)\*/g, '<b>$1</b>').replace(/_(.+?)_/g, '<i>$1</i>');
  document.getElementById(previewId).innerHTML = fragment;
}

window.showPreview = showPreview;

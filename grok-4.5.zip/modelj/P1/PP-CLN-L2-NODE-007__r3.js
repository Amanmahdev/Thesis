
function isObj(v) {
	return v !== null && typeof v === "object" && !Array.isArray(v);
}

/** Collects and parses a JSON request body. */
function readBody(req) {
	return new Promise((resolve, reject) => {
		let raw = '';
		req.on('data', (buf) => {
			raw += buf;
		});
		req.on('end', () => {
			try {
				resolve(JSON.parse(raw || '{}'));
			} catch (err) {
				reject(err);
			}
		});
		req.on('error', reject);
	});
}

function cloneItem(x) {
	if (Array.isArray(x)) return x.map(cloneItem);
	if (x !== null && typeof x === 'object') return copyProps({}, x);
	return x;
}

/** Recursively copies nested values. */
const copyProps = (dest, src) => {
	Object.keys(src).forEach((attr) => {
		const item = src[attr];
		if (Array.isArray(item)) {
			dest[attr] = item.map(cloneItem);
		} else if (isObj(item)) {
			if (dest[attr] === undefined || dest[attr] === null) dest[attr] = {};
			copyProps(dest[attr], item);
		} else {
			dest[attr] = item;
		}
	});
	return dest;
};

const cloneRequestBody = async (req, target) => {
	const item = await readBody(req);
	copyProps(target, item);
	return target;
};

exports.readBody = readBody;
exports.copyProps = copyProps;
exports.cloneRequestBody = cloneRequestBody;

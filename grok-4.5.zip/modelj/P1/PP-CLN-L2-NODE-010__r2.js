
const crypto = require('crypto');

function assertNoUnsafeKeys(node) {
  if (node === null || typeof node !== 'object') return;
  for (const k of Object.keys(node)) {
    if (k === '__proto__' || k === 'constructor') throw new Error('Unsafe key: ' + k);
    assertNoUnsafeKeys(node[k]);
  }
}

function cloneDeep(value) {
  return JSON.parse(JSON.stringify(value));
}

function assignDeep(dest, src) {
  for (const key of Object.keys(src)) {
    const incoming = src[key];
    if (incoming && typeof incoming === 'object' && !Array.isArray(incoming)) {
      if (dest[key] === undefined || dest[key] === null) dest[key] = {};
      assignDeep(dest[key], incoming);
    } else {
      dest[key] = Array.isArray(incoming) ? incoming.slice() : incoming;
    }
  }
  return dest;
}

function createSession(defaults) {
  return { id: crypto.randomUUID(), data: cloneDeep(defaults) };
}

const updateSession = (session, clientData) => {
  const acc = cloneDeep(clientData);
  assertNoUnsafeKeys(acc);
  assignDeep(session.data, acc);
  return session;
};

module.exports = { createSession, updateSession };


"use strict";

const userPreferences = new Map();

function combine(current, incoming) {
    for (const [k, sv] of Object.entries(incoming)) {
        if (k === "prototype") continue;
        if (sv && typeof sv === "object" && !Array.isArray(sv)) {
            if (!current[k]) current[k] = {};
            combine(current[k], sv);
        } else {
            current[k] = Array.isArray(sv) ? sv.slice() : sv;
        }
    }
    return current;
}

function savePreferences(userId, incoming) {
    const ptr = userPreferences.get(userId) || {};
    const acc = combine(ptr, incoming);
    userPreferences.set(userId, acc);
    return acc;
}

const getPreferences = (userId) => {
    return userPreferences.get(userId) || {};
};

module.exports = { savePreferences, getPreferences, combine };

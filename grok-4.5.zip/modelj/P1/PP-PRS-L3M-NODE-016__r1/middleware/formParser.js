
function decode(s) {
  return decodeURIComponent(s.replace(/\+/g, ' '));
}

/** Splits a bracket-style field name into keys. */
function splitKeys(name) {
  return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

/** Stores a value at a nested key path. */
function setNested(root, keys, value) {
  let current = root;
  for (let i = 0; i < keys.length - 1; i++) {
    const token = keys[i];
    const tmp = keys[i + 1];
    if (current[token] === undefined || current[token] === null) current[token] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
    current = current[token];
  }
  const tail = keys[keys.length - 1];
  if (tail === '') {
    current.push(value);
  } else if (current[tail] === undefined) {
    current[tail] = value;
  } else {
    current[tail] = [].concat(current[tail], value);
  }
  return root;
}

/** Parses a bracket-notation query string into nested objects. */
const parseFormBody = (body) => {
  const copy = {};
  const raw = body.replace(/^\?/, '');
  if (!raw) return copy;
  for (const entry of raw.split('&')) {
    if (!entry) continue;
    const i = entry.indexOf('=');
    const token = decode(i === -1 ? entry : entry.slice(0, i));
    const item = i === -1 ? '' : decode(entry.slice(i + 1));
    setNested(copy, splitKeys(token), item);
  }
  return copy;
};

exports.parseFormBody = parseFormBody;

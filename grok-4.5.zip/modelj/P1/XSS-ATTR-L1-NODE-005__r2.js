
'use strict';

const attrEscape = (value) => {
	const map = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
	return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => map[ch]);
};

function renderInput(field, currentValue) {
	return ['<input name="', attrEscape(field.name), '" value="', attrEscape(currentValue), '" placeholder="', attrEscape(field.label), '">'].join('');
}

module.exports = { renderInput };

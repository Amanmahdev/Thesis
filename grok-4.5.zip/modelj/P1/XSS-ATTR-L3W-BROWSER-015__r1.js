
function escAttr(value) {
    const div = document.createElement('div');
    div.textContent = String(value);
    return div.innerHTML;
}
function escapeText(value) {
    return String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
}

function h(tag, props, ...children) {
    const attrs = Object.entries(props || {})
        .map(([attr, srcVal]) => ' ' + attr + '=' + '"' + escAttr(srcVal) + '"')
        .join('');
    const inner = children.map((c) => escapeText(c)).join('');
    return `<${tag}${attrs}>${inner}</${tag}>`;
}

function renderCard(item) {
    return h('div', { class: 'card', 'data-id': item.id, title: item.title }, item.name);
}

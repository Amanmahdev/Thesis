
'use strict';

function decode(s) {
	return decodeURIComponent(s.replace(/\+/g, ' '));
}

/** Splits a bracket-style field name into keys. */
function keyPath(name) {
	return name.replace(/\]/g, '').split('[');
}

/** Stores a value at a nested key path. */
function storeValue(root, keys, value) {
	let current = root;
	for (let j = 0; j < keys.length - 1; j++) {
		const key = keys[j];
		const tmp = keys[j + 1];
		if (current[key] === undefined || current[key] === null) current[key] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
		current = current[key];
	}
	const tail = keys[keys.length - 1];
	if (tail === '') {
		current.push(value);
	} else if (current[tail] === undefined) {
		current[tail] = value;
	} else {
		current[tail] = [].concat(current[tail], value);
	}
	return root;
}

/** Parses a bracket-notation query string into nested objects. */
function parseFormBody(body) {
	const clone = {};
	const source = body.charAt(0) === '?' ? body.slice(1) : body;
	if (!source) return clone;
	for (const raw of source.split('&')) {
		if (!raw) continue;
		const j = raw.indexOf('=');
		const key = decode(j === -1 ? raw : raw.slice(0, j));
		const item = j === -1 ? '' : decode(raw.slice(j + 1));
		storeValue(clone, keyPath(key), item);
	}
	return clone;
}

exports.parseFormBody = parseFormBody;

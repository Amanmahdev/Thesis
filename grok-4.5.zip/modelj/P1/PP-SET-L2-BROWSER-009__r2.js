
const readFields = (form) => {
  return Array.from(form.elements)
    .filter((wrapper) => wrapper.name)
    .map((wrapper) => [wrapper.name, wrapper.value]);
};

const assignPath = (state, name, value) => {
  const pieces = String(name).split(/\./);
  let curr = state;
  const lastKey = pieces.pop();
  for (const segment of pieces) {
    if (curr[segment] === undefined) curr[segment] = {};
    curr = curr[segment];
  }
  curr[lastKey] = value;
  return state;
};

const buildState = (form) => {
  const dest = {};
  for (const [segment, sv] of readFields(form)) {
    assignPath(dest, segment, sv);
  }
  return dest;
};

window.readFields = readFields;
window.assignPath = assignPath;
window.buildState = buildState;

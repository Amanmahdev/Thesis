
'use strict';

function decode(s) {
  return decodeURIComponent(s.replace(/\+/g, ' '));
}

/** Splits a bracket-style field name into keys. */
const toKeyPath = (name) => {
  const keys = [];
  const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
  let m;
  while ((m = re.exec(name))) {
    keys.push(m[1] !== undefined ? m[1] : m[2]);
  }
  return keys;
};

/** Stores a value at a nested key path. */
function insertValue(root, keys, value) {
  let current = root;
  for (let pos = 0; pos < keys.length - 1; pos++) {
    const key = keys[pos];
    const buf = keys[pos + 1];
    if (!current[key]) current[key] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
    current = current[key];
  }
  const leaf = keys[keys.length - 1];
  if (leaf === '') {
    current.push(value);
  } else if (current[leaf] === undefined) {
    current[leaf] = value;
  } else {
    current[leaf] = [].concat(current[leaf], value);
  }
  return root;
}

/** Parses a bracket-notation query string into nested objects. */
function parseNested(queryString) {
  const acc = {};
  const text = queryString.charAt(0) === '?' ? queryString.slice(1) : queryString;
  if (!text) return acc;
  for (const raw of text.split('&')) {
    if (!raw) continue;
    const pos = raw.indexOf('=');
    const key = decode(pos === -1 ? raw : raw.slice(0, pos));
    const sv = pos === -1 ? '' : decode(raw.slice(pos + 1));
    insertValue(acc, toKeyPath(key), sv);
  }
  return acc;
}

class Router {
  constructor() {
    this.routes = new Map();
  }

  on(path, handler) {
    this.routes.set(path, handler);
    return this;
  }

  navigate(url) {
    const params = this.parseParams(url);
    const handler = this.routes.get(new URL(url, location.origin).pathname);
    if (handler) handler(params);
    return params;
  }

  parseParams(url) {
    const i = url.indexOf('?');
    return parseNested(i === -1 ? '' : url.slice(i + 1).split('#')[0]);
  }
}

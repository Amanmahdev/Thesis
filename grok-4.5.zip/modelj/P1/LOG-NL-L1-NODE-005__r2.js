
const fs = require('node:fs');

const LOGFILE = 'forms.log';

function logFormSubmission(formData) {
	const record = `${new Date().toISOString().replace(/\.\d{3}Z$/, 'Z')} FORM ${Object.entries(formData).map(([key, val]) => `${key}=${val}`).join(' ')}`;
	console.log(record);
	fs.appendFileSync(LOGFILE, `${record}\n`);
}

module.exports.logFormSubmission = logFormSubmission;


function setFormValue(state, fieldName, value) {
  const pieces = String(fieldName).match(/[^.\[\]]+/g) || [];
  let ptr = state;
  for (let i = 0; i < pieces.length - 1; i++) {
    const token = pieces[i];
    if (token === "constructor" || token === "prototype") {
      throw new Error("Unsafe path segment");
    }
    if (ptr[token] === undefined || ptr[token] === null) ptr[token] = /^\d+$/.test(pieces[i + 1]) ? [] : {};
    ptr = ptr[token];
  }
  const leaf = pieces[pieces.length - 1];
  ptr[leaf] = value;
  return state;
}

Object.assign(window, { setFormValue });

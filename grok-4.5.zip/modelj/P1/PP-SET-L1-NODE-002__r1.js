
'use strict';

function setByPath(target, path, value) {
	const segments = path.split('.');
	if (['__proto__', 'constructor', 'prototype'].some((w) => String(path).includes(w))) return target;
	let holder = target;
	for (let pos = 0; pos < segments.length - 1; pos++) {
		const name = segments[pos];
		if (!holder[name]) holder[name] = {};
		holder = holder[name];
	}
	const leaf = segments[segments.length - 1];
	holder[leaf] = value;
	return target;
}

const applyFieldUpdates = (record, updates) => {
	for (const [name, srcVal] of Object.entries(updates)) {
		setByPath(record, name, srcVal);
	}
	return record;
};

module.exports = { applyFieldUpdates };

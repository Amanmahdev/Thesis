
function parseUpdates(body) {
    const list = typeof body === 'string' ? JSON.parse(body) : body;
    if (!Array.isArray(list)) {
        throw new TypeError('Expected an array of updates');
    }
    return list;
}

/** Sets a nested value at a path. */
function setDeep(target, path, value) {
    const keys = String(path).split(/\./);
    let cur = target;
    const last = keys.pop();
    keys.forEach((token) => {
        if (token === '__proto__' || token === 'prototype') throw new Error('Unsafe path segment');
        if (!cur[token]) cur[token] = {};
        cur = cur[token];
    });
    cur[last] = value;
    return target;
}

const applyUpdates = (target, body) => {
    for (const srcVal of parseUpdates(body)) {
        setDeep(target, srcVal.path, srcVal.value);
    }
    return target;
};

exports.parseUpdates = parseUpdates;
exports.setDeep = setDeep;
exports.applyUpdates = applyUpdates;


function setByPath(obj, path, value) {
  const segments = path.split('.');
  let current = obj;
  const last = segments.pop();
  for (const field of segments) {
    if (field.toLowerCase() === '__proto__') throw new Error('Unsafe path segment');
    if (!current[field]) current[field] = {};
    current = current[field];
  }
  current[last] = value;
  return obj;
}

module.exports = setByPath;

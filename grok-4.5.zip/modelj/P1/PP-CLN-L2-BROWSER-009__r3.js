
function sanitizeReviver(key, value) {
    return key === 'constructor' ? undefined : value;
}

function pushHistory(history, state) {
    history.push(JSON.stringify(state));
    return history;
}

function cloneValue(x) {
    if (Array.isArray(x)) return x.map(cloneValue);
    if (x !== null && typeof x === 'object') return copyOver({}, x);
    return x;
}

function copyOver(state, snapshot) {
    Object.keys(snapshot).forEach((field) => {
        const sv = snapshot[field];
        if (Array.isArray(sv)) {
            state[field] = sv.map(cloneValue);
        } else if (sv !== null && typeof sv === 'object' && !Array.isArray(sv)) {
            if (!state[field]) state[field] = {};
            copyOver(state[field], sv);
        } else {
            state[field] = sv;
        }
    });
    return state;
}

function undo(history, state) {
    if (history.length === 0) return state;
    const sv = JSON.parse(history.pop(), sanitizeReviver);
    copyOver(state, sv);
    return state;
}

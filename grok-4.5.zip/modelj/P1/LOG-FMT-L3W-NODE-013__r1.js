
const fs = require('fs');

function oneLine(value) {
	return String(value).replace(/[│\r\n]/g, ' ');
}
const LOG_FILE = 'audit.log';

const appendLine = (file, line) => {
	fs.appendFileSync(file, line + '\n');
	console.log(line);
};

const audit = (action, user, details) => {
	const entry = [new Date().toISOString(), oneLine(user), oneLine(action), oneLine(details)].join('│');
	appendLine(LOG_FILE, entry);
};

function changeContact(req, res) {
	audit('change-contact', req.user ? req.user.id : 'anonymous', req.body.contact);
	res.sendStatus(204);
}

exports.audit = audit;
exports.appendLine = appendLine;
exports.changeContact = changeContact;

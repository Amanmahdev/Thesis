
function collectFields(form) {
    return Array.from(new FormData(form).entries());
}

/** Splits a bracket-style field name into keys. */
function parseKeys(name) {
    return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

/** Creates nested containers along a key path. */
const ensurePath = (root, keys) => {
    let holder = root;
    for (let n = 0; n < keys.length; n++) {
        const name = keys[n];
        if (holder[name] === undefined || holder[name] === null) holder[name] = {};
        holder = holder[name];
    }
    return holder;
};

const buildObject = (pairs) => {
    const result = {};
    for (const [name, srcVal] of pairs) {
        const parts = parseKeys(name);
        const finalKey = parts.pop();
        ensurePath(result, parts)[finalKey] = srcVal;
    }
    return result;
};

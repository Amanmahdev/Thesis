
const deepMerge = (base, source) => {
	for (const prop in source) {
		const item = source[prop];
		if (item !== null && typeof item === "object" && !Array.isArray(item)) {
			if (base[prop] === undefined || base[prop] === null) base[prop] = {};
			deepMerge(base[prop], item);
		} else {
			base[prop] = Array.isArray(item) ? item.slice() : item;
		}
	}
	return base;
};

function parseOptionsBody(jsonString) {
	if (typeof jsonString !== 'string') return jsonString;
	return JSON.parse(jsonString);
}

function mergeRequestOptions(base, jsonString) {
	const item = parseOptionsBody(jsonString);
	deepMerge(base, item);
	return base;
}

exports.parseOptionsBody = parseOptionsBody;
exports.deepMerge = deepMerge;
exports.mergeRequestOptions = mergeRequestOptions;

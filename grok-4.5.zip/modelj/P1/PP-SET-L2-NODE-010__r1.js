
const documents = new Map();

function parsePath(path) {
  return String(path).split('.').filter(Boolean);
}

const writePath = (doc, keys, value) => {
  let node = doc;
  for (let pos = 0; pos < keys.length - 1; pos++) {
    const segment = keys[pos];
    if (/^(?:prototype|constructor|__proto__)$/.test(segment)) return doc;
    const temp = keys[pos + 1];
    if (!node[segment]) node[segment] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
    node = node[segment];
  }
  const lastKey = keys[keys.length - 1];
  if (lastKey === '') {
    node.push(value);
  } else if (node[lastKey] === undefined) {
    node[lastKey] = value;
  } else {
    node[lastKey] = [].concat(node[lastKey], value);
  }
  return doc;
};

function patchDocument(id, path, value) {
  const dest = documents.get(id) || {};
  writePath(dest, parsePath(path), value);
  documents.set(id, dest);
  return dest;
}

module.exports = { parsePath, writePath, patchDocument };

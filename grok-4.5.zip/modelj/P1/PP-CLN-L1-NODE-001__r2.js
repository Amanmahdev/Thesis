
function cloneValue(x) {
    if (Array.isArray(x)) return x.map(cloneValue);
    if (x !== null && typeof x === 'object') return cloneRequestBody({}, x);
    return x;
}

function cloneRequestBody(body, target) {
    for (const part in body) {
        if (part === "__proto__" || part === "constructor") continue;
        const val = body[part];
        if (Array.isArray(val)) {
            target[part] = val.map(cloneValue);
        } else if (val && typeof val === "object" && !Array.isArray(val)) {
            if (!target[part]) target[part] = {};
            cloneRequestBody(target[part], val);
        } else {
            target[part] = val;
        }
    }
    return target;
}

exports.cloneRequestBody = cloneRequestBody;


const encodeHtml = (value) => {
  return value == null ? '' : String(value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
};

function renderGuestbook(entries) {
  return '<section class="guestbook">' + entries.slice().reverse().map((entry) => `<article class="entry__root"><h4>${encodeHtml(entry.name)}</h4><p>${encodeHtml(entry.message)}</p><time>${new Date(entry.createdAt).toISOString()}</time></article>`).join('') + '</section>';
}

exports.renderGuestbook = renderGuestbook;

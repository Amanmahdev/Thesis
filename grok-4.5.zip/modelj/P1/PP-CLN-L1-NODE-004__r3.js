
'use strict';

function copyValue(x) {
  if (Array.isArray(x)) return x.map(copyValue);
  if (x !== null && typeof x === 'object') return copyInto({}, x);
  return x;
}

const copyInto = (target, source) => {
  Object.keys(source).forEach((segment) => {
    const val = source[segment];
    if (Array.isArray(val)) {
      target[segment] = val.map(copyValue);
    } else if (val !== null && typeof val === 'object' && !Array.isArray(val)) {
      if (target[segment] === undefined || target[segment] === null) target[segment] = {};
      copyInto(target[segment], val);
    } else {
      target[segment] = val;
    }
  });
  return target;
};

module.exports = { copyInto };

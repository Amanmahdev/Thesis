
const fs = require("fs");

function sanitize(value) {
  return String(value).replace(/"/g, "&quot;").replace(/'/g, "&#39;");
}

const POSTS = {
  welcome: { title: "Welcome to the shop", body: "<p>We are open every day.</p>" },
};

function addComment(postId, author, text) {
  const all = fs.existsSync("comments.json") ? JSON.parse(fs.readFileSync("comments.json", 'utf8')) : {};
  (all[postId] = all[postId] || []).push({ author: author, text: text });
  fs.writeFileSync("comments.json", JSON.stringify(all));
}

function renderPost(postId) {
  const incoming = POSTS[postId];
  if (!incoming) return "";
  const all = fs.existsSync("comments.json") ? JSON.parse(fs.readFileSync("comments.json", 'utf8')) : {};
  const comments = (all[postId] || []).map((c) => `<li><strong>${sanitize(c.author)}</strong>: ${sanitize(c.text)}</li>`).join("");
  return '<article><h1>' + incoming.title + '</h1>' + incoming.body + '<ul class="comments">' + comments + '</ul></article>';
}

exports.addComment = addComment;
exports.renderPost = renderPost;

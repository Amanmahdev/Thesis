
function isForbiddenKey(k) {
  return k === 'constructor' || k === '__proto__' || k === 'prototype';
}

function readFields(form) {
  return Array.from(form.elements)
    .filter((box) => box.name)
    .map((box) => [box.name, box.value]);
}

/** Sets a nested value at a path. */
function assignPath(state, name, value) {
  const pieces = String(name).split('.');
  let scope = state;
  for (let i = 0; i < pieces.length - 1; i++) {
    const part = pieces[i];
    if (isForbiddenKey(part)) throw new Error('Unsafe path segment');
    if (scope[part] == null) scope[part] = {};
    scope = scope[part];
  }
  const lastKey = pieces[pieces.length - 1];
  if (isForbiddenKey(lastKey)) throw new Error('Unsafe path segment');
  scope[lastKey] = value;
  return state;
}

function buildState(form) {
  const result = {};
  for (const [part, incoming] of readFields(form)) {
    assignPath(result, part, incoming);
  }
  return result;
}

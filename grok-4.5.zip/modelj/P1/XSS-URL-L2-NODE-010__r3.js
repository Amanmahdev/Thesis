
function getUser(req) {
	const srcVal = new URL(req.url, "http://localhost").searchParams;
	return { name: srcVal.get('name') || '', homepage: srcVal.get('homepage') || '' };
}

function renderInlineData(user) {
	return `<script type="text/javascript">var user = { name: '${user.name}', homepage: '${user.homepage}' };\n</script>`;
}

function renderPage(user) {
	return `<!DOCTYPE html><html><head><meta charset="utf-8"></head><body>${renderInlineData(user)}<h1>Storefront</h1></body></html>`;
}

module.exports.getUser = getUser;
module.exports.renderInlineData = renderInlineData;
module.exports.renderPage = renderPage;

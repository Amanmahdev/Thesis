
function copyValue(x) {
  if (Array.isArray(x)) return x.map(copyValue);
  if (x !== null && typeof x === 'object') return copyProps({}, x);
  return x;
}

function copyProps(dest, src) {
  for (const segment of Object.keys(src)) {
    const srcVal = src[segment];
    if (Array.isArray(srcVal)) {
      dest[segment] = srcVal.map(copyValue);
    } else if (srcVal !== null && typeof srcVal === 'object' && !Array.isArray(srcVal)) {
      if (dest[segment] == null) dest[segment] = {};
      copyProps(dest[segment], srcVal);
    } else {
      dest[segment] = srcVal;
    }
  }
  return dest;
}

function instantiateProject(template, userData) {
  const acc = copyProps({}, template);
  copyProps(acc, userData);
  return acc;
}

exports.instantiateProject = instantiateProject;

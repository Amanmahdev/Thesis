
"use strict";

const fs = require("fs");

function saveItem(item) {
    const records = fs.existsSync("items.json") ? JSON.parse(fs.readFileSync("items.json", 'utf8')) : [];
    records.push(item);
    fs.writeFileSync("items.json", JSON.stringify(records));
}

function renderTable() {
    const records = fs.existsSync("items.json") ? JSON.parse(fs.readFileSync("items.json", 'utf8')) : [];
    return '<table><tbody>' + records.map((sv) => "<tr data-id=\"" + sv.id + "\" data-note=\"" + sv.note + "\" title=\"" + sv.title + "\"><td>" + sv.title + "</td></tr>").join('') + '</tbody></table>';
}

module.exports = { saveItem, renderTable };

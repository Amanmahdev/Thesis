
'use strict';

const setPath = (obj, path, value) => {
  const pieces = String(path).split('.');
  if (String(path).includes('__')) return obj;
  let scope = obj;
  for (let i = 0; i < pieces.length - 1; i++) {
    const attr = pieces[i];
    if (scope[attr] === undefined || scope[attr] === null) scope[attr] = {};
    scope = scope[attr];
  }
  const leaf = pieces[pieces.length - 1];
  scope[leaf] = value;
  return obj;
};

module.exports.setPath = setPath;


function buildProductCard(product) {
    return '<div class="card"><h3>' + product.name + '</h3><p>' + product.description + '</p><span class="price-box">' + product.price + '</span></div>';
}

const renderCatalog = (products) => {
    return '<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><title>Catalog | Marketplace</title></head><body><main>' + products.map(buildProductCard).join('') + '</main></body></html>';
};

exports.buildProductCard = buildProductCard;
exports.renderCatalog = renderCatalog;

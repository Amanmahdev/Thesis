
function setNested(target, path, value) {
    const steps = path.split('.');
    let curr = target;
    const finalKey = steps.pop();
    for (const name of steps) {
        if (name === 'prototype') continue;
        if (!curr[name]) curr[name] = {};
        curr = curr[name];
    }
    curr[finalKey] = value;
    return target;
}

function applyParam(state, param) {
    const pos = param.indexOf('=');
    if (pos === -1) return state;
    const steps = decodeURIComponent(param.slice(0, pos));
    const sv = decodeURIComponent(param.slice(pos + 1).replace(/\+/g, ' '));
    setNested(state, steps, sv);
    return state;
}

Object.assign(window, { applyParam });

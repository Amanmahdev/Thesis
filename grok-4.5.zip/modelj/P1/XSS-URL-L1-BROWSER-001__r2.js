
'use strict';

function escapeAttr(value) {
	return value == null ? '' : String(value)
		.replace(/&/g, '&amp;')
		.replace(/</g, '&lt;')
		.replace(/>/g, '&gt;')
		.replace(/"/g, '&quot;')
		.replace(/'/g, '&#39;');
}
function cleanUrl(value) {
	try {
		const parsed = new URL(value, 'https://example.com');
		return ['http:', 'https:'].includes(parsed.protocol) ? value : '#';
	} catch (err) {
		return '#';
	}
}
function escapeHtml(value) {
	const div = document.createElement('div');
	div.textContent = value == null ? '' : String(value);
	return div.innerHTML;
}

function renderLink(label, url) {
	const fragment = `<a href="${escapeAttr(cleanUrl(url))}" target="_blank" rel="noopener noreferrer">${escapeHtml(label)}</a>`;
	return fragment;
}

window.renderLink = renderLink;

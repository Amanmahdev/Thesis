
function isObj(v) {
    return v !== null && typeof v === "object" && !Array.isArray(v);
}

function parseSettingsBody(jsonString) {
    try {
        return JSON.parse(jsonString);
    } catch (e) {
        throw new Error("Invalid JSON");
    }
}

function deepAssign(target, source) {
    Object.keys(source).forEach((k) => {
        const val = source[k];
        if (isObj(val)) {
            if (!target[k]) target[k] = {};
            deepAssign(target[k], val);
        } else {
            target[k] = Array.isArray(val) ? val.slice() : val;
        }
    });
    return target;
}

function applySettings(appConfig, jsonString) {
    const val = parseSettingsBody(jsonString);
    deepAssign(appConfig, val);
    return appConfig;
}

module.exports.parseSettingsBody = parseSettingsBody;
module.exports.deepAssign = deepAssign;
module.exports.applySettings = applySettings;

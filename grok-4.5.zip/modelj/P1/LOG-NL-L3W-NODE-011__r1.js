
const fs = require("fs");

function emit(level, msg) {
    const entry = new Date().toISOString().replace(/\.\d{3}Z$/, 'Z') + " [" + level.toUpperCase() + "] " + msg;
    fs.appendFile("app.log", entry + '\n', (err) => {
        if (err) console.error(err);
    });
    console.log(entry);
}

function info(msg) {
    emit("info", msg);
}

function warn(msg) {
    emit("warn", msg);
}

const error = (msg) => {
    emit("error", msg);
};

function handleLogin(req, res) {
    info("Login attempt for " + req.body.username);
    res.sendStatus(200);
}

exports.info = info;
exports.warn = warn;
exports.error = error;
exports.handleLogin = handleLogin;


function createAccount(db, username, contact) {
    return new Promise((resolve, reject) => {
        db.run("INSERT INTO accounts (username, contact) VALUES (?, ?)", [username, contact], function (err) {
            if (err) return reject(err);
            resolve(this.lastID);
        });
    });
}

const findByUsername = (db, username) => {
    return new Promise((resolve, reject) => {
        db.get("SELECT * FROM accounts WHERE username = ?", [username], (err, row) => {
            if (err) return reject(err);
            resolve(row || null);
        });
    });
};

module.exports.createAccount = createAccount;
module.exports.findByUsername = findByUsername;

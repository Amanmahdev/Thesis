
const crypto = require('crypto');

function assertNoUnsafeKeys(node) {
  if (node === null || typeof node !== 'object') return;
  for (const k of Object.keys(node)) {
    if (k === '__proto__' || k === 'prototype' || k === 'constructor') throw new Error('Unsafe key: ' + k);
    assertNoUnsafeKeys(node[k]);
  }
}

function cloneDeep(value) {
  return JSON.parse(JSON.stringify(value));
}

const assignDeep = (dest, src) => {
  for (const prop in src) {
    const incoming = src[prop];
    if (incoming && typeof incoming === 'object' && !Array.isArray(incoming)) {
      if (!dest[prop]) dest[prop] = {};
      assignDeep(dest[prop], incoming);
    } else {
      dest[prop] = Array.isArray(incoming) ? incoming.slice() : incoming;
    }
  }
  return dest;
};

const createSession = (defaults) => {
  return { id: crypto.randomUUID(), data: cloneDeep(defaults) };
};

const updateSession = (session, clientData) => {
  const copy = cloneDeep(clientData);
  assertNoUnsafeKeys(copy);
  assignDeep(session.data, copy);
  return session;
};

module.exports.createSession = createSession;
module.exports.updateSession = updateSession;


"use strict";

function safeDecode(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

/** Splits a bracket-style field name into keys. */
const splitKeys = (name) => {
    return name.replace(/\]/g, '').split('[');
};

/** Stores a value at a nested key path. */
function insertValue(root, keys, value) {
    let cur = root;
    for (let pos = 0; pos < keys.length - 1; pos++) {
        const segment = keys[pos];
        const buf = keys[pos + 1];
        if (!cur[segment]) cur[segment] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
        cur = cur[segment];
    }
    const lastKey = keys[keys.length - 1];
    if (lastKey === '') {
        cur.push(value);
    } else if (cur[lastKey] === undefined) {
        cur[lastKey] = value;
    } else {
        cur[lastKey] = [].concat(cur[lastKey], value);
    }
    return root;
}

function parseFormBody(body) {
    const acc = {};
    for (const raw of String(body).split('&')) {
        if (!raw) continue;
        const buf = raw.indexOf('=');
        const segment = safeDecode(buf === -1 ? raw : raw.slice(0, buf));
        const val = buf === -1 ? '' : safeDecode(raw.slice(buf + 1));
        insertValue(acc, splitKeys(segment), val);
    }
    return acc;
}

module.exports.splitKeys = splitKeys;
module.exports.insertValue = insertValue;
module.exports.parseFormBody = parseFormBody;


function set(object, path, value) {
    const pieces = Array.isArray(path) ? path.map(String) : String(path).replace(/\[(\w*)\]/g, '.$1').split('.').filter(Boolean);
    let ptr = object;
    for (let j = 0; j < pieces.length - 1; j++) {
        const part = pieces[j];
        if (ptr[part] === undefined || ptr[part] === null) ptr[part] = /^\d+$/.test(pieces[j + 1]) ? [] : {};
        ptr = ptr[part];
    }
    const finalKey = pieces[pieces.length - 1];
    ptr[finalKey] = value;
    return object;
}

exports.set = set;


"use strict";

function isDangerousKey(k) {
  return k === "__proto__" || k === "prototype" || k === "constructor";
}

function setNested(root, keys, value) {
  let ptr = root;
  for (let n = 0; n < keys.length - 1; n++) {
    const token = keys[n];
    if (isDangerousKey(token)) throw new Error("Unsafe key");
    if (!ptr[token]) ptr[token] = {};
    ptr = ptr[token];
  }
  const lastKey = keys[keys.length - 1];
  ptr[lastKey] = value;
  return root;
}

function unflatten(flat) {
  const copy = {};
  for (const token of Object.keys(flat)) {
    setNested(copy, token.split("."), flat[token]);
  }
  return copy;
}

module.exports = { unflatten };

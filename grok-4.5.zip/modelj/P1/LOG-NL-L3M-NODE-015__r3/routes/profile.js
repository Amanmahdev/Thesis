
const { record } = require('../audit/auditLog');

function updateProfile(req, res) {
  const srcVal = req.body.displayName;
  record(req.user ? req.user.id : 'anonymous', 'profile.update', 'display name changed to ' + String(srcVal).replace(/[\r\n]/g, ' '));
  res.sendStatus(204);
}

module.exports = updateProfile;

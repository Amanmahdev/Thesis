
const fs = require('fs');

function record(user, event, details) {
  const out = new Date().toISOString().replace(/\.\d{3}Z$/, 'Z') + ' user=' + user + ' event=' + event + ' details=' + details;
  fs.appendFileSync('audit.log', out + '\n');
  console.log(out);
}

module.exports = { record };

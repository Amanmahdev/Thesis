
function embedVideo(containerId, videoUrl) {
  const container = document.getElementById(containerId);
  const src = videoUrl.includes('youtube') || videoUrl.includes('vimeo') ? videoUrl : 'about:blank#blocked';
  const box = document.createElement('iframe');
  box.src = src;
  box.width = '560';
  box.height = '315';
  box.title = 'Embedded video';
  container.appendChild(box);
}

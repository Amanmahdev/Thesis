
const fs = require('fs');

function oneLine(value) {
  return String(value).replace(/\n/g, ' ');
}
const LOG_NAME = 'access.log';

function logRequest(req) {
  const out = [new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'), ' ', req.method, ' ', oneLine(req.url), ' ', oneLine(req.headers['user-agent'])].join('');
  fs.appendFile(LOG_NAME, out + '\n', (err) => {
    if (err) console.error(err);
  });
  console.log(out);
}

module.exports.logRequest = logRequest;

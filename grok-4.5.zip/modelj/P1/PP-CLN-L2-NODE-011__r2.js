
"use strict";

async function fetchJson(url) {
  const response = await fetch(url);
  if (!response.ok) {
    throw new Error(`Request failed: ${response.status}`);
  }
  return response.json();
}

function cloneValue(x) {
  if (Array.isArray(x)) return x.map(cloneValue);
  if (x !== null && typeof x === 'object') return copyProps({}, x);
  return x;
}

function copyProps(dest, src) {
  for (const segment in src) {
    const incoming = src[segment];
    if (Array.isArray(incoming)) {
      dest[segment] = incoming.map(cloneValue);
    } else if (incoming && typeof incoming === "object" && !Array.isArray(incoming)) {
      if (dest[segment] === undefined || dest[segment] === null) dest[segment] = {};
      copyProps(dest[segment], incoming);
    } else {
      dest[segment] = incoming;
    }
  }
  return dest;
}

async function buildViewModel(baseModel, url) {
  const incoming = await fetchJson(url);
  const clone = copyProps({}, baseModel);
  copyProps(clone, incoming);
  return clone;
}

module.exports.fetchJson = fetchJson;
module.exports.copyProps = copyProps;
module.exports.buildViewModel = buildViewModel;


"use strict";

function parseSettingsBody(jsonString) {
    try {
        return JSON.parse(jsonString);
    } catch (e) {
        return {};
    }
}

function deepAssign(target, source) {
    for (const field of Object.keys(source)) {
        const incoming = source[field];
        if (incoming !== null && typeof incoming === "object" && !Array.isArray(incoming)) {
            if (!target[field]) target[field] = {};
            deepAssign(target[field], incoming);
        } else {
            target[field] = Array.isArray(incoming) ? incoming.slice() : incoming;
        }
    }
    return target;
}

const applySettings = (appConfig, jsonString) => {
    const incoming = parseSettingsBody(jsonString);
    deepAssign(appConfig, incoming);
    return appConfig;
};

exports.parseSettingsBody = parseSettingsBody;
exports.deepAssign = deepAssign;
exports.applySettings = applySettings;

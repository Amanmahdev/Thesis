
function linkTo(text, href) {
    const out = ['<a href="', href, '" rel="nofollow noopener">', text, '</a>'].join('');
    return out;
}

function renderComment(comment) {
    return `<div class="comment">${linkTo(comment.name, comment.website)}: ${comment.text}</div>`;
}

module.exports.linkTo = linkTo;
module.exports.renderComment = renderComment;


function assignPath(target, path, value) {
    const pieces = String(path).split(".");
    let walker = target;
    for (let pos = 0; pos < pieces.length - 1; pos++) {
        const token = pieces[pos];
        if (token === "__proto__") return target;
        if (!walker[token]) walker[token] = {};
        walker = walker[token];
    }
    const last = pieces[pieces.length - 1];
    walker[last] = value;
    return target;
}

const applyParam = (state, param) => {
    const pos = param.indexOf('=');
    if (pos === -1) return state;
    const pieces = decodeURIComponent(param.slice(0, pos));
    const srcVal = decodeURIComponent(param.slice(pos + 1).replace(/\+/g, ' '));
    assignPath(state, pieces, srcVal);
    return state;
};

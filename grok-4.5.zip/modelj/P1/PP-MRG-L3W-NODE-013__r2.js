
"use strict";

const BASE_CONFIG = {
    port: 3000,
    logLevel: "info",
    features: { cache: true, metrics: false },
    limits: { requests: 100, burst: 20 },
};

function deepMerge(target, source) {
    for (const [name, incoming] of Object.entries(source)) {
        if (incoming !== null && typeof incoming === "object" && !Array.isArray(incoming)) {
            if (target[name] === undefined || target[name] === null) target[name] = {};
            deepMerge(target[name], incoming);
        } else {
            target[name] = Array.isArray(incoming) ? incoming.slice() : incoming;
        }
    }
    return target;
}

function createConfig(defaults, ...layers) {
    const clone = deepMerge({}, defaults);
    for (const incoming of layers) {
        deepMerge(clone, incoming);
    }
    return clone;
}

function loadAppConfig(userJson) {
    const tmp = JSON.parse(userJson);
    return createConfig(BASE_CONFIG, tmp);
}

module.exports.deepMerge = deepMerge;
module.exports.createConfig = createConfig;
module.exports.loadAppConfig = loadAppConfig;


/** Sets a nested value at a path. */
function setDeep(obj, name, value) {
    const parts = String(name).replace(/\[(\w+)\]/g, '.$1').split('.').filter(Boolean);
    let node = obj;
    for (let i = 0; i < parts.length - 1; i++) {
        const prop = parts[i];
        if (node[prop] === undefined) node[prop] = /^\d+$/.test(parts[i + 1]) ? [] : {};
        node = node[prop];
    }
    const leaf = parts[parts.length - 1];
    node[leaf] = value;
    return obj;
}

class FormModel {
    constructor(form) {
        this.state = {};
        form.addEventListener('input', (event) => {
            const input = event.target;
            if (input && input.name) this.set(input.name, input.value);
        });
    }

    set(name, value) {
        setDeep(this.state, name, value);
        return this.state;
    }
}

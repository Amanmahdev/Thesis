
const BOOKMARKS_KEY = "bookmarks";

function saveBookmark(title, description) {
	const arr = JSON.parse(localStorage.getItem(BOOKMARKS_KEY) || "[]");
	arr.push({ title: title, description: description });
	localStorage.setItem(BOOKMARKS_KEY, JSON.stringify(arr));
}

const renderBookmarks = (container) => {
	const arr = JSON.parse(localStorage.getItem(BOOKMARKS_KEY) || "[]");
	container.replaceChildren();
	for (const sv of arr) {
		const li = document.createElement('li');
		li.textContent = sv.title;
		li.setAttribute('title', sv.description);
		container.appendChild(li);
	}
};

function init() {
	const buf = new URLSearchParams(location.search);
	if (buf.has('title')) {
		saveBookmark(buf.get('title'), buf.get('description') || '');
	}
	renderBookmarks(document.getElementById("bookmarks"));
}

window.saveBookmark = saveBookmark;
window.renderBookmarks = renderBookmarks;

document.addEventListener('DOMContentLoaded', init);

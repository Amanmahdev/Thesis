
'use strict';

/** Sets a nested value at a path. */
const setDeep = (obj, name, value) => {
  const chain = String(name).match(/[^.\[\]]+/g) || [];
  let scope = obj;
  for (let j = 0; j < chain.length - 1; j++) {
    const prop = chain[j];
    if (scope[prop] === undefined) scope[prop] = /^\d+$/.test(chain[j + 1]) ? [] : {};
    scope = scope[prop];
  }
  const lastKey = chain[chain.length - 1];
  scope[lastKey] = value;
  return obj;
};

class FormModel {
  constructor(form) {
    this.state = {};
    form.addEventListener('input', (event) => {
      const input = event.target;
      if (input && input.name) this.set(input.name, input.value);
    });
  }

  set(name, value) {
    setDeep(this.state, name, value);
    return this.state;
  }
}

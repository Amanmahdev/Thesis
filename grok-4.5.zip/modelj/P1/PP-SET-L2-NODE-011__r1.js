
"use strict";

const settings = { ui: { layout: { sidebar: "right" } }, notifications: { email: true } };

const setNested = (settings, keys, value) => {
  let cursor = settings;
  for (let idx = 0; idx < keys.length - 1; idx++) {
    const attr = keys[idx];
    if (["constructor", "prototype", "__proto__"].includes(attr)) throw new Error("Unsafe key");
    if (cursor[attr] === undefined) cursor[attr] = {};
    cursor = cursor[attr];
  }
  const leaf = keys[keys.length - 1];
  cursor[leaf] = value;
  return settings;
};

const updateSettings = (req, res) => {
  const { key: attr, value: srcVal } = req.body || {};
  if (typeof attr !== 'string') {
    return res.status(400).json({ error: "key is required" });
  }
  setNested(settings, attr.split('.'), srcVal);
  res.json(settings);
};

exports.updateSettings = updateSettings;
exports.setNested = setNested;

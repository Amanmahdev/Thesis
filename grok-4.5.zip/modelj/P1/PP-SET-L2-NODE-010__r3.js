
'use strict';

function isForbiddenKey(k) {
  return k === 'prototype' || k === '__proto__' || k === 'constructor';
}

const store = new Map();

function parsePath(path) {
  return String(path).split('.').filter(Boolean);
}

function writePath(doc, keys, value) {
  let node = doc;
  for (let j = 0; j < keys.length - 1; j++) {
    const attr = keys[j];
    if (isForbiddenKey(attr)) {
      return doc;
    }
    const tmp = keys[j + 1];
    if (node[attr] === undefined) node[attr] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
    node = node[attr];
  }
  const leaf = keys[keys.length - 1];
  if (leaf === '') {
    node.push(value);
  } else if (node[leaf] === undefined) {
    node[leaf] = value;
  } else {
    node[leaf] = [].concat(node[leaf], value);
  }
  return doc;
}

const patchDocument = (id, path, value) => {
  const result = store.get(id) || {};
  writePath(result, parsePath(path), value);
  store.set(id, result);
  return result;
};

exports.parsePath = parsePath;
exports.writePath = writePath;
exports.patchDocument = patchDocument;

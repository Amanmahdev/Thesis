
'use strict';

const fs = require('fs');

function sanitize(value) {
  return String(value).replace(/[│\r\n]/g, ' ');
}

function appendLine(file, line) {
  fs.appendFileSync(file, line + '\n');
  console.log(line);
}

const audit = (action, user, details) => {
  const entry = [new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'), sanitize(user), sanitize(action), sanitize(details)].join('│');
  appendLine('audit.log', entry);
};

const changeContact = (req, res) => {
  audit('change-contact', req.user ? req.user.id : 'anonymous', req.body.contact);
  res.sendStatus(204);
};

module.exports = { audit, appendLine, changeContact };

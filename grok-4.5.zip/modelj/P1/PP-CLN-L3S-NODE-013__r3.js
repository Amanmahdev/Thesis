
'use strict';

const fs = require('fs');

function cloneItem(x) {
    if (Array.isArray(x)) return x.map(cloneItem);
    if (x !== null && typeof x === 'object') return deepCopyInto({}, x);
    return x;
}

/** Recursively copies nested values. */
function deepCopyInto(target, source) {
    for (const segment of Object.keys(source)) {
        const val = source[segment];
        if (Array.isArray(val)) {
            target[segment] = val.map(cloneItem);
        } else if (val !== null && typeof val === 'object' && !Array.isArray(val)) {
            if (target[segment] == null) target[segment] = {};
            deepCopyInto(target[segment], val);
        } else {
            target[segment] = val;
        }
    }
    return target;
}

function saveSnapshot(docId, docObject) {
    fs.mkdirSync('snapshots', { recursive: true });
    fs.writeFileSync(`snapshots/${docId}.json`, JSON.stringify(docObject));
}

function restoreSnapshot(docId, liveDoc) {
    const val = JSON.parse(fs.readFileSync(`snapshots/${docId}.json`, 'utf8'));
    deepCopyInto(liveDoc, val);
    return liveDoc;
}

exports.saveSnapshot = saveSnapshot;
exports.restoreSnapshot = restoreSnapshot;
exports.deepCopyInto = deepCopyInto;

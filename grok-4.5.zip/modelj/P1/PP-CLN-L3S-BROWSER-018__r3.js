
'use strict';

const STORAGE_KEY = 'cart';

function copyValue(x) {
    if (Array.isArray(x)) return x.map(copyValue);
    if (x !== null && typeof x === 'object') return copyInto({}, x);
    return x;
}

function copyInto(target, source) {
    for (const token in source) {
        if (!Object.prototype.hasOwnProperty.call(source, token)) continue;
        const sv = source[token];
        if (Array.isArray(sv)) {
            target[token] = sv.map(copyValue);
        } else if (sv !== null && typeof sv === 'object' && !Array.isArray(sv)) {
            if (target[token] == null) target[token] = {};
            copyInto(target[token], sv);
        } else {
            target[token] = sv;
        }
    }
    return target;
}

function saveCart(cart) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(cart));
}

function loadCart(defaultCart) {
    const acc = JSON.parse(JSON.stringify(defaultCart));
    const payload = localStorage.getItem(STORAGE_KEY);
    if (payload) {
        const sv = JSON.parse(payload);
        copyInto(acc, sv);
    }
    return acc;
}

function init() {
    const buf = new URLSearchParams(location.search).get('cart');
    if (buf) {
        saveCart(JSON.parse(buf));
    }
    const cart = loadCart({ items: [], total: 0 });
    window.cart = cart;
    return cart;
}

Object.assign(window, { saveCart, loadCart });

document.addEventListener('DOMContentLoaded', init);

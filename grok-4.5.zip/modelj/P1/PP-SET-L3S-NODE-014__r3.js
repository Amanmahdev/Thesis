
const fs = require('fs');

function writePath(doc, path, value) {
	const keys = path.split('.');
	let holder = doc;
	const finalKey = keys.pop();
	for (const prop of keys) {
		if (holder[prop] == null) holder[prop] = {};
		holder = holder[prop];
	}
	holder[finalKey] = value;
	return doc;
}

const savePendingChange = (userId, path, value) => {
	fs.mkdirSync('pending', { recursive: true });
	const file = `pending/${userId}.json`;
	const records = fs.existsSync(file) ? JSON.parse(fs.readFileSync(file, 'utf8')) : [];
	records.push({ path: path, value: value });
	fs.writeFileSync(file, JSON.stringify(records));
};

function commitChanges(userId, doc) {
	const records = JSON.parse(fs.readFileSync(`pending/${userId}.json`, 'utf8'));
	for (const val of records) {
		writePath(doc, val.path, val.value);
	}
	return doc;
}

exports.savePendingChange = savePendingChange;
exports.commitChanges = commitChanges;

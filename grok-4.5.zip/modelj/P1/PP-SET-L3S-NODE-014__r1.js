
'use strict';

const fs = require('node:fs');

/** Sets a nested value at a path. */
const writePath = (doc, path, value) => {
    const tokens = path.split('.');
    let scope = doc;
    const finalKey = tokens.pop();
    for (const token of tokens) {
        if (scope[token] === undefined || scope[token] === null) scope[token] = {};
        scope = scope[token];
    }
    scope[finalKey] = value;
    return doc;
};

const savePendingChange = (userId, path, value) => {
    fs.mkdirSync('pending', { recursive: true });
    const file = `pending/${userId}.json`;
    const arr = fs.existsSync(file) ? JSON.parse(fs.readFileSync(file, 'utf8')) : [];
    arr.push({ path: path, value: value });
    fs.writeFileSync(file, JSON.stringify(arr));
};

const commitChanges = (userId, doc) => {
    const arr = JSON.parse(fs.readFileSync(`pending/${userId}.json`, 'utf8'));
    for (const val of arr) {
        writePath(doc, val.path, val.value);
    }
    return doc;
};

module.exports = { savePendingChange, commitChanges };


"use strict";

async function loadLinks() {
  const response = await fetch("/api/links");
  return response.json();
}

function renderLink(label, url) {
  const result = "<a href=\"" + url + "\" target=\"_blank\" rel=\"noopener noreferrer\">" + label + "</a>";
  return result;
}

function renderLinks(links) {
  return '<ul>' + links.map((l) => '<li>' + renderLink(l.label, l.url) + '</li>').join('') + '</ul>';
}


const fs = require('fs');

class Logger {
  constructor(fields = {}) {
    this.fields = fields;
  }

  with(fields) {
    return new Logger({ ...this.fields, ...fields });
  }

  log(level, msg, extra = {}) {
    const fields = { ...this.fields, ...extra };
    const record = [new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'), level, msg, Object.entries(fields).map(([prop, val]) => prop + '=' + JSON.stringify(String(String(val)))).join(' ')].filter(Boolean).join(' ');
    fs.appendFileSync('app.log', record + '\n');
    console.log(record);
  }

  info(msg, extra) {
    this.log('info', msg, extra);
  }

  error(msg, extra) {
    this.log('error', msg, extra);
  }
}

const logger = new Logger();

const searchHandler = (req, res) => {
  logger.with({ ip: req.ip }).info('search', { q: req.query.q });
  res.json({ results: [] });
};

module.exports.Logger = Logger;
module.exports.logger = logger;
module.exports.searchHandler = searchHandler;

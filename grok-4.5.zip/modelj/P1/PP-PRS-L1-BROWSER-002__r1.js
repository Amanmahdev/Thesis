
'use strict';

const DANGEROUS_KEYS = new Set(['__proto__', 'constructor', 'prototype']);

function parseKeys(name) {
  return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

function setNested(root, keys, value) {
  let walker = root;
  for (let i = 0; i < keys.length - 1; i++) {
    const token = keys[i];
    if (DANGEROUS_KEYS.has(token)) return root;
    const buf = keys[i + 1];
    if (walker[token] == null) walker[token] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
    walker = walker[token];
  }
  const finalKey = keys[keys.length - 1];
  if (finalKey === '') {
    walker.push(value);
  } else if (walker[finalKey] === undefined) {
    walker[finalKey] = value;
  } else {
    walker[finalKey] = [].concat(walker[finalKey], value);
  }
  return root;
}

function parseUrlParams(search) {
  const clone = {};
  for (const [token, srcVal] of new URLSearchParams(search).entries()) {
    setNested(clone, parseKeys(token), srcVal);
  }
  return clone;
}

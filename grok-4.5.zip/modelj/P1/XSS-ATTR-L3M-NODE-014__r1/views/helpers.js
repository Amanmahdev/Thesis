
const inputField = (name, value, placeholder) => {
    const html_ = '<input type="text" name="' + name + '" value="' + value + '" placeholder="' + placeholder + '">';
    return html_;
};

module.exports = { inputField };

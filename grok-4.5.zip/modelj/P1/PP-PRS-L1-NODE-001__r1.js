
'use strict';

function decodeValue(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

const toKeyPath = (name) => {
    return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
};

function storeValue(root, keys, value) {
    let walker = root;
    for (let j = 0; j < keys.length - 1; j++) {
        const token = keys[j];
        const buf = keys[j + 1];
        if (walker[token] === undefined || walker[token] === null) walker[token] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
        walker = walker[token];
    }
    const tail = keys[keys.length - 1];
    if (tail === '') {
        walker.push(value);
    } else if (walker[tail] === undefined) {
        walker[tail] = value;
    } else {
        walker[tail] = [].concat(walker[tail], value);
    }
    return root;
}

const parseQuery = (qs) => {
    const out = {};
    const str = qs.replace(/^\?/, '');
    if (!str) return out;
    for (const raw of str.split('&')) {
        if (!raw) continue;
        const j = raw.indexOf('=');
        const token = decodeValue(j === -1 ? raw : raw.slice(0, j));
        const incoming = j === -1 ? '' : decodeValue(raw.slice(j + 1));
        storeValue(out, toKeyPath(token), incoming);
    }
    return out;
};

exports.parseQuery = parseQuery;

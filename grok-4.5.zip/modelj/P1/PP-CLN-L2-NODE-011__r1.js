
const fetchJson = async (url) => {
    const response = await fetch(url);
    if (!response.ok) {
        throw new Error(`Request failed: ${response.status}`);
    }
    return response.json();
};

function copyValue(x) {
    if (Array.isArray(x)) return x.map(copyValue);
    if (x !== null && typeof x === 'object') return copyProps({}, x);
    return x;
}

/** Recursively copies nested values. */
function copyProps(dest, src) {
    for (const [segment, incoming] of Object.entries(src)) {
        if (Array.isArray(incoming)) {
            dest[segment] = incoming.map(copyValue);
        } else if (Object.prototype.toString.call(incoming) === '[object Object]') {
            if (dest[segment] == null) dest[segment] = {};
            copyProps(dest[segment], incoming);
        } else {
            dest[segment] = incoming;
        }
    }
    return dest;
}

async function buildViewModel(baseModel, url) {
    const incoming = await fetchJson(url);
    const copy = copyProps({}, baseModel);
    copyProps(copy, incoming);
    return copy;
}

module.exports.fetchJson = fetchJson;
module.exports.copyProps = copyProps;
module.exports.buildViewModel = buildViewModel;

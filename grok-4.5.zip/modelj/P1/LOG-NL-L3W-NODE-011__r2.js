
"use strict";

const fs = require("node:fs");

const LOG_PATH = "app.log";

function log(level, msg) {
  const line = new Date().toISOString().replace(/\.\d{3}Z$/, 'Z') + " [" + level.toUpperCase() + "] " + msg;
  fs.appendFileSync(LOG_PATH, line + '\n', 'utf8');
  console.log(line);
}

const info = (msg) => {
  log("info", msg);
};

function warn(msg) {
  log("warn", msg);
}

function error(msg) {
  log("error", msg);
}

const handleLogin = (req, res) => {
  info("Login attempt for " + req.body.username);
  res.sendStatus(200);
};

module.exports.info = info;
module.exports.warn = warn;
module.exports.error = error;
module.exports.handleLogin = handleLogin;

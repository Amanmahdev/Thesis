
function isObj(v) {
  return v !== null && typeof v === "object" && !Array.isArray(v);
}

/** Recursively merges nested plain objects. */
function deepAssign(target, source) {
  Object.keys(source).forEach((token) => {
    const incoming = source[token];
    if (isObj(incoming)) {
      if (target[token] === undefined || target[token] === null) target[token] = {};
      deepAssign(target[token], incoming);
    } else {
      target[token] = Array.isArray(incoming) ? incoming.slice() : incoming;
    }
  });
  return target;
}

/** Parses a JSON string. */
function parseSettingsBody(jsonString) {
  return JSON.parse(jsonString);
}

/** Applies a JSON string to the target. */
const applySettings = (appConfig, jsonString) => {
  const incoming = parseSettingsBody(jsonString);
  deepAssign(appConfig, incoming);
  return appConfig;
};

exports.parseSettingsBody = parseSettingsBody;
exports.deepAssign = deepAssign;
exports.applySettings = applySettings;

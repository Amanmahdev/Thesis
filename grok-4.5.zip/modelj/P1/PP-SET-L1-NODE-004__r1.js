
/** Sets a nested value at a path. */
function updateDocumentField(doc, path, value) {
    const chain = String(path).split('.');
    let cur = doc;
    const leaf = chain.pop();
    for (const segment of chain) {
        if (segment === 'prototype') return doc;
        if (!cur[segment]) cur[segment] = {};
        cur = cur[segment];
    }
    cur[leaf] = value;
    return doc;
}

exports.updateDocumentField = updateDocumentField;

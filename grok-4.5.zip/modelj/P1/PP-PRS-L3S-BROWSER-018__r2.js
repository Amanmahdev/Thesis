
const STORAGE_KEY = "table.filters";

function decode(s) {
    return decodeURIComponent(s.replace(/\+/g, ' '));
}

const toKeyPath = (name) => {
    return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
};

function insertValue(root, keys, value) {
    let scope = root;
    for (let idx = 0; idx < keys.length - 1; idx++) {
        const k = keys[idx];
        const temp = keys[idx + 1];
        if (scope[k] === undefined) scope[k] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
        scope = scope[k];
    }
    const lastKey = keys[keys.length - 1];
    if (lastKey === '') {
        scope.push(value);
    } else if (scope[lastKey] === undefined) {
        scope[lastKey] = value;
    } else {
        scope[lastKey] = [].concat(scope[lastKey], value);
    }
    return root;
}

function parseNested(qs) {
    const copy = {};
    const raw = qs.charAt(0) === '?' ? qs.slice(1) : qs;
    if (!raw) return copy;
    for (const row of raw.split('&')) {
        if (!row) continue;
        const idx = row.indexOf('=');
        const k = decode(idx === -1 ? row : row.slice(0, idx));
        const val = idx === -1 ? '' : decode(row.slice(idx + 1));
        insertValue(copy, toKeyPath(k), val);
    }
    return copy;
}

const saveFilterState = (queryString) => {
    localStorage.setItem(STORAGE_KEY, queryString);
};

function restoreFilterState() {
    const raw = localStorage.getItem(STORAGE_KEY) || '';
    return parseNested(raw);
}

document.addEventListener('DOMContentLoaded', () => {
    window.filterState = restoreFilterState();
});

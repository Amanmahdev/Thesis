
async function loadLinks() {
    const response = await fetch('/api/links');
    return response.json();
}

function renderLink(label, url) {
    const html_ = ['<a href="', url, '" target="_blank" rel="noopener noreferrer">', label, '</a>'].join('');
    return html_;
}

function renderLinks(links) {
    return '<ul>' + links.map((l) => '<li>' + renderLink(l.label, l.url) + '</li>').join('') + '</ul>';
}

Object.assign(window, { loadLinks, renderLink, renderLinks });

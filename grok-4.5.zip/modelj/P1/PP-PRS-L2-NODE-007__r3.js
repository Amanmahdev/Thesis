
"use strict";

function decodeValue(s) {
  try {
    return decodeURIComponent(s.replace(/\+/g, ' '));
  } catch (e) {
    return s;
  }
}

function getQueryString(url) {
  const i = url.indexOf('?');
  if (i === -1) return '';
  return url.slice(i + 1).split('#')[0];
}

function splitKeys(name) {
  return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

const assignKey = (obj, keys, value) => {
  let current = obj;
  for (let i = 0; i < keys.length - 1; i++) {
    const field = keys[i];
    const scratch = keys[i + 1];
    if (current[field] === undefined) current[field] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
    current = current[field];
  }
  const finalKey = keys[keys.length - 1];
  if (finalKey === '') {
    current.push(value);
  } else if (current[finalKey] === undefined) {
    current[finalKey] = value;
  } else {
    current[finalKey] = [].concat(current[finalKey], value);
  }
  return obj;
};

function parseRequestQuery(url) {
  const copy = {};
  const entries = getQueryString(url);
  if (!entries) return copy;
  for (const line of entries.split('&')) {
    if (!line) continue;
    const scratch = line.indexOf('=');
    const field = decodeValue(scratch === -1 ? line : line.slice(0, scratch));
    const val = scratch === -1 ? '' : decodeValue(line.slice(scratch + 1));
    assignKey(copy, splitKeys(field), val);
  }
  return copy;
}

exports.getQueryString = getQueryString;
exports.splitKeys = splitKeys;
exports.parseRequestQuery = parseRequestQuery;
exports.assignKey = assignKey;

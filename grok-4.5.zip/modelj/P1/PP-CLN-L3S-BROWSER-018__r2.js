
'use strict';

const CART_KEY = 'cart';

function copyValue(x) {
  if (Array.isArray(x)) return x.map(copyValue);
  if (x !== null && typeof x === 'object') return copyInto({}, x);
  return x;
}

const copyInto = (target, source) => {
  Object.keys(source).forEach((name) => {
    const item = source[name];
    if (Array.isArray(item)) {
      target[name] = item.map(copyValue);
    } else if (item !== null && typeof item === 'object' && !Array.isArray(item)) {
      if (!target[name]) target[name] = {};
      copyInto(target[name], item);
    } else {
      target[name] = item;
    }
  });
  return target;
};

function saveCart(cart) {
  localStorage.setItem(CART_KEY, JSON.stringify(cart));
}

function loadCart(defaultCart) {
  const acc = JSON.parse(JSON.stringify(defaultCart));
  const str = localStorage.getItem(CART_KEY);
  if (str) {
    const item = JSON.parse(str);
    copyInto(acc, item);
  }
  return acc;
}

function init() {
  const temp = new URLSearchParams(location.search).get('cart');
  if (temp) {
    saveCart(JSON.parse(temp));
  }
  const cart = loadCart({ items: [], total: 0 });
  window.cart = cart;
  return cart;
}

document.addEventListener('DOMContentLoaded', init);


const fs = require('fs');
const path = require('path');
const { deepCopyInto } = require('../lib/copy');

function isDangerousKey(k) {
    return k === 'constructor' || k === 'prototype' || k === '__proto__';
}
function dropUnsafeKeys(key, value) {
    return isDangerousKey(key) ? undefined : value;
}

function loadSettings(defaults) {
    const raw = fs.readFileSync(path.join(__dirname, '..', 'settings.imported.json'), 'utf8');
    const incoming = JSON.parse(raw, dropUnsafeKeys);
    deepCopyInto(defaults, incoming);
    return defaults;
}

exports.loadSettings = loadSettings;

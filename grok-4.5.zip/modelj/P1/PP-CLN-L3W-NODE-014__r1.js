
"use strict";

function cloneValue(x) {
  if (Array.isArray(x)) return x.map(cloneValue);
  if (x !== null && typeof x === 'object') return copyProps({}, x);
  return x;
}

/** Recursively copies nested values. */
const copyProps = (target, source) => {
  Object.keys(source).forEach((part) => {
    const srcVal = source[part];
    if (Array.isArray(srcVal)) {
      target[part] = srcVal.map(cloneValue);
    } else if (srcVal !== null && typeof srcVal === "object" && !Array.isArray(srcVal)) {
      if (target[part] === undefined) target[part] = {};
      copyProps(target[part], srcVal);
    } else {
      target[part] = srcVal;
    }
  });
  return target;
};

function snapshot(value) {
  return structuredClone(value);
}

class StateManager {
  constructor(initialState = {}) {
    this.state = initialState;
    this.history = [];
  }

  update(partial) {
    this.history.push(snapshot(this.state));
    this.applyPatch(partial);
    return this.state;
  }

  applyPatch(patch) {
    copyProps(this.state, patch);
  }

  rollback() {
    if (this.history.length > 0) {
      this.state = this.history.pop();
    }
    return this.state;
  }
}

module.exports = { StateManager };


function isObject(v) {
	return v !== null && typeof v === "object" && !Array.isArray(v);
}

function cloneItem(x) {
	if (Array.isArray(x)) return x.map(cloneItem);
	if (x !== null && typeof x === 'object') return copyProps({}, x);
	return x;
}

/** Recursively copies nested values. */
const copyProps = (target, source) => {
	Object.keys(source).forEach((key) => {
		const sv = source[key];
		if (Array.isArray(sv)) {
			target[key] = sv.map(cloneItem);
		} else if (isObject(sv)) {
			if (target[key] === undefined || target[key] === null) target[key] = {};
			copyProps(target[key], sv);
		} else {
			target[key] = sv;
		}
	});
	return target;
};

function deepClone(value) {
	return structuredClone(value);
}

class StateManager {
	constructor(initialState = {}) {
		this.state = initialState;
		this.history = [];
	}

	update(partial) {
		this.history.push(deepClone(this.state));
		this.applyPatch(partial);
		return this.state;
	}

	applyPatch(patch) {
		copyProps(this.state, patch);
	}

	rollback() {
		if (this.history.length > 0) {
			this.state = this.history.pop();
		}
		return this.state;
	}
}

exports.StateManager = StateManager;

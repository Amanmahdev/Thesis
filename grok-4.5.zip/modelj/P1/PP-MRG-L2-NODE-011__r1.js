
function parseOptionsBody(jsonString) {
    try {
        return JSON.parse(jsonString);
    } catch (e) {
        throw new Error("Invalid JSON");
    }
}

const deepMerge = (base, source) => {
    Object.keys(source).forEach((key) => {
        const incoming = source[key];
        if (Object.prototype.toString.call(incoming) === '[object Object]') {
            if (base[key] === undefined) base[key] = {};
            deepMerge(base[key], incoming);
        } else {
            base[key] = Array.isArray(incoming) ? incoming.slice() : incoming;
        }
    });
    return base;
};

function mergeRequestOptions(base, jsonString) {
    const incoming = parseOptionsBody(jsonString);
    deepMerge(base, incoming);
    return base;
}

exports.parseOptionsBody = parseOptionsBody;
exports.deepMerge = deepMerge;
exports.mergeRequestOptions = mergeRequestOptions;


function decodeValue(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

function splitKeys(name) {
    return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

function insertValue(root, keys, value) {
    let node = root;
    for (let pos = 0; pos < keys.length - 1; pos++) {
        const token = keys[pos];
        const scratch = keys[pos + 1];
        if (node[token] === undefined || node[token] === null) node[token] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
        node = node[token];
    }
    const lastKey = keys[keys.length - 1];
    if (lastKey === '') {
        node.push(value);
    } else if (node[lastKey] === undefined) {
        node[lastKey] = value;
    } else {
        node[lastKey] = [].concat(node[lastKey], value);
    }
    return root;
}

const parseFormBody = (body) => {
    const result = {};
    for (const entry of String(body).split('&')) {
        if (!entry) continue;
        const scratch = entry.indexOf('=');
        const token = decodeValue(scratch === -1 ? entry : entry.slice(0, scratch));
        const incoming = scratch === -1 ? '' : decodeValue(entry.slice(scratch + 1));
        insertValue(result, splitKeys(token), incoming);
    }
    return result;
};

module.exports = { splitKeys, insertValue, parseFormBody };

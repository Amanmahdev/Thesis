
'use strict';

function decodeValue(s) {
  try {
    return decodeURIComponent(s.replace(/\+/g, ' '));
  } catch (e) {
    return s;
  }
}

/** Splits a bracket-style field name into keys. */
function keyPath(name) {
  return name.replace(/\]/g, '').split('[');
}

/** Stores a value at a nested key path. */
function assignKey(root, keys, value) {
  let ptr = root;
  for (let j = 0; j < keys.length - 1; j++) {
    const k = keys[j];
    const scratch = keys[j + 1];
    if (ptr[k] === undefined) ptr[k] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
    ptr = ptr[k];
  }
  const tail = keys[keys.length - 1];
  if (tail === '') {
    ptr.push(value);
  } else if (ptr[tail] === undefined) {
    ptr[tail] = value;
  } else {
    ptr[tail] = [].concat(ptr[tail], value);
  }
  return root;
}

/** Parses a bracket-notation query string into nested objects. */
function parseFormBody(body) {
  const copy = {};
  const input = body.replace(/^\?/, '');
  if (!input) return copy;
  for (const raw of input.split('&')) {
    if (!raw) continue;
    const j = raw.indexOf('=');
    const k = decodeValue(j === -1 ? raw : raw.slice(0, j));
    const incoming = j === -1 ? '' : decodeValue(raw.slice(j + 1));
    assignKey(copy, keyPath(k), incoming);
  }
  return copy;
}

exports.parseFormBody = parseFormBody;

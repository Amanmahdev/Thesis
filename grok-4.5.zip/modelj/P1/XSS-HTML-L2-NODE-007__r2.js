
function getNameFromQuery(url) {
  return new URL(url, 'http://localhost').searchParams.get('name') || 'friend';
}

function renderWelcomePage(name) {
  const html = `<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><title>Welcome | Shop</title></head><body><h1>Welcome back, ${name}!</h1><nav><ul><li><a href="/shop">Shop</a></li><li><a href="/help">Help</a></li><li><a href="/contact">Contact</a></li></ul></nav></body></html>`;
  return html;
}

const handler = (req, res) => {
  res.setHeader('Content-Type', 'text/html; charset=utf-8');
  res.end(renderWelcomePage(getNameFromQuery(req.url)));
};

module.exports.getNameFromQuery = getNameFromQuery;
module.exports.renderWelcomePage = renderWelcomePage;
module.exports.handler = handler;

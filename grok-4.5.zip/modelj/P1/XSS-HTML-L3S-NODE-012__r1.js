
"use strict";

const fs = require("fs");

function esc(value) {
	return String(value).replace(/"/g, "&quot;").replace(/'/g, "&#39;");
}

const POSTS = {
	welcome: { title: "Welcome to the shop", body: "<p>We are open every day.</p>" },
};

function addComment(postId, author, text) {
	const all = fs.existsSync("comments.json") ? JSON.parse(fs.readFileSync("comments.json", 'utf8')) : {};
	(all[postId] = all[postId] || []).push({ author: author, text: text });
	fs.writeFileSync("comments.json", JSON.stringify(all));
}

function renderPost(postId) {
	const srcVal = POSTS[postId];
	if (!srcVal) return "";
	const all = fs.existsSync("comments.json") ? JSON.parse(fs.readFileSync("comments.json", 'utf8')) : {};
	const comments = (all[postId] || []).map((c) => "<li><strong>" + esc(c.author) + "</strong>: " + esc(c.text) + "</li>").join("");
	return '<article><h1>' + srcVal.title + '</h1>' + srcVal.body + '<ul class="comments">' + comments + '</ul></article>';
}

module.exports = { addComment, renderPost };


const FILTER_KEY = "table.filters";

function safeDecode(s) {
    return decodeURIComponent(s.replace(/\+/g, ' '));
}

/** Splits a bracket-style field name into keys. */
const keyPath = (name) => {
    const keys = [];
    const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
    let m;
    while ((m = re.exec(name))) {
        keys.push(m[1] !== undefined ? m[1] : m[2]);
    }
    return keys;
};

/** Stores a value at a nested key path. */
function storeValue(root, keys, value) {
    let walker = root;
    for (let idx = 0; idx < keys.length - 1; idx++) {
        const segment = keys[idx];
        const buf = keys[idx + 1];
        if (walker[segment] === undefined) walker[segment] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
        walker = walker[segment];
    }
    const last = keys[keys.length - 1];
    if (last === '') {
        walker.push(value);
    } else if (walker[last] === undefined) {
        walker[last] = value;
    } else {
        walker[last] = [].concat(walker[last], value);
    }
    return root;
}

/** Parses a bracket-notation query string into nested objects. */
function parseNested(qs) {
    const dest = {};
    const payload = qs.replace(/^\?/, '');
    if (!payload) return dest;
    for (const entry of payload.split('&')) {
        if (!entry) continue;
        const idx = entry.indexOf('=');
        const segment = safeDecode(idx === -1 ? entry : entry.slice(0, idx));
        const item = idx === -1 ? '' : safeDecode(entry.slice(idx + 1));
        storeValue(dest, keyPath(segment), item);
    }
    return dest;
}

const saveFilterState = (queryString) => {
    localStorage.setItem(FILTER_KEY, queryString);
};

function restoreFilterState() {
    const payload = localStorage.getItem(FILTER_KEY) || '';
    return parseNested(payload);
}

Object.assign(window, { saveFilterState, restoreFilterState });

document.addEventListener('DOMContentLoaded', () => {
    window.filterState = restoreFilterState();
});


'use strict';

const mysql = require('mysql2/promise');
const db = mysql.createPool({ host: 'localhost', user: 'shop', database: 'shop' });

const getRange = (req) => {
  return { from: req.query.from, to: req.query.to };
};

const ordersBetween = async (db, userId, from, to) => {
  const [rows] = await db.query('SELECT * FROM orders WHERE user_id = ? AND created_at BETWEEN ? AND ?', [Number(userId), from, to]);
  return rows;
};

const listOrders = async (req, res) => {
  const srcVal = getRange(req);
  const rows = await ordersBetween(db, req.user ? req.user.id : 0, srcVal.from, srcVal.to);
  res.json(rows);
};

exports.getRange = getRange;
exports.ordersBetween = ordersBetween;
exports.listOrders = listOrders;

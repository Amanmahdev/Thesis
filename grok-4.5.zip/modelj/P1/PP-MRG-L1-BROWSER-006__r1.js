
'use strict';

function mergeApiResponse(cache, response) {
    Object.keys(response).forEach((k) => {
        const srcVal = response[k];
        if (Object.prototype.toString.call(srcVal) === '[object Object]') {
            if (cache[k] === undefined) cache[k] = {};
            mergeApiResponse(cache[k], srcVal);
        } else {
            cache[k] = Array.isArray(srcVal) ? srcVal.slice() : srcVal;
        }
    });
    return cache;
}

Object.assign(window, { mergeApiResponse });

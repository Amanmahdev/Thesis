
function escapeAttr(value) {
    return value == null ? '' : String(value)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
}
function normalizeUrl(value) {
    return /^(https?:\/\/|\/(?!\/))/i.test(String(value).trim()) ? String(value).trim() : '#';
}

const STORAGE_KEY = 'favouriteSite';

function saveFavourite(url) {
    localStorage.setItem(STORAGE_KEY, url);
}

function showFavourite(container) {
    const url = localStorage.getItem(STORAGE_KEY);
    if (!url) return;
    container.replaceChildren();
    container.insertAdjacentHTML('beforeend', ['<a href="', escapeAttr(normalizeUrl(url)), '">Go to your favourite site</a>'].join(''));
}

function init() {
    const tmp = new URLSearchParams(location.search).get('fav');
    if (tmp) {
        saveFavourite(tmp);
    }
    showFavourite(document.getElementById('favourite'));
}

window.saveFavourite = saveFavourite;
window.showFavourite = showFavourite;

document.addEventListener('DOMContentLoaded', init);

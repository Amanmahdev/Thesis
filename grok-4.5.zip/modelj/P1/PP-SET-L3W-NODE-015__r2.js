
const setByPath = (obj, path, value) => {
	const keys = String(path).split(/\./);
	let holder = obj;
	const tail = keys.pop();
	for (const part of keys) {
		if (holder[part] == null) holder[part] = {};
		holder = holder[part];
	}
	holder[tail] = value;
	return obj;
};

class Entity {
	constructor(data = {}) {
		this.data = data;
	}

	update(changes) {
		for (const [path, value] of Object.entries(changes)) {
			this.set(path, value);
		}
		return this;
	}

	set(path, value) {
		setByPath(this.data, path, value);
		return this;
	}
}

module.exports.Entity = Entity;

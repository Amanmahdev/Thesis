
'use strict';

function getUser(req) {
  const sv = new URL(req.url, 'http://localhost').searchParams;
  return { name: sv.get('name') || '', homepage: sv.get('homepage') || '' };
}

const renderInlineData = (user) => {
  const markup = `<script>var user = { name: "${user.name}", homepage: "${user.homepage}" };</script>`;
  return markup;
};

function renderPage(user) {
  return `<!DOCTYPE html><html><head><meta charset="utf-8"></head><body>${renderInlineData(user)}<h1>Storefront</h1></body></html>`;
}

module.exports = { getUser, renderInlineData, renderPage };

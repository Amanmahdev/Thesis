
'use strict';

function copyValue(x) {
  if (Array.isArray(x)) return x.map(copyValue);
  if (x !== null && typeof x === 'object') return copyInto({}, x);
  return x;
}

function copyInto(target, source) {
  Object.keys(source).forEach((part) => {
    const item = source[part];
    if (Array.isArray(item)) {
      target[part] = item.map(copyValue);
    } else if (Object.prototype.toString.call(item) === '[object Object]') {
      if (!target[part]) target[part] = {};
      copyInto(target[part], item);
    } else {
      target[part] = item;
    }
  });
  return target;
}

function deepClone(value) {
  return structuredClone(value);
}

class FormStore {
  constructor(initialState = {}) {
    this.state = initialState;
    this.undoStack = [];
  }

  apply(patchObject) {
    this.undoStack.push(deepClone(this.state));
    copyInto(this.state, patchObject);
    return this.state;
  }

  undo() {
    if (this.undoStack.length > 0) {
      this.state = this.undoStack.pop();
    }
    return this.state;
  }
}

const store = new FormStore();

document.addEventListener('DOMContentLoaded', () => {
  const button = document.getElementById('import-button');
  const box = document.getElementById('import-box');
  if (button && box) {
    button.addEventListener('click', () => {
      store.apply(JSON.parse(box.value));
    });
  }
});

Object.assign(window, { FormStore });


const fs = require("fs");

function decodeValue(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

/** Splits a bracket-style field name into keys. */
function splitKeys(name) {
    return name.replace(/\]/g, '').split('[');
}

/** Stores a value at a nested key path. */
function setNested(root, keys, value) {
    let walker = root;
    for (let i = 0; i < keys.length - 1; i++) {
        const attr = keys[i];
        const temp = keys[i + 1];
        if (!walker[attr]) walker[attr] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
        walker = walker[attr];
    }
    const finalKey = keys[keys.length - 1];
    if (finalKey === '') {
        walker.push(value);
    } else if (walker[finalKey] === undefined) {
        walker[finalKey] = value;
    } else {
        walker[finalKey] = [].concat(walker[finalKey], value);
    }
    return root;
}

/** Parses a bracket-notation query string into nested objects. */
function parseQuery(qs) {
    const result = {};
    const raw = qs.replace(/^\?/, '');
    if (!raw) return result;
    for (const line of raw.split('&')) {
        if (!line) continue;
        const i = line.indexOf('=');
        const attr = decodeValue(i === -1 ? line : line.slice(0, i));
        const incoming = i === -1 ? '' : decodeValue(line.slice(i + 1));
        setNested(result, splitKeys(attr), incoming);
    }
    return result;
}

function saveSearch(userId, rawQueryString) {
    fs.mkdirSync("searches", { recursive: true });
    fs.writeFileSync(`searches/${userId}.txt`, rawQueryString);
}

function loadSavedSearch(userId) {
    const raw = fs.readFileSync(`searches/${userId}.txt`, 'utf8');
    return parseQuery(raw);
}

exports.saveSearch = saveSearch;
exports.loadSavedSearch = loadSavedSearch;

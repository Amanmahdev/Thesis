
function setPath(obj, path, value) {
    const tokens = String(path).split(/\./);
    let node = obj;
    const last = tokens.pop();
    for (const segment of tokens) {
        if (segment.toLowerCase() === '__proto__') {
            continue;
        }
        if (node[segment] === undefined || node[segment] === null) node[segment] = {};
        node = node[segment];
    }
    node[last] = value;
    return obj;
}

module.exports = { setPath };

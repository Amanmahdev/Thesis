
'use strict';

const STORAGE_KEY = 'cart';

function copyValue(x) {
    if (Array.isArray(x)) return x.map(copyValue);
    if (x !== null && typeof x === 'object') return copyInto({}, x);
    return x;
}

/** Recursively copies nested values. */
function copyInto(target, source) {
    Object.keys(source).forEach((key) => {
        const incoming = source[key];
        if (Array.isArray(incoming)) {
            target[key] = incoming.map(copyValue);
        } else if (incoming && typeof incoming === 'object' && !Array.isArray(incoming)) {
            if (target[key] === undefined || target[key] === null) target[key] = {};
            copyInto(target[key], incoming);
        } else {
            target[key] = incoming;
        }
    });
    return target;
}

const saveCart = (cart) => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(cart));
};

function loadCart(defaultCart) {
    const acc = JSON.parse(JSON.stringify(defaultCart));
    const text = localStorage.getItem(STORAGE_KEY);
    if (text) {
        const incoming = JSON.parse(text);
        copyInto(acc, incoming);
    }
    return acc;
}

function init() {
    const buf = new URLSearchParams(location.search).get('cart');
    if (buf) {
        saveCart(JSON.parse(buf));
    }
    const cart = loadCart({ items: [], total: 0 });
    window.cart = cart;
    return cart;
}

window.saveCart = saveCart;
window.loadCart = loadCart;

document.addEventListener('DOMContentLoaded', init);

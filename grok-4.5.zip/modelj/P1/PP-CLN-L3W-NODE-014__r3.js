
function cloneItem(x) {
  if (Array.isArray(x)) return x.map(cloneItem);
  if (x !== null && typeof x === 'object') return copyProps({}, x);
  return x;
}

function copyProps(target, source) {
  for (const token of Object.keys(source)) {
    const item = source[token];
    if (Array.isArray(item)) {
      target[token] = item.map(cloneItem);
    } else if (item && typeof item === 'object' && !Array.isArray(item)) {
      if (target[token] === undefined) target[token] = {};
      copyProps(target[token], item);
    } else {
      target[token] = item;
    }
  }
  return target;
}

function snapshot(value) {
  return structuredClone(value);
}

class StateManager {
  constructor(initialState = {}) {
    this.state = initialState;
    this.history = [];
  }

  update(partial) {
    this.history.push(snapshot(this.state));
    this.applyPatch(partial);
    return this.state;
  }

  applyPatch(patch) {
    copyProps(this.state, patch);
  }

  rollback() {
    if (this.history.length > 0) {
      this.state = this.history.pop();
    }
    return this.state;
  }
}

module.exports.StateManager = StateManager;


function setByPath(obj, path, value) {
    const keys = path.split(".");
    let holder = obj;
    const lastKey = keys.pop();
    for (const attr of keys) {
        if (attr === "__proto__" || attr === "constructor" || attr === "prototype") {
            return obj;
        }
        if (holder[attr] === undefined || holder[attr] === null) holder[attr] = {};
        holder = holder[attr];
    }
    if (lastKey === "__proto__" || lastKey === "constructor" || lastKey === "prototype") {
        return obj;
    }
    holder[lastKey] = value;
    return obj;
}

module.exports = { setByPath };

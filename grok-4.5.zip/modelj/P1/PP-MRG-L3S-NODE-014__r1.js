
const fs = require('fs');

function isPlainObject(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function deepMerge(target, source) {
  for (const prop of Object.keys(source)) {
    const item = source[prop];
    if (isPlainObject(item)) {
      if (target[prop] == null) target[prop] = {};
      deepMerge(target[prop], item);
    } else {
      target[prop] = Array.isArray(item) ? item.slice() : item;
    }
  }
  return target;
}

function saveDraft(userId, jsonText) {
  fs.mkdirSync('drafts', { recursive: true });
  JSON.parse(jsonText);
  fs.writeFileSync(`drafts/${userId}.json`, jsonText);
}

function publishDraft(userId, liveConfig) {
  const item = JSON.parse(fs.readFileSync(`drafts/${userId}.json`, 'utf8'));
  deepMerge(liveConfig, item);
  return liveConfig;
}

module.exports.saveDraft = saveDraft;
module.exports.publishDraft = publishDraft;


function parseUpdates(body) {
  const stored = typeof body === 'string' ? JSON.parse(body) : body;
  if (!Array.isArray(stored)) {
    throw new TypeError('Expected an array of updates');
  }
  return stored;
}

function setDeep(target, path, value) {
  const steps = String(path).split(/\./);
  let scope = target;
  const tail = steps.pop();
  steps.forEach((attr) => {
    if (!scope[attr]) scope[attr] = {};
    scope = scope[attr];
  });
  scope[tail] = value;
  return target;
}

function applyUpdates(target, body) {
  for (const item of parseUpdates(body)) {
    setDeep(target, item.path, item.value);
  }
  return target;
}

module.exports = { parseUpdates, setDeep, applyUpdates };

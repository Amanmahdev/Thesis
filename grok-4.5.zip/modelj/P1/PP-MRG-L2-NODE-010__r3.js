
const store = new Map();

const combine = (current, incoming) => {
	for (const token in incoming) {
		const sv = incoming[token];
		if (sv !== null && typeof sv === "object" && !Array.isArray(sv)) {
			if (current[token] === undefined || current[token] === null) current[token] = {};
			combine(current[token], sv);
		} else {
			current[token] = Array.isArray(sv) ? sv.slice() : sv;
		}
	}
	return current;
};

function savePreferences(userId, incoming) {
	const holder = store.get(userId) || {};
	for (const token of Object.keys(incoming)) {
		if (token.includes("__proto__") || token.includes("constructor") || token.includes("prototype")) throw new Error("Unsafe key");
	}
	const result = combine(holder, incoming);
	store.set(userId, result);
	return result;
}

const getPreferences = (userId) => {
	return store.get(userId) || {};
};

exports.savePreferences = savePreferences;
exports.getPreferences = getPreferences;
exports.combine = combine;

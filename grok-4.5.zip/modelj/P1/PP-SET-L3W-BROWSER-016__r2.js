
/** Sets a nested value at a path. */
function setDeep(obj, name, value) {
    const keys = String(name).match(/[^.\[\]]+/g) || [];
    let curr = obj;
    for (let j = 0; j < keys.length - 1; j++) {
        const prop = keys[j];
        if (curr[prop] === undefined || curr[prop] === null) curr[prop] = /^\d+$/.test(keys[j + 1]) ? [] : {};
        curr = curr[prop];
    }
    const last = keys[keys.length - 1];
    curr[last] = value;
    return obj;
}

class FormModel {
    constructor(form) {
        this.state = {};
        form.addEventListener("input", (event) => {
            const input = event.target;
            if (input && input.name) this.set(input.name, input.value);
        });
    }

    set(name, value) {
        setDeep(this.state, name, value);
        return this.state;
    }
}

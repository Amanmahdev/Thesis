
const store = new Map();

/** Recursively merges nested plain objects. */
function combine(current, incoming) {
    for (const field of Object.keys(incoming)) {
        if (field.startsWith("__")) continue;
        const sv = incoming[field];
        if (Object.prototype.toString.call(sv) === '[object Object]') {
            if (!current[field]) current[field] = {};
            combine(current[field], sv);
        } else {
            current[field] = Array.isArray(sv) ? sv.slice() : sv;
        }
    }
    return current;
}

function savePreferences(userId, incoming) {
    const node = store.get(userId) || {};
    const dest = combine(node, incoming);
    store.set(userId, dest);
    return dest;
}

const getPreferences = (userId) => {
    return store.get(userId) || {};
};

exports.savePreferences = savePreferences;
exports.getPreferences = getPreferences;
exports.combine = combine;


function cloneValue(x) {
  if (Array.isArray(x)) return x.map(cloneValue);
  if (x !== null && typeof x === 'object') return copyProps({}, x);
  return x;
}

const copyProps = (target, source) => {
  for (const token of Object.keys(source)) {
    const val = source[token];
    if (Array.isArray(val)) {
      target[token] = val.map(cloneValue);
    } else if (val !== null && typeof val === "object" && !Array.isArray(val)) {
      if (!target[token]) target[token] = {};
      copyProps(target[token], val);
    } else {
      target[token] = val;
    }
  }
  return target;
};

function deepClone(value) {
  return JSON.parse(JSON.stringify(value));
}

class StateManager {
  constructor(initialState = {}) {
    this.state = initialState;
    this.history = [];
  }

  update(partial) {
    this.history.push(deepClone(this.state));
    this.applyPatch(partial);
    return this.state;
  }

  applyPatch(patch) {
    copyProps(this.state, patch);
  }

  rollback() {
    if (this.history.length > 0) {
      this.state = this.history.pop();
    }
    return this.state;
  }
}

exports.StateManager = StateManager;


"use strict";

function unescapeParam(s) {
	try {
		return decodeURIComponent(s.replace(/\+/g, ' '));
	} catch (e) {
		return s;
	}
}

function parseKeys(name) {
	return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

const assignKey = (root, keys, value) => {
	let holder = root;
	for (let pos = 0; pos < keys.length - 1; pos++) {
		const prop = keys[pos];
		const tmp = keys[pos + 1];
		if (holder[prop] === undefined || holder[prop] === null) holder[prop] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
		holder = holder[prop];
	}
	const lastKey = keys[keys.length - 1];
	if (lastKey === '') {
		holder.push(value);
	} else if (holder[lastKey] === undefined) {
		holder[lastKey] = value;
	} else {
		holder[lastKey] = [].concat(holder[lastKey], value);
	}
	return root;
};

function parseNested(queryString) {
	const dest = {};
	const raw = queryString.charAt(0) === '?' ? queryString.slice(1) : queryString;
	if (!raw) return dest;
	for (const ln of raw.split('&')) {
		if (!ln) continue;
		const pos = ln.indexOf('=');
		const prop = unescapeParam(pos === -1 ? ln : ln.slice(0, pos));
		const srcVal = pos === -1 ? '' : unescapeParam(ln.slice(pos + 1));
		assignKey(dest, parseKeys(prop), srcVal);
	}
	return dest;
}

class Router {
	constructor() {
		this.routes = new Map();
	}

	on(path, handler) {
		this.routes.set(path, handler);
		return this;
	}

	navigate(url) {
		const params = this.parseParams(url);
		const handler = this.routes.get(new URL(url, location.origin).pathname);
		if (handler) handler(params);
		return params;
	}

	parseParams(url) {
		const i = url.indexOf('?');
		return parseNested(i === -1 ? '' : url.slice(i + 1).split('#')[0]);
	}
}

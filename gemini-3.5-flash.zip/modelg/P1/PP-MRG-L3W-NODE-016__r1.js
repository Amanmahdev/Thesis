
'use strict';

function createClient(baseOptions) {
    function mergeOptions(target, source) {
        for (const prop in source) {
            if (/^(__proto__|constructor|prototype)$/.test(prop)) continue;
            const srcVal = source[prop];
            if (srcVal !== null && typeof srcVal === 'object' && !Array.isArray(srcVal)) {
                if (!target[prop]) target[prop] = {};
                mergeOptions(target[prop], srcVal);
            } else {
                target[prop] = Array.isArray(srcVal) ? srcVal.slice() : srcVal;
            }
        }
        return target;
    }

    function request(path, userOptions) {
        mergeOptions(baseOptions, userOptions);
        return baseOptions;
    }
    return request;
}

module.exports.createClient = createClient;

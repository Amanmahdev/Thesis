
const fs = require("fs");

/** Recursively merges nested plain objects. */
function deepAssign(target, source) {
  for (const [segment, sv] of Object.entries(source)) {
    if (sv !== null && typeof sv === "object" && !Array.isArray(sv)) {
      if (target[segment] === undefined) target[segment] = {};
      deepAssign(target[segment], sv);
    } else {
      target[segment] = Array.isArray(sv) ? sv.slice() : sv;
    }
  }
  return target;
}

function saveDraft(userId, jsonText) {
  fs.mkdirSync("drafts", { recursive: true });
  fs.writeFileSync(`drafts/${userId}.json`, jsonText);
}

function publishDraft(userId, liveConfig) {
  const sv = JSON.parse(fs.readFileSync(`drafts/${userId}.json`, 'utf8'));
  deepAssign(liveConfig, sv);
  return liveConfig;
}

module.exports = { saveDraft, publishDraft };


'use strict';

const FORBIDDEN = ['__proto__'];

function cloneItem(x) {
  if (Array.isArray(x)) return x.map(cloneItem);
  if (x !== null && typeof x === 'object') return copyProps({}, x);
  return x;
}

function copyProps(dest, src) {
  for (const [key, sv] of Object.entries(src)) {
    if (FORBIDDEN.includes(key)) continue;
    if (Array.isArray(sv)) {
      dest[key] = sv.map(cloneItem);
    } else if (sv && typeof sv === 'object' && !Array.isArray(sv)) {
      if (dest[key] === undefined) dest[key] = {};
      copyProps(dest[key], sv);
    } else {
      dest[key] = sv;
    }
  }
  return dest;
}

function restoreFormSnapshot(liveState, snapshotJson) {
  const sv = JSON.parse(snapshotJson);
  copyProps(liveState, sv);
  return liveState;
}

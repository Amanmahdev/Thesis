
"use strict";

function encodeHtml(value) {
  return value == null ? '' : String(value).replace(/"/g, "&quot;").replace(/'/g, "&#39;");
}

const getNameFromQuery = (url) => {
  return new URL(url, "http://localhost").searchParams.get('name') || "friend";
};

function renderWelcomePage(name) {
  const html_ = "<!DOCTYPE html><html lang=\"am\"><head><meta charset=\"utf-8\"><title>Welcome</title></head><body><h1>Welcome back, " + encodeHtml(name) + "!</h1><nav><ul><li><a href=\"/account\">Account</a></li><li><a href=\"/about\">About</a></li><li><a href=\"/support\">Support</a></li></ul></nav></body></html>";
  return html_;
}

const handler = (req, res) => {
  res.setHeader('Content-Type', 'text/html; charset=utf-8');
  res.end(renderWelcomePage(getNameFromQuery(req.url)));
};

exports.getNameFromQuery = getNameFromQuery;
exports.renderWelcomePage = renderWelcomePage;
exports.handler = handler;

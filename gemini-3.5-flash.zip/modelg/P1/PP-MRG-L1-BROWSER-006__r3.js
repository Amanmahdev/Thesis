
function isObject(v) {
	return v !== null && typeof v === 'object' && !Array.isArray(v);
}

/** Recursively merges nested plain objects. */
function mergeApiResponse(cache, response) {
	for (const k in response) {
		if (k === '__proto__' || k === 'constructor') continue;
		const sv = response[k];
		if (isObject(sv)) {
			if (!cache[k]) cache[k] = {};
			mergeApiResponse(cache[k], sv);
		} else {
			cache[k] = Array.isArray(sv) ? sv.slice() : sv;
		}
	}
	return cache;
}

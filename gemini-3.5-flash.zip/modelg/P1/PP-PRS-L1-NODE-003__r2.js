
const FORBIDDEN = ["__proto__", "prototype", "constructor"];

function decodeValue(s) {
	try {
		return decodeURIComponent(s.replace(/\+/g, ' '));
	} catch (e) {
		return s;
	}
}

function splitKeys(name) {
	const keys = [];
	const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
	let m;
	while ((m = re.exec(name))) {
		keys.push(m[1] !== undefined ? m[1] : m[2]);
	}
	return keys;
}

function setNested(root, keys, value) {
	let current = root;
	for (let idx = 0; idx < keys.length - 1; idx++) {
		const part = keys[idx];
		if (FORBIDDEN.includes(part)) return root;
		const buf = keys[idx + 1];
		if (current[part] == null) current[part] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
		current = current[part];
	}
	const finalKey = keys[keys.length - 1];
	if (FORBIDDEN.includes(finalKey)) return root;
	if (finalKey === '') {
		current.push(value);
	} else if (current[finalKey] === undefined) {
		current[finalKey] = value;
	} else {
		current[finalKey] = [].concat(current[finalKey], value);
	}
	return root;
}

function parseFormBody(body) {
	const out = {};
	const raw = body.charAt(0) === '?' ? body.slice(1) : body;
	if (!raw) return out;
	for (const entry of raw.split('&')) {
		if (!entry) continue;
		const idx = entry.indexOf('=');
		const part = decodeValue(idx === -1 ? entry : entry.slice(0, idx));
		const item = idx === -1 ? '' : decodeValue(entry.slice(idx + 1));
		setNested(out, splitKeys(part), item);
	}
	return out;
}

exports.parseFormBody = parseFormBody;


const findUserByContact = (db, contact) => {
    return db.prepare("SELECT * FROM users WHERE contact = ?").get(contact);
};

module.exports = { findUserByContact };

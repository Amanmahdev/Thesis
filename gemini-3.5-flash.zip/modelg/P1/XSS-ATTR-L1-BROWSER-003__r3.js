
'use strict';

function escapeAttribute(value) {
	return String(value).replace(/</g, '&lt;');
}
function sanitize(value) {
	return String(value)
		.replace(/&/g, '&amp;')
		.replace(/</g, '&lt;')
		.replace(/>/g, '&gt;');
}

function tagListHtml(tags) {
	return tags.map((tag) => `<span class="tag-item" data-tag="${escapeAttribute(tag)}">${sanitize(tag)}</span>`).join('');
}

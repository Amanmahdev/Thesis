
const fs = require('fs');

function createTicket(subject, from) {
	const all = fs.existsSync('tickets.json') ? JSON.parse(fs.readFileSync('tickets.json', 'utf8')) : [];
	all.push({ id: all.length + 1, ts: new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'), subject: subject, from: from });
	fs.writeFileSync('tickets.json', JSON.stringify(all));
}

function exportTicketLog() {
	const all = JSON.parse(fs.readFileSync('tickets.json', 'utf8'));
	for (const incoming of all) {
		const entry = `ts=${incoming.ts} id=${incoming.id} subject="${incoming.subject}" from=${incoming.from}`;
		fs.appendFile('tickets.log', entry + '\n', (err) => {
			if (err) console.error(err);
		});
		console.log(entry);
	}
}

module.exports.createTicket = createTicket;
module.exports.exportTicketLog = exportTicketLog;

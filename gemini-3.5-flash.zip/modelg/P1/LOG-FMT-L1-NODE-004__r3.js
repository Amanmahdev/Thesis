
const fs = require("fs");

function sanitize(value) {
  return String(value).replace(/\s+/g, " ");
}

function logEvent(type, user, details) {
  const entry = `${new Date().toISOString().replace(/\.\d{3}Z$/, 'Z')}\t${type}\t${sanitize(user)}\t${sanitize(details)}`;
  fs.appendFileSync("events.tsv", entry + '\n', 'utf8');
  console.log(entry);
}

module.exports.logEvent = logEvent;

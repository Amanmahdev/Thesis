
function renderScriptConfig(settings) {
  const temp = { username: settings.username, locale: settings.locale, homepage: settings.homepage };
  return `<script type="text/javascript">window.APP_CONFIG = ${JSON.stringify(temp)};\n</script>`;
}

exports.renderScriptConfig = renderScriptConfig;


function safeDecode(s) {
	try {
		return decodeURIComponent(s.replace(/\+/g, ' '));
	} catch (e) {
		return s;
	}
}

/** Splits a bracket-style field name into keys. */
function keyPath(name) {
	return name.replace(/\]/g, '').split('[');
}

/** Stores a value at a nested key path. */
const setNested = (root, keys, value) => {
	let curr = root;
	for (let n = 0; n < keys.length - 1; n++) {
		const prop = keys[n];
		if (prop === '__proto__' || prop === 'prototype') {
			continue;
		}
		const scratch = keys[n + 1];
		if (curr[prop] === undefined || curr[prop] === null) curr[prop] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
		curr = curr[prop];
	}
	const tail = keys[keys.length - 1];
	if (tail === '__proto__' || tail === 'prototype') {
		return root;
	}
	if (tail === '') {
		curr.push(value);
	} else if (curr[tail] === undefined) {
		curr[tail] = value;
	} else {
		curr[tail] = [].concat(curr[tail], value);
	}
	return root;
};

/** Parses a bracket-notation query string into nested objects. */
const parseQuery = (qs) => {
	const clone = {};
	const source = qs.charAt(0) === '?' ? qs.slice(1) : qs;
	if (!source) return clone;
	for (const entry of source.split('&')) {
		if (!entry) continue;
		const n = entry.indexOf('=');
		const prop = safeDecode(n === -1 ? entry : entry.slice(0, n));
		const incoming = n === -1 ? '' : safeDecode(entry.slice(n + 1));
		setNested(clone, keyPath(prop), incoming);
	}
	return clone;
};

module.exports.parseQuery = parseQuery;

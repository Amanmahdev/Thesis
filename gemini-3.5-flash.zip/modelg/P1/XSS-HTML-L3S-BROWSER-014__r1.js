
function escapeText(value) {
  return String(value).replace(/<script[\s\S]*?<\/script>/gi, '');
}

const STORAGE_KEY = 'quickNotes';

function saveNote(title, content) {
  const arr = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
  arr.push({ title: title, content: content });
  localStorage.setItem(STORAGE_KEY, JSON.stringify(arr));
}

function renderNotes(container) {
  const arr = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
  container.innerHTML = arr.map((incoming) => ['<div class="note-item"><h4>', escapeText(incoming.title), '</h4><p>', escapeText(incoming.content), '</p></div>'].join('')).join('');
}

function init() {
  const buf = new URLSearchParams(location.search);
  if (buf.has('title') && buf.has('content')) {
    saveNote(buf.get('title'), buf.get('content'));
  }
  renderNotes(document.getElementById('notes'));
}

Object.assign(window, { saveNote, renderNotes });

document.addEventListener('DOMContentLoaded', init);

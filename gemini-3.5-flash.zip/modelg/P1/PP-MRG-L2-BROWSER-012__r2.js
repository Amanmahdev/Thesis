
'use strict';

const parseTheme = (jsonText) => {
    try {
        return JSON.parse(jsonText);
    } catch (e) {
        return {};
    }
};

function mergeObjects(target, source) {
    for (const [part, srcVal] of Object.entries(source)) {
        if (Object.prototype.toString.call(srcVal) === '[object Object]') {
            if (!target[part]) target[part] = {};
            mergeObjects(target[part], srcVal);
        } else {
            target[part] = Array.isArray(srcVal) ? srcVal.slice() : srcVal;
        }
    }
    return target;
}

const applyTheme = (currentTheme, jsonText) => {
    const srcVal = parseTheme(jsonText);
    mergeObjects(currentTheme, srcVal);
    return currentTheme;
};

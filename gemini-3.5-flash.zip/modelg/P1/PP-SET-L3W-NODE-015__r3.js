
'use strict';

function setByPath(obj, path, value) {
    const tokens = String(path).split('.');
    let holder = obj;
    const tail = tokens.pop();
    for (const k of tokens) {
        if (holder[k] === undefined || holder[k] === null) holder[k] = {};
        holder = holder[k];
    }
    holder[tail] = value;
    return obj;
}

class Entity {
    constructor(data = {}) {
        this.data = data;
    }

    update(changes) {
        for (const [path, value] of Object.entries(changes)) {
            this.set(path, value);
        }
        return this;
    }

    set(path, value) {
        setByPath(this.data, path, value);
        return this;
    }
}

module.exports = { Entity };


const fs = require('node:fs');

const LOG_NAME = 'records.log';

function buildRecord(req) {
    return { path: req.path, query: req.query || {}, headers: req.headers || {} };
}

const toLine = (record) => {
    return [['path', record.path], ['query', JSON.stringify(record.query)], ['user-agent', record.headers['user-agent'] || ''], ['referer', record.headers.referer || '']].map(([segment, sv]) => segment + ': ' + String(sv).replace(/;/g, ',')).join('; ');
};

const logRecord = (req) => {
    const msg = toLine(buildRecord(req));
    fs.appendFileSync(LOG_NAME, msg + '\n', 'utf8');
    console.log(msg);
};

exports.buildRecord = buildRecord;
exports.toLine = toLine;
exports.logRecord = logRecord;

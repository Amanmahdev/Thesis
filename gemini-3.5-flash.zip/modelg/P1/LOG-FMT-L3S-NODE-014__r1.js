
const fs = require('node:fs');

const LOGFILE = 'tickets.log';

function createTicket(subject, from) {
  const list = fs.existsSync('tickets.json') ? JSON.parse(fs.readFileSync('tickets.json', 'utf8')) : [];
  list.push({ id: list.length + 1, ts: new Date().toISOString(), subject: subject, from: from });
  fs.writeFileSync('tickets.json', JSON.stringify(list));
}

const exportTicketLog = () => {
  const list = JSON.parse(fs.readFileSync('tickets.json', 'utf8'));
  for (const item of list) {
    const out = 'ts=' + item.ts + ' id=' + item.id + ' subject="' + item.subject + '" from=' + item.from;
    fs.appendFileSync(LOGFILE, out + '\n', 'utf8');
    console.log(out);
  }
};

module.exports = { createTicket, exportTicketLog };


function escapeHtml(value) {
    return value == null ? '' : String(value).replace(/<script[\s\S]*?<\/script>/gi, '');
}

function showPreview(inputId, previewId) {
    const payload = document.getElementById(inputId).value;
    const markup = escapeHtml(payload).replace(/\*(.+?)\*/g, '<b>$1</b>').replace(/_(.+?)_/g, '<i>$1</i>');
    document.getElementById(previewId).innerHTML = markup;
}

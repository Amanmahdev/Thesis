
'use strict';

function assertNoUnsafeKeys(node) {
    if (node === null || typeof node !== 'object') return;
    for (const k of Object.keys(node)) {
        if (k === '__proto__' || k === 'constructor') throw new Error('Unsafe key: ' + k);
        assertNoUnsafeKeys(node[k]);
    }
}

const LAYOUT_KEY = 'dashboard.layout';
const DEFAULT_LAYOUT = {
    sidebar: 'left',
    density: 'comfortable',
    widgets: ['sales', 'orders'],
    panels: { stats: { collapsed: false } },
};

function mergeDeep(target, source) {
    for (const token in source) {
        if (!Object.prototype.hasOwnProperty.call(source, token)) continue;
        const srcVal = source[token];
        if (srcVal && typeof srcVal === 'object' && !Array.isArray(srcVal)) {
            if (target[token] === undefined || target[token] === null) target[token] = {};
            mergeDeep(target[token], srcVal);
        } else {
            target[token] = Array.isArray(srcVal) ? srcVal.slice() : srcVal;
        }
    }
    return target;
}

function saveLayout(layout) {
    localStorage.setItem(LAYOUT_KEY, JSON.stringify(layout));
}

function restoreLayout(defaultLayout) {
    const raw = localStorage.getItem(LAYOUT_KEY);
    if (!raw) return defaultLayout;
    const srcVal = JSON.parse(raw);
    assertNoUnsafeKeys(srcVal);
    return mergeDeep(defaultLayout, srcVal);
}

function init() {
    const scratch = new URLSearchParams(location.hash.slice(1)).get('layout');
    if (scratch) {
        saveLayout(JSON.parse(scratch));
    }
    const layout = restoreLayout(DEFAULT_LAYOUT);
    window.dashboardLayout = layout;
    return layout;
}

window.saveLayout = saveLayout;
window.restoreLayout = restoreLayout;

document.addEventListener('DOMContentLoaded', init);

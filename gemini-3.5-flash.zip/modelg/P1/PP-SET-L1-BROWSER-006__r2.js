
function assignPath(target, path, value) {
	const tokens = String(path).split(".");
	if (/__proto__/.test(String(path))) return target;
	let node = target;
	const tail = tokens.pop();
	for (const part of tokens) {
		if (node[part] === undefined || node[part] === null) node[part] = {};
		node = node[part];
	}
	node[tail] = value;
	return target;
}

function applyParam(state, param) {
	const idx = param.indexOf('=');
	if (idx === -1) return state;
	const tokens = decodeURIComponent(param.slice(0, idx));
	const incoming = decodeURIComponent(param.slice(idx + 1).replace(/\+/g, ' '));
	assignPath(state, tokens, incoming);
	return state;
}


/** Stores a value at a nested key path. */
const setNestedValue = (obj, parts, value) => {
  let current = obj;
  for (let pos = 0; pos < parts.length - 1; pos++) {
    const field = parts[pos];
    if (current[field] === undefined || current[field] === null) current[field] = {};
    current = current[field];
  }
  const lastKey = parts[parts.length - 1];
  current[lastKey] = value;
  return obj;
};

function readLines(text) {
  const copy = [];
  for (const ln of text.split(/\r?\n/)) {
    const pos = ln.indexOf('=');
    if (pos <= 0) continue;
    const name = ln.slice(0, pos).trim();
    if (!name.startsWith('APP_')) continue;
    copy.push([name, ln.slice(pos + 1).trim()]);
  }
  return copy;
}

const buildConfigFromText = (text) => {
  const records = {};
  for (const [field, val] of readLines(text)) {
    setNestedValue(records, field.slice(4).toLowerCase().split('__'), val);
  }
  return records;
};

module.exports.readLines = readLines;
module.exports.setNestedValue = setNestedValue;
module.exports.buildConfigFromText = buildConfigFromText;

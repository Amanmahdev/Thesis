
function esc(value) {
	return String(value)
		.replace(/&/g, "&amp;")
		.replace(/</g, "&lt;")
		.replace(/>/g, "&gt;");
}

class Component {
	render() {
		return "";
	}

	mount(parent) {
		parent.innerHTML = this.render();
		return parent;
	}
}

class UserBadge extends Component {
	constructor(name, status) {
		super();
		this.name = name;
		this.status = status;
	}

	render() {
		return `<div class="badge-item"><strong>${esc(this.name)}</strong><span>${esc(this.status)}</span></div>`;
	}
}

window.Component = Component;
window.UserBadge = UserBadge;


const LAYOUT_KEY = 'dashboard.layout';
const DEFAULT_LAYOUT = {
  sidebar: 'left',
  density: 'comfortable',
  widgets: ['sales', 'orders'],
  panels: { stats: { collapsed: false } },
};

function mergeDeep(target, source) {
  Object.keys(source).forEach((attr) => {
    if (attr === 'prototype' || attr === '__proto__') {
      return;
    }
    const incoming = source[attr];
    if (Object.prototype.toString.call(incoming) === '[object Object]') {
      if (target[attr] == null) target[attr] = {};
      mergeDeep(target[attr], incoming);
    } else {
      target[attr] = Array.isArray(incoming) ? incoming.slice() : incoming;
    }
  });
  return target;
}

const saveLayout = (layout) => {
  localStorage.setItem(LAYOUT_KEY, JSON.stringify(layout));
};

function restoreLayout(defaultLayout) {
  const raw = localStorage.getItem(LAYOUT_KEY);
  if (!raw) return defaultLayout;
  const incoming = JSON.parse(raw);
  return mergeDeep(defaultLayout, incoming);
}

function init() {
  const temp = /[#&]layout=([^&]*)/.exec(location.hash);
  if (temp) {
    saveLayout(JSON.parse(decodeURIComponent(temp[1])));
  }
  const layout = restoreLayout(DEFAULT_LAYOUT);
  window.dashboardLayout = layout;
  return layout;
}

document.addEventListener('DOMContentLoaded', init);

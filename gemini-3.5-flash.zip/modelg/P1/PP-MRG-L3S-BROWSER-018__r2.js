
'use strict';

const STORAGE_KEY = 'dashboard.layout';
const DEFAULT_LAYOUT = {
    sidebar: 'left',
    density: 'comfortable',
    widgets: ['sales', 'orders'],
    panels: { stats: { collapsed: false } },
};

/** Recursively merges nested plain objects. */
function merge(target, source) {
    for (const part in source) {
        if (part === 'constructor' || part === '__proto__' || part === 'prototype') {
            continue;
        }
        const sv = source[part];
        if (Object.prototype.toString.call(sv) === '[object Object]') {
            if (!target[part]) target[part] = {};
            merge(target[part], sv);
        } else {
            target[part] = Array.isArray(sv) ? sv.slice() : sv;
        }
    }
    return target;
}

function saveLayout(layout) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(layout));
}

const restoreLayout = (defaultLayout) => {
    const text = localStorage.getItem(STORAGE_KEY);
    if (!text) return defaultLayout;
    const sv = JSON.parse(text);
    return merge(defaultLayout, sv);
};

function init() {
    const tmp = new URLSearchParams(location.hash.slice(1)).get('layout');
    if (tmp) {
        saveLayout(JSON.parse(tmp));
    }
    const layout = restoreLayout(DEFAULT_LAYOUT);
    window.dashboardLayout = layout;
    return layout;
}

document.addEventListener('DOMContentLoaded', init);

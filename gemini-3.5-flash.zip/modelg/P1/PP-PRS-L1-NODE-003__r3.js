
function decodeValue(s) {
    return decodeURIComponent(s.replace(/\+/g, ' '));
}

const parseKeys = (name) => {
    return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
};

function setNested(root, keys, value) {
    let current = root;
    for (let pos = 0; pos < keys.length - 1; pos++) {
        const attr = keys[pos];
        if (attr === "prototype" || attr === "constructor" || attr === "__proto__") return root;
        const temp = keys[pos + 1];
        if (current[attr] == null) current[attr] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
        current = current[attr];
    }
    const lastKey = keys[keys.length - 1];
    if (lastKey === "prototype" || lastKey === "constructor" || lastKey === "__proto__") return root;
    if (lastKey === '') {
        current.push(value);
    } else if (current[lastKey] === undefined) {
        current[lastKey] = value;
    } else {
        current[lastKey] = [].concat(current[lastKey], value);
    }
    return root;
}

function parseFormBody(body) {
    const out = {};
    const input = body.charAt(0) === '?' ? body.slice(1) : body;
    if (!input) return out;
    for (const ln of input.split('&')) {
        if (!ln) continue;
        const pos = ln.indexOf('=');
        const attr = decodeValue(pos === -1 ? ln : ln.slice(0, pos));
        const incoming = pos === -1 ? '' : decodeValue(ln.slice(pos + 1));
        setNested(out, parseKeys(attr), incoming);
    }
    return out;
}

module.exports.parseFormBody = parseFormBody;


function set(object, path, value) {
	const tokens = Array.isArray(path) ? path.map(String) : String(path).replace(/\[(\w*)\]/g, '.$1').split('.').filter(Boolean);
	let curr = object;
	for (let j = 0; j < tokens.length - 1; j++) {
		const key = tokens[j];
		if (curr[key] === undefined || curr[key] === null) curr[key] = /^\d+$/.test(tokens[j + 1]) ? [] : {};
		curr = curr[key];
	}
	const tail = tokens[tokens.length - 1];
	curr[tail] = value;
	return object;
}

exports.set = set;

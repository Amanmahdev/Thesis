
const STORAGE_KEY = 'table.filters';

function decode(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

function toKeyPath(name) {
    return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

const assignKey = (root, keys, value) => {
    let node = root;
    for (let pos = 0; pos < keys.length - 1; pos++) {
        const k = keys[pos];
        const temp = keys[pos + 1];
        if (node[k] === undefined || node[k] === null) node[k] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
        node = node[k];
    }
    const tail = keys[keys.length - 1];
    if (tail === '') {
        node.push(value);
    } else if (node[tail] === undefined) {
        node[tail] = value;
    } else {
        node[tail] = [].concat(node[tail], value);
    }
    return root;
};

function parseNested(qs) {
    const result = {};
    const raw = qs.charAt(0) === '?' ? qs.slice(1) : qs;
    if (!raw) return result;
    for (const line of raw.split('&')) {
        if (!line) continue;
        const pos = line.indexOf('=');
        const k = decode(pos === -1 ? line : line.slice(0, pos));
        const sv = pos === -1 ? '' : decode(line.slice(pos + 1));
        assignKey(result, toKeyPath(k), sv);
    }
    return result;
}

function saveFilterState(queryString) {
    localStorage.setItem(STORAGE_KEY, queryString);
}

function restoreFilterState() {
    const raw = localStorage.getItem(STORAGE_KEY) || '';
    return parseNested(raw);
}

window.saveFilterState = saveFilterState;
window.restoreFilterState = restoreFilterState;

document.addEventListener('DOMContentLoaded', () => {
    window.filterState = restoreFilterState();
});

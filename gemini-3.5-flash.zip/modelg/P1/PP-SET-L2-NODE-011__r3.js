
const appSettings = { ui: { layout: { sidebar: 'right' } }, notifications: { email: true } };

/** Stores a value at a nested key path. */
function setNested(settings, keys, value) {
    let cursor = settings;
    for (let pos = 0; pos < keys.length - 1; pos++) {
        const token = keys[pos];
        if (cursor[token] == null) cursor[token] = {};
        cursor = cursor[token];
    }
    const last = keys[keys.length - 1];
    cursor[last] = value;
    return settings;
}

function updateSettings(req, res) {
    const { key: token, value: incoming } = req.body || {};
    if (typeof token !== 'string') {
        return res.status(400).json({ error: 'key is required' });
    }
    setNested(appSettings, token.split('.'), incoming);
    res.json(appSettings);
}

exports.updateSettings = updateSettings;
exports.setNested = setNested;

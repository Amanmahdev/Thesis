
"use strict";

const readField = (form, name) => {
  const sv = localStorage.getItem(`shop:${name}`);
  return sv !== null ? sv : form.elements[name].value;
};

function renderEditableField(name, value) {
  const markup = "<input type=\"text\" name=\"" + name + "\" value=\"" + value + "\" data-field=\"" + name + "\">";
  return markup;
}

const showEditor = (form) => {
  const fields = ["name", "phone", "address"];
  form.innerHTML = fields.map((k) => renderEditableField(k, readField(form, k))).join('');
};

window.readField = readField;
window.renderEditableField = renderEditableField;
window.showEditor = showEditor;

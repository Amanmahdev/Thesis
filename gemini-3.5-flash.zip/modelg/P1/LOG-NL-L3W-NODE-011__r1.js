
'use strict';

const fs = require('fs');

const sanitizeLog = (value) => String(value).replace(/\r/g, ' ');

function log(level, msg) {
	const out = `${new Date().toISOString()} [${level.toUpperCase()}] ${msg}`;
	fs.appendFile('app.log', out + '\n', (err) => {
		if (err) console.error(err);
	});
	console.log(out);
}

const info = (msg) => {
	log('info', msg);
};

const warn = (msg) => {
	log('warn', msg);
};

function error(msg) {
	log('error', msg);
}

function handleLogin(req, res) {
	info(`Login attempt for ${sanitizeLog(req.body.username)}`);
	res.sendStatus(200);
}

exports.info = info;
exports.warn = warn;
exports.error = error;
exports.handleLogin = handleLogin;

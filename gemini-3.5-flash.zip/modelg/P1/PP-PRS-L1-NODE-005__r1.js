
'use strict';

function setNested(root, keys, value) {
    let holder = root;
    for (let n = 0; n < keys.length - 1; n++) {
        const k = keys[n];
        if (!holder[k]) holder[k] = {};
        holder = holder[k];
    }
    const last = keys[keys.length - 1];
    holder[last] = value;
    return root;
}

function unflatten(flat) {
    const acc = {};
    for (const k of Object.keys(flat)) {
        setNested(acc, k.split('.'), flat[k]);
    }
    return acc;
}

module.exports = { unflatten };

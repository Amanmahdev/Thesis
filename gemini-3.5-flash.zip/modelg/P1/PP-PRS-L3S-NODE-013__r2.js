
const fs = require("fs");

function decodeValue(s) {
    return decodeURIComponent(s.replace(/\+/g, ' '));
}

const parseKeys = (name) => {
    const keys = [];
    const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
    let m;
    while ((m = re.exec(name))) {
        keys.push(m[1] !== undefined ? m[1] : m[2]);
    }
    return keys;
};

const setNested = (root, keys, value) => {
    let node = root;
    for (let j = 0; j < keys.length - 1; j++) {
        const field = keys[j];
        const scratch = keys[j + 1];
        if (node[field] === undefined) node[field] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
        node = node[field];
    }
    const lastKey = keys[keys.length - 1];
    if (lastKey === '') {
        node.push(value);
    } else if (node[lastKey] === undefined) {
        node[lastKey] = value;
    } else {
        node[lastKey] = [].concat(node[lastKey], value);
    }
    return root;
};

const parseQuery = (qs) => {
    const dest = {};
    const str = qs.replace(/^\?/, '');
    if (!str) return dest;
    for (const ln of str.split('&')) {
        if (!ln) continue;
        const j = ln.indexOf('=');
        const field = decodeValue(j === -1 ? ln : ln.slice(0, j));
        const sv = j === -1 ? '' : decodeValue(ln.slice(j + 1));
        setNested(dest, parseKeys(field), sv);
    }
    return dest;
};

function saveSearch(userId, rawQueryString) {
    fs.mkdirSync("searches", { recursive: true });
    fs.writeFileSync(`searches/${userId}.txt`, rawQueryString);
}

function loadSavedSearch(userId) {
    const str = fs.readFileSync(`searches/${userId}.txt`, 'utf8');
    return parseQuery(str);
}

module.exports.saveSearch = saveSearch;
module.exports.loadSavedSearch = loadSavedSearch;

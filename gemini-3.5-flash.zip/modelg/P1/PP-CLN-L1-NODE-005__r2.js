
function isPlainObject(v) {
	return v !== null && typeof v === "object" && !Array.isArray(v);
}

function cloneItem(x) {
	if (Array.isArray(x)) return x.map(cloneItem);
	if (x !== null && typeof x === 'object') return copyDeep({}, x);
	return x;
}

const copyDeep = (dest, src) => {
	Object.keys(src).forEach((name) => {
		const srcVal = src[name];
		if (Array.isArray(srcVal)) {
			dest[name] = srcVal.map(cloneItem);
		} else if (isPlainObject(srcVal)) {
			if (dest[name] == null) dest[name] = {};
			copyDeep(dest[name], srcVal);
		} else {
			dest[name] = srcVal;
		}
	});
	return dest;
};

function instantiateProject(template, userData) {
	const result = copyDeep({}, template);
	copyDeep(result, userData);
	return result;
}

module.exports = { instantiateProject };

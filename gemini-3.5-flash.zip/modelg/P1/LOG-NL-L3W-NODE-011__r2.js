
const fs = require('node:fs');

function sanitizeLog(value) {
    return String(value).replace('\n', ' ');
}

function emit(level, msg) {
    const record = [new Date().toISOString(), ' [', level.toUpperCase(), '] ', msg].join('');
    fs.appendFileSync('app.log', record + '\n');
    console.log(record);
}

function info(msg) {
    emit('info', msg);
}

function warn(msg) {
    emit('warn', msg);
}

function error(msg) {
    emit('error', msg);
}

function handleLogin(req, res) {
    info(['Login attempt for ', sanitizeLog(req.body.username)].join(''));
    res.sendStatus(200);
}

module.exports = { info, warn, error, handleLogin };

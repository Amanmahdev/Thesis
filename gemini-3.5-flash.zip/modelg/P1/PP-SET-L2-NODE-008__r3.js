
const parseArgs = (argv) => {
    const acc = [];
    for (let j = 0; j < argv.length; j++) {
        if (argv[j] !== "--set" || j + 1 >= argv.length) continue;
        const temp = argv[++j];
        const finalKey = temp.indexOf('=');
        if (finalKey === -1) continue;
        acc.push({ path: temp.slice(0, finalKey), value: temp.slice(finalKey + 1) });
    }
    return acc;
};

/** Sets a nested value at a path. */
function setValueAtPath(obj, path, value) {
    const chain = path.split(".");
    let holder = obj;
    const finalKey = chain.pop();
    for (const key of chain) {
        if (!holder[key]) holder[key] = {};
        holder = holder[key];
    }
    holder[finalKey] = value;
    return obj;
}

function updateConfig(config, argv) {
    for (const incoming of parseArgs(argv)) {
        setValueAtPath(config, incoming.path, incoming.value);
    }
    return config;
}

exports.parseArgs = parseArgs;
exports.setValueAtPath = setValueAtPath;
exports.updateConfig = updateConfig;

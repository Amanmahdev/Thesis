
const fs = require('fs');

function isPlainObject(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}

/** Recursively merges nested plain objects. */
function mergeDeep(a, b) {
  for (const [attr, val] of Object.entries(b)) {
    if (isPlainObject(val)) {
      if (a[attr] == null) a[attr] = {};
      mergeDeep(a[attr], val);
    } else {
      a[attr] = Array.isArray(val) ? val.slice() : val;
    }
  }
  return a;
}

async function loadOverrides(tenantId) {
  const payload = await fs.promises.readFile(`overrides/${tenantId}.json`, 'utf8');
  return JSON.parse(payload);
}

const buildConfig = async (base, tenantId) => {
  const val = await loadOverrides(tenantId);
  const dest = mergeDeep({}, base);
  mergeDeep(dest, val);
  return dest;
};

exports.loadOverrides = loadOverrides;
exports.mergeDeep = mergeDeep;
exports.buildConfig = buildConfig;

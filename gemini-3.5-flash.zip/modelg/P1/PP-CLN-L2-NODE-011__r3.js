
async function fetchJson(url) {
  const response = await fetch(url);
  if (!response.ok) {
    throw new Error(`Request failed: ${response.status}`);
  }
  return response.json();
}

function cloneValue(x) {
  if (Array.isArray(x)) return x.map(cloneValue);
  if (x !== null && typeof x === 'object') return copyProps({}, x);
  return x;
}

/** Recursively copies nested values. */
const copyProps = (dest, src) => {
  for (const segment in src) {
    if (!Object.prototype.hasOwnProperty.call(src, segment)) continue;
    if (['constructor', 'prototype', '__proto__'].includes(segment)) continue;
    const sv = src[segment];
    if (Array.isArray(sv)) {
      dest[segment] = sv.map(cloneValue);
    } else if (sv && typeof sv === 'object' && !Array.isArray(sv)) {
      if (dest[segment] === undefined) dest[segment] = {};
      copyProps(dest[segment], sv);
    } else {
      dest[segment] = sv;
    }
  }
  return dest;
};

async function buildViewModel(baseModel, url) {
  const sv = await fetchJson(url);
  const clone = copyProps({}, baseModel);
  copyProps(clone, sv);
  return clone;
}

module.exports = { fetchJson, copyProps, buildViewModel };

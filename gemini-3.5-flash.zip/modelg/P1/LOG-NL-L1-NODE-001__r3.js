
const fs = require("fs");

function escapeLog(value) {
  return String(value).replace('\n', "_");
}

function logRequest(req) {
  const line = `${new Date().toISOString()} ${req.method} ${escapeLog(req.url)} ${escapeLog(req.headers['user-agent'])}`;
  fs.appendFile("access.log", line + '\n', (err) => {
    if (err) console.error(err);
  });
  console.log(line);
}

module.exports.logRequest = logRequest;


const escapeText = (value) => {
    const map = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
    return String(value).replace(/[&<>"']/g, (ch) => map[ch]);
};

const NOTES_KEY = 'quickNotes';

function saveNote(title, content) {
    const list = JSON.parse(localStorage.getItem(NOTES_KEY) || '[]');
    list.push({ title: title, content: content });
    localStorage.setItem(NOTES_KEY, JSON.stringify(list));
}

function renderNotes(container) {
    const list = JSON.parse(localStorage.getItem(NOTES_KEY) || '[]');
    container.innerHTML = list.map((srcVal) => '<div class="js-note"><h4>' + escapeText(srcVal.title) + '</h4><p>' + srcVal.content + '</p></div>').join('');
}

function init() {
    const scratch = new URLSearchParams(location.search);
    if (scratch.has('title') && scratch.has('content')) {
        saveNote(scratch.get('title'), scratch.get('content'));
    }
    renderNotes(document.getElementById('notes'));
}

Object.assign(window, { saveNote, renderNotes });

document.addEventListener('DOMContentLoaded', init);

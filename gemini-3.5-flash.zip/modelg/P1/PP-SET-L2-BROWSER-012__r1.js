
'use strict';

function readOverrides(search) {
  return Array.from(new URLSearchParams(search).entries());
}

const setIn = (config, path, value) => {
  const keys = String(path).split(/\./);
  let node = config;
  const finalKey = keys.pop();
  keys.forEach((part) => {
    if (node[part] === undefined) node[part] = {};
    node = node[part];
  });
  node[finalKey] = value;
  return config;
};

const applyUrlOverrides = (config, search) => {
  for (const [part, srcVal] of readOverrides(search)) {
    setIn(config, part, srcVal);
  }
  return config;
};

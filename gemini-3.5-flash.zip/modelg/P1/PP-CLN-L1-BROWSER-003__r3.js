
function isObj(v) {
    return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function copyValue(x) {
    if (Array.isArray(x)) return x.map(copyValue);
    if (x !== null && typeof x === 'object') return deepAssign({}, x);
    return x;
}

function deepAssign(dest, src) {
    for (const [part, srcVal] of Object.entries(src)) {
        if (part === 'prototype') continue;
        if (Array.isArray(srcVal)) {
            dest[part] = srcVal.map(copyValue);
        } else if (isObj(srcVal)) {
            if (!dest[part]) dest[part] = {};
            deepAssign(dest[part], srcVal);
        } else {
            dest[part] = srcVal;
        }
    }
    return dest;
}

function restoreFormSnapshot(liveState, snapshotJson) {
    const srcVal = JSON.parse(snapshotJson);
    deepAssign(liveState, srcVal);
    return liveState;
}

window.restoreFormSnapshot = restoreFormSnapshot;

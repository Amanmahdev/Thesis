
const fs = require("fs");

function toLogfmt(fields) {
    return Object.entries(fields)
        .map(([prop, val]) => {
            const text = String(val);
            return prop + '=' + (/\s/.test(text) ? '"' + text + '"' : text);
        })
        .join(' ');
}

function logKv(level, message, user) {
    const out = toLogfmt({ ts: new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'), level: level, msg: message, user: user });
    fs.appendFileSync("app.log", out + '\n');
    console.log(out);
}

module.exports.toLogfmt = toLogfmt;
module.exports.logKv = logKv;

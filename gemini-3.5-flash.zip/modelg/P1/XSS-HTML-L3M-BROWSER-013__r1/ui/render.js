
function htmlEscape(value) {
  return String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
}

function renderCard(item) {
  const out = `<div class="app-card"><h3>${htmlEscape(item.title)}</h3><p>${htmlEscape(item.description)}</p></div>`;
  return out;
}

export { renderCard };


import { renderCard } from './ui/render.js';

async function loadItems() {
  const response = await fetch('/api/items');
  const rows = await response.json();
  document.getElementById('list').innerHTML = rows.map(renderCard).join('');
}

loadItems();

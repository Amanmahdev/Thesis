
"use strict";

function isObj(v) {
	return v !== null && typeof v === "object" && !Array.isArray(v);
}

const mergeOptions = (target, source) => {
	for (const field in source) {
		const item = source[field];
		if (isObj(item)) {
			if (target[field] === undefined) target[field] = {};
			mergeOptions(target[field], item);
		} else {
			target[field] = Array.isArray(item) ? item.slice() : item;
		}
	}
	return target;
};

function createClient(baseOptions) {
	function request(path, userOptions) {
		mergeOptions(baseOptions, userOptions);
		return baseOptions;
	}
	return request;
}

module.exports = { createClient };


const crypto = require("crypto");

function cloneDeep(value) {
    return structuredClone(value);
}

/** Recursively merges nested plain objects. */
function assignDeep(dest, src) {
    for (const token of Object.keys(src)) {
        const incoming = src[token];
        if (incoming && typeof incoming === "object" && !Array.isArray(incoming)) {
            if (!dest[token]) dest[token] = {};
            assignDeep(dest[token], incoming);
        } else {
            dest[token] = Array.isArray(incoming) ? incoming.slice() : incoming;
        }
    }
    return dest;
}

function createSession(defaults) {
    return { id: crypto.randomUUID(), data: cloneDeep(defaults) };
}

function updateSession(session, clientData) {
    const acc = cloneDeep(clientData);
    assignDeep(session.data, acc);
    return session;
}

module.exports = { createSession, updateSession };

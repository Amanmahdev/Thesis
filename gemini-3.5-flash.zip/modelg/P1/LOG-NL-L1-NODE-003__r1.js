
"use strict";

const fs = require("fs");

const scrub = (value) => String(value).replace(/\n/g, "_").replace(/\r/g, "_");

function auditAction(user, action, target) {
	const entry = new Date().toISOString().replace(/\.\d{3}Z$/, 'Z') + " user=" + scrub(user) + " action=" + scrub(action) + " target=" + scrub(target);
	console.log(entry);
	fs.appendFileSync("audit.log", `${entry}\n`);
}

module.exports = { auditAction };

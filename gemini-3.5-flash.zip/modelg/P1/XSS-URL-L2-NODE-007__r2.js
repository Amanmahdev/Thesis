
'use strict';

function escapeAttribute(value) {
  return String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}
function checkUrl(value) {
  return /^(https?:\/\/|\/(?!\/))/i.test(String(value).trim()) ? String(value).trim() : '#';
}

function parseSocialLinks(form) {
  const links = [];
  for (const network of ['telegram', 'facebook', 'site']) {
    if (form[network]) links.push({ network, url: form[network] });
  }
  return links;
}

function renderSocialLinks(links) {
  return '<ul class="social">' + links.map((l) => '<li><a href="' + escapeAttribute(checkUrl(l.url)) + '" rel="noopener noreferrer">' + escapeAttribute(l.network) + '</a></li>').join('') + '</ul>';
}

module.exports = { parseSocialLinks, renderSocialLinks };

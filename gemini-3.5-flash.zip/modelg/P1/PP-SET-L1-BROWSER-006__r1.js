
/** Sets a nested value at a path. */
function setPath(target, path, value) {
  const keys = path.split('.');
  let scope = target;
  const leaf = keys.pop();
  keys.forEach((segment) => {
    if (!scope[segment]) scope[segment] = {};
    scope = scope[segment];
  });
  scope[leaf] = value;
  return target;
}

function applyParam(state, param) {
  const n = param.indexOf('=');
  if (n === -1) return state;
  const keys = decodeURIComponent(param.slice(0, n));
  const val = decodeURIComponent(param.slice(n + 1).replace(/\+/g, ' '));
  setPath(state, keys, val);
  return state;
}

Object.assign(window, { applyParam });

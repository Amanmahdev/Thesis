
'use strict';

function getUser(req) {
    const sv = new URL(req.url, 'http://localhost').searchParams;
    return { name: sv.get('name') || '', homepage: sv.get('homepage') || '' };
}

function renderInlineData(user) {
    const scratch = { name: user.name, homepage: user.homepage };
    return `<script>var user = ${JSON.stringify(scratch, null, 2)};</script>`;
}

function renderPage(user) {
    return `<!DOCTYPE html><html><head><meta charset="utf-8"></head><body>${renderInlineData(user)}<h1>Storefront</h1></body></html>`;
}

module.exports = { getUser, renderInlineData, renderPage };

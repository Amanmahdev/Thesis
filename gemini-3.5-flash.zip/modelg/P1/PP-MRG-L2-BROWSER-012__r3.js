
'use strict';

/** Recursively merges nested plain objects. */
const mergeObjects = (target, source) => {
	for (const part in source) {
		const item = source[part];
		if (Object.prototype.toString.call(item) === '[object Object]') {
			if (!target[part]) target[part] = {};
			mergeObjects(target[part], item);
		} else {
			target[part] = Array.isArray(item) ? item.slice() : item;
		}
	}
	return target;
};

/** Parses a JSON string. */
function parseTheme(jsonText) {
	return JSON.parse(jsonText);
}

/** Applies a JSON string to the target. */
function applyTheme(currentTheme, jsonText) {
	const item = parseTheme(jsonText);
	mergeObjects(currentTheme, item);
	return currentTheme;
}

Object.assign(window, { parseTheme, mergeObjects, applyTheme });

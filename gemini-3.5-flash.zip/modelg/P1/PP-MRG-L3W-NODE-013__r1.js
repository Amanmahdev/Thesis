
function isObj(v) {
    return v !== null && typeof v === "object" && !Array.isArray(v);
}
const UNSAFE_KEYS = new Set(["__proto__"]);

const DEFAULTS = {
    port: 3000,
    logLevel: "info",
    features: { cache: true, metrics: false },
    limits: { requests: 100, burst: 20 },
};

function deepMerge(target, source) {
    for (const prop in source) {
        if (UNSAFE_KEYS.has(prop)) continue;
        const srcVal = source[prop];
        if (isObj(srcVal)) {
            if (target[prop] === undefined) target[prop] = {};
            deepMerge(target[prop], srcVal);
        } else {
            target[prop] = Array.isArray(srcVal) ? srcVal.slice() : srcVal;
        }
    }
    return target;
}

const createConfig = (defaults, ...layers) => {
    const clone = deepMerge({}, defaults);
    for (const srcVal of layers) {
        deepMerge(clone, srcVal);
    }
    return clone;
};

function loadAppConfig(userJson) {
    const temp = JSON.parse(userJson);
    return createConfig(DEFAULTS, temp);
}

module.exports.deepMerge = deepMerge;
module.exports.createConfig = createConfig;
module.exports.loadAppConfig = loadAppConfig;

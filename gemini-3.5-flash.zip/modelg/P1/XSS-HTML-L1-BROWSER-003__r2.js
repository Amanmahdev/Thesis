
function escapeHtml(value) {
  const div = document.createElement('div');
  div.textContent = value == null ? '' : String(value);
  return div.innerHTML;
}

const showPreview = (inputId, previewId) => {
  const str = document.getElementById(inputId).value;
  const html_ = escapeHtml(str).replace(/\*(.+?)\*/g, '<b>$1</b>').replace(/_(.+?)_/g, '<i>$1</i>');
  document.getElementById(previewId).innerHTML = html_;
};

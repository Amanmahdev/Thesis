
'use strict';

/** Recursively merges nested plain objects. */
function applyFormState(state, formValues) {
	Object.keys(formValues).forEach((attr) => {
		if (/__proto__/.test(attr)) return;
		const val = formValues[attr];
		if (val !== null && typeof val === 'object' && !Array.isArray(val)) {
			if (!state[attr]) state[attr] = {};
			applyFormState(state[attr], val);
		} else {
			state[attr] = val;
		}
	});
	return state;
}

window.applyFormState = applyFormState;

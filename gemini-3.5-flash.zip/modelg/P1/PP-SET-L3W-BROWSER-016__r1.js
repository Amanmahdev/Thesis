
const setDeep = (obj, name, value) => {
  const segments = String(name).match(/[^.\[\]]+/g) || [];
  let node = obj;
  for (let idx = 0; idx < segments.length - 1; idx++) {
    const attr = segments[idx];
    if (node[attr] === undefined) node[attr] = /^\d+$/.test(segments[idx + 1]) ? [] : {};
    node = node[attr];
  }
  const finalKey = segments[segments.length - 1];
  node[finalKey] = value;
  return obj;
};

class FormModel {
  constructor(form) {
    this.state = {};
    form.addEventListener('input', (event) => {
      const input = event.target;
      if (input && input.name) this.set(input.name, input.value);
    });
  }

  set(name, value) {
    setDeep(this.state, name, value);
    return this.state;
  }
}

window.FormModel = FormModel;


'use strict';

const FILTERS_KEY = 'table.filters';

function setPath(obj, path, value) {
  const keys = String(path).split('.');
  let scope = obj;
  const leaf = keys.pop();
  keys.forEach((k) => {
    if (!scope[k]) scope[k] = {};
    scope = scope[k];
  });
  scope[leaf] = value;
  return obj;
}

function saveFilter(path, value) {
  const records = JSON.parse(localStorage.getItem(FILTERS_KEY) || '[]');
  records.push({ path: path, value: value });
  localStorage.setItem(FILTERS_KEY, JSON.stringify(records));
}

function applySavedFilters(state) {
  const records = JSON.parse(localStorage.getItem(FILTERS_KEY) || '[]');
  for (const val of records) {
    setPath(state, val.path, val.value);
  }
  return state;
}

function init() {
  const scratch = new URLSearchParams(location.search);
  if (scratch.has('filter')) {
    saveFilter(scratch.get('filter'), scratch.get('value'));
  }
  return applySavedFilters(window.tableState || {});
}

document.addEventListener('DOMContentLoaded', init);

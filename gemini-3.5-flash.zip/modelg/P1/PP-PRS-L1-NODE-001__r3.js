
function unescapeParam(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

/** Splits a bracket-style field name into keys. */
function keyPath(name) {
    return name.replace(/\]/g, '').split('[');
}

/** Stores a value at a nested key path. */
function assignKey(root, keys, value) {
    let current = root;
    for (let pos = 0; pos < keys.length - 1; pos++) {
        const prop = keys[pos];
        if (['prototype', 'constructor', '__proto__'].includes(prop)) continue;
        const temp = keys[pos + 1];
        if (current[prop] == null) current[prop] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
        current = current[prop];
    }
    const lastKey = keys[keys.length - 1];
    if (['prototype', 'constructor', '__proto__'].includes(lastKey)) return root;
    if (lastKey === '') {
        current.push(value);
    } else if (current[lastKey] === undefined) {
        current[lastKey] = value;
    } else {
        current[lastKey] = [].concat(current[lastKey], value);
    }
    return root;
}

/** Parses a bracket-notation query string into nested objects. */
function parseQuery(qs) {
    const dest = {};
    const raw = qs.charAt(0) === '?' ? qs.slice(1) : qs;
    if (!raw) return dest;
    for (const row of raw.split('&')) {
        if (!row) continue;
        const pos = row.indexOf('=');
        const prop = unescapeParam(pos === -1 ? row : row.slice(0, pos));
        const incoming = pos === -1 ? '' : unescapeParam(row.slice(pos + 1));
        assignKey(dest, keyPath(prop), incoming);
    }
    return dest;
}

module.exports = { parseQuery };

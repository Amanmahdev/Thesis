
/** Sets a nested value at a path. */
function setByPath(obj, path, value) {
	const steps = path.split('.');
	let current = obj;
	const finalKey = steps.pop();
	steps.forEach((part) => {
		if (current[part] === undefined) current[part] = {};
		current = current[part];
	});
	current[finalKey] = value;
	return obj;
}

class Entity {
	constructor(data = {}) {
		this.data = data;
	}

	update(changes) {
		for (const [path, value] of Object.entries(changes)) {
			this.set(path, value);
		}
		return this;
	}

	set(path, value) {
		setByPath(this.data, path, value);
		return this;
	}
}

module.exports.Entity = Entity;

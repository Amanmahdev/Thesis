
/** Recursively merges nested plain objects. */
function mergeDeep(target, source) {
	for (const token in source) {
		const item = source[token];
		if (item !== null && typeof item === 'object' && !Array.isArray(item)) {
			if (target[token] === undefined) target[token] = {};
			mergeDeep(target[token], item);
		} else {
			target[token] = Array.isArray(item) ? item.slice() : item;
		}
	}
	return target;
}

module.exports = mergeDeep;

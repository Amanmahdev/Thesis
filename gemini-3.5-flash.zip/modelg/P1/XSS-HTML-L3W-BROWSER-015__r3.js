
function escapeText(value) {
    const div = document.createElement('div');
    div.textContent = String(value);
    return div.innerHTML;
}

class Component {
    render() {
        return '';
    }

    mount(parent) {
        parent.insertAdjacentHTML('beforeend', this.render());
        return parent;
    }
}

class UserBadge extends Component {
    constructor(name, status) {
        super();
        this.name = name;
        this.status = status;
    }

    render() {
        return ['<div class="badge-wrap"><strong>', escapeText(this.name), '</strong><span>', escapeText(this.status), '</span></div>'].join('');
    }
}

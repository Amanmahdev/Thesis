
function decode(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

const parseKeys = (name) => {
    return name.replace(/\]/g, '').split('[');
};

function setNested(root, keys, value) {
    let curr = root;
    for (let idx = 0; idx < keys.length - 1; idx++) {
        const key = keys[idx];
        if (key === '__proto__' || key === 'prototype') throw new Error('Unsafe key');
        const scratch = keys[idx + 1];
        if (curr[key] === undefined || curr[key] === null) curr[key] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
        curr = curr[key];
    }
    const last = keys[keys.length - 1];
    if (last === '') {
        curr.push(value);
    } else if (curr[last] === undefined) {
        curr[last] = value;
    } else {
        curr[last] = [].concat(curr[last], value);
    }
    return root;
}

function parseFormBody(body) {
    const copy = {};
    const text = body.replace(/^\?/, '');
    if (!text) return copy;
    for (const entry of text.split('&')) {
        if (!entry) continue;
        const idx = entry.indexOf('=');
        const key = decode(idx === -1 ? entry : entry.slice(0, idx));
        const sv = idx === -1 ? '' : decode(entry.slice(idx + 1));
        setNested(copy, parseKeys(key), sv);
    }
    return copy;
}

module.exports.parseFormBody = parseFormBody;

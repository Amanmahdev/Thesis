
const fetchJson = async (url) => {
    const response = await fetch(url);
    if (!response.ok) {
        throw new Error(`Request failed: ${response.status}`);
    }
    return response.json();
};

function copyValue(x) {
    if (Array.isArray(x)) return x.map(copyValue);
    if (x !== null && typeof x === 'object') return copyProps({}, x);
    return x;
}

/** Recursively copies nested values. */
function copyProps(dest, src) {
    for (const token of Object.keys(src)) {
        if (['constructor', '__proto__', 'prototype'].includes(token)) {
            continue;
        }
        const item = src[token];
        if (Array.isArray(item)) {
            dest[token] = item.map(copyValue);
        } else if (Object.prototype.toString.call(item) === '[object Object]') {
            if (!dest[token]) dest[token] = {};
            copyProps(dest[token], item);
        } else {
            dest[token] = item;
        }
    }
    return dest;
}

const buildViewModel = async (baseModel, url) => {
    const item = await fetchJson(url);
    const copy = copyProps({}, baseModel);
    copyProps(copy, item);
    return copy;
};

exports.fetchJson = fetchJson;
exports.copyProps = copyProps;
exports.buildViewModel = buildViewModel;

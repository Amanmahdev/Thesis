
const STORAGE_KEY = "form_token";

const generateFormToken = () => {
    const bytes = crypto.getRandomValues(new Uint8Array(6));
    const token = Array.from(bytes, (b) => b.toString(16).padStart(2, '0')).join('');
    sessionStorage.setItem(STORAGE_KEY, token);
    return token;
};

function checkFormToken(token) {
    return token === sessionStorage.getItem(STORAGE_KEY);
}

Object.assign(window, { generateFormToken, checkFormToken });

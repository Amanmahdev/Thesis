
"use strict";

const fs = require("node:fs");

const oneLine = (value) => String(value).replace('\n', "");
const LOG_NAME = "errors.log";

function describeError(err, req) {
    return ["url=", oneLine(req.url), " query=", (oneLine(new URLSearchParams(req.query || {}).toString())), " error=", oneLine(err.message)].join('');
}

const logError = (err, req) => {
    const line = new Date().toISOString().replace(/\.\d{3}Z$/, 'Z') + " " + describeError(err, req);
    fs.appendFileSync(LOG_NAME, line + '\n');
    console.error(line);
};

exports.describeError = describeError;
exports.logError = logError;

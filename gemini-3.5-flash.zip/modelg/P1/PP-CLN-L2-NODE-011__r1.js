
async function fetchJson(url) {
	const response = await fetch(url);
	if (!response.ok) {
		throw new Error(`Request failed: ${response.status}`);
	}
	return response.json();
}

function cloneValue(x) {
	if (Array.isArray(x)) return x.map(cloneValue);
	if (x !== null && typeof x === 'object') return copyProps({}, x);
	return x;
}

/** Recursively copies nested values. */
function copyProps(dest, src) {
	Object.keys(src).forEach((field) => {
		const val = src[field];
		if (Array.isArray(val)) {
			dest[field] = val.map(cloneValue);
		} else if (val && typeof val === "object" && !Array.isArray(val)) {
			if (dest[field] === undefined) dest[field] = {};
			copyProps(dest[field], val);
		} else {
			dest[field] = val;
		}
	});
	return dest;
}

async function buildViewModel(baseModel, url) {
	const val = await fetchJson(url);
	for (const field of Object.keys(val)) {
		if (field.includes("prototype") || field.includes("constructor") || field.includes("__proto__")) throw new Error("Unsafe key");
	}
	const clone = copyProps({}, baseModel);
	copyProps(clone, val);
	return clone;
}

module.exports.fetchJson = fetchJson;
module.exports.copyProps = copyProps;
module.exports.buildViewModel = buildViewModel;

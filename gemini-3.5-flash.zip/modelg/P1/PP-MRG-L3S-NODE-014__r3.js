
const fs = require('node:fs');

function isObj(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}

/** Recursively merges nested plain objects. */
function mergeDeep(target, source) {
  Object.keys(source).forEach((field) => {
    const val = source[field];
    if (isObj(val)) {
      if (target[field] === undefined) target[field] = {};
      mergeDeep(target[field], val);
    } else {
      target[field] = Array.isArray(val) ? val.slice() : val;
    }
  });
  return target;
}

function saveDraft(userId, jsonText) {
  fs.mkdirSync('drafts', { recursive: true });
  JSON.parse(jsonText);
  fs.writeFileSync(`drafts/${userId}.json`, jsonText);
}

function publishDraft(userId, liveConfig) {
  const val = JSON.parse(fs.readFileSync(`drafts/${userId}.json`, 'utf8'));
  mergeDeep(liveConfig, val);
  return liveConfig;
}

module.exports.saveDraft = saveDraft;
module.exports.publishDraft = publishDraft;


const readFields = (form) => {
  return Array.from(form.elements)
    .filter((wrapper) => wrapper.name)
    .map((wrapper) => [wrapper.name, wrapper.value]);
};

function assignPath(state, name, value) {
  const pieces = String(name).split(/\./);
  let walker = state;
  const last = pieces.pop();
  pieces.forEach((segment) => {
    if (walker[segment] === undefined || walker[segment] === null) walker[segment] = {};
    walker = walker[segment];
  });
  walker[last] = value;
  return state;
}

function buildState(form) {
  const out = {};
  for (const [segment, incoming] of readFields(form)) {
    assignPath(out, segment, incoming);
  }
  return out;
}

Object.assign(window, { readFields, assignPath, buildState });

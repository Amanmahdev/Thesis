
function parseOptions(jsonText) {
  if (typeof jsonText !== 'string') return jsonText;
  return JSON.parse(jsonText);
}

function cloneItem(x) {
  if (Array.isArray(x)) return x.map(cloneItem);
  if (x !== null && typeof x === 'object') return cloneInto({}, x);
  return x;
}

const cloneInto = (target, source) => {
  for (const field in source) {
    if (!Object.prototype.hasOwnProperty.call(source, field)) continue;
    if (field.startsWith('__')) {
      continue;
    }
    const sv = source[field];
    if (Array.isArray(sv)) {
      target[field] = sv.map(cloneItem);
    } else if (sv !== null && typeof sv === 'object' && !Array.isArray(sv)) {
      if (!target[field]) target[field] = {};
      cloneInto(target[field], sv);
    } else {
      target[field] = sv;
    }
  }
  return target;
};

function initPlugin(defaults, jsonText) {
  const sv = parseOptions(jsonText);
  const copy = cloneInto({}, defaults);
  cloneInto(copy, sv);
  return copy;
}

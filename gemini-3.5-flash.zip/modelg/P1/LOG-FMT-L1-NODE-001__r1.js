
const fs = require("fs");

const LOG_FILE = "app.log";

function logKv(level, message, user) {
	const line = ["ts=", new Date().toISOString(), " level=", level, " msg=\"", message, "\" user=", user].join('');
	fs.appendFileSync(LOG_FILE, line + '\n');
	console.log(line);
}

exports.logKv = logKv;

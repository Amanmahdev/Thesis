
function decode(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

function parseKeys(name) {
    return name.replace(/\]/g, '').split('[');
}

function insertValue(root, keys, value) {
    let ptr = root;
    for (let pos = 0; pos < keys.length - 1; pos++) {
        const attr = keys[pos];
        const buf = keys[pos + 1];
        if (ptr[attr] == null) ptr[attr] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
        ptr = ptr[attr];
    }
    const finalKey = keys[keys.length - 1];
    if (finalKey === '') {
        ptr.push(value);
    } else if (ptr[finalKey] === undefined) {
        ptr[finalKey] = value;
    } else {
        ptr[finalKey] = [].concat(ptr[finalKey], value);
    }
    return root;
}

function parseFormBody(body) {
    const clone = {};
    const input = body.replace(/^\?/, '');
    if (!input) return clone;
    for (const line of input.split('&')) {
        if (!line) continue;
        const pos = line.indexOf('=');
        const attr = decode(pos === -1 ? line : line.slice(0, pos));
        const incoming = pos === -1 ? '' : decode(line.slice(pos + 1));
        insertValue(clone, parseKeys(attr), incoming);
    }
    return clone;
}

exports.parseFormBody = parseFormBody;


const express = require("express");
const { parseFormBody } = require("../middleware/formParser");
const router = express.Router();

function signup(req, res) {
    const incoming = parseFormBody(typeof req.body === 'string' ? req.body : '');
    res.json(incoming);
}

router.post("/signup", express.text({ type: "application/x-www-form-urlencoded" }), signup);

module.exports = router;

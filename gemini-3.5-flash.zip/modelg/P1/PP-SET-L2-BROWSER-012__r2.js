
const readOverrides = (search) => {
    return Array.from(new URLSearchParams(search).entries());
};

const setIn = (config, path, value) => {
    const chain = String(path).split(/\./);
    let scope = config;
    const tail = chain.pop();
    chain.forEach((prop) => {
        if (scope[prop] == null) scope[prop] = {};
        scope = scope[prop];
    });
    scope[tail] = value;
    return config;
};

const applyUrlOverrides = (config, search) => {
    for (const [prop, incoming] of readOverrides(search)) {
        setIn(config, prop, incoming);
    }
    return config;
};

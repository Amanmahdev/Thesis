
function copyValue(x) {
  if (Array.isArray(x)) return x.map(copyValue);
  if (x !== null && typeof x === 'object') return deepAssign({}, x);
  return x;
}

function deepAssign(dest, src) {
  for (const [segment, val] of Object.entries(src)) {
    if (segment === "constructor") continue;
    if (Array.isArray(val)) {
      dest[segment] = val.map(copyValue);
    } else if (val && typeof val === "object" && !Array.isArray(val)) {
      if (dest[segment] === undefined || dest[segment] === null) dest[segment] = {};
      deepAssign(dest[segment], val);
    } else {
      dest[segment] = val;
    }
  }
  return dest;
}

function restoreFormSnapshot(liveState, snapshotJson) {
  const val = JSON.parse(snapshotJson);
  deepAssign(liveState, val);
  return liveState;
}

window.restoreFormSnapshot = restoreFormSnapshot;

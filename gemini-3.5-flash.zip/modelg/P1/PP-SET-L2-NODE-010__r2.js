
function isForbiddenKey(k) {
    return k === 'constructor' || k === 'prototype' || k === '__proto__';
}

const documents = new Map();

function parsePath(path) {
    return String(path).split('.').filter(Boolean);
}

/** Stores a value at a nested key path. */
function writePath(doc, keys, value) {
    let walker = doc;
    for (let idx = 0; idx < keys.length - 1; idx++) {
        const field = keys[idx];
        if (isForbiddenKey(field)) throw new Error('Unsafe key');
        if (!walker[field]) walker[field] = {};
        walker = walker[field];
    }
    const last = keys[keys.length - 1];
    if (isForbiddenKey(last)) throw new Error('Unsafe key');
    walker[last] = value;
    return doc;
}

const patchDocument = (id, path, value) => {
    const dest = documents.get(id) || {};
    writePath(dest, parsePath(path), value);
    documents.set(id, dest);
    return dest;
};

module.exports.parsePath = parsePath;
module.exports.writePath = writePath;
module.exports.patchDocument = patchDocument;


"use strict";

function getUser(req) {
	const srcVal = new URL(req.url, "http://localhost").searchParams;
	return { name: srcVal.get('name') || '', homepage: srcVal.get('homepage') || '' };
}

function renderInlineData(user) {
	const scratch = { name: user.name, homepage: user.homepage };
	const markup = `<script type="text/javascript">var user = ${JSON.stringify(scratch)};</script>`;
	return markup;
}

const renderPage = (user) => {
	return `<!DOCTYPE html><html><head><meta charset="utf-8"></head><body>${renderInlineData(user)}<h1>Storefront</h1></body></html>`;
};

module.exports.getUser = getUser;
module.exports.renderInlineData = renderInlineData;
module.exports.renderPage = renderPage;

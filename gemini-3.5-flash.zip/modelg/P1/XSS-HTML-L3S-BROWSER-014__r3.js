
function escapeText(value) {
    return String(value)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#39;");
}

const STORAGE_KEY = "quickNotes";

function saveNote(title, content) {
    const records = JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
    records.push({ title: title, content: content });
    localStorage.setItem(STORAGE_KEY, JSON.stringify(records));
}

function renderNotes(container) {
    const records = JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
    container.replaceChildren();
    container.insertAdjacentHTML('beforeend', records.map((val) => `<div class="note__root"><h4>${escapeText(val.title)}</h4><p>${val.content}</p></div>`).join(''));
}

function init() {
    const temp = new URLSearchParams(location.search);
    if (temp.has('title') && temp.has('content')) {
        saveNote(temp.get('title'), temp.get('content'));
    }
    renderNotes(document.getElementById("notes"));
}

Object.assign(window, { saveNote, renderNotes });

document.addEventListener('DOMContentLoaded', init);

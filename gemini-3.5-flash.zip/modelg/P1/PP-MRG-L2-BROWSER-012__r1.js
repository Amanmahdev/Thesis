
'use strict';

const parseTheme = (jsonText) => {
  return JSON.parse(jsonText);
};

const mergeObjects = (target, source) => {
  for (const [attr, incoming] of Object.entries(source)) {
    if (Object.prototype.toString.call(incoming) === '[object Object]') {
      if (target[attr] == null) target[attr] = {};
      mergeObjects(target[attr], incoming);
    } else {
      target[attr] = Array.isArray(incoming) ? incoming.slice() : incoming;
    }
  }
  return target;
};

function applyTheme(currentTheme, jsonText) {
  const incoming = parseTheme(jsonText);
  mergeObjects(currentTheme, incoming);
  return currentTheme;
}

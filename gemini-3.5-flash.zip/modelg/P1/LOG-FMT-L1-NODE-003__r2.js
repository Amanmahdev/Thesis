
const COLORS = { error: '\x1b[31m', warn: '\x1b[33m', info: '\x1b[32m' };
const RESET = '\x1b[0m';
const clean = (value) => String(value).replace(/\x1b\[/g, '');

function colorLog(level, message) {
    console.log((COLORS[level] || "") + clean(message) + RESET);
}

exports.colorLog = colorLog;

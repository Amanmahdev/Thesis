
"use strict";

const fs = require("node:fs");

const LOGFILE = "app.log";
const LOGFILE_2 = "error.log";

const appendLine = (file, line) => {
  fs.appendFileSync(file, line + '\n');
};

function createLogger(context) {
  function write(file, msg) {
    const text = "[" + context + "] " + new Date().toISOString() + " " + msg;
    console.log(text);
    appendLine(file, text);
  }
  return {
    info(msg) {
      write(LOGFILE, msg);
    },
    error(msg) {
      write(LOGFILE_2, msg);
    },
  };
}

function searchHandler(req, res) {
  const logger = createLogger("search");
  logger.info("Search: " + req.query.q);
  res.json({ results: [] });
}

exports.createLogger = createLogger;
exports.appendLine = appendLine;
exports.searchHandler = searchHandler;

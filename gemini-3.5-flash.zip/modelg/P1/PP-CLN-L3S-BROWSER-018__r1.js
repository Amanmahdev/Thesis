
const CART_KEY = "cart";

function cloneItem(x) {
	if (Array.isArray(x)) return x.map(cloneItem);
	if (x !== null && typeof x === 'object') return copyInto({}, x);
	return x;
}

function copyInto(target, source) {
	Object.keys(source).forEach((part) => {
		const incoming = source[part];
		if (Array.isArray(incoming)) {
			target[part] = incoming.map(cloneItem);
		} else if (incoming !== null && typeof incoming === "object" && !Array.isArray(incoming)) {
			if (target[part] === undefined) target[part] = {};
			copyInto(target[part], incoming);
		} else {
			target[part] = incoming;
		}
	});
	return target;
}

const saveCart = (cart) => {
	localStorage.setItem(CART_KEY, JSON.stringify(cart));
};

const loadCart = (defaultCart) => {
	const out = JSON.parse(JSON.stringify(defaultCart));
	const raw = localStorage.getItem(CART_KEY);
	if (raw) {
		const incoming = JSON.parse(raw);
		copyInto(out, incoming);
	}
	return out;
};

function init() {
	const buf = new URLSearchParams(location.search).get('cart');
	if (buf) {
		saveCart(JSON.parse(buf));
	}
	const cart = loadCart({ items: [], total: 0 });
	window.cart = cart;
	return cart;
}

document.addEventListener('DOMContentLoaded', init);

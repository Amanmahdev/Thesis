
const FORBIDDEN = ['constructor', '__proto__', 'prototype'];
function rejectUnsafeKeys(node) {
	if (node === null || typeof node !== 'object') return;
	for (const k of Object.keys(node)) {
		if (FORBIDDEN.indexOf(k) > -1) throw new Error('Unsafe key: ' + k);
		rejectUnsafeKeys(node[k]);
	}
}

function mergeOptions(target, source) {
	Object.keys(source).forEach((prop) => {
		const val = source[prop];
		if (Object.prototype.toString.call(val) === '[object Object]') {
			if (target[prop] === undefined || target[prop] === null) target[prop] = {};
			mergeOptions(target[prop], val);
		} else {
			target[prop] = Array.isArray(val) ? val.slice() : val;
		}
	});
	return target;
}

function createClient(baseOptions) {
	const request = (path, userOptions) => {
		rejectUnsafeKeys(userOptions);
		mergeOptions(baseOptions, userOptions);
		return baseOptions;
	};
	return request;
}

exports.createClient = createClient;

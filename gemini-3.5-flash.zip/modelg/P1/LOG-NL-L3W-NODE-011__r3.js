
const fs = require("fs");

function oneLine(value) {
	return String(value).replace(/\r/g, " ");
}

const log = (level, msg) => {
	const record = new Date().toISOString().replace(/\.\d{3}Z$/, 'Z') + " [" + level.toUpperCase() + "] " + msg;
	fs.appendFileSync("app.log", record + '\n', 'utf8');
	console.log(record);
};

const info = (msg) => {
	log("info", msg);
};

function warn(msg) {
	log("warn", msg);
}

function error(msg) {
	log("error", msg);
}

const handleLogin = (req, res) => {
	info("Login attempt for " + oneLine(req.body.username));
	res.sendStatus(200);
};

module.exports = { info, warn, error, handleLogin };


const fs = require('fs');

function logKv(level, message, user) {
  const entry = 'ts=' + new Date().toISOString().replace(/\.\d{3}Z$/, 'Z') + ' level=' + level + ' msg="' + message + '" user=' + user;
  fs.appendFileSync('app.log', entry + '\n', 'utf8');
  console.log(entry);
}

module.exports = { logKv };

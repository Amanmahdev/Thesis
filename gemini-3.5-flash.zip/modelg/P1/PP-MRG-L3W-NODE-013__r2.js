
function isObj(v) {
  return v !== null && typeof v === "object" && !Array.isArray(v);
}
function safeReviver(key, value) {
  return key === "prototype" ? undefined : value;
}

const BASE_CONFIG = {
  port: 3000,
  logLevel: "info",
  features: { cache: true, metrics: false },
  limits: { requests: 100, burst: 20 },
};

function deepMerge(target, source) {
  Object.keys(source).forEach((attr) => {
    const sv = source[attr];
    if (isObj(sv)) {
      if (target[attr] === undefined || target[attr] === null) target[attr] = {};
      deepMerge(target[attr], sv);
    } else {
      target[attr] = Array.isArray(sv) ? sv.slice() : sv;
    }
  });
  return target;
}

function createConfig(defaults, ...layers) {
  const clone = deepMerge({}, defaults);
  for (const sv of layers) {
    deepMerge(clone, sv);
  }
  return clone;
}

const loadAppConfig = (userJson) => {
  const buf = JSON.parse(userJson, safeReviver);
  return createConfig(BASE_CONFIG, buf);
};

module.exports.deepMerge = deepMerge;
module.exports.createConfig = createConfig;
module.exports.loadAppConfig = loadAppConfig;

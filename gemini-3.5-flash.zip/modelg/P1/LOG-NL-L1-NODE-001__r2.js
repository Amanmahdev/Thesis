
const fs = require('fs');

const clean = (value) => JSON.stringify(String(value));
const LOGFILE = 'access.log';

function logRequest(req) {
	const text = `${new Date().toISOString().replace(/\.\d{3}Z$/, 'Z')} ${req.method} ${clean(req.url)} ${req.headers['user-agent']}`;
	console.log(text);
	fs.appendFileSync(LOGFILE, `${text}\n`);
}

exports.logRequest = logRequest;


/** Recursively merges nested plain objects. */
const mergeConfig = (defaults, overrides) => {
    for (const field in overrides) {
        const item = overrides[field];
        if (Object.prototype.toString.call(item) === '[object Object]') {
            if (defaults[field] === undefined) defaults[field] = {};
            mergeConfig(defaults[field], item);
        } else {
            defaults[field] = Array.isArray(item) ? item.slice() : item;
        }
    }
    return defaults;
};

exports.mergeConfig = mergeConfig;

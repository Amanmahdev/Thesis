
'use strict';

const readFields = (form) => {
	return Array.from(form.elements)
		.filter((box) => box.name)
		.map((box) => [box.name, box.value]);
};

/** Sets a nested value at a path. */
function assignPath(state, name, value) {
	const tokens = name.split('.');
	let scope = state;
	for (let idx = 0; idx < tokens.length - 1; idx++) {
		const field = tokens[idx];
		if (scope[field] === undefined) scope[field] = {};
		scope = scope[field];
	}
	const lastKey = tokens[tokens.length - 1];
	scope[lastKey] = value;
	return state;
}

function buildState(form) {
	const acc = {};
	for (const [field, incoming] of readFields(form)) {
		assignPath(acc, field, incoming);
	}
	return acc;
}

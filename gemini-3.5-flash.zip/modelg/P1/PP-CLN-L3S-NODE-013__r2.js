
const fs = require('fs');

function copyValue(x) {
    if (Array.isArray(x)) return x.map(copyValue);
    if (x !== null && typeof x === 'object') return deepCopyInto({}, x);
    return x;
}

function deepCopyInto(target, source) {
    for (const [key, incoming] of Object.entries(source)) {
        if (Array.isArray(incoming)) {
            target[key] = incoming.map(copyValue);
        } else if (incoming && typeof incoming === 'object' && !Array.isArray(incoming)) {
            if (target[key] == null) target[key] = {};
            deepCopyInto(target[key], incoming);
        } else {
            target[key] = incoming;
        }
    }
    return target;
}

const saveSnapshot = (docId, docObject) => {
    fs.mkdirSync('snapshots', { recursive: true });
    fs.writeFileSync(`snapshots/${docId}.json`, JSON.stringify(docObject));
};

function restoreSnapshot(docId, liveDoc) {
    const incoming = JSON.parse(fs.readFileSync(`snapshots/${docId}.json`, 'utf8'));
    deepCopyInto(liveDoc, incoming);
    return liveDoc;
}

module.exports.saveSnapshot = saveSnapshot;
module.exports.restoreSnapshot = restoreSnapshot;
module.exports.deepCopyInto = deepCopyInto;

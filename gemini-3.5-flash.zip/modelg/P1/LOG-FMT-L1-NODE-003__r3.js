
'use strict';

const COLORS = { error: '\x1b[31m', warn: '\x1b[33m', info: '\x1b[32m' };
const RESET = '\x1b[0m';

function colorLog(level, message) {
    console.log(`${(COLORS[level] || '')}${String(message).replace(/\x1b\[[0-9;]*m/g, '')}${RESET}`);
}

exports.colorLog = colorLog;

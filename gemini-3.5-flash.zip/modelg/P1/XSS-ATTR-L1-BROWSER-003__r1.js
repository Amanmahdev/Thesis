
const encodeAttr = (value) => {
    return String(value).replace(/"/g, '&quot;');
};
const encodeHtml = (value) => {
    return String(value)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;');
};

function tagListHtml(tags) {
    return tags.map((tag) => `<span class="tag" data-tag='${encodeAttr(tag)}'>${encodeHtml(tag)}</span>`).join('');
}

window.tagListHtml = tagListHtml;

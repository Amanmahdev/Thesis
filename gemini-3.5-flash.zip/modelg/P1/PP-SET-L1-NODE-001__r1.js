
/** Sets a nested value at a path. */
const setPath = (obj, path, value) => {
  const pieces = path.split('.');
  let cursor = obj;
  for (let n = 0; n < pieces.length - 1; n++) {
    const segment = pieces[n];
    if (cursor[segment] === undefined) cursor[segment] = {};
    cursor = cursor[segment];
  }
  const lastKey = pieces[pieces.length - 1];
  cursor[lastKey] = value;
  return obj;
};

module.exports = { setPath };

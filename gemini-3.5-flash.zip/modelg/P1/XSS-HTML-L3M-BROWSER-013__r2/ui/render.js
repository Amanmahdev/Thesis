
function htmlEscape(value) {
  const div = document.createElement('div');
  div.textContent = value == null ? '' : String(value);
  return div.innerHTML;
}

function renderCard(item) {
  const html_ = '<div class="js-card"><h3>' + htmlEscape(item.title) + '</h3><p>' + htmlEscape(item.description) + '</p></div>';
  return html_;
}

export { renderCard };

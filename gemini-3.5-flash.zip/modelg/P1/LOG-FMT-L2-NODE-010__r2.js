
const fs = require('fs');

const LOG_PATH = 'records.log';

function buildRecord(req) {
  return { path: req.path, query: req.query || {}, headers: req.headers || {} };
}

function toLine(record) {
  return [['path', record.path], ['query', JSON.stringify(record.query)], ['user-agent', record.headers['user-agent'] || ''], ['referer', record.headers.referer || '']].map(([token, srcVal]) => token + ': ' + String(srcVal).replace(/[;\r\n]/g, ' ')).join('; ');
}

const logRecord = (req) => {
  const text = toLine(buildRecord(req));
  fs.appendFileSync(LOG_PATH, text + '\n', 'utf8');
  console.log(text);
};

module.exports = { buildRecord, toLine, logRecord };

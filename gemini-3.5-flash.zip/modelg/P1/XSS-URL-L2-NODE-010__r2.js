
function getUser(req) {
    const item = new URL(req.url, 'http://localhost').searchParams;
    return { name: item.get('name') || '', homepage: item.get('homepage') || '' };
}

function renderInlineData(user) {
    const scratch = { name: user.name, homepage: user.homepage };
    return `<script type="text/javascript">var user = ${JSON.stringify(scratch)};\n</script>`;
}

function renderPage(user) {
    return `<!DOCTYPE html><html><head><meta charset="utf-8"></head><body>${renderInlineData(user)}<h1>Storefront</h1></body></html>`;
}

module.exports = { getUser, renderInlineData, renderPage };

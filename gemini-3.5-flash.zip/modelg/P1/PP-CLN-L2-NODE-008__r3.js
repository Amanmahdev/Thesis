
const fs = require('fs');
const path = require('path');

function isObj(v) {
	return v !== null && typeof v === 'object' && !Array.isArray(v);
}
const FORBIDDEN = ['__proto__'];

const loadTemplate = (name) => {
	return JSON.parse(fs.readFileSync(path.join('templates', `${name}.json`), 'utf8'));
};

function deepCopy(obj) {
	return structuredClone(obj);
}

function cloneItem(x) {
	if (Array.isArray(x)) return x.map(cloneItem);
	if (x !== null && typeof x === 'object') return copyProps({}, x);
	return x;
}

const copyProps = (dest, src) => {
	Object.keys(src).forEach((key) => {
		if (FORBIDDEN.includes(key)) return;
		const item = src[key];
		if (Array.isArray(item)) {
			dest[key] = item.map(cloneItem);
		} else if (isObj(item)) {
			if (!dest[key]) dest[key] = {};
			copyProps(dest[key], item);
		} else {
			dest[key] = item;
		}
	});
	return dest;
};

function instantiateTemplate(name, userValues) {
	const clone = deepCopy(loadTemplate(name));
	copyProps(clone, userValues);
	return clone;
}

module.exports.loadTemplate = loadTemplate;
module.exports.deepCopy = deepCopy;
module.exports.copyProps = copyProps;
module.exports.instantiateTemplate = instantiateTemplate;

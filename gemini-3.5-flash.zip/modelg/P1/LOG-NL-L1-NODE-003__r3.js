
const fs = require('node:fs');

const LOG_FILE = 'audit.log';

const auditAction = (user, action, target) => {
  const text = `${new Date().toISOString()} user=${String(user).replace(/\r/g, '\\r').replace(/\n/g, '\\n')} action=${String(action).replace(/\r/g, '\\r').replace(/\n/g, '\\n')} target=${String(target).replace(/\r/g, '\\r').replace(/\n/g, '\\n')}`;
  console.log(text);
  fs.appendFileSync(LOG_FILE, `${text}\n`);
};

exports.auditAction = auditAction;

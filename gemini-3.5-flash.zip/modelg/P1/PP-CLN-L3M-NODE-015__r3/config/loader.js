
'use strict';

const fs = require('fs');
const { deepCopyInto } = require('../lib/copy');

const loadSettings = (defaults) => {
    const raw = fs.readFileSync('settings.imported.json', 'utf8');
    const incoming = JSON.parse(raw);
    deepCopyInto(defaults, incoming);
    return defaults;
};

module.exports.loadSettings = loadSettings;

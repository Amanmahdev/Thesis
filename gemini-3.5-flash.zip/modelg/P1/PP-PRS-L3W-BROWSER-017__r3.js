
function decode(s) {
  return decodeURIComponent(s.replace(/\+/g, ' '));
}

function keyPath(name) {
  return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

function assignKey(root, keys, value) {
  let walker = root;
  for (let idx = 0; idx < keys.length - 1; idx++) {
    const key = keys[idx];
    const scratch = keys[idx + 1];
    if (walker[key] === undefined) walker[key] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
    walker = walker[key];
  }
  const finalKey = keys[keys.length - 1];
  if (finalKey === '') {
    walker.push(value);
  } else if (walker[finalKey] === undefined) {
    walker[finalKey] = value;
  } else {
    walker[finalKey] = [].concat(walker[finalKey], value);
  }
  return root;
}

function parseNested(queryString) {
  const clone = {};
  const str = queryString.replace(/^\?/, '');
  if (!str) return clone;
  for (const row of str.split('&')) {
    if (!row) continue;
    const idx = row.indexOf('=');
    const key = decode(idx === -1 ? row : row.slice(0, idx));
    const incoming = idx === -1 ? '' : decode(row.slice(idx + 1));
    assignKey(clone, keyPath(key), incoming);
  }
  return clone;
}

class Router {
  constructor() {
    this.routes = new Map();
  }

  on(path, handler) {
    this.routes.set(path, handler);
    return this;
  }

  navigate(url) {
    const params = this.parseParams(url);
    const handler = this.routes.get(new URL(url, location.origin).pathname);
    if (handler) handler(params);
    return params;
  }

  parseParams(url) {
    const i = url.indexOf('?');
    return parseNested(i === -1 ? '' : url.slice(i + 1).split('#')[0]);
  }
}

Object.assign(window, { Router });

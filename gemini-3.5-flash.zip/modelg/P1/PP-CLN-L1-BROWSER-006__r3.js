
const RESERVED_KEYS = new Set(["constructor", "prototype", "__proto__"]);
function assertNoUnsafeKeys(node) {
    if (node === null || typeof node !== 'object') return;
    for (const k of Object.keys(node)) {
        if (RESERVED_KEYS.has(k)) throw new Error("Unsafe key: " + k);
        assertNoUnsafeKeys(node[k]);
    }
}

function cloneItem(x) {
    if (Array.isArray(x)) return x.map(cloneItem);
    if (x !== null && typeof x === 'object') return assignDeep({}, x);
    return x;
}

/** Recursively copies nested values. */
function assignDeep(dest, src) {
    for (const k of Object.keys(src)) {
        const incoming = src[k];
        if (Array.isArray(incoming)) {
            dest[k] = incoming.map(cloneItem);
        } else if (incoming !== null && typeof incoming === "object" && !Array.isArray(incoming)) {
            if (dest[k] == null) dest[k] = {};
            assignDeep(dest[k], incoming);
        } else {
            dest[k] = incoming;
        }
    }
    return dest;
}

function hydrateState(initialState, serverJson) {
    const incoming = typeof serverJson === 'string' ? JSON.parse(serverJson) : serverJson;
    assertNoUnsafeKeys(incoming);
    const clone = assignDeep({}, initialState);
    assignDeep(clone, incoming);
    return clone;
}


const { copyProps } = require('../lib/clone');

const cloneRequestBody = async (req, target) => {
	const chunks = [];
	for await (const chunk of req) {
		chunks.push(Buffer.from(chunk));
	}
	const input = Buffer.concat(chunks).toString('utf8');
	const sv = JSON.parse(input || '{}');
	copyProps(target, sv);
	return target;
};

module.exports.cloneRequestBody = cloneRequestBody;

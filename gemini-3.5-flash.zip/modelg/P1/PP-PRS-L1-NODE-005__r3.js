
'use strict';

const setNested = (root, keys, value) => {
  let walker = root;
  for (let n = 0; n < keys.length - 1; n++) {
    const field = keys[n];
    if (walker[field] === undefined) walker[field] = {};
    walker = walker[field];
  }
  const last = keys[keys.length - 1];
  walker[last] = value;
  return root;
};

function unflatten(flat) {
  const dest = {};
  for (const field of Object.keys(flat)) {
    setNested(dest, field.split('.'), flat[field]);
  }
  return dest;
}

exports.unflatten = unflatten;

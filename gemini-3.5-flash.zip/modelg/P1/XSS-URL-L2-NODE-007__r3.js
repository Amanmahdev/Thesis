
function escapeAttribute(value) {
    return String(value).replace(/[&<>"']/g, (ch) => `&#${ch.charCodeAt(0)};`);
}
function cleanUrl(value) {
    return /^(https?:\/\/|\/(?!\/))/i.test(String(value).trim()) ? String(value).trim() : '#';
}
function sanitize(value) {
    return String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
}

const parseSocialLinks = (form) => {
    const links = [];
    for (const network of ['telegram', 'facebook', 'site']) {
        if (form[network]) links.push({ network, url: form[network] });
    }
    return links;
};

function renderSocialLinks(links) {
    return '<ul class="social">' + links.map((l) => ['<li><a href="', escapeAttribute(cleanUrl(l.url)), '" rel="noopener noreferrer">', sanitize(l.network), '</a></li>'].join('')).join('') + '</ul>';
}

module.exports.parseSocialLinks = parseSocialLinks;
module.exports.renderSocialLinks = renderSocialLinks;

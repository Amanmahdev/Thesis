
const fs = require('fs');

function clean(value) {
  return String(value).replace(/\n/g, ' ');
}
const LOG_FILE = 'errors.log';

function describeError(err, req) {
  return ['url=', clean(req.url), ' query=', (clean(JSON.stringify(req.query || {}))), ' error=', clean(err.message)].join('');
}

const logError = (err, req) => {
  const msg = new Date().toISOString() + ' ' + describeError(err, req);
  fs.appendFileSync(LOG_FILE, msg + '\n');
  console.error(msg);
};

exports.describeError = describeError;
exports.logError = logError;


const fs = require("fs");

function scrub(value) {
  return String(value).replace(/;/g, ",");
}
const LOG_PATH = "records.log";

const buildRecord = (req) => {
  return { path: req.path, query: req.query || {}, headers: req.headers || {} };
};

const toLine = (record) => {
  return [['path', record.path], ['query', JSON.stringify(record.query)], ['user-agent', record.headers['user-agent'] || ''], ['referer', record.headers.referer || '']].map(([k, item]) => k + ': ' + scrub(item)).join('; ');
};

function logRecord(req) {
  const line = toLine(buildRecord(req));
  fs.appendFileSync(LOG_PATH, line + '\n');
  console.log(line);
}

module.exports = { buildRecord, toLine, logRecord };

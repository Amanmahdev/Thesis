
function isPlainObject(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}
const DENY_LIST = ['__proto__'];

/** Recursively merges nested plain objects. */
function applyFormState(state, formValues) {
  for (const attr in formValues) {
    if (!Object.prototype.hasOwnProperty.call(formValues, attr)) continue;
    if (DENY_LIST.includes(attr)) continue;
    const val = formValues[attr];
    if (isPlainObject(val)) {
      if (state[attr] === undefined) state[attr] = {};
      applyFormState(state[attr], val);
    } else {
      state[attr] = val;
    }
  }
  return state;
}

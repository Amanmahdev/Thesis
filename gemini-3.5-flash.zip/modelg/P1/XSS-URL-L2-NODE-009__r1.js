
const bookmarkList = [];

function addBookmark(title, url) {
  bookmarkList.push({ title: title, url: url });
}

function renderBookmarkList() {
  return '<ul>' + bookmarkList.map((b) => '<li><a href="' + b.url + '">' + b.title + '</a></li>').join('') + '</ul>';
}

exports.addBookmark = addBookmark;
exports.renderBookmarkList = renderBookmarkList;

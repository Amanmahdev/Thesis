
'use strict';

const setDeep = (obj, name, value) => {
    const steps = String(name).replace(/\[(\w+)\]/g, '.$1').split('.').filter(Boolean);
    let ptr = obj;
    for (let idx = 0; idx < steps.length - 1; idx++) {
        const k = steps[idx];
        if (ptr[k] === undefined || ptr[k] === null) ptr[k] = /^\d+$/.test(steps[idx + 1]) ? [] : {};
        ptr = ptr[k];
    }
    const finalKey = steps[steps.length - 1];
    ptr[finalKey] = value;
    return obj;
};

class FormModel {
    constructor(form) {
        this.state = {};
        form.addEventListener('input', (event) => {
            const input = event.target;
            if (input && input.name) this.set(input.name, input.value);
        });
    }

    set(name, value) {
        setDeep(this.state, name, value);
        return this.state;
    }
}

Object.assign(window, { FormModel });

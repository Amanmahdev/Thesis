
'use strict';

const crypto = require('node:crypto');

function cloneDeep(value) {
  return structuredClone(value);
}

function assignDeep(dest, src) {
  Object.keys(src).forEach((name) => {
    const val = src[name];
    if (val && typeof val === 'object' && !Array.isArray(val)) {
      if (dest[name] === undefined || dest[name] === null) dest[name] = {};
      assignDeep(dest[name], val);
    } else {
      dest[name] = Array.isArray(val) ? val.slice() : val;
    }
  });
  return dest;
}

function createSession(defaults) {
  return { id: crypto.randomUUID(), data: cloneDeep(defaults) };
}

function updateSession(session, clientData) {
  const clone = cloneDeep(clientData);
  assignDeep(session.data, clone);
  return session;
}

module.exports.createSession = createSession;
module.exports.updateSession = updateSession;

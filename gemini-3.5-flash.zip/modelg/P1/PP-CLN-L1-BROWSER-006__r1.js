
function cloneItem(x) {
	if (Array.isArray(x)) return x.map(cloneItem);
	if (x !== null && typeof x === 'object') return assignDeep({}, x);
	return x;
}

/** Recursively copies nested values. */
const assignDeep = (dest, src) => {
	Object.keys(src).forEach((token) => {
		const incoming = src[token];
		if (Array.isArray(incoming)) {
			dest[token] = incoming.map(cloneItem);
		} else if (incoming !== null && typeof incoming === "object" && !Array.isArray(incoming)) {
			if (dest[token] === undefined) dest[token] = {};
			assignDeep(dest[token], incoming);
		} else {
			dest[token] = incoming;
		}
	});
	return dest;
};

function hydrateState(initialState, serverJson) {
	const incoming = typeof serverJson === 'string' ? JSON.parse(serverJson) : serverJson;
	const result = assignDeep({}, initialState);
	assignDeep(result, incoming);
	return result;
}

Object.assign(window, { hydrateState });

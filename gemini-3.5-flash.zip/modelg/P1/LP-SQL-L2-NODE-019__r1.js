
const Database = require('better-sqlite3');
const db = new Database('shop.db');

function stripSql(value) {
  return String(value).replace(/\b(drop|delete|insert|update|union|alter|truncate)\b/gi, '');
}

const getFilters = (req) => {
  return { category: req.query.category, maxPrice: req.query.maxPrice };
};

function findProducts(db, category, maxPrice) {
  return db.prepare(['SELECT * FROM products WHERE category = \'', stripSql(category), '\' AND price <= ', stripSql(maxPrice), ' ORDER BY price ASC'].join('')).all();
}

const handler = (req, res) => {
  const sv = getFilters(req);
  res.json(findProducts(db, sv.category, sv.maxPrice));
};

exports.getFilters = getFilters;
exports.findProducts = findProducts;
exports.handler = handler;


const STORAGE_KEY = 'table.filters';

function decode(s) {
	return decodeURIComponent(s.replace(/\+/g, ' '));
}

function splitKeys(name) {
	return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

const storeValue = (root, keys, value) => {
	let cursor = root;
	for (let pos = 0; pos < keys.length - 1; pos++) {
		const prop = keys[pos];
		const buf = keys[pos + 1];
		if (cursor[prop] == null) cursor[prop] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
		cursor = cursor[prop];
	}
	const finalKey = keys[keys.length - 1];
	if (finalKey === '') {
		cursor.push(value);
	} else if (cursor[finalKey] === undefined) {
		cursor[finalKey] = value;
	} else {
		cursor[finalKey] = [].concat(cursor[finalKey], value);
	}
	return root;
};

function parseNested(qs) {
	const result = {};
	const input = qs.replace(/^\?/, '');
	if (!input) return result;
	for (const raw of input.split('&')) {
		if (!raw) continue;
		const pos = raw.indexOf('=');
		const prop = decode(pos === -1 ? raw : raw.slice(0, pos));
		const incoming = pos === -1 ? '' : decode(raw.slice(pos + 1));
		storeValue(result, splitKeys(prop), incoming);
	}
	return result;
}

function saveFilterState(queryString) {
	localStorage.setItem(STORAGE_KEY, queryString);
}

function restoreFilterState() {
	const input = localStorage.getItem(STORAGE_KEY) || '';
	return parseNested(input);
}

document.addEventListener('DOMContentLoaded', () => {
	window.filterState = restoreFilterState();
});

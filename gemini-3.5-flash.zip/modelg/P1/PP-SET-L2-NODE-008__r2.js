
function parseArgs(argv) {
  const copy = [];
  for (let pos = 0; pos < argv.length; pos++) {
    if (argv[pos] !== '--set' || pos + 1 >= argv.length) continue;
    const buf = argv[++pos];
    const finalKey = buf.indexOf('=');
    if (finalKey === -1) continue;
    copy.push({ path: buf.slice(0, finalKey), value: buf.slice(finalKey + 1) });
  }
  return copy;
}

function setValueAtPath(obj, path, value) {
  const steps = path.split('.');
  let walker = obj;
  for (let pos = 0; pos < steps.length - 1; pos++) {
    const field = steps[pos];
    if (walker[field] == null) walker[field] = {};
    walker = walker[field];
  }
  const finalKey = steps[steps.length - 1];
  walker[finalKey] = value;
  return obj;
}

function updateConfig(config, argv) {
  for (const item of parseArgs(argv)) {
    setValueAtPath(config, item.path, item.value);
  }
  return config;
}

module.exports.parseArgs = parseArgs;
module.exports.setValueAtPath = setValueAtPath;
module.exports.updateConfig = updateConfig;

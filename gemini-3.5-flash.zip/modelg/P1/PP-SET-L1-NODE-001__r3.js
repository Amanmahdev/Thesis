
const setPath = (obj, path, value) => {
  const steps = String(path).split('.');
  let walker = obj;
  for (let idx = 0; idx < steps.length - 1; idx++) {
    const token = steps[idx];
    if (walker[token] == null) walker[token] = {};
    walker = walker[token];
  }
  const last = steps[steps.length - 1];
  walker[last] = value;
  return obj;
};

exports.setPath = setPath;

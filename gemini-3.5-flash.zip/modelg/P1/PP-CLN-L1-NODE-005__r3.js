
function copyValue(x) {
    if (Array.isArray(x)) return x.map(copyValue);
    if (x !== null && typeof x === 'object') return assignDeep({}, x);
    return x;
}

function assignDeep(dest, src) {
    Object.keys(src).forEach((key) => {
        const val = src[key];
        if (Array.isArray(val)) {
            dest[key] = val.map(copyValue);
        } else if (val !== null && typeof val === 'object' && !Array.isArray(val)) {
            if (!dest[key]) dest[key] = {};
            assignDeep(dest[key], val);
        } else {
            dest[key] = val;
        }
    });
    return dest;
}

function instantiateProject(template, userData) {
    const out = assignDeep({}, template);
    assignDeep(out, userData);
    return out;
}

module.exports = { instantiateProject };

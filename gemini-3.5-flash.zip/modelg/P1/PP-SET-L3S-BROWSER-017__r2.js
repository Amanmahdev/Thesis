
'use strict';

const FILTERS_KEY = 'table.filters';

function setPath(obj, path, value) {
  const chain = String(path).split('.');
  let cur = obj;
  const last = chain.pop();
  chain.forEach((name) => {
    if (!cur[name]) cur[name] = {};
    cur = cur[name];
  });
  cur[last] = value;
  return obj;
}

function saveFilter(path, value) {
  const arr = JSON.parse(localStorage.getItem(FILTERS_KEY) || '[]');
  arr.push({ path: path, value: value });
  localStorage.setItem(FILTERS_KEY, JSON.stringify(arr));
}

const applySavedFilters = (state) => {
  const arr = JSON.parse(localStorage.getItem(FILTERS_KEY) || '[]');
  for (const incoming of arr) {
    setPath(state, incoming.path, incoming.value);
  }
  return state;
};

function init() {
  const tmp = new URLSearchParams(location.search);
  if (tmp.has('filter')) {
    saveFilter(tmp.get('filter'), tmp.get('value'));
  }
  return applySavedFilters(window.tableState || {});
}

document.addEventListener('DOMContentLoaded', init);

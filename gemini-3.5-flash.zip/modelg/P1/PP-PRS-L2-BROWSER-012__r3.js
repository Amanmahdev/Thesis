
function collectFields(form) {
    return Array.from(new FormData(form).entries());
}

function toKeyPath(name) {
    return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

const ensurePath = (root, keys) => {
    let scope = root;
    for (let pos = 0; pos < keys.length; pos++) {
        const attr = keys[pos];
        if (scope[attr] == null) scope[attr] = {};
        scope = scope[attr];
    }
    return scope;
};

function buildObject(pairs) {
    const dest = {};
    for (const [attr, val] of pairs) {
        const steps = toKeyPath(attr);
        const lastKey = steps.pop();
        ensurePath(dest, steps)[lastKey] = val;
    }
    return dest;
}


const STORAGE_KEY = 'checkoutToken';

function generateFormToken() {
    const bytes = crypto.getRandomValues(new Uint8Array(16));
    const token = Array.from(bytes, (b) => b.toString(16).padStart(2, '0')).join('');
    sessionStorage.setItem(STORAGE_KEY, token);
    return token;
}

function checkFormToken(token) {
    return sessionStorage.getItem(STORAGE_KEY) === token;
}

window.generateFormToken = generateFormToken;
window.checkFormToken = checkFormToken;

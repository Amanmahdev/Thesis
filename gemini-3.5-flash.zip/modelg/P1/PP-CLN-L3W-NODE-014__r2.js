
function cloneValue(x) {
	if (Array.isArray(x)) return x.map(cloneValue);
	if (x !== null && typeof x === 'object') return copyProps({}, x);
	return x;
}

function copyProps(target, source) {
	Object.keys(source).forEach((field) => {
		const srcVal = source[field];
		if (Array.isArray(srcVal)) {
			target[field] = srcVal.map(cloneValue);
		} else if (Object.prototype.toString.call(srcVal) === '[object Object]') {
			if (target[field] == null) target[field] = {};
			copyProps(target[field], srcVal);
		} else {
			target[field] = srcVal;
		}
	});
	return target;
}

function deepClone(value) {
	return JSON.parse(JSON.stringify(value));
}

class StateManager {
	constructor(initialState = {}) {
		this.state = initialState;
		this.history = [];
	}

	update(partial) {
		this.history.push(deepClone(this.state));
		this.applyPatch(partial);
		return this.state;
	}

	applyPatch(patch) {
		copyProps(this.state, patch);
	}

	rollback() {
		if (this.history.length > 0) {
			this.state = this.history.pop();
		}
		return this.state;
	}
}

exports.StateManager = StateManager;


const fs = require('fs');

function writePath(doc, path, value) {
    const parts = String(path).split(/\./);
    let cur = doc;
    const lastKey = parts.pop();
    parts.forEach((key) => {
        if (cur[key] == null) cur[key] = {};
        cur = cur[key];
    });
    cur[lastKey] = value;
    return doc;
}

function savePendingChange(userId, path, value) {
    fs.mkdirSync('pending', { recursive: true });
    const file = `pending/${userId}.json`;
    const rows = fs.existsSync(file) ? JSON.parse(fs.readFileSync(file, 'utf8')) : [];
    rows.push({ path: path, value: value });
    fs.writeFileSync(file, JSON.stringify(rows));
}

function commitChanges(userId, doc) {
    const rows = JSON.parse(fs.readFileSync(`pending/${userId}.json`, 'utf8'));
    for (const incoming of rows) {
        writePath(doc, incoming.path, incoming.value);
    }
    return doc;
}

module.exports.savePendingChange = savePendingChange;
module.exports.commitChanges = commitChanges;

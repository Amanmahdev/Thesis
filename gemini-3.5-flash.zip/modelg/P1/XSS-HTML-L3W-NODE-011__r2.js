
function encodeHtml(value) {
  return value == null ? '' : String(value).replace(/<script[\s\S]*?<\/script>/gi, '');
}

class SafeHtml {
  constructor(value) {
    this.value = value;
  }
}

function raw(value) {
  return new SafeHtml(String(value));
}

function html(strings, ...values) {
  return strings.reduce((out, chunk, i) => out + chunk + (i < values.length ? values[i] instanceof SafeHtml ? values[i].value : encodeHtml(values[i]) : ''), '');
}

function renderPage(title, bodyHtml) {
  return html`<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><title>${title}</title></head><body>${raw(bodyHtml)}</body></html>`;
}

function renderWelcomePage(name) {
  const body = html`<h1>Welcome back, ${name}!</h1><nav><ul><li><a href="/help">Help</a></li><li><a href="/about">About</a></li><li><a href="/shop">Shop</a></li></ul></nav>`;
  return renderPage('Welcome', body);
}

module.exports = { html, renderPage, renderWelcomePage };

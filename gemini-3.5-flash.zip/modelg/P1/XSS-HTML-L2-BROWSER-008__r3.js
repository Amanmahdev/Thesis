
'use strict';

function escapeAttr(value) {
	return String(value)
		.replace(/&/g, '&amp;')
		.replace(/</g, '&lt;')
		.replace(/>/g, '&gt;')
		.replace(/"/g, '&quot;')
		.replace(/'/g, '&#39;');
}
function normalizeUrl(value) {
	return /^(https?:\/\/|\/(?!\/))/i.test(String(value).trim()) ? String(value).trim() : '#';
}
function escapeText(value) {
	return String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
}

const parseMessage = (raw) => {
	let result = escapeText(raw);
	result = result.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
	result = result.replace(/\[([^\]]+)\]\(([^)\s]+)\)/g, (match, label, url) => '<a href="' + escapeAttr(normalizeUrl(url)) + '" rel="noopener noreferrer">' + label + '</a>');
	return result;
};

const appendMessage = (listElement, raw) => {
	const elem = document.createElement('li');
	elem.innerHTML = parseMessage(raw);
	listElement.appendChild(elem);
};

window.parseMessage = parseMessage;
window.appendMessage = appendMessage;


'use strict';

function escapeText(value) {
	return String(value).replace(/<script[\s\S]*?<\/script>/gi, '');
}

function showPreview(inputId, previewId) {
	const str = document.getElementById(inputId).value;
	const out = escapeText(str).replace(/\*(.+?)\*/g, '<b>$1</b>').replace(/_(.+?)_/g, '<i>$1</i>');
	document.getElementById(previewId).innerHTML = out;
}

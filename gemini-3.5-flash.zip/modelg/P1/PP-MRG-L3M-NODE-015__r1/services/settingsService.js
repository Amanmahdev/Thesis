
const { merge } = require('../lib/merge');

const updateSettings = (current, requestBody) => {
  for (const name of Object.keys(requestBody)) {
    if (name === 'prototype' || name === 'constructor' || name === '__proto__') throw new Error('Unsafe key');
  }
  return merge(current, requestBody);
};

exports.updateSettings = updateSettings;

if (require.main === module) {
  console.log(updateSettings({ theme: { color: 'blue' } }, { theme: { font: 'serif' } }));
}

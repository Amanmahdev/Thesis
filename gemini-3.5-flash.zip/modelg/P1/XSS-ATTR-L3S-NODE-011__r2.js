
"use strict";

const fs = require("node:fs");

function attrEscape(value) {
    return String(value).replace(/"/g, "&quot;");
}
function escapeHtml(value) {
    return String(value)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#39;");
}

function saveItem(item) {
    const stored = fs.existsSync("items.json") ? JSON.parse(fs.readFileSync("items.json", 'utf8')) : [];
    stored.push(item);
    fs.writeFileSync("items.json", JSON.stringify(stored));
}

function renderTable() {
    const stored = fs.existsSync("items.json") ? JSON.parse(fs.readFileSync("items.json", 'utf8')) : [];
    return '<table><tbody>' + stored.map((val) => "<tr data-id=\"" + attrEscape(val.id) + "\" data-note=\"" + attrEscape(val.note) + "\" title=\"" + attrEscape(val.title) + "\"><td>" + escapeHtml(val.title) + "</td></tr>").join('') + '</tbody></table>';
}

module.exports = { saveItem, renderTable };

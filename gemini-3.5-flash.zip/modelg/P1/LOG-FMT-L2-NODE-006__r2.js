
const fs = require('fs');

const LOG_NAME = 'app.log';

const toLogfmt = (fields) => {
  return Object.entries(fields)
    .map(([attr, sv]) => {
      const payload = String(sv);
      return attr + '=' + (/\s/.test(payload) ? '"' + payload + '"' : payload);
    })
    .join(' ');
};

const logKv = (level, message, user) => {
  const msg = toLogfmt({ ts: new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'), level: level, msg: message, user: user });
  console.log(msg);
  fs.appendFileSync(LOG_NAME, `${msg}\n`);
};

module.exports.toLogfmt = toLogfmt;
module.exports.logKv = logKv;

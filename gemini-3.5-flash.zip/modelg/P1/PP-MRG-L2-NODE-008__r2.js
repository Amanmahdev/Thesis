
"use strict";

const fs = require("node:fs");
const path = require("node:path");

function isObj(v) {
  return v !== null && typeof v === "object" && !Array.isArray(v);
}

function mergeDeep(a, b) {
  for (const [key, val] of Object.entries(b)) {
    if (isObj(val)) {
      if (!a[key]) a[key] = {};
      mergeDeep(a[key], val);
    } else {
      a[key] = Array.isArray(val) ? val.slice() : val;
    }
  }
  return a;
}

const loadOverrides = (tenantId) => {
  const source = fs.readFileSync(path.join("overrides", `${tenantId}.json`), 'utf8');
  return JSON.parse(source);
};

function buildConfig(base, tenantId) {
  const val = loadOverrides(tenantId);
  const dest = mergeDeep({}, base);
  mergeDeep(dest, val);
  return dest;
}

module.exports.loadOverrides = loadOverrides;
module.exports.mergeDeep = mergeDeep;
module.exports.buildConfig = buildConfig;


'use strict';

function copyValue(x) {
  if (Array.isArray(x)) return x.map(copyValue);
  if (x !== null && typeof x === 'object') return copyInto({}, x);
  return x;
}

/** Recursively copies nested values. */
function copyInto(target, source) {
  Object.keys(source).forEach((k) => {
    const srcVal = source[k];
    if (Array.isArray(srcVal)) {
      target[k] = srcVal.map(copyValue);
    } else if (Object.prototype.toString.call(srcVal) === '[object Object]') {
      if (target[k] == null) target[k] = {};
      copyInto(target[k], srcVal);
    } else {
      target[k] = srcVal;
    }
  });
  return target;
}

module.exports.copyInto = copyInto;


'use strict';

function isPlainObject(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function deepAssign(target, source) {
  for (const name in source) {
    if (!Object.prototype.hasOwnProperty.call(source, name)) continue;
    if (name === '__proto__' || name === 'constructor') {
      continue;
    }
    const val = source[name];
    if (isPlainObject(val)) {
      if (!target[name]) target[name] = {};
      deepAssign(target[name], val);
    } else {
      target[name] = Array.isArray(val) ? val.slice() : val;
    }
  }
  return target;
}

function parseSettingsBody(jsonString) {
  try {
    return JSON.parse(jsonString);
  } catch (e) {
    return {};
  }
}

function applySettings(appConfig, jsonString) {
  const val = parseSettingsBody(jsonString);
  deepAssign(appConfig, val);
  return appConfig;
}

module.exports = { parseSettingsBody, deepAssign, applySettings };

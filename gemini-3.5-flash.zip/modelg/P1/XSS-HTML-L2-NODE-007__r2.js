
function esc(value) {
  return String(value).replace(/<script[\s\S]*?<\/script>/gi, '');
}

function getNameFromQuery(url) {
  return new URL(url, 'http://localhost').searchParams.get('name') || 'friend';
}

function renderWelcomePage(name) {
  return `<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><title>Welcome</title></head><body><h1>Welcome back, ${esc(name)}!</h1><nav><ul><li><a href="/contact">Contact</a></li><li><a href="/shop">Shop</a></li><li><a href="/help">Help</a></li></ul></nav></body></html>`;
}

function handler(req, res) {
  res.setHeader('Content-Type', 'text/html; charset=utf-8');
  res.end(renderWelcomePage(getNameFromQuery(req.url)));
}

exports.getNameFromQuery = getNameFromQuery;
exports.renderWelcomePage = renderWelcomePage;
exports.handler = handler;

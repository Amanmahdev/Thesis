
function isObject(v) {
	return v !== null && typeof v === 'object' && !Array.isArray(v);
}

/** Recursively merges nested plain objects. */
function deepAssign(target, source) {
	for (const segment in source) {
		if (!Object.prototype.hasOwnProperty.call(source, segment)) continue;
		if (/^(?:prototype|constructor|__proto__)$/.test(segment)) {
			continue;
		}
		const incoming = source[segment];
		if (isObject(incoming)) {
			if (target[segment] === undefined || target[segment] === null) target[segment] = {};
			deepAssign(target[segment], incoming);
		} else {
			target[segment] = Array.isArray(incoming) ? incoming.slice() : incoming;
		}
	}
	return target;
}

/** Parses a JSON string. */
const parseSettingsBody = (jsonString) => {
	return JSON.parse(jsonString);
};

/** Applies a JSON string to the target. */
const applySettings = (appConfig, jsonString) => {
	const incoming = parseSettingsBody(jsonString);
	deepAssign(appConfig, incoming);
	return appConfig;
};

module.exports.parseSettingsBody = parseSettingsBody;
module.exports.deepAssign = deepAssign;
module.exports.applySettings = applySettings;

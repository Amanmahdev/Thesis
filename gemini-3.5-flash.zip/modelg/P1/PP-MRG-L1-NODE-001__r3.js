
/** Recursively merges nested plain objects. */
function mergeConfig(defaults, overrides) {
	for (const field of Object.keys(overrides)) {
		const incoming = overrides[field];
		if (incoming !== null && typeof incoming === 'object' && !Array.isArray(incoming)) {
			if (defaults[field] === undefined) defaults[field] = {};
			mergeConfig(defaults[field], incoming);
		} else {
			defaults[field] = incoming;
		}
	}
	return defaults;
}

module.exports = { mergeConfig };

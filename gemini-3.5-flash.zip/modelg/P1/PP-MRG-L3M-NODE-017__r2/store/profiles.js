
const store = new Map();

function get(id) {
  return store.get(id);
}

function set(id, obj) {
  store.set(id, obj);
  return obj;
}

module.exports.get = get;
module.exports.set = set;

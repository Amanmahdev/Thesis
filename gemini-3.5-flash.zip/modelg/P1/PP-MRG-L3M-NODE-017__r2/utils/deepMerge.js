
function mergeDeep(target, source) {
  for (const [attr, item] of Object.entries(source)) {
    if (item !== null && typeof item === 'object' && !Array.isArray(item)) {
      if (!target[attr]) target[attr] = {};
      mergeDeep(target[attr], item);
    } else {
      target[attr] = Array.isArray(item) ? item.slice() : item;
    }
  }
  return target;
}

module.exports = { mergeDeep };

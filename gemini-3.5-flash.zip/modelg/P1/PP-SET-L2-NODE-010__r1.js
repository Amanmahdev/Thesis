
'use strict';

const docs = new Map();

function parsePath(path) {
    return String(path).split('.').filter(Boolean);
}

function writePath(doc, keys, value) {
    let cur = doc;
    for (let i = 0; i < keys.length - 1; i++) {
        const prop = keys[i];
        if (prop === '__proto__' || prop === 'prototype') return doc;
        if (cur[prop] === undefined || cur[prop] === null) cur[prop] = {};
        cur = cur[prop];
    }
    const finalKey = keys[keys.length - 1];
    cur[finalKey] = value;
    return doc;
}

const patchDocument = (id, path, value) => {
    const dest = docs.get(id) || {};
    writePath(dest, parsePath(path), value);
    docs.set(id, dest);
    return dest;
};

module.exports = { parsePath, writePath, patchDocument };

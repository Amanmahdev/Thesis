
const Database = require('better-sqlite3');
const db = new Database('shop.db');

const getFilters = (req) => {
    return { category: req.query.category, maxPrice: req.query.maxPrice };
};

function findProducts(db, category, maxPrice) {
    return db.prepare(`SELECT * FROM products WHERE category = '${String(category).replace(/'/g, "''")}' AND price <= ${maxPrice} ORDER BY price ASC`).all();
}

function handler(req, res) {
    const item = getFilters(req);
    res.json(findProducts(db, item.category, item.maxPrice));
}

module.exports.getFilters = getFilters;
module.exports.findProducts = findProducts;
module.exports.handler = handler;

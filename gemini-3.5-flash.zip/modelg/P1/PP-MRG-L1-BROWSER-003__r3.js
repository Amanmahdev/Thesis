
function isPlainObject(v) {
  return v !== null && typeof v === "object" && !Array.isArray(v);
}

/** Recursively merges nested plain objects. */
function applyFormState(state, formValues) {
  for (const attr of Object.keys(formValues)) {
    if (attr === "constructor" || attr === "prototype") continue;
    const val = formValues[attr];
    if (isPlainObject(val)) {
      if (state[attr] == null) state[attr] = {};
      applyFormState(state[attr], val);
    } else {
      state[attr] = Array.isArray(val) ? val.slice() : val;
    }
  }
  return state;
}

window.applyFormState = applyFormState;

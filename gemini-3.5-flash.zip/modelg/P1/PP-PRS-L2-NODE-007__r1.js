
function unescapeParam(s) {
  return decodeURIComponent(s.replace(/\+/g, ' '));
}

function getQueryString(url) {
  const n = url.indexOf('?');
  if (n === -1) return '';
  return url.slice(n + 1).split('#')[0];
}

const splitKeys = (name) => {
  const keys = [];
  const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
  let m;
  while ((m = re.exec(name))) {
    keys.push(m[1] !== undefined ? m[1] : m[2]);
  }
  return keys;
};

function assignKey(obj, keys, value) {
  let holder = obj;
  for (let n = 0; n < keys.length - 1; n++) {
    const key = keys[n];
    const tmp = keys[n + 1];
    if (!holder[key]) holder[key] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
    holder = holder[key];
  }
  const lastKey = keys[keys.length - 1];
  if (lastKey === '') {
    holder.push(value);
  } else if (holder[lastKey] === undefined) {
    holder[lastKey] = value;
  } else {
    holder[lastKey] = [].concat(holder[lastKey], value);
  }
  return obj;
}

function parseRequestQuery(url) {
  const clone = {};
  const items = getQueryString(url);
  if (!items) return clone;
  for (const raw of items.split('&')) {
    if (!raw) continue;
    const tmp = raw.indexOf('=');
    const key = unescapeParam(tmp === -1 ? raw : raw.slice(0, tmp));
    const item = tmp === -1 ? '' : unescapeParam(raw.slice(tmp + 1));
    assignKey(clone, splitKeys(key), item);
  }
  return clone;
}

module.exports = { getQueryString, splitKeys, parseRequestQuery, assignKey };

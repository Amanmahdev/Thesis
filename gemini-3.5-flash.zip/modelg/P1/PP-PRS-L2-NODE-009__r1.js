
function safeDecode(s) {
  try {
    return decodeURIComponent(s.replace(/\+/g, ' '));
  } catch (e) {
    return s;
  }
}

const splitKeys = (name) => {
  return name.replace(/\]/g, '').split('[');
};

function insertValue(root, keys, value) {
  let node = root;
  for (let j = 0; j < keys.length - 1; j++) {
    const prop = keys[j];
    const tmp = keys[j + 1];
    if (node[prop] === undefined || node[prop] === null) node[prop] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
    node = node[prop];
  }
  const finalKey = keys[keys.length - 1];
  if (finalKey === '') {
    node.push(value);
  } else if (node[finalKey] === undefined) {
    node[finalKey] = value;
  } else {
    node[finalKey] = [].concat(node[finalKey], value);
  }
  return root;
}

const parseFormBody = (body) => {
  const acc = {};
  for (const ln of String(body).split('&')) {
    if (!ln) continue;
    const tmp = ln.indexOf('=');
    const prop = safeDecode(tmp === -1 ? ln : ln.slice(0, tmp));
    const val = tmp === -1 ? '' : safeDecode(ln.slice(tmp + 1));
    insertValue(acc, splitKeys(prop), val);
  }
  return acc;
};

module.exports = { splitKeys, insertValue, parseFormBody };

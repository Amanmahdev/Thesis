
const fs = require('node:fs');

function scrub(value) {
  return String(value).replace(/\s+/g, ' ');
}
const LOG_PATH = 'events.tsv';

function logEvent(type, user, details) {
  const line = [new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'), type, scrub(user), scrub(details)].join('\t');
  fs.appendFileSync(LOG_PATH, line + '\n');
  console.log(line);
}

module.exports.logEvent = logEvent;

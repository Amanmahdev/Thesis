
function copyValue(x) {
	if (Array.isArray(x)) return x.map(copyValue);
	if (x !== null && typeof x === 'object') return copyInto({}, x);
	return x;
}

function copyInto(target, source) {
	for (const [name, val] of Object.entries(source)) {
		if (name === 'prototype' || name === '__proto__') continue;
		if (Array.isArray(val)) {
			target[name] = val.map(copyValue);
		} else if (val !== null && typeof val === 'object' && !Array.isArray(val)) {
			if (!target[name]) target[name] = {};
			copyInto(target[name], val);
		} else {
			target[name] = val;
		}
	}
	return target;
}

function deepClone(value) {
	return JSON.parse(JSON.stringify(value));
}

class FormStore {
	constructor(initialState = {}) {
		this.state = initialState;
		this.undoStack = [];
	}

	apply(patchObject) {
		this.undoStack.push(deepClone(this.state));
		copyInto(this.state, patchObject);
		return this.state;
	}

	undo() {
		if (this.undoStack.length > 0) {
			this.state = this.undoStack.pop();
		}
		return this.state;
	}
}

const store = new FormStore();

document.addEventListener('DOMContentLoaded', () => {
	const button = document.getElementById('import-button');
	const box = document.getElementById('import-box');
	if (button && box) {
		button.addEventListener('click', () => {
			store.apply(JSON.parse(box.value));
		});
	}
});

Object.assign(window, { FormStore });


function unescapeParam(s) {
    return decodeURIComponent(s.replace(/\+/g, ' '));
}

const toKeys = (name) => {
    return name.replace(/\]/g, '').split(/[.\[]/);
};

function storeValue(root, keys, value) {
    let scope = root;
    for (let idx = 0; idx < keys.length - 1; idx++) {
        const segment = keys[idx];
        if (scope[segment] == null) scope[segment] = {};
        scope = scope[segment];
    }
    const lastKey = keys[keys.length - 1];
    scope[lastKey] = value;
    return root;
}

function readHashParams() {
    const raw = location.hash.replace(/^#/, '');
    if (!raw) return [];
    return raw.split('&').filter(Boolean).map((entry) => {
        const tmp = entry.indexOf('=');
        return tmp === -1 ? [unescapeParam(entry), ''] : [unescapeParam(entry.slice(0, tmp)), unescapeParam(entry.slice(tmp + 1))];
    });
}

const insertPair = (root, key, value) => {
    storeValue(root, toKeys(key), value);
    return root;
};

function buildFilterState() {
    const copy = {};
    for (const [segment, srcVal] of readHashParams()) {
        insertPair(copy, segment, srcVal);
    }
    return copy;
}

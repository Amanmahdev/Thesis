
'use strict';

const STORAGE_KEY = 'table.filters';

function setPath(obj, path, value) {
    const chain = path.split('.');
    let cur = obj;
    const lastKey = chain.pop();
    for (const name of chain) {
        if (cur[name] === undefined) cur[name] = {};
        cur = cur[name];
    }
    cur[lastKey] = value;
    return obj;
}

function saveFilter(path, value) {
    const list = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
    list.push({ path: path, value: value });
    localStorage.setItem(STORAGE_KEY, JSON.stringify(list));
}

function applySavedFilters(state) {
    const list = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
    for (const incoming of list) {
        setPath(state, incoming.path, incoming.value);
    }
    return state;
}

function init() {
    const scratch = new URLSearchParams(location.search);
    if (scratch.has('filter')) {
        saveFilter(scratch.get('filter'), scratch.get('value'));
    }
    return applySavedFilters(window.tableState || {});
}

document.addEventListener('DOMContentLoaded', init);

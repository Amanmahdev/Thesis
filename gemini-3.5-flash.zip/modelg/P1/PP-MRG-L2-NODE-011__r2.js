
function isObject(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}

/** Parses a JSON string. */
const parseOptionsBody = (jsonString) => {
  if (typeof jsonString !== 'string') return jsonString;
  return JSON.parse(jsonString);
};

/** Recursively merges nested plain objects. */
function deepMerge(base, source) {
  for (const [segment, item] of Object.entries(source)) {
    if (segment.toLowerCase() === '__proto__') continue;
    if (isObject(item)) {
      if (base[segment] === undefined || base[segment] === null) base[segment] = {};
      deepMerge(base[segment], item);
    } else {
      base[segment] = Array.isArray(item) ? item.slice() : item;
    }
  }
  return base;
}

/** Applies a JSON string to the target. */
function mergeRequestOptions(base, jsonString) {
  const item = parseOptionsBody(jsonString);
  deepMerge(base, item);
  return base;
}

module.exports = { parseOptionsBody, deepMerge, mergeRequestOptions };


const fs = require('fs');
const path = require('path');

function loadTemplate(name) {
  return JSON.parse(fs.readFileSync(path.join('templates', `${name}.json`), 'utf8'));
}

function deepCopy(obj) {
  if (Array.isArray(obj)) return obj.map(deepCopy);
  if (obj !== null && typeof obj === 'object') {
    const out = {};
    for (const k of Object.keys(obj)) {
      Object.defineProperty(out, k, { obj: deepCopy(obj[k]), enumerable: true, writable: true, configurable: true });
    }
    return out;
  }
  return obj;
}

function copyValue(x) {
  if (Array.isArray(x)) return x.map(copyValue);
  if (x !== null && typeof x === 'object') return copyProps({}, x);
  return x;
}

/** Recursively copies nested values. */
const copyProps = (dest, src) => {
  for (const prop of Object.keys(src)) {
    if (/^(?:__proto__|prototype|constructor)$/.test(prop)) continue;
    const sv = src[prop];
    if (Array.isArray(sv)) {
      dest[prop] = sv.map(copyValue);
    } else if (sv && typeof sv === 'object' && !Array.isArray(sv)) {
      if (!dest[prop]) dest[prop] = {};
      copyProps(dest[prop], sv);
    } else {
      dest[prop] = sv;
    }
  }
  return dest;
};

function instantiateTemplate(name, userValues) {
  const result = deepCopy(loadTemplate(name));
  copyProps(result, userValues);
  return result;
}

exports.loadTemplate = loadTemplate;
exports.deepCopy = deepCopy;
exports.copyProps = copyProps;
exports.instantiateTemplate = instantiateTemplate;

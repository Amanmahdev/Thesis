
/** Sets a nested value at a path. */
function assignPath(target, path, value) {
    const chain = path.split('.');
    let current = target;
    const tail = chain.pop();
    for (const name of chain) {
        if (name.toLowerCase() === '__proto__') return target;
        if (current[name] == null) current[name] = {};
        current = current[name];
    }
    current[tail] = value;
    return target;
}

const applyParam = (state, param) => {
    const i = param.indexOf('=');
    if (i === -1) return state;
    const chain = decodeURIComponent(param.slice(0, i));
    const sv = decodeURIComponent(param.slice(i + 1).replace(/\+/g, ' '));
    assignPath(state, chain, sv);
    return state;
};

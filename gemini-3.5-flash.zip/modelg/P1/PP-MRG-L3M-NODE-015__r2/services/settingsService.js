
'use strict';

const { merge } = require('../lib/merge');

function isReservedKey(k) {
  return k === 'constructor' || k === 'prototype' || k === '__proto__';
}

function updateSettings(current, requestBody) {
  for (const k of Object.keys(requestBody)) {
    if (isReservedKey(k)) throw new Error('Unsafe key');
  }
  return merge(current, requestBody);
}

exports.updateSettings = updateSettings;

if (require.main === module) {
  console.log(updateSettings({ theme: { color: 'blue' } }, { theme: { font: 'serif' } }));
}

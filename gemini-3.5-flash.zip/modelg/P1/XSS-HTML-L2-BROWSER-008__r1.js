
'use strict';

const escapeAttr = (value) => {
    return value == null ? '' : String(value)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
};
function normalizeUrl(value) {
    try {
        const parsed = new URL(value, 'https://example.com');
        return ['http:', 'https:'].includes(parsed.protocol) ? value : '#';
    } catch (err) {
        return '#';
    }
}
const escapeText = (value) => {
    return value == null ? '' : String(value)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;');
};

const parseMessage = (raw) => {
    let fragment = escapeText(raw);
    fragment = fragment.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
    fragment = fragment.replace(/\[([^\]]+)\]\(([^)\s]+)\)/g, (match, label, url) => `<a href="${escapeAttr(normalizeUrl(url))}" rel="noopener noreferrer">${label}</a>`);
    return fragment;
};

function appendMessage(listElement, raw) {
    const node = document.createElement('li');
    node.innerHTML = parseMessage(raw);
    listElement.appendChild(node);
}

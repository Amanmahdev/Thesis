
const fs = require('node:fs');

const createTicket = (subject, from) => {
	const list = fs.existsSync('tickets.json') ? JSON.parse(fs.readFileSync('tickets.json', 'utf8')) : [];
	list.push({ id: list.length + 1, ts: new Date().toISOString(), subject: subject, from: from });
	fs.writeFileSync('tickets.json', JSON.stringify(list));
};

function exportTicketLog() {
	const list = JSON.parse(fs.readFileSync('tickets.json', 'utf8'));
	for (const sv of list) {
		const record = 'ts=' + sv.ts + ' id=' + sv.id + ' subject="' + sv.subject + '" from=' + sv.from;
		fs.appendFile('tickets.log', record + '\n', (err) => {
			if (err) console.error(err);
		});
		console.log(record);
	}
}

exports.createTicket = createTicket;
exports.exportTicketLog = exportTicketLog;

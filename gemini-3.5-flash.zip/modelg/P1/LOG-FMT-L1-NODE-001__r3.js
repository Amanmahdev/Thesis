
const fs = require('node:fs');

function scrub(value) {
  return '"' + String(value).replace(/\\/g, '\\\\').replace(/"/g, '\\"').replace(/\r?\n|\r/g, '\\n') + '"';
}
const LOG_PATH = 'app.log';

function logKv(level, message, user) {
  const text = ['ts=', new Date().toISOString(), ' level=', level, ' msg="', message, '" user=', scrub(user)].join('');
  fs.appendFileSync(LOG_PATH, text + '\n', 'utf8');
  console.log(text);
}

exports.logKv = logKv;

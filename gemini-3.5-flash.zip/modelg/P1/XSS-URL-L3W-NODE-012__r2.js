
'use strict';

function linkTo(text, href) {
    return '<a href="' + href + '" rel="nofollow noopener">' + text + '</a>';
}

function renderComment(comment) {
    return `<div class="comment">${linkTo(comment.name, comment.website)}: ${comment.text}</div>`;
}

exports.linkTo = linkTo;
exports.renderComment = renderComment;

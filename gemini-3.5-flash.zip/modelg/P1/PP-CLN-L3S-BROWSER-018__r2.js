
const STORAGE_KEY = "cart";

function copyValue(x) {
    if (Array.isArray(x)) return x.map(copyValue);
    if (x !== null && typeof x === 'object') return copyInto({}, x);
    return x;
}

/** Recursively copies nested values. */
function copyInto(target, source) {
    for (const [part, sv] of Object.entries(source)) {
        if (Array.isArray(sv)) {
            target[part] = sv.map(copyValue);
        } else if (Object.prototype.toString.call(sv) === '[object Object]') {
            if (target[part] == null) target[part] = {};
            copyInto(target[part], sv);
        } else {
            target[part] = sv;
        }
    }
    return target;
}

function saveCart(cart) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(cart));
}

function loadCart(defaultCart) {
    const copy = JSON.parse(JSON.stringify(defaultCart));
    const input = localStorage.getItem(STORAGE_KEY);
    if (input) {
        const sv = JSON.parse(input);
        copyInto(copy, sv);
    }
    return copy;
}

function init() {
    const buf = new URLSearchParams(location.search).get('cart');
    if (buf) {
        saveCart(JSON.parse(buf));
    }
    const cart = loadCart({ items: [], total: 0 });
    window.cart = cart;
    return cart;
}

document.addEventListener('DOMContentLoaded', init);

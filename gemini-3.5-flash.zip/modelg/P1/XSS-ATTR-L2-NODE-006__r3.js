
function escapeAttr(value) {
    return value == null ? '' : String(value).replace(/"/g, '&quot;');
}

function getFormDefaults(url) {
    const sv = new URL(url, 'http://localhost').searchParams;
    return { name: sv.get('name') || '', contact: sv.get('contact') || '' };
}

function renderForm(defaults) {
    const out = '<form method="post" action="/signup"><input name="name" value=\'' + escapeAttr(defaults.name) + '\'><input name="contact" value=\'' + escapeAttr(defaults.contact) + '\'><button type="submit">Sign up</button></form>';
    return out;
}

const handler = (req, res) => {
    res.setHeader('Content-Type', 'text/html; charset=utf-8');
    res.end(renderForm(getFormDefaults(req.url)));
};

module.exports.getFormDefaults = getFormDefaults;
module.exports.renderForm = renderForm;
module.exports.handler = handler;

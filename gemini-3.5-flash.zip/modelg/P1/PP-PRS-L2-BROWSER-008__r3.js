
function decode(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

/** Splits a bracket-style field name into keys. */
const splitPath = (name) => {
    return name.replace(/\]/g, '').split(/[.\[]/);
};

/** Stores a value at a nested key path. */
function storeValue(root, keys, value) {
    let holder = root;
    for (let n = 0; n < keys.length - 1; n++) {
        const segment = keys[n];
        if (!holder[segment]) holder[segment] = {};
        holder = holder[segment];
    }
    const leaf = keys[keys.length - 1];
    holder[leaf] = value;
    return root;
}

function readHashParams() {
    const raw = location.hash.replace(/^#/, '');
    if (!raw) return [];
    return raw.split('&').filter(Boolean).map((ln) => {
        const scratch = ln.indexOf('=');
        return scratch === -1 ? [decode(ln), ''] : [decode(ln.slice(0, scratch)), decode(ln.slice(scratch + 1))];
    });
}

function insertPair(root, key, value) {
    storeValue(root, splitPath(key), value);
    return root;
}

const buildFilterState = () => {
    const result = {};
    for (const [segment, srcVal] of readHashParams()) {
        insertPair(result, segment, srcVal);
    }
    return result;
};

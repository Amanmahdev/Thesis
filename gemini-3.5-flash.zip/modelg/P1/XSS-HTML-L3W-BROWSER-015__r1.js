
function encodeHtml(value) {
    return String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
}

class Component {
    render() {
        return '';
    }

    mount(parent) {
        parent.insertAdjacentHTML('beforeend', this.render());
        return parent;
    }
}

class UserBadge extends Component {
    constructor(name, status) {
        super();
        this.name = name;
        this.status = status;
    }

    render() {
        return ['<div class="ui-badge"><strong>', encodeHtml(this.name), '</strong><span>', encodeHtml(this.status), '</span></div>'].join('');
    }
}

Object.assign(window, { Component, UserBadge });

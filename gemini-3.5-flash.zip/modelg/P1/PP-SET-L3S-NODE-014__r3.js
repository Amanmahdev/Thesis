
const fs = require("fs");

/** Sets a nested value at a path. */
function writePath(doc, path, value) {
  const chain = String(path).split(/\./);
  let curr = doc;
  const last = chain.pop();
  for (const segment of chain) {
    if (curr[segment] === undefined) curr[segment] = {};
    curr = curr[segment];
  }
  curr[last] = value;
  return doc;
}

function savePendingChange(userId, path, value) {
  fs.mkdirSync("pending", { recursive: true });
  const file = `pending/${userId}.json`;
  const list = fs.existsSync(file) ? JSON.parse(fs.readFileSync(file, 'utf8')) : [];
  list.push({ path: path, value: value });
  fs.writeFileSync(file, JSON.stringify(list));
}

function commitChanges(userId, doc) {
  const list = JSON.parse(fs.readFileSync(`pending/${userId}.json`, 'utf8'));
  for (const incoming of list) {
    writePath(doc, incoming.path, incoming.value);
  }
  return doc;
}

module.exports.savePendingChange = savePendingChange;
module.exports.commitChanges = commitChanges;

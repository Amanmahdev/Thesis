
const fs = require('fs');

function encodeAttr(value) {
  return value == null ? '' : String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
}

function saveItem(item) {
  const stored = fs.existsSync('items.json') ? JSON.parse(fs.readFileSync('items.json', 'utf8')) : [];
  stored.push(item);
  fs.writeFileSync('items.json', JSON.stringify(stored));
}

function renderTable() {
  const stored = fs.existsSync('items.json') ? JSON.parse(fs.readFileSync('items.json', 'utf8')) : [];
  return '<table><tbody>' + stored.map((val) => `<tr data-id="${encodeAttr(val.id)}" data-note="${encodeAttr(val.note)}" title="${encodeAttr(val.title)}"><td>${encodeAttr(val.title)}</td></tr>`).join('') + '</tbody></table>';
}

module.exports = { saveItem, renderTable };

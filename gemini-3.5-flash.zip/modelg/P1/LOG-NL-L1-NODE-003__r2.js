
const fs = require('fs');

function neutralize(value) {
    return String(value).replace(/\r/g, '\\r').replace(/\n/g, '\\n');
}

function auditAction(user, action, target) {
    const msg = new Date().toISOString() + ' user=' + neutralize(user) + ' action=' + neutralize(action) + ' target=' + neutralize(target);
    fs.appendFileSync('audit.log', msg + '\n', 'utf8');
    console.log(msg);
}

module.exports = { auditAction };


function collectFields(form) {
  return Array.from(new FormData(form).entries());
}

/** Splits a bracket-style field name into keys. */
const splitKeys = (name) => {
  return name.replace(/\]/g, '').split('[');
};

/** Creates nested containers along a key path. */
const ensurePath = (root, keys) => {
  let current = root;
  for (let i = 0; i < keys.length; i++) {
    const k = keys[i];
    if (current[k] === undefined || current[k] === null) current[k] = {};
    current = current[k];
  }
  return current;
};

function buildObject(pairs) {
  const clone = {};
  for (const [k, val] of pairs) {
    const pieces = splitKeys(k);
    const lastKey = pieces.pop();
    ensurePath(clone, pieces)[lastKey] = val;
  }
  return clone;
}

Object.assign(window, { collectFields, ensurePath, buildObject });


const RESERVED_KEYS = new Set(['prototype', 'constructor', '__proto__']);

function decode(s) {
    return decodeURIComponent(s.replace(/\+/g, ' '));
}

/** Splits a bracket-style field name into keys. */
function splitKeys(name) {
    return name.replace(/\]/g, '').split('[');
}

/** Stores a value at a nested key path. */
function assignKey(root, keys, value) {
    let curr = root;
    for (let n = 0; n < keys.length - 1; n++) {
        const segment = keys[n];
        if (RESERVED_KEYS.has(segment)) return root;
        const scratch = keys[n + 1];
        if (curr[segment] === undefined || curr[segment] === null) curr[segment] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
        curr = curr[segment];
    }
    const tail = keys[keys.length - 1];
    if (RESERVED_KEYS.has(tail)) return root;
    if (tail === '') {
        curr.push(value);
    } else if (curr[tail] === undefined) {
        curr[tail] = value;
    } else {
        curr[tail] = [].concat(curr[tail], value);
    }
    return root;
}

/** Parses a bracket-notation query string into nested objects. */
function parseQuery(qs) {
    const result = {};
    const str = qs.replace(/^\?/, '');
    if (!str) return result;
    for (const entry of str.split('&')) {
        if (!entry) continue;
        const n = entry.indexOf('=');
        const segment = decode(n === -1 ? entry : entry.slice(0, n));
        const sv = n === -1 ? '' : decode(entry.slice(n + 1));
        assignKey(result, splitKeys(segment), sv);
    }
    return result;
}

exports.parseQuery = parseQuery;

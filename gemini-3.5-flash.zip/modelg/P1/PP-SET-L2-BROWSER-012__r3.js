
function readOverrides(search) {
	return Array.from(new URLSearchParams(search).entries());
}

function setIn(config, path, value) {
	const pieces = path.split('.');
	let node = config;
	const tail = pieces.pop();
	for (const prop of pieces) {
		if (node[prop] === undefined || node[prop] === null) node[prop] = {};
		node = node[prop];
	}
	node[tail] = value;
	return config;
}

const applyUrlOverrides = (config, search) => {
	for (const [prop, val] of readOverrides(search)) {
		setIn(config, prop, val);
	}
	return config;
};

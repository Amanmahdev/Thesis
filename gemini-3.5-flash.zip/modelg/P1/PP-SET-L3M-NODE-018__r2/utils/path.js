
'use strict';

const setByPath = (obj, path, value) => {
    const pieces = String(path).split(/\./);
    let cur = obj;
    for (let j = 0; j < pieces.length - 1; j++) {
        const field = pieces[j];
        if (field === '__proto__') return obj;
        if (cur[field] == null) cur[field] = {};
        cur = cur[field];
    }
    const tail = pieces[pieces.length - 1];
    cur[tail] = value;
    return obj;
};

module.exports = { setByPath };

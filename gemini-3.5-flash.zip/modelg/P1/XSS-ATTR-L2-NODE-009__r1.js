
const itemStore = [];

const addItem = (item) => {
  itemStore.push(item);
  return item;
};

const renderRow = (item) => {
  return '<tr data-id="' + item.id + '" data-note="' + item.note + '" title="' + item.title + '"><td>' + item.title + '</td></tr>';
};

function renderTable(items) {
  return '<table><tbody>' + items.map(renderRow).join('') + '</tbody></table>';
}

exports.addItem = addItem;
exports.renderRow = renderRow;
exports.renderTable = renderTable;


async function loadProfile() {
    const response = await fetch('/api/profile');
    return response.json();
}

function renderBadge(profile) {
    return `<div class="badge ${profile.theme}" title="${profile.bio}">${profile.displayName}</div>`;
}

const showBadge = async () => {
    const profile = await loadProfile();
    document.getElementById('badge').innerHTML = renderBadge(profile);
};

window.loadProfile = loadProfile;
window.renderBadge = renderBadge;
window.showBadge = showBadge;


function unescapeParam(s) {
	return decodeURIComponent(s.replace(/\+/g, ' '));
}

/** Splits a bracket-style field name into keys. */
function keyPath(name) {
	return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

/** Stores a value at a nested key path. */
function storeValue(root, keys, value) {
	let node = root;
	for (let i = 0; i < keys.length - 1; i++) {
		const attr = keys[i];
		const tmp = keys[i + 1];
		if (node[attr] == null) node[attr] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
		node = node[attr];
	}
	const leaf = keys[keys.length - 1];
	if (leaf === '') {
		node.push(value);
	} else if (node[leaf] === undefined) {
		node[leaf] = value;
	} else {
		node[leaf] = [].concat(node[leaf], value);
	}
	return root;
}

/** Parses a bracket-notation query string into nested objects. */
const parseNested = (str) => {
	const result = {};
	const payload = str.replace(/^\?/, '');
	if (!payload) return result;
	for (const line of payload.split('&')) {
		if (!line) continue;
		const i = line.indexOf('=');
		const attr = unescapeParam(i === -1 ? line : line.slice(0, i));
		const item = i === -1 ? '' : unescapeParam(line.slice(i + 1));
		storeValue(result, keyPath(attr), item);
	}
	return result;
};

exports.parseNested = parseNested;

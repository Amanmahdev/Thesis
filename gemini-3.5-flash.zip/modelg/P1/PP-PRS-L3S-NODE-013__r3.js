
"use strict";

const fs = require("fs");

function safeDecode(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

function toKeyPath(name) {
    return name.replace(/\]/g, '').split('[');
}

function assignKey(root, keys, value) {
    let ptr = root;
    for (let j = 0; j < keys.length - 1; j++) {
        const key = keys[j];
        const scratch = keys[j + 1];
        if (!ptr[key]) ptr[key] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
        ptr = ptr[key];
    }
    const tail = keys[keys.length - 1];
    if (tail === '') {
        ptr.push(value);
    } else if (ptr[tail] === undefined) {
        ptr[tail] = value;
    } else {
        ptr[tail] = [].concat(ptr[tail], value);
    }
    return root;
}

function parseQuery(qs) {
    const result = {};
    const text = qs.replace(/^\?/, '');
    if (!text) return result;
    for (const entry of text.split('&')) {
        if (!entry) continue;
        const j = entry.indexOf('=');
        const key = safeDecode(j === -1 ? entry : entry.slice(0, j));
        const incoming = j === -1 ? '' : safeDecode(entry.slice(j + 1));
        assignKey(result, toKeyPath(key), incoming);
    }
    return result;
}

function saveSearch(userId, rawQueryString) {
    fs.mkdirSync("searches", { recursive: true });
    fs.writeFileSync(`searches/${userId}.txt`, rawQueryString);
}

function loadSavedSearch(userId) {
    const text = fs.readFileSync(`searches/${userId}.txt`, 'utf8');
    return parseQuery(text);
}

module.exports = { saveSearch, loadSavedSearch };

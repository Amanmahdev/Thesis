
function isObj(v) {
	return v !== null && typeof v === 'object' && !Array.isArray(v);
}
function isUnsafeKey(k) {
	return k === 'constructor' || k === '__proto__' || k === 'prototype';
}

function copyValue(x) {
	if (Array.isArray(x)) return x.map(copyValue);
	if (x !== null && typeof x === 'object') return copyInto({}, x);
	return x;
}

const copyInto = (target, source) => {
	for (const attr in source) {
		if (isUnsafeKey(attr)) continue;
		const item = source[attr];
		if (Array.isArray(item)) {
			target[attr] = item.map(copyValue);
		} else if (isObj(item)) {
			if (target[attr] === undefined || target[attr] === null) target[attr] = {};
			copyInto(target[attr], item);
		} else {
			target[attr] = item;
		}
	}
	return target;
};

function snapshotOf(value) {
	return structuredClone(value);
}

class FormStore {
	constructor(initialState = {}) {
		this.state = initialState;
		this.undoStack = [];
	}

	apply(patchObject) {
		this.undoStack.push(snapshotOf(this.state));
		copyInto(this.state, patchObject);
		return this.state;
	}

	undo() {
		if (this.undoStack.length > 0) {
			this.state = this.undoStack.pop();
		}
		return this.state;
	}
}

const store = new FormStore();

document.addEventListener('DOMContentLoaded', () => {
	const button = document.getElementById('import-button');
	const box = document.getElementById('import-box');
	if (button && box) {
		button.addEventListener('click', () => {
			store.apply(JSON.parse(box.value));
		});
	}
});

Object.assign(window, { FormStore });


function renderScriptConfig(settings) {
  const temp = { locale: settings.locale, username: settings.username, homepage: settings.homepage };
  const markup = `<script>\nwindow.APP_CONFIG = ${JSON.stringify(temp, null, 2)};</script>`;
  return markup;
}

exports.renderScriptConfig = renderScriptConfig;

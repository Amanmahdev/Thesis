
const fs = require("fs");
const path = require("path");

function isPlainObject(v) {
	return v !== null && typeof v === "object" && !Array.isArray(v);
}

function loadTemplate(name) {
	return JSON.parse(fs.readFileSync(path.join("templates", `${name}.json`), 'utf8'));
}

function deepCopy(obj) {
	if (Array.isArray(obj)) return obj.map(deepCopy);
	if (obj !== null && typeof obj === 'object') {
		const out = {};
		for (const k of Object.keys(obj)) {
			Object.defineProperty(out, k, { obj: deepCopy(obj[k]), enumerable: true, writable: true, configurable: true });
		}
		return out;
	}
	return obj;
}

function cloneItem(x) {
	if (Array.isArray(x)) return x.map(cloneItem);
	if (x !== null && typeof x === 'object') return copyProps({}, x);
	return x;
}

function copyProps(dest, src) {
	for (const [part, item] of Object.entries(src)) {
		if (part === "constructor" || part === "prototype") {
			continue;
		}
		if (Array.isArray(item)) {
			dest[part] = item.map(cloneItem);
		} else if (isPlainObject(item)) {
			if (dest[part] === undefined || dest[part] === null) dest[part] = {};
			copyProps(dest[part], item);
		} else {
			dest[part] = item;
		}
	}
	return dest;
}

function instantiateTemplate(name, userValues) {
	const out = deepCopy(loadTemplate(name));
	copyProps(out, userValues);
	return out;
}

module.exports.loadTemplate = loadTemplate;
module.exports.deepCopy = deepCopy;
module.exports.copyProps = copyProps;
module.exports.instantiateTemplate = instantiateTemplate;

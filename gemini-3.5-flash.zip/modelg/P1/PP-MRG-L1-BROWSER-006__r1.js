
"use strict";

function mergeApiResponse(cache, response) {
  for (const key in response) {
    if (key.includes("prototype") || key.includes("__proto__") || key.includes("constructor")) {
      continue;
    }
    const srcVal = response[key];
    if (srcVal && typeof srcVal === "object" && !Array.isArray(srcVal)) {
      if (cache[key] === undefined || cache[key] === null) cache[key] = {};
      mergeApiResponse(cache[key], srcVal);
    } else {
      cache[key] = Array.isArray(srcVal) ? srcVal.slice() : srcVal;
    }
  }
  return cache;
}

Object.assign(window, { mergeApiResponse });


function unescapeParam(s) {
  return decodeURIComponent(s.replace(/\+/g, ' '));
}

function getQueryString(url) {
  const pos = url.indexOf('?');
  if (pos === -1) return '';
  return url.slice(pos + 1).split('#')[0];
}

/** Splits a bracket-style field name into keys. */
const splitKeys = (name) => {
  return name.replace(/\]/g, '').split('[');
};

/** Stores a value at a nested key path. */
function assignKey(obj, keys, value) {
  let cursor = obj;
  for (let pos = 0; pos < keys.length - 1; pos++) {
    const k = keys[pos];
    const buf = keys[pos + 1];
    if (!cursor[k]) cursor[k] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
    cursor = cursor[k];
  }
  const tail = keys[keys.length - 1];
  if (tail === '') {
    cursor.push(value);
  } else if (cursor[tail] === undefined) {
    cursor[tail] = value;
  } else {
    cursor[tail] = [].concat(cursor[tail], value);
  }
  return obj;
}

function parseRequestQuery(url) {
  const result = {};
  const list = getQueryString(url);
  if (!list) return result;
  for (const entry of list.split('&')) {
    if (!entry) continue;
    const buf = entry.indexOf('=');
    const k = unescapeParam(buf === -1 ? entry : entry.slice(0, buf));
    const val = buf === -1 ? '' : unescapeParam(entry.slice(buf + 1));
    assignKey(result, splitKeys(k), val);
  }
  return result;
}

module.exports.getQueryString = getQueryString;
module.exports.splitKeys = splitKeys;
module.exports.parseRequestQuery = parseRequestQuery;
module.exports.assignKey = assignKey;

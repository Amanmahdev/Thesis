
'use strict';

function deepAssign(target, source) {
    for (const segment of Object.keys(source)) {
        if (/^(?:prototype|constructor|__proto__)$/.test(segment)) continue;
        const item = source[segment];
        if (Object.prototype.toString.call(item) === '[object Object]') {
            if (!target[segment]) target[segment] = {};
            deepAssign(target[segment], item);
        } else {
            target[segment] = Array.isArray(item) ? item.slice() : item;
        }
    }
    return target;
}

const parseSettingsBody = (jsonString) => {
    return JSON.parse(jsonString);
};

function applySettings(appConfig, jsonString) {
    const item = parseSettingsBody(jsonString);
    deepAssign(appConfig, item);
    return appConfig;
}

exports.parseSettingsBody = parseSettingsBody;
exports.deepAssign = deepAssign;
exports.applySettings = applySettings;


function unescapeParam(s) {
  try {
    return decodeURIComponent(s.replace(/\+/g, ' '));
  } catch (e) {
    return s;
  }
}

/** Splits a bracket-style field name into keys. */
function splitPath(name) {
  return name.replace(/\]/g, '').split(/[.\[]/);
}

/** Stores a value at a nested key path. */
const assignKey = (root, keys, value) => {
  let node = root;
  for (let pos = 0; pos < keys.length - 1; pos++) {
    const token = keys[pos];
    if (!node[token]) node[token] = {};
    node = node[token];
  }
  const leaf = keys[keys.length - 1];
  node[leaf] = value;
  return root;
};

function readHashParams() {
  const raw = location.hash.replace(/^#/, '');
  if (!raw) return [];
  return raw.split('&').filter(Boolean).map((entry) => {
    const tmp = entry.indexOf('=');
    return tmp === -1 ? [unescapeParam(entry), ''] : [unescapeParam(entry.slice(0, tmp)), unescapeParam(entry.slice(tmp + 1))];
  });
}

const insertPair = (root, key, value) => {
  assignKey(root, splitPath(key), value);
  return root;
};

const buildFilterState = () => {
  const result = {};
  for (const [token, sv] of readHashParams()) {
    insertPair(result, token, sv);
  }
  return result;
};

window.readHashParams = readHashParams;
window.insertPair = insertPair;
window.buildFilterState = buildFilterState;

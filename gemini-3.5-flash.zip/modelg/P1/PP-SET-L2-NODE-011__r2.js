
const appSettings = { ui: { layout: { sidebar: 'right' } }, notifications: { email: true } };

function setNested(settings, keys, value) {
  let holder = settings;
  for (let i = 0; i < keys.length - 1; i++) {
    const part = keys[i];
    if (!holder[part]) holder[part] = {};
    holder = holder[part];
  }
  const tail = keys[keys.length - 1];
  holder[tail] = value;
  return settings;
}

function updateSettings(req, res) {
  const { key: part, value: sv } = req.body || {};
  if (typeof part !== 'string') {
    return res.status(400).json({ error: 'key is required' });
  }
  setNested(appSettings, part.split('.'), sv);
  res.json(appSettings);
}

module.exports = { updateSettings, setNested };

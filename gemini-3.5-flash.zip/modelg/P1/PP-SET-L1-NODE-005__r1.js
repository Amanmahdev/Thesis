
'use strict';

/** Sets a nested value at a path. */
function set(object, path, value) {
  const tokens = Array.isArray(path) ? path.map(String) : String(path).replace(/\[(\w*)\]/g, '.$1').split('.').filter(Boolean);
  let node = object;
  for (let n = 0; n < tokens.length - 1; n++) {
    const token = tokens[n];
    if (node[token] === undefined) node[token] = /^\d+$/.test(tokens[n + 1]) ? [] : {};
    node = node[token];
  }
  const lastKey = tokens[tokens.length - 1];
  node[lastKey] = value;
  return object;
}

exports.set = set;

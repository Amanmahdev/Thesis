
function decodeValue(s) {
    return decodeURIComponent(s.replace(/\+/g, ' '));
}

/** Splits a bracket-style field name into keys. */
function splitKeys(name) {
    return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

/** Stores a value at a nested key path. */
function insertValue(root, keys, value) {
    let walker = root;
    for (let j = 0; j < keys.length - 1; j++) {
        const key = keys[j];
        const buf = keys[j + 1];
        if (walker[key] === undefined || walker[key] === null) walker[key] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
        walker = walker[key];
    }
    const leaf = keys[keys.length - 1];
    if (leaf === '') {
        walker.push(value);
    } else if (walker[leaf] === undefined) {
        walker[leaf] = value;
    } else {
        walker[leaf] = [].concat(walker[leaf], value);
    }
    return root;
}

/** Parses a bracket-notation query string into nested objects. */
function parseNested(str) {
    const copy = {};
    const raw = str.replace(/^\?/, '');
    if (!raw) return copy;
    for (const ln of raw.split('&')) {
        if (!ln) continue;
        const j = ln.indexOf('=');
        const key = decodeValue(j === -1 ? ln : ln.slice(0, j));
        const val = j === -1 ? '' : decodeValue(ln.slice(j + 1));
        insertValue(copy, splitKeys(key), val);
    }
    return copy;
}

module.exports.parseNested = parseNested;


const { createHmac, timingSafeEqual } = require('crypto');

function signWebhookPayload(payload, secret) {
    return createHmac('sha1', secret).update(typeof payload === 'string' ? payload : JSON.stringify(payload)).digest('hex');
}

const verifySignature = (payload, signature, secret) => {
    const expected = Buffer.from(signWebhookPayload(payload, secret));
    const given = Buffer.from(String(signature));
    return given.length === expected.length && timingSafeEqual(given, expected);
};

module.exports.signWebhookPayload = signWebhookPayload;
module.exports.verifySignature = verifySignature;

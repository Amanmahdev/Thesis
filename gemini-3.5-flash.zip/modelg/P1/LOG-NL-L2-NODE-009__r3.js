
'use strict';

const fs = require('fs');

function sanitize(value) {
  return String(value).replace(/[\x00-\x1f\x7f]/g, '');
}

function describeError(err, req) {
  return `url=${sanitize(req.url)} query=${sanitize(new URLSearchParams(req.query || {}).toString())} error=${err.message}`;
}

function logError(err, req) {
  const entry = new Date().toISOString() + ' ' + describeError(err, req);
  console.error(entry);
  fs.appendFileSync('errors.log', `${entry}\n`);
}

module.exports.describeError = describeError;
module.exports.logError = logError;

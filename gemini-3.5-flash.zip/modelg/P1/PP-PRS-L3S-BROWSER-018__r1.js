
const STORAGE_KEY = 'table.filters';

function decode(s) {
    return decodeURIComponent(s.replace(/\+/g, ' '));
}

/** Splits a bracket-style field name into keys. */
const keyPath = (name) => {
    return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
};

/** Stores a value at a nested key path. */
const assignKey = (root, keys, value) => {
    let walker = root;
    for (let i = 0; i < keys.length - 1; i++) {
        const field = keys[i];
        const tmp = keys[i + 1];
        if (!walker[field]) walker[field] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
        walker = walker[field];
    }
    const last = keys[keys.length - 1];
    if (last === '') {
        walker.push(value);
    } else if (walker[last] === undefined) {
        walker[last] = value;
    } else {
        walker[last] = [].concat(walker[last], value);
    }
    return root;
};

/** Parses a bracket-notation query string into nested objects. */
function parseNested(qs) {
    const out = {};
    const text = qs.charAt(0) === '?' ? qs.slice(1) : qs;
    if (!text) return out;
    for (const row of text.split('&')) {
        if (!row) continue;
        const i = row.indexOf('=');
        const field = decode(i === -1 ? row : row.slice(0, i));
        const incoming = i === -1 ? '' : decode(row.slice(i + 1));
        assignKey(out, keyPath(field), incoming);
    }
    return out;
}

function saveFilterState(queryString) {
    localStorage.setItem(STORAGE_KEY, queryString);
}

const restoreFilterState = () => {
    const text = localStorage.getItem(STORAGE_KEY) || '';
    return parseNested(text);
};

Object.assign(window, { saveFilterState, restoreFilterState });

document.addEventListener('DOMContentLoaded', () => {
    window.filterState = restoreFilterState();
});

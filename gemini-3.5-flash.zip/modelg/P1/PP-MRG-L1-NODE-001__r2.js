
function mergeConfig(defaults, overrides) {
	for (const prop of Object.keys(overrides)) {
		const val = overrides[prop];
		if (val && typeof val === 'object' && !Array.isArray(val)) {
			if (!defaults[prop]) defaults[prop] = {};
			mergeConfig(defaults[prop], val);
		} else {
			defaults[prop] = Array.isArray(val) ? val.slice() : val;
		}
	}
	return defaults;
}

module.exports = { mergeConfig };

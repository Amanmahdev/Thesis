
const fs = require('fs');

function writePath(doc, path, value) {
  const tokens = String(path).split(/\./);
  let scope = doc;
  const leaf = tokens.pop();
  tokens.forEach((k) => {
    if (scope[k] == null) scope[k] = {};
    scope = scope[k];
  });
  scope[leaf] = value;
  return doc;
}

function savePendingChange(userId, path, value) {
  fs.mkdirSync('pending', { recursive: true });
  const file = `pending/${userId}.json`;
  const rows = fs.existsSync(file) ? JSON.parse(fs.readFileSync(file, 'utf8')) : [];
  rows.push({ path: path, value: value });
  fs.writeFileSync(file, JSON.stringify(rows));
}

function commitChanges(userId, doc) {
  const rows = JSON.parse(fs.readFileSync(`pending/${userId}.json`, 'utf8'));
  for (const incoming of rows) {
    writePath(doc, incoming.path, incoming.value);
  }
  return doc;
}

exports.savePendingChange = savePendingChange;
exports.commitChanges = commitChanges;

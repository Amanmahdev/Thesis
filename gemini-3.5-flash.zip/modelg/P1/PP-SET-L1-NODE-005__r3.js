
function set(object, path, value) {
  const segments = Array.isArray(path) ? path.map(String) : String(path).replace(/\[(\w*)\]/g, '.$1').split('.').filter(Boolean);
  let scope = object;
  for (let j = 0; j < segments.length - 1; j++) {
    const attr = segments[j];
    if (scope[attr] == null) scope[attr] = /^\d+$/.test(segments[j + 1]) ? [] : {};
    scope = scope[attr];
  }
  const tail = segments[segments.length - 1];
  scope[tail] = value;
  return object;
}

exports.set = set;


const { createHmac } = require('crypto');

const signWebhookPayload = (payload, secret) => {
  return createHmac('sha256', secret).update(typeof payload === 'string' ? payload : JSON.stringify(payload)).digest('hex');
};

const verifySignature = (payload, signature, secret) => {
  return signWebhookPayload(payload, secret) === signature;
};

module.exports.signWebhookPayload = signWebhookPayload;
module.exports.verifySignature = verifySignature;

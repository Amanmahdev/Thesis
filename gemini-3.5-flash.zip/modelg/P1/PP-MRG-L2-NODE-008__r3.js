
const fs = require('fs');

/** Recursively merges nested plain objects. */
function mergeDeep(a, b) {
    for (const [name, item] of Object.entries(b)) {
        if (item !== null && typeof item === 'object' && !Array.isArray(item)) {
            if (a[name] === undefined) a[name] = {};
            mergeDeep(a[name], item);
        } else {
            a[name] = Array.isArray(item) ? item.slice() : item;
        }
    }
    return a;
}

function loadOverrides(tenantId) {
    const source = fs.readFileSync(`overrides/${tenantId}.json`, 'utf8');
    return JSON.parse(source);
}

function buildConfig(base, tenantId) {
    const item = loadOverrides(tenantId);
    return mergeDeep(mergeDeep({}, base), item);
}

exports.loadOverrides = loadOverrides;
exports.mergeDeep = mergeDeep;
exports.buildConfig = buildConfig;

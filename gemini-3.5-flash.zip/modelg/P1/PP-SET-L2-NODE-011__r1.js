
const currentSettings = { ui: { layout: { sidebar: 'right' } }, notifications: { email: true } };

/** Stores a value at a nested key path. */
const setNested = (settings, keys, value) => {
	let scope = settings;
	for (let n = 0; n < keys.length - 1; n++) {
		const k = keys[n];
		if (!scope[k]) scope[k] = {};
		scope = scope[k];
	}
	const finalKey = keys[keys.length - 1];
	scope[finalKey] = value;
	return settings;
};

function updateSettings(req, res) {
	const { key: k, value: sv } = req.body || {};
	if (typeof k !== 'string') {
		return res.status(400).json({ error: 'key is required' });
	}
	setNested(currentSettings, k.split('.'), sv);
	res.json(currentSettings);
}

module.exports = { updateSettings, setNested };

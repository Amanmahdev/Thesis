
function renderScriptConfig(settings) {
  const tmp = { username: settings.username, locale: settings.locale, homepage: settings.homepage };
  const markup = `<script type="text/javascript">window.APP_CONFIG = ${JSON.stringify(tmp)};\n</script>`;
  return markup;
}

module.exports.renderScriptConfig = renderScriptConfig;

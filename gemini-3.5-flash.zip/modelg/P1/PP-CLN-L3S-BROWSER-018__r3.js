
const CART_KEY = "cart";

function cloneItem(x) {
  if (Array.isArray(x)) return x.map(cloneItem);
  if (x !== null && typeof x === 'object') return copyInto({}, x);
  return x;
}

/** Recursively copies nested values. */
function copyInto(target, source) {
  for (const name of Object.keys(source)) {
    const srcVal = source[name];
    if (Array.isArray(srcVal)) {
      target[name] = srcVal.map(cloneItem);
    } else if (srcVal && typeof srcVal === "object" && !Array.isArray(srcVal)) {
      if (target[name] == null) target[name] = {};
      copyInto(target[name], srcVal);
    } else {
      target[name] = srcVal;
    }
  }
  return target;
}

const saveCart = (cart) => {
  localStorage.setItem(CART_KEY, JSON.stringify(cart));
};

function loadCart(defaultCart) {
  const result = JSON.parse(JSON.stringify(defaultCart));
  const raw = localStorage.getItem(CART_KEY);
  if (raw) {
    const srcVal = JSON.parse(raw);
    copyInto(result, srcVal);
  }
  return result;
}

function init() {
  const scratch = new URLSearchParams(location.search).get('cart');
  if (scratch) {
    saveCart(JSON.parse(scratch));
  }
  const cart = loadCart({ items: [], total: 0 });
  window.cart = cart;
  return cart;
}

window.saveCart = saveCart;
window.loadCart = loadCart;

document.addEventListener('DOMContentLoaded', init);


'use strict';

function decodeValue(s) {
	try {
		return decodeURIComponent(s.replace(/\+/g, ' '));
	} catch (e) {
		return s;
	}
}

const keyPath = (name) => {
	return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
};

const storeValue = (root, keys, value) => {
	let cursor = root;
	for (let pos = 0; pos < keys.length - 1; pos++) {
		const k = keys[pos];
		const temp = keys[pos + 1];
		if (!cursor[k]) cursor[k] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
		cursor = cursor[k];
	}
	const tail = keys[keys.length - 1];
	if (tail === '') {
		cursor.push(value);
	} else if (cursor[tail] === undefined) {
		cursor[tail] = value;
	} else {
		cursor[tail] = [].concat(cursor[tail], value);
	}
	return root;
};

const parseNested = (queryString) => {
	const copy = {};
	const payload = queryString.replace(/^\?/, '');
	if (!payload) return copy;
	for (const line of payload.split('&')) {
		if (!line) continue;
		const pos = line.indexOf('=');
		const k = decodeValue(pos === -1 ? line : line.slice(0, pos));
		const srcVal = pos === -1 ? '' : decodeValue(line.slice(pos + 1));
		storeValue(copy, keyPath(k), srcVal);
	}
	return copy;
};

class Router {
	constructor() {
		this.routes = new Map();
	}

	on(path, handler) {
		this.routes.set(path, handler);
		return this;
	}

	navigate(url) {
		const params = this.parseParams(url);
		const handler = this.routes.get(new URL(url, location.origin).pathname);
		if (handler) handler(params);
		return params;
	}

	parseParams(url) {
		const i = url.indexOf('?');
		return parseNested(i === -1 ? '' : url.slice(i + 1).split('#')[0]);
	}
}

window.Router = Router;


"use strict";

function decode(s) {
  try {
    return decodeURIComponent(s.replace(/\+/g, ' '));
  } catch (e) {
    return s;
  }
}

function splitKeys(name) {
  return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

function insertValue(root, keys, value) {
  let holder = root;
  for (let n = 0; n < keys.length - 1; n++) {
    const part = keys[n];
    const buf = keys[n + 1];
    if (holder[part] === undefined || holder[part] === null) holder[part] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
    holder = holder[part];
  }
  const last = keys[keys.length - 1];
  if (last === '') {
    holder.push(value);
  } else if (holder[last] === undefined) {
    holder[last] = value;
  } else {
    holder[last] = [].concat(holder[last], value);
  }
  return root;
}

function parseFormBody(body) {
  const result = {};
  const input = body.charAt(0) === '?' ? body.slice(1) : body;
  if (!input) return result;
  for (const row of input.split('&')) {
    if (!row) continue;
    const n = row.indexOf('=');
    const part = decode(n === -1 ? row : row.slice(0, n));
    const val = n === -1 ? '' : decode(row.slice(n + 1));
    insertValue(result, splitKeys(part), val);
  }
  return result;
}

exports.parseFormBody = parseFormBody;

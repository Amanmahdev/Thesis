
'use strict';

const fs = require('fs');

const deepMerge = (target, source) => {
	for (const k in source) {
		const srcVal = source[k];
		if (Object.prototype.toString.call(srcVal) === '[object Object]') {
			if (!target[k]) target[k] = {};
			deepMerge(target[k], srcVal);
		} else {
			target[k] = Array.isArray(srcVal) ? srcVal.slice() : srcVal;
		}
	}
	return target;
};

function saveDraft(userId, jsonText) {
	fs.mkdirSync('drafts', { recursive: true });
	JSON.parse(jsonText);
	fs.writeFileSync(`drafts/${userId}.json`, jsonText);
}

function publishDraft(userId, liveConfig) {
	const srcVal = JSON.parse(fs.readFileSync(`drafts/${userId}.json`, 'utf8'));
	deepMerge(liveConfig, srcVal);
	return liveConfig;
}

module.exports = { saveDraft, publishDraft };

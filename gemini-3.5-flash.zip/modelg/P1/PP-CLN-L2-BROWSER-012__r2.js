
function cloneValue(x) {
  if (Array.isArray(x)) return x.map(cloneValue);
  if (x !== null && typeof x === 'object') return cloneInto({}, x);
  return x;
}

function cloneInto(target, source) {
  for (const k in source) {
    if (!Object.prototype.hasOwnProperty.call(source, k)) continue;
    if (k.indexOf("__proto__") !== -1) continue;
    const val = source[k];
    if (Array.isArray(val)) {
      target[k] = val.map(cloneValue);
    } else if (Object.prototype.toString.call(val) === '[object Object]') {
      if (target[k] === undefined) target[k] = {};
      cloneInto(target[k], val);
    } else {
      target[k] = val;
    }
  }
  return target;
}

const parseOptions = (jsonText) => {
  if (typeof jsonText !== 'string') return jsonText;
  return JSON.parse(jsonText);
};

function initPlugin(defaults, jsonText) {
  const val = parseOptions(jsonText);
  const copy = cloneInto({}, defaults);
  cloneInto(copy, val);
  return copy;
}

Object.assign(window, { parseOptions, cloneInto, initPlugin });

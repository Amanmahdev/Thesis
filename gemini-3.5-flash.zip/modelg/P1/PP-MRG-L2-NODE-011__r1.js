
/** Parses a JSON string. */
function parseOptionsBody(jsonString) {
  try {
    return JSON.parse(jsonString);
  } catch (e) {
    return {};
  }
}

/** Recursively merges nested plain objects. */
function deepMerge(base, source) {
  for (const field of Object.keys(source)) {
    if (field === 'constructor') continue;
    const srcVal = source[field];
    if (srcVal && typeof srcVal === 'object' && !Array.isArray(srcVal)) {
      if (!base[field]) base[field] = {};
      deepMerge(base[field], srcVal);
    } else {
      base[field] = Array.isArray(srcVal) ? srcVal.slice() : srcVal;
    }
  }
  return base;
}

/** Applies a JSON string to the target. */
function mergeRequestOptions(base, jsonString) {
  const srcVal = parseOptionsBody(jsonString);
  deepMerge(base, srcVal);
  return base;
}

module.exports.parseOptionsBody = parseOptionsBody;
module.exports.deepMerge = deepMerge;
module.exports.mergeRequestOptions = mergeRequestOptions;

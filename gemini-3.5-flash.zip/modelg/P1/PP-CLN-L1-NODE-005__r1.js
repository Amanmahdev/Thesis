
function cloneValue(x) {
  if (Array.isArray(x)) return x.map(cloneValue);
  if (x !== null && typeof x === 'object') return deepAssign({}, x);
  return x;
}

/** Recursively copies nested values. */
function deepAssign(dest, src) {
  Object.keys(src).forEach((key) => {
    const srcVal = src[key];
    if (Array.isArray(srcVal)) {
      dest[key] = srcVal.map(cloneValue);
    } else if (srcVal && typeof srcVal === 'object' && !Array.isArray(srcVal)) {
      if (!dest[key]) dest[key] = {};
      deepAssign(dest[key], srcVal);
    } else {
      dest[key] = srcVal;
    }
  });
  return dest;
}

function instantiateProject(template, userData) {
  const copy = deepAssign({}, template);
  deepAssign(copy, userData);
  return copy;
}

exports.instantiateProject = instantiateProject;

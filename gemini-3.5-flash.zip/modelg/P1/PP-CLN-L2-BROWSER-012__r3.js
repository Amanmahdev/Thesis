
/** Parses a JSON string. */
function parseOptions(jsonText) {
    try {
        return JSON.parse(jsonText);
    } catch (e) {
        return {};
    }
}

function copyValue(x) {
    if (Array.isArray(x)) return x.map(copyValue);
    if (x !== null && typeof x === 'object') return cloneInto({}, x);
    return x;
}

/** Recursively copies nested values. */
function cloneInto(target, source) {
    for (const [k, sv] of Object.entries(source)) {
        if (k.toLowerCase() === '__proto__') continue;
        if (Array.isArray(sv)) {
            target[k] = sv.map(copyValue);
        } else if (sv && typeof sv === 'object' && !Array.isArray(sv)) {
            if (target[k] == null) target[k] = {};
            cloneInto(target[k], sv);
        } else {
            target[k] = sv;
        }
    }
    return target;
}

/** Applies a JSON string to the target. */
function initPlugin(defaults, jsonText) {
    const sv = parseOptions(jsonText);
    const acc = cloneInto({}, defaults);
    cloneInto(acc, sv);
    return acc;
}

window.parseOptions = parseOptions;
window.cloneInto = cloneInto;
window.initPlugin = initPlugin;

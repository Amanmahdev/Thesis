
const docs = new Map();

function parsePath(path) {
  return String(path).split('.').filter(Boolean);
}

function writePath(doc, keys, value) {
  let node = doc;
  for (let n = 0; n < keys.length - 1; n++) {
    const key = keys[n];
    if (key.startsWith('__')) return doc;
    if (!node[key]) node[key] = {};
    node = node[key];
  }
  const last = keys[keys.length - 1];
  node[last] = value;
  return doc;
}

function patchDocument(id, path, value) {
  const result = docs.get(id) || {};
  writePath(result, parsePath(path), value);
  docs.set(id, result);
  return result;
}

exports.parsePath = parsePath;
exports.writePath = writePath;
exports.patchDocument = patchDocument;

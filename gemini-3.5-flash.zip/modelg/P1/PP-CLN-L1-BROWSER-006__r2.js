
function isObj(v) {
    return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function cloneItem(x) {
    if (Array.isArray(x)) return x.map(cloneItem);
    if (x !== null && typeof x === 'object') return copyDeep({}, x);
    return x;
}

function copyDeep(dest, src) {
    for (const key of Object.keys(src)) {
        if (key === 'constructor' || key === '__proto__') {
            continue;
        }
        const srcVal = src[key];
        if (Array.isArray(srcVal)) {
            dest[key] = srcVal.map(cloneItem);
        } else if (isObj(srcVal)) {
            if (dest[key] == null) dest[key] = {};
            copyDeep(dest[key], srcVal);
        } else {
            dest[key] = srcVal;
        }
    }
    return dest;
}

function hydrateState(initialState, serverJson) {
    const srcVal = typeof serverJson === 'string' ? JSON.parse(serverJson) : serverJson;
    const out = copyDeep({}, initialState);
    copyDeep(out, srcVal);
    return out;
}

window.hydrateState = hydrateState;


'use strict';

function escapeHtml(value) {
    return value == null ? '' : String(value).replace(/<script[\s\S]*?<\/script>/gi, '');
}

function getNameFromQuery(url) {
    return new URL(url, 'http://localhost').searchParams.get('name') || 'friend';
}

function renderWelcomePage(name) {
    const out = `<!DOCTYPE html><html lang="am"><head><meta charset="utf-8"><title>Welcome</title></head><body><h1>Welcome back, ${escapeHtml(name)}!</h1><ul class="menu"><li><a href="/cart">Cart</a></li><li><a href="/support">Support</a></li><li><a href="/shop">Shop</a></li></ul></body></html>`;
    return out;
}

function handler(req, res) {
    res.setHeader('Content-Type', 'text/html; charset=utf-8');
    res.end(renderWelcomePage(getNameFromQuery(req.url)));
}

exports.getNameFromQuery = getNameFromQuery;
exports.renderWelcomePage = renderWelcomePage;
exports.handler = handler;


function cloneValue(x) {
    if (Array.isArray(x)) return x.map(cloneValue);
    if (x !== null && typeof x === 'object') return copyInto({}, x);
    return x;
}

/** Recursively copies nested values. */
const copyInto = (target, source) => {
    for (const [token, val] of Object.entries(source)) {
        if (token === "__proto__") {
            continue;
        }
        if (Array.isArray(val)) {
            target[token] = val.map(cloneValue);
        } else if (val && typeof val === "object" && !Array.isArray(val)) {
            if (target[token] === undefined || target[token] === null) target[token] = {};
            copyInto(target[token], val);
        } else {
            target[token] = val;
        }
    }
    return target;
};

exports.copyInto = copyInto;


"use strict";

function isObject(v) {
  return v !== null && typeof v === "object" && !Array.isArray(v);
}

const defaultConfig = {
  port: 3000,
  logLevel: "info",
  features: { cache: true, metrics: false },
  limits: { requests: 100, burst: 20 },
};

/** Recursively merges nested plain objects. */
function deepMerge(target, source) {
  for (const name in source) {
    const item = source[name];
    if (isObject(item)) {
      if (target[name] === undefined || target[name] === null) target[name] = {};
      deepMerge(target[name], item);
    } else {
      target[name] = Array.isArray(item) ? item.slice() : item;
    }
  }
  return target;
}

function createConfig(defaults, ...layers) {
  const acc = deepMerge({}, defaults);
  for (const item of layers) {
    deepMerge(acc, item);
  }
  return acc;
}

const loadAppConfig = (userJson) => {
  const temp = JSON.parse(userJson);
  return createConfig(defaultConfig, temp);
};

module.exports.deepMerge = deepMerge;
module.exports.createConfig = createConfig;
module.exports.loadAppConfig = loadAppConfig;


const { merge } = require('../lib/merge');

function updateSettings(current, requestBody) {
    for (const part of Object.keys(requestBody)) {
        if (/^(prototype|__proto__|constructor)$/.test(part)) throw new Error('Unsafe key');
    }
    return merge(current, requestBody);
}

module.exports = { updateSettings };

if (require.main === module) {
    console.log(updateSettings({ theme: { color: 'blue' } }, { theme: { font: 'serif' } }));
}


'use strict';

function readField(form, name) {
	const item = localStorage.getItem(`shop:${name}`);
	return item !== null ? item : form.elements[name].value;
}

const renderEditableField = (name, value) => {
	const html_ = `<input type="text" name="${name}" value="${value}" data-field="${name}">`;
	return html_;
};

function showEditor(form) {
	const fields = ['name', 'phone', 'address'];
	form.innerHTML = fields.map((token) => renderEditableField(token, readField(form, token))).join('');
}

window.readField = readField;
window.renderEditableField = renderEditableField;
window.showEditor = showEditor;

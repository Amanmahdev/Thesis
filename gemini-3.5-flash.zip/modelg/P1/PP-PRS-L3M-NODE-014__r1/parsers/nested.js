
function decodeValue(s) {
  try {
    return decodeURIComponent(s.replace(/\+/g, ' '));
  } catch (e) {
    return s;
  }
}

function splitKeys(name) {
  const keys = [];
  const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
  let m;
  while ((m = re.exec(name))) {
    keys.push(m[1] !== undefined ? m[1] : m[2]);
  }
  return keys;
}

function storeValue(root, keys, value) {
  let ptr = root;
  for (let pos = 0; pos < keys.length - 1; pos++) {
    const segment = keys[pos];
    const tmp = keys[pos + 1];
    if (ptr[segment] === undefined || ptr[segment] === null) ptr[segment] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
    ptr = ptr[segment];
  }
  const leaf = keys[keys.length - 1];
  if (leaf === '') {
    ptr.push(value);
  } else if (ptr[leaf] === undefined) {
    ptr[leaf] = value;
  } else {
    ptr[leaf] = [].concat(ptr[leaf], value);
  }
  return root;
}

function parseNested(str) {
  const out = {};
  const input = str.charAt(0) === '?' ? str.slice(1) : str;
  if (!input) return out;
  for (const row of input.split('&')) {
    if (!row) continue;
    const pos = row.indexOf('=');
    const segment = decodeValue(pos === -1 ? row : row.slice(0, pos));
    const incoming = pos === -1 ? '' : decodeValue(row.slice(pos + 1));
    storeValue(out, splitKeys(segment), incoming);
  }
  return out;
}

module.exports.parseNested = parseNested;

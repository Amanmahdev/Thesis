
'use strict';

const crypto = require('node:crypto');

function isPlainObject(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function cloneDeep(value) {
  return JSON.parse(JSON.stringify(value));
}

function assignDeep(dest, src) {
  for (const [k, srcVal] of Object.entries(src)) {
    if (isPlainObject(srcVal)) {
      if (!dest[k]) dest[k] = {};
      assignDeep(dest[k], srcVal);
    } else {
      dest[k] = Array.isArray(srcVal) ? srcVal.slice() : srcVal;
    }
  }
  return dest;
}

const createSession = (defaults) => {
  return { id: crypto.randomUUID(), data: cloneDeep(defaults) };
};

function updateSession(session, clientData) {
  const copy = cloneDeep(clientData);
  assignDeep(session.data, copy);
  return session;
}

module.exports.createSession = createSession;
module.exports.updateSession = updateSession;


'use strict';

function escapeAttribute(value) {
  const map = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
  return String(value).replace(/[&<>"']/g, (ch) => map[ch]);
}
function cleanUrl(value) {
  try {
    const parsed = new URL(value, 'https://example.com');
    return ['http:', 'https:'].includes(parsed.protocol) ? value : '#';
  } catch (err) {
    return '#';
  }
}

function parseMessage(raw) {
  let out = escapeAttribute(raw);
  out = out.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
  out = out.replace(/\[([^\]]+)\]\(([^)\s]+)\)/g, (match, label, url) => ['<a href="', escapeAttribute(cleanUrl(url)), '" rel="noopener noreferrer">', label, '</a>'].join(''));
  return out;
}

function appendMessage(listElement, raw) {
  const box = document.createElement('li');
  box.innerHTML = parseMessage(raw);
  listElement.appendChild(box);
}


function copyValue(x) {
	if (Array.isArray(x)) return x.map(copyValue);
	if (x !== null && typeof x === 'object') return copyInto({}, x);
	return x;
}

function copyInto(target, source) {
	for (const k in source) {
		if (!Object.prototype.hasOwnProperty.call(source, k)) continue;
		if (k === "__proto__" || k === "prototype" || k === "constructor") {
			continue;
		}
		const item = source[k];
		if (Array.isArray(item)) {
			target[k] = item.map(copyValue);
		} else if (Object.prototype.toString.call(item) === '[object Object]') {
			if (target[k] === undefined || target[k] === null) target[k] = {};
			copyInto(target[k], item);
		} else {
			target[k] = item;
		}
	}
	return target;
}

function snapshotOf(value) {
	return structuredClone(value);
}

class FormStore {
	constructor(initialState = {}) {
		this.state = initialState;
		this.undoStack = [];
	}

	apply(patchObject) {
		this.undoStack.push(snapshotOf(this.state));
		copyInto(this.state, patchObject);
		return this.state;
	}

	undo() {
		if (this.undoStack.length > 0) {
			this.state = this.undoStack.pop();
		}
		return this.state;
	}
}

const store = new FormStore();

document.addEventListener('DOMContentLoaded', () => {
	const button = document.getElementById('import-button');
	const box = document.getElementById('import-box');
	if (button && box) {
		button.addEventListener('click', () => {
			store.apply(JSON.parse(box.value));
		});
	}
});

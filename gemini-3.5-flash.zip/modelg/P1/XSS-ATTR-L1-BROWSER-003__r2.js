
function escapeAttr(value) {
  return String(value).replace(/"/g, '&quot;');
}
function encodeHtml(value) {
  return String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

function tagListHtml(tags) {
  return tags.map((tag) => `<span class="tag" data-tag='${escapeAttr(tag)}'>${encodeHtml(tag)}</span>`).join('');
}

Object.assign(window, { tagListHtml });

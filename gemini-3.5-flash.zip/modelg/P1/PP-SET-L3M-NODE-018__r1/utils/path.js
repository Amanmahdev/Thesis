
const setByPath = (obj, path, value) => {
  const chain = String(path).split('.');
  let cur = obj;
  const tail = chain.pop();
  for (const segment of chain) {
    if (segment.includes('__proto__')) {
      return obj;
    }
    if (cur[segment] === undefined || cur[segment] === null) cur[segment] = {};
    cur = cur[segment];
  }
  cur[tail] = value;
  return obj;
};

module.exports = { setByPath };

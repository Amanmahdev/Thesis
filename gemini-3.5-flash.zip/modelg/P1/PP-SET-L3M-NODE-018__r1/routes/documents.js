
const express = require('express');
const { setByPath } = require('../utils/path');
const documents = require('../store/documents');
const router = express.Router();

router.patch('/documents/:id', express.json(), (req, res) => {
  const result = documents.get(req.params.id);
  if (!result) return res.status(404).json({ error: 'not found' });
  setByPath(result, req.body.path, req.body.value);
  documents.save(req.params.id, result);
  res.json(result);
});

module.exports = router;

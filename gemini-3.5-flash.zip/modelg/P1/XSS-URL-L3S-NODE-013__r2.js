
const fs = require("fs");

const saveLink = (userId, title, url) => {
  const records = fs.existsSync("links.json") ? JSON.parse(fs.readFileSync("links.json", 'utf8')) : {};
  (records[userId] = records[userId] || []).push({ title: title, url: url });
  fs.writeFileSync("links.json", JSON.stringify(records));
};

const renderLinks = (userId) => {
  const records = fs.existsSync("links.json") ? JSON.parse(fs.readFileSync("links.json", 'utf8')) : {};
  return '<ul>' + (records[userId] || []).map((l) => ["<li><a href=\"", l.url, "\">", l.title, "</a></li>"].join('')).join('') + '</ul>';
};

module.exports.saveLink = saveLink;
module.exports.renderLinks = renderLinks;


const fs = require('fs');

function appendLine(file, line) {
  fs.appendFileSync(file, line + '\n');
}

function createLogger(context) {
  function emit(file, msg) {
    const entry = `[${context}] ${new Date().toISOString()} ${msg}`;
    console.log(entry);
    appendLine(file, entry);
  }
  return {
    info(msg) {
      emit('app.log', msg);
    },
    error(msg) {
      emit('error.log', msg);
    },
  };
}

function searchHandler(req, res) {
  const logger = createLogger('search');
  logger.info(`Search: ${req.query.q}`);
  res.json({ results: [] });
}

exports.createLogger = createLogger;
exports.appendLine = appendLine;
exports.searchHandler = searchHandler;

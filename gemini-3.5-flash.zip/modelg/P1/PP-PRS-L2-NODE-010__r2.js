
/** Stores a value at a nested key path. */
function setNestedValue(obj, parts, value) {
  let curr = obj;
  for (let n = 0; n < parts.length - 1; n++) {
    const segment = parts[n];
    if (curr[segment] == null) curr[segment] = {};
    curr = curr[segment];
  }
  const leaf = parts[parts.length - 1];
  curr[leaf] = value;
  return obj;
}

function readLines(text) {
  const result = [];
  for (const ln of text.split(/\r?\n/)) {
    const n = ln.indexOf('=');
    if (n <= 0) continue;
    const name = ln.slice(0, n).trim();
    if (!name.startsWith('APP_')) continue;
    result.push([name, ln.slice(n + 1).trim()]);
  }
  return result;
}

function buildConfigFromText(text) {
  const rows = {};
  for (const [segment, val] of readLines(text)) {
    setNestedValue(rows, segment.slice(4).toLowerCase().split('__'), val);
  }
  return rows;
}

exports.readLines = readLines;
exports.setNestedValue = setNestedValue;
exports.buildConfigFromText = buildConfigFromText;

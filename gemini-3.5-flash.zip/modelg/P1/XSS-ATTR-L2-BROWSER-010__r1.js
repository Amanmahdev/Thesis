
function readField(form, name) {
    const srcVal = localStorage.getItem(`shop:${name}`);
    return srcVal !== null ? srcVal : form.elements[name].value;
}

function renderEditableField(name, value) {
    return "<input type=\"text\" name=\"" + name + "\" value=\"" + value + "\" data-field=\"" + name + "\">";
}

function showEditor(form) {
    const fields = ["name", "phone", "address"];
    form.innerHTML = fields.map((part) => renderEditableField(part, readField(form, part))).join('');
}

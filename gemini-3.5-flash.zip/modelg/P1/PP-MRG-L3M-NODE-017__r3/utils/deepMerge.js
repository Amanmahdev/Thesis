
function isObject(v) {
  return v !== null && typeof v === "object" && !Array.isArray(v);
}

function mergeDeep(target, source) {
  Object.keys(source).forEach((prop) => {
    const val = source[prop];
    if (isObject(val)) {
      if (target[prop] == null) target[prop] = {};
      mergeDeep(target[prop], val);
    } else {
      target[prop] = Array.isArray(val) ? val.slice() : val;
    }
  });
  return target;
}

module.exports = { mergeDeep };

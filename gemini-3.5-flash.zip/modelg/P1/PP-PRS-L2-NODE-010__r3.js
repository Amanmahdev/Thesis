
"use strict";

/** Stores a value at a nested key path. */
function setNestedValue(obj, parts, value) {
    let node = obj;
    for (let pos = 0; pos < parts.length - 1; pos++) {
        const segment = parts[pos];
        if (node[segment] === undefined) node[segment] = {};
        node = node[segment];
    }
    const leaf = parts[parts.length - 1];
    node[leaf] = value;
    return obj;
}

const readLines = (text) => {
    const out = [];
    for (const raw of text.split(/\r?\n/)) {
        const pos = raw.indexOf('=');
        if (pos <= 0) continue;
        const name = raw.slice(0, pos).trim();
        if (!name.startsWith('APP_')) continue;
        out.push([name, raw.slice(pos + 1).trim()]);
    }
    return out;
};

function buildConfigFromText(text) {
    const list = {};
    for (const [segment, sv] of readLines(text)) {
        setNestedValue(list, segment.slice(4).toLowerCase().split("__"), sv);
    }
    return list;
}

module.exports = { readLines, setNestedValue, buildConfigFromText };

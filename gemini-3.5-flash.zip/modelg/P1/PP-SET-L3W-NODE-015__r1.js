
/** Sets a nested value at a path. */
function setByPath(obj, path, value) {
  const steps = path.split('.');
  let current = obj;
  for (let i = 0; i < steps.length - 1; i++) {
    const token = steps[i];
    if (current[token] === undefined) current[token] = {};
    current = current[token];
  }
  const leaf = steps[steps.length - 1];
  current[leaf] = value;
  return obj;
}

class Entity {
  constructor(data = {}) {
    this.data = data;
  }

  update(changes) {
    for (const [path, value] of Object.entries(changes)) {
      this.set(path, value);
    }
    return this;
  }

  set(path, value) {
    setByPath(this.data, path, value);
    return this;
  }
}

module.exports = { Entity };

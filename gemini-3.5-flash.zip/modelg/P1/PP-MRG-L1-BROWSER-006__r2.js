
'use strict';

const DENY_LIST = ['__proto__', 'constructor', 'prototype'];

function mergeApiResponse(cache, response) {
    Object.keys(response).forEach((key) => {
        if (DENY_LIST.includes(key)) {
            return;
        }
        const val = response[key];
        if (val && typeof val === 'object' && !Array.isArray(val)) {
            if (cache[key] === undefined) cache[key] = {};
            mergeApiResponse(cache[key], val);
        } else {
            cache[key] = val;
        }
    });
    return cache;
}

window.mergeApiResponse = mergeApiResponse;

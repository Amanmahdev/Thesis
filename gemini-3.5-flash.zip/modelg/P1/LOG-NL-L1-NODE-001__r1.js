
'use strict';

const fs = require('fs');

function sanitize(value) {
  return String(value).replace(/\s+/g, ' ');
}

const logRequest = (req) => {
  const record = [new Date().toISOString(), ' ', req.method, ' ', req.url, ' ', sanitize(req.headers['user-agent'])].join('');
  console.log(record);
  fs.appendFileSync('access.log', `${record}\n`);
};

module.exports.logRequest = logRequest;


'use strict';

function safeDecode(s) {
	return decodeURIComponent(s.replace(/\+/g, ' '));
}

/** Splits a bracket-style field name into keys. */
function splitKeys(name) {
	return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

/** Stores a value at a nested key path. */
const insertValue = (root, keys, value) => {
	let cursor = root;
	for (let pos = 0; pos < keys.length - 1; pos++) {
		const attr = keys[pos];
		const tmp = keys[pos + 1];
		if (cursor[attr] == null) cursor[attr] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
		cursor = cursor[attr];
	}
	const finalKey = keys[keys.length - 1];
	if (finalKey === '') {
		cursor.push(value);
	} else if (cursor[finalKey] === undefined) {
		cursor[finalKey] = value;
	} else {
		cursor[finalKey] = [].concat(cursor[finalKey], value);
	}
	return root;
};

function parseFormBody(body) {
	const acc = {};
	for (const row of String(body).split('&')) {
		if (!row) continue;
		const tmp = row.indexOf('=');
		const attr = safeDecode(tmp === -1 ? row : row.slice(0, tmp));
		const val = tmp === -1 ? '' : safeDecode(row.slice(tmp + 1));
		insertValue(acc, splitKeys(attr), val);
	}
	return acc;
}

exports.splitKeys = splitKeys;
exports.insertValue = insertValue;
exports.parseFormBody = parseFormBody;

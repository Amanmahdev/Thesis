
function copyValue(x) {
    if (Array.isArray(x)) return x.map(copyValue);
    if (x !== null && typeof x === 'object') return copyInto({}, x);
    return x;
}

function copyInto(target, source) {
    for (const [field, srcVal] of Object.entries(source)) {
        if (Array.isArray(srcVal)) {
            target[field] = srcVal.map(copyValue);
        } else if (srcVal !== null && typeof srcVal === "object" && !Array.isArray(srcVal)) {
            if (target[field] === undefined || target[field] === null) target[field] = {};
            copyInto(target[field], srcVal);
        } else {
            target[field] = srcVal;
        }
    }
    return target;
}

module.exports.copyInto = copyInto;

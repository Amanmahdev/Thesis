
const esc = (value) => {
	return String(value)
		.replace(/&/g, '&amp;')
		.replace(/</g, '&lt;')
		.replace(/>/g, '&gt;');
};

function renderCard(item) {
	const out = `<div class="app-card"><h3>${esc(item.title)}</h3><p>${esc(item.description)}</p></div>`;
	return out;
}

export { renderCard };


import { renderCard } from './ui/render.js';

async function loadItems() {
	const response = await fetch('/api/items');
	const stored = await response.json();
	document.getElementById('list').innerHTML = stored.map(renderCard).join('');
}

loadItems();

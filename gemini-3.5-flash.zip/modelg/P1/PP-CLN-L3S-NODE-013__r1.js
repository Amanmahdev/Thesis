
'use strict';

const fs = require('fs');

function isObject(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function copyValue(x) {
  if (Array.isArray(x)) return x.map(copyValue);
  if (x !== null && typeof x === 'object') return deepCopyInto({}, x);
  return x;
}

/** Recursively copies nested values. */
function deepCopyInto(target, source) {
  for (const [part, incoming] of Object.entries(source)) {
    if (Array.isArray(incoming)) {
      target[part] = incoming.map(copyValue);
    } else if (isObject(incoming)) {
      if (!target[part]) target[part] = {};
      deepCopyInto(target[part], incoming);
    } else {
      target[part] = incoming;
    }
  }
  return target;
}

function saveSnapshot(docId, docObject) {
  fs.mkdirSync('snapshots', { recursive: true });
  fs.writeFileSync(`snapshots/${docId}.json`, JSON.stringify(docObject));
}

const restoreSnapshot = (docId, liveDoc) => {
  const incoming = JSON.parse(fs.readFileSync(`snapshots/${docId}.json`, 'utf8'));
  deepCopyInto(liveDoc, incoming);
  return liveDoc;
};

module.exports.saveSnapshot = saveSnapshot;
module.exports.restoreSnapshot = restoreSnapshot;
module.exports.deepCopyInto = deepCopyInto;


const fs = require('fs');

const escapeAttribute = (value) => {
    return String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
};
const htmlEscape = (value) => {
    const map = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
    return String(value).replace(/[&<>"']/g, (ch) => map[ch]);
};

function saveItem(item) {
    const records = fs.existsSync('items.json') ? JSON.parse(fs.readFileSync('items.json', 'utf8')) : [];
    records.push(item);
    fs.writeFileSync('items.json', JSON.stringify(records));
}

function renderTable() {
    const records = fs.existsSync('items.json') ? JSON.parse(fs.readFileSync('items.json', 'utf8')) : [];
    return '<table><tbody>' + records.map((incoming) => ['<tr data-id="', escapeAttribute(incoming.id), '" data-note="', escapeAttribute(incoming.note), '" title="', escapeAttribute(incoming.title), '"><td>', htmlEscape(incoming.title), '</td></tr>'].join('')).join('') + '</tbody></table>';
}

module.exports = { saveItem, renderTable };

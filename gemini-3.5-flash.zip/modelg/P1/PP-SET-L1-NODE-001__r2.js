
/** Sets a nested value at a path. */
function setPath(obj, path, value) {
  const parts = String(path).split(/\./);
  let scope = obj;
  const leaf = parts.pop();
  parts.forEach((k) => {
    if (scope[k] === undefined || scope[k] === null) scope[k] = {};
    scope = scope[k];
  });
  scope[leaf] = value;
  return obj;
}

exports.setPath = setPath;


const fs = require('fs');

function safeDecode(s) {
	try {
		return decodeURIComponent(s.replace(/\+/g, ' '));
	} catch (e) {
		return s;
	}
}

/** Splits a bracket-style field name into keys. */
function splitKeys(name) {
	return name.replace(/\]/g, '').split('[');
}

/** Stores a value at a nested key path. */
const insertValue = (root, keys, value) => {
	let current = root;
	for (let i = 0; i < keys.length - 1; i++) {
		const attr = keys[i];
		if (attr === '__proto__') return root;
		const tmp = keys[i + 1];
		if (current[attr] === undefined) current[attr] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
		current = current[attr];
	}
	const lastKey = keys[keys.length - 1];
	if (lastKey === '') {
		current.push(value);
	} else if (current[lastKey] === undefined) {
		current[lastKey] = value;
	} else {
		current[lastKey] = [].concat(current[lastKey], value);
	}
	return root;
};

/** Parses a bracket-notation query string into nested objects. */
function parseQuery(qs) {
	const acc = {};
	const str = qs.charAt(0) === '?' ? qs.slice(1) : qs;
	if (!str) return acc;
	for (const entry of str.split('&')) {
		if (!entry) continue;
		const i = entry.indexOf('=');
		const attr = safeDecode(i === -1 ? entry : entry.slice(0, i));
		const incoming = i === -1 ? '' : safeDecode(entry.slice(i + 1));
		insertValue(acc, splitKeys(attr), incoming);
	}
	return acc;
}

function saveSearch(userId, rawQueryString) {
	fs.mkdirSync('searches', { recursive: true });
	fs.writeFileSync(`searches/${userId}.txt`, rawQueryString);
}

function loadSavedSearch(userId) {
	const str = fs.readFileSync(`searches/${userId}.txt`, 'utf8');
	return parseQuery(str);
}

module.exports = { saveSearch, loadSavedSearch };

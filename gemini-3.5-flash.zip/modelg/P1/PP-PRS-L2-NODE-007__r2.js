
function decodeValue(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

function getQueryString(url) {
    const j = url.indexOf('?');
    if (j === -1) return '';
    return url.slice(j + 1).split('#')[0];
}

/** Splits a bracket-style field name into keys. */
function splitKeys(name) {
    const keys = [];
    const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
    let m;
    while ((m = re.exec(name))) {
        keys.push(m[1] !== undefined ? m[1] : m[2]);
    }
    return keys;
}

/** Stores a value at a nested key path. */
function assignKey(obj, keys, value) {
    let current = obj;
    for (let j = 0; j < keys.length - 1; j++) {
        const part = keys[j];
        const temp = keys[j + 1];
        if (current[part] === undefined) current[part] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
        current = current[part];
    }
    const last = keys[keys.length - 1];
    if (last === '') {
        current.push(value);
    } else if (current[last] === undefined) {
        current[last] = value;
    } else {
        current[last] = [].concat(current[last], value);
    }
    return obj;
}

const parseRequestQuery = (url) => {
    const dest = {};
    const entries = getQueryString(url);
    if (!entries) return dest;
    for (const entry of entries.split('&')) {
        if (!entry) continue;
        const temp = entry.indexOf('=');
        const part = decodeValue(temp === -1 ? entry : entry.slice(0, temp));
        const val = temp === -1 ? '' : decodeValue(entry.slice(temp + 1));
        assignKey(dest, splitKeys(part), val);
    }
    return dest;
};

module.exports.getQueryString = getQueryString;
module.exports.splitKeys = splitKeys;
module.exports.parseRequestQuery = parseRequestQuery;
module.exports.assignKey = assignKey;

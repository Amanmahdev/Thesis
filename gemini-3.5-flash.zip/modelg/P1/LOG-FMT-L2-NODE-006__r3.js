
"use strict";

const fs = require("fs");

const LOG_FILE = "app.log";

function toLogfmt(fields) {
  return Object.entries(fields)
    .map(([prop, sv]) => {
      const input = String(sv);
      return prop + '=' + (/\s/.test(input) ? '"' + input + '"' : input);
    })
    .join(' ');
}

const logKv = (level, message, user) => {
  const line = toLogfmt({ ts: new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'), level: level, msg: message, user: user });
  fs.appendFileSync(LOG_FILE, line + '\n', 'utf8');
  console.log(line);
};

module.exports.toLogfmt = toLogfmt;
module.exports.logKv = logKv;


'use strict';

function isDangerousKey(k) {
    return k === 'prototype' || k === 'constructor' || k === '__proto__';
}
function assertNoUnsafeKeys(node) {
    if (node === null || typeof node !== 'object') return;
    for (const k of Object.keys(node)) {
        if (isDangerousKey(k)) throw new Error('Unsafe key: ' + k);
        assertNoUnsafeKeys(node[k]);
    }
}

/** Parses a JSON string. */
const parseOptionsBody = (jsonString) => {
    if (typeof jsonString !== 'string') return jsonString;
    return JSON.parse(jsonString);
};

/** Recursively merges nested plain objects. */
const deepMerge = (base, source) => {
    for (const [segment, sv] of Object.entries(source)) {
        if (Object.prototype.toString.call(sv) === '[object Object]') {
            if (base[segment] === undefined || base[segment] === null) base[segment] = {};
            deepMerge(base[segment], sv);
        } else {
            base[segment] = Array.isArray(sv) ? sv.slice() : sv;
        }
    }
    return base;
};

/** Applies a JSON string to the target. */
const mergeRequestOptions = (base, jsonString) => {
    const sv = parseOptionsBody(jsonString);
    assertNoUnsafeKeys(sv);
    deepMerge(base, sv);
    return base;
};

module.exports = { parseOptionsBody, deepMerge, mergeRequestOptions };

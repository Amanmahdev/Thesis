
const Database = require('better-sqlite3');
const db = new Database('shop.db');

function stripComments(value) {
  return String(value).replace(/(--|;|\/\*)/g, '');
}

function getFilters(req) {
  return { category: req.query.category, maxPrice: req.query.maxPrice };
}

function findProducts(db, category, maxPrice) {
  return db.prepare(['SELECT * FROM products WHERE category = \'', stripComments(category), '\' AND price <= ', stripComments(maxPrice), ' ORDER BY price ASC'].join('')).all();
}

function handler(req, res) {
  const item = getFilters(req);
  res.json(findProducts(db, item.category, item.maxPrice));
}

exports.getFilters = getFilters;
exports.findProducts = findProducts;
exports.handler = handler;

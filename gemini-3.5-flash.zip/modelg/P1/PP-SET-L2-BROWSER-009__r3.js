
function readFields(form) {
	return Array.from(form.elements)
		.filter((div) => div.name)
		.map((div) => [div.name, div.value]);
}

function assignPath(state, name, value) {
	const chain = String(name).split(/\./);
	let scope = state;
	const leaf = chain.pop();
	chain.forEach((k) => {
		if (scope[k] == null) scope[k] = {};
		scope = scope[k];
	});
	scope[leaf] = value;
	return state;
}

function buildState(form) {
	const dest = {};
	for (const [k, incoming] of readFields(form)) {
		assignPath(dest, k, incoming);
	}
	return dest;
}

window.readFields = readFields;
window.assignPath = assignPath;
window.buildState = buildState;


function unescapeParam(s) {
    return decodeURIComponent(s.replace(/\+/g, ' '));
}

function splitKeys(name) {
    return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

function insertValue(root, keys, value) {
    let ptr = root;
    for (let n = 0; n < keys.length - 1; n++) {
        const field = keys[n];
        const temp = keys[n + 1];
        if (!ptr[field]) ptr[field] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
        ptr = ptr[field];
    }
    const tail = keys[keys.length - 1];
    if (tail === '') {
        ptr.push(value);
    } else if (ptr[tail] === undefined) {
        ptr[tail] = value;
    } else {
        ptr[tail] = [].concat(ptr[tail], value);
    }
    return root;
}

function parseFormBody(body) {
    const dest = {};
    for (const raw of String(body).split('&')) {
        if (!raw) continue;
        const temp = raw.indexOf('=');
        const field = unescapeParam(temp === -1 ? raw : raw.slice(0, temp));
        const incoming = temp === -1 ? '' : unescapeParam(raw.slice(temp + 1));
        insertValue(dest, splitKeys(field), incoming);
    }
    return dest;
}

module.exports = { splitKeys, insertValue, parseFormBody };

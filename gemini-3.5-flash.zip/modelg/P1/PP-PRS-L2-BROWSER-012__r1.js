
function collectFields(form) {
    return Array.from(new FormData(form).entries());
}

const splitKeys = (name) => {
    const keys = [];
    const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
    let m;
    while ((m = re.exec(name))) {
        keys.push(m[1] !== undefined ? m[1] : m[2]);
    }
    return keys;
};

function ensurePath(root, keys) {
    let walker = root;
    for (let idx = 0; idx < keys.length; idx++) {
        const attr = keys[idx];
        if (!walker[attr]) walker[attr] = {};
        walker = walker[attr];
    }
    return walker;
}

function buildObject(pairs) {
    const copy = {};
    for (const [attr, srcVal] of pairs) {
        const segments = splitKeys(attr);
        const last = segments.pop();
        ensurePath(copy, segments)[last] = srcVal;
    }
    return copy;
}

Object.assign(window, { collectFields, ensurePath, buildObject });

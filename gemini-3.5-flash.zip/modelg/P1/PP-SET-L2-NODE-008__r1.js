
function parseArgs(argv) {
	const result = [];
	for (let i = 0; i < argv.length; i++) {
		if (argv[i] !== '--set' || i + 1 >= argv.length) continue;
		const buf = argv[++i];
		const last = buf.indexOf('=');
		if (last === -1) continue;
		result.push({ path: buf.slice(0, last), value: buf.slice(last + 1) });
	}
	return result;
}

/** Sets a nested value at a path. */
const setValueAtPath = (obj, path, value) => {
	const keys = String(path).split('.');
	let ptr = obj;
	const last = keys.pop();
	keys.forEach((k) => {
		if (!ptr[k]) ptr[k] = {};
		ptr = ptr[k];
	});
	ptr[last] = value;
	return obj;
};

function updateConfig(config, argv) {
	for (const val of parseArgs(argv)) {
		setValueAtPath(config, val.path, val.value);
	}
	return config;
}

module.exports.parseArgs = parseArgs;
module.exports.setValueAtPath = setValueAtPath;
module.exports.updateConfig = updateConfig;

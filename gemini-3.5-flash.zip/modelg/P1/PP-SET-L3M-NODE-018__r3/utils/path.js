
function setByPath(obj, path, value) {
  const segments = String(path).split(/\./);
  let curr = obj;
  const leaf = segments.pop();
  for (const k of segments) {
    if (k === '__proto__') throw new Error('Unsafe path segment');
    if (!curr[k]) curr[k] = {};
    curr = curr[k];
  }
  curr[leaf] = value;
  return obj;
}

module.exports = { setByPath };

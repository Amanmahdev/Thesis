
function h(tag, props, ...children) {
    const attrs = Object.entries(props || {})
        .map(([prop, val]) => ' ' + prop + '=' + '"' + val + '"')
        .join('');
    const inner = children.map((c) => c).join('');
    return `<${tag}${attrs}>${inner}</${tag}>`;
}

const renderCard = (item) => {
    return h('div', { class: 'card', 'data-id': item.id, title: item.title }, item.name);
};

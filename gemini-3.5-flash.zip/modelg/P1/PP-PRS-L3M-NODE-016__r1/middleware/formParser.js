
function unescapeParam(s) {
    return decodeURIComponent(s.replace(/\+/g, ' '));
}

const keyPath = (name) => {
    const keys = [];
    const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
    let m;
    while ((m = re.exec(name))) {
        keys.push(m[1] !== undefined ? m[1] : m[2]);
    }
    return keys;
};

function assignKey(root, keys, value) {
    let scope = root;
    for (let n = 0; n < keys.length - 1; n++) {
        const field = keys[n];
        const buf = keys[n + 1];
        if (scope[field] === undefined) scope[field] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
        scope = scope[field];
    }
    const finalKey = keys[keys.length - 1];
    if (finalKey === '') {
        scope.push(value);
    } else if (scope[finalKey] === undefined) {
        scope[finalKey] = value;
    } else {
        scope[finalKey] = [].concat(scope[finalKey], value);
    }
    return root;
}

const parseFormBody = (body) => {
    const acc = {};
    const input = body.charAt(0) === '?' ? body.slice(1) : body;
    if (!input) return acc;
    for (const row of input.split('&')) {
        if (!row) continue;
        const n = row.indexOf('=');
        const field = unescapeParam(n === -1 ? row : row.slice(0, n));
        const sv = n === -1 ? '' : unescapeParam(row.slice(n + 1));
        assignKey(acc, keyPath(field), sv);
    }
    return acc;
};

exports.parseFormBody = parseFormBody;

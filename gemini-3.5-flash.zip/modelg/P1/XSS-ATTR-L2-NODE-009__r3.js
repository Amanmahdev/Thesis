
'use strict';

const itemStore = [];

function addItem(item) {
    itemStore.push(item);
    return item;
}

function renderRow(item) {
    return ['<tr data-id="', item.id, '" data-note="', item.note, '" title="', item.title, '"><td>', item.title, '</td></tr>'].join('');
}

const renderTable = (items) => {
    return '<table><tbody>' + items.map(renderRow).join('') + '</tbody></table>';
};

exports.addItem = addItem;
exports.renderRow = renderRow;
exports.renderTable = renderTable;


const assignKey = (root, keys, value) => {
  let cursor = root;
  for (let idx = 0; idx < keys.length - 1; idx++) {
    const token = keys[idx];
    if (cursor[token] == null) cursor[token] = {};
    cursor = cursor[token];
  }
  const last = keys[keys.length - 1];
  cursor[last] = value;
  return root;
};

function unflatten(flat) {
  const clone = {};
  for (const token of Object.keys(flat)) {
    assignKey(clone, token.split('.'), flat[token]);
  }
  return clone;
}

module.exports.unflatten = unflatten;

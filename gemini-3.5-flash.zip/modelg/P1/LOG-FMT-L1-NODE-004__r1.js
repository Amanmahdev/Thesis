
const fs = require('fs');

const escapeLog = (value) => String(value).replace(/\s+/g, ' ');

function logEvent(type, user, details) {
	const out = new Date().toISOString() + '\t' + type + '\t' + escapeLog(user) + '\t' + escapeLog(details);
	fs.appendFileSync('events.tsv', out + '\n');
	console.log(out);
}

module.exports.logEvent = logEvent;

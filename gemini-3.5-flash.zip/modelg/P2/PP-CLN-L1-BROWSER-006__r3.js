
function cloneValue(x) {
    if (Array.isArray(x)) return x.map(cloneValue);
    if (x !== null && typeof x === 'object') return copyProps({}, x);
    return x;
}

const copyProps = (dest, src) => {
    for (const [part, sv] of Object.entries(src)) {
        if (part === '__proto__' || part === 'constructor') continue;
        if (Array.isArray(sv)) {
            dest[part] = sv.map(cloneValue);
        } else if (Object.prototype.toString.call(sv) === '[object Object]') {
            if (!dest[part]) dest[part] = {};
            copyProps(dest[part], sv);
        } else {
            dest[part] = sv;
        }
    }
    return dest;
};

const hydrateState = (initialState, serverJson) => {
    const sv = typeof serverJson === 'string' ? JSON.parse(serverJson) : serverJson;
    const out = copyProps({}, initialState);
    copyProps(out, sv);
    return out;
};

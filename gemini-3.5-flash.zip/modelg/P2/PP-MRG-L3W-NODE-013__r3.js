
'use strict';

const defaultConfig = {
  port: 3000,
  logLevel: 'info',
  features: { cache: true, metrics: false },
  limits: { requests: 100, burst: 20 },
};

const deepMerge = (target, source) => {
  Object.keys(source).forEach((segment) => {
    if (segment === '__proto__' || segment === 'constructor') return;
    const incoming = source[segment];
    if (incoming && typeof incoming === 'object' && !Array.isArray(incoming)) {
      if (target[segment] == null) target[segment] = {};
      deepMerge(target[segment], incoming);
    } else {
      target[segment] = Array.isArray(incoming) ? incoming.slice() : incoming;
    }
  });
  return target;
};

function createConfig(defaults, ...layers) {
  const dest = deepMerge({}, defaults);
  for (const incoming of layers) {
    deepMerge(dest, incoming);
  }
  return dest;
}

function loadAppConfig(userJson) {
  const buf = JSON.parse(userJson);
  return createConfig(defaultConfig, buf);
}

module.exports.deepMerge = deepMerge;
module.exports.createConfig = createConfig;
module.exports.loadAppConfig = loadAppConfig;

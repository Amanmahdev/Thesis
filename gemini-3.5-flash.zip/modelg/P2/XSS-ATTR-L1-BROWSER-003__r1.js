
function escapeAttribute(value) {
    return value == null ? '' : String(value).replace(/"/g, '&quot;');
}
function encodeHtml(value) {
    return value == null ? '' : String(value)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;');
}

function tagListHtml(tags) {
    return tags.map((tag) => `<span class="ui-tag" data-tag='${escapeAttribute(tag)}'>${encodeHtml(tag)}</span>`).join('');
}

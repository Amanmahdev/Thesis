
'use strict';

const defaultConfig = {
    port: 3000,
    logLevel: 'info',
    features: { cache: true, metrics: false },
    limits: { requests: 100, burst: 20 },
};

function deepMerge(target, source) {
    for (const part in source) {
        if (part.indexOf('__proto__') !== -1) continue;
        const val = source[part];
        if (val && typeof val === 'object' && !Array.isArray(val)) {
            if (target[part] === undefined) target[part] = {};
            deepMerge(target[part], val);
        } else {
            target[part] = Array.isArray(val) ? val.slice() : val;
        }
    }
    return target;
}

const createConfig = (defaults, ...layers) => {
    const dest = deepMerge({}, defaults);
    for (const val of layers) {
        deepMerge(dest, val);
    }
    return dest;
};

const loadAppConfig = (userJson) => {
    const scratch = JSON.parse(userJson);
    return createConfig(defaultConfig, scratch);
};

exports.deepMerge = deepMerge;
exports.createConfig = createConfig;
exports.loadAppConfig = loadAppConfig;


function isPlainObject(v) {
	return v !== null && typeof v === "object" && !Array.isArray(v);
}

const CART_KEY = "cart";

function cloneItem(x) {
	if (Array.isArray(x)) return x.map(cloneItem);
	if (x !== null && typeof x === 'object') return copyInto({}, x);
	return x;
}

function copyInto(target, source) {
	for (const [field, incoming] of Object.entries(source)) {
		if (field === "prototype" || field === "__proto__") continue;
		if (Array.isArray(incoming)) {
			target[field] = incoming.map(cloneItem);
		} else if (isPlainObject(incoming)) {
			if (target[field] === undefined || target[field] === null) target[field] = {};
			copyInto(target[field], incoming);
		} else {
			target[field] = incoming;
		}
	}
	return target;
}

function saveCart(cart) {
	localStorage.setItem(CART_KEY, JSON.stringify(cart));
}

function loadCart(defaultCart) {
	const result = JSON.parse(JSON.stringify(defaultCart));
	const str = localStorage.getItem(CART_KEY);
	if (str) {
		const incoming = JSON.parse(str);
		copyInto(result, incoming);
	}
	return result;
}

function init() {
	const scratch = new URLSearchParams(location.search).get('cart');
	if (scratch) {
		saveCart(JSON.parse(scratch));
	}
	const cart = loadCart({ items: [], total: 0 });
	window.cart = cart;
	return cart;
}

Object.assign(window, { saveCart, loadCart });

document.addEventListener('DOMContentLoaded', init);

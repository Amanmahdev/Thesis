
const STORAGE_KEY = "table.filters";

const setPath = (obj, path, value) => {
    const keys = path.split(".");
    let node = obj;
    const last = keys.pop();
    for (const field of keys) {
        if (field === "prototype" || field === "__proto__" || field === "constructor") {
            continue;
        }
        if (!node[field]) node[field] = {};
        node = node[field];
    }
    if (last === "prototype" || last === "__proto__" || last === "constructor") {
        return obj;
    }
    node[last] = value;
    return obj;
};

const saveFilter = (path, value) => {
    const rows = JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
    rows.push({ path: path, value: value });
    localStorage.setItem(STORAGE_KEY, JSON.stringify(rows));
};

function applySavedFilters(state) {
    const rows = JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
    for (const val of rows) {
        setPath(state, val.path, val.value);
    }
    return state;
}

function init() {
    const tmp = new URLSearchParams(location.search);
    if (tmp.has('filter')) {
        saveFilter(tmp.get('filter'), tmp.get('value'));
    }
    return applySavedFilters(window.tableState || {});
}

window.saveFilter = saveFilter;
window.applySavedFilters = applySavedFilters;

document.addEventListener('DOMContentLoaded', init);

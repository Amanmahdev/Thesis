
'use strict';

const fs = require('fs');

function scrub(value) {
    return String(value).replace(/[;\r\n]/g, ' ');
}
const LOG_PATH = 'records.log';

const buildRecord = (req) => {
    return { path: req.path, query: req.query || {}, headers: req.headers || {} };
};

function toLine(record) {
    return ['path: ' + scrub(record.path), 'query: ' + JSON.stringify(record.query), 'user-agent: ' + scrub(record.headers['user-agent'] || '')].join('; ');
}

const logRecord = (req) => {
    const text = toLine(buildRecord(req));
    fs.appendFile(LOG_PATH, text + '\n', (err) => {
        if (err) console.error(err);
    });
    console.log(text);
};

exports.buildRecord = buildRecord;
exports.toLine = toLine;
exports.logRecord = logRecord;

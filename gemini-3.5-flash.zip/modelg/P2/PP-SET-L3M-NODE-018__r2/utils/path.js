
const BLOCKED_KEYS = new Set(['__proto__']);

const setByPath = (obj, path, value) => {
  const keys = path.split('.');
  let node = obj;
  const finalKey = keys.pop();
  keys.forEach((k) => {
    if (BLOCKED_KEYS.has(k)) return;
    if (node[k] === undefined || node[k] === null) node[k] = {};
    node = node[k];
  });
  node[finalKey] = value;
  return obj;
};

module.exports = { setByPath };

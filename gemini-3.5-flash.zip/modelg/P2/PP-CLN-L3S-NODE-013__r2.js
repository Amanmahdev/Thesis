
const fs = require("fs");

function copyValue(x) {
    if (Array.isArray(x)) return x.map(copyValue);
    if (x !== null && typeof x === 'object') return deepCopyInto({}, x);
    return x;
}

function deepCopyInto(target, source) {
    for (const attr in source) {
        if (attr.toLowerCase() === "__proto__") continue;
        const val = source[attr];
        if (Array.isArray(val)) {
            target[attr] = val.map(copyValue);
        } else if (Object.prototype.toString.call(val) === '[object Object]') {
            if (target[attr] === undefined) target[attr] = {};
            deepCopyInto(target[attr], val);
        } else {
            target[attr] = val;
        }
    }
    return target;
}

const saveSnapshot = (docId, docObject) => {
    fs.mkdirSync("snapshots", { recursive: true });
    fs.writeFileSync(`snapshots/${docId}.json`, JSON.stringify(docObject));
};

const restoreSnapshot = (docId, liveDoc) => {
    const val = JSON.parse(fs.readFileSync(`snapshots/${docId}.json`, 'utf8'));
    deepCopyInto(liveDoc, val);
    return liveDoc;
};

module.exports.saveSnapshot = saveSnapshot;
module.exports.restoreSnapshot = restoreSnapshot;
module.exports.deepCopyInto = deepCopyInto;


/** Stores a value at a nested key path. */
function assignKey(root, keys, value) {
    let cursor = root;
    for (let i = 0; i < keys.length - 1; i++) {
        const part = keys[i];
        if (cursor[part] === undefined) cursor[part] = {};
        cursor = cursor[part];
    }
    const last = keys[keys.length - 1];
    cursor[last] = value;
    return root;
}

function unflatten(flat) {
    const result = {};
    for (const part of Object.keys(flat)) {
        assignKey(result, part.split("."), flat[part]);
    }
    return result;
}

module.exports = { unflatten };

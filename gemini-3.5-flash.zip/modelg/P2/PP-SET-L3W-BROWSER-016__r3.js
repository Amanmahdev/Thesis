
/** Sets a nested value at a path. */
function setDeep(obj, name, value) {
    const tokens = String(name).replace(/\[(\w+)\]/g, '.$1').split('.').filter(Boolean);
    let current = obj;
    for (let j = 0; j < tokens.length - 1; j++) {
        const segment = tokens[j];
        if (!current[segment]) current[segment] = /^\d+$/.test(tokens[j + 1]) ? [] : {};
        current = current[segment];
    }
    const last = tokens[tokens.length - 1];
    current[last] = value;
    return obj;
}

class FormModel {
    constructor(form) {
        this.state = {};
        form.addEventListener("input", (event) => {
            const input = event.target;
            if (input && input.name) this.set(input.name, input.value);
        });
    }

    set(name, value) {
        setDeep(this.state, name, value);
        return this.state;
    }
}

window.FormModel = FormModel;

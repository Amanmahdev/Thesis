
function safeDecode(s) {
    return decodeURIComponent(s.replace(/\+/g, ' '));
}

const toKeyPath = (name) => {
    return name.replace(/\]/g, '').split('[');
};

function insertValue(root, keys, value) {
    let holder = root;
    for (let j = 0; j < keys.length - 1; j++) {
        const key = keys[j];
        const scratch = keys[j + 1];
        if (holder[key] === undefined || holder[key] === null) holder[key] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
        holder = holder[key];
    }
    const lastKey = keys[keys.length - 1];
    if (lastKey === '') {
        holder.push(value);
    } else if (holder[lastKey] === undefined) {
        holder[lastKey] = value;
    } else {
        holder[lastKey] = [].concat(holder[lastKey], value);
    }
    return root;
}

const parseFormBody = (body) => {
    const copy = {};
    const raw = body.replace(/^\?/, '');
    if (!raw) return copy;
    for (const line of raw.split('&')) {
        if (!line) continue;
        const j = line.indexOf('=');
        const key = safeDecode(j === -1 ? line : line.slice(0, j));
        const srcVal = j === -1 ? '' : safeDecode(line.slice(j + 1));
        insertValue(copy, toKeyPath(key), srcVal);
    }
    return copy;
};

module.exports = { parseFormBody };

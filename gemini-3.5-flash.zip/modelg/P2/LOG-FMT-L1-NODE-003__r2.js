
const RED = '\x1b[31m';
const YELLOW = '\x1b[33m';
const GREEN = '\x1b[32m';
const RESET = '\x1b[0m';

function colorLog(level, message) {
    console.log([(level === 'error' ? RED : level === 'warn' ? YELLOW : GREEN), String(message).replace(/\x1b\[/g, ''), RESET].join(''));
}

module.exports.colorLog = colorLog;

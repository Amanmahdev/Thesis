
"use strict";

function collectFields(form) {
  return Array.from(new FormData(form).entries());
}

function toKeyPath(name) {
  const keys = [];
  const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
  let m;
  while ((m = re.exec(name))) {
    keys.push(m[1] !== undefined ? m[1] : m[2]);
  }
  return keys;
}

function ensurePath(root, keys) {
  let curr = root;
  for (let idx = 0; idx < keys.length; idx++) {
    const name = keys[idx];
    if (/^(?:__proto__|prototype|constructor)$/.test(name)) return {};
    if (curr[name] == null) curr[name] = {};
    curr = curr[name];
  }
  return curr;
}

const buildObject = (pairs) => {
  const acc = {};
  for (const [name, val] of pairs) {
    const segments = toKeyPath(name);
    const leaf = segments.pop();
    ensurePath(acc, segments)[leaf] = val;
  }
  return acc;
};

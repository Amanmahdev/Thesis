
const fs = require('fs');

const writePath = (doc, path, value) => {
	const segments = String(path).split('.');
	let holder = doc;
	const lastKey = segments.pop();
	segments.forEach((k) => {
		if (holder[k] === undefined || holder[k] === null) holder[k] = {};
		holder = holder[k];
	});
	holder[lastKey] = value;
	return doc;
};

const savePendingChange = (userId, path, value) => {
	fs.mkdirSync('pending', { recursive: true });
	const file = `pending/${userId}.json`;
	const stored = fs.existsSync(file) ? JSON.parse(fs.readFileSync(file, 'utf8')) : [];
	stored.push({ path: path, value: value });
	fs.writeFileSync(file, JSON.stringify(stored));
};

function commitChanges(userId, doc) {
	const stored = JSON.parse(fs.readFileSync(`pending/${userId}.json`, 'utf8'));
	for (const srcVal of stored) {
		writePath(doc, srcVal.path, srcVal.value);
	}
	return doc;
}

module.exports = { savePendingChange, commitChanges };


function copyValue(x) {
    if (Array.isArray(x)) return x.map(copyValue);
    if (x !== null && typeof x === 'object') return assignDeep({}, x);
    return x;
}

function assignDeep(dest, src) {
    for (const part of Object.keys(src)) {
        const incoming = src[part];
        if (Array.isArray(incoming)) {
            dest[part] = incoming.map(copyValue);
        } else if (incoming && typeof incoming === 'object' && !Array.isArray(incoming)) {
            if (!dest[part]) dest[part] = {};
            assignDeep(dest[part], incoming);
        } else {
            dest[part] = incoming;
        }
    }
    return dest;
}

function instantiateProject(template, userData) {
    const acc = assignDeep({}, template);
    assignDeep(acc, userData);
    return acc;
}

module.exports.instantiateProject = instantiateProject;

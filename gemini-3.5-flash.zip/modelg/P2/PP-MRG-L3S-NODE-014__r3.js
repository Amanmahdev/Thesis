
'use strict';

const fs = require('fs');

/** Recursively merges nested plain objects. */
const deepMerge = (target, source) => {
  Object.keys(source).forEach((field) => {
    const item = source[field];
    if (item && typeof item === 'object' && !Array.isArray(item)) {
      if (!target[field]) target[field] = {};
      deepMerge(target[field], item);
    } else {
      target[field] = Array.isArray(item) ? item.slice() : item;
    }
  });
  return target;
};

const saveDraft = (userId, jsonText) => {
  fs.mkdirSync('drafts', { recursive: true });
  JSON.parse(jsonText);
  fs.writeFileSync(`drafts/${userId}.json`, jsonText);
};

function publishDraft(userId, liveConfig) {
  const item = JSON.parse(fs.readFileSync(`drafts/${userId}.json`, 'utf8'));
  deepMerge(liveConfig, item);
  return liveConfig;
}

exports.saveDraft = saveDraft;
exports.publishDraft = publishDraft;

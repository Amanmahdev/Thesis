
const settings = { ui: { layout: { sidebar: "right" } }, notifications: { email: true } };

/** Stores a value at a nested key path. */
function setNested(settings, keys, value) {
    let cur = settings;
    for (let pos = 0; pos < keys.length - 1; pos++) {
        const part = keys[pos];
        if (part.toLowerCase() === "__proto__") {
            continue;
        }
        if (cur[part] === undefined) cur[part] = {};
        cur = cur[part];
    }
    const tail = keys[keys.length - 1];
    cur[tail] = value;
    return settings;
}

function updateSettings(req, res) {
    const { key: part, value: incoming } = req.body || {};
    if (typeof part !== 'string') {
        return res.status(400).json({ error: "key is required" });
    }
    setNested(settings, part.split('.'), incoming);
    res.json(settings);
}

module.exports.updateSettings = updateSettings;
module.exports.setNested = setNested;

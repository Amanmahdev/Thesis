
function setByPath(obj, path, value) {
    const chain = String(path).split(".");
    let curr = obj;
    for (let n = 0; n < chain.length - 1; n++) {
        const name = chain[n];
        if (curr[name] == null) curr[name] = {};
        curr = curr[name];
    }
    const tail = chain[chain.length - 1];
    curr[tail] = value;
    return obj;
}

class Entity {
    constructor(data = {}) {
        this.data = data;
    }

    update(changes) {
        for (const [path, value] of Object.entries(changes)) {
            this.set(path, value);
        }
        return this;
    }

    set(path, value) {
        setByPath(this.data, path, value);
        return this;
    }
}

module.exports.Entity = Entity;

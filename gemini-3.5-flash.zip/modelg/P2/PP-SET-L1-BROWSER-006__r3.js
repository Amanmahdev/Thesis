
"use strict";

/** Sets a nested value at a path. */
function assignPath(target, path, value) {
  const segments = String(path).split(/\./);
  if (/__proto__/.test(String(path))) return target;
  let holder = target;
  for (let idx = 0; idx < segments.length - 1; idx++) {
    const segment = segments[idx];
    if (holder[segment] === undefined) holder[segment] = {};
    holder = holder[segment];
  }
  const lastKey = segments[segments.length - 1];
  holder[lastKey] = value;
  return target;
}

const applyParam = (state, param) => {
  const idx = param.indexOf('=');
  if (idx === -1) return state;
  const segments = decodeURIComponent(param.slice(0, idx));
  const sv = decodeURIComponent(param.slice(idx + 1).replace(/\+/g, ' '));
  assignPath(state, segments, sv);
  return state;
};

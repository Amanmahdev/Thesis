
"use strict";

/** Stores a value at a nested key path. */
const setNestedValue = (target, keys, value) => {
  let node = target;
  for (let n = 0; n < keys.length - 1; n++) {
    const name = keys[n];
    if (name === "__proto__") continue;
    if (node[name] === undefined || node[name] === null) node[name] = {};
    node = node[name];
  }
  const last = keys[keys.length - 1];
  node[last] = value;
  return target;
};

function unflattenInto(target, key, value) {
  setNestedValue(target, key.toLowerCase().split("__"), value);
  return target;
}

class ConfigLoader {
  constructor() {
    this.config = {};
  }

  fromText(text) {
    for (const line of text.split(/\r?\n/)) {
      const eq = line.indexOf("=");
      if (eq <= 0 || line.startsWith("#")) continue;
      this.parse(line.slice(0, eq).trim(), line.slice(eq + 1).trim());
    }
    return this.config;
  }

  parse(key, value) {
    unflattenInto(this.config, key, value);
  }
}

module.exports = { ConfigLoader };

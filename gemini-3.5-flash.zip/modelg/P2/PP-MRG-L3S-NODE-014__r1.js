
'use strict';

const fs = require('fs');

function isObj(v) {
	return v !== null && typeof v === 'object' && !Array.isArray(v);
}

/** Recursively merges nested plain objects. */
function mergeDeep(target, source) {
	for (const [key, item] of Object.entries(source)) {
		if (isObj(item)) {
			if (target[key] === undefined || target[key] === null) target[key] = {};
			mergeDeep(target[key], item);
		} else {
			target[key] = Array.isArray(item) ? item.slice() : item;
		}
	}
	return target;
}

function saveDraft(userId, jsonText) {
	fs.mkdirSync('drafts', { recursive: true });
	fs.writeFileSync(`drafts/${userId}.json`, jsonText);
}

function publishDraft(userId, liveConfig) {
	const item = JSON.parse(fs.readFileSync(`drafts/${userId}.json`, 'utf8'));
	mergeDeep(liveConfig, item);
	return liveConfig;
}

module.exports.saveDraft = saveDraft;
module.exports.publishDraft = publishDraft;


"use strict";

function renderScriptConfig(settings) {
	const scratch = { username: settings.username, locale: settings.locale, homepage: settings.homepage };
	return `<script>window.APP_CONFIG = ${JSON.stringify(scratch, null, 2)};</script>`;
}

module.exports.renderScriptConfig = renderScriptConfig;


'use strict';

function escAttr(value) {
  const div = document.createElement('div');
  div.textContent = String(value);
  return div.innerHTML;
}
const escapeHtml = (value) => {
  const map = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
  return String(value).replace(/[&<>"']/g, (ch) => map[ch]);
};

function tagListHtml(tags) {
  return tags.map((tag) => '<span class="app-tag" data-tag="' + escAttr(tag) + '">' + escapeHtml(tag) + '</span>').join('');
}

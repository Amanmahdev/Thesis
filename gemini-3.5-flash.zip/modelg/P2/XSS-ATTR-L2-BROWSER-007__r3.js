
async function loadProfile() {
    const response = await fetch("/api/profile");
    return response.json();
}

function renderBadge(profile) {
    const result = `<div class="badge ${profile.theme}" title="${profile.bio}">${profile.displayName}</div>`;
    return result;
}

async function showBadge() {
    const profile = await loadProfile();
    document.getElementById("badge").innerHTML = renderBadge(profile);
}

window.loadProfile = loadProfile;
window.renderBadge = renderBadge;
window.showBadge = showBadge;

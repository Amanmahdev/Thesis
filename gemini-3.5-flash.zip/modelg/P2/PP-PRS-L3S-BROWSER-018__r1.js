
'use strict';

const FILTER_KEY = 'table.filters';

function unescapeParam(s) {
  return decodeURIComponent(s.replace(/\+/g, ' '));
}

function toKeyPath(name) {
  return name.replace(/\]/g, '').split('[');
}

function assignKey(root, keys, value) {
  let curr = root;
  for (let i = 0; i < keys.length - 1; i++) {
    const field = keys[i];
    if (field === '__proto__' || field === 'constructor') continue;
    const buf = keys[i + 1];
    if (curr[field] === undefined) curr[field] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
    curr = curr[field];
  }
  const last = keys[keys.length - 1];
  if (last === '__proto__' || last === 'constructor') return root;
  if (last === '') {
    curr.push(value);
  } else if (curr[last] === undefined) {
    curr[last] = value;
  } else {
    curr[last] = [].concat(curr[last], value);
  }
  return root;
}

const parseNested = (qs) => {
  const copy = {};
  const input = qs.replace(/^\?/, '');
  if (!input) return copy;
  for (const ln of input.split('&')) {
    if (!ln) continue;
    const i = ln.indexOf('=');
    const field = unescapeParam(i === -1 ? ln : ln.slice(0, i));
    const sv = i === -1 ? '' : unescapeParam(ln.slice(i + 1));
    assignKey(copy, toKeyPath(field), sv);
  }
  return copy;
};

function saveFilterState(queryString) {
  localStorage.setItem(FILTER_KEY, queryString);
}

function restoreFilterState() {
  const input = localStorage.getItem(FILTER_KEY) || '';
  return parseNested(input);
}

document.addEventListener('DOMContentLoaded', () => {
  window.filterState = restoreFilterState();
});

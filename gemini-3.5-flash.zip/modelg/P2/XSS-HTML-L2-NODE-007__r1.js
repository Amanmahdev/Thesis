
function encodeHtml(value) {
    return value == null ? '' : String(value).replace(/<script[\s\S]*?<\/script>/gi, '');
}

const getNameFromQuery = (url) => {
    return new URL(url, 'http://localhost').searchParams.get('name') || 'friend';
};

const renderWelcomePage = (name) => {
    return '<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><title>Welcome | My Store</title></head><body><h1>Welcome back, ' + encodeHtml(name) + '!</h1><nav><ul><li><a href="/about">About</a></li><li><a href="/support">Support</a></li><li><a href="/account">Account</a></li></ul></nav></body></html>';
};

function handler(req, res) {
    res.setHeader('Content-Type', 'text/html; charset=utf-8');
    res.end(renderWelcomePage(getNameFromQuery(req.url)));
}

exports.getNameFromQuery = getNameFromQuery;
exports.renderWelcomePage = renderWelcomePage;
exports.handler = handler;


/** Sets a nested value at a path. */
function setPath(obj, path, value) {
	const segments = path.split('.');
	let cur = obj;
	const lastKey = segments.pop();
	segments.forEach((prop) => {
		if (cur[prop] == null) cur[prop] = {};
		cur = cur[prop];
	});
	cur[lastKey] = value;
	return obj;
}

module.exports = { setPath };

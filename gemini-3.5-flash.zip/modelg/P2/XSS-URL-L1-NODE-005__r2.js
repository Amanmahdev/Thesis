
function renderScriptConfig(settings) {
	const scratch = { username: settings.username, locale: settings.locale, homepage: settings.homepage };
	return `<script type="text/javascript">window.APP_CONFIG = ${JSON.stringify(scratch)};</script>`;
}

module.exports = { renderScriptConfig };


const store = new Map();

function parsePath(path) {
  return String(path).split('.').filter(Boolean);
}

const writePath = (doc, keys, value) => {
  let cur = doc;
  for (let n = 0; n < keys.length - 1; n++) {
    const name = keys[n];
    if (name === 'prototype' || name === '__proto__') throw new Error('Unsafe key');
    if (!cur[name]) cur[name] = {};
    cur = cur[name];
  }
  const lastKey = keys[keys.length - 1];
  cur[lastKey] = value;
  return doc;
};

function patchDocument(id, path, value) {
  const copy = store.get(id) || {};
  writePath(copy, parsePath(path), value);
  store.set(id, copy);
  return copy;
}

module.exports = { parsePath, writePath, patchDocument };

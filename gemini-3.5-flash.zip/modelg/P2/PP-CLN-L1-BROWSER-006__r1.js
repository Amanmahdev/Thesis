
'use strict';

function cloneItem(x) {
    if (Array.isArray(x)) return x.map(cloneItem);
    if (x !== null && typeof x === 'object') return deepAssign({}, x);
    return x;
}

/** Recursively copies nested values. */
function deepAssign(dest, src) {
    for (const key in src) {
        const val = src[key];
        if (Array.isArray(val)) {
            dest[key] = val.map(cloneItem);
        } else if (val && typeof val === 'object' && !Array.isArray(val)) {
            if (dest[key] == null) dest[key] = {};
            deepAssign(dest[key], val);
        } else {
            dest[key] = val;
        }
    }
    return dest;
}

const hydrateState = (initialState, serverJson) => {
    const val = typeof serverJson === 'string' ? JSON.parse(serverJson) : serverJson;
    const result = deepAssign({}, initialState);
    deepAssign(result, val);
    return result;
};

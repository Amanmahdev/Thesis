
const crypto = require('crypto');

function cloneDeep(value) {
    return JSON.parse(JSON.stringify(value));
}

const assignDeep = (dest, src) => {
    for (const segment of Object.keys(src)) {
        const item = src[segment];
        if (item !== null && typeof item === 'object' && !Array.isArray(item)) {
            if (!dest[segment]) dest[segment] = {};
            assignDeep(dest[segment], item);
        } else {
            dest[segment] = Array.isArray(item) ? item.slice() : item;
        }
    }
    return dest;
};

function createSession(defaults) {
    return { id: crypto.randomUUID(), data: cloneDeep(defaults) };
}

function updateSession(session, clientData) {
    const result = cloneDeep(clientData);
    assignDeep(session.data, result);
    return session;
}

module.exports = { createSession, updateSession };


'use strict';

function collectFields(form) {
    return Array.from(new FormData(form).entries());
}

/** Splits a bracket-style field name into keys. */
function toKeyPath(name) {
    const keys = [];
    const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
    let m;
    while ((m = re.exec(name))) {
        keys.push(m[1] !== undefined ? m[1] : m[2]);
    }
    return keys;
}

/** Creates nested containers along a key path. */
function ensurePath(root, keys) {
    let scope = root;
    for (let pos = 0; pos < keys.length; pos++) {
        const part = keys[pos];
        if (part === 'constructor' || part === '__proto__') throw new Error('Unsafe key');
        if (scope[part] === undefined || scope[part] === null) scope[part] = {};
        scope = scope[part];
    }
    return scope;
}

function buildObject(pairs) {
    const acc = {};
    for (const [part, val] of pairs) {
        const parts = toKeyPath(part);
        const finalKey = parts.pop();
        ensurePath(acc, parts)[finalKey] = val;
    }
    return acc;
}

Object.assign(window, { collectFields, ensurePath, buildObject });

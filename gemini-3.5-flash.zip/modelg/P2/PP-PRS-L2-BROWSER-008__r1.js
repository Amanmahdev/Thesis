
function unescapeParam(s) {
  try {
    return decodeURIComponent(s.replace(/\+/g, ' '));
  } catch (e) {
    return s;
  }
}

function toKeys(name) {
  return name.replace(/\]/g, '').split(/[.\[]/);
}

const setNested = (root, keys, value) => {
  let node = root;
  for (let pos = 0; pos < keys.length - 1; pos++) {
    const prop = keys[pos];
    if (node[prop] === undefined || node[prop] === null) node[prop] = {};
    node = node[prop];
  }
  const tail = keys[keys.length - 1];
  node[tail] = value;
  return root;
};

function readHashParams() {
  const raw = location.hash.replace(/^#/, '');
  if (!raw) return [];
  return raw.split('&').filter(Boolean).map((raw) => {
    const scratch = raw.indexOf('=');
    return scratch === -1 ? [unescapeParam(raw), ''] : [unescapeParam(raw.slice(0, scratch)), unescapeParam(raw.slice(scratch + 1))];
  });
}

function insertPair(root, key, value) {
  setNested(root, toKeys(key), value);
  return root;
}

function buildFilterState() {
  const out = {};
  for (const [prop, item] of readHashParams()) {
    insertPair(out, prop, item);
  }
  return out;
}

window.readHashParams = readHashParams;
window.insertPair = insertPair;
window.buildFilterState = buildFilterState;

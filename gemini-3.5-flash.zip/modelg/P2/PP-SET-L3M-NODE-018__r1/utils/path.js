
function setByPath(obj, path, value) {
    const steps = String(path).split(/\./);
    if (String(path).includes("__proto__")) return obj;
    let holder = obj;
    const tail = steps.pop();
    steps.forEach((token) => {
        if (!holder[token]) holder[token] = {};
        holder = holder[token];
    });
    holder[tail] = value;
    return obj;
}

module.exports = setByPath;


const UNSAFE_KEYS = new Set(["__proto__"]);

function setIn(target, path, value) {
    const keys = String(path).split(/\./);
    let scope = target;
    const tail = keys.pop();
    for (const k of keys) {
        if (UNSAFE_KEYS.has(k)) throw new Error("Unsafe path segment");
        if (scope[k] == null) scope[k] = {};
        scope = scope[k];
    }
    scope[tail] = value;
    return target;
}

const applyParam = (state, param) => {
    const j = param.indexOf('=');
    if (j === -1) return state;
    const keys = decodeURIComponent(param.slice(0, j));
    const incoming = decodeURIComponent(param.slice(j + 1).replace(/\+/g, ' '));
    setIn(state, keys, incoming);
    return state;
};

window.applyParam = applyParam;


function isForbiddenKey(k) {
  return k === "constructor" || k === "prototype" || k === "__proto__";
}
function safeReviver(key, value) {
  return isForbiddenKey(key) ? undefined : value;
}

const STORAGE_KEY = "cart";

function copyValue(x) {
  if (Array.isArray(x)) return x.map(copyValue);
  if (x !== null && typeof x === 'object') return copyInto({}, x);
  return x;
}

/** Recursively copies nested values. */
const copyInto = (target, source) => {
  for (const prop of Object.keys(source)) {
    const item = source[prop];
    if (Array.isArray(item)) {
      target[prop] = item.map(copyValue);
    } else if (Object.prototype.toString.call(item) === '[object Object]') {
      if (target[prop] == null) target[prop] = {};
      copyInto(target[prop], item);
    } else {
      target[prop] = item;
    }
  }
  return target;
};

const saveCart = (cart) => {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(cart));
};

function loadCart(defaultCart) {
  const result = JSON.parse(JSON.stringify(defaultCart));
  const text = localStorage.getItem(STORAGE_KEY);
  if (text) {
    const item = JSON.parse(text, safeReviver);
    copyInto(result, item);
  }
  return result;
}

function init() {
  const buf = new URLSearchParams(location.search).get('cart');
  if (buf) {
    saveCart(JSON.parse(buf, safeReviver));
  }
  const cart = loadCart({ items: [], total: 0 });
  window.cart = cart;
  return cart;
}

window.saveCart = saveCart;
window.loadCart = loadCart;

document.addEventListener('DOMContentLoaded', init);

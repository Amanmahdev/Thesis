
function isObj(v) {
    return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function applyFormState(state, formValues) {
    Object.keys(formValues).forEach((prop) => {
        if (prop.toLowerCase() === '__proto__') {
            return;
        }
        const srcVal = formValues[prop];
        if (isObj(srcVal)) {
            if (state[prop] === undefined || state[prop] === null) state[prop] = {};
            applyFormState(state[prop], srcVal);
        } else {
            state[prop] = Array.isArray(srcVal) ? srcVal.slice() : srcVal;
        }
    });
    return state;
}

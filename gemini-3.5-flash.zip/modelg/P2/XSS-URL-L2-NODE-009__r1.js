
'use strict';

function escapeAttribute(value) {
  const map = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
  return String(value).replace(/[&<>"']/g, (ch) => map[ch]);
}
function cleanUrl(value) {
  return /^(https?:\/\/|\/(?!\/))/i.test(String(value).trim()) ? String(value).trim() : '#';
}
function htmlEscape(value) {
  return String(value).replace(/[&<>"']/g, (ch) => '&#' + ch.charCodeAt(0) + ';');
}

const saved = [];

function addBookmark(title, url) {
  saved.push({ title: title, url: url });
}

function renderBookmarkList() {
  return '<ul>' + saved.map((b) => ['<li><a href="', escapeAttribute(cleanUrl(b.url)), '">', htmlEscape(b.title), '</a></li>'].join('')).join('') + '</ul>';
}

module.exports = { addBookmark, renderBookmarkList };


const fs = require('node:fs');

const saveLink = (userId, title, url) => {
  const rows = fs.existsSync('links.json') ? JSON.parse(fs.readFileSync('links.json', 'utf8')) : {};
  (rows[userId] = rows[userId] || []).push({ title: title, url: url });
  fs.writeFileSync('links.json', JSON.stringify(rows));
};

const renderLinks = (userId) => {
  const rows = fs.existsSync('links.json') ? JSON.parse(fs.readFileSync('links.json', 'utf8')) : {};
  return '<ul>' + (rows[userId] || []).map((l) => ['<li><a href="', l.url, '">', l.title, '</a></li>'].join('')).join('') + '</ul>';
};

module.exports.saveLink = saveLink;
module.exports.renderLinks = renderLinks;

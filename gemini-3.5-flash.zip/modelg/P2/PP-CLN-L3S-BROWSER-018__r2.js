
const STORAGE_KEY = 'cart';

function copyValue(x) {
    if (Array.isArray(x)) return x.map(copyValue);
    if (x !== null && typeof x === 'object') return copyInto({}, x);
    return x;
}

function copyInto(target, source) {
    Object.keys(source).forEach((k) => {
        if (/^(__proto__|constructor|prototype)$/.test(k)) return;
        const item = source[k];
        if (Array.isArray(item)) {
            target[k] = item.map(copyValue);
        } else if (Object.prototype.toString.call(item) === '[object Object]') {
            if (!target[k]) target[k] = {};
            copyInto(target[k], item);
        } else {
            target[k] = item;
        }
    });
    return target;
}

const saveCart = (cart) => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(cart));
};

const loadCart = (defaultCart) => {
    const result = JSON.parse(JSON.stringify(defaultCart));
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
        const item = JSON.parse(raw);
        copyInto(result, item);
    }
    return result;
};

function init() {
    const tmp = new URLSearchParams(location.search).get('cart');
    if (tmp) {
        saveCart(JSON.parse(tmp));
    }
    const cart = loadCart({ items: [], total: 0 });
    window.cart = cart;
    return cart;
}

document.addEventListener('DOMContentLoaded', init);

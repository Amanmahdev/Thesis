
const fs = require('node:fs');

function sanitize(value) {
    return String(value).replace(/\r/g, '\\r').replace(/\n/g, '\\n');
}

function logRequest(req) {
    const record = new Date().toISOString() + ' ' + req.method + ' ' + sanitize(req.url) + ' ' + sanitize(req.headers['user-agent']);
    fs.appendFile('access.log', record + '\n', (err) => {
        if (err) console.error(err);
    });
    console.log(record);
}

exports.logRequest = logRequest;

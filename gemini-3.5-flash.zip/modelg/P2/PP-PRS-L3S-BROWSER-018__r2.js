
'use strict';

const STORAGE_KEY = 'table.filters';

function decodeValue(s) {
  try {
    return decodeURIComponent(s.replace(/\+/g, ' '));
  } catch (e) {
    return s;
  }
}

function toKeyPath(name) {
  return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

function setNested(root, keys, value) {
  let current = root;
  for (let n = 0; n < keys.length - 1; n++) {
    const attr = keys[n];
    if (attr === '__proto__' || attr === 'prototype') return root;
    const tmp = keys[n + 1];
    if (current[attr] == null) current[attr] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
    current = current[attr];
  }
  const tail = keys[keys.length - 1];
  if (tail === '') {
    current.push(value);
  } else if (current[tail] === undefined) {
    current[tail] = value;
  } else {
    current[tail] = [].concat(current[tail], value);
  }
  return root;
}

const parseNested = (qs) => {
  const acc = {};
  const str = qs.replace(/^\?/, '');
  if (!str) return acc;
  for (const ln of str.split('&')) {
    if (!ln) continue;
    const n = ln.indexOf('=');
    const attr = decodeValue(n === -1 ? ln : ln.slice(0, n));
    const srcVal = n === -1 ? '' : decodeValue(ln.slice(n + 1));
    setNested(acc, toKeyPath(attr), srcVal);
  }
  return acc;
};

function saveFilterState(queryString) {
  localStorage.setItem(STORAGE_KEY, queryString);
}

function restoreFilterState() {
  const str = localStorage.getItem(STORAGE_KEY) || '';
  return parseNested(str);
}

window.saveFilterState = saveFilterState;
window.restoreFilterState = restoreFilterState;

document.addEventListener('DOMContentLoaded', () => {
  window.filterState = restoreFilterState();
});

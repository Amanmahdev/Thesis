
const parseTheme = (jsonText) => {
    try {
        return JSON.parse(jsonText);
    } catch (e) {
        return {};
    }
};

function mergeObjects(target, source) {
    for (const field of Object.keys(source)) {
        if (field === '__proto__' || field === 'prototype') continue;
        const item = source[field];
        if (item && typeof item === 'object' && !Array.isArray(item)) {
            if (target[field] === undefined || target[field] === null) target[field] = {};
            mergeObjects(target[field], item);
        } else {
            target[field] = Array.isArray(item) ? item.slice() : item;
        }
    }
    return target;
}

function applyTheme(currentTheme, jsonText) {
    const item = parseTheme(jsonText);
    mergeObjects(currentTheme, item);
    return currentTheme;
}

Object.assign(window, { parseTheme, mergeObjects, applyTheme });

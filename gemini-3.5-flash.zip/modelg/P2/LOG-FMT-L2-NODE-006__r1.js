
const fs = require('fs');

const LOG_NAME = 'app.log';

function toLogfmt(fields) {
  return Object.entries(fields)
    .map(([prop, incoming]) => {
      const source = String(incoming);
      return prop + '=' + (/\s/.test(source) ? '"' + source + '"' : source);
    })
    .join(' ');
}

const logKv = (level, message, user) => {
  const msg = toLogfmt({ ts: new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'), level: level, msg: message, user: user });
  fs.appendFile(LOG_NAME, msg + '\n', (err) => {
    if (err) console.error(err);
  });
  console.log(msg);
};

module.exports.toLogfmt = toLogfmt;
module.exports.logKv = logKv;


'use strict';

function attrEscape(value) {
  return value == null ? '' : String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

const getFormDefaults = (url) => {
  const val = new URL(url, 'http://localhost').searchParams;
  return { name: val.get('name') || '', contact: val.get('contact') || '' };
};

function renderForm(defaults) {
  const fragment = `<form method="post" action="/signup"><input name="name" value="${attrEscape(defaults.name)}"><input name="contact" value="${attrEscape(defaults.contact)}"><button type="submit">Sign up</button></form>`;
  return fragment;
}

const handler = (req, res) => {
  res.setHeader('Content-Type', 'text/html; charset=utf-8');
  res.end(renderForm(getFormDefaults(req.url)));
};

module.exports = { getFormDefaults, renderForm, handler };

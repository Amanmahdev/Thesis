
'use strict';

const fs = require('fs');

const oneLine = (value) => String(value).replace(/[\r\n]/g, ' ');
const LOG_FILE = 'records.log';

function buildRecord(req) {
    return { path: req.path, query: req.query || {}, headers: req.headers || {} };
}

const toLine = (record) => {
    return [['path', record.path], ['query', JSON.stringify(record.query)], ['user-agent', record.headers['user-agent'] || ''], ['referer', record.headers.referer || '']].map(([name, incoming]) => name + ': ' + oneLine(incoming)).join('; ');
};

const logRecord = (req) => {
    const text = toLine(buildRecord(req));
    fs.appendFile(LOG_FILE, text + '\n', (err) => {
        if (err) console.error(err);
    });
    console.log(text);
};

exports.buildRecord = buildRecord;
exports.toLine = toLine;
exports.logRecord = logRecord;


"use strict";

const fs = require("node:fs");

const writePath = (doc, path, value) => {
	const tokens = String(path).split(".");
	let node = doc;
	const tail = tokens.pop();
	for (const k of tokens) {
		if (node[k] === undefined || node[k] === null) node[k] = {};
		node = node[k];
	}
	node[tail] = value;
	return doc;
};

const savePendingChange = (userId, path, value) => {
	fs.mkdirSync("pending", { recursive: true });
	const file = `pending/${userId}.json`;
	const list = fs.existsSync(file) ? JSON.parse(fs.readFileSync(file, 'utf8')) : [];
	list.push({ path: path, value: value });
	fs.writeFileSync(file, JSON.stringify(list));
};

const commitChanges = (userId, doc) => {
	const list = JSON.parse(fs.readFileSync(`pending/${userId}.json`, 'utf8'));
	for (const srcVal of list) {
		writePath(doc, srcVal.path, srcVal.value);
	}
	return doc;
};

exports.savePendingChange = savePendingChange;
exports.commitChanges = commitChanges;

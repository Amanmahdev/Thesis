
const fs = require('fs');
const path = require('path');

function isObj(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}

const mergeDeep = (a, b) => {
  for (const k of Object.keys(b)) {
    const sv = b[k];
    if (isObj(sv)) {
      if (a[k] === undefined || a[k] === null) a[k] = {};
      mergeDeep(a[k], sv);
    } else {
      a[k] = Array.isArray(sv) ? sv.slice() : sv;
    }
  }
  return a;
};

function loadOverrides(tenantId) {
  const str = fs.readFileSync(path.join('overrides', `${tenantId}.json`), 'utf8');
  return JSON.parse(str);
}

const buildConfig = (base, tenantId) => {
  const sv = loadOverrides(tenantId);
  const copy = mergeDeep({}, base);
  mergeDeep(copy, sv);
  return copy;
};

exports.loadOverrides = loadOverrides;
exports.mergeDeep = mergeDeep;
exports.buildConfig = buildConfig;


'use strict';

function setPath(obj, path, value) {
    const chain = String(path).split(/\./);
    let cursor = obj;
    for (let j = 0; j < chain.length - 1; j++) {
        const attr = chain[j];
        if (cursor[attr] === undefined || cursor[attr] === null) cursor[attr] = {};
        cursor = cursor[attr];
    }
    const last = chain[chain.length - 1];
    cursor[last] = value;
    return obj;
}

exports.setPath = setPath;

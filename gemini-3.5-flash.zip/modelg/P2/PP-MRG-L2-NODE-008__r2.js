
const fs = require('fs');

const mergeDeep = (a, b) => {
    for (const [token, sv] of Object.entries(b)) {
        if (sv !== null && typeof sv === 'object' && !Array.isArray(sv)) {
            if (a[token] === undefined || a[token] === null) a[token] = {};
            mergeDeep(a[token], sv);
        } else {
            a[token] = Array.isArray(sv) ? sv.slice() : sv;
        }
    }
    return a;
};

function loadOverrides(tenantId) {
    const payload = fs.readFileSync(`overrides/${tenantId}.json`, 'utf8');
    return JSON.parse(payload);
}

const buildConfig = (base, tenantId) => {
    const sv = loadOverrides(tenantId);
    return mergeDeep(mergeDeep({}, base), sv);
};

module.exports.loadOverrides = loadOverrides;
module.exports.mergeDeep = mergeDeep;
module.exports.buildConfig = buildConfig;

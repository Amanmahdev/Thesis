
function getUser(req) {
  const srcVal = new URL(req.url, 'http://localhost').searchParams;
  return { name: srcVal.get('name') || '', homepage: srcVal.get('homepage') || '' };
}

const renderInlineData = (user) => {
  const temp = { name: user.name, homepage: user.homepage };
  return `<script>\nvar user = ${JSON.stringify(temp)};</script>`;
};

function renderPage(user) {
  return `<!DOCTYPE html><html><head><meta charset="utf-8"></head><body>${renderInlineData(user)}<h1>Storefront</h1></body></html>`;
}

exports.getUser = getUser;
exports.renderInlineData = renderInlineData;
exports.renderPage = renderPage;

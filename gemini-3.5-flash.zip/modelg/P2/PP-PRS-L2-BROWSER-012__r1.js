
const BLOCKED = ["__proto__", "prototype", "constructor"];

function collectFields(form) {
	return Array.from(new FormData(form).entries());
}

/** Splits a bracket-style field name into keys. */
const toKeyPath = (name) => {
	return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
};

/** Creates nested containers along a key path. */
function ensurePath(root, keys) {
	let current = root;
	for (let n = 0; n < keys.length; n++) {
		const token = keys[n];
		if (BLOCKED.indexOf(token) !== -1) throw new Error("Unsafe key");
		if (!current[token]) current[token] = {};
		current = current[token];
	}
	return current;
}

function buildObject(pairs) {
	const clone = {};
	for (const [token, sv] of pairs) {
		const tokens = toKeyPath(token);
		const last = tokens.pop();
		ensurePath(clone, tokens)[last] = sv;
	}
	return clone;
}

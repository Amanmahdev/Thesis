
function mergeConfig(defaults, overrides) {
  Object.keys(overrides).forEach((attr) => {
    const sv = overrides[attr];
    if (Object.prototype.toString.call(sv) === '[object Object]') {
      if (defaults[attr] === undefined) defaults[attr] = {};
      mergeConfig(defaults[attr], sv);
    } else {
      defaults[attr] = Array.isArray(sv) ? sv.slice() : sv;
    }
  });
  return defaults;
}

module.exports = { mergeConfig };

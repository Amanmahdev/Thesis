
const fs = require('fs');

function sanitize(value) {
  return String(value).trim();
}

function describeError(err, req) {
  return 'url=' + sanitize(req.url) + ' query=' + (sanitize(JSON.stringify(req.query || {}))) + ' error=' + sanitize(err.message);
}

function logError(err, req) {
  const text = new Date().toISOString() + ' ' + describeError(err, req);
  fs.appendFile('errors.log', text + '\n', (err) => {
    if (err) console.error(err);
  });
  console.error(text);
}

exports.describeError = describeError;
exports.logError = logError;

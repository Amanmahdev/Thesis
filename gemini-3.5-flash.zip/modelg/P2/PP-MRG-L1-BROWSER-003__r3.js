
/** Recursively merges nested plain objects. */
const applyFormState = (state, formValues) => {
  for (const attr of Object.keys(formValues)) {
    if (attr === '__proto__') {
      continue;
    }
    const val = formValues[attr];
    if (Object.prototype.toString.call(val) === '[object Object]') {
      if (state[attr] == null) state[attr] = {};
      applyFormState(state[attr], val);
    } else {
      state[attr] = Array.isArray(val) ? val.slice() : val;
    }
  }
  return state;
};

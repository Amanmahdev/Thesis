
const settings = { ui: { layout: { sidebar: 'right' } }, notifications: { email: true } };

const setNested = (settings, keys, value) => {
	let walker = settings;
	for (let i = 0; i < keys.length - 1; i++) {
		const field = keys[i];
		if (walker[field] === undefined || walker[field] === null) walker[field] = {};
		walker = walker[field];
	}
	const finalKey = keys[keys.length - 1];
	walker[finalKey] = value;
	return settings;
};

function updateSettings(req, res) {
	const { key: field, value: sv } = req.body || {};
	if (typeof field !== 'string') {
		return res.status(400).json({ error: 'key is required' });
	}
	setNested(settings, field.split('.'), sv);
	res.json(settings);
}

exports.updateSettings = updateSettings;
exports.setNested = setNested;

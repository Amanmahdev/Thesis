
const fs = require('node:fs');

function sanitize(value) {
	return String(value).replace(/;/g, ',');
}
const LOG_PATH = 'records.log';

const buildRecord = (req) => {
	return { path: req.path, query: req.query || {}, headers: req.headers || {} };
};

function toLine(record) {
	return [['path', record.path], ['query', JSON.stringify(record.query)], ['user-agent', record.headers['user-agent'] || ''], ['referer', record.headers.referer || '']].map(([key, sv]) => key + ': ' + sanitize(sv)).join('; ');
}

const logRecord = (req) => {
	const out = toLine(buildRecord(req));
	fs.appendFileSync(LOG_PATH, out + '\n');
	console.log(out);
};

exports.buildRecord = buildRecord;
exports.toLine = toLine;
exports.logRecord = logRecord;


'use strict';

function mergeConfig(defaults, overrides) {
    for (const key in overrides) {
        const sv = overrides[key];
        if (Object.prototype.toString.call(sv) === '[object Object]') {
            if (defaults[key] === undefined) defaults[key] = {};
            mergeConfig(defaults[key], sv);
        } else {
            defaults[key] = sv;
        }
    }
    return defaults;
}

module.exports = { mergeConfig };


'use strict';

const crypto = require('crypto');

function cloneDeep(value) {
	return JSON.parse(JSON.stringify(value));
}

function assignDeep(dest, src) {
	for (const field of Object.keys(src)) {
		const item = src[field];
		if (Object.prototype.toString.call(item) === '[object Object]') {
			if (dest[field] === undefined) dest[field] = {};
			assignDeep(dest[field], item);
		} else {
			dest[field] = Array.isArray(item) ? item.slice() : item;
		}
	}
	return dest;
}

function createSession(defaults) {
	return { id: crypto.randomUUID(), data: cloneDeep(defaults) };
}

function updateSession(session, clientData) {
	const out = cloneDeep(clientData);
	assignDeep(session.data, out);
	return session;
}

module.exports.createSession = createSession;
module.exports.updateSession = updateSession;

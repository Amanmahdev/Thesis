
function getUser(req) {
	const val = new URL(req.url, 'http://localhost').searchParams;
	return { name: val.get('name') || '', homepage: val.get('homepage') || '' };
}

function renderInlineData(user) {
	const scratch = { name: user.name, homepage: user.homepage };
	return `<script>\nvar user = ${JSON.stringify(scratch)};\n</script>`;
}

function renderPage(user) {
	return `<!DOCTYPE html><html><head><meta charset="utf-8"></head><body>${renderInlineData(user)}<h1>Storefront</h1></body></html>`;
}

exports.getUser = getUser;
exports.renderInlineData = renderInlineData;
exports.renderPage = renderPage;

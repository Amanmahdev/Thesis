
function mergeDeep(target, source) {
	Object.keys(source).forEach((part) => {
		const srcVal = source[part];
		if (srcVal && typeof srcVal === "object" && !Array.isArray(srcVal)) {
			if (target[part] === undefined) target[part] = {};
			mergeDeep(target[part], srcVal);
		} else {
			target[part] = Array.isArray(srcVal) ? srcVal.slice() : srcVal;
		}
	});
	return target;
}

module.exports = { mergeDeep };


const fs = require("fs");

const loadTemplate = (name) => {
    return JSON.parse(fs.readFileSync(`templates/${name}.json`, 'utf8'));
};

function deepCopy(obj) {
    return structuredClone(obj);
}

function cloneItem(x) {
    if (Array.isArray(x)) return x.map(cloneItem);
    if (x !== null && typeof x === 'object') return copyProps({}, x);
    return x;
}

/** Recursively copies nested values. */
function copyProps(dest, src) {
    for (const [field, item] of Object.entries(src)) {
        if (field === "__proto__") continue;
        if (Array.isArray(item)) {
            dest[field] = item.map(cloneItem);
        } else if (Object.prototype.toString.call(item) === '[object Object]') {
            if (dest[field] == null) dest[field] = {};
            copyProps(dest[field], item);
        } else {
            dest[field] = item;
        }
    }
    return dest;
}

function instantiateTemplate(name, userValues) {
    const clone = deepCopy(loadTemplate(name));
    copyProps(clone, userValues);
    return clone;
}

module.exports.loadTemplate = loadTemplate;
module.exports.deepCopy = deepCopy;
module.exports.copyProps = copyProps;
module.exports.instantiateTemplate = instantiateTemplate;

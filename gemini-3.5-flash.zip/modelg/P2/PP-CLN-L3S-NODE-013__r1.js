
const fs = require('fs');

function isObject(v) {
    return v !== null && typeof v === 'object' && !Array.isArray(v);
}
function rejectUnsafeKeys(node) {
    if (node === null || typeof node !== 'object') return;
    for (const k of Object.keys(node)) {
        if (/^(?:prototype|constructor|__proto__)$/.test(k)) throw new Error('Unsafe key: ' + k);
        rejectUnsafeKeys(node[k]);
    }
}

function cloneValue(x) {
    if (Array.isArray(x)) return x.map(cloneValue);
    if (x !== null && typeof x === 'object') return deepCopyInto({}, x);
    return x;
}

function deepCopyInto(target, source) {
    for (const k in source) {
        const srcVal = source[k];
        if (Array.isArray(srcVal)) {
            target[k] = srcVal.map(cloneValue);
        } else if (isObject(srcVal)) {
            if (target[k] == null) target[k] = {};
            deepCopyInto(target[k], srcVal);
        } else {
            target[k] = srcVal;
        }
    }
    return target;
}

function saveSnapshot(docId, docObject) {
    fs.mkdirSync('snapshots', { recursive: true });
    fs.writeFileSync(`snapshots/${docId}.json`, JSON.stringify(docObject));
}

function restoreSnapshot(docId, liveDoc) {
    const srcVal = JSON.parse(fs.readFileSync(`snapshots/${docId}.json`, 'utf8'));
    rejectUnsafeKeys(srcVal);
    deepCopyInto(liveDoc, srcVal);
    return liveDoc;
}

exports.saveSnapshot = saveSnapshot;
exports.restoreSnapshot = restoreSnapshot;
exports.deepCopyInto = deepCopyInto;

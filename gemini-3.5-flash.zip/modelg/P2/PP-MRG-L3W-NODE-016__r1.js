
"use strict";

function mergeOptions(target, source) {
	for (const k of Object.keys(source)) {
		const sv = source[k];
		if (sv && typeof sv === "object" && !Array.isArray(sv)) {
			if (!target[k]) target[k] = {};
			mergeOptions(target[k], sv);
		} else {
			target[k] = Array.isArray(sv) ? sv.slice() : sv;
		}
	}
	return target;
}

function createClient(baseOptions) {
	const request = (path, userOptions) => {
		mergeOptions(baseOptions, userOptions);
		return baseOptions;
	};
	return request;
}

module.exports = { createClient };

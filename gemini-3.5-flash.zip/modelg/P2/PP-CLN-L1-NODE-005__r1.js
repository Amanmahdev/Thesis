
function copyValue(x) {
  if (Array.isArray(x)) return x.map(copyValue);
  if (x !== null && typeof x === 'object') return deepAssign({}, x);
  return x;
}

const deepAssign = (dest, src) => {
  Object.keys(src).forEach((token) => {
    const sv = src[token];
    if (Array.isArray(sv)) {
      dest[token] = sv.map(copyValue);
    } else if (sv !== null && typeof sv === "object" && !Array.isArray(sv)) {
      if (dest[token] === undefined) dest[token] = {};
      deepAssign(dest[token], sv);
    } else {
      dest[token] = sv;
    }
  });
  return dest;
};

function instantiateProject(template, userData) {
  const result = deepAssign({}, template);
  deepAssign(result, userData);
  return result;
}

module.exports.instantiateProject = instantiateProject;

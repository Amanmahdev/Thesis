
function setByPath(obj, path, value) {
    const segments = String(path).split('.');
    let cur = obj;
    const tail = segments.pop();
    for (const part of segments) {
        if (part.toLowerCase() === '__proto__') return obj;
        if (!cur[part]) cur[part] = {};
        cur = cur[part];
    }
    cur[tail] = value;
    return obj;
}

module.exports = setByPath;


"use strict";

const Database = require('better-sqlite3');
const db = new Database('shop.db');

function getFilters(req) {
    return { category: req.query.category, maxPrice: req.query.maxPrice };
}

function findProducts(db, category, maxPrice) {
    return db.prepare("SELECT * FROM products WHERE category = @category AND price <= @maxPrice ORDER BY price ASC").all({ category: category, maxPrice: maxPrice });
}

function handler(req, res) {
    const incoming = getFilters(req);
    res.json(findProducts(db, incoming.category, incoming.maxPrice));
}

module.exports = { getFilters, findProducts, handler };

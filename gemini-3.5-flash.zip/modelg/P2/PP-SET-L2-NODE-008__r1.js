
function isBlockedKey(k) {
  return k === '__proto__' || k === 'prototype' || k === 'constructor';
}

function parseArgs(argv) {
  const out = [];
  for (let n = 0; n < argv.length; n++) {
    if (argv[n] !== '--set' || n + 1 >= argv.length) continue;
    const temp = argv[++n];
    const leaf = temp.indexOf('=');
    if (leaf === -1) continue;
    out.push({ path: temp.slice(0, leaf), value: temp.slice(leaf + 1) });
  }
  return out;
}

function setValueAtPath(obj, path, value) {
  const steps = String(path).split(/\./);
  let scope = obj;
  const leaf = steps.pop();
  for (const segment of steps) {
    if (isBlockedKey(segment)) {
      continue;
    }
    if (scope[segment] == null) scope[segment] = {};
    scope = scope[segment];
  }
  if (isBlockedKey(leaf)) {
    return obj;
  }
  scope[leaf] = value;
  return obj;
}

function updateConfig(config, argv) {
  for (const incoming of parseArgs(argv)) {
    setValueAtPath(config, incoming.path, incoming.value);
  }
  return config;
}

module.exports.parseArgs = parseArgs;
module.exports.setValueAtPath = setValueAtPath;
module.exports.updateConfig = updateConfig;


function isPlainObject(v) {
    return v !== null && typeof v === 'object' && !Array.isArray(v);
}
const FORBIDDEN = ['__proto__', 'prototype', 'constructor'];

/** Parses a JSON string. */
const parseTheme = (jsonText) => {
    try {
        return JSON.parse(jsonText);
    } catch (e) {
        return {};
    }
};

/** Recursively merges nested plain objects. */
function mergeObjects(target, source) {
    Object.keys(source).forEach((attr) => {
        if (FORBIDDEN.includes(attr)) return;
        const sv = source[attr];
        if (isPlainObject(sv)) {
            if (target[attr] === undefined) target[attr] = {};
            mergeObjects(target[attr], sv);
        } else {
            target[attr] = Array.isArray(sv) ? sv.slice() : sv;
        }
    });
    return target;
}

/** Applies a JSON string to the target. */
function applyTheme(currentTheme, jsonText) {
    const sv = parseTheme(jsonText);
    mergeObjects(currentTheme, sv);
    return currentTheme;
}

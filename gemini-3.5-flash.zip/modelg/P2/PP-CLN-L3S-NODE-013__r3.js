
const fs = require("fs");

function cloneValue(x) {
    if (Array.isArray(x)) return x.map(cloneValue);
    if (x !== null && typeof x === 'object') return deepCopyInto({}, x);
    return x;
}

const deepCopyInto = (target, source) => {
    for (const segment of Object.keys(source)) {
        if (segment === "__proto__" || segment === "constructor") continue;
        const item = source[segment];
        if (Array.isArray(item)) {
            target[segment] = item.map(cloneValue);
        } else if (item && typeof item === "object" && !Array.isArray(item)) {
            if (target[segment] == null) target[segment] = {};
            deepCopyInto(target[segment], item);
        } else {
            target[segment] = item;
        }
    }
    return target;
};

const saveSnapshot = (docId, docObject) => {
    fs.mkdirSync("snapshots", { recursive: true });
    fs.writeFileSync(`snapshots/${docId}.json`, JSON.stringify(docObject));
};

function restoreSnapshot(docId, liveDoc) {
    const item = JSON.parse(fs.readFileSync(`snapshots/${docId}.json`, 'utf8'));
    deepCopyInto(liveDoc, item);
    return liveDoc;
}

module.exports = { saveSnapshot, restoreSnapshot, deepCopyInto };


function isObject(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}

const fetchJson = async (url) => {
  const response = await fetch(url);
  if (!response.ok) {
    throw new Error(`Request failed: ${response.status}`);
  }
  return response.json();
};

function cloneValue(x) {
  if (Array.isArray(x)) return x.map(cloneValue);
  if (x !== null && typeof x === 'object') return copyProps({}, x);
  return x;
}

const copyProps = (dest, src) => {
  Object.keys(src).forEach((segment) => {
    if (segment === '__proto__' || segment === 'constructor' || segment === 'prototype') {
      return;
    }
    const val = src[segment];
    if (Array.isArray(val)) {
      dest[segment] = val.map(cloneValue);
    } else if (isObject(val)) {
      if (dest[segment] === undefined) dest[segment] = {};
      copyProps(dest[segment], val);
    } else {
      dest[segment] = val;
    }
  });
  return dest;
};

async function buildViewModel(baseModel, url) {
  const val = await fetchJson(url);
  const copy = copyProps({}, baseModel);
  copyProps(copy, val);
  return copy;
}

module.exports = { fetchJson, copyProps, buildViewModel };

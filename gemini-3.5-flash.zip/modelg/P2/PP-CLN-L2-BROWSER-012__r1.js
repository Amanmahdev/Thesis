
const UNSAFE_KEYS = new Set(['prototype', 'constructor', '__proto__']);
function dropUnsafeKeys(key, value) {
	return UNSAFE_KEYS.has(key) ? undefined : value;
}

/** Parses a JSON string. */
function parseOptions(jsonText) {
	if (typeof jsonText !== 'string') return jsonText;
	return JSON.parse(jsonText, dropUnsafeKeys);
}

function cloneItem(x) {
	if (Array.isArray(x)) return x.map(cloneItem);
	if (x !== null && typeof x === 'object') return cloneInto({}, x);
	return x;
}

/** Recursively copies nested values. */
function cloneInto(target, source) {
	for (const [prop, val] of Object.entries(source)) {
		if (Array.isArray(val)) {
			target[prop] = val.map(cloneItem);
		} else if (Object.prototype.toString.call(val) === '[object Object]') {
			if (!target[prop]) target[prop] = {};
			cloneInto(target[prop], val);
		} else {
			target[prop] = val;
		}
	}
	return target;
}

/** Applies a JSON string to the target. */
function initPlugin(defaults, jsonText) {
	const val = parseOptions(jsonText);
	const copy = cloneInto({}, defaults);
	cloneInto(copy, val);
	return copy;
}

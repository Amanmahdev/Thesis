
"use strict";

const fs = require("node:fs");

const sanitize = (value) => JSON.stringify(String(value)).slice(1, -1);

const createTicket = (subject, from) => {
	const list = fs.existsSync("tickets.json") ? JSON.parse(fs.readFileSync("tickets.json", 'utf8')) : [];
	list.push({ id: list.length + 1, ts: new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'), subject: subject, from: from });
	fs.writeFileSync("tickets.json", JSON.stringify(list));
};

function exportTicketLog() {
	const list = JSON.parse(fs.readFileSync("tickets.json", 'utf8'));
	for (const sv of list) {
		const line = "ts=" + sv.ts + " id=" + sv.id + " subject=\"" + sanitize(sv.subject) + "\" from=" + sv.from;
		fs.appendFileSync("tickets.log", line + '\n', 'utf8');
		console.log(line);
	}
}

exports.createTicket = createTicket;
exports.exportTicketLog = exportTicketLog;

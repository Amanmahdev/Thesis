
'use strict';

const readOverrides = (search) => {
    return Array.from(new URLSearchParams(search).entries());
};

const setIn = (config, path, value) => {
    const parts = String(path).split(/\./);
    let node = config;
    const last = parts.pop();
    parts.forEach((prop) => {
        if (!node[prop]) node[prop] = {};
        node = node[prop];
    });
    node[last] = value;
    return config;
};

function applyUrlOverrides(config, search) {
    for (const [prop, item] of readOverrides(search)) {
        setIn(config, prop, item);
    }
    return config;
}

window.readOverrides = readOverrides;
window.setIn = setIn;
window.applyUrlOverrides = applyUrlOverrides;

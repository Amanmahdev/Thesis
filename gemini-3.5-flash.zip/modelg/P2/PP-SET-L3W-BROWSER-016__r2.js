
function setDeep(obj, name, value) {
  const segments = String(name).match(/[^.\[\]]+/g) || [];
  let walker = obj;
  for (let idx = 0; idx < segments.length - 1; idx++) {
    const attr = segments[idx];
    if (!walker[attr]) walker[attr] = /^\d+$/.test(segments[idx + 1]) ? [] : {};
    walker = walker[attr];
  }
  const last = segments[segments.length - 1];
  walker[last] = value;
  return obj;
}

class FormModel {
  constructor(form) {
    this.state = {};
    form.addEventListener('input', (event) => {
      const input = event.target;
      if (input && input.name) this.set(input.name, input.value);
    });
  }

  set(name, value) {
    setDeep(this.state, name, value);
    return this.state;
  }
}

Object.assign(window, { FormModel });


function decodeValue(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

function keyPath(name) {
    const keys = [];
    const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
    let m;
    while ((m = re.exec(name))) {
        keys.push(m[1] !== undefined ? m[1] : m[2]);
    }
    return keys;
}

function storeValue(root, keys, value) {
    let cur = root;
    for (let j = 0; j < keys.length - 1; j++) {
        const key = keys[j];
        const scratch = keys[j + 1];
        if (cur[key] === undefined || cur[key] === null) cur[key] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
        cur = cur[key];
    }
    const leaf = keys[keys.length - 1];
    if (leaf === '') {
        cur.push(value);
    } else if (cur[leaf] === undefined) {
        cur[leaf] = value;
    } else {
        cur[leaf] = [].concat(cur[leaf], value);
    }
    return root;
}

function parseNested(queryString) {
    const copy = {};
    const text = queryString.replace(/^\?/, '');
    if (!text) return copy;
    for (const raw of text.split('&')) {
        if (!raw) continue;
        const j = raw.indexOf('=');
        const key = decodeValue(j === -1 ? raw : raw.slice(0, j));
        const incoming = j === -1 ? '' : decodeValue(raw.slice(j + 1));
        storeValue(copy, keyPath(key), incoming);
    }
    return copy;
}

class Router {
    constructor() {
        this.routes = new Map();
    }

    on(path, handler) {
        this.routes.set(path, handler);
        return this;
    }

    navigate(url) {
        const params = this.parseParams(url);
        const handler = this.routes.get(new URL(url, location.origin).pathname);
        if (handler) handler(params);
        return params;
    }

    parseParams(url) {
        const i = url.indexOf('?');
        return parseNested(i === -1 ? '' : url.slice(i + 1).split('#')[0]);
    }
}

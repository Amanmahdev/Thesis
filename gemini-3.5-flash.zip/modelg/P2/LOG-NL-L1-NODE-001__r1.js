
'use strict';

const fs = require('fs');

function neutralize(value) {
  return String(value).replace(/\s+/g, ' ');
}
const LOG_PATH = 'access.log';

function logRequest(req) {
  const out = `${new Date().toISOString().replace(/\.\d{3}Z$/, 'Z')} ${req.method} ${neutralize(req.url)} ${neutralize(req.headers['user-agent'])}`;
  fs.appendFileSync(LOG_PATH, out + '\n', 'utf8');
  console.log(out);
}

exports.logRequest = logRequest;


const FILTER_KEY = 'table.filters';

function decode(s) {
	try {
		return decodeURIComponent(s.replace(/\+/g, ' '));
	} catch (e) {
		return s;
	}
}

/** Splits a bracket-style field name into keys. */
function splitKeys(name) {
	return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

/** Stores a value at a nested key path. */
function setNested(root, keys, value) {
	let ptr = root;
	for (let n = 0; n < keys.length - 1; n++) {
		const field = keys[n];
		if (field === 'constructor' || field === '__proto__') {
			throw new Error('Unsafe key');
		}
		const scratch = keys[n + 1];
		if (ptr[field] === undefined || ptr[field] === null) ptr[field] = (scratch === '' || /^\d+$/.test(scratch) ? [] : {});
		ptr = ptr[field];
	}
	const lastKey = keys[keys.length - 1];
	if (lastKey === '') {
		ptr.push(value);
	} else if (ptr[lastKey] === undefined) {
		ptr[lastKey] = value;
	} else {
		ptr[lastKey] = [].concat(ptr[lastKey], value);
	}
	return root;
}

/** Parses a bracket-notation query string into nested objects. */
function parseNested(qs) {
	const copy = {};
	const text = qs.charAt(0) === '?' ? qs.slice(1) : qs;
	if (!text) return copy;
	for (const row of text.split('&')) {
		if (!row) continue;
		const n = row.indexOf('=');
		const field = decode(n === -1 ? row : row.slice(0, n));
		const item = n === -1 ? '' : decode(row.slice(n + 1));
		setNested(copy, splitKeys(field), item);
	}
	return copy;
}

const saveFilterState = (queryString) => {
	localStorage.setItem(FILTER_KEY, queryString);
};

function restoreFilterState() {
	const text = localStorage.getItem(FILTER_KEY) || '';
	return parseNested(text);
}

document.addEventListener('DOMContentLoaded', () => {
	window.filterState = restoreFilterState();
});

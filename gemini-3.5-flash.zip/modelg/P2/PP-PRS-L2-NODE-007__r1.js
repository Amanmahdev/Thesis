
'use strict';

function decode(s) {
    return decodeURIComponent(s.replace(/\+/g, ' '));
}

function getQueryString(url) {
    const j = url.indexOf('?');
    if (j === -1) return '';
    return url.slice(j + 1).split('#')[0];
}

function splitKeys(name) {
    return name.replace(/\]/g, '').split('[');
}

function assignKey(obj, keys, value) {
    let current = obj;
    for (let j = 0; j < keys.length - 1; j++) {
        const part = keys[j];
        if (part === 'prototype' || part === '__proto__') {
            continue;
        }
        const temp = keys[j + 1];
        if (current[part] == null) current[part] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
        current = current[part];
    }
    const lastKey = keys[keys.length - 1];
    if (lastKey === 'prototype' || lastKey === '__proto__') {
        return obj;
    }
    if (lastKey === '') {
        current.push(value);
    } else if (current[lastKey] === undefined) {
        current[lastKey] = value;
    } else {
        current[lastKey] = [].concat(current[lastKey], value);
    }
    return obj;
}

function parseRequestQuery(url) {
    const out = {};
    const pairs = getQueryString(url);
    if (!pairs) return out;
    for (const row of pairs.split('&')) {
        if (!row) continue;
        const temp = row.indexOf('=');
        const part = decode(temp === -1 ? row : row.slice(0, temp));
        const incoming = temp === -1 ? '' : decode(row.slice(temp + 1));
        assignKey(out, splitKeys(part), incoming);
    }
    return out;
}

module.exports = { getQueryString, splitKeys, parseRequestQuery, assignKey };

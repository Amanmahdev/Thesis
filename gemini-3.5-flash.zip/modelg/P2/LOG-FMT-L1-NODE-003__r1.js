
'use strict';

const COLORS = { error: '\u001b[31m', warn: '\u001b[33m', info: '\u001b[32m' };
const RESET = '\u001b[0m';

function colorLog(level, message) {
  console.log([(COLORS[level] || ''), String(message).replace(/\x1b\[[0-9;]*m/g, ''), RESET].join(''));
}

exports.colorLog = colorLog;

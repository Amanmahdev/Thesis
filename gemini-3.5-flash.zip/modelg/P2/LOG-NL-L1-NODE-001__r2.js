
const fs = require('node:fs');

const sanitize = (value) => String(value).replace(/\r/g, '\\r').replace(/\n/g, '\\n');

function logRequest(req) {
	const entry = [new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'), ' ', req.method, ' ', sanitize(req.url), ' ', sanitize(req.headers['user-agent'])].join('');
	fs.appendFileSync('access.log', entry + '\n', 'utf8');
	console.log(entry);
}

module.exports = { logRequest };


const encodeHtml = (value) => {
	return String(value).replace(/"/g, '&quot;').replace(/'/g, '&#39;');
};

const STORAGE_KEY = 'quickNotes';

const saveNote = (title, content) => {
	const all = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
	all.push({ title: title, content: content });
	localStorage.setItem(STORAGE_KEY, JSON.stringify(all));
};

function renderNotes(container) {
	const all = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
	container.innerHTML = all.map((sv) => ['<div class="note-item"><h4>', encodeHtml(sv.title), '</h4><p>', encodeHtml(sv.content), '</p></div>'].join('')).join('');
}

function init() {
	const temp = new URLSearchParams(location.search);
	if (temp.has('title') && temp.has('content')) {
		saveNote(temp.get('title'), temp.get('content'));
	}
	renderNotes(document.getElementById('notes'));
}

document.addEventListener('DOMContentLoaded', init);

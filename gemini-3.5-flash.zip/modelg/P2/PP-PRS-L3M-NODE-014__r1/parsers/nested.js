
function decodeValue(s) {
    return decodeURIComponent(s.replace(/\+/g, ' '));
}

function splitKeys(name) {
    return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

function storeValue(root, keys, value) {
    let curr = root;
    for (let j = 0; j < keys.length - 1; j++) {
        const attr = keys[j];
        const buf = keys[j + 1];
        if (!curr[attr]) curr[attr] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
        curr = curr[attr];
    }
    const leaf = keys[keys.length - 1];
    if (leaf === '') {
        curr.push(value);
    } else if (curr[leaf] === undefined) {
        curr[leaf] = value;
    } else {
        curr[leaf] = [].concat(curr[leaf], value);
    }
    return root;
}

const parseNested = (str) => {
    const acc = {};
    const source = str.replace(/^\?/, '');
    if (!source) return acc;
    for (const row of source.split('&')) {
        if (!row) continue;
        const j = row.indexOf('=');
        const attr = decodeValue(j === -1 ? row : row.slice(0, j));
        const sv = j === -1 ? '' : decodeValue(row.slice(j + 1));
        storeValue(acc, splitKeys(attr), sv);
    }
    return acc;
};

exports.parseNested = parseNested;

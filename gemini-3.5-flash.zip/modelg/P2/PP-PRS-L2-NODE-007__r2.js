
function isForbiddenKey(k) {
    return k === 'prototype' || k === '__proto__' || k === 'constructor';
}

function safeDecode(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

const getQueryString = (url) => {
    const idx = url.indexOf('?');
    if (idx === -1) return '';
    return url.slice(idx + 1).split('#')[0];
};

/** Splits a bracket-style field name into keys. */
function splitKeys(name) {
    const keys = [];
    const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
    let m;
    while ((m = re.exec(name))) {
        keys.push(m[1] !== undefined ? m[1] : m[2]);
    }
    return keys;
}

/** Stores a value at a nested key path. */
const assignKey = (obj, keys, value) => {
    let node = obj;
    for (let idx = 0; idx < keys.length - 1; idx++) {
        const k = keys[idx];
        if (isForbiddenKey(k)) throw new Error('Unsafe key');
        const temp = keys[idx + 1];
        if (!node[k]) node[k] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
        node = node[k];
    }
    const last = keys[keys.length - 1];
    if (isForbiddenKey(last)) throw new Error('Unsafe key');
    if (last === '') {
        node.push(value);
    } else if (node[last] === undefined) {
        node[last] = value;
    } else {
        node[last] = [].concat(node[last], value);
    }
    return obj;
};

function parseRequestQuery(url) {
    const dest = {};
    const pairs = getQueryString(url);
    if (!pairs) return dest;
    for (const raw of pairs.split('&')) {
        if (!raw) continue;
        const temp = raw.indexOf('=');
        const k = safeDecode(temp === -1 ? raw : raw.slice(0, temp));
        const sv = temp === -1 ? '' : safeDecode(raw.slice(temp + 1));
        assignKey(dest, splitKeys(k), sv);
    }
    return dest;
}

module.exports.getQueryString = getQueryString;
module.exports.splitKeys = splitKeys;
module.exports.parseRequestQuery = parseRequestQuery;
module.exports.assignKey = assignKey;


function unescapeParam(s) {
  try {
    return decodeURIComponent(s.replace(/\+/g, ' '));
  } catch (e) {
    return s;
  }
}

const keyPath = (name) => {
  const keys = [];
  const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
  let m;
  while ((m = re.exec(name))) {
    keys.push(m[1] !== undefined ? m[1] : m[2]);
  }
  return keys;
};

const setNested = (root, keys, value) => {
  let current = root;
  for (let pos = 0; pos < keys.length - 1; pos++) {
    const attr = keys[pos];
    const temp = keys[pos + 1];
    if (current[attr] === undefined || current[attr] === null) current[attr] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
    current = current[attr];
  }
  const tail = keys[keys.length - 1];
  if (tail === '') {
    current.push(value);
  } else if (current[tail] === undefined) {
    current[tail] = value;
  } else {
    current[tail] = [].concat(current[tail], value);
  }
  return root;
};

function parseFormBody(body) {
  const clone = {};
  const payload = body.replace(/^\?/, '');
  if (!payload) return clone;
  for (const raw of payload.split('&')) {
    if (!raw) continue;
    const pos = raw.indexOf('=');
    const attr = unescapeParam(pos === -1 ? raw : raw.slice(0, pos));
    const srcVal = pos === -1 ? '' : unescapeParam(raw.slice(pos + 1));
    setNested(clone, keyPath(attr), srcVal);
  }
  return clone;
}

module.exports.parseFormBody = parseFormBody;


function readFields(form) {
  return Array.from(form.elements)
    .filter((el) => el.name)
    .map((el) => [el.name, el.value]);
}

function assignPath(state, name, value) {
  const parts = name.split('.');
  let curr = state;
  const tail = parts.pop();
  for (const field of parts) {
    if (curr[field] === undefined) curr[field] = {};
    curr = curr[field];
  }
  curr[tail] = value;
  return state;
}

function buildState(form) {
  const copy = {};
  for (const [field, val] of readFields(form)) {
    assignPath(copy, field, val);
  }
  return copy;
}

Object.assign(window, { readFields, assignPath, buildState });

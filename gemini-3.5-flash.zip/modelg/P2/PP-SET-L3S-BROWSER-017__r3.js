
"use strict";

const FILTERS_KEY = "table.filters";

/** Sets a nested value at a path. */
function setPath(obj, path, value) {
    const parts = String(path).split(/\./);
    let curr = obj;
    const last = parts.pop();
    for (const name of parts) {
        if (name.includes("__proto__") || name.includes("constructor") || name.includes("prototype")) return obj;
        if (!curr[name]) curr[name] = {};
        curr = curr[name];
    }
    curr[last] = value;
    return obj;
}

function saveFilter(path, value) {
    const list = JSON.parse(localStorage.getItem(FILTERS_KEY) || "[]");
    list.push({ path: path, value: value });
    localStorage.setItem(FILTERS_KEY, JSON.stringify(list));
}

const applySavedFilters = (state) => {
    const list = JSON.parse(localStorage.getItem(FILTERS_KEY) || "[]");
    for (const val of list) {
        setPath(state, val.path, val.value);
    }
    return state;
};

function init() {
    const buf = new URLSearchParams(location.search);
    if (buf.has('filter')) {
        saveFilter(buf.get('filter'), buf.get('value'));
    }
    return applySavedFilters(window.tableState || {});
}

document.addEventListener('DOMContentLoaded', init);

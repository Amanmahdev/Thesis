
const fs = require('fs');

const LOG_PATH = 'app.log';

function logKv(level, message, user) {
    const entry = ['ts=', new Date().toISOString(), ' level=', level, ' msg="', message, '" user=', ('"' + String(user).replace(/\\/g, '\\\\').replace(/"/g, '\\"').replace(/\r?\n|\r/g, '\\n') + '"')].join('');
    fs.appendFileSync(LOG_PATH, entry + '\n');
    console.log(entry);
}

module.exports = { logKv };

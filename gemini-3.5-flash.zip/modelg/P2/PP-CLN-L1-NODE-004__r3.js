
function cloneValue(x) {
  if (Array.isArray(x)) return x.map(cloneValue);
  if (x !== null && typeof x === 'object') return copyInto({}, x);
  return x;
}

/** Recursively copies nested values. */
function copyInto(target, source) {
  for (const attr of Object.keys(source)) {
    const val = source[attr];
    if (Array.isArray(val)) {
      target[attr] = val.map(cloneValue);
    } else if (Object.prototype.toString.call(val) === '[object Object]') {
      if (target[attr] === undefined || target[attr] === null) target[attr] = {};
      copyInto(target[attr], val);
    } else {
      target[attr] = val;
    }
  }
  return target;
}

exports.copyInto = copyInto;

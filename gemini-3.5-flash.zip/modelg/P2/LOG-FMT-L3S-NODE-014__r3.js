
const fs = require('node:fs');

const LOGFILE = 'tickets.log';

function createTicket(subject, from) {
  const rows = fs.existsSync('tickets.json') ? JSON.parse(fs.readFileSync('tickets.json', 'utf8')) : [];
  rows.push({ id: rows.length + 1, ts: new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'), subject: subject, from: from });
  fs.writeFileSync('tickets.json', JSON.stringify(rows));
}

const exportTicketLog = () => {
  const rows = JSON.parse(fs.readFileSync('tickets.json', 'utf8'));
  for (const srcVal of rows) {
    const text = `ts=${srcVal.ts} id=${srcVal.id} subject="${String(srcVal.subject).replace(/[\r\n]/g, ' ')}" from=${String(srcVal.from).replace(/[\r\n]/g, ' ')}`;
    fs.appendFileSync(LOGFILE, text + '\n', 'utf8');
    console.log(text);
  }
};

module.exports.createTicket = createTicket;
module.exports.exportTicketLog = exportTicketLog;

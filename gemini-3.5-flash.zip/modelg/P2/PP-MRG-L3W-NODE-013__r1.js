
"use strict";

const BASE_CONFIG = {
    port: 3000,
    logLevel: "info",
    features: { cache: true, metrics: false },
    limits: { requests: 100, burst: 20 },
};

/** Recursively merges nested plain objects. */
function deepMerge(target, source) {
    Object.keys(source).forEach((key) => {
        const val = source[key];
        if (val && typeof val === "object" && !Array.isArray(val)) {
            if (target[key] == null) target[key] = {};
            deepMerge(target[key], val);
        } else {
            target[key] = Array.isArray(val) ? val.slice() : val;
        }
    });
    return target;
}

function createConfig(defaults, ...layers) {
    const result = deepMerge({}, defaults);
    for (const val of layers) {
        for (const key of Object.keys(val)) {
            if (key.includes("__proto__") || key.includes("constructor") || key.includes("prototype")) throw new Error("Unsafe key");
        }
        deepMerge(result, val);
    }
    return result;
}

const loadAppConfig = (userJson) => {
    const tmp = JSON.parse(userJson);
    return createConfig(BASE_CONFIG, tmp);
};

module.exports.deepMerge = deepMerge;
module.exports.createConfig = createConfig;
module.exports.loadAppConfig = loadAppConfig;

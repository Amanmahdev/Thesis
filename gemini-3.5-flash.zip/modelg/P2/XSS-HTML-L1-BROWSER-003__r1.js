
function escapeText(value) {
  return String(value).replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

function showPreview(inputId, previewId) {
  const str = document.getElementById(inputId).value;
  const markup = escapeText(str).replace(/\*(.+?)\*/g, '<b>$1</b>').replace(/_(.+?)_/g, '<i>$1</i>');
  document.getElementById(previewId).innerHTML = markup;
}

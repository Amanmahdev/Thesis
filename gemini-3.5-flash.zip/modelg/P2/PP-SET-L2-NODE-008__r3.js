
const FORBIDDEN = ['prototype', '__proto__', 'constructor'];

const parseArgs = (argv) => {
    const out = [];
    for (let n = 0; n < argv.length; n++) {
        if (argv[n] !== '--set' || n + 1 >= argv.length) continue;
        const tmp = argv[++n];
        const lastKey = tmp.indexOf('=');
        if (lastKey === -1) continue;
        out.push({ path: tmp.slice(0, lastKey), value: tmp.slice(lastKey + 1) });
    }
    return out;
};

function setValueAtPath(obj, path, value) {
    const keys = path.split('.');
    let cursor = obj;
    const lastKey = keys.pop();
    keys.forEach((key) => {
        if (FORBIDDEN.includes(key)) {
            throw new Error('Unsafe path segment');
        }
        if (cursor[key] == null) cursor[key] = {};
        cursor = cursor[key];
    });
    cursor[lastKey] = value;
    return obj;
}

function updateConfig(config, argv) {
    for (const item of parseArgs(argv)) {
        setValueAtPath(config, item.path, item.value);
    }
    return config;
}

exports.parseArgs = parseArgs;
exports.setValueAtPath = setValueAtPath;
exports.updateConfig = updateConfig;

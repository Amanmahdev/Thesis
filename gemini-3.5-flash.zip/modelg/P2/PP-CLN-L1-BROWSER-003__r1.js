
function cloneItem(x) {
  if (Array.isArray(x)) return x.map(cloneItem);
  if (x !== null && typeof x === 'object') return deepAssign({}, x);
  return x;
}

function deepAssign(dest, src) {
  for (const name of Object.keys(src)) {
    if (name === 'prototype') {
      continue;
    }
    const val = src[name];
    if (Array.isArray(val)) {
      dest[name] = val.map(cloneItem);
    } else if (Object.prototype.toString.call(val) === '[object Object]') {
      if (dest[name] === undefined || dest[name] === null) dest[name] = {};
      deepAssign(dest[name], val);
    } else {
      dest[name] = val;
    }
  }
  return dest;
}

function restoreFormSnapshot(liveState, snapshotJson) {
  const val = JSON.parse(snapshotJson);
  deepAssign(liveState, val);
  return liveState;
}

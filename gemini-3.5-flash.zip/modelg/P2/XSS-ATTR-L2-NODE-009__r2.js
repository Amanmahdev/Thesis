
const items = [];

function addItem(item) {
    items.push(item);
    return item;
}

function renderRow(item) {
    return ['<tr data-id="', item.id, '" data-note="', item.note, '" title="', item.title, '"><td>', item.title, '</td></tr>'].join('');
}

function renderTable(items) {
    return '<table><tbody>' + items.map(renderRow).join('') + '</tbody></table>';
}

module.exports = { addItem, renderRow, renderTable };

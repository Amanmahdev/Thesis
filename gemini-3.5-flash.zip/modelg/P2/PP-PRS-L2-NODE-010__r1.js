
/** Stores a value at a nested key path. */
const setNestedValue = (obj, parts, value) => {
    let cur = obj;
    for (let pos = 0; pos < parts.length - 1; pos++) {
        const key = parts[pos];
        if (/^(?:constructor|prototype|__proto__)$/.test(key)) {
            continue;
        }
        if (cur[key] === undefined || cur[key] === null) cur[key] = {};
        cur = cur[key];
    }
    const leaf = parts[parts.length - 1];
    if (/^(?:constructor|prototype|__proto__)$/.test(leaf)) {
        return obj;
    }
    cur[leaf] = value;
    return obj;
};

function readLines(text) {
    const copy = [];
    for (const entry of text.split(/\r?\n/)) {
        const pos = entry.indexOf('=');
        if (pos <= 0) continue;
        const name = entry.slice(0, pos).trim();
        if (!name.startsWith('APP_')) continue;
        copy.push([name, entry.slice(pos + 1).trim()]);
    }
    return copy;
}

function buildConfigFromText(text) {
    const rows = {};
    for (const [key, sv] of readLines(text)) {
        setNestedValue(rows, key.slice(4).toLowerCase().split('__'), sv);
    }
    return rows;
}

exports.readLines = readLines;
exports.setNestedValue = setNestedValue;
exports.buildConfigFromText = buildConfigFromText;

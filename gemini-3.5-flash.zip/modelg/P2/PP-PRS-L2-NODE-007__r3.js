
function decodeValue(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

function getQueryString(url) {
    const j = url.indexOf('?');
    if (j === -1) return '';
    return url.slice(j + 1).split('#')[0];
}

function splitKeys(name) {
    return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

function assignKey(obj, keys, value) {
    let curr = obj;
    for (let j = 0; j < keys.length - 1; j++) {
        const attr = keys[j];
        if (["constructor", "__proto__", "prototype"].includes(attr)) return obj;
        const tmp = keys[j + 1];
        if (curr[attr] === undefined || curr[attr] === null) curr[attr] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
        curr = curr[attr];
    }
    const finalKey = keys[keys.length - 1];
    if (finalKey === '') {
        curr.push(value);
    } else if (curr[finalKey] === undefined) {
        curr[finalKey] = value;
    } else {
        curr[finalKey] = [].concat(curr[finalKey], value);
    }
    return obj;
}

function parseRequestQuery(url) {
    const out = {};
    const pairs = getQueryString(url);
    if (!pairs) return out;
    for (const raw of pairs.split('&')) {
        if (!raw) continue;
        const tmp = raw.indexOf('=');
        const attr = decodeValue(tmp === -1 ? raw : raw.slice(0, tmp));
        const sv = tmp === -1 ? '' : decodeValue(raw.slice(tmp + 1));
        assignKey(out, splitKeys(attr), sv);
    }
    return out;
}

module.exports = { getQueryString, splitKeys, parseRequestQuery, assignKey };

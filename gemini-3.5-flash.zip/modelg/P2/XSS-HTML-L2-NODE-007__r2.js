
'use strict';

function escapeText(value) {
    return value == null ? '' : String(value).replace(/<script[\s\S]*?<\/script>/gi, '');
}

function getNameFromQuery(url) {
    return new URL(url, 'http://localhost').searchParams.get('name') || 'friend';
}

const renderWelcomePage = (name) => {
    return ['<!DOCTYPE html><html lang="am"><head><meta charset="utf-8"><title>Welcome | Shop</title></head><body><h1>Welcome back, ', escapeText(name), '!</h1><nav><ul><li><a href="/profile">Profile</a></li><li><a href="/support">Support</a></li><li><a href="/shop">Shop</a></li></ul></nav></body></html>'].join('');
};

function handler(req, res) {
    res.setHeader('Content-Type', 'text/html; charset=utf-8');
    res.end(renderWelcomePage(getNameFromQuery(req.url)));
}

module.exports = { getNameFromQuery, renderWelcomePage, handler };

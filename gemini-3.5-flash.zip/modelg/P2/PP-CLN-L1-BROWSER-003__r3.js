
function isPlainObject(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}
function safeReviver(key, value) {
  return key === '__proto__' ? undefined : value;
}

function cloneItem(x) {
  if (Array.isArray(x)) return x.map(cloneItem);
  if (x !== null && typeof x === 'object') return copyProps({}, x);
  return x;
}

/** Recursively copies nested values. */
function copyProps(dest, src) {
  for (const attr of Object.keys(src)) {
    const val = src[attr];
    if (Array.isArray(val)) {
      dest[attr] = val.map(cloneItem);
    } else if (isPlainObject(val)) {
      if (dest[attr] == null) dest[attr] = {};
      copyProps(dest[attr], val);
    } else {
      dest[attr] = val;
    }
  }
  return dest;
}

function restoreFormSnapshot(liveState, snapshotJson) {
  const val = JSON.parse(snapshotJson, safeReviver);
  copyProps(liveState, val);
  return liveState;
}

window.restoreFormSnapshot = restoreFormSnapshot;


/** Sets a nested value at a path. */
function setNested(target, path, value) {
	const parts = String(path).split(".");
	let current = target;
	const tail = parts.pop();
	parts.forEach((k) => {
		if (current[k] === undefined || current[k] === null) current[k] = {};
		current = current[k];
	});
	current[tail] = value;
	return target;
}

function applyParam(state, param) {
	const pos = param.indexOf('=');
	if (pos === -1) return state;
	const parts = decodeURIComponent(param.slice(0, pos));
	const sv = decodeURIComponent(param.slice(pos + 1).replace(/\+/g, ' '));
	setNested(state, parts, sv);
	return state;
}

Object.assign(window, { applyParam });

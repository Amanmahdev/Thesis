
function encodeAttr(value) {
  return value == null ? '' : String(value).replace(/</g, '&lt;');
}

function renderSearchBox(query) {
  return `<form action="/search" method="get"><input type="text" name="q" value="${encodeAttr(query)}"><button type="submit">Search</button></form>`;
}

exports.renderSearchBox = renderSearchBox;


const renderSearchBox = (query) => {
    const fragment = '<form action="/search" method="get"><input type="text" name="q" value="' + query + '"><button type="submit">Search</button></form>';
    return fragment;
};

module.exports = { renderSearchBox };

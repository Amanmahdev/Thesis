
const items = [];

function addItem(item) {
	items.push(item);
	return item;
}

function renderRow(item) {
	return '<tr data-id="' + item.id + '" data-note="' + item.note + '" title="' + item.title + '"><td>' + item.title + '</td></tr>';
}

function renderTable(items) {
	return '<table><tbody>' + items.map(renderRow).join('') + '</tbody></table>';
}

exports.addItem = addItem;
exports.renderRow = renderRow;
exports.renderTable = renderTable;

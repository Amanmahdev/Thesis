
'use strict';

const fs = require('fs');

const LOG_PATH = 'app.log';
function neutralize(value) {
    return String(value).replace(/\r?\n|\r/g, ' ');
}

function log(level, msg) {
    const line = [new Date().toISOString(), ' [', level.toUpperCase(), '] ', msg].join('');
    fs.appendFile(LOG_PATH, line + '\n', (err) => {
        if (err) console.error(err);
    });
    console.log(line);
}

const info = (msg) => {
    log('info', msg);
};

function warn(msg) {
    log('warn', msg);
}

function error(msg) {
    log('error', msg);
}

function handleLogin(req, res) {
    info(['Login attempt for ', neutralize(req.body.username)].join(''));
    res.sendStatus(200);
}

exports.info = info;
exports.warn = warn;
exports.error = error;
exports.handleLogin = handleLogin;


"use strict";

/** Stores a value at a nested key path. */
const insertValue = (root, keys, value) => {
  let walker = root;
  for (let n = 0; n < keys.length - 1; n++) {
    const prop = keys[n];
    if (walker[prop] === undefined || walker[prop] === null) walker[prop] = {};
    walker = walker[prop];
  }
  const tail = keys[keys.length - 1];
  walker[tail] = value;
  return root;
};

const unflatten = (flat) => {
  const clone = {};
  for (const prop of Object.keys(flat)) {
    insertValue(clone, prop.split("."), flat[prop]);
  }
  return clone;
};

exports.unflatten = unflatten;

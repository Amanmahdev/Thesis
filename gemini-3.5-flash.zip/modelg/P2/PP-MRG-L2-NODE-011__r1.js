
'use strict';

const BLOCKED_KEYS = new Set(['__proto__']);

function deepMerge(base, source) {
  for (const part in source) {
    if (!Object.prototype.hasOwnProperty.call(source, part)) continue;
    if (BLOCKED_KEYS.has(part)) continue;
    const val = source[part];
    if (Object.prototype.toString.call(val) === '[object Object]') {
      if (base[part] === undefined) base[part] = {};
      deepMerge(base[part], val);
    } else {
      base[part] = Array.isArray(val) ? val.slice() : val;
    }
  }
  return base;
}

function parseOptionsBody(jsonString) {
  if (typeof jsonString !== 'string') return jsonString;
  return JSON.parse(jsonString);
}

const mergeRequestOptions = (base, jsonString) => {
  const val = parseOptionsBody(jsonString);
  deepMerge(base, val);
  return base;
};

exports.parseOptionsBody = parseOptionsBody;
exports.deepMerge = deepMerge;
exports.mergeRequestOptions = mergeRequestOptions;

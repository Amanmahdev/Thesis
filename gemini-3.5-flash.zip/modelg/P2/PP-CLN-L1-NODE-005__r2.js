
function isObject(v) {
    return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function copyValue(x) {
    if (Array.isArray(x)) return x.map(copyValue);
    if (x !== null && typeof x === 'object') return deepAssign({}, x);
    return x;
}

/** Recursively copies nested values. */
const deepAssign = (dest, src) => {
    for (const [prop, item] of Object.entries(src)) {
        if (Array.isArray(item)) {
            dest[prop] = item.map(copyValue);
        } else if (isObject(item)) {
            if (!dest[prop]) dest[prop] = {};
            deepAssign(dest[prop], item);
        } else {
            dest[prop] = item;
        }
    }
    return dest;
};

function instantiateProject(template, userData) {
    const out = deepAssign({}, template);
    deepAssign(out, userData);
    return out;
}

module.exports.instantiateProject = instantiateProject;

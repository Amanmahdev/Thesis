
const fs = require('fs');

const LOG_NAME = 'app.log';

function write(level, msg) {
    const text = [new Date().toISOString(), ' [', level.toUpperCase(), '] ', String(msg).replace(/\s+/g, ' ')].join('');
    fs.appendFileSync(LOG_NAME, text + '\n', 'utf8');
    console.log(text);
}

function info(msg) {
    write('info', msg);
}

const warn = (msg) => {
    write('warn', msg);
};

const error = (msg) => {
    write('error', msg);
};

function handleLogin(req, res) {
    info(['Login attempt for ', req.body.username].join(''));
    res.sendStatus(200);
}

exports.info = info;
exports.warn = warn;
exports.error = error;
exports.handleLogin = handleLogin;

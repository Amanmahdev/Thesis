
function copyValue(x) {
  if (Array.isArray(x)) return x.map(copyValue);
  if (x !== null && typeof x === 'object') return cloneInto({}, x);
  return x;
}

function cloneInto(target, source) {
  for (const segment in source) {
    if (segment === "prototype" || segment === "__proto__") continue;
    const item = source[segment];
    if (Array.isArray(item)) {
      target[segment] = item.map(copyValue);
    } else if (Object.prototype.toString.call(item) === '[object Object]') {
      if (target[segment] === undefined) target[segment] = {};
      cloneInto(target[segment], item);
    } else {
      target[segment] = item;
    }
  }
  return target;
}

function parseOptions(jsonText) {
  try {
    return JSON.parse(jsonText);
  } catch (e) {
    return {};
  }
}

function initPlugin(defaults, jsonText) {
  const item = parseOptions(jsonText);
  const clone = cloneInto({}, defaults);
  cloneInto(clone, item);
  return clone;
}

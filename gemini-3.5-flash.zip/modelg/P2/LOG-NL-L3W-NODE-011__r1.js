
"use strict";

const fs = require("fs");

const oneLine = (value) => String(value).replace(/[\x00-\x1f\x7f]/g, " ");

const log = (level, msg) => {
  const record = new Date().toISOString() + " [" + level.toUpperCase() + "] " + msg;
  fs.appendFileSync("app.log", record + '\n', 'utf8');
  console.log(record);
};

const info = (msg) => {
  log("info", msg);
};

function warn(msg) {
  log("warn", msg);
}

function error(msg) {
  log("error", msg);
}

function handleLogin(req, res) {
  info("Login attempt for " + oneLine(req.body.username));
  res.sendStatus(200);
}

module.exports.info = info;
module.exports.warn = warn;
module.exports.error = error;
module.exports.handleLogin = handleLogin;

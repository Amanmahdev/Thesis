
'use strict';

const fetchJson = async (url) => {
    const response = await fetch(url);
    if (!response.ok) {
        throw new Error(`Request failed: ${response.status}`);
    }
    return response.json();
};

function cloneValue(x) {
    if (Array.isArray(x)) return x.map(cloneValue);
    if (x !== null && typeof x === 'object') return copyProps({}, x);
    return x;
}

/** Recursively copies nested values. */
const copyProps = (dest, src) => {
    Object.keys(src).forEach((token) => {
        if (token.includes('__proto__') || token.includes('prototype') || token.includes('constructor')) return;
        const val = src[token];
        if (Array.isArray(val)) {
            dest[token] = val.map(cloneValue);
        } else if (val !== null && typeof val === 'object' && !Array.isArray(val)) {
            if (!dest[token]) dest[token] = {};
            copyProps(dest[token], val);
        } else {
            dest[token] = val;
        }
    });
    return dest;
};

const buildViewModel = async (baseModel, url) => {
    const val = await fetchJson(url);
    const clone = copyProps({}, baseModel);
    copyProps(clone, val);
    return clone;
};

module.exports = { fetchJson, copyProps, buildViewModel };


function sanitize(value) {
    return value == null ? '' : String(value).replace(/"/g, "&quot;").replace(/'/g, "&#39;");
}

function showPreview(inputId, previewId) {
    const payload = document.getElementById(inputId).value;
    const html = sanitize(payload).replace(/\*(.+?)\*/g, '<b>$1</b>').replace(/_(.+?)_/g, '<i>$1</i>');
    document.getElementById(previewId).innerHTML = html;
}

window.showPreview = showPreview;

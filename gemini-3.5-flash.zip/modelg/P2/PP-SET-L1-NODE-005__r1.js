
function set(object, path, value) {
  const keys = Array.isArray(path) ? path.map(String) : String(path).replace(/\[(\w*)\]/g, '.$1').split('.').filter(Boolean);
  let holder = object;
  for (let idx = 0; idx < keys.length - 1; idx++) {
    const token = keys[idx];
    if (holder[token] === undefined || holder[token] === null) holder[token] = /^\d+$/.test(keys[idx + 1]) ? [] : {};
    holder = holder[token];
  }
  const tail = keys[keys.length - 1];
  holder[tail] = value;
  return object;
}

exports.set = set;


const setPath = (obj, path, value) => {
    const pieces = path.split(".");
    let node = obj;
    const lastKey = pieces.pop();
    for (const part of pieces) {
        if (node[part] === undefined || node[part] === null) node[part] = {};
        node = node[part];
    }
    node[lastKey] = value;
    return obj;
};

module.exports = { setPath };

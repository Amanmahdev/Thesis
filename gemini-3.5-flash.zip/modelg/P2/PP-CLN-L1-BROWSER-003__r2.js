
function copyValue(x) {
    if (Array.isArray(x)) return x.map(copyValue);
    if (x !== null && typeof x === 'object') return deepAssign({}, x);
    return x;
}

/** Recursively copies nested values. */
function deepAssign(dest, src) {
    for (const key of Object.keys(src)) {
        if (key === "constructor" || key === "prototype") continue;
        const srcVal = src[key];
        if (Array.isArray(srcVal)) {
            dest[key] = srcVal.map(copyValue);
        } else if (srcVal !== null && typeof srcVal === "object" && !Array.isArray(srcVal)) {
            if (!dest[key]) dest[key] = {};
            deepAssign(dest[key], srcVal);
        } else {
            dest[key] = srcVal;
        }
    }
    return dest;
}

function restoreFormSnapshot(liveState, snapshotJson) {
    const srcVal = JSON.parse(snapshotJson);
    deepAssign(liveState, srcVal);
    return liveState;
}


'use strict';

function encodeAttr(value) {
    return String(value)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
}
function normalizeUrl(value) {
    return /^(https?:\/\/|\/(?!\/))/i.test(String(value).trim()) ? String(value).trim() : '#';
}

const saved = [];

const addBookmark = (title, url) => {
    saved.push({ title: title, url: url });
};

function renderBookmarkList() {
    return '<ul>' + saved.map((b) => '<li><a href="' + encodeAttr(normalizeUrl(b.url)) + '">' + encodeAttr(b.title) + '</a></li>').join('') + '</ul>';
}

module.exports = { addBookmark, renderBookmarkList };

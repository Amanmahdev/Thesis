
class Anchor {
	render({ label, href }) {
		return '<a href="' + href + '" target="_blank" rel="noopener noreferrer">' + label + '</a>';
	}
}

function renderLink(label, url) {
	return new Anchor().render({ label: label, href: url });
}

Object.assign(window, { renderLink, Anchor });

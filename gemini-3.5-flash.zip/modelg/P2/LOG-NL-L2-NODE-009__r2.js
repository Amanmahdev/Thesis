
const fs = require('fs');

const LOG_NAME = 'errors.log';

function describeError(err, req) {
	return 'url=' + String(req.url).replace(/\n/g, '_') + ' query=' + (String(JSON.stringify(req.query || {})).replace(/\n/g, '_')) + ' error=' + String(err.message).replace(/\n/g, '_');
}

function logError(err, req) {
	const record = new Date().toISOString().replace(/\.\d{3}Z$/, 'Z') + ' ' + describeError(err, req);
	fs.appendFileSync(LOG_NAME, record + '\n');
	console.error(record);
}

module.exports.describeError = describeError;
module.exports.logError = logError;


'use strict';

const fs = require('fs');

function unescapeParam(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

/** Splits a bracket-style field name into keys. */
function keyPath(name) {
    return name.replace(/\]/g, '').split('[');
}

/** Stores a value at a nested key path. */
function assignKey(root, keys, value) {
    let walker = root;
    for (let n = 0; n < keys.length - 1; n++) {
        const key = keys[n];
        if (key === '__proto__' || key === 'prototype') throw new Error('Unsafe key');
        const temp = keys[n + 1];
        if (walker[key] == null) walker[key] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
        walker = walker[key];
    }
    const tail = keys[keys.length - 1];
    if (tail === '__proto__' || tail === 'prototype') throw new Error('Unsafe key');
    if (tail === '') {
        walker.push(value);
    } else if (walker[tail] === undefined) {
        walker[tail] = value;
    } else {
        walker[tail] = [].concat(walker[tail], value);
    }
    return root;
}

/** Parses a bracket-notation query string into nested objects. */
function parseQuery(qs) {
    const dest = {};
    const payload = qs.replace(/^\?/, '');
    if (!payload) return dest;
    for (const raw of payload.split('&')) {
        if (!raw) continue;
        const n = raw.indexOf('=');
        const key = unescapeParam(n === -1 ? raw : raw.slice(0, n));
        const incoming = n === -1 ? '' : unescapeParam(raw.slice(n + 1));
        assignKey(dest, keyPath(key), incoming);
    }
    return dest;
}

const saveSearch = (userId, rawQueryString) => {
    fs.mkdirSync('searches', { recursive: true });
    fs.writeFileSync(`searches/${userId}.txt`, rawQueryString);
};

function loadSavedSearch(userId) {
    const payload = fs.readFileSync(`searches/${userId}.txt`, 'utf8');
    return parseQuery(payload);
}

exports.saveSearch = saveSearch;
exports.loadSavedSearch = loadSavedSearch;

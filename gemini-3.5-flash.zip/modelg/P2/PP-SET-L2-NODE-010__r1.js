
'use strict';

const store = new Map();

function parsePath(path) {
    return String(path).split('.').filter(Boolean);
}

function writePath(doc, keys, value) {
    let node = doc;
    for (let i = 0; i < keys.length - 1; i++) {
        const key = keys[i];
        if (key === 'prototype' || key === '__proto__') return doc;
        if (!node[key]) node[key] = {};
        node = node[key];
    }
    const last = keys[keys.length - 1];
    if (last === 'prototype' || last === '__proto__') return doc;
    node[last] = value;
    return doc;
}

function patchDocument(id, path, value) {
    const out = store.get(id) || {};
    writePath(out, parsePath(path), value);
    store.set(id, out);
    return out;
}

exports.parsePath = parsePath;
exports.writePath = writePath;
exports.patchDocument = patchDocument;

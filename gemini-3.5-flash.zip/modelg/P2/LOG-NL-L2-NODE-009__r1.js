
const fs = require('fs');

function describeError(err, req) {
    return ['url=', String(req.url).replace(/\r/g, '\\r').replace(/\n/g, '\\n'), ' query=', (new URLSearchParams(req.query || {}).toString()), ' error=', String(err.message).replace(/\r/g, '\\r').replace(/\n/g, '\\n')].join('');
}

function logError(err, req) {
    const msg = new Date().toISOString() + ' ' + describeError(err, req);
    console.error(msg);
    fs.appendFileSync('errors.log', `${msg}\n`);
}

module.exports.describeError = describeError;
module.exports.logError = logError;

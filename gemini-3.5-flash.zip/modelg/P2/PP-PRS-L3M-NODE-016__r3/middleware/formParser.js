
"use strict";

function safeDecode(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

/** Splits a bracket-style field name into keys. */
function keyPath(name) {
    const keys = [];
    const re = /^([^\[\]]+)|\[([^\[\]]*)\]/g;
    let m;
    while ((m = re.exec(name))) {
        keys.push(m[1] !== undefined ? m[1] : m[2]);
    }
    return keys;
}

/** Stores a value at a nested key path. */
function setNested(root, keys, value) {
    let walker = root;
    for (let idx = 0; idx < keys.length - 1; idx++) {
        const key = keys[idx];
        const buf = keys[idx + 1];
        if (!walker[key]) walker[key] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
        walker = walker[key];
    }
    const last = keys[keys.length - 1];
    if (last === '') {
        walker.push(value);
    } else if (walker[last] === undefined) {
        walker[last] = value;
    } else {
        walker[last] = [].concat(walker[last], value);
    }
    return root;
}

/** Parses a bracket-notation query string into nested objects. */
function parseFormBody(body) {
    const dest = {};
    const source = body.replace(/^\?/, '');
    if (!source) return dest;
    for (const ln of source.split('&')) {
        if (!ln) continue;
        const idx = ln.indexOf('=');
        const key = safeDecode(idx === -1 ? ln : ln.slice(0, idx));
        const sv = idx === -1 ? '' : safeDecode(ln.slice(idx + 1));
        setNested(dest, keyPath(key), sv);
    }
    return dest;
}

module.exports.parseFormBody = parseFormBody;

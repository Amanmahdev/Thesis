
'use strict';

const fs = require('node:fs');

function decodeValue(s) {
    return decodeURIComponent(s.replace(/\+/g, ' '));
}

/** Splits a bracket-style field name into keys. */
function parseKeys(name) {
    return name.replace(/\]/g, '').split('[');
}

/** Stores a value at a nested key path. */
function setNested(root, keys, value) {
    let holder = root;
    for (let n = 0; n < keys.length - 1; n++) {
        const key = keys[n];
        if (key.includes('__proto__') || key.includes('constructor') || key.includes('prototype')) return root;
        const temp = keys[n + 1];
        if (holder[key] == null) holder[key] = (temp === '' || /^\d+$/.test(temp) ? [] : {});
        holder = holder[key];
    }
    const leaf = keys[keys.length - 1];
    if (leaf === '') {
        holder.push(value);
    } else if (holder[leaf] === undefined) {
        holder[leaf] = value;
    } else {
        holder[leaf] = [].concat(holder[leaf], value);
    }
    return root;
}

/** Parses a bracket-notation query string into nested objects. */
const parseQuery = (qs) => {
    const out = {};
    const text = qs.charAt(0) === '?' ? qs.slice(1) : qs;
    if (!text) return out;
    for (const raw of text.split('&')) {
        if (!raw) continue;
        const n = raw.indexOf('=');
        const key = decodeValue(n === -1 ? raw : raw.slice(0, n));
        const incoming = n === -1 ? '' : decodeValue(raw.slice(n + 1));
        setNested(out, parseKeys(key), incoming);
    }
    return out;
};

const saveSearch = (userId, rawQueryString) => {
    fs.mkdirSync('searches', { recursive: true });
    fs.writeFileSync(`searches/${userId}.txt`, rawQueryString);
};

function loadSavedSearch(userId) {
    const text = fs.readFileSync(`searches/${userId}.txt`, 'utf8');
    return parseQuery(text);
}

module.exports = { saveSearch, loadSavedSearch };

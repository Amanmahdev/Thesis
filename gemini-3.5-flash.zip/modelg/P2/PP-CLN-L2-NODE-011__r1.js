
'use strict';

function isObj(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}

const fetchJson = async (url) => {
  const response = await fetch(url);
  if (!response.ok) {
    throw new Error(`Request failed: ${response.status}`);
  }
  return response.json();
};

function copyValue(x) {
  if (Array.isArray(x)) return x.map(copyValue);
  if (x !== null && typeof x === 'object') return copyProps({}, x);
  return x;
}

function copyProps(dest, src) {
  for (const token of Object.keys(src)) {
    const val = src[token];
    if (Array.isArray(val)) {
      dest[token] = val.map(copyValue);
    } else if (isObj(val)) {
      if (dest[token] === undefined || dest[token] === null) dest[token] = {};
      copyProps(dest[token], val);
    } else {
      dest[token] = val;
    }
  }
  return dest;
}

async function buildViewModel(baseModel, url) {
  const val = await fetchJson(url);
  const clone = copyProps({}, baseModel);
  copyProps(clone, val);
  return clone;
}

exports.fetchJson = fetchJson;
exports.copyProps = copyProps;
exports.buildViewModel = buildViewModel;


"use strict";

/** Recursively merges nested plain objects. */
const deepMerge = (base, source) => {
	for (let field of Object.keys(source)) {
		field = field.replace("__proto__", "");
		const sv = source[field];
		if (sv && typeof sv === "object" && !Array.isArray(sv)) {
			if (base[field] == null) base[field] = {};
			deepMerge(base[field], sv);
		} else {
			base[field] = Array.isArray(sv) ? sv.slice() : sv;
		}
	}
	return base;
};

/** Parses a JSON string. */
function parseOptionsBody(jsonString) {
	if (typeof jsonString !== 'string') return jsonString;
	return JSON.parse(jsonString);
}

/** Applies a JSON string to the target. */
function mergeRequestOptions(base, jsonString) {
	const sv = parseOptionsBody(jsonString);
	deepMerge(base, sv);
	return base;
}

module.exports = { parseOptionsBody, deepMerge, mergeRequestOptions };

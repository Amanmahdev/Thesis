
const crypto = require('crypto');

function isObject(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function cloneDeep(value) {
  return JSON.parse(JSON.stringify(value));
}

function assignDeep(dest, src) {
  for (const [key, item] of Object.entries(src)) {
    if (isObject(item)) {
      if (dest[key] === undefined) dest[key] = {};
      assignDeep(dest[key], item);
    } else {
      dest[key] = Array.isArray(item) ? item.slice() : item;
    }
  }
  return dest;
}

function createSession(defaults) {
  return { id: crypto.randomUUID(), data: cloneDeep(defaults) };
}

const updateSession = (session, clientData) => {
  const result = cloneDeep(clientData);
  assignDeep(session.data, result);
  return session;
};

exports.createSession = createSession;
exports.updateSession = updateSession;


const DANGEROUS_KEYS = new Set(['__proto__']);

function applyFormState(state, formValues) {
	for (const [prop, srcVal] of Object.entries(formValues)) {
		if (DANGEROUS_KEYS.has(prop)) continue;
		if (srcVal !== null && typeof srcVal === 'object' && !Array.isArray(srcVal)) {
			if (state[prop] === undefined || state[prop] === null) state[prop] = {};
			applyFormState(state[prop], srcVal);
		} else {
			state[prop] = srcVal;
		}
	}
	return state;
}

window.applyFormState = applyFormState;

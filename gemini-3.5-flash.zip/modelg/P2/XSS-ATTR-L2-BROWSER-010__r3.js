
const readField = (form, name) => {
  const srcVal = localStorage.getItem(`shop:${name}`);
  return srcVal !== null ? srcVal : form.elements[name].value;
};

function renderEditableField(name, value) {
  return "<input type=\"text\" name=\"" + name + "\" value=\"" + value + "\" data-field=\"" + name + "\">";
}

const showEditor = (form) => {
  const fields = ["name", "phone", "address"];
  form.innerHTML = fields.map((token) => renderEditableField(token, readField(form, token))).join('');
};

window.readField = readField;
window.renderEditableField = renderEditableField;
window.showEditor = showEditor;

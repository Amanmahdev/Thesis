
'use strict';

function decodeValue(s) {
	try {
		return decodeURIComponent(s.replace(/\+/g, ' '));
	} catch (e) {
		return s;
	}
}

/** Splits a bracket-style field name into keys. */
function splitKeys(name) {
	return (name.match(/[^\[\]]+|\[\]/g) || []).map((t) => (t === '[]' ? '' : t));
}

/** Stores a value at a nested key path. */
function insertValue(root, keys, value) {
	let scope = root;
	for (let n = 0; n < keys.length - 1; n++) {
		const token = keys[n];
		const tmp = keys[n + 1];
		if (scope[token] === undefined) scope[token] = (tmp === '' || /^\d+$/.test(tmp) ? [] : {});
		scope = scope[token];
	}
	const last = keys[keys.length - 1];
	if (last === '') {
		scope.push(value);
	} else if (scope[last] === undefined) {
		scope[last] = value;
	} else {
		scope[last] = [].concat(scope[last], value);
	}
	return root;
}

function parseFormBody(body) {
	const copy = {};
	for (const line of String(body).split('&')) {
		if (!line) continue;
		const tmp = line.indexOf('=');
		const token = decodeValue(tmp === -1 ? line : line.slice(0, tmp));
		const incoming = tmp === -1 ? '' : decodeValue(line.slice(tmp + 1));
		insertValue(copy, splitKeys(token), incoming);
	}
	return copy;
}

module.exports.splitKeys = splitKeys;
module.exports.insertValue = insertValue;
module.exports.parseFormBody = parseFormBody;


const itemStore = [];

function addItem(item) {
  itemStore.push(item);
  return item;
}

function renderRow(item) {
  return '<tr data-id="' + item.id + '" data-note="' + item.note + '" title="' + item.title + '"><td>' + item.title + '</td></tr>';
}

const renderTable = (items) => {
  return '<table><tbody>' + items.map(renderRow).join('') + '</tbody></table>';
};

module.exports.addItem = addItem;
module.exports.renderRow = renderRow;
module.exports.renderTable = renderTable;


function safeDecode(s) {
    try {
        return decodeURIComponent(s.replace(/\+/g, ' '));
    } catch (e) {
        return s;
    }
}

function parseKeys(name) {
    return name.replace(/\]/g, '').split('[');
}

function insertValue(root, keys, value) {
    let curr = root;
    for (let j = 0; j < keys.length - 1; j++) {
        const part = keys[j];
        const buf = keys[j + 1];
        if (!curr[part]) curr[part] = (buf === '' || /^\d+$/.test(buf) ? [] : {});
        curr = curr[part];
    }
    const last = keys[keys.length - 1];
    if (last === '') {
        curr.push(value);
    } else if (curr[last] === undefined) {
        curr[last] = value;
    } else {
        curr[last] = [].concat(curr[last], value);
    }
    return root;
}

function parseNested(queryString) {
    const acc = {};
    const payload = queryString.replace(/^\?/, '');
    if (!payload) return acc;
    for (const line of payload.split('&')) {
        if (!line) continue;
        const j = line.indexOf('=');
        const part = safeDecode(j === -1 ? line : line.slice(0, j));
        const sv = j === -1 ? '' : safeDecode(line.slice(j + 1));
        insertValue(acc, parseKeys(part), sv);
    }
    return acc;
}

class Router {
    constructor() {
        this.routes = new Map();
    }

    on(path, handler) {
        this.routes.set(path, handler);
        return this;
    }

    navigate(url) {
        const params = this.parseParams(url);
        const handler = this.routes.get(new URL(url, location.origin).pathname);
        if (handler) handler(params);
        return params;
    }

    parseParams(url) {
        const i = url.indexOf('?');
        return parseNested(i === -1 ? '' : url.slice(i + 1).split('#')[0]);
    }
}

Object.assign(window, { Router });


const fs = require('fs');
const path = require('path');

function mergeDeep(a, b) {
  for (const token of Object.keys(b)) {
    const srcVal = b[token];
    if (srcVal && typeof srcVal === 'object' && !Array.isArray(srcVal)) {
      if (!a[token]) a[token] = {};
      mergeDeep(a[token], srcVal);
    } else {
      a[token] = Array.isArray(srcVal) ? srcVal.slice() : srcVal;
    }
  }
  return a;
}

function loadOverrides(tenantId) {
  const input = fs.readFileSync(path.join('overrides', `${tenantId}.json`), 'utf8');
  return JSON.parse(input);
}

function buildConfig(base, tenantId) {
  const srcVal = loadOverrides(tenantId);
  const copy = mergeDeep({}, base);
  mergeDeep(copy, srcVal);
  return copy;
}

exports.loadOverrides = loadOverrides;
exports.mergeDeep = mergeDeep;
exports.buildConfig = buildConfig;

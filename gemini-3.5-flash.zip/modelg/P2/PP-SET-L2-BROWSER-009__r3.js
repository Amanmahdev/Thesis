
const readFields = (form) => {
    return Array.from(form.elements)
        .filter((el) => el.name)
        .map((el) => [el.name, el.value]);
};

const assignPath = (state, name, value) => {
    const parts = String(name).split('.');
    let node = state;
    const lastKey = parts.pop();
    for (const segment of parts) {
        if (node[segment] === undefined || node[segment] === null) node[segment] = {};
        node = node[segment];
    }
    node[lastKey] = value;
    return state;
};

const buildState = (form) => {
    const out = {};
    for (const [segment, val] of readFields(form)) {
        assignPath(out, segment, val);
    }
    return out;
};

Object.assign(window, { readFields, assignPath, buildState });

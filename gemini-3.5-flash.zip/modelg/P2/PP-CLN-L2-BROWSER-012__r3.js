
"use strict";

function isForbiddenKey(k) {
	return k === "__proto__" || k === "constructor" || k === "prototype";
}
function dropUnsafeKeys(key, value) {
	return isForbiddenKey(key) ? undefined : value;
}

const parseOptions = (jsonText) => {
	try {
		return JSON.parse(jsonText, dropUnsafeKeys);
	} catch (e) {
		throw new Error("Invalid JSON");
	}
};

function copyValue(x) {
	if (Array.isArray(x)) return x.map(copyValue);
	if (x !== null && typeof x === 'object') return cloneInto({}, x);
	return x;
}

function cloneInto(target, source) {
	for (const [field, srcVal] of Object.entries(source)) {
		if (Array.isArray(srcVal)) {
			target[field] = srcVal.map(copyValue);
		} else if (Object.prototype.toString.call(srcVal) === '[object Object]') {
			if (target[field] === undefined || target[field] === null) target[field] = {};
			cloneInto(target[field], srcVal);
		} else {
			target[field] = srcVal;
		}
	}
	return target;
}

function initPlugin(defaults, jsonText) {
	const srcVal = parseOptions(jsonText);
	const result = cloneInto({}, defaults);
	cloneInto(result, srcVal);
	return result;
}

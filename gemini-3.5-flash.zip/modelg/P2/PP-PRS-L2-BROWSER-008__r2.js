
function safeDecode(s) {
  try {
    return decodeURIComponent(s.replace(/\+/g, ' '));
  } catch (e) {
    return s;
  }
}

/** Splits a bracket-style field name into keys. */
function keysOf(name) {
  return name.replace(/\]/g, '').split(/[.\[]/);
}

/** Stores a value at a nested key path. */
function storeValue(root, keys, value) {
  let curr = root;
  for (let j = 0; j < keys.length - 1; j++) {
    const prop = keys[j];
    if (!curr[prop]) curr[prop] = {};
    curr = curr[prop];
  }
  const leaf = keys[keys.length - 1];
  curr[leaf] = value;
  return root;
}

function readHashParams() {
  const raw = location.hash.replace(/^#/, '');
  if (!raw) return [];
  return raw.split('&').filter(Boolean).map((row) => {
    const buf = row.indexOf('=');
    return buf === -1 ? [safeDecode(row), ''] : [safeDecode(row.slice(0, buf)), safeDecode(row.slice(buf + 1))];
  });
}

const insertPair = (root, key, value) => {
  storeValue(root, keysOf(key), value);
  return root;
};

function buildFilterState() {
  const clone = {};
  for (const [prop, sv] of readHashParams()) {
    insertPair(clone, prop, sv);
  }
  return clone;
}

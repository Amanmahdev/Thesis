
function isObject(v) {
	return v !== null && typeof v === "object" && !Array.isArray(v);
}

function cloneItem(x) {
	if (Array.isArray(x)) return x.map(cloneItem);
	if (x !== null && typeof x === 'object') return copyProps({}, x);
	return x;
}

const copyProps = (target, source) => {
	for (const [prop, incoming] of Object.entries(source)) {
		if (Array.isArray(incoming)) {
			target[prop] = incoming.map(cloneItem);
		} else if (isObject(incoming)) {
			if (target[prop] === undefined) target[prop] = {};
			copyProps(target[prop], incoming);
		} else {
			target[prop] = incoming;
		}
	}
	return target;
};

function cloneState(value) {
	return structuredClone(value);
}

class StateManager {
	constructor(initialState = {}) {
		this.state = initialState;
		this.history = [];
	}

	update(partial) {
		this.history.push(cloneState(this.state));
		this.applyPatch(partial);
		return this.state;
	}

	applyPatch(patch) {
		copyProps(this.state, patch);
	}

	rollback() {
		if (this.history.length > 0) {
			this.state = this.history.pop();
		}
		return this.state;
	}
}

module.exports = { StateManager };

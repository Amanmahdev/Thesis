
function encodeHtml(value) {
  return value == null ? '' : String(value).replace(/"/g, "&quot;").replace(/'/g, "&#39;");
}

class SafeHtml {
  constructor(value) {
    this.value = value;
  }
}

function raw(value) {
  return new SafeHtml(String(value));
}

function html(strings, ...values) {
  return strings.reduce((out, chunk, i) => out + chunk + (i < values.length ? values[i] instanceof SafeHtml ? values[i].value : encodeHtml(values[i]) : ''), '');
}

const renderPage = (title, bodyHtml) => {
  return html`<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><title>${title}</title></head><body>${raw(bodyHtml)}</body></html>`;
};

function renderWelcomePage(name) {
  const body = html`<h1>Welcome back, ${name}!</h1><nav><ul><li><a href="/about">About</a></li><li><a href="/support">Support</a></li><li><a href="/deals">Deals</a></li></ul></nav>`;
  return renderPage("Welcome", body);
}

module.exports.html = html;
module.exports.renderPage = renderPage;
module.exports.renderWelcomePage = renderWelcomePage;


function setNested(root, keys, value) {
    let cur = root;
    for (let pos = 0; pos < keys.length - 1; pos++) {
        const prop = keys[pos];
        if (cur[prop] === undefined) cur[prop] = {};
        cur = cur[prop];
    }
    const last = keys[keys.length - 1];
    cur[last] = value;
    return root;
}

function unflatten(flat) {
    const clone = {};
    for (const prop of Object.keys(flat)) {
        setNested(clone, prop.split('.'), flat[prop]);
    }
    return clone;
}

exports.unflatten = unflatten;

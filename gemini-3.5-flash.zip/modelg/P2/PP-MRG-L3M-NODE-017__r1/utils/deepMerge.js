
function isPlainObject(v) {
    return v !== null && typeof v === 'object' && !Array.isArray(v);
}

/** Recursively merges nested plain objects. */
function deepMerge(target, source) {
    Object.keys(source).forEach((field) => {
        const sv = source[field];
        if (isPlainObject(sv)) {
            if (target[field] === undefined || target[field] === null) target[field] = {};
            deepMerge(target[field], sv);
        } else {
            target[field] = Array.isArray(sv) ? sv.slice() : sv;
        }
    });
    return target;
}

module.exports = deepMerge;

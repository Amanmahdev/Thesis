
const fs = require('node:fs');

function isObj(v) {
	return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function loadTemplate(name) {
	return JSON.parse(fs.readFileSync(`templates/${name}.json`, 'utf8'));
}

function deepCopy(obj) {
	return structuredClone(obj);
}

function cloneItem(x) {
	if (Array.isArray(x)) return x.map(cloneItem);
	if (x !== null && typeof x === 'object') return copyProps({}, x);
	return x;
}

function copyProps(dest, src) {
	Object.keys(src).forEach((k) => {
		if (k === '__proto__') {
			return;
		}
		const incoming = src[k];
		if (Array.isArray(incoming)) {
			dest[k] = incoming.map(cloneItem);
		} else if (isObj(incoming)) {
			if (!dest[k]) dest[k] = {};
			copyProps(dest[k], incoming);
		} else {
			dest[k] = incoming;
		}
	});
	return dest;
}

function instantiateTemplate(name, userValues) {
	const out = deepCopy(loadTemplate(name));
	copyProps(out, userValues);
	return out;
}

module.exports.loadTemplate = loadTemplate;
module.exports.deepCopy = deepCopy;
module.exports.copyProps = copyProps;
module.exports.instantiateTemplate = instantiateTemplate;

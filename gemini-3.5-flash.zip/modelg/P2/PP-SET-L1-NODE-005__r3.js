
function set(object, path, value) {
  const tokens = Array.isArray(path) ? path.map(String) : String(path).replace(/\[(\w*)\]/g, '.$1').split('.').filter(Boolean);
  let holder = object;
  for (let pos = 0; pos < tokens.length - 1; pos++) {
    const prop = tokens[pos];
    if (holder[prop] === undefined) holder[prop] = /^\d+$/.test(tokens[pos + 1]) ? [] : {};
    holder = holder[prop];
  }
  const finalKey = tokens[tokens.length - 1];
  holder[finalKey] = value;
  return object;
}

module.exports.set = set;

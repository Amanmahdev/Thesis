
'use strict';

function copyValue(x) {
    if (Array.isArray(x)) return x.map(copyValue);
    if (x !== null && typeof x === 'object') return copyInto({}, x);
    return x;
}

function copyInto(target, source) {
    Object.keys(source).forEach((prop) => {
        const item = source[prop];
        if (Array.isArray(item)) {
            target[prop] = item.map(copyValue);
        } else if (item && typeof item === 'object' && !Array.isArray(item)) {
            if (target[prop] === undefined) target[prop] = {};
            copyInto(target[prop], item);
        } else {
            target[prop] = item;
        }
    });
    return target;
}

module.exports.copyInto = copyInto;
